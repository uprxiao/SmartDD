import { breadcrumbSelectionText } from '../../../src/shared/file-breadcrumb-copy.mjs';
import { FileEditorStatus } from '../../../src/shared/file-editor-status';
import { ReviewTextModel } from '../../../src/renderer/features/files/review-text/model.mjs';
import { ReviewTextPane } from '../../../src/renderer/features/files/review-text/pane';
import { Volume2 as MediaVolume2, VolumeX as MediaVolumeX, Check as MediaCheck } from 'lucide-react';
import { mediaCopyLink } from '../../../src/shared/media-source-policy.mjs';
import {readPrototypeReading,rememberPrototypeReading} from './file-reading-model.mjs';
import { searchPriorityFolders } from '../../../src/shared/file-search-priority.mjs';
import { FILE_SEARCH_INPUT_LIMIT, clampFileSearchInput } from '../../../src/shared/file-search-input.mjs';
import FileHtmlPreview from './FileHtmlPreview';
import FileRecoveryPrototype from './FileRecoveryPrototype';
import { prototypeAttachmentFile, attachmentExamples } from './file-attachment-presentation.mjs';
import { Globe as WebGlobe } from 'lucide-react';
import { isNonLocalFileSource, NONLOCAL_WORKSPACE_MESSAGE } from '../../../src/shared/file-source-boundary.mjs';
import FileMcpViewer from './FileMcpViewer';
import FileLanguageTools, { LANGUAGE_ACTIONS } from './FileLanguageTools';
import { FILE_DRAG_TYPE, beginFileDrag, endFileDrag } from './file-drag-model.mjs';
import { composing as imeComposing } from './file-ime.mjs';
import { guardEditorComposition } from '../../../src/shared/file-composition-shortcut.mjs';
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { File, FileCode2, FileText, FileSearch, FolderOpen, Folder, ChevronDown, ChevronRight, X, Plus, Search, PanelRight, Maximize2, Minimize2, Code2, Copy, ExternalLink, Check, AlertCircle, RotateCcw, Save, Download, Sun, Moon, Settings2, MoreHorizontal, Undo2, Redo2, WrapText, TextSelect, Image, FileSpreadsheet, FileSliders, Play, Pause, ZoomIn, ZoomOut, ArrowLeft, ArrowRight, Pin, Loader2 } from 'lucide-react';
import { fileAbsolutePath, fileDisplayLocation, fileNavigationLocation, rootRelativePath } from '../../../src/shared/file-root-location.mjs';
import { treeSetInfo, FILES, FILE_BY_PATH, SAMPLE_MD, fileKey, initialWorkspace, openFile, closeFile, restoreFile, updatePdfReading, treeRows, directoryChildren, treeKeyboardIntent, searchTreeRows, migratePrototypeSaved, openDocument, readRootView, updateRootView } from './file-workspace-model.mjs';
import iconMap from './m9-icon-map.json';
import { FileArtifactPreview } from './FileArtifactPreview';
import { createOfficeDocument, serializeOffice } from './file-office-model.mjs';
import { FileMarkdown } from './FileMarkdown';
import { findFileText } from '../../../src/renderer/features/files/text-find.ts';
import { GoToLineButton, GoToLinePanel } from '../../../src/renderer/features/files/go-to-line.tsx';
import { prototypeLineNavigator } from './file-line-navigation.mjs';
import { normalizeReference, formatReference, formatReferenceTray, pasteData, referenceStaleness, selectionLineRange, textFingerprint, REF_LIMITS } from './file-reference-model.mjs';
import { FileConflictSource } from './FileConflictSource.jsx';
import { workspaceScope, searchFiles, serializeWorkspaceStore, documentKey, fileScenario, setFileScenario, editDraft, commitDraft, acceptDisk, continueConflict, captureSelection, selectionIsCurrent, applyExternalFileChange, queueSyntheticFile, prototypeDirectoryFiles, queueSyntheticDirectoryChanges, refreshSyntheticDirectoryStore, retrySyntheticFile, openVerifiedDocument, completeSyntheticFileRestores, completeSyntheticWorkspaceRestores, prototypeCloseContext, prototypeCloseIsCurrent, prototypeModeSwitchContext, completePrototypeModeSwitch, artifactModel, updateArtifactCell, updateArtifactSlide, preparePrototypeTaskClose } from './file-workspace-model.mjs';
import { FileWorkspaceTree } from './FileWorkspaceTree';
import { FileCodeTextarea, FilePrototypeBlame } from './FileCodeTextarea';
import { createFixtureFileProvider, largeDirectoryFixture, latestRequestGate } from './file-interaction-model.mjs';
import { MISSING_PROTOTYPE_APPLICATION, prototypeApplicationChoices, prototypeOpenApplication, prototypeRevealTarget } from './file-actions-model.mjs';
import { normalizeSearchHistory, readSearchHistories, writeSearchHistory } from './file-search-history-model.mjs';
import './file-workspace.css';
const LARGE_FILES = largeDirectoryFixture();
const STORAGE = 'willyou-m9-prototype-v1';
const load = () => {
  try {
    const saved=JSON.parse(localStorage.getItem(STORAGE)) || {};
    return {...saved,saved:migratePrototypeSaved(saved.saved)};
  } catch {
    return {};
  }
};
const isText = f => ['code', 'markdown', 'html', 'svg', 'large'].includes(f?.kind);
function Icon({
  file,
  size = 16
}) {
  const path = typeof file === 'string' ? file : file?.path || '';
  const name = path.split('/').pop().toLowerCase();
  const ext = name.split('.').slice(1);
  let type = iconMap.fileNameTokens[name];
  for (let i = 0; !type && i < ext.length; i++) {
    const suffix = ext.slice(i).join('.');
    type = iconMap.completeExtensionOverrides[suffix] || iconMap.extensionTokens[suffix];
  }
  type = type || iconMap.defaultType;
  const colors = iconMap.palette[iconMap.colorRoles[type]];
  return <svg className="fw-file-icon" width={size} height={size} viewBox="0 0 16 16" aria-hidden="true" style={{
    '--file-light': colors?.light || 'currentColor',
    '--file-dark': colors?.dark || 'currentColor'
  }}><use href={iconMap.spriteUrl + '#' + iconMap.idPrefix + type} /></svg>;
}
function PrototypeBreadcrumbDirectory({ files, prefix, rootPath, scenario, onDirectory, onChoose }) {
  const entries = directoryChildren(files, prefix), [attempt, setAttempt] = useState(0), [state, setState] = useState(null);
  const key = JSON.stringify([prefix, scenario, attempt, entries]);
  useEffect(() => {
    const timer = setTimeout(() => setState({ key, phase: scenario === 'permission' && !attempt ? 'error' : 'ready' }), scenario === 'slow' ? 600 : 0);
    return () => clearTimeout(timer);
  }, [key]);
  // A new synthetic directory never paints the previous directory's rows.
  const phase = state?.key === key ? state.phase : 'loading';
  return <div className="fw-breadcrumb-directory">{phase === 'loading' ? <p role="status"><Loader2 size={14} className="animate-spin" />正在读取目录…</p>
    : phase === 'error' ? <p role="alert">PERMISSION：无法读取目录（合成，重试后恢复）<button onClick={() => setAttempt(value => value + 1)}>重试</button></p>
    : entries.length ? entries.map(file => <button key={file.path} title={fileAbsolutePath({ path: rootPath }, file.path) || ''} onClick={() => file.folder ? onDirectory(file.path) : onChoose(file.path)}>{file.folder ? <Folder size={15} /> : <Icon file={file} />} {file.name}</button>)
    : <p role="status">此目录为空</p>}</div>;
}
const Button = ({
  icon: C,
  label,
  onClick,
  active,
  disabled,
  preserveEditorFocus = false
}) => <button className={'fw-icon ' + (active ? 'active' : '')} title={label} aria-label={label} onMouseDown={event => { if (event.button === 0 && preserveEditorFocus && document.activeElement?.closest('.fw-content textarea, .fw-content [contenteditable="true"], .fw-content .cm-editor')) event.preventDefault(); }} onClick={onClick} disabled={disabled}><C size={17} strokeWidth={1.65} /></button>;
function ContentSearch({
  onClose,
  onOpen,
  scope,
  searchScenario = 'ready',
  files = FILES,
  priorityFolders = []
}) {
  const loadHistory = () => normalizeSearchHistory(readSearchHistories(localStorage).find(item => item.scope === scope));
  const [query, setQuery] = useState(''),
    [mask, setMask] = useState(''),
    [selected, setSelected] = useState(0),
    [history, setHistory] = useState(loadHistory);
  const composing = useRef(false), [submittedQuery, setSubmittedQuery] = useState(''), [submittedMask, setSubmittedMask] = useState('');
  const commitQuery = value => { const text = clampFileSearchInput(value); setQuery(text); setSubmittedQuery(text); };
  const commitMask = value => { const text = clampFileSearchInput(value); setMask(text); setSubmittedMask(text); };
  const [hits, setHits] = useState([]),
    [busy, setBusy] = useState(false),
    [spinner, setSpinner] = useState(false),
    [error, setError] = useState(''), [capped,setCapped]=useState(false), [attempt,setAttempt]=useState(0);
  const priorityKey=JSON.stringify(priorityFolders);
  const provider=useMemo(()=>createFixtureFileProvider(files),[files]), gate=useRef(latestRequestGate());
  const input = useRef(null),
    historyIndex = useRef(-1),
    historyDraft = useRef(''), maskHistoryIndex = useRef(-1), maskHistoryDraft = useRef(''), resultsRef = useRef(null);
  const returnFocus = useRef(document.activeElement);
  useEffect(() => () => { const previous = returnFocus.current; requestAnimationFrame(() => { if (previous?.isConnected && document.activeElement === document.body) previous.focus(); }); }, []);
  useEffect(() => {
    setHistory(loadHistory()); historyIndex.current = -1; historyDraft.current = ''; maskHistoryIndex.current = -1; maskHistoryDraft.current = '';
    commitQuery(''); commitMask(''); setSelected(0);
  }, [scope]);
  useEffect(()=>{resultsRef.current?.querySelector('[aria-selected=true]')?.scrollIntoView({block:'nearest'});},[selected]);
  const remember = (rememberQuery = false) => {
    const next = {
      queries: rememberQuery && query ? [query, ...history.queries.filter(x => x !== query)].slice(0, 30) : history.queries,
      masks: mask.trim() ? [mask.trim(), ...history.masks.filter(x => x !== mask.trim())].slice(0, 20) : history.masks
    };
    setHistory(next);
    try {
      writeSearchHistory(localStorage, scope, next);
    } catch {
      setError('原型搜索历史未能保存。');
    }
  };
  useEffect(() => {
    const token=gate.current.start(scope+':'+submittedQuery+':'+submittedMask+':'+priorityKey);
    setHits([]);setError('');setCapped(false);setSelected(0);setSpinner(false);
    if(!submittedQuery.trim()){setBusy(false);return()=>gate.current.cancel();}
    setBusy(true);
    const spin=setTimeout(()=>{if(gate.current.accepts(token))setSpinner(true);},500);
    const work=setTimeout(()=>provider.content(submittedQuery,submittedMask,{signal:token.signal,priorityFolders,mode:searchScenario==='error'&&attempt>0?'ready':searchScenario,onChunk:batch=>{if(gate.current.accepts(token))setHits(old=>[...old,...batch]);}}).then(result=>{
      if(gate.current.accepts(token)){setHits(result.hits);setCapped(result.capped);}
    }).catch(error=>{if(gate.current.accepts(token))setError(error.message);}).finally(()=>{
      if(gate.current.accepts(token)){setBusy(false);setSpinner(false);clearTimeout(spin);}
    }),50);
    return()=>{gate.current.cancel();clearTimeout(work);clearTimeout(spin);};
  },[provider,submittedQuery,submittedMask,scope,searchScenario,attempt,priorityKey]);
  const pick = r => {
    if (!r || busy) return;
    remember(true);
    onOpen(r.path, query, r.number, r.column);
  };
  const keydown = e => {
    if (composing.current || imeComposing(e)) return;
    if (e.key === 'Escape') {
      e.stopPropagation();
      onClose();
    }
    if (e.key === 'ArrowUp' && e.target === input.current && (selected === 0 || !hits.length)) {
      e.preventDefault();
      if (historyIndex.current === -1) historyDraft.current = query;
      if (historyIndex.current + 1 < history.queries.length) commitQuery(history.queries[++historyIndex.current]);
      return;
    }
    if (e.key === 'ArrowDown' && e.target === input.current && historyIndex.current >= 0) {
      e.preventDefault();
      historyIndex.current--;
      commitQuery(historyIndex.current < 0 ? historyDraft.current : history.queries[historyIndex.current]);
      return;
    }
    if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
      e.preventDefault();
      setSelected(i => Math.max(0, Math.min(hits.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1))));
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      pick(hits[selected]);
    }
  };
  return <div className="fw-modal-scrim" onClick={onClose}><section className="fw-dialog fw-search-dialog" role="dialog" aria-modal="true" aria-label="在文件中搜索" onClick={e => e.stopPropagation()} onKeyDown={keydown}>
    <div className="fw-find"><Search size={18} /><input ref={input} aria-label="搜索文件内容" autoFocus maxLength={FILE_SEARCH_INPUT_LIMIT} placeholder="搜索所有文件中的文本…" value={query} onCompositionStart={() => { composing.current = true; }} onCompositionEnd={e => { composing.current = false; commitQuery(e.currentTarget.value); }} onChange={e => {
          if (composing.current) setQuery(e.target.value); else commitQuery(e.target.value);
          setSelected(0);
          historyIndex.current = -1;
        }} /><Button icon={X} label="关闭内容搜索" onClick={onClose} /></div>
    <div className="fw-search-mask"><label>文件范围<input aria-label="文件范围" list="m9-file-masks" maxLength={FILE_SEARCH_INPUT_LIMIT} value={mask} onCompositionStart={() => { composing.current = true; }} onCompositionEnd={e => { composing.current = false; commitMask(e.currentTarget.value); }} onChange={e => {maskHistoryIndex.current = -1; if (composing.current) setMask(e.target.value); else commitMask(e.target.value);}} onKeyDown={e => {
            if(composing.current || imeComposing(e))return;
            if (['ArrowUp', 'ArrowDown', 'Enter'].includes(e.key)) e.stopPropagation();
            if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
              e.preventDefault(); if (!history.masks.length) return;
              if (maskHistoryIndex.current < 0) maskHistoryDraft.current = mask;
              const next = maskHistoryIndex.current < 0 ? 0 : Math.max(-1, Math.min(history.masks.length - 1, maskHistoryIndex.current + (e.key === 'ArrowDown' ? 1 : -1)));
              maskHistoryIndex.current = next; commitMask(next < 0 ? maskHistoryDraft.current : history.masks[next]); return;
            }
            if (e.key === 'Enter') {
              e.preventDefault(); maskHistoryIndex.current = -1; remember();
              input.current?.focus();
            }
          }} placeholder="*.ts" /><datalist id="m9-file-masks">{history.masks.map(m => <option key={m} value={m} />)}</datalist></label><span>{spinner ? '搜索中…' : hits.length + ' 条匹配'}{capped ? '（仅显示前100行）' : ''}</span></div>
    <div className="fw-search-results" ref={resultsRef} role="listbox" aria-label="搜索结果" aria-busy={busy}>{hits.map((r, i) => <button key={r.path + ':' + r.number} role="option" aria-selected={selected === i} onMouseEnter={() => setSelected(i)} onClick={() => pick(r)}><code>{r.line.slice(0, r.column - 1)}<mark>{r.line.slice(r.column - 1, r.column - 1 + query.length)}</mark>{r.line.slice(r.column - 1 + query.length)}</code><span title={r.path}><Icon file={r.path} />{r.path}<small>:{r.number}:{r.column}</small></span></button>)}{error && <p role="alert">{error}<button onClick={()=>setAttempt(v=>v+1)}>重试搜索</button></p>}{query && !hits.length && !busy && !error && <p>没有匹配内容</p>}{!query && <p>搜索当前目录中的文件内容；↑ 可访问本目录的查询历史。</p>}</div>
    <small>↑↓ 选择 · Enter 打开 · Esc 关闭。原型以可取消的异步批次搜索合成文件；不是实际 rg 后端。</small>
  </section></div>;
}
export function Media({
  kind,
  name,
  sourceUrl,
  sourcePath,
  src = name,
  onCopy,
  onDownload
}) {
  const copyLink = kind === 'video' ? mediaCopyLink(sourceUrl) : null;
  const copyPath = sourcePath === undefined ? name : sourcePath;
  const [playing, setPlaying] = useState(false),
    [position, setPosition] = useState(0),
    [speed, setSpeed] = useState(1),
    [muted, setMuted] = useState(false),
    [volume, setVolume] = useState(.75),
    [expanded, setExpanded] = useState(false),
    [pip, setPip] = useState(false),
    [menu, setMenu] = useState(false),
    [volumeOpen, setVolumeOpen] = useState(false);
  const resume = useRef(false);
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => setPosition(p => {
      if (p >= 20) {
        setPlaying(false);
        return 20;
      }
      return Math.min(20, p + .1 * speed);
    }), 100);
    return () => clearInterval(timer);
  }, [playing, speed]);
  const toggle = () => {
    if (position >= 20) setPosition(0);
    setPlaying(p => !p);
  };
  const release = () => {
    if (resume.current) setPlaying(true);
    resume.current = false;
  };
  const time = n => Math.floor(n / 60) + ':' + String(Math.floor(n % 60)).padStart(2, '0');
  return <div className={'fw-media ' + (expanded ? 'fw-media-expanded' : '') + (pip ? ' fw-media-pip' : '')} onKeyDown={e=>{if(e.key==='Escape'&&!e.nativeEvent.isComposing){setMenu(false);setVolumeOpen(false);}}}>
  {kind === 'video' ? <div className="fw-video-frame" tabIndex={0} aria-label="视频画面" onKeyDown={e => {
      if (!e.nativeEvent.isComposing && e.keyCode !== 229 && [' ', 'Enter'].includes(e.key)) {
        e.preventDefault();
        if (!e.repeat) toggle();
      }
    }}><img src="/assets/app-icon.png" alt="WillYou 演示画面" /><h2>文件工作区</h2><p>媒体控件交互示例</p></div> : <strong>{name} · WAV</strong>}
  <div className="fw-media-bar"><Button icon={playing ? Pause : Play} label={playing ? '暂停' : '播放'} onClick={toggle} /><input aria-label="播放进度" type="range" min={0} max={20} step={.1} value={position} onPointerDown={() => {
        resume.current = playing;
        setPlaying(false);
      }} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release} onChange={e => setPosition(+e.target.value)} /><span>{time(position)} / {time(20)}</span>
  {kind === 'video' && <><button aria-label="视频音量" aria-expanded={volumeOpen} onClick={() => setVolumeOpen(!volumeOpen)}>{muted||volume===0?<MediaVolumeX size={17}/>:<MediaVolume2 size={17}/>}</button>{volumeOpen && <span className="fw-volume"><button aria-label={muted ? '取消静音' : '静音'} onClick={() => setMuted(!muted)}>{muted ? '取消静音' : '静音'}</button><input aria-label="音量" type="range" min={0} max={1} step={.01} value={muted ? 0 : volume} onChange={e => {
            setVolume(+e.target.value);
            setMuted(false);
          }} /></span>}<button onClick={() => setPip(!pip)}>{pip ? '退出画中画' : '画中画（模拟）'}</button><Button icon={expanded ? Minimize2 : Maximize2} label={expanded ? '退出全屏示例' : '全屏示例'} onClick={() => setExpanded(!expanded)} /></>}
  <Button icon={MoreHorizontal} label="媒体菜单" onClick={() => setMenu(!menu)} /></div>
  {menu && <div className="fw-media-options">{kind === 'audio' && typeof copyPath === 'string' && copyPath && !/^data:/i.test(copyPath) && typeof onCopy === 'function' && <button onClick={() => {
        if (sourcePath === undefined) onCopy(); else onCopy(sourcePath);
        setMenu(false);
      }}>复制路径</button>}{src && typeof onDownload === 'function' && <button onClick={() => {
        onDownload();
        setMenu(false);
      }}>{kind === 'video' ? '视频另存为' : '另存副本'}</button>}{copyLink && <button onClick={()=>{onCopy(copyLink);setMenu(false);}}>复制链接</button>}{kind === 'video' && <div role="group" aria-label="播放速度"><span className="fw-media-speed-label">播放速度</span>{[.25,.5,.75,1,1.25,1.5,1.75,2].map(v=><button key={v} role="menuitemradio" aria-checked={speed===v} className="fw-media-speed" onClick={()=>setSpeed(v)}><span className="fw-media-check">{speed===v&&<MediaCheck size={13}/>}</span>{v}×</button>)}</div>}</div>}
  <small>模拟时间轴和控件；不播放真实文件。系统全屏、画中画可用性与 codec 尚未验证。</small></div>;
}
function FileReviewTextExample({ text }) {
  // Synthetic design state only. Real256MiB reads/hash/cancellation are App I/A.
  const model = useMemo(() => new ReviewTextModel(new TextEncoder().encode(text)), [text]);
  const [index, setIndex] = useState(0);
  return <section className="fw-review-text"><ReviewTextPane value={model.window(Math.min(index, model.info.pages - 1))} onPage={setIndex} /></section>;
}
export function FileWorkspace(props) {
  // Historical/foreign task identities never select the synthetic local tree.
  // Keep the source state untouched; switching back to a local task is reversible.
  if (isNonLocalFileSource(props.task) || isNonLocalFileSource(props.project)) return <section className="file-workspace" aria-label="文件工作区"><div className="fw-empty" role="alert"><AlertCircle size={20}/><p>{NONLOCAL_WORKSPACE_MESSAGE}</p><p>项目的服务器配置仍可用于已有终端功能。</p><button onClick={props.onClose}>关闭文件工作区</button></div></section>;
  return <LocalFileWorkspace key={JSON.stringify([props.task.id, props.task.hostId || 'local', props.task.cwd || props.project.path])} {...props}/>;
}
function LocalFileWorkspace({
  imageMenuScope, imageContext, imageGalleryRouting, resolveImageOpen, repositoryWebUrl, repositoryCommitId, onRepositoryLink,
  task,
  project,
  dark,
  onTheme,
  onClose,
  // M12 (optional): web tabs share this strip. Omitted props keep M9 behaviour unchanged.
  webTabs = [], webActiveId = null, onWebSelect, onWebClose, onWebNew, webView
}) {
  const officeResources=useRef(new Map());
  const registerOfficeResource=(root,path,resource)=>{const key=fileKey(root,path);if(!resource){officeResources.current.delete(key);return;}officeResources.current.set(key,resource);return()=>{if(officeResources.current.get(key)===resource)officeResources.current.delete(key);};};
  const [store, setStore] = useState(load),
    [query, setQueryLocal] = useState(''),
    [menu, setMenuState] = useState(null),
    [confirm, setConfirm] = useState(null),
    [recoveryOpen, setRecoveryOpen] = useState(false),
    [demo, setDemo] = useState(false),
    [attachmentExample, setAttachmentExample] = useState('plain'),
    [attachmentCopy, setAttachmentCopy] = useState(null),
    [full, setFull] = useState(false),
    [searchMode, setSearchMode] = useState(false),
    [status, setStatus] = useState(''),
    [modePending, setModePending] = useState(null),
    [auto, setAuto] = useState(true),
    [find, setFind] = useState(''),
    [findIndex, setFindIndex] = useState(0),
    [focusedPath, setFocusedPathLocal] = useState('AGENTS.md'),
    [searchCollapsed, setSearchCollapsed] = useState([]),
    [appsState, setAppsState] = useState('ready'),
    [appsScenario, setAppsScenario] = useState('ready'),
    [appsAttempt, setAppsAttempt] = useState(0),
    [rememberApp, setRememberApp] = useState(false),
    [treeDataset, setTreeDataset] = useState('normal'),
    [searchScenario, setSearchScenario] = useState('ready'),
    [breadcrumbScenario, setBreadcrumbScenario] = useState('ready'),
    [directoryWatch, setDirectoryWatch] = useState(true),
    [workspaceConflict, setWorkspaceConflict] = useState(null),
    [rootScenario, setRootScenario] = useState('multiple'),
    [finding, setFinding] = useState(false),
    [lineNavigation, setLineNavigation] = useState(null),
    [context, setContext] = useState(''),
    [rich, setRich] = useState(null),
    [dock, setDock] = useState('right'),
    [contentSearch, setContentSearch] = useState(false),
    [wrap, setWrap] = useState(false),
    [selection, setSelection] = useState(null),
    [aiState, setAiState] = useState(null),
    [refs, setRefs] = useState([]), [refOptions, setRefOptions] = useState({ includeText: true, style: 'plain' }), [refPreview, setRefPreview] = useState(false), [refBusy, setRefBusy] = useState(false),
    [terminalBracketed, setTerminalBracketed] = useState(false),
    [composing, setComposing] = useState(false),
    [selectedRows, setSelectedRowsLocal] = useState([]),
    [reveal, setReveal] = useState(null),
    [imageOverlay, setImageOverlay] = useState(false),
    [changedOnly, setChangedOnly] = useState(false),
    [hideGenerated, setHideGenerated] = useState(false),
    [blame, setBlame] = useState(false),
    [extension, setExtension] = useState(false),
    [symbol, setSymbol] = useState(null);
  const roots = rootScenario==='none'?[]:[{
    id: 'main',
    hostId: task.hostId || 'local',
    label: project.name || 'WillYou',
    path: task.cwd || project.path || '/workspace/SmartDD'
  }, ...(rootScenario==='single'?[]:[{
    id: 'extra',
    hostId: task.hostId || 'local',
    label: '共享文档',
    path: rootScenario==='nested' ? (task.cwd || project.path || '/workspace/SmartDD')+'/docs' : '/workspace/shared-docs'
  }])];
  const scope = workspaceScope(task.id, roots);
  useEffect(() => {
    const prepare = event => {
      if (event.detail.taskId !== task.id) return;
      const outcome = preparePrototypeTaskClose(store, task.id, event.detail.action);
      setStore(outcome.store);
      localStorage.setItem(STORAGE, JSON.stringify(serializeWorkspaceStore(outcome.store)));
      event.detail.reply(outcome);
    };
    window.addEventListener('m9:prepare-session-close', prepare);
    return () => window.removeEventListener('m9:prepare-session-close', prepare);
  }, [store, task.id]);
  const [treeReveal, setTreeReveal] = useState(null);
  useEffect(() => setTreeReveal(null), [scope]);
  const createState=()=>roots.length?initialWorkspace():{...initialWorkspace(),tabs:[],active:null};
  const state = store[scope] || createState(),
    set = fn => setStore(old => {
      const previous=old[scope]||createState();
      const next=typeof fn==='function'?fn(previous):fn;
      if(next===previous)return old;
      return {...old,[scope]:next.expanded!==previous.expanded?updateRootView(next,{expanded:next.expanded}):next};
    });
  function dragFile(event, rootId, path, allowTabReorder = false) {
    if (!task?.id || task.status !== 'running') {
      if (!allowTabReorder) event.preventDefault();
      endFileDrag(); note('当前没有可用的任务终端；路径未投递，文件浏览仍可使用。'); return;
    }
    const selectedRoot = roots.find(root => root.id === rootId), source = getFile(rootId, path);
    if (!selectedRoot || !source || source.kind === 'missing' || ['missing', 'root-missing'].includes(fileScenario(state, fileKey(rootId, path)))) {
      if (!allowTabReorder) event.preventDefault();
      endFileDrag(); note(allowTabReorder ? '文件已删除或目录不可用，仅可调整标签顺序，不能投递路径。' : '文件已删除或目录不可用，未开始拖放。'); return;
    }
    const result = beginFileDrag({ taskId: task.id, ptyId: task.ptyId ?? task.id, rootPath: selectedRoot.path, relativePath: path });
    if (!result.ok) { if (!allowTabReorder) event.preventDefault(); note('文件路径含不支持的字符，不能投递路径。'); return; }
    event.dataTransfer.setData(FILE_DRAG_TYPE, result.token);
    event.dataTransfer.effectAllowed = 'copyMove';
  }
  function finishFileDrag() { endFileDrag(); dragged.current = null; }
  function defaultFilesForRoot(id=state.root) {
    const defaults=rootScenario==='nested'&&id==='extra'?FILES.filter(f=>f.path.startsWith('docs/')).map(f=>({...f,path:f.path.slice(5)})):FILES;
    return treeDataset==='empty'?[]:[...defaults, ...(treeDataset==='large'?LARGE_FILES:[])];
  }
  function filesForRoot(id=state.root) { return treeDataset==='empty'?[]:prototypeDirectoryFiles(state,id,defaultFilesForRoot(id)); }
  const activeFiles = useMemo(()=>filesForRoot(),[rootScenario,state.root,state.syntheticFiles,state.removedPaths,treeDataset]);
  const treeSourceKey = scope + ':' + state.root + ':' + treeDataset;
  function getFile(id,path) {return filesForRoot(id).find(f=>f.path===path);}
  function setQuery(value) {const next=typeof value==='function'?value(query):value;if(next.trim())setTreeReveal(null);setQueryLocal(next);set(s=>updateRootView(s,{query:next,...(next.trim()&&next!==query?{searchScrollTop:0}:{})}));}
  function setSelectedRows(value) {const next=typeof value==='function'?value(selectedRows):value;setSelectedRowsLocal(next);set(s=>updateRootView(s,{selected:next}));}
  function setFocusedPath(value) {setFocusedPathLocal(value);set(s=>updateRootView(s,{focused:value}));}
  const current = state.tabs.find(t => fileKey(t.root, t.path) === state.active),
    file = prototypeAttachmentFile(state.retiredFiles?.[state.active] ?? getFile(current?.root,current?.path) ?? (current ? {path:current.path,kind:'missing',text:''}:undefined), current?.attachment),
    draft = state.drafts[state.active],
    identity = documentKey(roots, state.active),
    revision = state.revisions?.[state.active] || 0,
    text = draft?.text ?? state.retiredFiles?.[state.active]?.text ?? store.saved?.[identity] ?? file?.text ?? '',
    scenario = fileScenario(state),
    mode = current?.navigationView ? 'source' : state.mode[state.active] || (!current?.attachment && /\.(?:csv|tsv|html?|tex)$/i.test(current?.path || '') ? 'source' : 'render');
  const savePdfReading = useCallback(position => setStore(old => {
    const previous = old[scope]; if (!previous) return old;
    const next = updatePdfReading(previous, state.active, position);
    return next === previous ? old : { ...old, [scope]: next };
  }), [scope, state.active]);
  const pendingLocation = useRef(null);
  const editor = useRef(null),
    filter = useRef(null),
    host = useRef(null), content = useRef(null), modePositions = useRef(new Map()), modeIntent = useRef(0),
    compose = useRef(false),
    dragged = useRef(null),
    timer = useRef(null),
    historyRef = useRef({}),
    anchor = useRef(null), menuRef = useRef(null), triggerRef = useRef(null), pointerRef = useRef(null), treeRef = useRef(null), treeApiRef = useRef(null);
  const [hostWidth, setHostWidth] = useState(0);
  useLayoutEffect(() => {
    const node = host.current;
    if (!node) return;
    const measure = () => setHostWidth(node.clientWidth);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  const treeMaximum = (hostWidth || 1000) * .6, treeMinimum = Math.min(200, treeMaximum);
  const treeWidth = Math.max(treeMinimum, Math.min(state.width, treeMaximum));
  const root = roots.find(r => r.id === state.root) || roots[0] || {id:'none',path:'',label:'无工作目录',hostId:'local'},
    activeRoot = roots.find(r => r.id === current?.root) || root,
    activeAbsolutePath = current ? fileAbsolutePath(activeRoot, current.path) : null,
    displayLocation = activeAbsolutePath ? fileDisplayLocation(roots, activeAbsolutePath, activeRoot) : null,
    displayRoot = displayLocation?.root || activeRoot,
    displayPath = displayLocation?.relativePath ?? current?.path;
  const effective = state.retiredFiles?.[state.active] ? 'missing' : scenario === 'ready' ? file?.kind : scenario;
  const textMenu = isText(file) && !(file?.kind === 'svg' && mode !== 'source') || file?.kind === 'tex' && mode === 'source';
  const reading = readPrototypeReading(state,state.active,text);
  const modePositionKey = identity + ':' + mode;
  const scrollNode = () => host.current?.querySelector('textarea[aria-label="文件编辑器"]') || content.current;
  useLayoutEffect(() => { modeIntent.current++; }, [state.active]);
  useLayoutEffect(() => {
    const node = scrollNode(), position = modePositions.current.get(modePositionKey) ?? reading?.views[mode];
    if (editor.current && reading?.selection) { const {anchor,head}=reading.selection;editor.current.setSelectionRange(Math.min(anchor,head),Math.max(anchor,head),anchor>head?'backward':'forward'); }
    if (node) { node.scrollTop = position?.top || 0; node.scrollLeft = position?.left || 0; }
  }, [modePositionKey]);
  useLayoutEffect(() => {
    const location = pendingLocation.current, node = editor.current;
    if (!location || !node || current?.root !== location.root || current?.path !== location.path) return;
    pendingLocation.current = null;
    const lines = node.value.split('\n'), offset = (line, column, last = false) => {
      const index = Math.min((line ?? 1) - 1, lines.length - 1), start = lines.slice(0, index).reduce((n, value) => n + value.length + 1, 0);
      return start + Math.min(lines[index].length, column == null ? last ? lines[index].length : 0 : column - 1);
    };
    const from = offset(location.line, location.column), to = location.endLine == null ? from : Math.max(from, offset(location.endLine, location.endColumn, true));
    node.setSelectionRange(from, to); node.focus();
    node.scrollTop = Math.max(0, (location.line - 2) * (parseFloat(getComputedStyle(node).lineHeight) || 22));
  }, [state.active, current?.navigationView, mode, text]);
  function rememberReadingSelection(anchor,head) { set(s=>rememberPrototypeReading(s,state.active,text,{selection:{anchor,head}})); }
  function captureReading() {
    const node=scrollNode();if(!node?.isConnected||!current)return;
    const area=editor.current,range=area?{anchor:area.selectionDirection==='backward'?area.selectionEnd:area.selectionStart,head:area.selectionDirection==='backward'?area.selectionStart:area.selectionEnd}:undefined;
    const position={top:node.scrollTop,left:node.scrollLeft};modePositions.current.set(modePositionKey,position);
    set(s=>rememberPrototypeReading(s,state.active,text,{selection:range,view:{mode,...position}}));
  }
  function setMenu(next) {
    if (!next) { setMenuState(null); if(triggerRef.current?.isConnected)triggerRef.current.focus({preventScroll:true}); return; }
    if (next.type === 'external' && menu?.type !== 'external') setRememberApp(false);
    if (!menu) triggerRef.current = next.anchor || document.activeElement;
    const target = (next.anchor || document.activeElement)?.getBoundingClientRect();
    const location = next.point || (pointerRef.current && performance.now()-pointerRef.current.time<400 ? pointerRef.current : { x:target?.left||0, y:target?.bottom||0 });
    setMenuState({...next, root:next.root || (next.type==='file'?state.root:current?.root||state.root), point:location});
  }
  useLayoutEffect(() => {
    if(!menu || !menuRef.current) return;
    const el=menuRef.current;
    const position=()=>{
      el.style.maxHeight='';
      let r=el.getBoundingClientRect();
      if(menu.type==='crumb' && menu.anchor?.isConnected){
        const target=menu.anchor.getBoundingClientRect();
        const below=innerHeight-8-target.bottom-1, above=target.top-8-1;
        const side=below>=r.height || below>=above?'bottom':'top';
        el.style.maxHeight=Math.max(0,side==='bottom'?below:above)+'px';
        r=el.getBoundingClientRect();
        el.style.left=Math.max(8,Math.min(target.left,innerWidth-r.width-8))+'px';
        el.style.top=(side==='bottom'?target.bottom+1:target.top-1-r.height)+'px';
        el.dataset.side=side;el.dataset.align='start';
      }else{
        el.style.left=Math.max(8,Math.min(menu.point.x,innerWidth-r.width-8))+'px';
        el.style.top=Math.max(8,Math.min(menu.point.y,innerHeight-r.height-8))+'px';
        delete el.dataset.side;delete el.dataset.align;
      }
    };
    position();
    if(!el.contains(document.activeElement)||document.activeElement?.disabled)el.querySelector('button:not(:disabled)')?.focus();
    if(menu.type==='crumb'){
      window.addEventListener('resize',position);
      window.addEventListener('scroll',position,true);
      return()=>{window.removeEventListener('resize',position);window.removeEventListener('scroll',position,true);};
    }
  },[menu,appsState]);
  useEffect(()=>{
    if(!['file','external'].includes(menu?.type))return;
    if(appsScenario==='unavailable'){setAppsState('unavailable');return;}
    setAppsState('loading');
    if(appsScenario==='loading')return;
    const timer=setTimeout(()=>setAppsState(appsScenario==='error'&&appsAttempt===0?'error':'ready'),160);
    return()=>clearTimeout(timer);
  },[menu?.type,menu?.path,menu?.root,appsScenario,appsAttempt]);
  const menuRoot=roots.find(r=>r.id===menu?.root)||activeRoot;
  const applications = prototypeApplicationChoices(store.fileOpener);
  const modalActive=!!(confirm||contentSearch||aiState);
  useEffect(() => {
    if(!modalActive)return;
    const previous=document.activeElement, dialog=host.current?.querySelector('[role=dialog]');
    if(!dialog)return;
    dialog.querySelector('input,textarea,button')?.focus();
    const trap=e=>{
      if(e.key!=='Tab')return;
      const items=[...dialog.querySelectorAll('input:not(:disabled),textarea:not(:disabled),button:not(:disabled),select:not(:disabled),[tabindex="0"]')].filter(el=>el.getClientRects().length);
      if(!items.length)return;
      const index=items.indexOf(document.activeElement);
      if((e.shiftKey&&index<=0)||(!e.shiftKey&&index===items.length-1)){e.preventDefault();items[e.shiftKey?items.length-1:0].focus();}
    };
    dialog.addEventListener('keydown',trap);
    return()=>{dialog.removeEventListener('keydown',trap);if(previous?.isConnected)previous.focus();};
  },[modalActive,contentSearch,confirm?.type,aiState?.phase]);
  function changeRoot(id) {
    setTreeReveal(null);
    const next=readRootView(state,id);
    set(s=>({...s,root:id,expanded:next.expanded,rootStates:{...s.rootStates,[s.root]:{expanded:s.expanded,selected:selectedRows,query,focused:focusedPath,scrollTop:query.trim()?readRootView(state).scrollTop:(treeRef.current?.scrollTop||0),searchScrollTop:query.trim()?(treeRef.current?.scrollTop||0):(readRootView(state).searchScrollTop||0)}}}));
    setQueryLocal(next.query);setSelectedRowsLocal(next.selected);setFocusedPathLocal(next.focused);anchor.current=null;
    requestAnimationFrame(()=>{if(treeRef.current)treeRef.current.scrollTop=next.query.trim()?(next.searchScrollTop||0):next.scrollTop;});
  }
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE, JSON.stringify(serializeWorkspaceStore(store)));
    } catch {
      setStatus('原型存储已满；当前页内容仍保留。');
    }
  }, [store]);
  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => {
    if (!reveal || !editor.current) return;
    const offset = text.split('\n').slice(0, reveal.number - 1).join('\n').length + (reveal.number > 1 ? 1 : 0) + Math.max(0, (reveal.column || 1) - 1);
    editor.current.focus();
    editor.current.setSelectionRange(offset, offset + reveal.query.length);
    editor.current.scrollTop = Math.max(0, (reveal.number - 3) * 21);
    setReveal(null);
  }, [reveal, text, mode]);
  useLayoutEffect(() => {
    const view=readRootView(state);
    setQueryLocal(view.query);setSelectedRowsLocal(view.selected);setFocusedPathLocal(view.focused);
    setMenuState(null);setRich(null);anchor.current=null;setSearchCollapsed([]);
    const frame=requestAnimationFrame(()=>{if(treeRef.current)treeRef.current.scrollTop=view.scrollTop;});
    return()=>cancelAnimationFrame(frame);
  }, [scope]);
  useEffect(() => {
    setSelection(null);
    setAiState(null);
  }, [identity, revision]);
  function scenarioText(value, label) {
    if(['xlsx','pptx'].includes(file?.kind)) {
      const doc=createOfficeDocument(file.kind,value);
      if(file.kind==='xlsx')doc.sheets[0].cells[0][0]=label;
      else {doc.slides[0].title+=' · '+label;const title=doc.slides[0].elements.find(e=>e.kind==='text');if(title)title.text+=' · '+label;}
      return serializeOffice(doc);
    }
    return value + '\n' + label;
  }
  function setScenario(value, key = state.active) {
    const diskText = value === 'conflict' ? scenarioText(store.saved?.[documentKey(roots, key)] ?? getFile(key?.split('\u0000')[0],key?.split('\u0000')[1])?.text ?? '', '外部更新') : undefined;
    set(s => setFileScenario(s, key, value, diskText));
  }
  function note(message) {
    setStatus(message);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setStatus(''), 3500);
  }
  function openApplication(appId, remember = false, rootId = menu?.root || current?.root, path = menu?.path ?? current?.path) {
    const targetRoot = roots.find(candidate => candidate.id === rootId);
    const missing = !targetRoot || !path || ['missing', 'root-missing'].includes(fileScenario(state, fileKey(rootId, path)));
    const result = prototypeOpenApplication(store.fileOpener, appId, remember, { available: appsState === 'ready', missing });
    if (!result.ok) note(result.error);
    else {
      if (remember) setStore(previous => ({ ...previous, fileOpener: result.preference }));
      note(`${result.app.name}：原型模拟打开 ${targetRoot.path}/${path}；未启动外部应用。`);
    }
    setMenu(null);
  }
  function revealTarget(rootId, path = '', directory = false) {
    const targetRoot = roots.find(candidate => candidate.id === rootId);
    const result = prototypeRevealTarget(targetRoot?.path, path, { directory, missing: ['missing', 'root-missing'].includes(fileScenario(state, fileKey(rootId, path))) });
    note(result.ok ? `文件管理器（模拟）：显示 ${result.parent}；定位 ${result.selected}${directory ? '（目录）' : ''}。未启动 Finder。` : result.error);
    setMenu(null);
  }
  function locateFile(rootId, path) {
    const source = roots.find(r => r.id === rootId), absolute = fileAbsolutePath(source, path);
    const location = absolute ? fileNavigationLocation(roots, absolute, root, source) : null;
    if (location && location.root.id !== state.root) changeRoot(location.root.id);
    if (location) setTreeReveal({ id: crypto.randomUUID(), root: location.root.id, path: location.relativePath });
    return location;
  }
  function open(path, pin = false, rootId = state.root, { reveal = true, line, column, endLine, endColumn } = {}) {
    const located = line != null || column != null || endLine != null;
    const navigationView = located ? endLine != null || /\.pdf$/i.test(path) ? 'review' : 'source' : undefined;
    if (navigationView === 'review' && state.drafts[fileKey(rootId, path)]) { note('请先保存当前修改，再查看行范围。'); return false; }
    pendingLocation.current = located ? { root: rootId, path, line: line ?? 1, column, endLine, endColumn } : null;
    if (located) setExtension(false);
    const location = reveal ? locateFile(rootId, path) : null, treePath = location?.relativePath ?? path;
    if (!reveal) setTreeReveal(null);
    set(s => { const opened=openVerifiedDocument(s, roots, rootId, path, pin, defaultFilesForRoot(rootId)), next={...opened,tabs:opened.tabs.map(tab=>tab.root===rootId&&tab.path===path?{...tab,navigationView}:tab)};if(!reveal)return next;const ancestors=treePath.split('/').slice(0,-1).map((_,i)=>treePath.split('/').slice(0,i+1).join('/'));return {...next,expanded:[...new Set([...next.expanded,...ancestors])]}; });
    setRich(null);
    setMenu(null);
  }
  function save(key = state.active, override = false) {
    if (state.tabs.find(t => fileKey(t.root, t.path) === key)?.navigationView === 'review') { note('行范围只读预览'); return false; }
    if (state.tabs.find(t => fileKey(t.root, t.path) === key)?.attachment) { note('本机附件为只读，可通过来源下载或另存副本。'); return false; }
    if (fileScenario(state,key) === 'input-interrupted') { note('输入已中断，请返回编辑器继续输入或撤销后再保存'); return false; }
    if (!state.drafts[key]) return true;
    const outcome = commitDraft({
      ...store,
      [scope]: state
    }, scope, roots, key, {
      override
    });
    if (outcome.result === 'conflict') {
      setStore(old => commitDraft(old, scope, roots, key, {
        override
      }).store);
      setConfirm({
        type: 'conflict',
        key
      });
      return;
    }
    if (outcome.result === 'save-error') {
      note('保存失败：文件不可写。修改仍保留，可重试或另存为。');
      return;
    }
    if (outcome.result === 'missing') {
      note('文件不可读取、已缺失或换成另一文件；本地草稿保留，不能覆盖同名新文件。');
      return false;
    }
    if (outcome.result !== 'saved') return false;
    setStore(old => commitDraft(old, scope, roots, key, {
      override
    }).store);
    note('已保存到原型示例数据');
    return true;
  }
  useEffect(() => {
    if (!auto || !draft || scenario !== 'ready' || state.retiredFiles?.[state.active] || composing) return;
    const id = setTimeout(() => save(), ['xlsx', 'pptx'].includes(file?.kind) ? 500 : 3000);
    return () => clearTimeout(id);
  }, [text, auto, scenario, state.active, scope, composing]);
  function edit(value, record = true) {
    if (current?.attachment || current?.navigationView === 'review') return;
    if (value === text) return;
    if (record) {
      const h = historyRef.current[identity] || {
        undo: [],
        redo: []
      };
      h.undo.push(text);
      h.redo = [];
      historyRef.current[identity] = h;
    }
    const key = state.active;
    set(s => editDraft(s, key, value, store.saved?.[identity] ?? file?.text ?? ''));
  }
  function undo(redo = false) {
    if (current?.attachment || current?.navigationView === 'review') return;
    const h = historyRef.current[identity];
    if (!h) return;
    const from = redo ? h.redo : h.undo,
      to = redo ? h.undo : h.redo;
    if (!from.length) return;
    to.push(text);
    edit(from.pop(), false);
  }
  function demoScenario(value) {
    if (['conflict', 'save-error', 'input-interrupted'].includes(value) && file) edit(scenarioText(text, value === 'input-interrupted' ? '未确认候选' : '本地修改'));
    setScenario(value);
  }
  function switchMode() {
    const intent = ++modeIntent.current;
    if (draft && scenario === 'saving') {
      setModePending(prototypeModeSwitchContext(state, state.active, scope, intent, mode === 'source' ? 'render' : 'source'));
      note('等待合成保存完成，当前模式保留。');
      return;
    }
    if (draft && !save()) return;
    setExtension(false);
    set(s => ({
      ...s,
      tabs: s.tabs.map(tab => fileKey(tab.root, tab.path) === s.active ? { ...tab, navigationView: undefined } : tab),
      mode: {
        ...s.mode,
        [s.active]: mode === 'source' ? 'render' : 'source'
      }
    }));
    setRich(null);
  }
  function finishModeSave() {
    const outcome = completePrototypeModeSwitch(store, scope, roots, modePending, modeIntent.current);
    if (modePending && outcome.result === 'saved' && modePending.intent === modeIntent.current
      && outcome.store[scope]?.active === modePending.key
      && outcome.store[scope]?.mode[modePending.key] === modePending.target) setExtension(false);
    setStore(outcome.store); setModePending(null);
    note(outcome.result === 'saved' ? '合成保存已完成；仅当前有效的模式切换生效。' : '合成保存未通过或实例已变化，当前模式与草稿保留。');
  }
  function close(key, trigger) {
    const previousFocus = document.activeElement;
    const restoreFocus = trigger === previousFocus || Boolean(host.current?.contains(previousFocus));
    if (state.drafts[key]) {
      if (!save(key)) {
        setConfirm({
          type: 'close',
          ...prototypeCloseContext(state, key, scope)
        });
        return;
      }
    }
    set(s => closeFile(s, key));
    try { state.tabs.find(t => fileKey(t.root, t.path) === key)?.attachment?.onClose?.(); } catch { note('附件已关闭，但来源回调失败（原型模拟）。'); }
    if (restoreFocus) requestAnimationFrame(() => {
      if (previousFocus?.isConnected && previousFocus !== trigger) return;
      if (document.activeElement !== document.body && document.activeElement !== trigger) return;
      (host.current?.querySelector('[role="tab"][aria-selected="true"]') ?? host.current?.querySelector('[aria-label="查找并打开文件"]'))?.focus();
    });
  }
  function discard(key, context) {
    set(s => {
      if (context && !prototypeCloseIsCurrent(s, context, scope)) return s;
      const drafts = {
        ...s.drafts
      };
      delete drafts[key];
      return closeFile({
        ...s,
        drafts
      }, key);
    });
    setConfirm(current => context && current !== context ? current : null);
  }
  function reorder(key) {
    const source = dragged.current;
    if (!source || source === key) return;
    set(s => {
      const tabs = [...s.tabs],
        a = tabs.findIndex(t => fileKey(t.root, t.path) === source),
        b = tabs.findIndex(t => fileKey(t.root, t.path) === key);
      if (a < 0 || b < 0) return s;
      const [t] = tabs.splice(a, 1);
      tabs.splice(b, 0, {
        ...t,
        preview: false
      });
      return {
        ...s,
        tabs
      };
    });
  }
  function resize(e) {
    e.preventDefault();
    const start = e.clientX,
      w = treeWidth;
    const move = ev => set(s => ({
      ...s,
      tree: w + start - ev.clientX >= 100,
      width: Math.max(Math.min(200, host.current.clientWidth * .6), Math.min(host.current.clientWidth * .6, w + start - ev.clientX))
    }));
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
  }
  // ---- 文件/选区 → 终端输入（M9 GAP-07）。只“放入”输入，不回车；不调用模型；不解析终端输出。----
  const taskRunning = task?.status === 'running' && !task?.archived;
  const rangeText = (source, range) => source.split('\n').slice(range.startLine - 1, range.endLine).join('\n');
  function addRef(kind, { path, range, selection, noteText } = {}) {
    const selectedText = selection ? rangeText(selection.source, range) : '';
    const n = normalizeReference({ kind, relativePath: path, range, revision, selectedTextHash: selection ? textFingerprint(selectedText) : undefined, note: noteText });
    if (!n.ok) return note('无法添加引用：' + n.error);
    setRefs(list => list.some(x => x.ref.kind === n.ref.kind && x.ref.relativePath === n.ref.relativePath && JSON.stringify(x.ref.range) === JSON.stringify(n.ref.range)) ? list : [...list, { id: 'ref-' + Date.now() + '-' + list.length, ref: n.ref, selectedText }]);
    note('已加入终端引用（尚未放入终端）。');
  }
  function addPdfRefs(comments) {
    if (!current || !Array.isArray(comments) || !comments.length || comments.length > 64) return { ok: false, error: 'invalid-pdf-context' };
    const prepared = [];
    for (const item of comments) {
      const size = item.pageSize, rect = item.anchor?.kind === 'region' ? item.anchor.rect : item.anchor?.point && { ...item.anchor.point, width: 0, height: 0 };
      if (!(size?.width > 0 && size?.height > 0) || !rect) return { ok: false, error: 'invalid-pdf-context' };
      const pdf = { page: item.page, anchor: { x: rect.x / size.width, y: rect.y / size.height, width: rect.width / size.width, height: rect.height / size.height } };
      const selectedText = item.anchor.selectedText || '';
      const parsed = normalizeReference({ kind: 'pdf-comment', relativePath: current.path, pdf, revision, selectedTextHash: textFingerprint(selectedText), note: item.body });
      if (!parsed.ok) return parsed;
      prepared.push({ id: 'ref-' + crypto.randomUUID(), ref: parsed.ref, selectedText });
    }
    const next = [...refs];
    for (const item of prepared) if (!next.some(existing => existing.ref.relativePath === item.ref.relativePath && JSON.stringify(existing.ref.pdf) === JSON.stringify(item.ref.pdf) && existing.ref.note === item.ref.note && existing.ref.selectedTextHash === item.ref.selectedTextHash)) next.push(item);
    if (next.length > 64) return { ok: false, error: 'too-many-references' };
    setRefs(next); note('评论已加入终端引用；预览后可插入，不会自动回车。'); return { ok: true };
  }
  const refCurrent = item => {
    const f = getFile(state.root, item.ref.relativePath); if (!f) return { missing: true };
    const active = current && current.path === item.ref.relativePath;
    return { revision: active ? revision : undefined, selectedTextHash: active && item.ref.range ? textFingerprint(rangeText(text, item.ref.range)) : undefined };
  };
  const refTexts = items => formatReferenceTray(items, refOptions, refCurrent);
  const insertError = (code, length) => ({ 'task-not-running': '任务未运行，无法放入终端输入。', 'terminal-no-response': '插入结果未知，请先检查终端输入；内容已保留，不会自动重发。', 'too-large': (Number.isInteger(length) ? '内容共 ' + length + ' 字符，超过 ' : '内容超过 ') + REF_LIMITS.maxTotalChars + ' 字符，请取消“包含所选文字”或减少引用。', 'missing-source': '引用的文件不存在，请移除或重新选择。', empty: '没有可放入的内容。', 'pty-not-owned-by-task': '终端与当前任务不匹配，已拒绝。', 'no-terminal': '当前任务没有终端。' }[code] || '无法放入终端：' + code);
  async function sendToTerminal(textToSend) {
    const requestId = 'ins-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6); setRefBusy(true);
    const result = await new Promise(resolve => {
      const timer = setTimeout(() => { window.removeEventListener('m9:terminal-insert-result', handler); resolve({ ok: false, error: 'terminal-no-response' }); }, 1500);
      const handler = event => { if (event.detail?.requestId !== requestId) return; clearTimeout(timer); window.removeEventListener('m9:terminal-insert-result', handler); resolve(event.detail); };
      window.addEventListener('m9:terminal-insert-result', handler);
      window.dispatchEvent(new CustomEvent('m9:terminal-insert', { detail: { taskId: task.id, text: textToSend, requestId } }));
    });
    setRefBusy(false);
    if (!result.ok) { note(insertError(result.error)); return { ...result, requestId }; }
    note('已放入终端输入，未发送。' + (result.collapsed ? '此终端未启用括号粘贴，换行已折叠为空格。' : '') + (result.sanitized ? ' 已移除不安全的控制字符。' : '') + '请在终端检查后按 Enter。');
    return { ...result, requestId };
  }
  function prepareImageInput(image, options) {
    const sourcePath = current && (getFile(current.root, image.path) ? image.path : image.path === 'assets/app-icon.png' ? 'resources/app-icon.png' : null);
    const source = sourcePath && getFile(current.root, sourcePath);
    if (!source || source.kind !== 'image' || source.text !== image.src) return options.onState({ state: 'failed', message: '图片来源已变化或不可用，图片未加入。' });
    const request = { taskId: task.id, ptyId: task.ptyId ?? task.id, requestId: options.requestId, signal: options.signal,
      capability: options.scenario === 'no-input' ? 'unsupported' : options.scenario === 'unknown-input' ? 'unknown' : 'supported',
      behavior: options.scenario === 'reject-input' ? 'reject' : options.scenario === 'pending-input' ? 'pending' : 'normal',
      image: { kind: 'synthetic-image', sourceId: JSON.stringify([scope, current.root, sourcePath, source.text]), name: image.alt || image.path, mime: 'image/png', src: source.text },
      handled: false, onState: options.onState };
    window.dispatchEvent(new CustomEvent('m9:terminal-image-insert', { detail: request }));
    if (!request.handled) options.onState({ state: 'failed', message: '当前任务没有可用终端，图片未加入。' });
  }
  async function insertRefs() {
    if (!refs.length || refBusy) return;
    const built = refTexts(refs); if (!built.ok) return note(insertError(built.error, built.length));
    const result = await sendToTerminal(built.text); if (result.ok) setRefs([]);
  }
  async function requestCliEdit() {
    if (!aiState || refBusy) return;
    const request = aiState, sel = request.selection;
    if (!selectionIsCurrent(sel, { scope, identity, revision, text })) return note('文件或选区已变化，请重新选择。');
    const range = selectionLineRange(sel.source, sel.start, sel.end); if (!range) return note('选区无效。');
    const item = { ref: { kind: 'range', relativePath: current.path, range, revision, selectedTextHash: textFingerprint(rangeText(sel.source, range)), note: request.instruction.trim() }, selectedText: rangeText(sel.source, range) };
    const built = refTexts([item]); if (!built.ok) return note(insertError(built.error, built.length));
    const result = await sendToTerminal(built.text);
    // Handoff ends at insertion. Closing this draft cannot stop or undo terminal work.
    if (result.ok) setAiState(current => current === request ? null : current);
  }
  function simulateExternalChange() {
    if (!current || !file || !isText(file)) return;
    const disk = store.saved?.[identity] ?? file.text ?? '';
    const changed = scenarioText(disk, '独立外部更新示例');
    delete historyRef.current[identity];
    setStore(old => applyExternalFileChange({ ...old, [scope]: old[scope] || state }, scope, roots, state.active, changed));
    note(draft ? '检测到示例外部更新；未保存的手工草稿已保留，请处理普通文件冲突。' : '示例文件已刷新到最新内容。此操作不关联任何终端请求。');
  }
  function simulateDirectoryAddition() {
    const count = (state.syntheticFiles?.[state.root]?.length || 0) + (state.pendingFiles?.[state.root]?.length || 0) + 1;
    const file = { path: 'external-update-' + count + '.md', kind: 'markdown', text: '# 外部新增文件示例\n\n这是独立的合成目录更新，不来自终端执行。\n' };
    set(s => queueSyntheticFile(s, s.root, file));
    note('已模拟外部新增 ' + file.path + '；刷新示例目录后可见。未访问真实磁盘。');
  }
  function refreshDirectory() {
    treeApiRef.current?.refresh();
    setStore(old => refreshSyntheticDirectoryStore({...old,[scope]:old[scope]||state},scope,roots,state.root,defaultFilesForRoot()));
    note('示例目录已刷新。正式应用将读取磁盘并监听变化；此页仅演示合成数据。');
  }
  function simulateDirectoryChanges(changes,targetRoot=state.root) {
    setStore(old => {
      const previous=old[scope]||state,queued=queueSyntheticDirectoryChanges(previous,targetRoot,changes),next={...old,[scope]:queued};
      return directoryWatch ? refreshSyntheticDirectoryStore(next,scope,roots,targetRoot,defaultFilesForRoot(targetRoot)) : next;
    });
    note(directoryWatch?'已接收独立合成目录变化；不关联终端来源、执行或完成状态。':'已暂存合成磁盘变化；刷新或重新显示目录后补扫。');
  }
  function retryCurrentFile() {
    if(!current)return;
    const result=retrySyntheticFile(state,current.root,current.path,defaultFilesForRoot(current.root));
    if(result.result==='ready')set(result.state);
    else note(result.result==='changed-file'?'原位置是另一文件；请保留草稿，关闭旧标签后再重新打开。':'文件仍不存在；标签与本地草稿已保留。');
  }
  useEffect(()=>{
    if(state.tree&&((state.pendingDirectoryChanges?.[state.root]?.length||0)+(state.pendingFiles?.[state.root]?.length||0)>0))refreshDirectory();
  },[scope,state.root,state.tree]);
  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      note('已复制路径');
    } catch {
      setContext(value);
      note('复制权限不可用，路径已显示在下方供选择。');
    }
    setMenu(null);
  }
  function download(path, rootId = current?.root || state.root, previewResource) {
    const callback = state.tabs.find(t => t.root === rootId && t.path === path)?.attachment?.onDownload;
    if (callback) { callback(); setMenu(null); return; }
    const item = getFile(rootId,path);
    if(!item)return note('示例目录中没有该文件。');
    const key = fileKey(rootId, path);
    const resource=previewResource||officeResources.current.get(key);
    if(resource?.bytes instanceof Uint8Array){const blob=new Blob([resource.bytes],{type:resource.mime}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=resource.name||path.split('/').pop();a.click();URL.revokeObjectURL(a.href);setMenu(null);note('已下载合成 DOCX 原件，源内容未修改。');return;}
    const blob = new Blob([state.drafts[key]?.text ?? store.saved?.[documentKey(roots, key)] ?? item.text], {
      type: 'text/plain'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = path.split('/').pop() + (isText(item) ? '' : '.preview.txt');
    a.click();
    URL.revokeObjectURL(a.href);
    setMenu(null);
    note(isText(item) ? '已下载原型示例内容' : '已下载交互示例文本，不是实际文档文件');
  }
  function keys(e) {
    if (e.defaultPrevented) return;
    if (e.target.closest('textarea[aria-label="文件编辑器"]') && guardEditorComposition(e)) return;
    if (compose.current || imeComposing(e)) return;
    if (e.target.closest('[role=dialog], [role=menu]')) { if(e.key==='Escape'){e.stopPropagation();setMenu(null);setConfirm(null);setAiState(null);setContentSearch(false);} return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      e.stopPropagation();
      save();
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f' && !rich && isText(file) && !e.target.closest('input,select')) {
      e.preventDefault();
      e.stopPropagation();setFinding(true);
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 't') {
      e.preventDefault();
      set(s => restoreFile(s));
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase()==='g' && finding){e.preventDefault();navigateFind(e.shiftKey?-1:1);}
    if(e.key==='F3'&&finding){e.preventDefault();navigateFind(e.shiftKey?-1:1);}
    if (e.key === 'Escape') {
      setMenu(null);
      setFinding(false);
      setConfirm(null);
    }
  }
  useEffect(() => { window.dispatchEvent(new CustomEvent('m9:terminal-config', { detail: { taskId: task.id, bracketed: terminalBracketed } })); }, [task.id, terminalBracketed]);
  useEffect(() => () => { endFileDrag(); window.dispatchEvent(new CustomEvent('m9:file-context-invalidated', { detail: { taskId: task.id } })); }, [scope, state.root]);
  const searchWasOpen=useRef(false);
  useEffect(()=>{ // 全文搜索关闭后：若焦点已丢到 body（Esc/点遮罩），回到工具栏触发按钮；打开结果时不抢编辑器焦点
    if(searchWasOpen.current&&!contentSearch)requestAnimationFrame(()=>{if(!document.activeElement||document.activeElement===document.body)document.querySelector('[aria-label="在文件中搜索"]')?.focus();});
    searchWasOpen.current=contentSearch;
  },[contentSearch]);
  const lineNavigationRef=useRef(null),lineOwner=useRef('');lineOwner.current=JSON.stringify([scope,state.active,mode]);
  function openLineNavigation(){
    const element=editor.current;if(!element||compose.current)return;
    if(lineNavigationRef.current?.isCurrent()){const input=host.current?.querySelector('.fw-line-navigation input');input?.focus();input?.select();return}
    lineNavigationRef.current?.cancel(false);const owner=lineOwner.current,next=prototypeLineNavigator(element,()=>lineOwner.current===owner&&editor.current===element);lineNavigationRef.current=next;setFinding(false);setLineNavigation(next);
  }
  useLayoutEffect(()=>{if(lineNavigation&&!lineNavigation.isCurrent()){lineNavigation.cancel(false);if(lineNavigationRef.current===lineNavigation)lineNavigationRef.current=null;setLineNavigation(null)}},[scope,state.active,mode,text,lineNavigation,selection]);
  useLayoutEffect(()=>()=>{lineNavigationRef.current?.cancel(false);lineNavigationRef.current=null},[scope]);
  const findResults=useMemo(()=>findFileText(text,finding?find:''),[text,find,finding]),currentFind=Math.min(findIndex,Math.max(0,findResults.matches.length-1));
  function locateFind(index){
    const hit=findResults.matches[index];if(!hit)return;setFindIndex(index);
    const line=text.slice(0,hit.from).split('\n').length;
    if(editor.current){editor.current.setSelectionRange(text.slice(0,hit.from).replace(/\r\n?/g,'\n').length,text.slice(0,hit.to).replace(/\r\n?/g,'\n').length);editor.current.scrollTop=Math.max(0,(line-3)*21);}
    else host.current?.querySelector('[data-md-line="'+line+'"]')?.scrollIntoView({block:'center'});
  }
  useLayoutEffect(()=>{if(finding&&find)locateFind(0);},[finding,find,state.active]);
  function navigateFind(delta){
    if(!findResults.matches.length)return;
    locateFind((currentFind+delta+findResults.matches.length)%findResults.matches.length);
  }
  return <aside ref={host} className={'file-workspace ' + (full ? 'fw-full' : '') + (dock === 'bottom' ? ' fw-bottom' : '')} aria-label="M9 文件工作区原型" onKeyDown={keys} onKeyUpCapture={captureReading} onPointerDownCapture={e=>{captureReading();pointerRef.current={x:e.clientX,y:e.clientY,time:performance.now()};}}>
  <div className="fw-tabs" role="tablist" aria-label="文件标签" onKeyDown={e=>{if(imeComposing(e)||!e.target.matches('[role=tab]'))return;const tabs=[...e.currentTarget.querySelectorAll('[role=tab]')],i=tabs.indexOf(e.target);if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next]?.click();tabs[next]?.focus();}}}>{state.tabs.map(t => {
        const key = fileKey(t.root, t.path);
        return <div key={key} className={'fw-tab ' + (key === state.active && !webActiveId ? 'selected ' : '') + (t.preview ? 'preview' : '')} draggable onDragStart={e => { dragged.current = key; e.dataTransfer.setData('application/x-willyou-prototype-tab', key); dragFile(e, t.root, t.path, true); }} onDragEnd={finishFileDrag} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); reorder(key); }} onContextMenu={e => {
          e.preventDefault();
          setMenu({
            type: 'tab',
            key
          });
        }}><button role="tab" tabIndex={key===state.active&&!webActiveId?0:-1} aria-selected={key === state.active && !webActiveId} onClick={() => {
            onWebSelect?.(null);
            locateFile(t.root, t.path);
            set(s => ({
              ...s,
              active: key
            }));
            setRich(null);
          }} onDoubleClick={() => open(t.path, true, t.root)} title={roots.find(r => r.id === t.root)?.path + '/' + t.path}><Icon file={t.path} /><span>{key===state.active&&rich?'格式演示 · '+rich.toUpperCase():t.path.split('/').pop()}</span>{state.drafts[key] && <span className="fw-dirty" aria-label="未保存" />}</button><button className="fw-tab-close" aria-label={'关闭 ' + t.path} onMouseDown={event => { if (event.button === 0) event.preventDefault(); }} onClick={event => close(key, event.currentTarget)}><X size={14} /></button></div>;
      })}{webTabs.map(w => <div key={w.id} className={'fw-tab fw-web-tab ' + (w.id === webActiveId ? 'selected' : '')}><button role="tab" tabIndex={w.id === webActiveId ? 0 : -1} aria-selected={w.id === webActiveId} title={w.url} onClick={() => onWebSelect?.(w.id)}><WebGlobe size={14} strokeWidth={1.7} /><span>{w.title}</span>{w.marked && <span className={'bw-tab-agent' + (w.paused ? ' paused' : '')} aria-label={w.paused ? 'Agent 已暂停' : 'Agent 正在操作'} />}</button><button className="fw-tab-close" aria-label={'关闭网页 ' + w.title} onMouseDown={event => { if (event.button === 0) event.preventDefault(); }} onClick={() => onWebClose?.(w.id)}><X size={14} /></button></div>)}<Button icon={Plus} label="查找并打开文件" onClick={() => {
        onWebSelect?.(null);
        set(s => ({
          ...s,
          tree: true
        }));
        requestAnimationFrame(()=>filter.current?.focus());
      }} />{onWebNew && <Button icon={WebGlobe} label="新建网页标签" onClick={onWebNew} />}<span className="fw-push" /><Button icon={full ? Minimize2 : Maximize2} label={full ? '退出文件聚焦' : '聚焦文件工作区'} onClick={() => setFull(!full)} /><Button icon={PanelRight} label="隐藏文件工作区" onClick={onClose} /></div>
  {webActiveId && <div className="fw-web-layer" onKeyDown={event => event.stopPropagation()}>{webView}</div>}
  <div className="fw-toolbar"><div className="fw-breadcrumb" onCopy={event => {
    const text = breadcrumbSelectionText(event.currentTarget, window.getSelection(), rich ? undefined : fileAbsolutePath(activeRoot, current?.path || '') || displayRoot.path);
    if (text === null) return;
    event.preventDefault(); event.clipboardData.setData('text/plain', text);
  }}>{(rich?['会话产物查看器演示',rich.toUpperCase()]:[displayRoot.label, ...(displayPath?.split('/') || [])]).map((part, i, arr) => <span key={i}><button title={fileAbsolutePath({path:displayRoot.path},arr.slice(1,i+1).join('/')) || displayRoot.path} className={i === arr.length - 1 ? 'current' : ''} disabled={!!rich} onContextMenu={event => {
            if (rich) return;
            event.preventDefault();
            setMenu({ type: 'file', origin: 'breadcrumb', folder: !current || i < arr.length - 1, path: arr.slice(1, i + 1).join('/'), root: displayRoot.id, point: { x: event.clientX, y: event.clientY } });
          }} onClick={event => setMenu(menu?.type === 'crumb' ? null : {
            type: 'crumb',
            anchor: event.currentTarget,
            prefix: i===arr.length-1 && current ? displayPath.split('/').slice(0,-1).join('/') : arr.slice(1, i + 1).join('/'),
            root: displayRoot.id
          })}>{part}</button>{i < arr.length - 1 && <ChevronRight data-breadcrumb-separator="true" size={13} />}</span>)}</div><div className="fw-tools">{roots.length>0 && root.hostId==='local' && root.path && <Button preserveEditorFocus icon={FileSearch} label="在文件中搜索" active={searchMode} onClick={() => setContentSearch(true)} />}{!rich && file && ['markdown', 'svg', 'html', 'tex'].includes(file.kind) && <Button preserveEditorFocus icon={Code2} label={mode === 'source' ? file.kind === 'svg' ? '查看图像' : file.kind === 'tex' ? '编译并查看 PDF' : '查看文档' : '查看源码'} active={mode === 'source'} onClick={switchMode} />}{!rich && /\.(?:csv|tsv)$/i.test(current?.path || '') && <Button preserveEditorFocus icon={Code2} label={mode === 'source' ? '查看表格' : '查看源码'} active={mode === 'source'} onClick={switchMode} />}<Button icon={MoreHorizontal} label="文件查看选项" onClick={() => setMenu({
          type: 'viewer'
        })} /><Button icon={FolderOpen} label="切换文件目录" active={state.tree} onClick={() => set(s => ({
          ...s,
          tree: !s.tree
        }))} /><div className="fw-open-button"><button aria-label={applications.preferred ? `使用 ${applications.preferred.name} 打开（原型模拟）` : "打开文件（原型模拟）"} title={applications.preferredUnavailable ? "首选应用不可用，请选择打开方式" : "打开文件（原型模拟）"} disabled={!current || appsState!=='ready' || !applications.preferred} onClick={()=>openApplication(applications.preferred?.id, false, current?.root, current?.path)}><ExternalLink size={14} /><span>打开</span></button><button aria-label="打开方式" onClick={() => setMenu(menu?.type === 'external' ? null : {
          type: 'external'
        })}><ChevronDown size={12} /></button></div></div></div>
  {modePending && <div className="fw-save-strip" role="status">保存中（合成）：{modePending.key}<button data-testid="complete-mode-save" onClick={finishModeSave}>完成保存（合成）</button></div>}
  <div className="fw-body"><section ref={content} className="fw-content" aria-label="文件内容" onScrollCapture={event => {
    const node = scrollNode(); if (event.target === node && node?.isConnected) captureReading();
  }}>
   {current?.attachment && <div className="fw-save-strip" role="status">本机附件为只读，仅在当前会话保留；关闭或重启后请从原来源重新打开。</div>}
   {effective === 'root-missing' && <div className="fw-save-strip" role="alert"><span title={root.path}>{root.label}：工作目录不可用，请检查目录或权限后重试。</span><button onClick={() => setScenario('ready')}>重试目录</button></div>}
   {lineNavigation && <GoToLinePanel navigator={lineNavigation} onClose={()=>{if(lineNavigationRef.current===lineNavigation)lineNavigationRef.current=null;setLineNavigation(null)}}/>}
   {finding && !rich && isText(file) && <div className="fw-find"><Search size={15}/><input autoFocus aria-label="查找当前文件" value={find} onChange={e=>{setFind(e.target.value);setFindIndex(0);}} onKeyDown={e=>{if(imeComposing(e))return;if(e.key==='Enter'){e.preventDefault();navigateFind(e.shiftKey?-1:1);}if(e.key==='Escape'){e.preventDefault();e.stopPropagation();setFinding(false);editor.current?.focus();}}} placeholder="查找当前文件"/><button aria-label="上一个匹配" disabled={!findResults.matches.length} onClick={()=>navigateFind(-1)}><ArrowLeft size={14}/></button><button aria-label="下一个匹配" disabled={!findResults.matches.length} onClick={()=>navigateFind(1)}><ArrowRight size={14}/></button><span>{findResults.matches.length?currentFind+1:0} / {findResults.matches.length}{findResults.limited?'+':''}</span><Button icon={X} label="关闭查找" onClick={()=>{setFinding(false);editor.current?.focus();}}/></div>}

   {workspaceConflict?.scope === scope && <div role="alert" className="fw-save-strip"><AlertCircle size={15}/><span>另一窗口更新了标签；当前标签、选择与草稿已保留。保存当前窗口标签会采用此窗口的布局。</span><button onClick={() => { setWorkspaceConflict(null); note('已采用当前窗口的标签布局（原型模拟）；未保存任何文件内容。'); }}>保存当前窗口标签</button><button disabled={Object.keys(state.drafts).length > 0} onClick={() => { set(s => { const tabs = [...workspaceConflict.tabs, ...s.tabs.filter(t => t.preview && !workspaceConflict.tabs.some(remote => fileKey(remote.root,remote.path) === fileKey(t.root,t.path)))]; return { ...s, tabs, active: tabs.some(t => fileKey(t.root,t.path) === s.active) ? s.active : tabs[0] ? fileKey(tabs[0].root,tabs[0].path) : null }; }); setWorkspaceConflict(null); note('已读取另一窗口的标签顺序（原型模拟）；文件内容未改变。'); }}>读取最新标签</button></div>}
   {draft && effective === 'missing' && <div className="fw-save-strip" role="alert">文件已删除或原位置已换成另一文件；本地草稿已保留，不能覆盖同名新文件。<button onClick={retryCurrentFile}>重试读取原文件</button></div>}
   {draft && <div className="fw-save-strip" role={scenario === 'input-interrupted' ? 'alert' : undefined}><span>{scenario === 'input-interrupted' ? '输入已中断，请返回编辑器继续输入或撤销后再保存' : scenario === 'save-error' ? '保存失败，修改已保留' : scenario === 'conflict' ? '文件已被外部修改' : '未保存的修改'}</span><button disabled={scenario === 'input-interrupted'} onClick={() => save()}>保存</button>{scenario === 'conflict' && <button onClick={() => setConfirm({
            type: 'conflict',
            key: state.active
          })}>查看差异</button>}</div>}
   {file && !rich && isText(file) && !(file.kind === 'large' && current?.navigationView === 'review') && <FileEditorStatus canUndo={Boolean(historyRef.current[identity]?.undo.length)} canRedo={Boolean(historyRef.current[identity]?.redo.length)} saving={scenario === 'saving'} error={scenario === 'save-error' ? '保存失败，修改已保留' : ''} onUndo={() => undo()} onRedo={() => undo(true)} />}
   {file && !rich && isText(file) && !(file.kind === 'large' && current?.navigationView === 'review') && <div className="fw-editor-tools"><GoToLineButton disabled={Boolean(((['markdown','svg','html','tex'].includes(file.kind)||/\.(?:csv|tsv)$/i.test(current.path))&&mode!=='source')||['loading','missing','unreadable','too-large','unsupported','parse-error','root-missing'].includes(effective))} onOpen={openLineNavigation}/><Button icon={WrapText} label="自动换行" active={wrap} onClick={() => setWrap(!wrap)} /><Button icon={Copy} label="复制文件内容" onClick={() => copy(text)} /><span className="fw-push" /><button onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
          }} disabled={!selection || file.kind === 'large'}>编辑所选文本</button></div>}

   <FileLanguageTools command={symbol} onCommand={setSymbol} path={current?.path} onOpen={path=>open(path,true)} />
   {extension ? <FileMcpViewer key={current?.path} name={current?.path?.split('/').pop()} text={text} onEdit={edit} onSave={override=>save(state.active,Boolean(override))} onScenario={setScenario} initialSettings={extension==='settings'} onDefault={()=>setExtension(false)} /> : !file ? <div className="fw-empty"><File size={30} /><p>选择文件以开始浏览</p><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}>重新打开关闭的文件</button></div> : effective === 'root-missing' ? <div className="fw-empty"><FolderOpen size={28}/><p>没有可用的本机目录</p></div> : effective === 'loading' ? <div className="fw-empty" aria-busy="true"><span className="fw-loading" />正在读取文件…<button onClick={() => setScenario('ready')}>完成加载（模拟）</button></div> : ['missing', 'unreadable', 'too-large', 'unsupported', 'parse-error', 'root-missing'].includes(effective) && !(effective==='missing'&&draft) ? <div className="fw-empty" role="alert"><AlertCircle size={28} /><h2>{{
              missing: '文件不存在',
              unreadable: '无法读取文件',
              'too-large': '文件过大',
              unsupported: '不支持预览此文件',
              'parse-error': '文件解析失败',
              'root-missing': '工作目录不可用'
            }[effective]}</h2><p>{{
              missing: '文件可能已移动或删除。现有草稿会保留。',
              unreadable: '检查文件权限后重试。',
              'too-large': file.kind === 'tex' ? '[TOO_LARGE] TeX 编译输出超过 40 MiB 上限；源码已保留，请减小资源或拆分文档后重试。' : '此示例超过文本预览限制，请使用外部应用。',
              unsupported: '可以通过外部应用打开此文件。',
              'parse-error': '文件已损坏或不完整，源码已保留；修复文件后重试。',
              'root-missing': '重新连接或更新项目目录后重试。'
            }[effective]}</p><button className="fw-pill" onClick={effective==='missing'?retryCurrentFile:()=>setScenario('ready')}><RotateCcw size={15} />重试</button><button onClick={() => setMenu({
            type: 'external'
          })}>使用外部应用打开</button></div> : rich ? <FileArtifactPreview path={current.path} onInsertContext={sendToTerminal} onAddComments={addPdfRefs} key={rich + state.active} kind={rich} readOnly onDownload={resource => download(current.path,current.root,resource)} onResourceRead={resource=>registerOfficeResource(current.root,current.path,resource)} /> : /\.(?:csv|tsv)$/i.test(current.path) && mode !== 'source' ? <FileArtifactPreview path={current.path} kind={current.path.split('.').at(-1).toLowerCase()} initialValue={text} readOnly /> : file.kind === 'svg' && mode !== 'source' ? <div className="fw-image fw-ordinary-image fw-svg-image"><img draggable onDragStart={e => dragFile(e, current.root, current.path)} onDragEnd={finishFileDrag} src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(text)} alt="SVG 文件预览" /></div> : file.kind === 'html' && mode !== 'source' ? <FileHtmlPreview text={text} /> : file.kind === 'large' && current?.navigationView === 'review' ? <FileReviewTextExample text={text} /> : scenario === 'conflict' && isText(file) ? <FileConflictSource key={identity} ref={editor} filename={current.path} text={text} diskText={state.fileStates?.[state.active]?.diskText} onEdit={edit} onSelect={(start,end)=>setSelection(captureSelection({scope,identity,revision,text,start,end}))} onComposition={value=>{compose.current=value;setComposing(value);}} /> : file.kind === 'markdown' && mode !== 'source' ? <FileMarkdown resolveImageSource={path=>{const f=path&&getFile(current.root,path);return f?.kind==='image'?f.text:f?.kind==='svg'?'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(f.text):undefined;}} imageMenuScope={imageMenuScope} imageContext={imageContext} imageGalleryRouting={imageGalleryRouting} key={identity + ':' + (state.reloads?.[state.active] || 0)} text={text} readingSelection={reading?.selection} retainView onReadingSelection={rememberReadingSelection} findQuery={finding?find:''} path={current.path} overlay={imageOverlay} readOnly={!!current?.attachment || scenario === 'conflict'} onEdit={edit} onSelect={(start,end) => setSelection(captureSelection({scope, identity, revision, text, start, end}))} onOpenFile={async(path,{readOnlyImage=false,...location}={}) => {
            const target=readOnlyImage&&resolveImageOpen?await resolveImageOpen(path):path;
            if(!target)return null;
            const resolved=getFile(current.root,target)?target:target.startsWith('assets/')?'resources/app-icon.png':null;
            if(!resolved){note('示例目录中没有该目标：'+target);return null;}
            if(readOnlyImage){
              const image=getFile(current.root,resolved);
              if(!['image','svg'].includes(image?.kind))throw new Error('此引用不是图像，不能作为图片只读标签打开');
              const rootId=current.root,attachment={key:'prototype-markdown-image:'+rootId+':'+resolved,mimeType:image.kind==='svg'?'image/svg+xml':undefined};
              set(s=>{const opened=openFile(s,rootId,resolved,true);return{...opened,tabs:opened.tabs.map(t=>t.root===rootId&&t.path===resolved?{...t,attachment}:t),mode:{...opened.mode,[fileKey(rootId,resolved)]:'render'}};});
            }else open(resolved,true,current.root,location);
            return true;
          }} onImageReference={prepareImageInput} onImageAction={note} onComposition={value => { compose.current=value; setComposing(value); }} /> : (['code', 'html', 'svg', 'large', 'markdown'].includes(file.kind) || file.kind === 'tex' && mode === 'source') ? <div className="fw-editor"><div className="fw-line-numbers" aria-hidden="true">{text.split('\n').map((_, i) => <div key={i}>{i + 1}</div>)}</div>{blame && <FilePrototypeBlame text={text} identity={identity} repositoryWebUrl={repositoryWebUrl} commitId={repositoryCommitId} onOpenLink={onRepositoryLink ?? (href=>note("外部链接（原型演示）："+href))} />}<FileCodeTextarea key={identity} findMatches={finding?findResults.matches:[]} findCurrent={currentFind} filename={current.path} ref={editor} aria-label="文件编辑器" spellCheck={false} value={text} readOnly={!!current?.attachment || current?.navigationView === 'review' || file.kind === 'large'} onChange={e => edit(e.target.value)} style={{
            whiteSpace: wrap ? 'pre-wrap' : 'pre'
        }} onContextMenu={e => {
            e.preventDefault();
            setMenu({
              type: 'code'
            });
          }} onSelect={e => { const area=e.currentTarget;rememberReadingSelection(area.selectionDirection==='backward'?area.selectionEnd:area.selectionStart,area.selectionDirection==='backward'?area.selectionStart:area.selectionEnd);setSelection(captureSelection({
            scope: scope,
            identity,
            revision,
            text: area.value,
            start: area.selectionStart,
            end: area.selectionEnd
          })); }} onCompositionStart={() => {
            compose.current = true;
            setComposing(true);
          }} onCompositionEnd={() => {
            compose.current = false;
            setComposing(false);
          }} />{file.kind === 'large' && <div className="fw-readonly">10–20 MiB 文本：只读预览示例</div>}</div> : file.kind === 'image' ? <div className="fw-image fw-ordinary-image"><img draggable onDragStart={e => dragFile(e, current.root, current.path)} onDragEnd={finishFileDrag} src={file.text} alt={file.path} /></div> : ['audio', 'video'].includes(file.kind) ? <Media key={identity} kind={file.kind} name={file.path.split('/').pop()} sourceUrl={file.sourceUrl} onCopy={url => copy(url ?? activeRoot.path + '/' + current.path)} onDownload={resource => download(current.path,current.root,resource)} onResourceRead={resource=>registerOfficeResource(current.root,current.path,resource)} /> : <FileArtifactPreview path={current.path} onInsertContext={sendToTerminal} onAddComments={addPdfRefs} key={scope + ':' + identity + ':' + (state.reloads?.[state.active] || 0)} kind={file.kind === 'pdf' && current?.navigationView ? 'pdf-review' : file.kind} hostOptions={file.kind === 'pdf' ? { pdfSource: file.pdfSource } : ['xlsx','xlsm'].includes(file.kind) ? {sourceKind:'local',isEditing:true,manualEditUiEnabled:true,artifactSearchEnabled:false} : undefined} initialPage={current?.pdf?.page || 1} initialZoom={current?.pdf?.zoom} onReadingChange={file.kind === 'pdf' ? savePdfReading : undefined} readOnly={!!current?.attachment || scenario==='conflict'} initialValue={text} onDraft={edit} onDownload={resource => download(current.path,current.root,resource)} onResourceRead={resource=>registerOfficeResource(current.root,current.path,resource)} />}
  </section>{state.tree && <><div className="fw-tree-resizer" role="separator" tabIndex={0} aria-label="调整目录宽度" aria-orientation="vertical" aria-valuenow={Math.round(treeWidth)} aria-valuemin={Math.round(treeMinimum)} aria-valuemax={Math.round(treeMaximum)} onPointerDown={resize} onKeyDown={e => {
          if (['ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault();
            set(s => ({
              ...s,
              width: Math.max(treeMinimum, Math.min(treeMaximum, treeWidth + (e.key === 'ArrowLeft' ? 10 : -10)))
            }));
          }
        }} /><aside className="fw-tree" style={{
          width: treeWidth, minWidth: treeMinimum
        }} aria-label="目录树"><label className="fw-filter"><Search size={14} /><input ref={filter} placeholder={searchMode ? '搜索文件内容…' : '筛选文件…'} aria-label="筛选文件" value={query} onChange={e => {setQuery(e.target.value);anchor.current=null;setSearchCollapsed([]);}} onKeyDown={e => {
              if(imeComposing(e))return;
              if (e.key === 'Escape') {
                e.stopPropagation();
                setQuery('');
              }
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                treeApiRef.current?.focusFirst();
              }
            }} />{query && <button aria-label="清除筛选" onClick={() => setQuery('')}><X size={13} /></button>}</label>{changedOnly && <label className="fw-generated"><input type="checkbox" checked={hideGenerated} onChange={e => setHideGenerated(e.target.checked)} />筛除生成文件 {hideGenerated ? "1" : ""}</label>}{roots.length>1&&<div className="fw-root"><button aria-label="选择工作目录" aria-haspopup="menu" onClick={()=>setMenu({type:'roots'})}><Folder size={14}/><span title={root.path}>{root.label}</span><ChevronDown size={12}/></button></div>}{!roots.length&&<p className="fw-no-results">当前任务没有可用工作目录。请在项目中配置目录。</p>}{roots.length>0&&effective!=='root-missing'&&<FileWorkspaceTree key={treeSourceKey} files={activeFiles} scope={treeSourceKey} rootPath={root.path} query={query} searchScenario={searchScenario} expanded={state.expanded} selected={selectedRows} focused={focusedPath} activePath={activeAbsolutePath ? rootRelativePath(root, activeAbsolutePath) : null} revealRequest={treeReveal?.root===state.root?treeReveal:null} onRevealComplete={id=>setTreeReveal(old=>old?.id===id?null:old)} scrollRef={treeRef} apiRef={treeApiRef} initialScrollTop={query.trim()?(readRootView(state).searchScrollTop||0):readRootView(state).scrollTop} normalScrollTop={readRootView(state).scrollTop} onScrollPosition={scrollTop=>set(s=>updateRootView(s,{scrollTop}))} onSearchScrollPosition={searchScrollTop=>set(s=>updateRootView(s,{searchScrollTop}))} onExpandedChange={expanded=>set(s=>({...s,expanded}))} onSelectedChange={setSelectedRows} onFocusedChange={setFocusedPath} onOpen={(path,pin)=>open(path,pin,state.root,{reveal:false})} onMenu={(path,point)=>setMenu({type:'file',path,root:state.root,point})} onDrag={(event,path)=>dragFile(event,state.root,path)} onDragEnd={finishFileDrag} changedOnly={changedOnly} hideGenerated={hideGenerated} large={treeDataset==='large'} renderIcon={path=><Icon file={path}/>} />}</aside></>}</div>
  {refs.length > 0 && (() => { const built = refTexts(refs); const preview = built.ok ? pasteData(built.text, { bracketedPaste: terminalBracketed }) : null; return <section className="fw-refs" aria-label="待放入终端的引用"><header><strong>终端引用（{refs.length}）</strong><span className="fw-push" />
    <label><input type="checkbox" checked={refOptions.includeText} onChange={e => setRefOptions(o => ({ ...o, includeText: e.target.checked }))} />包含所选文字（≤{REF_LIMITS.maxSelectedChars} 字符）</label>
    <label>格式<select aria-label="引用格式" value={refOptions.style} onChange={e => setRefOptions(o => ({ ...o, style: e.target.value }))}><option value="plain">通用：路径:L起-止</option><option value="at">@路径（需 CLI 支持，未验证）</option></select></label></header>
    <ul>{refs.map(item => { const st = referenceStaleness(item.ref, refCurrent(item)); const f = formatReference(item.ref, { style: refOptions.style }); return <li key={item.id}><File size={13} /><span title={item.ref.relativePath}>{f.ok ? f.text.split('\n')[0] : item.ref.relativePath}</span>{st === 'stale' && <em title="文件或所选内容在加入引用后已变化">位置可能已变</em>}{st === 'missing' && <em role="alert">文件不存在</em>}<button aria-label={'移除引用 ' + item.ref.relativePath} onClick={() => setRefs(list => list.filter(x => x.id !== item.id))}><X size={12} /></button></li>; })}</ul>
    {!built.ok && <p role="alert">{insertError(built.error, built.length)}</p>}
    {refPreview && preview && <div className="fw-refs-preview"><small>将放入终端的文本（{preview.mode === 'bracketed' ? '括号粘贴，换行保留' : '普通输入，换行折叠为空格'}）{preview.sanitized.changed ? ' · 已移除 ' + Object.values(preview.sanitized.removed).reduce((a, b) => a + b, 0) + ' 个不安全字符' : ''}</small><pre aria-label="将放入终端的文本">{preview.sanitized.text}</pre></div>}
    <div className="fw-refs-actions"><button onClick={() => setRefPreview(v => !v)}>{refPreview ? '隐藏预览' : '预览'}</button><button onClick={() => setRefs([])}>清空</button><button disabled={!built.ok || refBusy || !taskRunning} title={taskRunning ? '' : '任务未运行'} onClick={insertRefs}>放入终端输入（不发送）</button>{!taskRunning && <small role="status">任务未运行，无法放入终端输入。</small>}</div></section>; })()}
  <footer className="fw-footer"><button onClick={() => setDemo(!demo)}><Settings2 size={13} />M9 交互样例<ChevronDown size={12} /></button><span role="status">{status || '示例数据 · 未连接真实文件'}</span><span className="fw-push" />{current && <span>{current.preview ? '预览' : '已固定'} · UTF-8</span>}<Button icon={dark ? Sun : Moon} label="切换原型主题" onClick={onTheme} /></footer>
  {demo && <div className="fw-demo">
    <span role="group" aria-label="错误恢复合成场景">{[['missing','已删除'],['unreadable','无读取权限'],['too-large','过大'],['unsupported','未知二进制'],['parse-error','解析失败'],['conflict','外部修改冲突'],['root-missing','根不可用']].map(([value,label])=><button key={value} data-testid={'error-scenario-'+value} onClick={()=>demoScenario(value)}>{label}（合成）</button>)}</span>
    <label><input type="checkbox" aria-label="合成目录监听" checked={directoryWatch} onChange={e=>{setDirectoryWatch(e.target.checked);if(e.target.checked)refreshDirectory();}}/>示例监听（合成）</label>
    <button disabled={!roots.length} onClick={()=>simulateDirectoryChanges(['a.txt','b.txt','dirty.txt'].map((name,i)=>({type:'create',file:{path:'external-sync/'+name,kind:'code',text:['Original A','Original B','Original dirty'][i]}})))}>载入目录同步样例</button>
    <button disabled={!filesForRoot().some(f=>f.path==='external-sync/b.txt')} onClick={()=>simulateDirectoryChanges([{type:'create',file:{path:'external-sync/new.txt',kind:'code',text:'Independent external file'}},{type:'delete',path:'external-sync/a.txt'},{type:'rename',from:'external-sync/b.txt',to:'external-sync/c.txt'}])}>模拟外部增删改名</button>
    <button data-testid="icon-samples-load" disabled={!roots.length} onClick={()=>simulateDirectoryChanges([{type:'delete',path:'icon-samples-中文/rename.json'},...[
      {path:'icon-samples-中文/Dockerfile',kind:'code',text:'# G205 Latin 中文 synthetic only\nFROM scratch\n'},
      {path:'icon-samples-中文/config.env.local',kind:'code',text:'G205 Latin 中文 compound suffix sample\n'},
      {path:'icon-samples-中文/unknown.g205unknown',kind:'code',text:'G205 Latin 中文 default sample\n'},
      {path:'icon-samples-中文/rename.txt',kind:'code',text:'{"G205":"Latin 中文 synthetic bytes"}\n'},
    ].map(file=>({type:'create',file}))])}>载入／重置图标规则样例（合成）</button>
    <button data-testid="icon-samples-rename" disabled={!filesForRoot().some(f=>f.path==='icon-samples-中文/rename.txt')} onClick={()=>simulateDirectoryChanges([{type:'rename',from:'icon-samples-中文/rename.txt',to:'icon-samples-中文/rename.json'}])}>模拟换后缀 txt→json（合成）</button>
    <button disabled={!current||!!current.attachment} onClick={()=>simulateDirectoryChanges([{type:'delete',path:current.path}],current.root)}>模拟删除当前文件</button>
    <button disabled={!current||!state.retiredFiles?.[state.active]} onClick={()=>simulateDirectoryChanges([{type:'create',file:{...state.retiredFiles[state.active],kind:state.retiredFiles[state.active].kind==='loading'?'code':state.retiredFiles[state.active].kind}}],current.root)}>模拟同名新文件</button>
    <button disabled={!current||!state.retiredFiles?.[state.active]} onClick={()=>simulateDirectoryChanges([{type:'restore',file:{...state.retiredFiles[state.active],kind:state.retiredFiles[state.active].kind==='loading'?'code':state.retiredFiles[state.active].kind}}],current.root)}>模拟恢复原文件</button>
    <button onClick={() => {
    if (!roots.length) return;
    const example = attachmentExamples.find(item => item.id === attachmentExample) || attachmentExamples[0], {path,kind,text,mimeType} = example, rootId = state.root, attachment = { key: 'prototype-local-attachment:' + example.id, mimeType, onDownload: () => setAttachmentCopy({path,text,mimeType,name:path.split('/').pop()}), onClose: () => note('已通知附件来源关闭（原型模拟）；此标签不会恢复。') };
    set(s => { const withFile = { ...s, syntheticFiles: { ...s.syntheticFiles, [rootId]: [...(s.syntheticFiles?.[rootId] || []).filter(f => f.path !== path), { path, kind, text }] } }; const opened = openFile(withFile, rootId, path, true); return { ...opened, tabs: opened.tabs.map(t => t.root === rootId && t.path === path ? { ...t, attachment } : t), mode: {...opened.mode, [fileKey(rootId,path)]: 'render'} }; });
  }}>模拟只读附件回调</button><label>附件样例<select aria-label="本机附件来源场景" value={attachmentExample} onChange={e=>setAttachmentExample(e.target.value)}>{attachmentExamples.map(item=><option key={item.id} value={item.id}>{item.label}</option>)}</select></label><button onClick={() => setWorkspaceConflict({ scope, tabs: state.tabs.filter(t => !t.preview).reverse() })}>模拟标签持久化冲突</button><label>目录样例<select aria-label="工作目录场景" value={rootScenario} onChange={e=>setRootScenario(e.target.value)}><option value="multiple">多根</option><option value="single">单根</option><option value="nested">嵌套根</option><option value="none">无根</option></select></label><label>场景<select aria-label="文件状态场景" value={scenario} onChange={e => demoScenario(e.target.value)}>{[['ready', '正常'], ['saving', '保存中（合成）'], ['loading', '读取中'], ['conflict', '外部修改冲突'], ['save-error', '保存失败'], ['input-interrupted', '输入中断（模拟）'], ['missing', '已删除'], ['unreadable', '无读取权限'], ['too-large', '过大'], ['unsupported', '未知二进制'], ['parse-error', '解析失败（合成）'], ['root-missing', '根不可用']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label><label><input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)} />自动保存（3秒）</label><span role="group" aria-label="模式切换合成场景">{[['ready','正常'],['saving','保存中'],['save-error','保存失败']].map(([value,label])=><button key={value} data-testid={"mode-scenario-"+value} onClick={()=>demoScenario(value)}>{label}（合成）</button>)}</span><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}><RotateCcw size={14} />恢复关闭标签</button><button disabled={!Object.values(store).some(s=>Array.isArray(s?.tabs)&&s.tabs.some(tab=>fileScenario(s,fileKey(tab.root,tab.path))==='loading'))} onMouseDown={event=>{if(event.button===0)event.preventDefault();}} onClick={()=>setStore(previous=>completeSyntheticWorkspaceRestores(previous))}>完成后台恢复（合成）</button><button onClick={() => setMenu({
        type: 'formats'
      })}>全部格式与入口</button><label>树数据<select aria-label="文件树数据场景" value={treeDataset} onChange={e=>{setTreeDataset(e.target.value);setQuery('');}}><option value="normal">普通样本</option><option value="large">6,000文件 / 懒加载</option><option value="empty">空目录</option></select></label><label>搜索服务<select aria-label="搜索服务场景" value={searchScenario} onChange={e=>setSearchScenario(e.target.value)}><option value="ready">正常异步</option><option value="slow">慢响应</option><option value="error">失败</option><option value="permission">权限不足（合成）</option><option value="timeout">超时（合成）</option></select></label><label>面包屑目录（合成）<select aria-label="面包屑目录场景" value={breadcrumbScenario} onChange={e=>setBreadcrumbScenario(e.target.value)}><option value="ready">正常列表</option><option value="slow">慢响应（合成）</option><option value="permission">权限失败后恢复（合成）</option></select></label><label>外开能力<select aria-label="外部应用能力场景" value={appsScenario} onChange={e=>{setAppsScenario(e.target.value);setAppsAttempt(0);}}><option value="ready">可用</option><option value="loading">加载中</option><option value="error">读取失败</option><option value="unavailable">无能力</option></select></label><button onClick={() => { setStore(previous => ({ ...previous, fileOpener: MISSING_PROTOTYPE_APPLICATION })); setAppsScenario('ready'); setAppsState('ready'); }}>模拟首选应用不可用</button><label><input type="checkbox" checked={changedOnly} onChange={e => {
          setChangedOnly(e.target.checked);
          setQuery('');
        }} />变化文件上下文</label><label><input type="checkbox" checked={imageOverlay} onChange={e => setImageOverlay(e.target.checked)} />图片新叠层（模拟开关）</label><label><input type="checkbox" checked={terminalBracketed} onChange={e => setTerminalBracketed(e.target.checked)} />演示终端启用括号粘贴（多行引用）</label><button disabled={!current || !isText(file)} onClick={simulateExternalChange}>模拟外部修改当前文件</button><button disabled={!roots.length} onClick={simulateDirectoryAddition}>模拟外部新增文件</button><button disabled={!roots.length} onClick={refreshDirectory}>刷新示例目录</button><button onClick={() => note('原型状态已在本浏览器保存；刷新可检查恢复。')}>检查恢复</button></div>}
  {context && <div className="fw-context"><File size={14} /><span>{context}</span><Button icon={X} label="移除文件引用" onClick={() => setContext('')} /></div>}
  {contentSearch && <ContentSearch key={treeSourceKey} files={activeFiles} priorityFolders={searchPriorityFolders(rootRelativePath(root,activeAbsolutePath))} searchScenario={searchScenario} scope={JSON.stringify([root.hostId, [root.path]])} onClose={() => setContentSearch(false)} onOpen={(path, line, number, column) => {
      open(path, true);
      setExtension(false);
      set(s => ({
        ...s,
        mode: {
          ...s.mode,
          [fileKey(state.root, path)]: 'source'
        }
      }));
      setFinding(true);
      setFind(line);
      setReveal({
        number,
        column,
        query: line
      });
      setContentSearch(false);
    }} />}
  {menu && <><div className="fw-dismiss" onClick={() => setMenu(null)} /><div ref={menuRef} className={'fw-menu fw-positioned-menu ' + (menu.type === 'formats' ? 'fw-format-menu' : menu.type === 'crumb' ? 'fw-breadcrumb-menu' : '')} role="menu" aria-label="文件操作菜单" onPointerDownCapture={e=>{if(e.button===0&&e.target instanceof Element&&e.target.closest('button:disabled'))e.preventDefault();}} onKeyDown={e=>{e.stopPropagation();const items=[...e.currentTarget.querySelectorAll('button:not(:disabled)')],i=items.indexOf(document.activeElement);if(e.key==='Escape'||e.key==='Tab'){setMenu(null);if(e.key==='Escape')e.preventDefault();}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();items[e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus();}}}>
   {menu.type==='roots'&&<><strong>选择工作目录</strong>{roots.map(r=><button key={r.id} role="menuitemradio" aria-checked={state.root===r.id} title={r.path} onClick={()=>{changeRoot(r.id);setMenu(null);}}><Folder size={15}/><span>{r.label}</span><small>{r.path}</small>{state.root===r.id&&<Check size={14}/>}</button>)}</>}
   {menu.type === 'viewer' && <><strong>文件查看选项</strong><button onClick={() => { setRecoveryOpen(true); setMenu(null); }}>保存恢复材料…</button>{textMenu && <><button onClick={() => {
            setWrap(!wrap);
            setMenu(null);
          }}>自动换行 {wrap ? '已开' : '已关'}</button><button onClick={() => {
            setBlame(!blame);
            setMenu(null);
          }}>只读行归属（示例）</button></>}<button onClick={() => {
            setExtension(!extension);
            setMenu(null);
          }}>自动选择查看器（原型）</button><button onClick={()=>{setExtension(false);setMenu(null)}}>内置文件查看器</button><button onClick={()=>{setExtension('settings');setMenu(null)}}>管理扩展文件查看器…</button><button onClick={() => copy(activeRoot.path + '/' + current?.path)}>复制路径</button>{textMenu && <button onClick={() => copy(text)}>复制文件内容</button>}<button disabled={!current} onClick={() => revealTarget(current?.root, current?.path)}>在 Finder 中显示</button></>}
   {menu.type === 'code' && <>{Object.entries(LANGUAGE_ACTIONS).map(([kind,label])=><button key={kind} onClick={()=>{setSymbol(kind);setMenu(null)}}>{kind==='references'?'查找':'转到'}{label}</button>)}<button onClick={()=>{setSymbol('settings');setMenu(null)}}>语言服务设置…</button><button disabled={!selection} onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
            setMenu(null);
          }}>请 CLI 修改所选文本…</button><button disabled={!selection} onClick={() => { const range = selectionLineRange(selection.source, selection.start, selection.end); addRef('range', { path: current.path, range, selection }); setMenu(null); }}>添加所选内容到终端引用</button><button onClick={() => copy(selection?.text || text)}>复制</button></>}
   {menu.type === 'file' && <><strong>{menu.path.split('/').pop()}</strong><button disabled={appsState!=='ready' || !applications.preferred} onClick={()=>openApplication(applications.preferred?.id)}>{applications.preferred ? `使用 ${applications.preferred.name} 打开` : '首选应用不可用'}</button>{appsState==='loading'&&<small>正在读取可用应用…</small>}{appsState==='error'&&<><small role="alert">无法获取可用应用。输入和文件已保留。</small><button onClick={()=>setAppsAttempt(v=>v+1)}>重新读取应用列表</button></>}{appsState==='unavailable'&&<small>此宿主未提供外部应用能力。</small>}<button onClick={() => setMenu({
            type: 'external',
            path: menu.path, root:menu.root
          })}><ExternalLink size={15} />打开方式</button>{!menu.folder && <button disabled={appsState==='unavailable'} onClick={() => download(menu.path, menu.root)}><Download size={15} />另存为…</button>}<button onClick={() => copy(fileAbsolutePath(menuRoot, menu.path) || menuRoot.path)}><Copy size={15} />复制完整路径</button><button onClick={() => copy(menu.path)}><Copy size={15} />复制相对路径</button>{menu.origin === 'breadcrumb' && <>{!menu.folder && isText(getFile(menu.root, menu.path)) && <button onClick={() => copy(state.drafts[fileKey(menu.root, menu.path)]?.text ?? store.saved?.[documentKey(roots, fileKey(menu.root, menu.path))] ?? getFile(menu.root, menu.path)?.text ?? '')}><Copy size={15} />复制文件内容</button>}<button onClick={() => revealTarget(menu.root, menu.path, Boolean(menu.folder))}><FolderOpen size={15} />在 Finder 中显示</button></>}{!menu.folder && <button onClick={() => {
            addRef('file', { path: menu.path });
            setMenu(null);
          }}>添加到终端引用</button>}</>}
   {menu.type === 'tab' && <><button onClick={() => {
            set(s => ({
              ...s,
              tabs: s.tabs.map(t => fileKey(t.root, t.path) === menu.key ? {
                ...t,
                preview: false
              } : t)
            }));
            setMenu(null);
          }}><Pin size={15} />固定标签</button><button onClick={() => {
            close(menu.key);
            setMenu(null);
          }}>关闭标签</button><button onClick={() => {
            set(s => restoreFile(s));
            setMenu(null);
          }}>重新打开关闭的标签</button><button onClick={() => {
            setDock(dock === 'right' ? 'bottom' : 'right');
            setMenu(null);
          }}>{dock === 'right' ? '移到底部面板' : '移到右侧面板'}</button></>}
   {menu.type === 'crumb' && <><strong>{menu.prefix||roots.find(r=>r.id===menu.root)?.label||activeRoot.label}</strong>{menu.prefix&&<button onClick={()=>setMenu({...menu,prefix:menu.prefix.split('/').slice(0,-1).join('/')})}><Folder size={15}/>上级目录</button>}<PrototypeBreadcrumbDirectory key={menu.root+'|'+menu.prefix} files={filesForRoot(menu.root)} prefix={menu.prefix} rootPath={roots.find(r=>r.id===menu.root)?.path||''} scenario={breadcrumbScenario} onDirectory={prefix=>setMenu({...menu,prefix})} onChoose={path=>open(path,false,menu.root)} /><hr/><button onClick={()=>copy(fileAbsolutePath(roots.find(r=>r.id===menu.root),menu.prefix)||'')}>复制目录路径</button><button onClick={()=>revealTarget(menu.root, menu.prefix, true)}>在文件管理器中显示</button></>}
   {menu.type === 'external' && <><strong>打开方式</strong>{appsState!=='ready'&&<p>{appsState==='loading'?'正在读取可用应用…':appsState==='error'?'读取应用失败':'此宿主未提供外部应用能力'}</p>}{appsState==='error'&&<button onClick={()=>setAppsAttempt(v=>v+1)}>重新读取应用列表</button>}{applications.preferredUnavailable && <p role="status">首选应用当前不可用，请选择其它应用。</p>}{applications.apps.map(app => <button disabled={appsState!=='ready'} key={app.id} onClick={() => openApplication(app.id, rememberApp)}><ExternalLink size={15} />{app.name}{app.systemDefault ? '（系统默认）' : ''}{applications.preferred?.id===app.id && <Check size={14}/>}</button>)}<hr/><button role="menuitemcheckbox" aria-checked={rememberApp} onClick={() => setRememberApp(value => !value)}>{rememberApp && <Check size={14}/>}记住选择的应用</button><button onClick={() => copy(menuRoot.path + '/' + (menu.path || current?.path || ''))}><Copy size={15} />复制路径</button></>}
   {menu.type === 'formats' && <><strong>文件类型 / 会话产物入口（模拟）</strong>{filesForRoot().map(f => <button key={f.path} onClick={() => open(f.path, true)}><Icon file={f} />{f.path}</button>)}<hr />{['csv', 'tsv', 'ipynb', 'tex', 'pdf', 'pdf-review', 'docx', 'xlsx', 'pptx'].map(kind => <button key={kind} onClick={() => {
            setRich(kind);
            setMenu(null);
          }}>以会话产物打开 {kind.toUpperCase()}</button>)}</>}
  </div></>}
  {recoveryOpen && <FileRecoveryPrototype onClose={() => setRecoveryOpen(false)}/>}
  {aiState && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label="请 CLI 修改所选文本"><h2>请 CLI 修改所选文本</h2><p>把“位置＋所选文字＋你的指令”放入终端输入，由你检查后按 Enter。CLI 按自身权限与指令操作文件，WillYou 不再审批。投递后即结束交接；取消这里只关闭指令草稿，不停止 CLI。此原型使用合成数据，不读写真实磁盘。</p><pre className="fw-ai-selection">{aiState.selection?.text}</pre><textarea aria-label="修改指令" className="fw-ai-prompt" placeholder="描述你希望 CLI 怎样修改…" value={aiState.instruction} onChange={e => setAiState(a => ({ ...a, instruction: e.target.value }))} />{!taskRunning && <p role="alert" className="fw-readonly">任务未运行，无法放入终端输入。</p>}<div className="fw-dialog-actions"><button onClick={() => setAiState(null)}>取消</button><button disabled={!aiState.instruction.trim() || !taskRunning || refBusy} onClick={requestCliEdit}>放入终端输入（不发送）</button></div></section></div>}
  {attachmentCopy && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label="另存附件副本（原型模拟）" onKeyDown={e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();setAttachmentCopy(null);note('已取消附件副本下载，原内容未改变。');}}}><h2>另存附件副本（原型模拟）</h2><p>仅下载当前合成附件的原始 UTF-8 内容；正式应用使用系统保存框。取消不会创建下载，附件保持只读。</p><label>副本文件名<input autoFocus aria-label="附件副本文件名" value={attachmentCopy.name} onChange={e=>setAttachmentCopy(x=>({...x,name:e.target.value}))}/></label><div className="fw-dialog-actions"><button onClick={()=>{setAttachmentCopy(null);note('已取消附件副本下载，原内容未改变。');}}>取消</button><button disabled={!attachmentCopy.name.trim()||['.','..'].includes(attachmentCopy.name)||/[\/\x00-\x1f]/.test(attachmentCopy.name)} onClick={()=>{const url=URL.createObjectURL(new Blob([new TextEncoder().encode(attachmentCopy.text)],{type:attachmentCopy.mimeType||'text/plain'})),a=document.createElement('a');a.href=url;a.download=attachmentCopy.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);setAttachmentCopy(null);note('已下载只读附件的合成原始内容，原附件未改变。');}}>保存副本</button></div></section></div>}
  {confirm && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label={confirm.type === 'close' ? '保留未保存修改' : '文件修改冲突'}>{confirm.type === 'close' ? <><h2>仍有未保存的修改</h2><p>可以继续查看并保存，或者放弃此文件的修改。</p><div className="fw-dialog-actions"><button onClick={() => setConfirm(null)}>继续查看</button><button className="fw-danger" onClick={() => discard(confirm.key, confirm)}>放弃修改并关闭</button></div></> : <><h2>文件已在外部更改</h2><p>请核对本地草稿与磁盘版本。选择前不会覆盖任何一方。</p><div className="fw-conflict-columns"><div><strong>磁盘版本（模拟）</strong><pre>{state.fileStates?.[confirm.key]?.diskText ?? ''}</pre></div><div><strong>本地草稿</strong><pre>{state.drafts[confirm.key]?.text ?? ''}</pre></div></div><div className="fw-dialog-actions"><button onClick={() => { set(s => continueConflict(s, confirm.key)); setConfirm(null); requestAnimationFrame(() => editor.current?.focus()); }}>继续编辑</button><button onClick={() => {
              const diskText = state.fileStates?.[confirm.key]?.diskText;
              if (diskText === undefined) {
                note('磁盘示例尚未读取，保留当前修改。');
                return;
              }
              const targetIdentity = documentKey(roots, confirm.key);
              delete historyRef.current[targetIdentity];
              setStore(old => ({
                ...old,
                [scope]: acceptDisk(old[scope] || state, confirm.key),
                saved: {
                  ...old.saved,
                  [targetIdentity]: diskText
                }
              }));
              setConfirm(null);
            }}>采用磁盘版本</button><button onClick={() => {
              save(confirm.key, true);
              setConfirm(null);
            }}>保留本地并保存</button></div></>}</section></div>}
 </aside>;
}
