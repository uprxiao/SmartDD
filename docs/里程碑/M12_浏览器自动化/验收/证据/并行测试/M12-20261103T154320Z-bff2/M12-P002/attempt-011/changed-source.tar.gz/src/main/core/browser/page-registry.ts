import { BaseWindow, WebContentsView, type BrowserWindow, type Rectangle, type WebContents, type BrowserWindowConstructorOptions } from 'electron';
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';
import { BrowserCdpProxy } from './cdp-proxy';
import { BrowserHelper, type BrowserHelperOptions } from './agent-browser';
import { BrowserReferences } from './references';
import { BrowserPageQueue } from './queue';
import { BrowserParkWindow } from './park-window';
import { browserDigest } from './artifacts';
import { BrowserError } from './errors';

export interface BrowserPage {
  id:string;short:string;taskId:string;projectId:string;profileId:string;view:WebContentsView;
  proxy:BrowserCdpProxy;helper:BrowserHelper;references:BrowserReferences;queue:BrowserPageQueue;
  rect:Rectangle;closed:boolean;abort:AbortController;hostNavigation:string|null;
  kind:'tab'|'popup';openerPageId?:string;popupWindow?:BaseWindow;
}
export type BrowserPageEvent={type:'created'|'closed';page:BrowserPage};
export const browserProjectProfile=(projectId:string)=>'project-'+browserDigest(projectId).slice(0,24);
export class BrowserPageRegistry {
  private readonly pages=new Map<string,BrowserPage>();
  private readonly active=new Map<string,string>();
  private readonly park=new BrowserParkWindow();
  private ordinal=0;
  private mounted?:BrowserPage;
  private readonly observers=new Set<(event:BrowserPageEvent)=>void>();
  private readonly closing=new Map<string,Promise<void>>();
  constructor(private readonly options:{userData:string;helper:Pick<BrowserHelperOptions,'executable'|'sha256'|'processes'>;window?:()=>BrowserWindow|null}){}
  observe(listener:(event:BrowserPageEvent)=>void):()=>void{this.observers.add(listener);return()=>{this.observers.delete(listener);};}
  private publish(type:BrowserPageEvent['type'],page:BrowserPage){for(const listener of this.observers)listener({type,page});}
  list(taskId:string){return [...this.pages.values()].filter(page=>page.taskId===taskId&&!page.closed);}
  get(taskId:string,id?:string):BrowserPage {
    const page=this.pages.get(id??this.active.get(taskId)??'');
    if(!page||page.closed||page.view.webContents.isDestroyed()||page.taskId!==taskId)throw new BrowserError(id?'BROWSER_TAB_NOT_FOUND':'BROWSER_NO_TAB','本任务没有这个网页标签');
    return page;
  }
  async create(taskId:string,projectId:string,savedId?:string):Promise<BrowserPage>{
    const id=savedId??randomUUID(),short='k'+(++this.ordinal).toString(36),profileId=browserProjectProfile(projectId);
    if(this.pages.has(id))throw new BrowserError('BROWSER_ERROR','网页身份已经存在');
    const view=new WebContentsView({webPreferences:{partition:'persist:wy-browser-'+profileId,sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});
    const proxy=new BrowserCdpProxy(view.webContents),references=new BrowserReferences(proxy,short);
    const page:BrowserPage={id,short,taskId,projectId,profileId,view,proxy,references,helper:undefined!,queue:new BrowserPageQueue(),rect:{x:0,y:0,width:1000,height:700},closed:false,abort:new AbortController(),hostNavigation:null,kind:'tab'};
    view.webContents.setWindowOpenHandler(()=>({action:'deny'})); // Popup UI/lifecycle is implemented in S2.
    const denyUnsafeNavigation=(event:Electron.Event,url:string)=>{
      try{const protocol=new URL(url).protocol;if(protocol==='javascript:')return;const localLink=protocol==='file:'&&view.webContents.getURL().startsWith('file:');if(!['http:','https:','about:'].includes(protocol)&&url!==page.hostNavigation&&!localLink)event.preventDefault();}catch{event.preventDefault();}
    };
    view.webContents.on('will-navigate',denyUnsafeNavigation);
    view.webContents.on('will-redirect',(event,url)=>{if(url.startsWith('file:'))event.preventDefault();else denyUnsafeNavigation(event,url);});
    try {
      await this.park.park(view,page.rect);
      await view.webContents.loadURL('about:blank');
      await proxy.start();await references.initialize();
      page.helper=new BrowserHelper({...this.options.helper,home:join(this.options.userData,'browser/agent-browser-home',id),
        // Darwin Unix-domain sockets have a short pathname limit. The home remains under userData.
        sockets:join('/private/tmp','wy-ab-'+browserDigest(this.options.userData+id).slice(0,24)),session:'wy-'+short,endpoint:proxy.endpoint},()=>references.invalidate());
      this.pages.set(id,page);if(!this.active.has(taskId))this.active.set(taskId,id);
      this.publish('created',page);
      return page;
    }catch(error){await proxy.stop();this.park.remove(view);view.webContents.close();throw error;}
  }
  /** Electron binds the opener to the returned WebContents. The child uses its
   * own native window and the opener's exact session, never an App preload. */
  createPopup(opener:BrowserPage,options:BrowserWindowConstructorOptions,asTab=false):WebContents{
    const id=randomUUID(),short='k'+(++this.ordinal).toString(36);
    const view=new WebContentsView({webPreferences:{session:opener.view.webContents.session,sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true,backgroundThrottling:false}});
    const window=asTab?undefined:new BaseWindow({width:Math.max(320,Math.min(options.width??800,1400)),height:Math.max(240,Math.min(options.height??600,1000)),show:false,title:'WillYou · 网页登录'});
    const bounds=window?.getContentBounds()??{width:1000,height:700};window?.contentView.addChildView(view);view.setBounds({x:0,y:0,width:bounds.width,height:bounds.height});
    const proxy=new BrowserCdpProxy(view.webContents),references=new BrowserReferences(proxy,short);
    const page:BrowserPage={id,short,taskId:opener.taskId,projectId:opener.projectId,profileId:opener.profileId,view,proxy,references,helper:undefined!,queue:new BrowserPageQueue(),rect:{x:0,y:0,width:bounds.width,height:bounds.height},closed:false,abort:new AbortController(),hostNavigation:null,kind:asTab?'tab':'popup',openerPageId:opener.id,popupWindow:window};
    view.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    const guard=(event:Electron.Event,url:string)=>{try{if(!['http:','https:','about:','javascript:'].includes(new URL(url).protocol))event.preventDefault();}catch{event.preventDefault();}};
    view.webContents.on('will-navigate',guard);view.webContents.on('will-redirect',guard);
    window?.on('resize',()=>{if(!view.webContents.isDestroyed()){const r=window.getContentBounds();view.setBounds({x:0,y:0,width:r.width,height:r.height});}});
    window?.on('closed',()=>{if(this.pages.has(id))void this.close(page.taskId,id);else if(!view.webContents.isDestroyed())view.webContents.close();});
    view.webContents.on('destroyed',()=>{if(this.pages.has(id))void this.close(page.taskId,id);});
    void(async()=>{
      try{
        if(asTab)await this.park.park(view,page.rect);
        await proxy.start();await references.initialize();
        if(view.webContents.isDestroyed()||opener.closed)throw new BrowserError('BROWSER_TAB_CLOSED','来源页面已关闭');
        page.helper=new BrowserHelper({...this.options.helper,home:join(this.options.userData,'browser/agent-browser-home',id),sockets:join('/private/tmp','wy-ab-'+browserDigest(this.options.userData+id).slice(0,24)),session:'wy-'+short,endpoint:proxy.endpoint},()=>references.invalidate());
        this.pages.set(id,page);this.publish('created',page);if(this.mounted?.taskId===page.taskId)window?.showInactive();
      }catch{await proxy.stop();this.park.remove(view);if(window&&!window.isDestroyed())window.close();if(!view.webContents.isDestroyed())view.webContents.close();}
    })();
    return view.webContents;
  }
  async navigate(page:BrowserPage,url:string):Promise<void>{
    let normalized:string;
    try{const parsed=new URL(url);if(!['http:','https:','file:','about:'].includes(parsed.protocol)||parsed.protocol==='about:'&&url!=='about:blank')throw Error();normalized=parsed.href;}catch{throw new BrowserError('BROWSER_ERROR','请输入有效的 http(s)、file 或 about:blank 地址');}
    page.references.invalidate();page.hostNavigation=normalized;
    try{await page.view.webContents.loadURL(normalized);}finally{page.hostNavigation=null;}
  }
  async placement(taskId:string,pageId:string,rect:Rectangle|null):Promise<void>{
    const page=this.get(taskId,pageId),window=this.options.window?.();
    if(page.kind==='popup')throw new BrowserError('BROWSER_ERROR','子窗口不能挂到工作区');
    if(this.mounted&&this.mounted!==page&&window&&!window.isDestroyed()){
      window.contentView.removeChildView(this.mounted.view);await this.park.park(this.mounted.view,this.mounted.rect);this.mounted=undefined;
    }
    if(rect&&window&&!window.isDestroyed()){
      if(!Object.values(rect).every(Number.isFinite)||rect.width<1||rect.height<1)throw new BrowserError('BROWSER_ERROR','网页显示区域无效');
      this.park.remove(page.view);window.contentView.addChildView(page.view);page.rect=rect;page.view.setBounds(rect);this.mounted=page;this.active.set(taskId,pageId);
    }else{
      if(this.mounted===page&&window&&!window.isDestroyed()){window.contentView.removeChildView(page.view);this.mounted=undefined;}
      await this.park.park(page.view,page.rect);
    }
    for(const child of this.pages.values())if(child.popupWindow&&!child.popupWindow.isDestroyed()){
      if(this.mounted?.taskId===child.taskId)child.popupWindow.showInactive();else child.popupWindow.hide();
    }
  }
  activate(taskId:string,pageId:string):void{this.get(taskId,pageId);this.active.set(taskId,pageId);}
  close(taskId:string,pageId:string):Promise<void>{
    const page=this.pages.get(pageId);
    if(!page||page.taskId!==taskId)return Promise.reject(new BrowserError('BROWSER_TAB_NOT_FOUND','本任务没有这个网页标签'));
    const pending=this.closing.get(pageId);if(pending)return pending;
    const closing=this.closePage(page).finally(()=>{this.closing.delete(pageId);});this.closing.set(pageId,closing);return closing;
  }
  private async closePage(page:BrowserPage):Promise<void>{
    const {taskId,id:pageId}=page;page.closed=true;page.queue.close();page.abort.abort(new BrowserError('BROWSER_TAB_CLOSED','网页已经关闭'));
    for(const child of this.list(taskId).filter(p=>p.kind==='popup'&&p.openerPageId===pageId))await this.close(taskId,child.id);
    await page.helper.close();await page.queue.settled();await page.proxy.stop();
    const window=this.options.window?.();if(this.mounted===page&&window&&!window.isDestroyed()){window.contentView.removeChildView(page.view);this.mounted=undefined;}
    this.park.remove(page.view);if(!page.view.webContents.isDestroyed())page.view.webContents.close();if(page.popupWindow&&!page.popupWindow.isDestroyed())page.popupWindow.close();this.pages.delete(pageId);this.publish('closed',page);
    if(this.active.get(taskId)===pageId){const next=this.list(taskId)[0];if(next)this.active.set(taskId,next.id);else this.active.delete(taskId);}
  }
  async dispose():Promise<void>{for(const page of [...this.pages.values()])if(this.pages.has(page.id))await this.close(page.taskId,page.id);this.park.dispose();}
}
