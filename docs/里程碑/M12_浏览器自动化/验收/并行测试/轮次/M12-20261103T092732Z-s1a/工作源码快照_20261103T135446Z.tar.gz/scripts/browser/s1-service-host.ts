// I-level composition. Real service/module/CLI/gateway/SQLite/kernel peers; controlled run root and synthetic website.
import { app, BrowserWindow } from 'electron';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import type { CapabilitySessionSnapshot } from '../../src/shared/application-session';
import { capabilitySessionSnapshotV3Schema } from '../../src/shared/application-session-v3';
import { applicationNativeSkillName } from '../../src/shared/application-session';
import { applicationToolDeclarations } from '../../src/shared/application-capabilities';
import * as schema from '../../src/main/db/schema';
import { SecretsStore } from '../../src/main/secrets';
import { ProjectService } from '../../src/main/core/projects/project-service';
import { agentFixture } from '../../src/main/core/applications/__tests__/agent-fixture';
import { BrowserService } from '../../src/main/core/browser/service';
import type { BrowserPage } from '../../src/main/core/browser/page-registry';
import { CapabilityBundleSource } from '../../src/main/core/applications/bundle-source';
import { BuiltinPackageRegistry } from '../../src/main/core/applications/builtin-package-registry';
import { RuntimeRegistry } from '../../src/main/core/applications/runtime-registry';
import { ApplicationService } from '../../src/main/core/applications/application-service';
import { ApplicationToolService } from '../../src/main/core/applications/tool-service';
import { ApplicationAdapterRegistry } from '../../src/main/core/applications/application-adapter-registry';
import { CapabilityRunRegistry } from '../../src/main/core/applications/run-registry';
import { createApplicationRunPlan } from '../../src/main/core/applications/run-plan';
import { applicationSkillContentHash } from '../../src/main/core/applications/session-registry';
import { MacProcessIdentityReader } from '../../src/main/core/applications/process-identity';
import { MacUnixPeerIdentityReader } from '../../src/main/core/applications/unix-peer-identity';
import { ApplicationCliGateway } from '../../src/main/core/applications/cli-gateway';
import { digest } from '../../src/main/core/applications/manifest';
import { ApplicationError } from '../../src/shared/applications';

for (const event of ['uncaughtException','unhandledRejection'] as const) process.on(event,error => {
  process.send?.({ fatal:String(error instanceof Error ? error.stack : error) }); app.exit(1);
});
let browser: BrowserService, applications: ApplicationService, gateway: ApplicationCliGateway;
let fixture: Awaited<ReturnType<typeof agentFixture>>, run: Awaited<ReturnType<CapabilityRunRegistry['reserve']>>;
let host: BrowserWindow, taskId: string, environment: NodeJS.ProcessEnv, binary: string;
let secondary: {taskId:string;pageId:string}|undefined;
const guardResponses=new Map<string,unknown>(),observedContents=new Set<number>();
interface SnapshotRace { mode:string;pageId:string;iterations:{before:number;helper:number;after:number}[];captures:number[][];restored:boolean }
const snapshotRaces:SnapshotRace[]=[],raceRestores=new Map<string,()=>void>();
const contextEvents:unknown[]=[];
const nestedMutations:{kind:string;point:string;mode:string;before:unknown;objectId:string;sessionId?:string}[]=[];
async function actionBackend(page:BrowserPage):Promise<number>{
  const doc=await page.proxy.send<{root:{nodeId:number}}>('DOM.getDocument');
  const selected=await page.proxy.send<{nodeId:number}>('DOM.querySelector',{nodeId:doc.root.nodeId,selector:'#action'});
  return (await page.proxy.send<{node:{backendNodeId:number}}>('DOM.describeNode',{nodeId:selected.nodeId})).node.backendNodeId;
}
const children = new Set<ReturnType<typeof spawn>>();
const timingEvents:{label:string|null;phase:string|null;at:number}[]=[];
const respond = (request:IncomingMessage,response:ServerResponse) => {
  const url=new URL(request.url??'/','http://127.0.0.1');
  if(url.pathname==='/event'){
    timingEvents.push({label:url.searchParams.get('label'),phase:url.searchParams.get('phase'),at:performance.now()});
    response.setHeader('content-type','application/json');response.end('{"received":true}');return;
  }
  response.setHeader('content-type','text/html;charset=utf-8');
  const address=server.address();if(!address||typeof address==='string')throw Error('Fixture HTTP address missing');
  const parentOrigin='http://127.0.0.1:'+address.port,frameOrigin='http://localhost:'+address.port;
  if(url.pathname==='/frame'){
    const script=`const state={value:'',hits:0};const report=()=>parent.postMessage({kind:'frame-state',...state},${JSON.stringify(parentOrigin)});document.addEventListener('input',e=>{if(e.target.id==='frame-field'){state.value=e.target.value;document.getElementById('echo').textContent=JSON.stringify(state);report();}},true);document.addEventListener('click',e=>{if(e.target.id==='frame-action'){state.hits++;document.getElementById('echo').textContent=JSON.stringify(state);report();}},true);report();`;
    new Function(script);
    response.end('<title>[I] cross-site child</title><button id="frame-action">Frame action</button><input id="frame-field" aria-label="Frame input"><p id="echo"></p><script>'+script+'</script>');return;
  }
  let html='<title>[I] S1 real native CLI</title><form><button type="button" id="action" data-instance="initial">Action</button><input id="field" aria-label="Input"><div contenteditable role="textbox" aria-label="Editor"></div><select aria-label="Choice"><option>A</option><option>B</option></select><input type="checkbox" aria-label="Check"><input type="file" aria-label="Upload"></form><div style="height:3000px">Long page</div><script>window.hits=[];window.hitInstances=[];window.inputEvents=[];window.addEventListener("input",e=>inputEvents.push({id:e.target.id,value:e.target.value}),true);window.addEventListener("click",e=>{hits.push(e.target.id);hitInstances.push(e.target.dataset.instance??e.target.id)},true);window.delayedStep=async function(label){await fetch("/event?phase=start&label="+encodeURIComponent(label));await new Promise(resolve=>setTimeout(resolve,2000));await fetch("/event?phase=end&label="+encodeURIComponent(label));return label;}</script>';
  if(url.pathname==='/nested'){
    const before=`window.frameState={value:'',hits:0};window.addEventListener('message',e=>{if(e.origin===${JSON.stringify(frameOrigin)}&&e.data?.kind==='frame-state'){window.frameState={...e.data,origin:e.origin};document.getElementById('frame-echo').textContent=JSON.stringify(window.frameState);}});`;
    const shadow=`(()=>{const host=document.getElementById('closed-host'),root=host.attachShadow({mode:'closed'});root.innerHTML='<button id="shadow-action">Shadow action</button><input id="shadow-field" aria-label="Shadow input"><p id="shadow-echo"></p>';window.shadowState={value:'',hits:0};const report=()=>{root.getElementById('shadow-echo').textContent=JSON.stringify(window.shadowState);document.getElementById('outer-shadow-echo').textContent=JSON.stringify(window.shadowState);};root.addEventListener('input',e=>{if(e.target.id==='shadow-field'){window.shadowState.value=e.target.value;report();}},true);root.addEventListener('click',e=>{if(e.target.id==='shadow-action'){window.shadowState.hits++;report();}},true);report();})();`;
    new Function(before);new Function(shadow);
    const nested='<script>'+before+'</script><iframe id="embedded" width="640" height="160" src="'+frameOrigin+'/frame"></iframe><p id="frame-echo"></p><div id="closed-host" style="display:block;min-height:70px;width:640px;border:1px solid"></div><p id="outer-shadow-echo"></p><script>'+shadow+'</script>';
    html=html.replace('<div style="height:3000px">',nested+'<div style="height:3000px">');
  }
  response.end(html);
};
const server=createServer(respond),ipv6Server=createServer(respond);
app.whenReady().then(async () => {
  const resources = process.env.M12_RESOURCE_ROOT!;
  const source = new CapabilityBundleSource(join(resources,'capability-bundles'));
  fixture = await agentFixture();
  const processes = new MacProcessIdentityReader(join(resources,'native/willyou-process-identity'));
  const helperSource = JSON.parse(readFileSync(join(resources,'agent-browser/SOURCE.json'),'utf8'));
  const helperFile = helperSource.files.find((file:{arch:string}) => file.arch === process.arch);
  host = new BrowserWindow({show:false,focusable:false,skipTaskbar:true,width:1000,height:700,title:'[I] S1 isolated native CLI host',webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  await host.loadURL('data:text/html,<title>[I] S1 controlled run host</title>'); host.showInactive();
  browser = new BrowserService({userData:app.getPath('userData'),sqlite:fixture.sqlite,helper:{executable:join(resources,'agent-browser',process.arch,'agent-browser'),sha256:helperFile.sha256,processes},window:()=>host,taskProject:id => {
    const row = fixture.sqlite.prepare('SELECT project_id FROM tasks WHERE id=?').get(id) as {project_id:string}|undefined;
    return row?.project_id ?? null;
  }});
  const createPage=browser.pages.create.bind(browser.pages);
  browser.pages.create=async(task,project)=>{
    const page=await createPage(task,project);
    page.proxy.onEvent(event=>{if(['Runtime.executionContextCreated','Runtime.executionContextDestroyed','Runtime.executionContextsCleared','Target.attachedToTarget','Page.frameNavigated'].includes(event.method))contextEvents.push({pageId:page.id,...event});});
    return page;
  };
  await new RuntimeRegistry(fixture.store).install(source.runtime());
  const trusted = new BuiltinPackageRegistry(fixture.store), entry = source.index.apps.find(item => item.appId === 'browser');
  if (!entry) throw Error('Frozen browser package missing');
  const installed = await trusted.install(source,entry), manifest = installed.manifest;
  if (manifest.schema !== 'smartdd-app-package-v2') throw Error('Browser v2 package required');
  await trusted.packages.activate(installed.packageHash,trusted.packages.active('browser')?.generation ?? 0);
  const db = drizzle(fixture.sqlite,{schema});
  // No connections or credentials exist; this codec is unused by browser calls.
  const secrets = new SecretsStore(db,{isAvailable:()=>true,encrypt:value=>Buffer.from(value),decrypt:value=>value.toString()});
  applications = new ApplicationService(fixture.store,{secrets,projects:new ProjectService(db,secrets),tasks:{stopProject:async()=>true,runningInProject:()=>0},requireSender:()=>{},mailWorker:join(fixture.root,'unused-mail-worker'),foxmailNative:join(fixture.root,'unused-native-mail'),processes,browser});
  await applications.recover(); await applications.selections.setAdded('browser',true,0);
  await applications.selections.select({projectId:'p1',appId:'browser',enabled:true,expectedRevision:0,connections:{}});
  const base = fixture.plan('codex'), adapter = fixture.installedAdapters.find(item => item.metadata.agentId === 'codex' && item.metadata.version === '1.2.0');
  if (!adapter) throw Error('Frozen adapter missing');
  taskId = base.taskId;
  fixture.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(taskId,'p1',fixture.cwd,'codex','[I] S1 synthetic task',1,1);
  const snapshot:CapabilitySessionSnapshot = {...base,schema:3,agentAtCreation:{version:'0.166.0',adapterRevision:1},adapterBinding:{id:'codex',version:adapter.metadata.version,hash:adapter.hash,projectionFormatVersion:1,nativeToolNames:{}},packages:[{
    appId:'browser',version:manifest.version,packageHash:installed.packageHash,hashAlgorithm:'app-manifest-v1',hostApi:manifest.hostApi,dataApi:manifest.dataApi,runtimeHash:manifest.runtime.hash,toolContractMajors:Object.fromEntries(applicationToolDeclarations(manifest).map(tool=>[tool.name,tool.contractMajor])),capabilityContractMajors:Object.fromEntries(manifest.capabilities.map(capability=>[capability.id,capability.contractMajor])),entry:'cli',bindings:[],allowedOperations:manifest.permissions,
    skills:manifest.skills.map(skill => {const nativeName=applicationNativeSkillName('browser',skill.id,installed.packageHash);return {skillId:skill.id,nativeName,contentHash:applicationSkillContentHash(manifest,skill.path),sourceRelativePath:skill.path,projectionPath:join(fixture.home,'.agents/skills',nativeName,'SKILL.md')};}),
  }],mcp:base.mcp.filter(item=>item.kind!=='applications')};
  const checked = capabilitySessionSnapshotV3Schema.safeParse(snapshot);
  if (!checked.success) throw Error('Fixture snapshot validation: '+JSON.stringify(checked.error.issues));
  const session = await fixture.sessions.create(checked.data,fixture.home);
  const runs = new CapabilityRunRegistry(fixture.store,fixture.sessions,{processes,assertCurrent:()=>{},revoke:()=>{},createPlan:(selected,hash,runId)=>createApplicationRunPlan({runId,snapshot:selected,snapshotHash:hash,applications:[{manifest,packageHash:installed.packageHash,capabilities:manifest.capabilities}],skills:[],available:{mcp:true,cli:true}})});
  applications.attachRuns(runs); run = await runs.reserve({taskId,snapshotHash:session.pointer.snapshotHash,bindings:[]});
  await run.prepare(); await run.cli.arm(); await run.cli.attach(process.pid);
  const tools = new ApplicationToolService(fixture.store,runs,new ApplicationAdapterRegistry(fixture.store,applications.data),{entry:'cli',retryDelays:[0,0]});
  binary = resolve(resources,'native/willyou-app');
  gateway = new ApplicationCliGateway(runs,tools,new MacUnixPeerIdentityReader(join(resources,'native/willyou-process-identity')),{executable:{path:binary,sha256:digest(readFileSync(binary))}});
  await gateway.start(); environment = {...gateway.issue(run).environment};
  await new Promise<void>(ok=>server.listen(0,'127.0.0.1',ok)); const address=server.address(); if (!address || typeof address==='string') throw Error('Fixture HTTP bind');
  await new Promise<void>((ok,no)=>{ipv6Server.once('error',no);ipv6Server.listen({port:address.port,host:'::1',ipv6Only:true},()=>{ipv6Server.off('error',no);ok();});});
  process.send?.({ready:true,pid:process.pid,taskId,runId:run.runId,url:`http://127.0.0.1:${address.port}/`,versions:process.versions,boundary:'I: real BrowserService/M11 module/CLI/gateway/SQLite/kernel peers; controlled Electron process as run root; synthetic page; not packaged App or real Agent'});
}).catch(error=>{process.send?.({fatal:String(error.stack??error)});app.exit(1);});

process.on('message',async (message:{id:number;command:string;args?:string[];input?:string;paused?:boolean;expression?:string;opacity?:number;ignoreMouse?:boolean;focusEmulation?:boolean;pageId?:string;mode?:string;ref?:string;kind?:string;point?:string}) => {
  try {
    let value:unknown;
    if (message.command === 'cli') value = await new Promise(resolve => {
      const child=spawn(binary,message.args!,{env:environment,stdio:[message.input===undefined?'ignore':'pipe','pipe','pipe']}); children.add(child);
      if (message.input!==undefined) child.stdin!.end(message.input);
      let stdout='',stderr='',timedOut=false;
      const timer=setTimeout(()=>{timedOut=true;child.kill('SIGKILL');},105000);
      child.stdout!.on('data',chunk=>stdout+=chunk);child.stderr!.on('data',chunk=>stderr+=chunk);
      child.on('close',(code,signal)=>{clearTimeout(timer);children.delete(child);resolve({code,signal,stdout,stderr,timedOut});});
    });
    else if (message.command === 'observe') {
      const page=browser.pages.get(taskId,message.pageId);
      value={...(await page.proxy.send<{result:{value:{hits:string[];value:string;url:string}}}>('Runtime.evaluate',{expression:'({hits:window.hits,instances:window.hitInstances,inputEvents:window.inputEvents,value:document.getElementById("field")?.value??null,url:location.href})',returnByValue:true})).result.value,rect:page.view.getBounds(),guardResponse:guardResponses.get(page.id)};
    }
    else if(message.command==='nested-observe'){
      const page=browser.pages.get(taskId);
      const frames=[];
      for(const id of page.proxy.sessions.keys())try{await page.proxy.frameReady(id);frames.push({id,ready:true,tree:await page.proxy.send('Page.getFrameTree',{},id)});}catch(error){frames.push({id,ready:false,error:String(error)});}
      const worlds=Reflect.get(page.references,'worlds'),bindings=Reflect.get(page.references,'refs');
      value={state:(await page.proxy.send<{result:{value:unknown}}>('Runtime.evaluate',{expression:'({frame:window.frameState,shadow:window.shadowState,frameEcho:document.getElementById("frame-echo")?.textContent,shadowEcho:document.getElementById("outer-shadow-echo")?.textContent,closed:document.getElementById("closed-host")?.shadowRoot===null})',returnByValue:true})).result.value,sessions:[...page.proxy.sessions].map(([id,target])=>({id,...target})),diagnostic:{frames,worlds:worlds instanceof Map?[...worlds]:null,bindings:bindings instanceof Map?[...bindings]:null,contexts:contextEvents}};
    }
    else if(message.command==='nested-mutate'){
      const page=browser.pages.get(taskId),bindings=Reflect.get(page.references,'refs') as Map<string,{backendNodeId:number;sessionId?:string}>;
      const node=bindings.get(message.ref!);if(!node)throw Error('Unknown private fixture ref');
      const mutate=async()=>{
        const resolved=await page.proxy.send<{object:{objectId:string}}>('DOM.resolveNode',{backendNodeId:node.backendNodeId},node.sessionId);
        const before=await page.proxy.send<{result:{value:unknown}}>('Runtime.callFunctionOn',{objectId:resolved.object.objectId,functionDeclaration:'function(){return {value:this.value??null,connected:this.isConnected}}',returnByValue:true},node.sessionId);
        const replacement=await page.proxy.send<{result:{objectId:string}}>('Runtime.callFunctionOn',{
          objectId:resolved.object.objectId,functionDeclaration:`function(fresh){
            const next=fresh?this.ownerDocument.createElement(this.tagName):this.cloneNode(true);
            if(fresh){for(const attr of this.attributes)if(attr.name!=='data-willyou-ref')next.setAttribute(attr.name,attr.value);next.textContent=this.textContent;if('value' in this)next.value=this.value;}
            this.replaceWith(next);return next;
          }`,arguments:[{value:message.mode==='fresh'}],returnByValue:false,
        },node.sessionId);
        await page.proxy.send('Runtime.releaseObject',{objectId:resolved.object.objectId},node.sessionId);
        nestedMutations.push({kind:message.kind!,point:message.point!,mode:message.mode!,before:before.result.value,objectId:replacement.result.objectId,sessionId:node.sessionId});
      };
      if(message.point==='before-arm')await mutate();
      else if(message.point==='post-arm'){
        const original=page.references.arm.bind(page.references);
        page.references.arm=async ref=>{const armed=await original(ref);page.references.arm=original;await mutate();return armed;};
      }else if(message.point==='pre-input'){
        const original=page.proxy.send;
        page.proxy.send=async(method,params={},sessionId)=>{
          if(method==='Input.dispatchMouseEvent'||method==='Input.insertText'){page.proxy.send=original;await mutate();}
          return original(method,params,sessionId);
        };
      }else throw Error('Unknown nested fault point');
      value={installed:true,kind:message.kind,point:message.point,mode:message.mode};
    }
    else if(message.command==='nested-mutations'){
      const page=browser.pages.get(taskId),observations=[];
      for(const mutation of nestedMutations.slice(-1)){
        const after=await page.proxy.send<{result:{value:unknown}}>('Runtime.callFunctionOn',{objectId:mutation.objectId,functionDeclaration:'function(){return {value:this.value??null,connected:this.isConnected}}',returnByValue:true},mutation.sessionId);
        const {objectId,...metadata}=mutation;observations.push({...metadata,after:after.result.value});
      }
      value={mutations:observations,guard:guardResponses.get(page.id)};
    }
    else if(message.command==='helper-state'||message.command==='helper-kill'){
      const page=browser.pages.get(taskId,message.pageId),helper=page.helper;
      let pid:number|null=null;try{pid=Number(readFileSync(join(helper.options.sockets!,helper.options.session+'.pid'),'utf8'));}catch{}
      const identity=pid&&Number.isSafeInteger(pid)?helper.options.processes?.read(pid):null;
      if(message.command==='helper-kill'){
        if(!identity||helper.options.processes?.state(identity)!=='running')throw Error('Owned private helper is not running');
        process.kill(identity.pid,'SIGKILL');
        const deadline=performance.now()+2000;
        while(helper.options.processes.state(identity)==='running'&&performance.now()<deadline)await new Promise(ok=>setTimeout(ok,20));
        if(helper.options.processes.state(identity)!=='stopped')throw Error('Killed private helper has not stopped');
      }
      value={pageId:page.id,pid,identity,state:identity?helper.options.processes?.state(identity):'absent',url:page.view.webContents.getURL(),observed:(await page.proxy.send<{result:{value:unknown}}>('Runtime.evaluate',{expression:'({hits:window.hits,value:document.getElementById("field")?.value})',returnByValue:true})).result.value};
    }
    else if(message.command==='identity-mutate'){
      const page=browser.pages.get(taskId,message.pageId),scripts:Record<string,string>={
        replace:'(()=>{const old=document.getElementById("action"),next=old.cloneNode(true);next.dataset.instance="replaced";old.replaceWith(next)})()',
        insert:'(()=>{const old=document.getElementById("action"),next=old.cloneNode(true);next.id="inserted";next.dataset.instance="inserted";old.before(next)})()',
        duplicate:'(()=>{const old=document.getElementById("action"),next=old.cloneNode(true);next.id="second";next.dataset.instance="second";old.after(next)})()',
        reorder:'document.getElementById("second").after(document.getElementById("action"))',
        rename:'document.getElementById("action").textContent="Renamed"',
      };
      const expression=scripts[message.mode??''];if(!expression)throw Error('Unknown identity mutation');new Function(expression);
      const before=await actionBackend(page);await page.proxy.send('Runtime.evaluate',{expression});value={before,after:await actionBackend(page),mode:message.mode};
    }
    else if(message.command==='identity-empty'){
      await browser.pages.get(taskId).proxy.send('Runtime.evaluate',{expression:'document.querySelector("form").remove()'});value={removed:'all form controls'};
    }
    else if(message.command==='native-stale-contract'){
      const page=browser.pages.get(taskId),options=page.helper.options,ref=message.args?.[0];
      if(!ref||!/^@e\d+$/.test(ref))throw Error('Native ref required');
      const raw=await new Promise((resolve,reject)=>{
        const child=spawn(options.executable,['--session',options.session,'--cdp',options.endpoint,'batch','--json'],{env:{PATH:process.env.PATH,HOME:options.home,TMPDIR:join(options.home,'tmp'),XDG_CONFIG_HOME:join(options.home,'config'),XDG_CACHE_HOME:join(options.home,'cache'),AGENT_BROWSER_SOCKET_DIR:options.sockets??join(options.home,'sockets'),AGENT_BROWSER_IDLE_TIMEOUT_MS:'600000'},stdio:['pipe','pipe','pipe']});children.add(child);
        let stdout='',stderr='',timedOut=false;
        const timer=setTimeout(()=>{timedOut=true;child.kill('SIGKILL');},10000);
        child.stdout.on('data',bytes=>stdout+=bytes);child.stderr.on('data',bytes=>stderr+=bytes);child.once('error',reject);
        child.on('close',(code,signal)=>{clearTimeout(timer);children.delete(child);resolve({code,signal,stdout,stderr,timedOut});});
        child.stdin.on('error',()=>{});child.stdin.end(JSON.stringify([['click',ref]]));
      });
      let mapped:unknown;
      try{mapped={unexpectedSuccess:await page.helper.command(['click',ref],{timeout:5000})};}
      catch(error){mapped=error instanceof ApplicationError?{code:error.code,message:error.message}:{error:String(error)};}
      value={raw,mapped,nativeRef:ref,version:JSON.parse(readFileSync(join(process.env.M12_RESOURCE_ROOT!,'agent-browser/SOURCE.json'),'utf8')).version,pinnedSha256:options.sha256,actualSha256:digest(readFileSync(options.executable))};
    }
    else if(message.command==='snapshot-race'){
      const page=browser.pages.get(taskId,message.pageId),mode=message.mode;
      if(!mode||!['once','continuous','aba'].includes(mode))throw Error('Unknown snapshot race mode');
      raceRestores.get(page.id)?.();
      const record:SnapshotRace={mode,pageId:page.id,iterations:[],captures:[],restored:false};snapshotRaces.push(record);
      const original=page.helper.command.bind(page.helper),capture=page.proxy.captureSnapshot.bind(page.proxy);
      page.proxy.captureSnapshot=()=>{
        const observed=capture();return {...observed,finish:()=>{
          record.captures.push(observed.trees.flatMap(tree=>tree.nodes.flatMap(node=>node.role?.value==='button'&&node.name?.value==='Action'&&node.backendDOMNodeId!==undefined?[node.backendDOMNodeId]:[])));
          observed.finish();
        }};
      };
      page.helper.command=async(args,options)=>{
        if(args[0]!=='snapshot')return original(args,options);
        const before=await actionBackend(page),index=record.iterations.length;
        if(mode!=='once'||index===0)await page.proxy.send('Runtime.evaluate',{expression:'(()=>{window.__raceOriginal=document.getElementById("action");const next=window.__raceOriginal.cloneNode(true);next.dataset.instance="race-"+String((window.__raceCount??0)+1);window.__raceCount=(window.__raceCount??0)+1;window.__raceOriginal.replaceWith(next)})()'});
        const helper=await actionBackend(page);
        try{return await original(args,options);}finally{
          if(mode==='aba')await page.proxy.send('Runtime.evaluate',{expression:'(()=>{document.getElementById("action").replaceWith(window.__raceOriginal);delete window.__raceOriginal})()'});
          record.iterations.push({before,helper,after:await actionBackend(page)});
        }
      };
      raceRestores.set(page.id,()=>{page.helper.command=original;page.proxy.captureSnapshot=capture;record.restored=true;raceRestores.delete(page.id);});
      value={installed:true,mode};
    }
    else if(message.command==='identity-diagnostics')value={races:snapshotRaces};
    else if(message.command==='identity-clear'){const page=browser.pages.get(taskId,message.pageId);raceRestores.get(page.id)?.();value={cleared:true};}
    else if(message.command==='identity-observe-guards'){
      const page=browser.pages.get(taskId,message.pageId),original=page.references.arm.bind(page.references);
      page.references.arm=async ref=>{const armed=await original(ref);return {...armed,finish:async()=>{const observed=await armed.finish();guardResponses.set(page.id,{result:{value:observed}});return observed;}};};
      value={observer:'read-only returned guard states, private fixture lifetime'};
    }
    else if (message.command === 'placement') {
      const page=browser.pages.get(taskId);
      if(!observedContents.has(page.view.webContents.id)){
        observedContents.add(page.view.webContents.id);
        // Read-only observation of the exact guard response. No commands, events or business outputs are changed.
        const original=page.view.webContents.debugger.sendCommand.bind(page.view.webContents.debugger);
        page.view.webContents.debugger.sendCommand=(method,params,sessionId)=>(sessionId?original(method,params,sessionId):original(method,params)).then(result=>{
          if(method==='Runtime.evaluate'&&params?.expression==='globalThis.__wyBrowserGuard.disarm()')guardResponses.set(page.id,result);
          return result;
        });
      }
      if(message.args?.[0]==='secondary'){
        if(!secondary){const otherTask=randomUUID();fixture.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(otherTask,'p1',fixture.cwd,'codex','[I] secondary task',1,1);const other=await browser.pages.create(otherTask,'p1');await browser.pages.navigate(other,page.view.webContents.getURL());secondary={taskId:otherTask,pageId:other.id};}
        await browser.pages.placement(secondary.taskId,secondary.pageId,{x:0,y:0,width:1000,height:700});
      }else await browser.pages.placement(taskId,page.id,{x:0,y:0,width:1000,height:700});
      value={placement:message.args?.[0]==='secondary'?'secondary-task-visible-primary-parked':'primary-mounted',primaryInMain:host.contentView.children.includes(page.view),primaryPageId:page.id,secondary};
    }
    else if (message.command === 'pause') { browser.pause(taskId,message.paused===true); value={paused:message.paused}; }
    else if (message.command === 'timing-events') value={events:timingEvents,operations:fixture.sqlite.prepare("SELECT request_id,created_at,rowid FROM browser_operations WHERE run_id=? AND command='eval' ORDER BY created_at,rowid").all(run.runId)};
    else if (message.command === 'park-config') {
      const page=browser.pages.get(taskId);
      const park=BrowserWindow.getAllWindows().find(window=>window.getTitle()==='WillYou browser background');
      if(!park)throw Error('Owned park window missing');
      park.setOpacity(message.opacity??0); park.setIgnoreMouseEvents(message.ignoreMouse!==false);
      await page.proxy.send('Emulation.setFocusEmulationEnabled',{enabled:message.focusEmulation===true});
      // Fault/diagnostic configuration only, never used as acceptance of the unchanged production environment.
      value={opacity:park.getOpacity(),ignoreMouse:message.ignoreMouse!==false,focusEmulation:message.focusEmulation===true};
    }
    else if (message.command === 'reset') { const page=browser.pages.get(taskId);await browser.pages.navigate(page,page.view.webContents.getURL());value={reset:true}; }
    else if (message.command === 'replace-next-arm') {
      const page=browser.pages.get(taskId),original=page.references.arm.bind(page.references);
      // Explicit race latch: replace the field after host identity check/arming, before the native fill path.
      page.references.arm=async ref=>{
        const armed=await original(ref);page.references.arm=original;
        await page.proxy.send('Runtime.evaluate',{expression:message.mode==='button'?'(()=>{const old=document.getElementById("action"),clone=old.cloneNode(true);clone.id="clone";old.replaceWith(clone)})()':message.mode==='new-button'?'(()=>{const old=document.getElementById("action"),next=document.createElement("button");next.id="action";next.textContent="Action";next.dataset.instance="new-button";old.replaceWith(next)})()':'(()=>{const old=document.getElementById("field"),clone=old.cloneNode(true);old.replaceWith(clone)})()'});
        return armed;
      };
      value={injected:message.mode==='button'?'one-shot post-arm button clone':'one-shot post-arm nonempty field clone'};
    }
    else if (message.command === 'clone') {
      const page=browser.pages.get(taskId); await page.proxy.send('Runtime.evaluate',{expression:'(()=>{const old=document.getElementById("action"),clone=old.cloneNode(true);clone.id="clone";old.replaceWith(clone)})()'}); value={injected:'same-name replacement before action'};
    }
    else if (message.command === 'close') {
      for (const child of children) child.kill('SIGKILL');
      await gateway.close(); await run.cli.exited();
      const helpers=browser.pages.list(taskId).map(page=>page.helper);
      await applications.dispose(); await browser.dispose();
      value={closed:true,helpers:helpers.map(helper=>helper.cleanup??{daemonState:'absent',clientStopped:true,socketFilesRemoved:true})};
      fixture.cleanup(); await Promise.all([new Promise<void>(ok=>server.close(()=>ok())),new Promise<void>(ok=>ipv6Server.close(()=>ok()))]); host.destroy();
    }
    else throw Error('Unknown fixture command');
    process.send?.({id:message.id,value}); if(message.command==='close') app.quit();
  } catch(error) { process.send?.({id:message.id,error:String(error instanceof Error?error.stack:error)}); }
});
app.on('window-all-closed',()=>{});
