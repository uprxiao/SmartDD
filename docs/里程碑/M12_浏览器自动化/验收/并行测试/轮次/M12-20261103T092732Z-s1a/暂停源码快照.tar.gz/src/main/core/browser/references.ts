import { randomBytes } from 'node:crypto';
import { BrowserCdpProxy, type BrowserAXNode } from './cdp-proxy';
import { BrowserHelper } from './agent-browser';
import { BROWSER_GUARD_SOURCE, BROWSER_GUARD_WORLD } from './action-guard';
import { staleReference, BrowserError } from './errors';

interface NodeRef { backendNodeId: number; frameId: string; sessionId?: string; role: string; name: string }
interface GuardState { blocked: string[]; accepted: string[]; connected: boolean }
export class BrowserReferences {
  private generation = 0;
  private refs = new Map<string, NodeRef>();
  private worlds = new Map<string, number>();
  constructor(private readonly proxy: BrowserCdpProxy, private readonly pageShort: string) {
    proxy.initializeFrames(session => this.initialize(session));
    proxy.onEvent(event => {
      if (event.method === 'Page.frameNavigated') this.invalidate();
      if (event.method === 'Runtime.executionContextCreated') {
        const context=event.params.context as {id:number;name:string;auxData?:{frameId?:string}};
        if(context?.name===BROWSER_GUARD_WORLD&&context.auxData?.frameId)this.worlds.set((event.sessionId??'')+'\0'+context.auxData.frameId,context.id);
      }
      if(event.method==='Runtime.executionContextsCleared')for(const key of this.worlds.keys())if(key.startsWith((event.sessionId??'')+'\0'))this.worlds.delete(key);
      if(event.method==='Runtime.executionContextDestroyed')for(const [key,id] of this.worlds)if(id===event.params.executionContextId&&key.startsWith((event.sessionId??'')+'\0'))this.worlds.delete(key);
    });
  }
  invalidate(): void { this.generation++; this.refs.clear(); }
  async initialize(sessionId?: string): Promise<void> {
    await this.proxy.send('Runtime.enable', {}, sessionId);
    await this.proxy.send('Page.addScriptToEvaluateOnNewDocument', { source: BROWSER_GUARD_SOURCE, worldName: BROWSER_GUARD_WORLD, runImmediately: true }, sessionId);
  }
  private async context(frameId: string, sessionId?: string): Promise<number> {
    await this.proxy.frameReady(sessionId);
    const context=this.worlds.get((sessionId??'')+'\0'+frameId);
    if(context===undefined)throw new BrowserError('BROWSER_UNAVAILABLE','页面的预先动作守卫尚未就绪');
    return context;
  }
  /** Capture the very AX responses consumed by the helper, not role/name samples before and after it. */
  async snapshot(helper: BrowserHelper, signal?: AbortSignal): Promise<unknown> {
    this.invalidate();
    const capture = this.proxy.captureSnapshot();
    let value: {snapshot:string;refs:Record<string,{role:string;name:string}>;origin?:string};
    try { value = await helper.command(['snapshot'],{signal}) as typeof value; } finally { capture.finish(); }
    if (!value || typeof value.snapshot !== 'string' || !value.refs || !capture.trees.length)
      throw new BrowserError('BROWSER_UNAVAILABLE','固定 helper 未提供可核对的原始无障碍树');
    const available = new Map<string,NodeRef[]>();
    for (const tree of capture.trees) {
      const frameId = tree.frameId ?? tree.nodes.find(node => node.frameId)?.frameId ??
        (await this.proxy.send<{frameTree:{frame:{id:string}}}>('Page.getFrameTree',{},tree.sessionId)).frameTree.frame.id;
      const byId = new Map(tree.nodes.map(node => [node.nodeId,node])), childIds = new Set(tree.nodes.flatMap(node=>node.childIds??[]));
      const ordered:BrowserAXNode[] = [], seen=new Set<string>();
      const visit=(node:BrowserAXNode):void=>{if(seen.has(node.nodeId))return;seen.add(node.nodeId);ordered.push(node);for(const id of node.childIds??[]){const child=byId.get(id);if(child)visit(child);}};
      for(const node of tree.nodes)if(!childIds.has(node.nodeId))visit(node);
      for(const node of tree.nodes)visit(node);
      for (const node of ordered) {
        if (node.ignored || !node.backendDOMNodeId || !node.role?.value) continue;
        const role = node.role.value, name = node.name?.value ?? '', key = role+'\0'+name;
        const entries = available.get(key) ?? [];
        if (!entries.some(entry => entry.backendNodeId === node.backendDOMNodeId && entry.sessionId === tree.sessionId))
          entries.push({backendNodeId:node.backendDOMNodeId,frameId,sessionId:tree.sessionId,role,name});
        available.set(key,entries);
      }
    }
    const counters = new Map<string,number>(), mapping = new Map<string,string>();
    const refs: {ref:string;role:string;name:string;available:boolean}[] = [];
    for (const [internal, metadata] of Object.entries(value.refs).sort(([a],[b])=>Number(a.slice(1))-Number(b.slice(1)))) {
      const key = metadata.role+'\0'+metadata.name, ordinal = counters.get(key) ?? 0;
      counters.set(key,ordinal+1);
      const node = available.get(key)?.[ordinal], external = '@'+this.pageShort+'s'+this.generation+internal;
      mapping.set(internal,external);
      if (node) this.refs.set(external,node);
      refs.push({ref:external,role:metadata.role,name:metadata.name,available:Boolean(node)});
    }
    const snapshot = value.snapshot.replace(/ref=(e\d+)/g,(_match,id:string)=>'ref='+(mapping.get(id)??id));
    return {origin:value.origin,snapshot,refs};
  }
  async arm(ref: string): Promise<{selector:string;node:NodeRef;finish:()=>Promise<GuardState>}> {
    const node = this.refs.get(ref); if (!node) throw staleReference();
    const contextId = await this.context(node.frameId,node.sessionId);
    const resolved = await this.proxy.send<{object:{objectId?:string}}>('DOM.resolveNode',{backendNodeId:node.backendNodeId,executionContextId:contextId},node.sessionId);
    const objectId = resolved.object.objectId; if (!objectId) throw staleReference();
    const armed = await this.proxy.send<{result:{value?:boolean};exceptionDetails?:unknown}>('Runtime.callFunctionOn',{
      objectId,functionDeclaration:'function(){return globalThis.__wyBrowserGuard?.arm(this) ?? false}',returnByValue:true,
    },node.sessionId);
    if (armed.result.value !== true) throw staleReference();
    const nonce = randomBytes(16).toString('hex');
    try {
      // Apply the locator attribute to the held object, never to a role/name re-resolution.
      await this.proxy.send('Runtime.callFunctionOn',{objectId,functionDeclaration:'function(value){this.setAttribute("data-willyou-ref",value)}',arguments:[{value:nonce}]},node.sessionId);
    } catch(error) { await this.disarm(node,contextId,objectId).catch(()=>{}); throw error; }
    return {selector:`[data-willyou-ref="${nonce}"]`,node,finish:()=>this.disarm(node,contextId,objectId)};
  }
  private async disarm(node:NodeRef,contextId:number,objectId:string):Promise<GuardState> {
    try {
      const result = await this.proxy.send<{result:{value:GuardState}}>('Runtime.evaluate',{expression:'globalThis.__wyBrowserGuard.disarm()',contextId,returnByValue:true},node.sessionId);
      return result.result.value;
    } finally {
      await this.proxy.send('Runtime.callFunctionOn',{objectId,functionDeclaration:'function(){this.removeAttribute("data-willyou-ref")}'},node.sessionId).catch(()=>{});
      await this.proxy.send('Runtime.releaseObject',{objectId},node.sessionId).catch(()=>{});
    }
  }
}
