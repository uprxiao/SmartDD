import { BrowserError } from './errors';

/** One queue per page. Admission runs twice so queued work cannot retain revoked authority. */
export class BrowserPageQueue {
  private tail: Promise<unknown> = Promise.resolve();
  private closed = false;
  run<T>(admit: () => void, work: () => Promise<T>, signal?: AbortSignal): Promise<T> {
    const check = () => {
      if (this.closed) throw new BrowserError('BROWSER_TAB_CLOSED', '网页已经关闭');
      if (signal?.aborted) throw signal.reason ?? new BrowserError('BROWSER_ERROR', '操作已取消');
      admit();
    };
    try { check(); } catch (error) { return Promise.reject(error); }
    const result = this.tail.then(async () => { check(); return work(); });
    this.tail = result.catch(() => {});
    return result;
  }
  close(): void { this.closed = true; }
  async settled(): Promise<void> { await this.tail; }
}
