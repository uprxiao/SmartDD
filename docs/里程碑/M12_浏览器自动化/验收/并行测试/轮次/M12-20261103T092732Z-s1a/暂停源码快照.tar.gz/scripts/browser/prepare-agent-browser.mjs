import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync, chmodSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { tmpdir } from 'node:os';

const version = '0.27.3', archiveHash = '732f8416363917f2696ef318972c479b79ca778cb2d2e5c2294952df86baca59';
const url = `https://registry.npmjs.org/agent-browser/-/agent-browser-${version}.tgz`;
const destination = resolve(process.argv[2] ?? 'out/agent-browser');
const scratch = mkdtempSync(join(tmpdir(),'wy-agent-browser-source-'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
try {
  const archive = join(scratch,'source.tgz');
  execFileSync('curl',['--fail','--location','--silent','--show-error',url,'--output',archive],{timeout:60000});
  if (hash(readFileSync(archive)) !== archiveHash) throw Error('agent-browser source archive hash mismatch');
  execFileSync('tar',['-xzf',archive,'-C',scratch],{timeout:10000});
  const source = join(scratch,'package'), manifest = JSON.parse(readFileSync(join(source,'package.json'),'utf8'));
  if (manifest.name !== 'agent-browser' || manifest.version !== version) throw Error('agent-browser version mismatch');
  const files = [];
  for (const arch of ['arm64','x64']) {
    const binary = readFileSync(join(source,'bin',`agent-browser-darwin-${arch}`)), folder = join(destination,arch);
    mkdirSync(folder,{recursive:true}); writeFileSync(join(folder,'agent-browser'),binary); chmodSync(join(folder,'agent-browser'),0o755);
    files.push({arch,source:`package/bin/agent-browser-darwin-${arch}`,path:`${arch}/agent-browser`,sha256:hash(binary),bytes:binary.length});
    for (const name of ['skills','skill-data']) cpSync(join(source,name),join(folder,name),{recursive:true});
  }
  mkdirSync(destination,{recursive:true});
  cpSync(join(source,'LICENSE'),join(destination,'LICENSE'));
  const metadata = {schema:1,package:'agent-browser',version,url,archiveSha256:archiveHash,files};
  writeFileSync(join(destination,'SOURCE.json'),JSON.stringify(metadata,null,2)+'\n');
  const pinned = resolve('resources/agent-browser/SOURCE.json');
  let previous; try { previous = readFileSync(pinned,'utf8'); } catch {}
  const bytes = JSON.stringify(metadata,null,2)+'\n';
  if (previous && previous !== bytes) throw Error('agent-browser pinned executable hashes changed');
  if (!previous) writeFileSync(pinned,bytes);
  console.log(JSON.stringify({destination,version,files}));
} finally { rmSync(scratch,{recursive:true,force:true}); }
