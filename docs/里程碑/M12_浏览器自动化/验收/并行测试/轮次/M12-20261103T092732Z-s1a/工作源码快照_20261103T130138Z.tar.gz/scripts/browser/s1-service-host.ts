// I-level composition. Real service/module/CLI/gateway/SQLite/kernel peers; controlled run root and synthetic website.
import { app, BrowserWindow } from 'electron';
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import type { CapabilitySessionSnapshot } from '../../src/shared/application-session';
import { capabilitySessionSnapshotV3Schema } from '../../src/shared/application-session-v3';
import { applicationNativeSkillName } from '../../src/shared/application-session';
import { applicationToolDeclarations } from '../../src/shared/application-capabilities';
import * as schema from '../../src/main/db/schema';
import { SecretsStore } from '../../src/main/secrets';
import { ProjectService } from '../../src/main/core/projects/project-service';
import { agentFixture } from '../../src/main/core/applications/__tests__/agent-fixture';
import { BrowserService } from '../../src/main/core/browser/service';
import { CapabilityBundleSource } from '../../src/main/core/applications/bundle-source';
import { BuiltinPackageRegistry } from '../../src/main/core/applications/builtin-package-registry';
import { RuntimeRegistry } from '../../src/main/core/applications/runtime-registry';
import { ApplicationService } from '../../src/main/core/applications/application-service';
import { ApplicationToolService } from '../../src/main/core/applications/tool-service';
import { ApplicationAdapterRegistry } from '../../src/main/core/applications/application-adapter-registry';
import { CapabilityRunRegistry } from '../../src/main/core/applications/run-registry';
import { createApplicationRunPlan } from '../../src/main/core/applications/run-plan';
import { applicationSkillContentHash } from '../../src/main/core/applications/session-registry';
import { MacProcessIdentityReader } from '../../src/main/core/applications/process-identity';
import { MacUnixPeerIdentityReader } from '../../src/main/core/applications/unix-peer-identity';
import { ApplicationCliGateway } from '../../src/main/core/applications/cli-gateway';
import { digest } from '../../src/main/core/applications/manifest';

for (const event of ['uncaughtException','unhandledRejection'] as const) process.on(event,error => {
  process.send?.({ fatal:String(error instanceof Error ? error.stack : error) }); app.exit(1);
});
let browser: BrowserService, applications: ApplicationService, gateway: ApplicationCliGateway;
let fixture: Awaited<ReturnType<typeof agentFixture>>, run: Awaited<ReturnType<CapabilityRunRegistry['reserve']>>;
let host: BrowserWindow, taskId: string, environment: NodeJS.ProcessEnv, binary: string;
let secondary: {taskId:string;pageId:string}|undefined;
const guardResponses=new Map<string,unknown>(),observedContents=new Set<number>();
const children = new Set<ReturnType<typeof spawn>>();
const timingEvents:{label:string|null;phase:string|null;at:number}[]=[];
const server = createServer((request,response) => {
  const url=new URL(request.url??'/','http://127.0.0.1');
  if(url.pathname==='/event'){
    timingEvents.push({label:url.searchParams.get('label'),phase:url.searchParams.get('phase'),at:performance.now()});
    response.setHeader('content-type','application/json');response.end('{"received":true}');return;
  }
  response.setHeader('content-type','text/html;charset=utf-8');
  response.end('<title>[I] S1 real native CLI</title><form><button type="button" id="action">Action</button><input id="field" aria-label="Input"><div contenteditable role="textbox" aria-label="Editor"></div><select aria-label="Choice"><option>A</option><option>B</option></select><input type="checkbox" aria-label="Check"><input type="file" aria-label="Upload"></form><div style="height:3000px">Long page</div><script>window.hits=[];window.addEventListener("click",e=>hits.push(e.target.id),true);window.delayedStep=async function(label){await fetch("/event?phase=start&label="+encodeURIComponent(label));await new Promise(resolve=>setTimeout(resolve,2000));await fetch("/event?phase=end&label="+encodeURIComponent(label));return label;}</script>');
});
app.whenReady().then(async () => {
  const resources = process.env.M12_RESOURCE_ROOT!;
  const source = new CapabilityBundleSource(join(resources,'capability-bundles'));
  fixture = await agentFixture();
  const processes = new MacProcessIdentityReader(join(resources,'native/willyou-process-identity'));
  const helperSource = JSON.parse(readFileSync(join(resources,'agent-browser/SOURCE.json'),'utf8'));
  const helperFile = helperSource.files.find((file:{arch:string}) => file.arch === process.arch);
  host = new BrowserWindow({show:false,focusable:false,skipTaskbar:true,width:1000,height:700,title:'[I] S1 isolated native CLI host',webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  await host.loadURL('data:text/html,<title>[I] S1 controlled run host</title>'); host.showInactive();
  browser = new BrowserService({userData:app.getPath('userData'),sqlite:fixture.sqlite,helper:{executable:join(resources,'agent-browser',process.arch,'agent-browser'),sha256:helperFile.sha256,processes},window:()=>host,taskProject:id => {
    const row = fixture.sqlite.prepare('SELECT project_id FROM tasks WHERE id=?').get(id) as {project_id:string}|undefined;
    return row?.project_id ?? null;
  }});
  await new RuntimeRegistry(fixture.store).install(source.runtime());
  const trusted = new BuiltinPackageRegistry(fixture.store), entry = source.index.apps.find(item => item.appId === 'browser');
  if (!entry) throw Error('Frozen browser package missing');
  const installed = await trusted.install(source,entry), manifest = installed.manifest;
  if (manifest.schema !== 'smartdd-app-package-v2') throw Error('Browser v2 package required');
  await trusted.packages.activate(installed.packageHash,trusted.packages.active('browser')?.generation ?? 0);
  const db = drizzle(fixture.sqlite,{schema});
  // No connections or credentials exist; this codec is unused by browser calls.
  const secrets = new SecretsStore(db,{isAvailable:()=>true,encrypt:value=>Buffer.from(value),decrypt:value=>value.toString()});
  applications = new ApplicationService(fixture.store,{secrets,projects:new ProjectService(db,secrets),tasks:{stopProject:async()=>true,runningInProject:()=>0},requireSender:()=>{},mailWorker:join(fixture.root,'unused-mail-worker'),foxmailNative:join(fixture.root,'unused-native-mail'),processes,browser});
  await applications.recover(); await applications.selections.setAdded('browser',true,0);
  await applications.selections.select({projectId:'p1',appId:'browser',enabled:true,expectedRevision:0,connections:{}});
  const base = fixture.plan('codex'), adapter = fixture.installedAdapters.find(item => item.metadata.agentId === 'codex' && item.metadata.version === '1.2.0');
  if (!adapter) throw Error('Frozen adapter missing');
  taskId = base.taskId;
  fixture.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(taskId,'p1',fixture.cwd,'codex','[I] S1 synthetic task',1,1);
  const snapshot:CapabilitySessionSnapshot = {...base,schema:3,agentAtCreation:{version:'0.166.0',adapterRevision:1},adapterBinding:{id:'codex',version:adapter.metadata.version,hash:adapter.hash,projectionFormatVersion:1,nativeToolNames:{}},packages:[{
    appId:'browser',version:manifest.version,packageHash:installed.packageHash,hashAlgorithm:'app-manifest-v1',hostApi:manifest.hostApi,dataApi:manifest.dataApi,runtimeHash:manifest.runtime.hash,toolContractMajors:Object.fromEntries(applicationToolDeclarations(manifest).map(tool=>[tool.name,tool.contractMajor])),capabilityContractMajors:Object.fromEntries(manifest.capabilities.map(capability=>[capability.id,capability.contractMajor])),entry:'cli',bindings:[],allowedOperations:manifest.permissions,
    skills:manifest.skills.map(skill => {const nativeName=applicationNativeSkillName('browser',skill.id,installed.packageHash);return {skillId:skill.id,nativeName,contentHash:applicationSkillContentHash(manifest,skill.path),sourceRelativePath:skill.path,projectionPath:join(fixture.home,'.agents/skills',nativeName,'SKILL.md')};}),
  }],mcp:base.mcp.filter(item=>item.kind!=='applications')};
  const checked = capabilitySessionSnapshotV3Schema.safeParse(snapshot);
  if (!checked.success) throw Error('Fixture snapshot validation: '+JSON.stringify(checked.error.issues));
  const session = await fixture.sessions.create(checked.data,fixture.home);
  const runs = new CapabilityRunRegistry(fixture.store,fixture.sessions,{processes,assertCurrent:()=>{},revoke:()=>{},createPlan:(selected,hash,runId)=>createApplicationRunPlan({runId,snapshot:selected,snapshotHash:hash,applications:[{manifest,packageHash:installed.packageHash,capabilities:manifest.capabilities}],skills:[],available:{mcp:true,cli:true}})});
  applications.attachRuns(runs); run = await runs.reserve({taskId,snapshotHash:session.pointer.snapshotHash,bindings:[]});
  await run.prepare(); await run.cli.arm(); await run.cli.attach(process.pid);
  const tools = new ApplicationToolService(fixture.store,runs,new ApplicationAdapterRegistry(fixture.store,applications.data),{entry:'cli',retryDelays:[0,0]});
  binary = resolve(resources,'native/willyou-app');
  gateway = new ApplicationCliGateway(runs,tools,new MacUnixPeerIdentityReader(join(resources,'native/willyou-process-identity')),{executable:{path:binary,sha256:digest(readFileSync(binary))}});
  await gateway.start(); environment = {...gateway.issue(run).environment};
  await new Promise<void>(ok=>server.listen(0,'127.0.0.1',ok)); const address=server.address(); if (!address || typeof address==='string') throw Error('Fixture HTTP bind');
  process.send?.({ready:true,pid:process.pid,taskId,runId:run.runId,url:`http://127.0.0.1:${address.port}/`,versions:process.versions,boundary:'I: real BrowserService/M11 module/CLI/gateway/SQLite/kernel peers; controlled Electron process as run root; synthetic page; not packaged App or real Agent'});
}).catch(error=>{process.send?.({fatal:String(error.stack??error)});app.exit(1);});

process.on('message',async (message:{id:number;command:string;args?:string[];input?:string;paused?:boolean;expression?:string;opacity?:number;ignoreMouse?:boolean;focusEmulation?:boolean}) => {
  try {
    let value:unknown;
    if (message.command === 'cli') value = await new Promise(resolve => {
      const child=spawn(binary,message.args!,{env:environment,stdio:[message.input===undefined?'ignore':'pipe','pipe','pipe']}); children.add(child);
      if (message.input!==undefined) child.stdin!.end(message.input);
      let stdout='',stderr='',timedOut=false;
      const timer=setTimeout(()=>{timedOut=true;child.kill('SIGKILL');},105000);
      child.stdout!.on('data',chunk=>stdout+=chunk);child.stderr!.on('data',chunk=>stderr+=chunk);
      child.on('close',(code,signal)=>{clearTimeout(timer);children.delete(child);resolve({code,signal,stdout,stderr,timedOut});});
    });
    else if (message.command === 'observe') {
      const page=browser.pages.get(taskId);
      value={...(await page.proxy.send<{result:{value:{hits:string[];value:string;url:string}}}>('Runtime.evaluate',{expression:'({hits:window.hits,value:document.getElementById("field").value,url:location.href})',returnByValue:true})).result.value,rect:page.view.getBounds(),guardResponse:guardResponses.get(page.id)};
    }
    else if (message.command === 'placement') {
      const page=browser.pages.get(taskId);
      if(!observedContents.has(page.view.webContents.id)){
        observedContents.add(page.view.webContents.id);
        // Read-only observation of the exact guard response. No commands, events or business outputs are changed.
        const original=page.view.webContents.debugger.sendCommand.bind(page.view.webContents.debugger);
        page.view.webContents.debugger.sendCommand=(method,params,sessionId)=>(sessionId?original(method,params,sessionId):original(method,params)).then(result=>{
          if(method==='Runtime.evaluate'&&params?.expression==='globalThis.__wyBrowserGuard.disarm()')guardResponses.set(page.id,result);
          return result;
        });
      }
      if(message.args?.[0]==='secondary'){
        if(!secondary){const otherTask=randomUUID();fixture.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?)').run(otherTask,'p1',fixture.cwd,'codex','[I] secondary task',1,1);const other=await browser.pages.create(otherTask,'p1');await browser.pages.navigate(other,page.view.webContents.getURL());secondary={taskId:otherTask,pageId:other.id};}
        await browser.pages.placement(secondary.taskId,secondary.pageId,{x:0,y:0,width:1000,height:700});
      }else await browser.pages.placement(taskId,page.id,{x:0,y:0,width:1000,height:700});
      value={placement:message.args?.[0]==='secondary'?'secondary-task-visible-primary-parked':'primary-mounted',primaryInMain:host.contentView.children.includes(page.view),primaryPageId:page.id,secondary};
    }
    else if (message.command === 'pause') { browser.pause(taskId,message.paused===true); value={paused:message.paused}; }
    else if (message.command === 'timing-events') value={events:timingEvents,operations:fixture.sqlite.prepare("SELECT request_id,created_at,rowid FROM browser_operations WHERE run_id=? AND command='eval' ORDER BY created_at,rowid").all(run.runId)};
    else if (message.command === 'park-config') {
      const page=browser.pages.get(taskId);
      const park=BrowserWindow.getAllWindows().find(window=>window.getTitle()==='WillYou browser background');
      if(!park)throw Error('Owned park window missing');
      park.setOpacity(message.opacity??0); park.setIgnoreMouseEvents(message.ignoreMouse!==false);
      await page.proxy.send('Emulation.setFocusEmulationEnabled',{enabled:message.focusEmulation===true});
      // Fault/diagnostic configuration only, never used as acceptance of the unchanged production environment.
      value={opacity:park.getOpacity(),ignoreMouse:message.ignoreMouse!==false,focusEmulation:message.focusEmulation===true};
    }
    else if (message.command === 'reset') { const page=browser.pages.get(taskId);await browser.pages.navigate(page,page.view.webContents.getURL());value={reset:true}; }
    else if (message.command === 'replace-next-arm') {
      const page=browser.pages.get(taskId),original=page.references.arm.bind(page.references);
      // Explicit race latch: replace the field after host identity check/arming, before the native fill path.
      page.references.arm=async ref=>{
        const armed=await original(ref);page.references.arm=original;
        await page.proxy.send('Runtime.evaluate',{expression:'(()=>{const old=document.getElementById("field"),clone=old.cloneNode(true);old.replaceWith(clone)})()'});
        return armed;
      };
      value={injected:'one-shot post-arm nonempty field clone'};
    }
    else if (message.command === 'clone') {
      const page=browser.pages.get(taskId); await page.proxy.send('Runtime.evaluate',{expression:'(()=>{const old=document.getElementById("action"),clone=old.cloneNode(true);clone.id="clone";old.replaceWith(clone)})()'}); value={injected:'same-name replacement before action'};
    }
    else if (message.command === 'close') {
      for (const child of children) child.kill('SIGKILL');
      await gateway.close(); await run.cli.exited();
      const helpers=browser.pages.list(taskId).map(page=>page.helper);
      await applications.dispose(); await browser.dispose();
      value={closed:true,helpers:helpers.map(helper=>helper.cleanup??{daemonState:'absent',clientStopped:true,socketFilesRemoved:true})};
      fixture.cleanup(); await new Promise<void>(ok=>server.close(()=>ok())); host.destroy();
    }
    else throw Error('Unknown fixture command');
    process.send?.({id:message.id,value}); if(message.command==='close') app.quit();
  } catch(error) { process.send?.({id:message.id,error:String(error instanceof Error?error.stack:error)}); }
});
app.on('window-all-closed',()=>{});
