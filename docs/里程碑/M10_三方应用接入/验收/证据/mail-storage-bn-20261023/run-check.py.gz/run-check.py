import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CANDIDATE = ROOT / 'candidate'
tag, kind = sys.argv[1:3]
base = json.loads((ROOT / 'baseline-inputs.json').read_text())
paths = {row['path'] for row in base['files']}
for folder in ('src', 'drizzle'):
    paths.update(str(path.relative_to(CANDIDATE)) for path in (CANDIDATE / folder).rglob('*') if path.is_file())

def observe():
    result = []
    for name in sorted(paths):
        data = (CANDIDATE / name).read_bytes()
        result.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    return result

before = observe()
base_hashes = {row['path']: row['sha256'] for row in base['files']}
for row in before:
    if base_hashes.get(row['path']) != row['sha256']:
        destination = ROOT / (tag + '-source') / row['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CANDIDATE / row['path'], destination)
(ROOT / (tag + '-inputs.json')).write_text(json.dumps({'parent': base['parent'], 'files': before}, indent=2) + '\n')
command = ['pnpm', 'typecheck'] if kind == 'types' else ['pnpm', 'test', *sys.argv[3:], '--maxWorkers=1', '--testTimeout=15000', '--reporter=verbose', '--reporter=json', '--outputFile=' + str(ROOT / (tag + '-report.json'))]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (ROOT / (tag + '.txt')).open('wb') as output:
    completed = subprocess.run(command, cwd=CANDIDATE, stdout=output, stderr=subprocess.STDOUT)
after = observe()
result = {'command': command, 'startedAt': started, 'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': completed.returncode, 'inputCount': len(before), 'inputsUnchanged': before == after}
(ROOT / (tag + '-result.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
sys.exit(completed.returncode if before == after else 97)
