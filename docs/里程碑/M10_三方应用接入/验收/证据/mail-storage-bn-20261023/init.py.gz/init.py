from pathlib import Path
import hashlib,json,shutil,subprocess
c=Path('/Users/liubu/Documents/ChatGPT/SmartDD-m10');e=Path(__file__).resolve().parent;w=e/'candidate'
assert not w.exists()
b=json.loads(Path('/private/tmp/m10-extension-call-bm-20261023/final-inputs.json').read_text())
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c).decode().strip();assert parent=='b54175b97591d43d4d5c1d0eda585a17147ce2b1'
for row in b['files']:
 data=(c/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 target=w/row['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(e/'baseline-inputs.json').write_text(json.dumps({'parent':parent,'files':b['files']},indent=2)+'\n')
for name in ['node_modules','out']:(w/name).symlink_to(Path('/private/tmp/m10-legacy-recovery-r-20261021/work-r4')/name,target_is_directory=True)
shutil.copyfile('/private/tmp/m10-extension-call-bm-20261023/preserved-worktree.json',e/'preserved-worktree.json')
shutil.copyfile('/private/tmp/m10-extension-call-bm-20261023/run-check.py',e/'run-check.py')
print('private BN candidate ready;2022 baseline inputs;no install/rebuild/App')
