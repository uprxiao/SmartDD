// P layer only. Reuse the actual Electron driver as an isolated browser carrier
// and serve the shared prototype source so its existing read-only model exports
// remain available. Nothing here prepares or mutates M10 business state.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:net';
import {readFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {openElectron,pause} from './electron-harness.mjs';
import {installAppFocusGuard} from './app-focus-guard.mjs';
import {openHeadlessBrowser} from './headless-browser-harness.mjs';

export async function openPrototypeSource({executable,headlessBrowser,root,record,route='apps'}){
 const prototypeRoot=resolve('prototypes/m6-codex');
 const sources=['src/App.jsx','src/IntegrationWorkspace.jsx','src/IntegrationPackageUI.jsx','src/integration-model.mjs','src/integration.css','package.json','package-lock.json'];
 const sourceHashes=async()=>Object.fromEntries(await Promise.all(sources.map(async name=>[name,createHash('sha256').update(await readFile(join(prototypeRoot,name))).digest('hex')])));
 const before=await sourceHashes();record.prototypeSources=before;record.layer='P: shared synthetic prototype source in a private Electron browser; not packaged product business';
 const listener=createServer();await new Promise(r=>listener.listen(0,'127.0.0.1',r));const port=listener.address().port;await new Promise(r=>listener.close(r));
 const origin='http://127.0.0.1:'+port;
 const vite=spawn(process.execPath,[join(prototypeRoot,'node_modules/vite/bin/vite.js'),'--host','127.0.0.1','--port',String(port),'--strictPort'],{cwd:prototypeRoot,env:process.env,stdio:['ignore','pipe','pipe']});
 let logs='',app;vite.stdout.on('data',b=>{logs+=b;});vite.stderr.on('data',b=>{logs+=b;});
 record.prototypeServer={pid:vite.pid,origin};record.requests=[];
 const stopServer=async()=>{if(vite.exitCode===null&&vite.signalCode===null){const done=new Promise(r=>vite.once('exit',r));vite.kill('SIGTERM');await Promise.race([done,pause(3000)]);if(vite.exitCode===null&&vite.signalCode===null) vite.kill('SIGKILL');}};
 try{
  const end=Date.now()+20000;let ready=false;
  while(Date.now()<end){if(vite.exitCode!==null)throw Error('Owned prototype server exited');if(logs.includes(origin)){try{ready=(await fetch(origin)).ok;}catch{}}if(ready)break;await pause(50);}
  assert(ready,'Owned prototype source server did not become ready');
  if(headlessBrowser){
   app=await openHeadlessBrowser({executable:headlessBrowser,userData:join(root,'browser-profile')});
   record.browser={mode:'independent headless Chromium',executable:headlessBrowser,pid:app.processId,version:app.version,systemWindow:false,nativePermissionOrFocusCoverage:false};
  }else{app=await openElectron({executable,userData:join(root,'userdata')});installAppFocusGuard(app,record);}
  await app.cdp('Network.enable');app.onCDP('Network.requestWillBeSent',e=>record.requests.push({url:e.request.url,method:e.request.method}));
  await app.cdp('Page.navigate',{url:origin+'/?preview=m10#'+route});
  await app.waitFor(`!!document.querySelector('.m10-shell')`,20000);
  await app.evaluate(`document.title='P · M10 · synthetic prototype forms';true`);
  return {app,origin,logs:()=>logs,assertSourcesUnchanged:async()=>assert.deepEqual(await sourceHashes(),before),close:async()=>{try{await app.close();}finally{await stopServer();}}};
 }catch(error){if(app)await app.close();await stopServer();throw error;}
}

export function prototypeInput(app,record){
 const lookup=(selector,text)=>`[...document.querySelectorAll(${JSON.stringify(selector)})].find(e=>e.getBoundingClientRect().width&&e.getBoundingClientRect().height${text===undefined?'':`&&e.textContent.trim()===${JSON.stringify(text)}`})`;
 const key=async(key,code,num,{modifiers=0,commands}={})=>{for(const type of ['keyDown','keyUp'])await app.cdp('Input.dispatchKeyEvent',{type,key,code,windowsVirtualKeyCode:num,modifiers,...(type==='keyDown'&&commands?{commands}:{})});};
 const click=async(selector,text)=>{
  record.lastAction={type:'click',selector,text};const get=()=>app.evaluate(`(()=>{const e=${lookup(selector,text)};if(!e||e.matches(':disabled,[aria-disabled="true"],[data-disabled]'))throw Error('Prototype control not ready');e.scrollIntoView({block:'nearest'});const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;if(!e.contains(document.elementFromPoint(x,y)))throw Error('Prototype control blocked');return{x,y};})()`);
  await get();await app.evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');const point=await get();
  for(const type of ['mouseMoved','mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,...(type==='mouseMoved'?{}:{button:'left',clickCount:1})});
 };
 const fill=async(selector,text)=>{await click(selector);await key('a','KeyA',65,{modifiers:4,commands:['selectAll']});if(text)await app.cdp('Input.insertText',{text});else await key('Backspace','Backspace',8);assert.equal(await app.evaluate(`document.querySelector(${JSON.stringify(selector)}).value`),text);};
 const choose=async(selector,index)=>{
  record.lastAction={type:'select',selector,index};
  let focused=false;for(let i=0;i<80;i++){focused=await app.evaluate(`document.activeElement?.matches(${JSON.stringify(selector)})`);if(focused)break;await key('Tab','Tab',9);}
  assert(focused,'Native select did not receive real Tab focus');
  await key('Home','Home',36);for(let i=0;i<index;i++)await key('ArrowDown','ArrowDown',40);await key('Enter','Enter',13);await key('Tab','Tab',9);
  const actual=await app.evaluate(`document.querySelector(${JSON.stringify(selector)}).selectedIndex`);record.selections??=[];record.selections.push({selector,index,actual});assert.equal(actual,index,'Native select keyboard input did not commit the requested option');
 };
 const has=text=>app.waitFor(`(document.body?.innerText??'').includes(${JSON.stringify(text)})`,12000);
 return {click,key,fill,choose,has};
}
