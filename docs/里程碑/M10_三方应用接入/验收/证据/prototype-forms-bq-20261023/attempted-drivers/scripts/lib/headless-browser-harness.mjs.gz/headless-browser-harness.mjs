// Synthetic prototype/browser layer only. Creates an independent headless
// Chromium profile and no macOS window. Never attaches to a daily browser or
// the packaged App; cannot validate native permissions, IME or system focus.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:net';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pause} from './electron-harness.mjs';

export async function openHeadlessBrowser({executable,userData}){
 await mkdir(userData,{recursive:true});
 const listener=createServer();await new Promise(r=>listener.listen(0,'127.0.0.1',r));const port=listener.address().port;await new Promise(r=>listener.close(r));
 const child=spawn(resolve(executable),['--headless=new',`--user-data-dir=${resolve(userData)}`,'--remote-debugging-address=127.0.0.1',`--remote-debugging-port=${port}`,'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-extensions','about:blank'],{env:process.env,stdio:['ignore','pipe','pipe']});
 let logs='',ws;child.stdout.on('data',b=>{logs+=b;});child.stderr.on('data',b=>{logs+=b;});
 const stop=async()=>{if(child.exitCode===null&&child.signalCode===null){const done=new Promise(r=>child.once('exit',r));child.kill('SIGTERM');await Promise.race([done,pause(3000)]);if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');}};
 try{
  let page;const deadline=Date.now()+20000;
  while(Date.now()<deadline){
   if(child.exitCode!==null)throw Error('Owned headless browser exited before readiness');
   if(logs.includes(`127.0.0.1:${port}`))try{page=(await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()).find(x=>x.type==='page');}catch{}
   if(page)break;await pause(50);
  }
  assert(page,'Owned headless prototype browser did not become ready');
  ws=new WebSocket(page.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
  let seq=0;const pending=new Map(),listeners=new Map(),rendererErrors=[];
  ws.addEventListener('message',({data})=>{
   const m=JSON.parse(data);
   if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}}
   if(m.method==='Runtime.exceptionThrown')rendererErrors.push(m.params.exceptionDetails.text);
   for(const listener of listeners.get(m.method)??[])listener(m.params);
  });
  const cdp=(method,params={},timeout=25000)=>new Promise((resolve,reject)=>{const id=++seq,timer=setTimeout(()=>{pending.delete(id);reject(Error('Headless prototype '+method+' timed out'));},timeout);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});
  const evaluate=async(expression,timeout)=>{const r=await cdp('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true},timeout);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;};
  const waitFor=async(expression,timeout=10000)=>{const end=Date.now()+timeout;while(Date.now()<end){if(await evaluate(expression))return;await pause(50);}throw Error('Headless prototype state wait timed out');};
  await cdp('Runtime.enable');await cdp('Page.enable');await cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});await cdp('Page.bringToFront');
  const version=await cdp('Browser.getVersion');
  return {cdp,evaluate,waitFor,processId:child.pid,rendererErrors,version,logs:()=>logs,
   onCDP:(method,fn)=>{const rows=listeners.get(method)??new Set();rows.add(fn);listeners.set(method,rows);return()=>rows.delete(fn);},
   screenshot:async path=>{const r=await cdp('Page.captureScreenshot',{format:'png'});await writeFile(path,Buffer.from(r.data,'base64'));},
   close:async()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Owned prototype browser closed'));}pending.clear();ws.close();listeners.clear();await stop();}};
 }catch(error){ws?.close();await stop();throw error;}
}
