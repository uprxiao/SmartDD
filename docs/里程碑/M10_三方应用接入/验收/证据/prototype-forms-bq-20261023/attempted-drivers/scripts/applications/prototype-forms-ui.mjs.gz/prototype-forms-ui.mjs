// Formal P-layer form/storage checks. All M10 edits/tests/saves/cancels go
// through actual pointer/keyboard input. Storage and exported terminal snapshots
// are read-only assertions; unrelated M9 width data is a declared prerequisite.
import assert from 'node:assert/strict';
import {mkdtemp,readFile,writeFile} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {openPrototypeSource,prototypeInput} from '../lib/prototype-source-harness.mjs';

const executable=process.env.WILLYOU_ACCEPTANCE_APP,headlessBrowser=process.env.M10_PROTOTYPE_HEADLESS==='1'?(process.env.M10_BROWSER??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'):undefined;assert(executable||headlessBrowser);
const wanted=new Set((process.env.M10_PROTOTYPE_CASES??'T27,T29,T32').split(','));
const root=await mkdtemp('/private/tmp/willyou-m10-prototype-forms-');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const result={schema:'m10-prototype-forms-v1',startedAt:new Date().toISOString(),root,
 branch:execFileSync('git',['branch','--show-current'],{encoding:'utf8'}).trim(),sourceBase:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),
 carrier:headlessBrowser?{type:'independent headless Chromium, P only',executable:headlessBrowser,packagedAppLaunched:false}:{executable:resolve(executable),asarSha256:sha(await readFile(resolve(dirname(executable),'../Resources/app.asar')))},
 boundary:'P only, synthetic configuration and secret canary. No production credentials, native keychain, real service authentication or actual Claude/Codex claimed.',
 checks:[],cases:Object.fromEntries([...wanted].map(id=>[id,{status:'pending'}])),status:'running'};
let harness,app,ui,stage='setup',caseId;
const check=(name,details={})=>result.checks.push({caseId,name,...details,at:new Date().toISOString(),passed:true});
const state=()=>app.evaluate(`JSON.parse(localStorage.getItem('willyou-m10-prototype-v2'))`);
const openAdd=async()=>{await ui.click('.m10-app-heading button','添加连接');await app.waitFor(`!!document.querySelector('dialog[open] input[aria-label="连接名称"]')`);};
const close=async(method='cancel')=>{if(method==='escape')await ui.key('Escape','Escape',27);else await ui.click('dialog button','取消');await app.waitFor(`!document.querySelector('dialog[open]')`);};
const ready=()=>ui.has('演示检查通过，可保存配置');
const test=async()=>{await ui.click('dialog button','测试连接');await ready();};
async function go(appId){
 if(await app.evaluate('location.hash')==='#apps/'+appId)return;
 if(await app.evaluate(`!!document.querySelector('.m10-back')`))await ui.click('.m10-back','全部应用');
 else await ui.click('.m10-sidebar .m10-nav','应用');
 await app.waitFor(`!!document.querySelector('.m10-catalog-open')`);
 await ui.click(`.m10-catalog-item:${appId==='zentao'?'first':'last'}-child .m10-catalog-open`);
 await app.waitFor(`location.hash==='#apps/${appId}'&&!!document.querySelector('.m10-app-heading')`);
}
async function edit(name){await ui.click('button[aria-label='+JSON.stringify('管理'+name)+']');await ui.click('.m10-menu button','编辑／重新连接');await app.waitFor(`!!document.querySelector('dialog[open] input[aria-label="连接名称"]')`);}
async function reload(){const old=await app.evaluate('performance.timeOrigin');await app.cdp('Page.reload');await app.waitFor(`performance.timeOrigin!==${old}&&!!document.querySelector('.m10-shell')`,20000);await app.evaluate(`document.title='P · M10 · synthetic prototype forms';true`);}
async function zenValues(secret,name='BQ synthetic connection'){
 await ui.fill('[aria-label="连接名称"]',name);await ui.fill('[aria-label="服务地址"]','https://bq.example.invalid/biz/');
 await ui.fill('[aria-label="用户名"]','bq.synthetic');await ui.fill('[aria-label="认证信息"]',secret);
}
async function assertSecretAbsent(secret,label){
 const stores=await app.evaluate(`(async()=>{
  const local=Object.fromEntries(Object.keys(localStorage).map(k=>[k,localStorage.getItem(k)])),session=Object.fromEntries(Object.keys(sessionStorage).map(k=>[k,sessionStorage.getItem(k)]));
  const databases=[];
  for(const descriptor of await indexedDB.databases()){
   const db=await new Promise((resolve,reject)=>{const request=indexedDB.open(descriptor.name,descriptor.version);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
   try{const values={};for(const name of db.objectStoreNames)values[name]=await new Promise((resolve,reject)=>{const request=db.transaction(name,'readonly').objectStore(name).getAll();request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});databases.push({name:descriptor.name,values});}finally{db.close();}
  }
  return {local,session,databases,url:location.href,body:document.body.innerText};
 })()`);
 const history=await app.cdp('Page.getNavigationHistory');
 assert(!JSON.stringify({stores,history}).includes(secret),'Synthetic secret leaked into storage, URL/history or rendered records');
 result.secretObservations??=[];result.secretObservations.push({label,at:new Date().toISOString(),localKeys:Object.keys(stores.local),sessionKeys:Object.keys(stores.session),indexedDatabases:stores.databases.map(d=>d.name),historyEntries:history.entries.length,secretPresent:false,storageSha256:sha(JSON.stringify({local:stores.local,session:stores.session,databases:stores.databases}))});
 assert.equal(stores.local['willyou-m9-prototype-panel-width'],'480');
 return stores;
}
try{
 harness=await openPrototypeSource({executable,headlessBrowser,root,record:result,route:'apps/zentao'});app=harness.app;ui=prototypeInput(app,result);
 await app.waitFor(`!!localStorage.getItem('willyou-m10-prototype-v2')`);
 // This is an unrelated M9 precondition, not a tested M10 edit or reset action.
 await app.evaluate(`localStorage.setItem('willyou-m9-prototype-panel-width','480');true`);
 result.prerequisites={m9Width:{key:'willyou-m9-prototype-panel-width',value:'480',purpose:'unchanged unrelated storage canary'},m10:'original synthetic bootstrap A; no M10 store/DOM values injected'};

 if(wanted.has('T27')){
  caseId='T27';result.cases[caseId].status='running';stage='T27-zentao';await openAdd();
  await ui.click('dialog button','测试连接');await ui.has('请输入连接名称');
  await ui.fill('[aria-label="连接名称"]','BQ validation');await ui.fill('[aria-label="服务地址"]','not-a-url');await ui.click('dialog button','测试连接');await ui.has('请输入有效的禅道服务地址');
  await ui.fill('[aria-label="服务地址"]','https://user:private@example.invalid/biz/');await ui.click('dialog button','测试连接');await ui.has('不含凭据、查询参数或片段');
  await ui.fill('[aria-label="服务地址"]','https://bq.example.invalid/biz/');await ui.click('dialog button','测试连接');await ui.has('请输入用户名');
  await ui.fill('[aria-label="用户名"]','bq.synthetic');await ui.click('dialog button','测试连接');await ui.has('请填入示例认证信息');
  await ui.fill('[aria-label="认证信息"]','BQ-public-synthetic-value');await test();
  await ui.choose('select[aria-label="认证方式"]',1);assert.equal(await app.evaluate(`!!document.querySelector('dialog [aria-label="用户名"]')`),false);assert.equal(await app.evaluate(`document.querySelector('dialog button[type=submit],dialog footer button:last-child').disabled`),true);await test();
  await ui.choose('select[aria-label="认证方式"]',0);assert.equal(await app.evaluate(`!!document.querySelector('dialog [aria-label="用户名"]')`),true);await test();
  check('ZenTao missing/invalid fields and both actual auth choices require a fresh simulated test');await close();
  stage='T27-local';await go('mail');await openAdd();await ui.click('dialog button','测试连接');await ui.has('请输入连接名称');
  await ui.fill('[aria-label="连接名称"]','BQ local validation');await ui.fill('[aria-label="Foxmail本地来源"]','relative/path');await ui.click('dialog button','测试连接');await ui.has('完整的本地来源路径');
  await ui.fill('[aria-label="Foxmail本地来源"]','/private/tmp/BQ-合成只读来源');assert.equal(await app.evaluate(`!!document.querySelector('dialog [aria-label="认证信息"]')`),false);await test();await close();check('Local source requires an absolute path and has no sending/credential fields');
  stage='T27-smtp';await ui.click('button','配置发件通道');await ui.fill('[aria-label="连接名称"]','BQ SMTP validation');await ui.fill('[aria-label="服务主机"]','bad@host');await ui.click('dialog button','测试连接');await ui.has('邮件服务主机名');
  await ui.fill('[aria-label="服务主机"]','smtp.example.invalid');
  for(const port of ['0','65536']){await ui.fill('[aria-label="端口"]',port);await ui.click('dialog button','测试连接');await ui.has('端口必须为1–65535');}
  await ui.fill('[aria-label="端口"]','465');await ui.fill('[aria-label="发件账号"]','invalid');await ui.click('dialog button','测试连接');await ui.has('邮件地址');
  await ui.fill('[aria-label="发件账号"]','bq@example.invalid');await ui.click('dialog button','测试连接');await ui.has('请填入示例认证信息');await ui.fill('[aria-label="认证信息"]','BQ-public-synthetic-value');await test();
  await ui.choose('select[aria-label="SMTP连接方式"]',1);await ui.fill('[aria-label="端口"]','587');await test();
  await app.screenshot(join(root,'T27-smtp-valid.png'));await close();check('SMTP host/port/account/secret validation and actual TLS choice stay separate from local reading');
  result.cases[caseId]={status:'passed',layer:'P interaction; corresponding model-unit validation recorded separately'};
 }

 if(wanted.has('T29')){
  caseId='T29';result.cases[caseId].status='running';stage='T29-new-cancel';await go('zentao');const before=await state(),original=before.connections.find(c=>c.id==='zt-demo');assert(original);
  for(const method of ['cancel','escape']){await openAdd();await ui.fill('[aria-label="连接名称"]','BQ unsaved '+method);await close(method);assert.deepEqual(await state(),before);assert.equal(await app.evaluate(`document.activeElement?.textContent.trim()`),'添加连接');}
  check('Cancel and Escape do not create B and return to the still-connected add control');
  stage='T29-edit-cancel';await edit(original.name);await ui.fill('[aria-label="连接名称"]','BQ unsaved A edit');await close();assert.deepEqual(await state(),before);
  result.editCancelFocus=await app.evaluate(`({tag:document.activeElement?.tagName,label:document.activeElement?.getAttribute('aria-label'),text:document.activeElement?.textContent?.slice(0,80)})`);
  assert.equal(result.editCancelFocus.label,'管理'+original.name,'Edit cancellation must restore its surviving connection menu trigger');
  await edit(original.name);assert.equal(await app.evaluate(`document.querySelector('[aria-label="连接名称"]').value`),original.name);assert.equal(await app.evaluate(`document.querySelector('[aria-label="认证信息"]').value`),'');
  check('Canceled A edit preserves original config and reopens with no secret value');
  stage='T29-save-reload';const renamed=original.name+' · BQ非敏感修订';await ui.fill('[aria-label="连接名称"]',renamed);await test();await ui.click('dialog button','保存连接');await app.waitFor(`!document.querySelector('dialog[open]')`);
  const saved=(await state()).connections.find(c=>c.id===original.id);assert.equal(saved.name,renamed);assert.equal(saved.revision,original.revision+1);await reload();assert.deepEqual((await state()).connections.find(c=>c.id===original.id),saved);await ui.has('已连接 · 示例');
  await edit(renamed);assert.equal(await app.evaluate(`document.querySelector('[aria-label="连接名称"]').value`),renamed);assert.equal(await app.evaluate(`document.querySelector('[aria-label="认证信息"]').value`),'');await close();await app.screenshot(join(root,'T29-restored.png'));
  check('Explicitly tested/saved non-secret A revision survives reload and stays labelled synthetic');result.cases[caseId]={status:'passed',layer:'P interaction and isolated browser storage'};
 }

 if(wanted.has('T32')){
  caseId='T32';result.cases[caseId].status='running';stage='T32-secret-save';await go('zentao');const secret='M10_BQ_SYNTHETIC_'+randomUUID(),name='BQ秘密不持久化样本';result.secretCanarySha256=sha(secret);
  await app.evaluate(`window.__bqTerminalEvents=[];window.__bqSubmits=[];window.addEventListener('m9:terminal-insert',e=>window.__bqTerminalEvents.push(e.detail));document.addEventListener('submit',e=>setTimeout(()=>window.__bqSubmits.push({prevented:e.defaultPrevented,label:e.target.closest('dialog')?.getAttribute('aria-label')}),0),true);true`);
  await openAdd();await zenValues(secret,name);await ui.fill('[aria-label="服务地址"]','https://bq.example.invalid/?private='+secret);await ui.click('dialog button','测试连接');await ui.has('不含凭据、查询参数或片段');assert(!(await app.evaluate(`document.querySelector('dialog [role=status]').textContent`)).includes(secret));
  await ui.fill('[aria-label="服务地址"]','https://bq.example.invalid/biz/');await test();await ui.click('dialog button','保存连接');await app.waitFor(`!document.querySelector('dialog[open]')`);
  const saved=(await state()).connections.find(c=>c.name===name);assert(saved?.credentialPresent);await assertSecretAbsent(secret,'after simulated save');
  result.formSubmitObservations=await app.evaluate('window.__bqSubmits');assert(result.formSubmitObservations.length>0&&result.formSubmitObservations.every(x=>x.prevented));assert.deepEqual(await app.evaluate('window.__bqTerminalEvents'),[]);
  await edit(name);assert.equal(await app.evaluate(`document.querySelector('[aria-label="认证信息"]').value`),'');await close();await reload();await assertSecretAbsent(secret,'after reload');await edit(name);assert.equal(await app.evaluate(`document.querySelector('[aria-label="认证信息"]').value`),'');await close();
  check('Secret is absent from local/session/IndexedDB, URLs/history and reopened input; only presence metadata persists, errors are generic, submit is prevented');
  stage='T32-project-terminal';
  for(const [project,title,task] of [['AIS','调研开发环境中的 Skill 与 Agent','research'],['WillYou','检查多平台安装包','build']]){
   await ui.click('.reference-project-name',project);await ui.click('.reference-task-title',title);await app.waitFor(`location.hash==='#task/${task}'&&!!document.querySelector('.xterm-screen')`);
   const snapshot=await app.evaluate(`import('/src/App.jsx').then(m=>m.terminalPreviewSnapshot(${JSON.stringify(task)}))`);assert(snapshot,'Read-only snapshot must refer to the actual mounted synthetic terminal');assert(!JSON.stringify(snapshot).includes(secret));result.terminalChecks??=[];result.terminalChecks.push({project,task,inputSha256:sha(snapshot.input),outputSha256:sha(snapshot.output),secretPresent:false});
   await assertSecretAbsent(secret,'project '+project+' and terminal '+task);
  }
  await app.screenshot(join(root,'T32-terminal-no-secret.png'));check('Switching two actual prototype projects and terminal models does not expose the secret or change unrelated M9 width');result.cases[caseId]={status:'passed',layer:'P storage/URL/events and actual synthetic terminal model'};
 }
 stage='final-boundaries';assert(result.requests.every(r=>!/^https?:/.test(r.url)||new URL(r.url).origin===harness.origin));await harness.assertSourcesUnchanged();assert.deepEqual(app.rendererErrors,[]);result.status='passed';
}catch(error){result.status='failed';result.failedStage=stage;result.error=String(error);result.stack=error.stack;if(caseId)result.cases[caseId]={status:'failed',stage};process.exitCode=1;if(app)try{result.dom=await app.evaluate('document.body?.innerText');await app.screenshot(join(root,'failure.png'));}catch{}}
finally{
 if(harness){result.rendererErrors=app.rendererErrors;await writeFile(join(root,'electron.log'),app.logs());await writeFile(join(root,'prototype-server.log'),harness.logs());await harness.close();}
 result.finishedAt=new Date().toISOString();await writeFile(join(root,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,cases:result.cases,checks:result.checks.length,failedStage:result.failedStage,error:result.error,root}));
}
