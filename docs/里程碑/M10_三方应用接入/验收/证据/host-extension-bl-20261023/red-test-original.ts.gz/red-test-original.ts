import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import Database from 'better-sqlite3';
import {drizzle} from 'drizzle-orm/better-sqlite3';
import {z} from 'zod';
import {beforeEach,afterEach,describe,it,expect,vi} from 'vitest';
import * as schema from '../../../db/schema';
import {runBundledMigrations} from '../../../db/migrations';
import {SecretsStore} from '../../../secrets';
import {ApplicationConnectionService} from '../connection-service';
import {ResourceStore} from '../resource-store';
const ids=['extalpha','extbeta'] as const;
const definition=(id:typeof ids[number])=>({id,appId:id,configApiMajor:1,authentication:{kind:'secret',modes:['token']},permissions:{read:id+'.read',write:id+'.write'},configSchema:z.object({kind:z.literal(id),endpoint:z.url(),username:z.string().min(1),authMode:z.literal('token')}).strict()});
const hosts=()=>({api:1,applications:ids.map(id=>({id,slots:[id],stopBeforeSwitch:false})),providers:ids.map(definition)});
let root:string,sqlite:Database.Database,store:ResourceStore,secrets:SecretsStore;
beforeEach(()=>{root=mkdtempSync(join(tmpdir(),'willyou-host-extension-'));sqlite=new Database(':memory:');sqlite.pragma('foreign_keys=ON');runBundledMigrations(sqlite);store=new ResourceStore(sqlite,root);secrets=new SecretsStore(drizzle(sqlite,{schema}),{isAvailable:()=>true,encrypt:s=>Buffer.from([...s].reverse().join('')),decrypt:b=>[...b.toString()].reverse().join('')});});
afterEach(()=>{vi.restoreAllMocks();sqlite.close();rmSync(root,{recursive:true,force:true});});
function connections(definitions:unknown=hosts()){
 // Pass the proposed main-process constructor contract to the existing real
 // service. Baseline ignores it and rejects the fake configuration at validation;
 // no missing module,SQL bypass or parallel lifecycle can make this test green.
 return Reflect.construct(ApplicationConnectionService,[store,secrets,{verify:vi.fn(async(config:{kind:string;username:string})=>({providerId:config.kind,serviceId:'isolated-service',accountId:config.username,contractMajor:1}))},1000,definitions]) as ApplicationConnectionService;
}
const request=(id:typeof ids[number])=>({expectedRevision:0,name:'Isolated '+id,config:{kind:id,endpoint:'https://'+id+'.example.test/',username:id+'-user',authMode:'token'},secret:'private-'+id+'-secret'});
const test=(service:ApplicationConnectionService,input:unknown)=>Reflect.apply(service.testCandidate,service,[input]);
describe('trusted host extension uses the actual shared connection lifecycle',()=>{
 it.each(ids)('verifies,commits,authenticates,revokes and recovers the registered %s provider',async id=>{
  const service=connections(),input=request(id),candidate=await test(service,input);expect(service.list()).toEqual([]);const saved=await service.commitCandidate(candidate.operationId,candidate.candidateHash);expect(saved).toMatchObject({appId:id,providerId:id,config:input.config,revision:1,identityRevision:1,authorization:'connected'});expect(service.authentication(saved.id,saved)).toEqual({config:input.config,secret:input.secret});expect(JSON.stringify(candidate)+JSON.stringify(saved)+JSON.stringify(sqlite.prepare('SELECT * FROM app_secrets').all())).not.toContain(input.secret);await expect(service.commitCandidate(candidate.operationId,candidate.candidateHash)).rejects.toMatchObject({code:'CONFIG_PLAN_STALE'});const disabled=await service.setEnabled(saved.id,false,saved.revision);expect(()=>service.authentication(saved.id,disabled)).toThrow();const enabled=await service.setEnabled(saved.id,true,disabled.revision);const disconnected=await service.disconnect(saved.id,enabled.revision);expect(disconnected).toMatchObject({authorization:'disconnected',hasSecret:false});const reopened=connections();await reopened.recoverSecretChanges();expect(reopened.get(saved.id)).toEqual(disconnected);
 });
 it('keeps two provider identities,secret references and failed rotations independent in the same actual SQLite store',async()=>{
  const service=connections(),a=await test(service,request('extalpha')),b=await test(service,request('extbeta')),first=await service.commitCandidate(a.operationId,a.candidateHash),second=await service.commitCandidate(b.operationId,b.candidateHash);expect(first.id).not.toBe(second.id);expect(service.list()).toHaveLength(2);const candidate=await test(service,{...request('extalpha'),id:first.id,expectedRevision:first.revision,secret:'discarded-rotation'});await service.discardCandidate(candidate.operationId);expect(service.authentication(first.id,first).secret).toBe(request('extalpha').secret);expect(service.authentication(second.id,second).secret).toBe(request('extbeta').secret);expect(sqlite.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
 });
 it.each(['duplicate-app','duplicate-provider','unregistered-slot','unknown-api'] as const)('rejects an invalid static registration before creating connection state: %s',fault=>{
  const defs=hosts();if(fault==='duplicate-app')defs.applications.push(defs.applications[0]);if(fault==='duplicate-provider')defs.providers.push(defs.providers[0]);if(fault==='unregistered-slot')defs.applications[0].slots=['missing-provider' as typeof ids[number]];if(fault==='unknown-api')defs.api=2;expect(()=>connections(defs)).toThrow();expect(sqlite.prepare('SELECT count(*) n FROM application_connections').get()).toEqual({n:0});expect(sqlite.prepare('SELECT count(*) n FROM app_secrets').get()).toEqual({n:0});
 });
 it('keeps default product configuration strict and refuses the fake provider without the static host definition',async()=>{
  const service=new ApplicationConnectionService(store,secrets,{verify:async()=>{throw new Error('must not verify');}});await expect(test(service,request('extalpha'))).rejects.toMatchObject({code:'INVALID_INPUT'});expect(sqlite.prepare('SELECT count(*) n FROM application_connections').get()).toEqual({n:0});
 });
});
