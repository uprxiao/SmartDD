from pathlib import Path
import re
p=Path(__file__).resolve().parent/'candidate/src/main/core/applications/execution-context.ts'
s=p.read_text()
assert 'export class ApplicationExecutionContexts {' in s
s=s.replace("import type { ApplicationId, ApplicationProvider, ApplicationConnection } from '@shared/application-connections';","import type {ApplicationId,ConnectionConfig} from '@shared/application-connections';\nimport type {HostedConfiguration,HostedConnection} from './host-application-registry';")
s=s.replace('export interface ApplicationExecutionContext {','export interface ApplicationExecutionContext<A extends string=ApplicationId> {').replace('readonly appId:ApplicationId;','readonly appId:A;')
s=s.replace('interface Target {slot:ApplicationProvider;','interface Target<P extends string> {slot:P;')
s=s.replace('interface ContextRecord {context:ApplicationExecutionContext;','interface ContextRecord<C extends HostedConfiguration,A extends string> {context:ApplicationExecutionContext<A>;').replace('targets:Map<ApplicationProvider,Target>;','targets:Map<C[\'kind\'],Target<C[\'kind\']>>;')
s=s.replace("slot:z.enum(['zentao','foxmail','smtp'])","slot:z.string().regex(/^[a-z][a-z0-9-]{0,63}$/)")
prefix,body=s.split('export class ApplicationExecutionContexts {',1)
for before,after in [('ApplicationExecutionContext','ApplicationExecutionContext<A>'),('ContextRecord','ContextRecord<C,A>'),('Target',"Target<C['kind']>"),('ApplicationProvider',"C['kind']"),('ApplicationConnection','HostedConnection<C,A>'),('ApplicationId','A'),('ApplicationSelectionService','ApplicationSelectionService<C,A>'),('ApplicationConnectionService','ApplicationConnectionService<C,A>')]:body=re.sub(r'\b'+before+r'\b',lambda _:after,body)
body=body.replace('new BuiltinPackageRegistry(store)','new BuiltinPackageRegistry(store,this.connections.registry)')
body=body.replace('  private now():number',"  private get registry(){return this.connections.registry;}\n  private decodeTargets(value:string,appId:A):Target<C['kind']>[] {\n    return z.array(targetSchema).parse(JSON.parse(value)).map(target=>{const provider=this.registry.provider(target.slot);if(provider.appId!==appId)throw new ApplicationError('HASH_MISMATCH','原业务来源类别不属于当前应用');return{...target,slot:provider.id};});\n  }\n  private now():number")
body=body.replace("this.require(context,slot==='smtp'?'mail.send':context.appId+'.read');","const provider=this.registry.provider(slot);this.require(context,context.semantics==='write'?provider.permissions.write:provider.permissions.read);")
body=body.replace('appId=application.appId as A','appId=this.registry.appId(application.appId)').replace('appId:application.appId as A','appId:this.registry.appId(application.appId)')
body=body.replace("this.pinConnection(context,'smtp',","this.pinConnection(context,this.registry.provider('smtp').id,")
body=body.replace("this.selections.connectionSlot(context.projectId,'mail','smtp')","this.selections.connectionSlot(context.projectId,this.registry.appId('mail'),this.registry.provider('smtp').id)")
body=body.replace("appId:'mail',packageHash:first.packageHash","appId:this.registry.appId('mail'),packageHash:first.packageHash")
body=body.replace('private checkTarget(context:ApplicationExecutionContext<A>,',"private checkTarget(context:Pick<ApplicationExecutionContext<A>,'projectId'|'appId'>,")
body=body.replace('z.array(targetSchema).parse(JSON.parse(row.targets_json))','this.decodeTargets(row.targets_json,context.appId)',1)
body=body.replace('z.array(targetSchema).parse(JSON.parse(row.targets_json))','this.decodeTargets(row.targets_json,row.app_id)',1)
body=body.replace('{projectId:row.project_id,appId:row.app_id} as ApplicationExecutionContext<A>','{projectId:row.project_id,appId:row.app_id}')
old="if(this.closed)throw new ApplicationError('CANCELED','应用业务服务已停止');actionSchema.parse(input.action);"
new="if(this.closed)throw new ApplicationError('CANCELED','应用业务服务已停止');this.registry.appId(input.appId);if(application.appId!==input.appId||application.packageHash!==input.packageHash)throw new ApplicationError('SCOPE_DENIED','业务上下文不能替换受信应用或原包');actionSchema.parse(input.action);"
assert body.count(old)==1;body=body.replace(old,new)
p.write_text(prefix+'export class ApplicationExecutionContexts<C extends HostedConfiguration=ConnectionConfig,A extends string=ApplicationId> {'+body)
print('Generalized the existing context class;kept producer,WeakMap,run,policy,target and receipt checks')
