# 新增应用实施与验收指南 · R1.6

2026-10-23 BM修订。需求依据为[需求](../需求.md) R1.6、§12.21、M10-R09、R10；实现基线为 `35088e7b44de6c483b522e6d7e7bf51c0f57b69c` 加[本批固定源码及验证证据](../验收/证据/m10-extension-call-bm-20261023.json)。BL已接注册／连接／项目选用，BM接入共用发现／调用／上下文／记录；2026-10-20 R09-H及其代码1f1390ba保留为历史，不用当时的硬编码描述覆盖当前接口。

本指南说明随程序编译的受信宿主接线，不是公开插件SDK或任意代码安装器。生产目录仍只有禅道、邮件；Jenkins仅为后续推演，没有真实接入、Job、外部写入或M11调度API。本次fake实验不增加产品入口、不证明第三种真实Agent或外部协议可用。

## 1. 定范围、身份与连接定义

新增真实应用先进入需求池、安排阶段并完成需求／原型／用例评审。复用M10公共核心不能替代这一步。应用ID需符合包原生命名约束（最多20字符、小写字母数字及单连字符分段），provider ID遵守宿主schema；同一provider不能跨应用或悄悄换配置主版本。

在主进程编译 `HostApplicationDefinitions<C,A>`，由 `ApplicationConnectionService<C,A>` 第五参数接入；省略时仍使用原两应用／三provider定义。定义包含：

| 项 | 实际契约及责任 |
| --- | --- |
| applications | 应用ID、全部单选来源槽、`stopBeforeSwitch`；禅道原先停再切保持，邮件原行为保持 |
| providers | provider／app归属、`configApiMajor:1`、实际配置zod schema、认证类别／支持模式、读写权限映射、必要的候选身份校验 |
| verifier | 应用专属认证协议与只读核验，返回稳定服务／账号身份及 `contractMajor:1`；处理证书、重定向、本地格式及错误，不能靠manifest声明证明认证支持 |

复用 `connection-service.ts` 的候选→测试→回执→提交／丢弃、CAS、秘密日志／恢复、启停／断开、影响检查和同身份轮换，不另建登录状态机。秘密由原SecretsStore处理；配置与日志不夹带明文凭据。`0026_registered_application_hosts` 在原SQLite中登记外键身份，保留旧连接／绑定／候选／发送引用；这些行不是可执行授权。当前RAM中的编译定义仍须存在，配置／provider／身份／版本不符时拒绝解析秘密。

`ApplicationSelectionService<C,A>` 使用同一连接实例读取槽，复用目录添加／启用、每项目显式选择、停止协调、槽修订及policy撤销。未选用为null，不选择第一个健康连接，也不自动回退。新增UI及对应系统／视觉验收另按该应用范围实施；现有产品RPC和配置页面仍限制本期两应用。

## 2. 完整包、运行依赖与可信分发

先准备完整manifest、Skill、输入／输出及连接schema、纯CJS分派器、操作表、完整文件摘要和runtime。包版本／hash、工具contractMajor、host/data API、连接配置／身份主版本、runtime及Agent adapter版本分别记录。缺资源、未知版本、重复工具或同版异内容拒绝，不原地覆盖已使用的不可变包。

`PackageRegistry.install` 验证包和数据迁移契约，但安装记录本身不授执行权。主进程构建／分发引导使用 `CapabilityBundleSource` 与 `BuiltinPackageRegistry(store,connections.registry)`，核对索引、原文件树、资源集、runtime身份并保存原分发依据。`BuiltinPackageRegistry(store)` 省略目录时仍只接受原两应用；复制数据库登记行、修改manifest或用户路径都不能代替受信宿主接线。

`ApplicationAdapterRegistry(store,data,connections.registry)` 只加载已批准原包的纯CJS入口，仍核对原文件字节、runtime、工具集合、权限、命名空间、读写语义与重试声明。每次调用只能访问自己的固定Data API路由一次；缓存模块也重新核验原包。VM不是不可信第三方代码安全沙箱，不能扩大require或按用户路径加载可执行文件。

生产构建按原脚本生成并验证索引，不能把实验包放入产品目录：

```sh
node scripts/applications/build-runtime.mjs /private/tmp/<本轮唯一根>/runtime
node scripts/applications/build-bundles.mjs /private/tmp/<本轮唯一根>/bundles /private/tmp/<本轮唯一根>/runtime/mcp-bridge.cjs
```

使用 `scripts/applications/verify-bundles.cjs` 校验完整内容与实际应用版本；变更runtime／adapter内容时使用新不可变版本，保留历史依赖。新增第三方来源按AGENTS更新NOTICE／许可。本指南修订未生成新App或触发发布。

## 3. 共用发现、执行上下文与应用差异

在主进程创建 `ApplicationExecutionContexts<C,A>(store,selections,connections,deps)`，`deps.assertRun` 连接真实 `CapabilityRunRegistry`，UI使用真实sender核验。上下文由原WeakMap签发；JSON副本、模型自报项目／账号／approved、数据库元信息不拥有能力。

应用数据服务实现 `ApplicationDataHost.resolve`，返回固定路由的 `HostToolOperation`。使用 `ApplicationBusinessDataService({registry:connections.registry,hosts:[{appId,data},...]})` 登记编译服务；未知／重复应用、缺resolver或空登记拒绝。原邮件／禅道构造入口及直接服务访问继续保留。这个登记不开放额外UI业务路由；新应用UI需按已评审范围接入受信producer及相应页面。

调用顺序为：原会话快照／实际run及允许动作 → `ApplicationToolService.list/call` → 原包／schema → `ApplicationAdapterRegistry` 固定路由 → 共用data分派 → 应用handler的 `contexts.withAgent` → `contexts.connection` 固定当前显式槽及修订 → 应用业务参数／对象与结果映射。连接读取按provider的读／写权限映射核验，返回前重验run、policy及原目标；不复制连接／权限／调用记录主流程。

应用handler负责外部API、对象归属、分页／游标、业务参数与结果schema、明确写入授权、外部结果核实及其恢复。通用context和manifest权限不能替代业务授权；未来写能力不能直接套用邮件语义或仅凭模型确认执行。邮件现有原用户指令、冻结内容和一次执行门禁保持。

调用账与业务操作账使用同一operation ID，记录真实run／task／project、原app／包／工具、尝试／效果状态、时间和已固定来源；不把秘密或原始请求正文塞入日志。当前授权及目标修订在读取原回执时仍重核。应用对象仍由各应用服务持久化；回执不是恢复外部业务或重放写操作的凭证。

## 4. 错误、取消、未知结果与资源

读重试由受信handler语义决定且有界；写重试必须never。取消本地等待不等于远端取消，提交后超时／断线保留unknown并核对原业务记录。当前ToolService按 `AbortSignal.any` 最先触发的原因区分取消和deadline；生产者迟到的本地取消不把超时改写为取消，稍后到期的deadline也不覆盖先发生的取消。结果交付与生产者真实结束分别处理，活动占用持续到真实settlement。

新业务状态不得统一映射为外部成功；邮件服务器接受不等于送达，未来queue/build需独立契约。故障注入与正常路径分开留证，未发生的真实外部动作不能填通过。

资源继续使用 `ResourceStore`、不可变包／runtime、session refs及run leases；不透明句柄绑定项目、应用、来源和修订，读取有字节预算。数据迁移使用已登记的 `ApplicationDataMigration`，声明、连续性与checksum符合才激活；包中SQL不会自动执行。共享C/H及历史引用按原保留／核验规则维护；未知身份不能按时间或PID缺失删除。完整有据回收仍属M10后续核对项，不因扩展实验通过就宣称已完成。

## 5. M11与未来Jenkins的边界

当前producer为受信UI／management、原生Agent run及受约束索引；没有scheduler producer或M11调度API。未来M11须在其授权范围内新增不可伪造的调度／任务身份、项目选用、policy／修订、运行占用、operation/request幂等、deadline／取消及恢复。不能构造JSON冒充run，不能借索引或连接管理context执行写入，也不能把 `tools.call(runId,...)` 当作脱离真实run的调度接口。

未来Jenkins可复用上述编译登记、连接候选／秘密、项目选用、分发／原包、Data API、context与调用账；仍需独立实现认证、Job等对象、版本适配、只读接口、UI／数据迁移及真实环境验收。触发／取消另需明确授权、queue/build身份、远端结果和unknown恢复，不随只读自动开放。[历史V2研究](多应用适配与Jenkins扩展方案V2.md)的外部资料为2026-10-17时点，本次未重新联网验证，不作目标实例或最新版本事实。

## 6. 验证矩阵与本次边界

| 用例 | 本次证据与边界 |
| --- | --- |
| T39 | BL公共注册／连接契约、R09-H无效完整包声明及BM完整fake分发／发现、连接schema、权限与日志映射；具体结果以[本批记录](受信扩展完整调用与超时记录_20261023.md)为准 |
| T40 | BM两fake应用、两连接、两真实隔离项目使用原公共类，覆盖正常读取、schema／跨项目／无权、取消／超时／unknown、原回执／目标及原代码字节核验，重复执行不增加正式条数 |
| T41 | 生产目录仍是禅道／邮件，fake不进入原型或产品目录；未操作的界面状态仍按原用例补验，不能用本实验冒充完整页面验收 |
| T42 | 本指南按登记步骤、共用／新增职责、契约／错误／权限／记录、版本／迁移、M11缺项五步复查；历史R09-H结论和证据保留 |

E-EXT使用真实SQLite、SecretsStore接口、原session/run/tool/adapter/context类及完整私有分发索引；认证、加密器、业务对象／故障由fake实现，进程身份读取器为受控夹具，直接使用原主进程ToolService发现／调用入口，没有启动MCP桥传输、原生Agent进程、网络认证或真实外部写入。定时器观察保留真实 `AbortSignal.timeout`，不改虚拟时钟；破坏目标账、适配器字节及迟到producer均明确注入并隔离／恢复。正式App／系统／原生发现及外部协议仍按各自用例和平台补验。

完整M10仍处第5步：89编号核对、有据回收及其他范围内补缺完成后，冻结新包并执行原72条和必要回归，最后交付归档。不能把本指南或fake实验通过当成M10开发完成、真实Jenkins交付或正式发布。
