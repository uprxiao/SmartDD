import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const {openElectron}=await import(pathToFileURL(resolve('scripts/lib/electron-harness.mjs')));
const scratch=await mkdtemp(join(tmpdir(),'willyou-harness-navigation-'));
const result={layer:'driver technical probe on isolated packaged App;no UI inputs,Agent,provider or formal-case credit',scratch,startedAt:new Date().toISOString(),checks:[],sourceSha256:createHash('sha256').update(await readFile('scripts/lib/electron-harness.mjs')).digest('hex')};
let app;
try{
 app=await openElectron({executable:process.env.WILLYOU_ACCEPTANCE_APP,userData:join(scratch,'userdata')});result.pid=app.processId;
 async function navigateWithPendingRead(navigation){
  const origin=await app.evaluate('performance.timeOrigin'),before=app.navigationWaits.length;
  // This technical marker has no connection to the application's business state.
  const waiting=app.waitFor(`performance.timeOrigin!==${origin}?true:(window.__harnessNavigationProbePending=true,new Promise(()=>{}))`,5000,{navigation});
  const observed=waiting.then(()=>({passed:true}),error=>({passed:false,error:{message:error.message,cdpMethod:error.cdpMethod,cdpCode:error.cdpCode}}));
  await app.waitFor('window.__harnessNavigationProbePending===true',2000);
  await app.cdp('Page.reload');const outcome=await observed;
  await app.waitFor('document.readyState==="complete"&&!!document.querySelector("[data-testid=nav-home]")',5000,{navigation:true});
  return {...outcome,retries:app.navigationWaits.length-before};
 }
 const retried=await navigateWithPendingRead(true);assert.equal(retried.passed,true);assert(retried.retries>=1);result.checks.push({name:'Explicit read-only navigation wait survives actual destroyed context on the same owned page',...retried});
 const ordinary=await navigateWithPendingRead(false);assert.equal(ordinary.passed,false);assert.equal(ordinary.error.cdpMethod,'Runtime.evaluate');assert.equal(ordinary.retries,0);result.checks.push({name:'Default wait still rejects an actual context-destruction protocol error without replay',...ordinary});
 await assert.rejects(app.waitFor('(()=>{throw new Error("Inspected target navigated or closed")})()',1000,{navigation:true}),error=>!error.cdpMethod&&error.message.includes('Inspected target navigated or closed'));result.checks.push({name:'JavaScript exception with matching text is not retried',passed:true});
 await assert.rejects(app.waitFor('false',40,{navigation:true}),/Electron test condition timed out/);result.checks.push({name:'False condition has a bounded deadline',passed:true});
 result.stopped=await app.crash();await assert.rejects(app.waitFor('true',1000,{navigation:true}),/Isolated Electron target stopped/);result.checks.push({name:'Owned process death is reported immediately even with navigation opt-in',passed:true});
 result.status='passed';
}catch(error){result.status='failed';result.error=String(error);result.stack=error.stack;process.exitCode=1;}
finally{if(app){result.navigationWaits=app.navigationWaits;result.rendererErrors=app.rendererErrors;await writeFile(join(scratch,'electron.log'),app.logs());await app.close();}result.finishedAt=new Date().toISOString();await writeFile(join(scratch,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,checks:result.checks.length,error:result.error,artifacts:scratch}));}
