import {createHash,randomBytes} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,rmSync,writeFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {Worker} from 'node:worker_threads';
import Database from 'better-sqlite3';
import {expect,it} from 'vitest';
import {AgentStore} from '@fixture-src/main/core/agent/agent-store';
import {TurnDiffs} from '@fixture-src/main/core/agent/turn-diffs';
import {runBundledMigrations} from '@fixture-src/main/db/migrations';
import type {DiffJob,TreeRef} from '@fixture-src/main/core/agent/turn-diff-worker';

const base='/private/tmp/willyou-m14-stage6.WRvdST/g04/prep-next/a34';
const workerPath='/private/tmp/willyou-m14-stage6.WRvdST/source/out/main/agent-diff-worker.js';
const hash=(bytes:Buffer)=>createHash('sha256').update(bytes).digest('hex');
const registeredRef=(r:TreeRef)=>execFileSync('/usr/bin/git',['--git-dir='+r.gitDir,'for-each-ref','--format=%(objectname)',r.ref],
  {encoding:'utf8',env:{...process.env,GIT_CONFIG_GLOBAL:'/dev/null',GIT_CONFIG_NOSYSTEM:'1'}}).trim();
type Shot={taskId:string;turnId:string;before:TreeRef;after:TreeRef};
type JobRecord={action:DiffJob['action'];turnId:string;side?:DiffJob['side'];afterReclaim?:boolean;ok?:boolean;error?:string};

it('A34: actual worker quota blocks fully leased snapshots, resumes after release, and reclaims archived/oldest first',async()=>{
  const results=join(base,'privateRuns');
  mkdirSync(results,{recursive:true,mode:0o700});
  const root=realpathSync(mkdtempSync(join(results,'integration-')));
  expect(root.startsWith(results+'/')).toBe(true);
  const cwd=join(root,'workspace'),storage=join(root,'private-shadow'),payload=join(cwd,'canary.bin');
  mkdirSync(cwd,{mode:0o700});
  writeFileSync(join(cwd,'small.txt'),'original baseline\n',{mode:0o600});
  const db=new Database(':memory:');
  db.pragma('foreign_keys=ON');
  runBundledMigrations(db);
  const store=new AgentStore(db,{artifactDir:join(root,'artifacts')});
  const changedTasks:string[]=[],jobs:JobRecord[]=[];
  const active=store.createTask({projectId:null,dirId:null,cwd,title:'A34 current local task',selection:{profileId:'fixture',driverId:'codex-app-server',tier:'ask'}});
  const archived=store.createTask({projectId:null,dirId:null,cwd,title:'A34 archived local task',selection:{profileId:'fixture',driverId:'codex-app-server',tier:'ask'}});
  const binding=store.createBinding({task_id:active,driver_id:'codex-app-server',profile_id:'fixture',continuation_hash:'a'.repeat(64),state_root:root,cwd_identity:cwd});
  const runId='a34-only-current-run';
  store.insertRun({runId,taskId:active,bindingId:binding,generation:1,projectId:null,driverId:'codex-app-server',
    owner:{instanceId:'a34-fixture',pid:process.pid,startedAt:null},launchPlanHash:'b'.repeat(64)});
  const worker=(input:DiffJob):Promise<unknown>=>new Promise((resolve,reject)=>{
    const job:JobRecord={action:input.action,turnId:input.turnId,side:input.side,afterReclaim:input.afterReclaim};
    jobs.push(job);
    const work=new Worker(workerPath,{workerData:{kind:'willyou-turn-diff-job',...input}});
    let result:{ok:boolean;value:unknown;error?:string}|undefined;
    work.on('message',(msg:{progress?:unknown;ok:boolean;value:unknown;error?:string})=>{
      if(!msg.progress)result=msg;
    });
    work.once('error',reject);
    work.once('exit',code=>{
      if(code!==0||!result)return reject(Error('actual diff worker exited without a clean result '+code));
      job.ok=result.ok;
      job.error=result.error;
      if(result.ok)resolve(result.value);else reject(Error(result.error));
    });
  });
  const quota=async()=>(await worker({action:'space',cwd,storage,turnId:'a34-space'}) as {bytes:number}).bytes;
  const turn=(taskId:string,label:string)=>store.acceptTurn({taskId,clientInputId:'a34-'+label,text:'isolated '+label,sourceKind:'user'}).turn;
  const seed=async(taskId:string,label:string):Promise<Shot>=>{
    const row=turn(taskId,label);
    writeFileSync(payload,randomBytes(96*1024),{mode:0o600});
    const capture=(side:'before'|'after')=>worker({action:'capture',cwd,storage,turnId:row.turn_id,side}) as Promise<TreeRef>;
    const before=await capture('before');
    writeFileSync(join(cwd,'small.txt'),label+'\n');
    const after=await capture('after');
    store.endTurn(row.turn_id,'completed');
    db.prepare("INSERT INTO agent_turn_changes(turn_id,task_id,before_ref,after_ref,status) VALUES(?,?,?,?,'complete')")
      .run(row.turn_id,taskId,JSON.stringify(before),JSON.stringify(after));
    return {taskId,turnId:row.turn_id,before,after};
  };
  const hosts:TurnDiffs[]=[];
  const make=async()=>{
    const capacity=Math.ceil((await quota())*1.06);
    const diffs=new TurnDiffs({store,storage,storageLimit:capacity,execute:worker,changed:taskId=>{changedTasks.push(taskId);}});
    hosts.push(diffs);
    return {diffs,capacity};
  };
  const retained=(shots:Shot[])=>shots.forEach(({before,after})=>{
    for(const ref of [before,after]){
      expect(ref.private).toBe(true);
      expect(dirname(ref.gitDir)).toBe(storage);
      expect(registeredRef(ref)).toBe(ref.commit);
    }
  });
  const reclaimed=(diffs:TurnDiffs,shot:Shot)=>{
    expect(diffs.turn(shot.taskId,shot.turnId)).toMatchObject({status:'none',reason:'快照已清理（空间回收）'});
    expect([registeredRef(shot.before),registeredRef(shot.after)]).toEqual(['','']);
  };
  const captured=async(diffs:TurnDiffs,label:string)=>{
    const row=turn(active,label);
    await diffs.before(active,row.turn_id,runId);
    return row.turn_id;
  };
  try{
    const activeOld=await seed(active,'first-active');
    const archivedOld=await seed(archived,'first-archived');
    const archivedNew=await seed(archived,'later-archived');
    const activeNew=await seed(active,'later-active');
    const original=[activeOld,archivedOld,archivedNew,activeNew];
    const acceptedAt=original.map(shot=>store.turn(shot.turnId)?.accepted_at);
    expect(acceptedAt).toEqual([...new Set(acceptedAt)].sort());
    store.setTasksArchived([archived],true);
    expect(store.task(archived)?.archived_at).toBeTruthy();
    const {diffs,capacity}=await make();
    const leases=original.map(shot=>({shot,token:diffs.hold(shot.taskId,shot.turnId)}));
    expect(new Set(leases.map(row=>row.token)).size).toBe(original.length);
    const testBytes=randomBytes(76*1024);
    writeFileSync(payload,testBytes);
    const releaseAt=jobs.length;
    const blockedTurn=await captured(diffs,'with-all-four-viewer-leases');
    const full=diffs.turn(active,blockedTurn);
    expect(full).toMatchObject({status:'incomplete',reason:expect.stringContaining('影子库空间已满')});
    expect(jobs.slice(releaseAt).filter(x=>x.action==='release')).toEqual([]);
    expect(jobs.slice(releaseAt).some(x=>x.action==='capture'&&x.afterReclaim===true&&x.ok===false&&x.error?.includes('影子库空间已满'))).toBe(true);
    retained(original);
    expect(hash(readFileSync(payload))).toBe(hash(testBytes));
    store.endTurn(blockedTurn,'completed');

    for(const {shot,token} of leases.filter(row=>row.shot!==activeNew))diffs.releaseView(shot.taskId,token);
    const retryAt=jobs.length;
    const recoveredTurn=await captured(diffs,'retry-after-releasing-old-leases');
    expect(diffs.turn(active,recoveredTurn)).toMatchObject({status:'capturing'});
    await diffs.after(active,recoveredTurn);
    expect(diffs.turn(active,recoveredTurn)).toMatchObject({status:'complete'});
    store.endTurn(recoveredTurn,'completed');
    expect(diffs.turn(active,blockedTurn)).toMatchObject({status:'incomplete'});
    reclaimed(diffs,archivedOld);
    expect(jobs.slice(retryAt).filter(x=>x.action==='release').map(x=>x.turnId)).toEqual([archivedOld.turnId]);
    retained([activeOld,archivedNew,activeNew]);
    expect(hash(readFileSync(payload))).toBe(hash(testBytes));
    diffs.releaseView(activeNew.taskId,leases.find(row=>row.shot===activeNew)!.token);

    const second=await make();
    const archiveLease=second.diffs.hold(archived,archivedNew.turnId);
    const retryLease=second.diffs.hold(active,recoveredTurn);
    writeFileSync(payload,randomBytes(69*1024));
    const activeAt=jobs.length;
    const lastTurn=await captured(second.diffs,'retry-selects-oldest-active');
    await second.diffs.after(active,lastTurn);
    expect(second.diffs.turn(active,lastTurn)).toMatchObject({status:'complete'});
    expect(jobs.slice(activeAt).filter(x=>x.action==='release').map(x=>x.turnId)).toEqual([activeOld.turnId]);
    reclaimed(second.diffs,activeOld);
    retained([archivedNew,activeNew]);
    second.diffs.releaseView(archived,archiveLease);
    second.diffs.releaseView(active,retryLease);
    writeFileSync(join(base,'integration-verdict.json'),JSON.stringify({active,archived,acceptedAt,capacity,secondCapacity:second.capacity,
      block:full,blockedTurn,recoveredTurn,lastTurn,reclaimOrder:[archivedOld.turnId,activeOld.turnId],
      retained:[archivedNew.turnId,activeNew.turnId],workerSha256:hash(readFileSync(workerPath)),jobs,changedTasks},null,2)+'\n',{mode:0o600});
  }finally{
    for(const host of hosts)await host.close();
    db.close();
    expect(existsSync(cwd)).toBe(true);
    rmSync(root,{recursive:true,force:true});
  }
});
