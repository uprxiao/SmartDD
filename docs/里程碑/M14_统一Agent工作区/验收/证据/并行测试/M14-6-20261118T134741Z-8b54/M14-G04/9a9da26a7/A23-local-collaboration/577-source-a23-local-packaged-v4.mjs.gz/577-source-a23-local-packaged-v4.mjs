import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, readdirSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { dirname, join } from 'node:path';
import { openElectron, pause } from '../../../g03/prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../../g03/prep-fef791bc6/home-redirect-main.mjs';
import { forwardResponse } from '../../../g03/claude-prep-1214412aa/a19-forward-response.mjs';
import { isA08OwnedApproval } from '../../../g03/prep-next/a08-relative-skill/owned-approval-v4.mjs';
import {correlate,peer,relativeProgram as program,skillName,skillText,warmMarker} from './proof-v3.mjs';
import {verifyChildProvenance,loadNativeChildFrames} from './child-provenance-v3.mjs';
import {serveVerifiedChild,childDispatchSql} from './child-provider-v4.mjs';
import { openPrivateModel, provider as localProvider, model } from '../../../local-model/ollama-private.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,sourceCommit]=process.argv.slice(2);
assert.equal(process.argv.length,4);
const testKind='codex';
const executable=process.env.M14_ACCEPTANCE_APP;
const asar=process.env.M14_EXPECTED_ASAR_SHA256;
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-[0-9]{3}$/);
assert.match(sourceCommit??'',/^[0-9a-f]{40}$/);
assert.match(asar??'',/^[0-9a-f]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceCommit);
assert.equal(executable,join(base,'package/mac-arm64/WillYou.app/Contents/MacOS/WillYou'));
assert.equal(realpathSync(executable),executable);
assert.equal(readFileSync(join(base,'source-commit.txt'),'utf8').trim(),sourceCommit);
assert.equal(createHash('sha256').update(readFileSync(join(base,'package/mac-arm64/WillYou.app/Contents/Resources/app.asar'))).digest('hex'),asar);
mkdirSync(out,{mode:0o700});
for(const file of ['a23-local-packaged-v4.mjs','proof-v3.mjs','child-provenance-v3.mjs','child-provider-v4.mjs','run-a23-local-v4.sh'])copyFileSync(new URL(file,import.meta.url),join(out,'source-'+file));
const root=realpathSync(mkdtempSync(join(out,'runtime-')));
const home=join(root,'home'), userData=join(root,'data'), cwd=join(root,'work');
for(const dir of [home,userData,cwd])mkdirSync(dir,{mode:0o700});
assert(!existsSync(join(cwd,'.git'))&&!existsSync(join(cwd,'.svn')));
const env={
  HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  npm_config_cache:join(root,'npm-cache'),npm_config_offline:'true',npm_config_audit:'false',npm_config_fund:'false',
  npm_config_userconfig:join(root,'test-npm-empty-user'),npm_config_globalconfig:join(root,'test-npm-empty-global'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',
  ENABLE_TOOL_SEARCH:'false',NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',
  HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
};
assert.deepEqual(Object.keys(process.env).filter(k=>/KEY|TOKEN|PROXY/.test(k)),[]);
const modelRoot=join(root,'local-model');
mkdirSync(modelRoot,{mode:0o700});
let modelState;
const hookResult={};
const globalDeadline=Date.now()+12*60*1000;
let stage=0;
const result={bootstrap:hookResult,sourceCommit,asar,executable,scope:'M14-A23 selected-Skill positive: actual packaged App and two fresh Codex parents use keyless local Qwen3-Coder; actual Claude SDK child uses a deterministic Anthropic text endpoint',testKind,
  observations:[],requests:[],actions:[],status:'failed'};
const port=3425;
const origin='http://127.0.0.1:'+port;
let app,projectId,childProfileId;
const childReplies=new Map();
const selectorExpr = selector => `document.querySelector(${JSON.stringify(selector)})`;
async function click(selector, text = null) {
  const query = text ? `[...document.querySelectorAll(${JSON.stringify(selector)})].filter(item => item.innerText.includes(${JSON.stringify(text)}))`
    : `[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const hit = `(() => {
    const nodes = ${query};
    const node = nodes.length === 1 && nodes[0];
    if (!node || node.disabled) return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});
    const rect=node.getBoundingClientRect(), x=rect.x+rect.width/2, y=rect.y+rect.height/2;
    return rect.width&&rect.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;
  })()`;
  await app.waitFor('Boolean('+hit+')',10000);
  const point=await app.evaluate(hit);
  assert(point, 'Expected visible unique control: ' + selector + ' ' + (text ?? ''));
  for (const type of ['mousePressed', 'mouseReleased']) {
    await app.cdp('Input.dispatchMouseEvent', { type, ...point, button: 'left', clickCount: 1 });
  }
  result.actions.push({ selector, text, ...point });
}



const name = skillName;
const source = join(home, '.claude', 'skills', name);
const entry = join(source, 'SKILL.md');
const relativeProgram=program;
const resource = join(source, relativeProgram);
const composer = '.agent-task-view textarea';
const row = '[data-testid="sidebar-agent-task"]';
const capsule='A23_ROLE_'+randomUUID().replaceAll('-','');
const configSha = () => [entry,resource].map(path => createHash('sha256').update(readFileSync(path)).digest('hex'));
const sanitized = value => String(value);
const check = (label, ok) => {
  result.observations.push({ label, ok: Boolean(ok) });
  assert(ok, label);
};
function observedTools(kind,body) {
  result.advertised ??= {};
  if(!result.advertised[kind]) result.advertised[kind]=(body.tools??[]).map(t=>typeof t.name==='string'?t.name:t.type);
}
const server = createServer(async (req,res) => {
  let kind;
  try {
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const requested=new URL(req.url,origin);
    assert.equal(requested.origin,origin);
    const path=requested.pathname;
    if (path.endsWith('/models')) {
      res.writeHead(200, { 'content-type':'application/json' });
      res.end(JSON.stringify({ data: [{ id:model }] }));
      return;
    }
    kind = path.endsWith('/messages') ? 'claude' : path.endsWith('/responses') ? 'codex' : null;
    if (req.method !== 'POST' || !kind) { res.writeHead(404); res.end(); return; }
    assert([req.headers.authorization,req.headers['x-api-key']].some(value=>value==='magpie-'+kind||value==='Bearer magpie-'+kind),'only this private Magpie token');
    const chunks = [];
    let bytes = 0;
    for await (const chunk of req) { bytes+=chunk.length; assert(bytes<6*1024*1024); chunks.push(chunk); }
    const body = JSON.parse(Buffer.concat(chunks).toString());
    assert.equal(body.model,model);
    const content = JSON.stringify(kind==='claude' ? body.messages : body.input);
    observedTools(kind,body);
    const toolOutput = kind==='claude' ? body.messages?.flatMap(message => Array.isArray(message.content) ? message.content : []).filter(block => block.type==='tool_result')
      : body.input?.filter(item => item.type==='function_call_output');
    const observed = {kind,lane:stage,at:Date.now(),capsuleFromTool:JSON.stringify(toolOutput??[]).includes(capsule),
      mentionsRelativeProgram:content.includes(relativeProgram),originalChildResult:content.includes('宿主子任务结果通知'),bytes};
    result.requests.push(observed);
    assert(result.requests.length<=90&&Date.now()<globalDeadline,'bounded isolated actual local trial');
    if(kind==='claude'){
      assert(appTrusted && [1,2].includes(stage) && projectId && childProfileId && liveTask);
      assert.equal(path,'/v1/messages');
      const rows=sql(childDispatchSql,[liveTask.taskId,projectId,cwd,app.processId,result.app.birth.startedAt]);
      observed.deterministic=serveVerifiedChild({body,res,model,capsule,profileId:childProfileId,cwd,rows,nativeIdentity,
        alreadyServed:childReplies.has(stage)});
      childReplies.set(stage,observed.deterministic);
      return;
    }
    const endpoint = localProvider + '/v1/responses';
    assert.equal(new URL(endpoint).origin,'http://127.0.0.1:3426');
    const headers = { 'content-type':'application/json' };
    const originalTools=body.tools??[];
    if(kind==='codex') {
      const omit=tool=>tool?.type==='custom' && tool.name==='apply_patch';
      body.tools=originalTools.filter(tool=>!omit(tool));
      observed.compatibilityOmitted=originalTools.filter(omit).map(tool=>tool.name);
      assert(observed.compatibilityOmitted.length<=1);
      assert(body.tools.some(tool=>tool.type==='function'&&tool.name==='exec_command'), 'Original native execution function must remain');
    }
    await forwardResponse(res, signal => fetch(endpoint, { method:'POST', headers, body:JSON.stringify(body), redirect:'error', signal }), observed, 180000);
  } catch (error) {
    result.serverError??=sanitized(error.message);
    if(!res.headersSent && kind==='claude'){
      res.writeHead(400,{'content-type':'application/json'});
      res.end(JSON.stringify({type:'error',error:{type:'invalid_request_error',message:'Isolated A23 child dispatch did not match its fixture contract'}}));
    }else{
      if(!res.headersSent)res.writeHead(500);
      res.end();
    }
  }
});
async function until(read, label, timeout=25000) {
  const limit=Math.min(globalDeadline,Date.now()+timeout);
  do {
    if (result.serverError) throw Error(result.serverError);
    const value=await read();
    if (value) return value;
    await pause(100);
  } while (Date.now()<limit);
  throw Error('Timed out: '+label);
}
async function navigate(task, label) {
  await click(row+'[data-task-id="'+task.taskId+'"]');
  await app.waitFor('document.querySelector(".agent-task-head h1")?.textContent==='+JSON.stringify(label), 12000);
}
async function input(text) {
  await click(composer);
  await app.cdp('Input.insertText',{ text });
}
async function send() { await click('.agent-task-view button[type="submit"]'); }
async function allowFixtureOnly() {
  const pending = await app.evaluate('document.querySelector(".agent-request")?.innerText??""');
  if (!pending) return;
  const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);
  assert.equal(snap.requests.length,1,'only one exact original parent native request may be approved');
  const request=snap.requests[0];
  if(!isA08OwnedApproval(request,{workingDir:cwd,scratch:root,skillName:name,entry,resource})) {
    result.unexpectedRequest={kind:request.kind,payload:request.payload};
    throw Error('Unexpected request outside the exact Skill or relative resource');
  }
  assert.equal(request.origin.taskId,liveTask.taskId);
  (result.approvedFixtureRequests??=[]).push({kind:request.kind,payload:request.payload,requestId:request.requestId});
  const button = '.agent-request [role="option"][aria-label="批准"],.agent-request [role="option"][aria-label="批准一次"]';
  if (await app.evaluate('Boolean('+selectorExpr(button)+')')) {
    await click(button);
    await click('.agent-confirm-choice');
    await app.waitFor('!document.querySelector(".agent-request")',12000);
  }
}
let phase='isolated source and identity';
let liveTask,appTrusted=false,listener=false;
const snapshot=taskId=>app.invoke('agentTasks.snapshot',taskId);
function sql(statement,args){
  const db=join(userData,'smartdd.db');
  assert.equal(realpathSync(db),db);
  const python='import json,pathlib,sys,sqlite3;d=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+"?mode=ro",uri=True);d.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in d.execute(sys.argv[2],json.loads(sys.argv[3]))]))';
  return JSON.parse(execFileSync('/usr/bin/python3',['-c',python,db,statement,JSON.stringify(args)],{encoding:'utf8',timeout:3000}));
}
const started=id=>sql('SELECT binding_id,native_id,driver_id,state_root FROM agent_bindings WHERE task_id=?',[id]);
const links=id=>sql('SELECT delegation_id,child_task_id,request_key,delivery_state FROM agent_delegations WHERE parent_task_id=? ORDER BY rowid',[id]);
const engineProcesses=pid=>sql(`SELECT DISTINCT p.pid,p.process_started_at FROM capability_runs r
  JOIN capability_run_processes p ON p.run_id=r.run_id WHERE r.owner_pid=? AND p.pid IS NOT NULL`,[pid]);
const reader=join(dirname(executable),'../Resources/native/willyou-process-identity');
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));

try{
  mkdirSync(dirname(resource),{recursive:true,mode:0o700});
  writeFileSync(entry,skillText(),{flag:'wx',mode:0o600});
  writeFileSync(resource,'console.log('+JSON.stringify(capsule)+');\n',{flag:'wx',mode:0o600});
  const neutral=join(cwd,'a23-synthetic-project.txt');
  writeFileSync(neutral,'Independent local A23 project. No production data.\n',{flag:'wx',mode:0o600});
  const stable=configSha();
  const sourceState=()=>({files:readdirSync(cwd).sort(),sha:createHash('sha256').update(readFileSync(neutral)).digest('hex')});
  const original=sourceState();
  modelState=await openPrivateModel(modelRoot);
  result.localModel=modelState.provenance;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',()=>{listener=true;resolve();});});
  app=await openElectron({executable,userData,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(hookResult,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate(`(() => {
    const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
    return [E.app.isPackaged,E.app.getPath('userData'),E.app.getPath('home'),process.env.HOME,process.execPath,process.pid];
  })()`);
  assert.deepEqual(identity,[true,userData,home,home,executable,app.processId]);
  assert(hookResult.workerInspectorFlagRemoved);
  const birth=nativeIdentity(app.processId);
  assert(birth.state==='running'&&birth.startedAt);
  result.app={identity,birth};
  appTrusted=true;
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await app.invoke('agents.refreshTools');
  const claude=await app.invoke('agents.customToolPath','claude',process.env.M14_SMOKE_CLAUDE);
  assert.equal(claude.tool.version,'2.1.326');
  const available=await app.invoke('agents.tools');
  const provider=await app.invoke('agents.saveProvider',{name:'A23 private actual local model',preset:'magpie',
    endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
  const profiles={};
  for(const k of ['codex','claude']){
    const tool=available.find(row=>row.kind===k&&row.installed);
    assert.equal(tool?.version,k==='codex'?'0.169.0':'2.1.326');
    profiles[k]=await app.invoke('agents.save',{name:k==='claude'?peer:'A23 Codex parent',toolId:tool.id,source:'provider',
      providerId:provider.id,models:[model],defaultModel:model,isDefault:k==='codex'});
  }
  const project=await app.invoke('projects.create',{name:'A23 isolated collaboration Skill',aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  projectId=project.id;
  childProfileId=profiles.claude.id;
  await click('[data-testid="nav-settings"]');
  const feature='[data-testid="m14-toggle"]';
  if(!(await app.evaluate(selectorExpr(feature)+'?.innerText.includes("已开启")')))await click(feature);
  await app.waitFor(selectorExpr(feature)+'?.innerText.includes("已开启")',12000);
  phase='select and manage exact synthetic source from real Skills view';
  await click('[data-testid="nav-home"]');
  await click('[data-testid="nav-apps"]');
  await click('button.m10-nav','技能');
  await app.waitFor('Array.from(document.querySelectorAll("button.m13-cap")).some(el=>el.innerText.includes('+JSON.stringify(name)+'))',18000);
  await click('button.m13-cap',name);
  await click('[role=dialog] button.m10-button.primary','纳管');
  const managed=await until(async()=>{const inv=await app.invoke('capabilities.managedList');
    return inv.items?.find(skill=>skill.name===name&&skill.managed);},'exact source managed');
  result.managed={name:managed.name,hashes:stable};
  await app.screenshot(join(out,'01-managed-collaboration-skill.png'));
  await click('[role=dialog] button[aria-label="关闭"]');
  await click('[data-testid="nav-home"]');
  result.fresh=[];
  for(const lane of [1,2]){
    stage=lane;
    phase='fresh task '+lane+' actual selected collaboration Skill';
    const label='A23 fresh native parent '+lane;
    liveTask=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title:label,
      profileId:profiles.codex.id,model,tier:'ask'});
    await navigate(liveTask,label);
    await input('Respond exactly '+warmMarker+'. Do not call tools or modify files.');
    await send();
    await until(async()=>{
      const s=await snapshot(liveTask.taskId);
      return !s.run?.busy&&s.run?.catalog?.skills.some(row=>row.name.includes(name))&&
        s.items.some(item=>item.type==='assistant_message'&&item.payload?.text?.includes(warmMarker));
    },'a fresh real native catalog, before selecting '+name,120000);
    const toggle='[data-testid="agent-delegation-toggle"]';
    await click(toggle);
    await app.waitFor(selectorExpr(toggle)+'?.getAttribute("aria-pressed")==="true"',6000);
    await input('$'+name.slice(0,-4));
    const option='.agent-menu [role="option"]';
    await app.waitFor('Array.from(document.querySelectorAll('+JSON.stringify(option)+')).some(e=>e.innerText.includes('+JSON.stringify(name)+'))',14000);
    await app.screenshot(join(out,'02-lane-'+lane+'-real-skill-menu.png'));
    await click(option,name);
    const selectedText=await app.evaluate(selectorExpr(composer)+'?.value');
    assert(selectedText.includes(name));
    await app.cdp('Input.insertText',{text:' Perform one safe local collaboration rehearsal by following the selected Skill. Use its exact resource and one authorized host delegation. Do not delegate other tasks or modify files.'});
    const userInput=await app.evaluate(selectorExpr(composer)+'?.value');
    assert(userInput.includes(name)&&!userInput.includes(capsule),'synthetic proof must not be in our prompt');
    await send();
    const resultScope={items:null,proof:null};
    await until(async()=>{
      await allowFixtureOnly();
      const current=await snapshot(liveTask.taskId);
      assert.equal(current.cwd,cwd);
      // A completed native receipt is emitted after the delegation transaction commits.
      // Sample SQLite after the snapshot so both observations can see that commit.
      const rows=links(liveTask.taskId);
      const proof=correlate({items:current.items,rows,expectedProfile:profiles.claude.id,capsule});
      for(const row of rows){
        const child=await snapshot(row.child_task_id);
        assert.equal(child.requests.length,0,'the tiny synthetic child should only reply and never request approval');
      }
      if(!proof||current.run?.busy||current.queuedTotal)return false;
      resultScope.items=current.items;resultScope.proof=proof;
      return true;
    },'selected Skill really reads resource, queries native targets, delegates, then receives the child result',190000);
    const {proof,items}=resultScope;
    const parentBinding=started(liveTask.taskId);
    const childBinding=started(proof.childId);
    assert.equal(parentBinding.length,1);assert.equal(childBinding.length,1);
    assert.equal(parentBinding[0].driver_id,'codex-app-server');
    assert.equal(childBinding[0].driver_id,'claude-sdk');
    assert(parentBinding[0].native_id&&childBinding[0].native_id);
    const accepted=sql("SELECT turn_id,native_turn_id,status,input_ref FROM agent_turns WHERE task_id=? AND turn_id=? AND source_kind='user'",[liveTask.taskId,proof.delegated.turnId]);
    assert.equal(accepted.length,1);
    assert.equal(accepted[0].status,'completed');
    const stored=JSON.parse(accepted[0].input_ref).text;
    assert(stored.includes(name)&&!stored.includes(capsule));
    const attemptRows=sql('SELECT * FROM agent_delegation_attempts WHERE delegation_id=? ORDER BY ordinal',[proof.delegated.receipt.delegationId]);
    const childTurns=sql('SELECT * FROM agent_turns WHERE task_id=? ORDER BY accepted_at',[proof.childId]);
    const childItems=sql('SELECT * FROM agent_items WHERE task_id=? ORDER BY ordinal',[proof.childId]);
    const deliveries=sql("SELECT * FROM agent_turns WHERE task_id=? AND source_kind='notification' ORDER BY accepted_at",[liveTask.taskId]);
    const childWire=loadNativeChildFrames({userData,cwd,binding:childBinding[0]});
    const provenance=verifyChildProvenance({proof,capsule,attemptRows,childTurns,childItems,deliveries,binding:childBinding[0],childWire});
    const controlledChild=childReplies.get(lane);
    assert(controlledChild);
    assert.equal(controlledChild.delegationId,proof.delegated.receipt.delegationId);
    assert.equal(controlledChild.childId,proof.childId);
    assert.equal(controlledChild.attemptId,provenance.attemptId);
    assert.equal(controlledChild.inputSha256,createHash('sha256').update(JSON.parse(childTurns[0].input_ref).text).digest('hex'));
    assert.equal(provenance.childEchoedMarker,true);
    assert.equal(proof.source.payload.summary,capsule);
    assert(items.some(row=>row.itemId===proof.resourceItem));
    assert(result.requests.some(row=>row.lane===lane&&row.kind==='codex'&&row.capsuleFromTool));
    assert(result.requests.some(row=>row.lane===lane&&row.kind==='codex'&&row.originalChildResult&&row.upstreamCompleted),
      'the original child notification was exchanged with the actual local model');
    assert.deepEqual(configSha(),stable);
    assert.deepEqual(sourceState(),original);
    result.fresh.push({lane,taskId:liveTask.taskId,selectedText,parentBinding:parentBinding[0],childBinding:childBinding[0],proof,accepted,provenance});
    await app.screenshot(join(out,'03-lane-'+lane+'-real-child-result.png'));
  }
  const [one,two]=result.fresh;
  assert.notEqual(one.taskId,two.taskId);
  assert.notEqual(one.parentBinding.native_id,two.parentBinding.native_id);
  assert.notEqual(one.proof.childId,two.proof.childId);
  assert.notEqual(one.childBinding.native_id,two.childBinding.native_id);
  assert.equal(childReplies.size,2);
  result.status='passed-initial';
}catch(error){
  result.phase=phase;result.error=sanitized(error.stack??error);
  if(appTrusted)try{
    result.visible=await app.evaluate('document.body.innerText.slice(-6500)');
    await app.screenshot(join(out,'99-failure.png'));
  }catch{}
}finally{
  if(app&&!appTrusted)try{result.unverifiedOwnAppExit=await app.crash();}catch(error){result.exitError=sanitized(error);}
  if(appTrusted){
    try{
      if(liveTask&&result.status!=='passed-initial')await app.invoke('agentTasks.stop',liveTask.taskId,true);
      const start=Date.now(),end=start+18000;
      while(Date.now()<end){
        const state=await app.invoke('agentTasks.list');
        if(!state.some(row=>['working','waiting'].includes(row.status)))break;
        await pause(100);
      }
      const observed=engineProcesses(app.processId);
      const ids=[result.app.birth,...observed.map(row=>({pid:row.pid,startedAt:row.process_started_at}))];
      await app.mainEvaluate(`(() => {
        const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(E.app.getPath('userData')!==${JSON.stringify(userData)}||process.pid!==${app.processId})throw Error('Wrong private App');
        setTimeout(()=>E.app.quit(),50);return true;
      })()`);
      result.exit=await app.waitForExit(23000);
      result.exactProcessesAfter=ids.map(id=>({id,after:nativeIdentity(id.pid)}));
    }catch(error){
      result.exitError=sanitized(error);
      try{result.forcedExit=await app.crash();}catch{}
    }
    result.rendererErrors=app.rendererErrors.map(sanitized);
    writeFileSync(join(out,'app.log'),app.logs(),{mode:0o600});
  }
  if(listener){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.listenerClosed=!server.listening;
  if(modelState)try{result.modelExit=await modelState.stop();}catch(error){result.modelExitError=String(error);}
  result.passed=Boolean(result.status==='passed-initial'&&result.exit?.code===0&&result.exit.signal===null&&
    result.rendererErrors?.length===0&&result.modelExit?.code===0&&result.listenerClosed&&result.exactProcessesAfter?.length>=5&&
    result.exactProcessesAfter.every(({id,after})=>id.startedAt&&!(after.state==='running'&&after.startedAt===id.startedAt)));
  writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({passed:result.passed,out,error:result.error,phase,exit:result.exit,modelExit:result.modelExit}));
}
if(!result.passed)process.exitCode=2;
