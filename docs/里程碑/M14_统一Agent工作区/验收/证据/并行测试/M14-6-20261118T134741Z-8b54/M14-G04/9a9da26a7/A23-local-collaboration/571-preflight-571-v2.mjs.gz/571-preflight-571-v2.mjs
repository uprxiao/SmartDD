import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync, readdirSync} from 'node:fs';
import {join} from 'node:path';
import {correlate,relativeProgram,toolKind} from './proof.mjs';

const attempt = '/private/tmp/willyou-m14-stage6.WRvdST/g04/attempt-571';
const readJson = path => JSON.parse(readFileSync(path, 'utf8'));
const result = readJson(join(attempt,'result.json'));
const runtime = join(attempt,'runtime-JhAANn');
const root = join(runtime,'data');
const cwd = join(runtime,'work');
const sql = query => JSON.parse(execFileSync('/usr/bin/sqlite3',
  ['-json','file:' + join(root,'smartdd.db') + '?mode=ro&immutable=1',query], {encoding:'utf8'}));
assert.equal(result.passed,false);
assert.match(result.error,/one persisted delegation in this parent[\s\S]*0 !== 1/);
assert.match(result.visible,/宿主子任务 · A23 Local Team Rehearsal[\s\S]*排队中/);
assert(result.exactProcessesAfter.every(item=>item.after.state==='stopped')&&result.listenerClosed);
assert.equal(result.exit.code,0);
assert.equal(result.modelExit.code,0);
const links = sql('SELECT * FROM agent_delegations');
assert.equal(links.length,1);
const [accepted] = links;
assert.equal(accepted.delivery_state,'canceled','the negative fixture canceled the already accepted child');
const {parent_task_id:taskId,child_task_id:childId}=accepted;
assert.match(taskId,/^[0-9a-f-]{36}$/);
const items = sql("SELECT * FROM agent_items WHERE task_id='"+taskId+"' ORDER BY ordinal").map(row=>({
  ...row,turnId:row.turn_id,itemId:row.item_id,payload:JSON.parse(row.payload_ref)
}));
const command = items.find(item=>item.type==='command_execution');
assert(command.payload.command.includes(relativeProgram));
const capsule=String(command.payload.output).match(/A23_ROLE_[a-f0-9]{32}/)[0];
const targets=items.find(item=>toolKind(item.payload)==='wy_targets');
const delegation=items.find(item=>toolKind(item.payload)==='wy_delegate');
const receipt=JSON.parse(delegation.payload.output.content[0].text);
assert.equal(receipt.delegationId,accepted.delegation_id);
assert.equal(receipt.childTaskId,childId);
assert.equal(receipt.state,'queued');
const expectedProfile=delegation.payload.input.profileId;
const verifiedTarget=JSON.parse(targets.payload.output.content[0].text).targets.find(r=>r.profileId===expectedProfile);
assert.equal(verifiedTarget.revision,delegation.payload.input.profileRevision);
assert.equal(verifiedTarget.name,'A23 Claude peer');
assert.equal(verifiedTarget.available,true);
assert.equal(items.filter(item=>toolKind(item.payload)==='wy_delegate').length,1);
assert.equal(result.requests.length,5);
assert.equal(result.requests.filter(row=>row.kind==='claude').length,0);
assert(result.requests.some(row=>row.capsuleFromTool));

const codexDir=join(root,'agents','codex');
const appServerAccount=readdirSync(codexDir).find(dir=>readdirSync(join(codexDir,dir)).includes('sessions'));
const sessionRoot=join(codexDir,appServerAccount,'sessions','2026','11','19');
const rolloutPath=join(sessionRoot,readdirSync(sessionRoot).find(filename=>filename.startsWith('rollout-')));
const frames=readFileSync(rolloutPath,'utf8').trim().split('\n').map(line=>JSON.parse(line).payload);
const call=frames.find(row=>row.type==='function_call'&&row.name==='wy_delegate');
const reply=frames.find(row=>row.type==='function_call_output'&&row.call_id===call.call_id);
const wireJson=JSON.parse(reply.output.slice(reply.output.indexOf('\nOutput:\n')+'\nOutput:\n'.length));
assert.deepEqual(wireJson,receipt);
assert.deepEqual(JSON.parse(call.arguments),delegation.payload.input);

const untilStart='    await until(async()=>{\n';
const untilEnd="    },'selected Skill really reads resource, queries native targets, delegates, then receives the child result',190000);";
function extractDriverPoll(file) {
  const source=readFileSync(new URL(file,import.meta.url),'utf8');
  const stop=source.indexOf(untilEnd);
  assert(stop>0);
  const start=source.lastIndexOf(untilStart,stop);
  assert(start>=0);
  return source.slice(start+untilStart.length,stop);
}
const original=extractDriverPoll('./a23-local-packaged.mjs');
const revised=extractDriverPoll('./a23-local-packaged-v2.mjs');
const originallyQueued={...accepted,delivery_state:'queued'};
const syntheticNotification={type:'notification',payload:{childTaskId:childId,status:'completed',summary:capsule}};
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
async function poll(code, options={}) {
  const resultScope={}, timeline=[];
  let committed=false;
  const allowFixtureOnly=async()=>{timeline.push('allow');committed=true;};
  const snapshot=async id=>{
    timeline.push(id===taskId?'parent snapshot':'child snapshot');
    if(id===childId)return {requests:options.childRequests??[]};
    assert.equal(id,taskId);
    assert.equal(committed,true);
    return {cwd:options.parentCwd??cwd, items:options.items??items, run:{busy:options.busy??false},queuedTotal:options.queuedTotal??0};
  };
  const links=id=>{
    assert.equal(id,taskId);
    timeline.push('sql');
    return committed?(options.rows??[originallyQueued]):[];
  };
  const run=new AsyncFunction('assert','allowFixtureOnly','snapshot','links','liveTask','cwd','correlate','profiles','capsule','resultScope',code);
  const value=await run(assert,allowFixtureOnly,snapshot,links,{taskId},cwd,correlate,{claude:{id:expectedProfile}},capsule,resultScope);
  return {value,resultScope,timeline};
}
await assert.rejects(()=>poll(original),/one persisted delegation in this parent/);
const queued=await poll(revised);
assert.equal(queued.value,false);
assert.deepEqual(queued.timeline,['allow','parent snapshot','sql','child snapshot']);
const completed={items:[...items,syntheticNotification],rows:[{...accepted,delivery_state:'delivered'}]};
assert.equal((await poll(revised,completed)).resultScope.proof.childId,childId);
assert.equal((await poll(revised,{...completed,busy:true})).value,false);
assert.equal((await poll(revised,{...completed,queuedTotal:1})).value,false);
assert.equal((await poll(revised,{...completed,items})).value,false);
await assert.rejects(()=>poll(revised,{...completed,rows:[]}),/one persisted delegation in this parent/);
await assert.rejects(()=>poll(revised,{...completed,rows:[...completed.rows,...completed.rows]}),/one persisted delegation in this parent/);
await assert.rejects(()=>poll(revised,{...completed,childRequests:[{}]}),/must only|should only reply/);
await assert.rejects(()=>poll(revised,{...completed,parentCwd:'/non-isolated/other'}),{code:'ERR_ASSERTION'});
console.log(JSON.stringify({
  acceptedOriginal:{delegationId:accepted.delegation_id,childTaskId:childId,requestKey:accepted.request_key,
    status:receipt.state, persistedAfterFixtureStop:accepted.delivery_state}, rolloutMatchesSql:true,
  exactOldCallbackFailed:true,newCallbackWaitsForActualChild:true,offlinePositive:1,pending:4,negatives:4,
  completionFixture:'synthetic notification added only in offline check',
  appLaunched:false, modelLaunched:false, portOpened:false
},null,2));
