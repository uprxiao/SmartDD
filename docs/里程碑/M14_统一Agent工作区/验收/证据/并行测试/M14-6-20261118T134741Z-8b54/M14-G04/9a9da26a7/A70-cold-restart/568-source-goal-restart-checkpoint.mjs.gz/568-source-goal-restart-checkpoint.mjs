import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,realpathSync} from 'node:fs';
import {join} from 'node:path';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const executable=join(base,'package/mac-arm64/WillYou.app/Contents/MacOS/WillYou');
export const appAsar=join(base,'package/mac-arm64/WillYou.app/Contents/Resources/app.asar');
const runPath=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-\d{3}\/runtime-[A-Za-z0-9]+$/;
const id=/^[a-f0-9-]{36}$/;
const digest=source=>createHash('sha256').update(source).digest('hex');
const quoted=JSON.stringify;

export function findFinishSite(source){
  const lines=source.split('\n').map(line=>line.trim());
  const original=lines.map((line,index)=>line==='async finishChildOwned(row) {'?index:-1).filter(index=>index>=0);
  assert.equal(original.length,1,'exact function present in compiled Main');
  const from=original[0], next=lines.findIndex((line,index)=>index>from&&line==='autoGoalIntent(taskId) {');
  assert(next>from);
  const exact='this.d.store.tx(() => {';
  const matches=lines.slice(from,next).map((line,offset)=>{
    const index=from+offset;
    return line===exact&&lines[index-1]?.startsWith('const result2 = { sourceKind: "child_result", delegationId: row.delegation_id,')&&
      lines[index+1]?.startsWith('const resultItemId = this.d.store.addHostItem(row.parent_task_id, null, "notification", result2);')?index:-1;
  }).filter(index=>index>=0);
  assert.equal(matches.length,1,'unambiguous child result immediately before its production transaction');
  return {lineNumber:matches[0],statement:exact};
}

export function exactPackagedSite(expectedAsar){
  assert.match(expectedAsar,/^[a-f0-9]{64}$/);
  const archive=readFileSync(appAsar);
  assert.equal(digest(archive),expectedAsar);
  const headerSize=archive.readUInt32LE(4),size=archive.readUInt32LE(12);
  assert(archive.readUInt32LE(0)===4&&size<=headerSize&&headerSize<4*1024**2);
  const tree=JSON.parse(archive.subarray(16,16+size).toString());
  const row=tree.files.out.files.main.files['index.js'];
  assert(row&&!row.unpacked);
  const start=8+headerSize+Number(row.offset);
  assert(Number.isSafeInteger(start)&&start>headerSize&&start+row.size<=archive.length);
  const main=archive.subarray(start,start+row.size);
  return {asarSha256:expectedAsar,mainSha256:digest(main),site:findFinishSite(main.toString())};
}

export function checkpointCondition({runtime,cwd,parent,child,pid,goal,time=16000}){
  assert.match(runtime,runPath);
  assert.equal(realpathSync(runtime),runtime);
  assert.equal(cwd,join(runtime,'project'));
  assert.equal(realpathSync(cwd),cwd);
  for(const key of [parent,child,goal.bindingId])assert.match(key,id);
  assert.notEqual(parent,child);
  assert(Number.isSafeInteger(pid)&&pid>1);
  assert(Number.isSafeInteger(time)&&time>=0&&time<=16000);
  assert(Number.isSafeInteger(goal.revision)&&goal.revision>0);
  assert.equal(goal.objective,'A70_AUTOMATIC_WAIT_FOR_MY_TWO_CHILDREN');
  const marker=join(runtime,'a70-cold-goal-checkpoint.json');
  const expected={runtime,cwd,parent,child,pid,goal:{bindingId:goal.bindingId,revision:goal.revision,objective:goal.objective}};
  return {marker,condition:'(()=>{const x='+quoted(expected)+';'+
    'if(process.pid!==x.pid||row.parent_task_id!==x.parent||row.child_task_id!==x.child||target.parentCwd!==x.cwd||target.strategy!=="serial"||result2.status!=="completed")return false;'+
    'const g=this.d.store.goal(x.parent);if(g?.status!=="paused"||g.pausedReason!=="waiting_children"||g.bindingId!==x.goal.bindingId||g.revision!==x.goal.revision||g.objective!==x.goal.objective)return false;'+
    'const fs=process.getBuiltinModule("fs"),file='+quoted(marker)+';if(fs.existsSync(file))return false;'+
    'fs.writeFileSync(file,JSON.stringify({pid:x.pid,at:Date.now(),goal:g,child:x.child,parent:x.parent,attemptId:a.attempt_id,childTurn:turn.turn_id,childStatus:turn.status,nativeTurn:turn.native_turn_id}),{flag:"wx",mode:0o600});'+
    'Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,'+time+');return false;})()'};
}

/** Reuses the A66 same-App inspector technique. This arms only; call after verifying isolated App. */
export async function armGoalRestart(app,proof,options){
  assert.equal(app.processId,options.pid);
  const {condition,marker}=checkpointCondition(options);
  const expected=[true,join(options.runtime,'data'),join(options.runtime,'home'),executable,options.pid];
  const {lineNumber,statement}=proof.site;
  const command='(async()=>{const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");'+
    'const identity=[E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];'+
    'if(JSON.stringify(identity)!=='+quoted(quoted(expected))+'||globalThis.__a70ColdState)throw Error("Wrong App or already armed");'+
    'const session=new (process.getBuiltinModule("inspector").Session)();session.connect();'+
    'const post=(name,args={})=>new Promise((resolve,reject)=>session.post(name,args,(err,result)=>err?reject(err):resolve(result)));'+
    'const urls=new Set();session.on("Debugger.scriptParsed",e=>urls.add(e.params.url));'+
    'await post("Debugger.enable");const hits=[...urls].filter(url=>url.endsWith("/Contents/Resources/app.asar/out/main/index.js"));'+
    'if(hits.length!==1){await post("Debugger.disable");session.disconnect();throw Error("Exact packaged main absent");}'+
    'const armed=await post("Debugger.setBreakpointByUrl",{url:hits[0],lineNumber:'+lineNumber+',condition:'+quoted(condition)+'});'+
    'if(armed.locations.length!==1||armed.locations[0].lineNumber!=='+lineNumber+'){await post("Debugger.disable");session.disconnect();throw Error("Unexpected breakpoint relocation");}'+
    'globalThis.__a70ColdState=session;return {...armed,url:hits[0]};})()';
  const result=await app.mainEvaluate(command);
  assert(result.url.endsWith('/app.asar/out/main/index.js'));
  assert.equal(result.locations[0].lineNumber,lineNumber);
  return {...result,marker,statement,lineNumber};
}

export function assertBeforeResume({marker,goal,pause,resumes,resultCount,child,expected,pid}){
  assert.equal(marker.pid,pid);
  assert.equal(marker.parent,expected.parent);
  assert.equal(marker.child,expected.child);
  assert.equal(child.taskId,expected.child);
  assert.equal(marker.childTurn,child.turnId);
  assert.equal(marker.nativeTurn,child.nativeTurnId);
  assert.equal(marker.childStatus,child.status);
  assert.equal(child.status,'completed');
  assert.equal(goal.status,'paused');
  assert.equal(goal.pausedReason,'waiting_children');
  assert.equal(goal.bindingId,expected.bindingId);
  assert.equal(goal.revision,expected.revision);
  assert.equal(pause.bindingId,goal.bindingId);
  assert.equal(pause.revision,goal.revision);
  assert.equal(pause.native.status,'paused');
  assert.equal(pause.native.threadId,expected.nativeId);
  assert.equal(resumes,0);
  assert.equal(resultCount,0,'the original result must not yet be persisted/dispatched at the break');
}
