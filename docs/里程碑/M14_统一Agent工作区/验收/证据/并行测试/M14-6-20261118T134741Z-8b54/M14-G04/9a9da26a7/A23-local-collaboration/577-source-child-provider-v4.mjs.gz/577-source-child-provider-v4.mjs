import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {sendAssistant} from '../../a60-prep/provider-contract.mjs';

export const childDispatchSql = `SELECT d.delegation_id, d.child_task_id, a.attempt_id, d.target_json,
  a.input_ref AS attempt_input, t.input_ref AS dispatch_input, r.run_id,
  r.pid, r.process_started_at, r.owner_started_at
  FROM agent_delegations d
  JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id
  JOIN agent_turns t ON t.turn_id=a.child_turn_id AND t.task_id=d.child_task_id
  JOIN tasks child ON child.id=d.child_task_id
  JOIN capability_runs r ON r.run_id=t.run_id AND r.task_id=d.child_task_id AND r.project_id=child.project_id
  WHERE d.parent_task_id=? AND child.project_id=? AND child.cwd=?
    AND d.access='write' AND d.delivery_state='running'
    AND a.kind='initial' AND a.ordinal=1 AND a.notified_at IS NULL
    AND t.source_kind='delegation' AND t.status IN ('dispatching','started')
    AND r.driver_id='claude-sdk' AND r.owner_pid=? AND r.owner_started_at=? AND r.state='active' AND r.revocation_state='open' AND r.ended_at IS NULL`;

function presentInput(messages, exactInput) {
  const user = Array.isArray(messages) ? messages.findLast(row=>row.role==='user') : null;
  const parts = typeof user?.content==='string' ? [{type:'text',text:user.content}] : user?.content;
  if (!Array.isArray(parts) || parts.some(part=>part.type==='tool_result')) return false;
  return parts.filter(part=>part.type==='text' && typeof part.text==='string' &&
    part.text.trimEnd().endsWith(exactInput) &&
    (part.text.trimEnd()===exactInput || part.text.trimEnd().slice(0,-exactInput.length).endsWith('\n'))).length===1;
}

export function serveVerifiedChild({body,res,model,capsule,profileId,cwd,rows,nativeIdentity,alreadyServed}) {
  assert.equal(body.model,model);
  assert.match(capsule,/^A23_ROLE_[a-f0-9]{32}$/);
  assert.equal(alreadyServed,false,'only one Claude provider reply for the original child run in each lane');
  assert.equal(rows.length,1,'only an exact persisted active A23 child dispatch can reach the deterministic endpoint');
  const [row]=rows;
  assert(Number.isSafeInteger(row.pid) && row.pid>0);
  const birth=nativeIdentity(row.pid);
  assert.equal(birth.state,'running');
  assert.equal(birth.startedAt,row.process_started_at);
  const target=JSON.parse(row.target_json);
  assert.equal(target.profile.profileId,profileId);
  assert.equal(target.profile.driverId,'claude-sdk');
  assert.equal(target.parentCwd,cwd);
  assert.equal(target.actualAccess,'write');
  assert.equal(target.strategy,'serial');
  assert.equal(target.tier,'ask');
  const dispatchInput=JSON.parse(row.dispatch_input).text;
  const attempt=JSON.parse(row.attempt_input);
  assert.equal(attempt.sourceKind,'delegation');
  assert(attempt.text.includes(capsule));
  assert(dispatchInput.startsWith('宿主委派（来源 delegation，不是新的真人授权）。'));
  assert(dispatchInput.endsWith('\n\n'+attempt.text));
  assert(presentInput(body.messages,dispatchInput),'the native request must contain the exact persisted child input');
  sendAssistant(res,{kind:'claude',model,text:capsule});
  return {reply:'isolated deterministic Anthropic text response',delegationId:row.delegation_id,childId:row.child_task_id,
    attemptId:row.attempt_id,runId:row.run_id,pid:row.pid,startedAt:birth.startedAt,
    inputSha256:createHash('sha256').update(dispatchInput).digest('hex')};
}
