import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {codexToolCall,codexToolReply,listedAvailable} from '../../../g03/prep-next/a26-recheck/codex-mcp.mjs';
import {claudeReply,latestUserText} from '../../../g03/prep-next/a32-recheck/protocol.mjs';

export const models={parent:'a70-parent',writer:'a70-child-writer',reader:'a70-child-reader',independent:'a70-unrelated-goal'};
export const input={warm:'A70_WARM',initial:'A70_PARENT_DELEGATES_WHOLE_CONTRACT',
  independent:'A70_INDEPENDENT_ACTIVE_GOAL',objective:'A70_AUTOMATIC_WAIT_FOR_MY_TWO_CHILDREN'};
export const markers={writer:'A70_WRITER_STARTED',reader:'A70_READONLY_CHILD_STARTED',
  warm:'A70_WARM_DONE',parent:'A70_PARENT_ORIGINAL_COMPLETED',writerDone:'A70_SHARED_WRITE_PROOF',
  readerDone:'A70_READONLY_BASELINE_PROOF',goalDone:'A70_ORIGINAL_GOAL_COMPLETED'};
export const modes=['normal','independent','user-stop','child-cancel','child-failed','child-approval-61'];
export const engineFor=(parent,role)=>role==='parent'?parent:role==='writer'&&parent==='codex'?'claude':'codex';
export function profileFixture(parent,mode,origin){
  const roles=['parent','writer','reader',...(mode==='independent'?['independent']:[])];
  return roles.map(role=>({role,kind:engineFor(parent,role),provider:{name:'A70 private synthetic loopback '+role,preset:'magpie',
    endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:models[role],name:models[role]}]}}));
}
export const claudeGoalDirective=objective=>'A session-scoped Stop hook is now active with condition: "'+objective+'". Briefly acknowledge the goal';
export function isNativeClaudeGoalDirective(body,objective){
  const content=(body.messages??[]).findLast(row=>row.role==='user')?.content;
  if(!Array.isArray(content))return false;
  const command=['<command-name>/goal</command-name>','<command-message>goal</command-message>',
    '<command-args>'+objective+'</command-args>'].join('\n');
  const acknowledged='<local-command-stdout>Goal set: '+objective+'</local-command-stdout>';
  return content.some((item,index)=>item.type==='text'&&item.text?.startsWith(claudeGoalDirective(objective))&&
    content[index-1]?.type==='text'&&content[index-1]?.text?.trim()===acknowledged&&
    content[index-2]?.type==='text'&&content[index-2]?.text?.trim().split(/\r?\n/).map(line=>line.trim()).join('\n')===command);
}

export const claudeJudgeSystem='You are evaluating a stop-condition hook in Claude Code.';
export const claudeJudgeQuestion='Based on the conversation transcript above, has the following stopping condition been satisfied? Answer based on transcript evidence only.';
export function isClaudeGoalJudge(body,objective){
  const system=typeof body.system==='string'?body.system:
    Array.isArray(body.system)?body.system.filter(row=>row.type==='text').map(row=>row.text).join('\n'):'';
  if(!system.includes(claudeJudgeSystem)||(body.tools??[]).length!==0)return false;
  const lines=latestUserText('claude',body).trim().split(/\r?\n/).map(line=>line.trim());
  return lines[0]===claudeJudgeQuestion&&lines.includes('Condition: '+objective);
}
export function providerFailure(native){
  const error={type:'invalid_request_error',message:'A70 deliberate isolated writer failure'};
  return native==='claude'?{type:'error',error}:{error:{...error,code:'invalid_request_error'}};
}
const inputDigest=(native,body)=>createHash('sha256').update(JSON.stringify(native==='claude'?body.messages:body.input)).digest('hex');
const boundedDelay=(ms)=>new Promise(resolve=>setTimeout(resolve,ms));
export const childTitle={writer:'A70 original writing child',reader:'A70 original readonly child'};
export const writerFile='a70-owned-child-proof.txt';
export const baselineFile='a70-baseline.txt';
export const baselineContent='A70_FIXED_SOURCE_WITNESS';
const gate=()=>{let resolve;return {promise:new Promise(done=>{resolve=done;}),release:()=>resolve()};};
const uuid=/^[0-9a-f-]{36}$/;

export function parseChildNotice(kind,body){
  const lines=latestUserText(kind,body).trim().split(/\r?\n/)
    .filter(line=>line.startsWith('宿主子任务结果通知'));
  if(!lines.length)return null;
  assert.equal(lines.length,1,'one exact original input notification');
  const hit=/^宿主子任务结果通知（来源 child_result，不是新的真人授权）。结果引用 [0-9a-f-]{36}；子任务 [^\r\n]+ \/ ([0-9a-f-]{36})，attempt (\d+) 状态 (completed|failed|canceled)。正文通过 wy_observe 领取；此通知不含新授权。$/.exec(lines[0]);
  assert(hit,'unrecognized actual child result template');
  return {childTaskId:hit[1],attempt:Number(hit[2]),status:hit[3]};
}

export function pendingChildDecision(text,file){
  return text?.includes(file)&&text.includes(markers.writerDone);
}

function toolResponse(provider,body,name,args){
  if(provider==='codex')return codexToolCall(body,name,args);
  const found=(body.tools??[]).filter(row=>row.name===name||row.name.endsWith('__'+name));
  assert.equal(found.length,1,'exact advertised Claude tool '+name);
  return {tool:found[0],args,callId:'toolu_'+randomUUID().replaceAll('-','')};
}
function mcpResult(kind,body,id){
  return kind==='codex'?codexToolReply(body,id):JSON.parse(claudeReply(body,id));
}
function stdout(body,id) {
  const rows=(body.input??[]).filter(part=>part.type==='function_call_output'&&part.call_id===id);
  assert.equal(rows.length,1,'one exact natural command result');
  return typeof rows[0].output==='string'?rows[0].output:JSON.stringify(rows[0].output);
}

export function createFlow({kind,mode,cwd,profiles}){
  assert(['codex','claude'].includes(kind)&&modes.includes(mode));
  const state={parentStep:'targets',seen:[],calls:{},receipts:{},children:{
    writer:{gate:gate(),seen:false,step:0},reader:{gate:gate(),seen:false,step:0}},independentGate:gate(),parentGate:gate(),closing:false};
  const tool=(native,body,name,args,key)=>{
    const call=toolResponse(native,body,name,args);
    if(key)state.calls[key]=call.callId;
    return {type:name,call};
  };
  async function next(native,body){
    if(state.closing)return {type:'fixture-cleanup',answer:'A70 isolated cleanup'};
    const latest=latestUserText(native,body).trim();
    if(latest.endsWith(input.warm))return {type:'warm',answer:markers.warm};
    if(body.model===models.independent){
      assert.equal(native,'codex');
      assert(!state.independentSeen,'independent task should retain its original pending turn during the family test');
      state.independentSeen=true;
      state.independentAt=Date.now();
      await state.independentGate.promise;
      return {type:'independent-result',answer:'A70 unrelated isolated fixture done'};
    }
    const role=Object.keys(state.children).find(role=>body.model===models[role]);
    if(role){
      assert.equal(native,engineFor(kind,role));
      const child=state.children[role];
      if(role==='writer'&&mode==='child-failed'){
        assert(latest.endsWith(markers.writer),'fault must belong to the exact original child input');
        const digest=inputDigest(native,body);
        if(!child.failureReceipt){
          child.failureReceipt={digest,requests:0};
          child.seen=true;child.at=Date.now();
        }
        assert.equal(digest,child.failureReceipt.digest,'native retry must contain the exact original child input');
        child.failureReceipt.requests++;
        assert(child.failureReceipt.requests<=12,'unexpected repeat route before native non-retryable failure');
        await child.gate.promise;
        if(state.closing)return {type:'canceled-fixture-cleanup',answer:'A70 child failure cleanup'};
        return {type:'native-400',error:400,proof:{attempt:child.failureReceipt.requests,digest}};
      }
      if(child.step===0){
        assert(latest.includes(markers[role]));
        child.step=1;child.seen=true;child.at=Date.now();
        await child.gate.promise;
        if(state.closing||child.canceled)return {type:'canceled-fixture-cleanup',answer:'A70 child cancel cleanup'};
        if(role==='writer'&&mode!=='child-approval-61'){
          child.completedWithoutTool=true;
          return {type:'writer-complete-without-tool',answer:markers.writerDone};
        }
        const command=role==='reader'?'/bin/cat '+baselineFile:
          "printf '%s\\n' '"+markers.writerDone+"' > "+writerFile+" && pwd -P && printf A70_WRITE_ACK";
        assert.equal(native,'codex','the only fixture write command belongs to the explicit native Codex approval lane');
        const args={cmd:command,workdir:cwd,max_output_tokens:300};
        if(role==='writer'&&mode==='child-approval-61'){
          args.sandbox_permissions='require_escalated';
          args.justification='Only the isolated write-child fixture after its explicit approval';
        }
        return tool(native,body,'exec_command',args,role);
      }
      assert.equal(child.step,1);
      child.step=2;
      const output=native==='claude'?claudeReply(body,state.calls[role]):stdout(body,state.calls[role]);
      assert(output.includes(role==='reader'?baselineContent:'A70_WRITE_ACK'));
      if(role==='writer')assert(output.includes(cwd));
      child.commandReceived=output.slice(0,720);
      return {type:role+'-complete',answer:markers[role+'Done']};
    }
    assert.equal(body.model,models.parent);
    assert.equal(native,kind);
    if(native==='claude'&&isClaudeGoalJudge(body,input.objective)){
      const complete=state.seen.length===2;
      const answer={ok:complete,reason:complete?'Both original child results have been received in the transcript.':'The two original child result receipts have not yet been observed.'};
      (state.goalJudges??=[]).push({at:Date.now(),...answer,seen:state.seen.length});
      return {type:'claude-native-goal-judge',answer:JSON.stringify(answer)};
    }
    if(native==='claude'&&latest.split(/\r?\n/).at(-1)==='/goal '+input.objective){
      assert.equal(state.parentStep,'targets');
      state.slashAsPlainText=true;
      return {type:'claude-native-slash-confirmation',answer:'Goal set: '+input.objective};
    }
    const notice=parseChildNotice(native,body);
    if(notice){
      const who=Object.keys(state.receipts).find(role=>state.receipts[role].childTaskId===notice.childTaskId);
      assert(who,'notice must belong to the original family');
      assert.equal(notice.attempt,1);
      assert.equal(notice.status,who==='writer'&&mode==='child-cancel'?'canceled':
        who==='writer'&&mode==='child-failed'?'failed':'completed');
      if(!state.seen.some(row=>row.childTaskId===notice.childTaskId))state.seen.push({...notice,role:who,at:Date.now()});
      return {type:state.seen.length===2?'final-notification':'one-notification',answer:state.seen.length===2?markers.goalDone:'A70 received one genuine child result'};
    }
    if(state.parentStep==='targets'){
      if(native==='codex')assert(JSON.stringify(body).includes(input.objective));
      else if(isNativeClaudeGoalDirective(body,input.objective))state.directNativeClaudeGoal=true;
      else assert(state.slashAsPlainText&&latest.includes(input.initial),'native-owned goal directive or exact explicit fallback required');
      state.parentStep='writer';
      return tool(native,body,'wy_targets',{},'targets');
    }
    if(state.parentStep==='writer'){
      const reply=mcpResult(native,body,state.calls.targets);
      const target=listedAvailable(reply,profiles.writer);
      state.readTarget=listedAvailable(reply,profiles.reader);
      state.parentStep='reader';
      return tool(native,body,'wy_delegate',{requestKey:'a70-original-writer',profileId:target.profileId,profileRevision:target.revision,
        model:models.writer,access:'write',workspaceMode:'shared',title:childTitle.writer,instructions:markers.writer},'writerDelegate');
    }
    if(state.parentStep==='reader'){
      const first=mcpResult(native,body,state.calls.writerDelegate);
      assert.match(first.childTaskId,uuid);assert.equal(first.state,'queued');assert.equal(first.workspaceMode,'shared');
      state.receipts.writer=first;
      const target=state.readTarget;
      state.parentStep='wait';
      return tool(native,body,'wy_delegate',{requestKey:'a70-original-reader',profileId:target.profileId,profileRevision:target.revision,
        model:models.reader,access:'read',title:childTitle.reader,instructions:markers.reader},'readerDelegate');
    }
    if(state.parentStep==='wait'){
      const second=mcpResult(native,body,state.calls.readerDelegate);
      assert.match(second.childTaskId,uuid);
      assert.notEqual(second.childTaskId,state.receipts.writer.childTaskId);
      state.receipts.reader=second;
      state.parentStep='finish';
      await state.parentGate.promise;
      state.parentStep='notifications';
      return {type:'original-parent-finish',answer:markers.parent};
    }
    // Real native automatic turns before a result can race the pause. Hold any model response
    // rather than granting a shell or fabricating completion. The owner has to interrupt it.
    assert.equal(native,'codex','Claude requested another provider round without a result or user input');
    state.unnotifiedRequests=(state.unnotifiedRequests??0)+1;
    if(state.seen.length===2){
      state.postNotificationAutoTurn=true;
      return {type:'post-notification-active-goal-hold',hold:true};
    }
    if(state.seen.length===1){
      state.afterFirstNotice=(state.afterFirstNotice??0)+1;
      // Complete an already-started real turn without invoking tools and give both native and host queues a scheduling point.
      await boundedDelay(150);
      return {type:'between-real-notifications',answer:'A70 awaiting the other original child result'};
    }
    return {type:'unnotified-codex-hold',hold:true};
  }
  return {state,next,close(){state.closing=true;state.parentGate.release();state.independentGate.release();
    for(const child of Object.values(state.children))child.gate.release();}};
}
