import assert from 'node:assert/strict';
import {codexToolCall,codexToolReply,listedAvailable} from '../../../g03/prep-next/a26-recheck/codex-mcp.mjs';
import {latestUserText} from '../../../g03/prep-next/a32-recheck/protocol.mjs';
import {parseChildNotice} from '../a70/flow-v2.mjs';
export const models={parent:'a23-capacity-parent',child:'a23-capacity-read-child'};
export const input='A23_CAPACITY_NATIVE_FIVE_TRUSTED_READ_CHILDREN';
export const warm='A23_CAPACITY_WARM';
const gate=()=>{let close;return {wait:new Promise(done=>{close=done;}),release:()=>close()};};
export function makeCapacityFlow(profile){
  const state={calls:[],receipts:[],gates:Array.from({length:5},gate),started:[],notices:[],closed:false};
  const call=(body,name,args)=>{
    const output=codexToolCall(body,name,args);
    state.calls.push(output.callId);
    return {type:name,call:output};
  };
  return {state,async next(body){
    if(state.closed)return {type:'owned-shutdown',answer:'A23 cleanup'};
    const text=latestUserText('codex',body).trim();
    if(body.model===models.child){
      const match=/A23_CAPACITY_CHILD_([1-5])$/.exec(text);
      assert(match,'actual original child instructions');
      const ordinal=Number(match[1]);
      assert(!state.started.some(row=>row.ordinal===ordinal),'no actual repeated child start');
      state.started.push({ordinal,at:Date.now()});
      await state.gates[ordinal-1].wait;
      return {type:'actual-read-child-complete',answer:'A23_CAPACITY_CHILD_FINISHED_'+ordinal};
    }
    assert.equal(body.model,models.parent);
    if(text.endsWith(warm))return {type:'warm',answer:warm+'_OK'};
    const note=parseChildNotice('codex',body);
    if(note){
      assert.equal(note.status,'completed');
      assert.equal(note.attempt,1);
      assert(state.receipts.some(row=>row.childTaskId===note.childTaskId));
      assert(!state.notices.some(row=>row.childTaskId===note.childTaskId));
      state.notices.push(note);
      return {type:'actual-receipt',answer:'A23 real result acknowledged'};
    }
    if(!state.calls.length){
      assert(text.endsWith(input));
      return call(body,'wy_targets',{});
    }
    const previous=state.calls.at(-1);
    const receipt=codexToolReply(body,previous);
    if(state.calls.length===1)state.target=listedAvailable(receipt,profile);
    else{
      assert.match(receipt.childTaskId,/^[a-f0-9-]{36}$/);
      assert.equal(receipt.workspaceMode,'shared');
      assert(!state.receipts.some(row=>row.childTaskId===receipt.childTaskId));
      state.receipts.push({...receipt,ordinal:state.calls.length-1});
    }
    if(state.receipts.length===5)return {type:'all-accepted',answer:'A23 five trusted read requests accepted'};
    const ordinal=state.receipts.length+1;
    return call(body,'wy_delegate',{requestKey:'a23-capacity-read-'+ordinal,profileId:state.target.profileId,profileRevision:state.target.revision,
      access:'read',workspaceMode:'shared',model:models.child,title:'A23 trusted read '+ordinal,instructions:'A23_CAPACITY_CHILD_'+ordinal});
  },close(){state.closed=true;state.gates.forEach(row=>row.release());}};
}
