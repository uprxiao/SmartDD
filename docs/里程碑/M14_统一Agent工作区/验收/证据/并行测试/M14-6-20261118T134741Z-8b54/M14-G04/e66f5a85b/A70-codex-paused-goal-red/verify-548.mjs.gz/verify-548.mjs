import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {existsSync,readFileSync} from 'node:fs';
import {join} from 'node:path';

const attempt='/private/tmp/willyou-m14-stage6.WRvdST/g04/attempt-548';
const raw=JSON.parse(readFileSync(join(attempt,'result.json'),'utf8'));
const db=join(attempt,'runtime-yeQkty','data','smartdd.db');
assert(!existsSync(db+'-wal'),'only immutable post-exit SQLite');
assert.equal(raw.sourceCommit,'e66f5a85b43ad6f3b7d3a9e56ac2537bc5faf191');
assert.equal(raw.passed,false);
assert.match(raw.failure.error,/host auto-resumed the original goal before model ends it/);
assert.equal(raw.exit.code,0);
assert.equal(raw.exit.signal,null);
assert.equal(raw.listenerClosed,true);
const {taskId}=raw.tasks.root;
assert.match(taskId,/^[0-9a-f-]{36}$/);
const rootWhere=" WHERE task_id='"+taskId+"'";
function sql(statement){
  return JSON.parse(execFileSync('/usr/bin/sqlite3',['-json','file:'+db+'?immutable=1',statement],{encoding:'utf8'}));
}
const json=(rows,column)=>rows.map(row=>({...row,[column]:JSON.parse(row[column])}));
const events=json(sql("SELECT seq,event_type,created_at,payload FROM agent_events"+rootWhere+" AND (event_type LIKE 'goal.%' OR event_type LIKE 'turn.%' OR event_type IN ('task.user_stopped','task.user_continued','run.active')) ORDER BY seq"),'payload');
const intents=json(sql("SELECT intent_id,action,state,created_at,updated_at,result_json FROM agent_intents"+rootWhere+" AND action IN ('goal_pause','goal_resume') ORDER BY rowid"),'result_json');
assert.equal(intents.length,1,'no resume intent had begun');
const [pause]=intents;
assert.equal(pause.action,'goal_pause');assert.equal(pause.state,'done');
assert.deepEqual(pause.result_json,raw.waiting.pause.result);
const {bindingId,revision,userSeq,native}=pause.result_json;
const turnRows=sql("SELECT turn_id,run_id,native_turn_id,source_kind,status FROM agent_turns"+rootWhere+" AND source_kind='notification' ORDER BY rowid");
assert.equal(turnRows.length,2);
assert.deepEqual(turnRows.map(row=>row.status),['completed','failed']);
const classification=events.filter(row=>row.event_type==='goal.changed'&&row.payload.pausedReason==='user'&&
  Date.parse(row.created_at)>Date.parse(pause.updated_at));
const yoke=turnRows.map((turn,index)=>{
  const start=events.find(row=>row.event_type==='turn.started'&&row.payload.turnId===turn.turn_id);
  const end=events.find(row=>row.event_type==='turn.ended'&&row.payload.turnId===turn.turn_id);
  const changed=classification[index];
  const runActive=events.find(row=>row.event_type==='run.active'&&row.payload.runId===turn.run_id);
  assert(runActive.seq<changed.seq&&changed.seq<start.seq&&start.seq<end.seq);
  assert.equal(changed.payload.revision,revision);
  assert.equal(changed.payload.bindingId,bindingId);
  assert.equal(changed.payload.nativeCreatedAt,native.createdAt);
  assert.equal(changed.payload.nativeUpdatedAt,native.updatedAt);
  assert.equal(changed.payload.status,'paused');
  assert(!events.some(row=>row.seq>userSeq&&row.seq<=end.seq&&['goal.user_action','task.user_stopped'].includes(row.event_type)));
  const wire=raw.nativeWire.find(row=>row.pid===runActive.payload.pid);
  const prior=wire.events.find(row=>row.direction==='recv'&&row.method==='thread/goal/get');
  const nativeUpdate=wire.events.find(row=>row.direction==='recv'&&row.method==='thread/goal/updated');
  const resumed=wire.events.find(row=>row.direction==='send'&&row.method==='thread/resume');
  for(const row of [prior,nativeUpdate]){
    assert.equal(row.threadId,native.threadId);
    assert.equal(row.status,'paused');
    assert.equal(row.createdAt,native.createdAt);
    assert.equal(row.updatedAt,native.updatedAt);
  }
  assert.equal(resumed.threadId,native.threadId);
  assert(prior.seq<resumed.seq&&resumed.seq<nativeUpdate.seq);
  assert.equal(nativeUpdate.at,Date.parse(changed.created_at));
  assert(!wire.events.some(row=>row.direction==='send'&&row.method==='thread/goal/set'&&row.status==='active'));
  const arrival=raw.fixtureState.seen[index];
  assert.equal(arrival.status,'completed');
  assert(Date.parse(start.created_at)<=arrival.at&&arrival.at<=Date.parse(end.created_at));
  return {runId:turn.run_id,pid:runActive.payload.pid,prior,resumed,nativeUpdate,changed,start,end,arrival};
});
const firstResponse=raw.requests.find(row=>row.kind==='one-notification');
assert.equal(firstResponse.at,firstResponse.readyAt,'fixture answered first notice immediately without waiting for goal resume');
assert.equal(raw.requests.at(-1).kind,undefined,'second notice response gate was the delayed consequence');
assert.equal(yoke[0].end.payload.status,'completed');
const survivors=raw.exactProcessesAfter.filter(({born,after})=>after.state==='running'&&after.startedAt===born.startedAt);
assert.equal(survivors.length,0);
console.log(JSON.stringify({attempt:548,appPid:raw.exit.pid,asar:raw.asar,productDefect:true,
  earliestMismatch:'same unchanged native paused replay rewrote waiting_children to user before accepting either notice',
  pause,yoke,firstResponse,fixtureSecondaryFailure:'old second-notice artificial wait expired and provoked HTTP 400',
  cleanup:{appExit:raw.exit.code,listenerClosed:raw.listenerClosed,survivors:survivors.length}},null,2));
