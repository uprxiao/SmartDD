#!/bin/bash
set -euo pipefail
base=/private/tmp/willyou-m14-stage6.WRvdST
dir="$base/g04/prep-next/a23"
program="$base/package/mac-arm64/WillYou.app/Contents/MacOS/WillYou"
[[ $# == 3 && "$1" =~ ^attempt-[0-9]{3}$ && "$2" =~ ^[a-f0-9]{40}$ && "$3" =~ ^[a-f0-9]{64}$ ]] || {
  printf '%s\n' 'usage: run-a23-local-v3.sh attempt-NNN <commit40> <asar64>' >&2
  exit 64
}
test ! -e "$base/g04/$1"
test "$(/usr/bin/git -C "$base/source" rev-parse HEAD)" = "$2"
read -r sha _ < <(/usr/bin/shasum -a 256 "$base/package/mac-arm64/WillYou.app/Contents/Resources/app.asar")
test "$sha" = "$3"
ensure_idle() {
  if /usr/sbin/lsof -nP -iTCP:3425 -sTCP:LISTEN || /usr/sbin/lsof -nP -iTCP:3426 -sTCP:LISTEN || /usr/sbin/lsof -nP "$program"; then
    printf '%s\n' 'Existing packaged App or private port listener has the slot' >&2
    return 65
  fi
}
ensure_idle
cd "$base/source"
status=0
/usr/bin/env -i PATH=/Users/liubu/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin HOME="$dir"   LANG=en_US.UTF-8 TZ=Asia/Singapore M14_ACCEPTANCE_APP="$program" M14_EXPECTED_ASAR_SHA256="$3"   M14_SMOKE_CLAUDE=/Users/liubu/.local/share/claude/versions/2.1.326   /Users/liubu/.local/bin/node "$dir/a23-local-packaged-v3.mjs" "$base/g04/$1" "$2" || status=$?
ensure_idle
exit "$status"
