import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron,pause } from '../../../g03/prep-fef791bc6/electron-harness.mjs';
import {redirectHome} from '../../../g03/prep-fef791bc6/home-redirect-main.mjs';
import {makeCapacityFlow,models,input,warm} from './capacity-flow.mjs';
import {summarizeCapacity} from './proof.mjs';
import { isM14PreEntryRun } from '../../../g03/prep-fef791bc6/electron-isolation-paths.mjs';
import {sendAssistant} from '../../a60-prep/provider-contract.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,commit,asar]=process.argv.slice(2);
assert.equal(process.argv.length,5);
const bundle=join(base,'package/mac-arm64/WillYou.app/Contents'),executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-[0-9]{3}$/);
assert.match(commit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(realpathSync(executable),executable);
assert.equal(digest(join(bundle,'Resources/app.asar')),asar);
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A23',scope:'native-capacity-only',sourceCommit:commit,asar,actions:[],requests:[],passed:false};
let app,rootTask,flow,appTrusted=false,listener=false,phase='isolated fixture';
const cwd=join(root,'project');
const tab=JSON.stringify;
for(const name of ['capacity-packaged.mjs','capacity-flow.mjs','proof.mjs','run-a23-capacity.sh'])
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);

async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
function sql(query,args=[],cold=false){
  const db=join(data,'smartdd.db');assert.equal(realpathSync(db),db);
  if(cold)assert.equal(existsSync(db+'-wal'),false,'Cold sqlite cannot ignore committed WAL data');
  const py='import sqlite3,json,pathlib,sys;c=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+"?mode=ro"+("&immutable=1" if sys.argv[4]=="true" else ""),uri=True);c.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in c.execute(sys.argv[2],json.loads(sys.argv[3]))]))';
  return JSON.parse(execFileSync('/usr/bin/python3',['-c',py,db,query,JSON.stringify(args),String(cold)],{encoding:'utf8',timeout:10000}));
}



function sseTool(res,native,model,call){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const emit=(type,value)=>res.write('event: '+type+'\ndata: '+JSON.stringify({type,...value})+'\n\n');
  assert.equal(native,'codex');
  const id='resp_'+randomUUID();
  const item={id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,
    ...(call.tool.namespace?{namespace:call.tool.namespace}:{}),name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'};
  emit('response.created',{response:{id,object:'response',model,status:'in_progress',output:[]}});
  emit('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
  emit('response.output_item.done',{output_index:0,item});
  emit('response.completed',{response:{id,object:'response',model,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  res.end();
}
const server=createServer(async(req,res)=>{
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      return res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
    }
    const native=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!native){res.writeHead(404);return res.end();}
    assert([req.headers.authorization,req.headers['x-api-key']].some(k=>k==='magpie-'+native||k==='Bearer magpie-'+native));
    let bytes=0;const chunks=[];
    for await(const b of req){bytes+=b.length;assert(bytes<2*1024*1024);chunks.push(b);}
    const body=JSON.parse(Buffer.concat(chunks));
    assert.equal(native,'codex');
    assert(Object.values(models).includes(body.model));
    assert(result.requests.length<80);
    const row={at:Date.now(),native,model:body.model};
    result.requests.push(row);
    const action=await flow.next(body);
    Object.assign(row,{kind:action.type,callId:action.call?.callId??null,tool:action.call?.tool?.name??null,readyAt:Date.now(),...(action.proof?{proof:action.proof}:{})});
    if(res.destroyed||action.hold)return;
    if(action.call)sseTool(res,native,body.model,action.call);
    else sendAssistant(res,{kind:native,model:body.model,text:action.answer});
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.writeHead(400);
    res.end();
  }
});
const birth=(pid)=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));
function children(){
  return sql(`SELECT d.rowid AS ordinal,d.delegation_id AS delegationId,d.child_task_id AS childId,d.access,d.delivery_state AS state,
    (SELECT COUNT(*) FROM capability_runs r WHERE r.task_id=d.child_task_id) AS runCount
    FROM agent_delegations d WHERE parent_task_id=? ORDER BY d.rowid`,[rootTask.taskId])
    .map((row,index)=>({...row,ordinal:index+1}));
}
try{
  mkdirSync(cwd,{mode:0o700});
  const canary=join(cwd,'capacity-canary.txt');
  writeFileSync(canary,'Private A23 original unchanged.\n',{flag:'wx',mode:0o600});
  const sourceHash=digest(canary);
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listener=true;resolve();});});
  const hook={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(hook,await redirectHome({...info,home}))});
  const scope=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(scope,[true,data,home,executable,app.processId]);
  assert(hook.workerInspectorFlagRemoved);
  appTrusted=true;
  const born=birth(app.processId);
  assert(born.state==='running');
  result.app={scope,born};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await app.invoke('agents.refreshTools');
  const native=(await app.invoke('agents.tools')).find(row=>row.kind==='codex'&&row.installed);
  assert.equal(native?.version,'0.169.0');
  const profile={};
  for(const [role,name] of Object.entries(models)){
    const provider=await app.invoke('agents.saveProvider',{name:'A23 capacity synthetic '+role,preset:'magpie',
      endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:name,name}]});
    profile[role]=await app.invoke('agents.save',{name:'A23 capacity '+role,toolId:native.id,source:'provider',providerId:provider.id,
      models:[name],defaultModel:name,isDefault:role==='parent'});
  }
  assert.notEqual(profile.parent.id,profile.child.id);
  const project=await app.invoke('projects.create',{name:'A23 isolated capacity',aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  const title='A23 parent capacity test';
  const task=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title,
    profileId:profile.parent.id,model:models.parent,tier:'ask'});
  rootTask={taskId:task.taskId,title};
  flow=makeCapacityFlow(profile.child.id);
  await click('[data-testid="nav-settings"]');
  const feature='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(feature)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(feature)+'?.innerText.includes("已开启")'))await click(feature);
  await app.waitFor(selected(feature)+'?.innerText.includes("已开启")',10000);
  await click('[data-testid="nav-home"]');
  await open(rootTask);
  await send(warm);
  await until(async()=>{const s=await state(rootTask.taskId);return !s.run?.busy&&s.items.some(i=>i.payload?.text===warm+'_OK');},'actual native warmup');
  const toggle='[data-testid="agent-delegation-toggle"]';
  await click(toggle);
  await app.waitFor(selected(toggle)+'?.getAttribute("aria-pressed")==="true"',8000);
  phase='five actual host accepts, exactly four genuine trusted-read children get a native worker';
  await send(input);
  const initial=await until(()=>{
    const rows=children();
    return flow.state.receipts.length===5&&flow.state.started.length>=4&&rows.length===5&&rows;
  },'five actual acceptances and at least four genuine native requests',40000);
  result.first=summarizeCapacity(initial);
  assert.deepEqual(flow.state.started.map(row=>row.ordinal).sort(),[1,2,3,4]);
  assert.equal(result.first.queued,flow.state.receipts[4].delegationId);
  assert.equal(flow.state.receipts[4].state,'queued');
  assert.equal(await app.evaluate('Boolean(document.querySelector(".agent-request"))'),false);
  await app.screenshot(join(out,'01-actual-capacity-queued.png'));
  const clock=Date.now();
  await until(()=>{
    assert.deepEqual(summarizeCapacity(children()),result.first);
    assert.equal(flow.state.started.length,4);
    return Date.now()-clock>=800;
  },'same accepted fifth remains queued with no original native run while all four are held',4000);
  phase='release one real native child, and the fifth accepted child can start';
  flow.state.gates[0].release();
  const advanced=await until(()=>{
    const rows=children();
    assert(rows.filter(row=>row.state==='running').length<=4);
    const fifth=rows[4];
    return flow.state.started.some(row=>row.ordinal===5)&&fifth.state==='running'&&fifth.runCount===1&&rows;
  },'release and exact fifth admitted without changing its receipt',17000);
  assert.equal(advanced[4].delegationId,result.first.queued);
  result.advanced=advanced;
  for(const gate of flow.state.gates)gate.release();
  await until(async()=>{
    const all=children(),s=await state(rootTask.taskId);
    return all.length===5&&all.every(row=>row.state==='delivered'&&row.runCount===1)&&!s.run?.busy&&s.queuedTotal===0&&flow.state.notices.length===5;
  },'all original children settle without duplicate run or result',35000);
  assert.equal(digest(canary),sourceHash);
  assert.deepEqual(byQueueAll(children().map(row=>row.childId)),[]);
  await app.screenshot(join(out,'02-fifth-started-after-release-and-settled.png'));
  result.final=children();
  result.passed=true;
}catch(error){
  result.error={phase,message:String(error.stack??error)};
  if(appTrusted)try{await app.screenshot(join(out,'99-failed.png'));result.visible=await app.evaluate('document.body.innerText.slice(-6500)');}catch{}
}finally{
  flow?.close();
  if(app&&!appTrusted)try{result.unverifiedOwnAppExit=await app.crash();}catch(error){result.cleanupError=String(error);}
  if(appTrusted){
    try{
      if(!result.passed&&rootTask)await app.invoke('agentTasks.stop',rootTask.taskId,true);
      const pids=sql(`SELECT DISTINCT p.pid,p.process_started_at FROM capability_runs r
        JOIN capability_run_processes p ON p.run_id=r.run_id WHERE r.owner_pid=? AND p.pid IS NOT NULL`,[app.processId]);
      const own=[{pid:app.processId,process_started_at:result.app.born.startedAt},...pids];
      await app.mainEvaluate(`(() => {const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(process.pid!==${app.processId}||E.app.getPath('userData')!==${tab(data)})throw Error('Wrong private App');
        setTimeout(()=>E.app.quit(),50);return true;})()`);
      result.exit=await app.waitForExit(23000);
      result.processes=own.map(row=>({...row,after:birth(row.pid)}));
    }catch(error){result.cleanupError=String(error);try{result.fallback=await app.crash();}catch{}}
    result.rendererErrors=app.rendererErrors;
    writeFileSync(join(out,'app.log'),app.logs(),{mode:0o600});
  }
  if(listener){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.listenerClosed=!server.listening;
  if(flow)result.flow={started:flow.state.started,receipts:flow.state.receipts,notices:flow.state.notices};
  result.passed=Boolean(result.passed&&result.exit?.code===0&&result.exit.signal===null&&result.rendererErrors?.length===0&&result.listenerClosed&&
    result.processes?.length>=6&&result.processes.every(row=>row.process_started_at&&
      !(row.after.state==='running'&&row.after.startedAt===row.process_started_at)));
  writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({passed:result.passed,out,error:result.error,exit:result.exit}));
}
if(!result.passed)process.exitCode=2;

function byQueueAll(ids){
  assert.equal(ids.length,5);
  return sql('SELECT task_id FROM agent_directory_queue WHERE task_id IN ('+ids.map(()=>'?').join(',')+')',ids);
}
