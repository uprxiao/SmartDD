import assert from 'node:assert/strict';
import {closeSync,existsSync,ftruncateSync,openSync,realpathSync,statSync,unlinkSync} from 'node:fs';
import {join} from 'node:path';

const privateRun=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-\d{3}(?:\/runtime-[A-Za-z0-9]+)?$/;
const uuid=/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/;
export const capacity=1024**3;
export function planBallast(existingBytes,headroom=32*1024){
  assert(Number.isSafeInteger(existingBytes)&&existingBytes>0);
  assert(Number.isSafeInteger(headroom)&&headroom>=16*1024&&headroom<=128*1024);
  assert(existingBytes+headroom<capacity*.9,'test should already have no pressure before installing ballast');
  return {existingBytes,headroom,logicalBytes:capacity-existingBytes-headroom,expectedTotal:capacity-headroom};
}
export function putBallast(runDir,shadow,plan){
  assert.match(runDir,privateRun);
  assert.equal(realpathSync(runDir),runDir);
  assert.equal(realpathSync(shadow),shadow);
  const prefix=join(runDir,'data','agent-diffs')+'/';
  assert(shadow.startsWith(prefix)&&/^[a-f0-9]{64}$/.test(shadow.slice(prefix.length)));
  assert.deepEqual(plan,planBallast(plan.existingBytes,plan.headroom));
  const path=join(shadow,'a34-private-sparse-ballast'),fd=openSync(path,'wx',0o600);
  try{ftruncateSync(fd,plan.logicalBytes);}finally{closeSync(fd);}
  const s=statSync(path),allocatedBytes=s.blocks*512;
  if(s.size!==plan.logicalBytes||allocatedBytes>1024*1024){
    unlinkSync(path);throw Error('Fixture threshold must be logical only and stay within its physical budget');
  }
  return {path,size:s.size,allocatedBytes,remove(){
    const exact=existsSync(path)&&statSync(path);
    assert(exact&&s.ino===exact.ino&&s.dev===exact.dev&&exact.size===s.size,'refuse to remove replaced fixture ballast');
    unlinkSync(path);
  }};
}
const evidence=id=>({taskId:id.taskId,turnId:id.turnId});

/** Only supplementary leases. The primary read lease still has to come from actual visible UI. */
export async function holdAdditionalProofLeases({app,binding,registered,primary,trace}){
  assert.match(binding.runDir,privateRun);
  assert.equal(realpathSync(binding.runDir),binding.runDir);
  assert.equal(binding.data,join(binding.runDir,'data'));
  assert.equal(binding.home,join(binding.runDir,'home'));
  assert.equal(binding.executable,'/private/tmp/willyou-m14-stage6.WRvdST/package/mac-arm64/WillYou.app/Contents/MacOS/WillYou');
  const E="process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron')";
  const claim=await app.mainEvaluate(`(() => {const E=${E};return [process.pid,process.execPath,E.app.isPackaged,E.app.getPath('userData'),E.app.getPath('home')];})()`);
  assert.deepEqual(claim,[app.processId,binding.executable,true,binding.data,binding.home]);
  const held=new Map();
  const keys=new Set();
  for(const row of registered){
    assert.match(row.taskId,uuid);assert.match(row.turnId,uuid);
    assert.equal(row.status,'complete');
    const key=row.taskId+':'+row.turnId;assert(!keys.has(key));keys.add(key);
  }
  assert(keys.has(primary.taskId+':'+primary.turnId));
  const release=async turnId=>{
    const row=held.get(turnId);
    assert(row,'attempt needs the exact token it acquired for this turn');
    await app.invoke('agentTasks.releaseDiff',row.taskId,row.token);
    held.delete(turnId);
    trace.push({channel:'agentTasks.releaseDiff',...evidence(row),token:row.token,at:Date.now()});
  };
  try{
    for(const row of registered.filter(row=>row.turnId!==primary.turnId)){
      const summary=await app.invoke('agentTasks.changeTurn',row.taskId,row.turnId);
      assert.equal(summary.turnId,row.turnId);
      assert.equal(summary.status,'complete');
      const token=await app.invoke('agentTasks.holdDiff',row.taskId,row.turnId);
      assert.match(token,uuid);
      assert(![...held.values()].some(row=>row.token===token));
      held.set(row.turnId,{...evidence(row),token});
      trace.push({channel:'agentTasks.holdDiff',...evidence(row),token,at:Date.now()});
    }
  }catch(error){
    for(const key of held.keys())await release(key).catch(()=>{});
    throw error;
  }
  return {release,remaining:()=>[...held.values()].map(row=>({...row})),
    async releaseAll(){for(const key of held.keys())await release(key);}};
}
