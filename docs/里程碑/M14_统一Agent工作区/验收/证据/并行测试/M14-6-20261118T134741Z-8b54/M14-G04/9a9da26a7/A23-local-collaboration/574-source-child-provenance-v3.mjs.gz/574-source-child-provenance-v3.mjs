import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {join} from 'node:path';

const uuid=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
function messageText(message) {
  if (typeof message?.content==='string') return message.content;
  return (message?.content??[]).filter(block=>block.type==='text').map(block=>block.text).join('');
}
export function loadNativeChildFrames({userData,cwd,binding}) {
  assert.equal(binding.driver_id,'claude-sdk');
  assert.match(binding.native_id,uuid);
  const claudeDir=join(userData,'agents','claude');
  assert.equal(realpathSync(claudeDir),claudeDir);
  const profileRoot=realpathSync(binding.state_root);
  assert(profileRoot.startsWith(claudeDir+'/'));
  assert.match(profileRoot.slice(claudeDir.length+1),/^[a-f0-9]{32}$/);
  const project=cwd.replace(/[^a-z0-9-]/gi,'-');
  const filename=join(profileRoot,'projects',project,binding.native_id+'.jsonl');
  assert.equal(realpathSync(filename),filename);
  return readFileSync(filename,'utf8').trim().split('\n').map(line=>JSON.parse(line));
}
export function verifyChildProvenance({proof,capsule,attemptRows,childTurns,childItems,deliveries,binding,childWire}) {
  const {childId,source,delegated}=proof;
  const {attemptId,summary,sourceItemIds}=source.payload;
  assert.match(source.itemId,uuid);
  assert.match(attemptId,uuid);
  assert.equal(attemptRows.length,1);
  const [attempt]=attemptRows;
  assert.equal(attempt.attempt_id,attemptId);
  assert.equal(attempt.delegation_id,delegated.receipt.delegationId);
  assert.equal(attempt.kind,'initial');
  assert.equal(attempt.ordinal,1);
  assert(attempt.notified_at);
  const instruction=JSON.parse(attempt.input_ref);
  assert.equal(instruction.sourceKind,'delegation');
  assert.equal(instruction.text,delegated.request.instructions);
  assert(instruction.text.includes(capsule));
  assert.equal(childTurns.length,1);
  const [turn]=childTurns;
  assert.equal(turn.task_id,childId);
  assert.equal(turn.turn_id,attempt.child_turn_id);
  assert.equal(turn.source_kind,'delegation');
  assert.equal(turn.status,'completed');
  assert.equal(turn.native_turn_id,binding.native_id+':1');
  const childInput=JSON.parse(turn.input_ref).text;
  assert(childInput.startsWith('宿主委派（来源 delegation，不是新的真人授权）。'));
  assert(childInput.endsWith('\n\n'+instruction.text));

  const nativeIndex=childWire.findIndex(frame=>frame.type==='user'&&frame.sessionId===binding.native_id&&messageText(frame.message)===childInput);
  assert(nativeIndex>=0, 'the real child session received the exact durable delegated input');
  const replies=childWire.slice(nativeIndex+1).filter(frame=>frame.type==='assistant'&&frame.sessionId===binding.native_id);
  assert(replies.length>0);
  assert(replies.every(frame=>!frame.message.content?.some?.(block=>block.type==='tool_use')),'fixture child must not call native tools');
  assert(childItems.every(item=>item.task_id===childId&&item.type!=='tool_call'&&item.type!=='command_execution'));
  const assistantRows=childItems.filter(item=>item.turn_id===turn.turn_id&&item.type==='assistant_message');
  assert.deepEqual(sourceItemIds,assistantRows.map(row=>row.item_id));
  const storedBody=assistantRows.map(row=>JSON.parse(row.payload_ref).text).join('\n');
  const nativeBody=replies.map(frame=>messageText(frame.message)).filter(Boolean).join('\n');
  assert(storedBody.trim().length>0);
  assert.equal(storedBody,nativeBody,'notification must cite the genuine complete native reply');
  assert.equal(summary,storedBody.slice(-24*1024),'summary must match the cited genuine messages');

  const delivered=deliveries.filter(row=>row.client_input_id==='result-'+attemptId);
  assert.equal(delivered.length,1);
  assert.equal(delivered[0].source_kind,'notification');
  assert.equal(delivered[0].status,'completed','parent must finish its genuine result-notification round');
  assert(delivered[0].native_turn_id);
  assert(JSON.parse(delivered[0].input_ref).text.includes('结果引用 '+source.itemId));
  return {attemptId,sourceItemIds,notificationId:source.itemId,childTurn:turn.turn_id,childNativeTurn:turn.native_turn_id,
    deliveredNativeTurn:delivered[0].native_turn_id,childTextLength:storedBody.length,childEchoedMarker:storedBody.includes(capsule)};
}
