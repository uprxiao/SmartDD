import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, mkdtempSync, readFileSync, readlinkSync, realpathSync, symlinkSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { createInterface } from 'node:readline';
import { setTimeout as sleep } from 'node:timers/promises';

const base='/private/tmp/willyou-m14-stage6.WRvdST/g04/a07-a08-review';
assert.equal(realpathSync(base),base);
const native='/Users/liubu/.local/lib/node_modules/@openai/codex/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex';
assert.equal(realpathSync(native),native);
const root=realpathSync(mkdtempSync(join(base,'skill-probe-')));
const home=join(root,'home'),state=join(root,'managed-codex'),project=join(root,'project'),tmp=join(root,'tmp'),vault=join(root,'sources');
for(const p of [home,state,project,tmp,vault])mkdirSync(p,{mode:0o700});
const openProxy='http://127.0.0.1:1';
const env={HOME:home,CODEX_HOME:state,PATH:'/usr/bin:/bin:/usr/sbin:/sbin',TMPDIR:tmp,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',HTTP_PROXY:openProxy,HTTPS_PROXY:openProxy,ALL_PROXY:openProxy,NO_PROXY:'',
  LANG:'en_US.UTF-8'};
const version=execFileSync(native,['--version'],{cwd:project,env,encoding:'utf8',timeout:5000}).trim();
assert.match(version,/\b0\.169\.0\b/);
function writeSkill(p,name,label){
  mkdirSync(dirname(p),{recursive:true,mode:0o700});
  writeFileSync(p,`---\nname: ${name}\ndescription: ${label}\n---\n\nPrivate inert acceptance text only.\n`,{mode:0o600,flag:'wx'});
  return p;
}
const isolatedHome=join(root,'managed-home');
mkdirSync(isolatedHome,{mode:0o700});
const shared=join(home,'.agents/skills');
const privateShared=join(isolatedHome,'.agents/skills');
mkdirSync(privateShared,{recursive:true,mode:0o700});
const paths={
  personal:writeSkill(join(shared,'a07-personal-raw/SKILL.md'),'a07-personal-raw','Never adopted personal marker'),
  managedSource:writeSkill(join(vault,'only-managed/SKILL.md'),'a07-managed-user','Explicit managed user source marker'),
  hostSource:writeSkill(join(vault,'only-host/SKILL.md'),'a07-host-control','WillYou host library control marker'),
  repo:writeSkill(join(project,'.agents/skills/a07-project-applied/SKILL.md'),'a07-project-applied','Authorized project skill marker'),
  frozen:writeSkill(join(vault,'frozen/SKILL.md'),'a07-frozen-owned','Existing private extraRoots control marker'),
  lowerFlag:writeSkill(join(shared,'a07-user-already-disabled/SKILL.md'),'a07-user-already-disabled','Already disabled by lower settings'),
};
const links={managed:join(shared,'a07-managed-user'),host:join(shared,'a07-host-control')};
symlinkSync(dirname(paths.managedSource),links.managed);
symlinkSync(dirname(paths.hostSource),links.host);
symlinkSync(dirname(paths.managedSource),join(privateShared,'a07-managed-user'));
symlinkSync(dirname(paths.hostSource),join(privateShared,'a07-host-control'));
const stateFile=join(state,'config.toml'),personalConfig=join(home,'.codex/config.toml');
mkdirSync(dirname(personalConfig),{recursive:true,mode:0o700});
writeFileSync(personalConfig,'# Existing original personal settings\napprovals_reviewer = "auto_review"\n',{mode:0o600,flag:'wx'});
writeFileSync(stateFile,`# Existing managed configuration\n[[skills.config]]\npath=${JSON.stringify(paths.lowerFlag)}\nenabled=false\n`,{mode:0o600,flag:'wx'});
const targetNames=new Set(['a07-personal-raw','a07-managed-user','a07-host-control','a07-project-applied','a07-frozen-owned','a07-user-already-disabled','a07-personal-arrived-after-start']);
const hash=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
const hashes=()=>Object.fromEntries([...Object.values(paths),stateFile,personalConfig].map(path=>[path,hash(path)]));
const previous=hashes(),previousLinks=Object.fromEntries(Object.entries(links).map(([k,v])=>[k,{inode:lstatSync(v).ino,target:readlinkSync(v)}]));
const record={root,native,version,halves:[],protectedHashesBefore:previous,protectedLinksBefore:previousLinks,passed:false};

async function exercise(label,isolated,withLateDiscovery=false){
  const args=['app-server','-c','analytics.enabled=false','-c','features.hooks=false','-c','features.plugins=false','-c','features.remote_plugin=false',
    '--config','model_provider="a07-inert"',
    '--config','model="a07-no-inference"',
    '--config','model_providers.a07-inert={name="A07 inert fixture",base_url="http://127.0.0.1:1/v1",wire_api="responses",requires_openai_auth=false,supports_websockets=false}',
    '--config','approval_policy="on-request"','--config','sandbox_mode="workspace-write"','--config','approvals_reviewer="user"'];
  const selectedEnv=isolated?{...env,HOME:isolatedHome,USERPROFILE:isolatedHome,XDG_CONFIG_HOME:join(isolatedHome,'.config'),XDG_DATA_HOME:join(isolatedHome,'.local/share'),XDG_CACHE_HOME:join(isolatedHome,'.cache')}:env;
  const child=spawn(native,args,{cwd:project,env:selectedEnv,stdio:['pipe','pipe','pipe']});
  const result={label,pid:child.pid,args,stderr:'',exit:null};
  record.halves.push(result);
  child.stderr.on('data',b=>{if(result.stderr.length<3000)result.stderr+=b.toString('utf8');});
  const exit=new Promise(resolve=>{
    child.once('exit',(code,signal)=>{result.exit={pid:child.pid,code,signal};resolve(result.exit);});
    child.once('error',e=>{result.spawnError=String(e);resolve(null);});
  });
  let id=0;
  const waiting=new Map(),lines=createInterface({input:child.stdout});
  lines.on('line',line=>{
    let packet;
    try{packet=JSON.parse(line);}catch{return;}
    const callback=waiting.get(packet.id);
    if(callback)callback(packet);
  });
  const send=message=>child.stdin.write(JSON.stringify(message)+'\n');
  const call=(method,params)=>new Promise((resolve,reject)=>{
    const request=++id,deadline=setTimeout(()=>reject(Error('Actual RPC timed out: '+method)),6000);
    waiting.set(request,packet=>{
      clearTimeout(deadline);waiting.delete(request);
      if(packet.error)reject(Error(method+': '+JSON.stringify(packet.error)));
      else resolve(packet.result);
    });
    void exit.then(observed=>{if(waiting.delete(request)){clearTimeout(deadline);reject(Error(method+' after actual process exit '+JSON.stringify(observed)+' '+result.stderr));}});
    if(child.stdin.writable)send({id:request,method,params});
  });
  try{
    result.initialized=(await call('initialize',{clientInfo:{name:'willyou_a07_skill_catalog_probe',version:'1'},
      capabilities:{experimentalApi:true}})).userAgent;
    send({method:'initialized'});
    await call('skills/extraRoots/set',{extraRoots:[dirname(paths.frozen)]});
    const catalog=await call('skills/list',{cwds:[project],forceReload:true});
    assert(Array.isArray(catalog.data));
    result.listErrors=catalog.data.flatMap(row=>row.errors??[]);
    result.raw=catalog.data.flatMap(row=>row.skills??[]).filter(row=>targetNames.has(row.name))
      .map(({name,path,scope,enabled})=>({name,path,scope,enabled}));
    result.effective=result.raw.filter(row=>row.enabled!==false);
    const config=(await call('config/read',{cwd:project,includeLayers:false})).config;
    result.config={model_provider:config.model_provider,model:config.model,approval_policy:config.approval_policy,approvals_reviewer:config.approvals_reviewer,sandbox_mode:config.sandbox_mode,
      skillFlags:config.skills?.config??[]};
    const thread=await call('thread/start',{cwd:project,approvalPolicy:'on-request',approvalsReviewer:'user',sandbox:'workspace-write',ephemeral:true});
    result.thread={id:thread.thread?.id,approvalPolicy:thread.approvalPolicy,approvalsReviewer:thread.approvalsReviewer,sandbox:thread.sandbox};
    assert(result.thread.id);
    assert.equal(thread.modelProvider,'a07-inert');
    if(withLateDiscovery){
      const name='a07-personal-arrived-after-start';
      writeSkill(join(shared,name,'SKILL.md'),name,'Previously unknown personal source');
      const next=await call('skills/list',{cwds:[project],forceReload:true});
      const rescanned=next.data.flatMap(row=>row.skills??[]);
      const late=rescanned.find(row=>row.name===name);
      result.late={name,actualPath:late?.path,enabled:late?.enabled,originalHidden:!rescanned.some(row=>row.name==='a07-personal-raw')};
      assert.deepEqual(result.late,{name,actualPath:undefined,enabled:undefined,originalHidden:true});
    }
  }catch(error){result.error=String(error.stack??error);throw error;}
  finally{
    child.stdin.end();
    let waitTimer;
    let ended=await Promise.race([exit,new Promise(resolve=>{waitTimer=setTimeout(()=>resolve(null),6000);})]);
    clearTimeout(waitTimer);
    if(!ended&&child.exitCode===null&&child.signalCode===null){
      result.ownedFallback=child.kill('SIGTERM');
      ended=await Promise.race([exit,sleep(1200).then(()=>null)]);
    }
    lines.close();
    assert(ended,'exact native process did not exit');
  }
  return result;
}
try{
  const before=await exercise('original HOME',false);
  const after=await exercise('private HOME with adopted controls',true,true);
  const roundTrip=await exercise('original HOME after private native process',false);
  const personal='a07-personal-raw',entry=(run,n)=>run.raw.find(row=>row.name===n);
  assert.equal(entry(before,personal)?.path,paths.personal);
  assert.equal(entry(before,personal)?.enabled,true);
  assert.equal(entry(after,personal),undefined);
  assert.equal(entry(roundTrip,personal)?.enabled,true);
  assert.equal(entry(before,'a07-personal-arrived-after-start'),undefined);
  assert.equal(entry(after,'a07-personal-arrived-after-start'),undefined);
  assert.equal(entry(roundTrip,'a07-personal-arrived-after-start')?.enabled,true);
  for(const approved of ['a07-managed-user','a07-host-control','a07-project-applied','a07-frozen-owned']){
    const first=entry(before,approved);
    assert.equal(first?.enabled,true);
    assert.equal(entry(after,approved)?.enabled,true);
    assert.deepEqual(entry(roundTrip,approved),first);
  }
  for(const half of record.halves){
    assert.deepEqual(half.exit,{pid:half.pid,code:0,signal:null});
    assert(!half.ownedFallback);
    assert.equal(half.config.model_provider,'a07-inert');
    assert.equal(half.config.model,'a07-no-inference');
    assert.equal(half.config.approval_policy,'on-request');
    assert.equal(half.config.approvals_reviewer,'user');
    assert.equal(half.config.sandbox_mode,'workspace-write');
  }
  record.passed=true;
}catch(error){record.error=String(error.stack??error);process.exitCode=2;}
finally{
  record.protectedHashesAfter=hashes();
  record.protectedLinksAfter=Object.fromEntries(Object.entries(links).map(([k,v])=>[k,{inode:lstatSync(v).ino,target:readlinkSync(v)}]));
  assert.deepEqual(record.protectedHashesAfter,record.protectedHashesBefore);
  assert.deepEqual(record.protectedLinksAfter,record.protectedLinksBefore);
  writeFileSync(join(root,'result.json'),JSON.stringify(record,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({root,version,passed:record.passed,error:record.error,
    halves:record.halves.map(({label,raw,effective,config,thread,late,exit,error,stderr})=>({label,raw,effective,config,thread,late,exit,error,stderr}))},null,2));
}
