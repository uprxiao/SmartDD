/** Capture the goal, stop-hook, thread, and process identities of only this private task family. */
export function installNativeTap(modules,expected){
  const {childProcess,fs}=modules;
  const spawn=childProcess.spawn,owners=[];
  let seq=0;
  function bind(child,kind,argv){
    const owner={kind,pid:child.pid,seq:++seq,events:[],exit:null,
      resumeArg:kind==='claude'?argv[argv.indexOf('--resume')+1]??null:null,
      newArg:kind==='claude'&&argv.includes('--session-id')?argv[argv.indexOf('--session-id')+1]??null:null};
    if(kind==='claude'&&!argv.includes('--resume'))owner.resumeArg=null;
    const pending=new Map(),stopHooks=new Set();
    const add=(row)=>{if(owner.events.length<180)owner.events.push({seq:++seq,at:Date.now(),...row});};
    function summarize(direction,row){
      if(!row||typeof row!=='object')return;
      if(kind==='codex'){
        const p=row.params??{};
        if(direction==='send'&&['thread/start','thread/resume','thread/goal/set','thread/goal/get','turn/start','turn/interrupt'].includes(row.method)){
          pending.set(String(row.id),row.method);
          add({direction,method:row.method,id:String(row.id),threadId:p.threadId??null,turnId:p.turnId??null,status:p.status??null});
        }else if(direction==='recv'&&row.id!==undefined&&!row.method){
          const id=String(row.id),method=pending.get(id),goal=row.result?.goal;
          if(!method)return;
          pending.delete(id);
          add({direction,method,id,threadId:row.result?.thread?.id??goal?.threadId??null,
            status:goal?.status??null,createdAt:goal?.createdAt??null,updatedAt:goal?.updatedAt??null,errorCode:row.error?.code??null});
        }else if(direction==='recv'&&['turn/started','turn/completed','thread/goal/updated'].includes(row.method)){
          add({direction,method:row.method,threadId:p.threadId,turnId:p.turn?.id,status:p.turn?.status??p.goal?.status??null,
            createdAt:p.goal?.createdAt??null,updatedAt:p.goal?.updatedAt??null});
        }else if(direction==='recv'&&['item/started','item/completed'].includes(row.method)&&
          ['commandExecution','fileChange','mcpToolCall','dynamicToolCall'].includes(p.item?.type)){
          add({direction,method:row.method,threadId:p.threadId,turnId:p.turnId,itemType:p.item.type,itemId:p.item.id});
        }
      }else if(direction==='recv'){
        const request=row.request;
        if(row.type==='control_request'&&request?.subtype==='hook_callback'&&request.input?.hook_event_name==='Stop'){
          stopHooks.add(row.request_id);
          add({direction,method:'hook/Stop',id:row.request_id,sessionId:request.input.session_id??null});
        }else if(row.type==='system'&&row.subtype==='init'){
          add({direction,method:'system/init',sessionId:row.session_id??null});
        }else if(row.type==='result'){
          add({direction,method:'result',subtype:row.subtype,sessionId:row.session_id??null,isError:row.is_error??null});
        }else if(row.type==='assistant'&&Array.isArray(row.message?.content)){
          for(const item of row.message.content)if(item.type==='tool_use'&&item.name==='Bash'){
            add({direction,method:'tool/bash',sessionId:row.session_id??null,toolUseId:item.id});
          }
        }
      }else if(row.type==='control_response'&&stopHooks.has(row.response?.request_id)){
        const answer=row.response;
        add({direction,method:'hook/Stop',id:answer.request_id,continued:answer.response?.continue??null,subtype:answer.subtype});
      }
    }
    function consume(direction){
      let buffer=Buffer.alloc(0),ignore=false;
      return chunk=>{
        if(!chunk)return;
        const bytes=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk);
        let begin=0,end;
        while((end=bytes.indexOf(10,begin))>=0){
          if(!ignore&&buffer.length+end-begin<1048576){
            const line=Buffer.concat([buffer,bytes.subarray(begin,end)]);
            let frame;
            try{frame=JSON.parse(line.toString('utf8'));}catch{/* not a protocol record */}
            summarize(direction,frame);
          }
          begin=end+1;buffer=Buffer.alloc(0);ignore=false;
        }
        if(!ignore){
          const tail=bytes.subarray(begin);
          if(buffer.length+tail.length>=1048576){buffer=Buffer.alloc(0);ignore=true;}
          else buffer=Buffer.concat([buffer,tail]);
        }
      };
    }
    const read=consume('recv'),send=consume('send');
    const original=child.stdin.write;
    const write=function(chunk,...rest){send(chunk);return Reflect.apply(original,this,[chunk,...rest]);};
    child.stdin.write=write;
    child.stdout.on('data',read);
    child.once('exit',(code,signal)=>{owner.exit={code,signal,at:Date.now(),seq:++seq};});
    owner.restore=()=>{if(child.stdin.write===write)child.stdin.write=original;child.stdout.off('data',read);};
    owners.push(owner);
  }
  function observeSpawn(executable,argv,options,...rest){
    const env=options?.env;
    const base=options?.cwd===expected.cwd&&env?.HOME===expected.home;
    const isCodex=base&&argv?.[0]==='app-server'&&env.CODEX_HOME?.startsWith(expected.data+'/agents/codex/');
    const isClaude=base&&argv?.includes('stream-json')&&env.CLAUDE_CONFIG_DIR?.startsWith(expected.data+'/agents/claude/');
    if((isCodex||isClaude)&&fs.realpathSync(executable)!==(isCodex?expected.codex:expected.claude))throw Error('unexpected scoped native executable');
    const child=Reflect.apply(spawn,this,[executable,argv,options,...rest]);
    if(isCodex||isClaude)bind(child,isCodex?'codex':'claude',argv);
    return child;
  }
  childProcess.spawn=observeSpawn;
  return {snapshot:()=>owners.map(({kind,pid,seq,events,exit,resumeArg,newArg})=>({kind,pid,seq,events,exit,resumeArg,newArg})),restore(){
    if(childProcess.spawn!==observeSpawn)throw Error('native spawn observer changed ownership');
    childProcess.spawn=spawn;
    for(const owner of owners)owner.restore();
  }};
}
