#!/bin/bash
set -euo pipefail

root=/private/tmp/willyou-m14-stage6.WRvdST
fixture="$root/g04/prep-next/a70"
[[ $# == 1 && "$1" =~ ^attempt-[0-9]{3}$ ]] || {
  printf '%s\n' 'usage: run-a70-cold-v2.sh attempt-NNN' >&2
  exit 64
}
test ! -e "$root/g04/$1"
if /usr/sbin/lsof -nP -iTCP:3425 -sTCP:LISTEN; then
  printf '%s\n' '3425 already leased by a listener' >&2
  exit 65
fi
cd "$root/source"
status=0
/usr/bin/env -i PATH=/Users/liubu/.local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin   HOME="$fixture" LANG=en_US.UTF-8 TZ=Asia/Singapore   /Users/liubu/.local/bin/node "$fixture/scenario-cold-v2.mjs" "$root/g04/$1" || status=$?
if /usr/sbin/lsof -nP -iTCP:3425 -sTCP:LISTEN; then
  printf '%s\n' '3425 listener survived this test' >&2
  exit 66
fi
exit "$status"
