import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {defineConfig} from 'vitest/config';
const root='/private/tmp/willyou-m14-stage6.WRvdST/source';
const here=fileURLToPath(new URL('.',import.meta.url));
export default defineConfig({
  root:here,cacheDir:resolve(here,'cache'),
  resolve:{alias:{'@fixture-src':resolve(root,'src'),'@root':root,'@shared':resolve(root,'src/shared'),
    '@main':resolve(root,'src/main'),'@renderer':resolve(root,'src/renderer')}},
  test:{include:['shadow-leases.integration.test.ts'],maxWorkers:1,minWorkers:1,pool:'threads',testTimeout:35000},
});
