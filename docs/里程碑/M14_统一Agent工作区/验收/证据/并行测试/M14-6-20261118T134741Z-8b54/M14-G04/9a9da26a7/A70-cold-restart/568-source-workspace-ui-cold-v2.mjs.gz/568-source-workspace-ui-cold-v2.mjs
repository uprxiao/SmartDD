import assert from 'node:assert/strict';

const select = selector => 'document.querySelector(' + JSON.stringify(selector) + ')';
const flag = 'localStorage.getItem("willyou-m14-agent-workspace")';
const settings = '[data-testid="nav-settings"]';
const toggle = '[data-testid="m14-toggle"]';
const home = '[data-testid="nav-home"]';
const label = select(toggle) + '?.innerText';

export async function ensureRecoveredWorkspace({app, click, actions, autonomous, row}) {
  assert.equal(autonomous.beforeAnyRecoveredInput, true);
  assert.equal(autonomous.actionCount, actions.length, 'Recovered renderer was touched before autonomous proof');
  assert(Number.isSafeInteger(autonomous.observedAt) && autonomous.observedAt <= Date.now(), 'Missing recorded autonomous proof time');
  await app.waitFor('Boolean(' + select(settings) + ')', 10000, {navigation:true});
  row.at = Date.now();
  row.beforeActions = actions.length;
  row.flagBefore = await app.evaluate(flag);
  assert([null, 'true', 'false'].includes(row.flagBefore), 'Unexpected M14 renderer flag');
  await click(settings);
  if (!await app.evaluate('Boolean(' + select(toggle) + ')')) {
    await click('.settings-nav button.nav-row', '常规');
  }
  await app.waitFor('Boolean(' + select(toggle) + ')', 12000, {navigation:true});
  row.labelBefore = await app.evaluate(label);
  assert.equal(typeof row.labelBefore, 'string');
  assert.equal(row.labelBefore.includes('已开启'), row.flagBefore === 'true', 'Settings control does not agree with its renderer flag');
  row.featureEnabledInTestSetup = row.flagBefore !== 'true';
  if (row.featureEnabledInTestSetup) {
    await click(toggle);
  }
  await app.waitFor(label + '.includes("已开启")', 14000);
  row.flagAfter = await app.evaluate(flag);
  assert.equal(row.flagAfter, 'true');
  await click(home);
  row.afterActions = actions.length;
  row.finishedAt = Date.now();
}
