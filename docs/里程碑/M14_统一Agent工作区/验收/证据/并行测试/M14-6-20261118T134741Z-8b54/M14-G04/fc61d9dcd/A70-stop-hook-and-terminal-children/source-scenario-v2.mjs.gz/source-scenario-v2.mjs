import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron,pause } from '../../../g03/prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../../g03/prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../../g03/prep-fef791bc6/electron-isolation-paths.mjs';
import {installNativeTap} from './native-tap.mjs';
import {baselineContent,baselineFile,childTitle,createFlow,engineFor,input,markers,models,modes,pendingChildDecision,profileFixture,providerFailure,writerFile} from './flow-v2.mjs';
import {sendAssistant} from '../../a60-prep/provider-contract.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,commit,asar,kind,vcs,mode]=process.argv.slice(2);
const bundle=join(base,'package/mac-arm64/WillYou.app/Contents'),executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-[0-9]{3}$/);
assert.match(commit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(realpathSync(executable),executable);
assert.equal(digest(join(bundle,'Resources/app.asar')),asar);
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
assert(['codex','claude'].includes(kind));
assert(['git','svn'].includes(vcs));
assert(modes.includes(mode));
assert(mode!=='independent'||vcs==='git');
assert(mode!=='child-approval-61'||kind==='claude','the real wait path uses a Codex writer with native approval');
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A70',sourceCommit:commit,asar,kind,vcs,mode,actions:[],requests:[],passed:false};
let app,rootTask,independent,flow,appTrusted=false,listener=false,phase='isolated fixture';
const cwd=join(root,'project');
const tab=JSON.stringify;
for(const name of ['scenario-v2.mjs','native-tap.mjs','flow-v2.mjs'])
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const relations=id=>app.invoke('agentTasks.relations',id);
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));

async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
function sql(query,args=[],cold=false){
  const db=join(data,'smartdd.db');assert.equal(realpathSync(db),db);
  if(cold)assert.equal(existsSync(db+'-wal'),false,'Cold sqlite cannot ignore committed WAL data');
  const py='import sqlite3,json,pathlib,sys;c=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+"?mode=ro"+("&immutable=1" if sys.argv[4]=="true" else ""),uri=True);c.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in c.execute(sys.argv[2],json.loads(sys.argv[3]))]))';
  return JSON.parse(execFileSync('/usr/bin/python3',['-c',py,db,query,JSON.stringify(args),String(cold)],{encoding:'utf8',timeout:10000}));
}



function sseTool(res,native,model,call){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const emit=(type,value)=>res.write('event: '+type+'\ndata: '+JSON.stringify({type,...value})+'\n\n');
  if(native==='claude'){
    emit('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});
    emit('content_block_start',{index:0,content_block:{type:'tool_use',id:call.callId,name:call.tool.name,input:{}}});
    emit('content_block_delta',{index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify(call.args)}});
    emit('content_block_stop',{index:0});
    emit('message_delta',{delta:{stop_reason:'tool_use'},usage:{output_tokens:1}});
    emit('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item={id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,
      ...(call.tool.namespace?{namespace:call.tool.namespace}:{}),name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'};
    emit('response.created',{response:{id,object:'response',model,status:'in_progress',output:[]}});
    emit('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    emit('response.output_item.done',{output_index:0,item});
    emit('response.completed',{response:{id,object:'response',model,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
const server=createServer(async(req,res)=>{
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      return res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
    }
    const native=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!native){res.writeHead(404);return res.end();}
    assert([req.headers.authorization,req.headers['x-api-key']].some(k=>k==='magpie-'+native||k==='Bearer magpie-'+native));
    let bytes=0;const chunks=[];
    for await(const b of req){bytes+=b.length;assert(bytes<2*1024*1024);chunks.push(b);}
    const body=JSON.parse(Buffer.concat(chunks));
    assert(Object.values(models).includes(body.model));
    const row={at:Date.now(),native,model:body.model};
    result.requests.push(row);
    const action=await flow.next(native,body);
    Object.assign(row,{kind:action.type,callId:action.call?.callId??null,tool:action.call?.tool?.name??null,readyAt:Date.now(),...(action.proof?{proof:action.proof}:{})});
    if(res.destroyed||action.hold)return;
    if(action.error){
      res.writeHead(400,{'content-type':'application/json','x-should-retry':'false'});
      return res.end(JSON.stringify(providerFailure(native)));
    }
    if(action.call)sseTool(res,native,body.model,action.call);
    else sendAssistant(res,{kind:native,model:body.model,text:action.answer});
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.writeHead(400);
    res.end();
  }
});
function eventRows(taskId,types){
  if(!types.length)return [];
  return sql('SELECT seq,event_type,payload,created_at FROM agent_events WHERE task_id=? AND event_type IN ('+types.map(()=>'?').join(',')+') ORDER BY seq',
    [taskId,...types]).map(({payload,...row})=>({...row,payload:JSON.parse(payload)}));
}
function intents(taskId){
  return sql("SELECT intent_id,action,state,result_json,created_at,updated_at FROM agent_intents WHERE task_id=? AND action IN ('goal_pause','goal_resume') ORDER BY rowid",[taskId])
    .map(({result_json,...row})=>({...row,result:result_json?JSON.parse(result_json):null}));
}
const bindings=taskId=>sql('SELECT binding_id,native_id,driver_id FROM agent_bindings WHERE task_id=?',[taskId]);
const runs=taskId=>sql('SELECT run_id,binding_id,generation,pid,process_started_at,owner_pid,owner_started_at,started_at,ended_at,state FROM capability_runs WHERE task_id=? ORDER BY started_at',[taskId]);
const byQueue=taskId=>sql('SELECT task_id,run_id,directory_identity,state,kind FROM agent_directory_queue WHERE task_id=?',[taskId]);
const available=()=>app.mainEvaluate('globalThis.__a70NativeTap.snapshot()');
const includesAnswer=(s,name)=>s.items.some(i=>i.type==='assistant_message'&&i.payload?.text===name);
const fullGoal='[data-testid="agent-goal"]';

function setupRepository(){
  const local=(exe,args)=>execFileSync(exe,args,{cwd:root,encoding:'utf8',env:{...env,PATH:'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'},timeout:15000}).trim();
  let readRevision;
  if(vcs==='git'){
    mkdirSync(cwd,{mode:0o700});
    const git=(...args)=>local('/usr/bin/git',['-C',cwd,...args]);
    git('init','-qb','main');
    assert.equal(git('remote'),'');
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    git('add',baselineFile);
    git('-c','user.name=Fixture','-c','user.email=a70@example.invalid','-c','commit.gpgsign=false','commit','-qm','A70 baseline');
    readRevision=()=>git('rev-parse','HEAD');
  }else{
    const repository=join(root,'svn-repository'),config=join(root,'svn-config');
    mkdirSync(config,{mode:0o700});
    const svn=(...args)=>local('/opt/homebrew/bin/svn',[...args,'--non-interactive','--config-dir',config]);
    local('/opt/homebrew/bin/svnadmin',['create',repository]);
    svn('checkout','file://'+repository,cwd);
    assert.equal(svn('info','--show-item','wc-root',cwd),cwd);
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    svn('add',join(cwd,baselineFile));
    svn('commit','-m','Synthetic A70 baseline',cwd);
    readRevision=()=>svn('info','--show-item','revision',join(cwd,baselineFile));
  }
  assert.equal(realpathSync(cwd),cwd);
  const revision=readRevision(), baseline=digest(join(cwd,baselineFile));
  result.repository={cwd,vcs,revision,baseline};
  return {revision,baseline,readRevision};
}

async function config(){
  const fixture=setupRepository();
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listener=true;resolve();});});
  const boot={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,startupMainHook:async info=>Object.assign(boot,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid]})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted=true;
  const birth=nativeIdentity(app.processId);
  assert(birth.state==='running'&&birth.startedAt);
  result.app={identity,boot,birth};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await app.invoke('agents.refreshTools');
  const claude='/Users/liubu/.local/share/claude/versions/2.1.326';
  assert.equal(realpathSync(claude),claude);
  const registered=await app.invoke('agents.customToolPath','claude',claude);
  assert.equal(registered.tool?.version,'2.1.326');
  const tools=await app.invoke('agents.tools');
  const native=Object.fromEntries(['codex','claude'].map(k=>{
    const found=tools.find(t=>t.kind===k&&t.installed&&t.version===(k==='claude'?'2.1.326':'0.169.0'));
    assert(found,'requires real supported '+k);
    return [k,found];
  }));
  const ownerPaths={codex:realpathSync(native.codex.customPath??native.codex.executable),claude};
  result.nativePrograms=ownerPaths;
  await app.mainEvaluate(`(() => {
    const load=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json');
    const {app}=load('electron');
    if(!app.isPackaged||process.pid!==${app.processId}||app.getPath('home')!==${tab(home)}||app.getPath('userData')!==${tab(data)})
      throw Error('Wrong private App for passive native tap');
    globalThis.__a70NativeTap=(${installNativeTap.toString()})({childProcess:load('node:child_process'),fs:load('node:fs')},
      ${tab({cwd,home,data,...ownerPaths})});
    return true;
  })()`);
  const profileIds={},providerIds=new Set();
  for(const {role,kind:runner,provider} of profileFixture(kind,mode,origin)){
    const saved=await app.invoke('agents.saveProvider',provider);
    assert(!providerIds.has(saved.id),'provider/tool pairs must be distinct for simultaneously tested roles');
    providerIds.add(saved.id);
    const row=await app.invoke('agents.save',{name:'A70 '+role+' '+runner,toolId:native[runner].id,source:'provider',
      providerId:saved.id,models:[models[role]],defaultModel:models[role],isDefault:role==='parent'});
    profileIds[role]=row.id;
  }
  assert.equal(providerIds.size,Object.keys(profileIds).length);
  const project=await app.invoke('projects.create',{name:'A70 exact '+vcs,aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  const task=async role=>{
    const title='A70 '+role+' '+kind+' '+vcs;
    const row=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title,profileId:profileIds[role],model:models[role],tier:'ask'});
    return {taskId:row.taskId,title};
  };
  rootTask=await task('parent');
  if(mode==='independent')independent=await task('independent');
  result.tasks={root:rootTask,independent};
  flow=createFlow({kind,mode,cwd,profiles:profileIds});
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(toggle)+'?.innerText.includes("已开启")'))await click(toggle);
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  await click('[data-testid="nav-home"]');
  return fixture;
}
async function warm(task){
  await open(task);
  await send(input.warm);
  await until(async()=>{const s=await state(task.taskId);return !s.run?.busy&&includesAnswer(s,markers.warm)&&s;},'native warmup for '+task.title,30000);
}
async function beginGoal(task,objective){
  await send('/goal '+objective);
  return until(async()=>{const s=await state(task.taskId);return s.goal?.objective===objective&&s.goal.status==='active'&&s;},
    'real active goal '+objective,30000);
}

async function verifyOwnerEnded(original,rows){
  const wire=rows.find(owner=>owner.pid===original.pid);
  assert(wire?.exit,'original real native ChildProcess exit record');
  const kernel=nativeIdentity(original.pid);
  assert(kernel.state==='stopped'||kernel.state==='running'&&kernel.startedAt!==original.process_started_at);
  assert.equal(original.owner_pid,app.processId);
  assert.equal(original.owner_started_at,result.app.birth.startedAt);
  return {wire,kernel};
}
function goalWire(waited,rootOwned,rootKind,childFirst,rootTurn){
  const nativeId=waited.binding.native_id;
  if(rootKind==='claude'){
    const blocked=rootOwned.events.find(f=>f.direction==='send'&&f.method==='hook/Stop'&&f.continued===false);
    assert(blocked,'real original Claude Stop callback never answered continue:false');
    const matched=rootOwned.events.find(f=>f.direction==='recv'&&f.method==='hook/Stop'&&f.id===blocked.id);
    assert(matched&&matched.sessionId===nativeId&&matched.seq<blocked.seq);
    assert(blocked.at<=childFirst);
    assert(!rootOwned.events.some(event=>event.method==='tool/bash'),'no real parent shell polling before serial hand-off');
    return {trigger:matched,blocked,parentBashInvocations:0};
  }
  const pause=rootOwned.events.find(f=>f.direction==='send'&&f.method==='thread/goal/set'&&f.threadId===nativeId&&f.status==='paused');
  const completed=rootOwned.events.find(f=>f.direction==='recv'&&f.method==='turn/completed'&&f.status==='completed'&&f.turnId===rootTurn.native_turn_id&&f.seq<(pause?.seq??0));
  assert(pause&&completed,'missing genuine Codex completed event and immediate host pause');
  assert.equal(pause.threadId,nativeId);
  assert(pause.at<=childFirst);
  const orphans=rootOwned.events.filter(f=>f.direction==='recv'&&f.method==='turn/started'&&f.seq>completed.seq);
  const settled=orphans.map(f=>{
    const interrupt=rootOwned.events.find(i=>i.direction==='send'&&i.method==='turn/interrupt'&&i.turnId===f.turnId);
    const ended=rootOwned.events.find(i=>i.direction==='recv'&&i.method==='turn/completed'&&i.turnId===f.turnId);
    const work=rootOwned.events.filter(i=>i.method==='item/started'&&i.turnId===f.turnId);
    assert(interrupt&&ended&&f.seq<interrupt.seq&&interrupt.seq<ended.seq);
    assert.equal(ended.status,'interrupted');
    assert.deepEqual(work,[]);
    assert.ok(ended.at<=childFirst);
    return {start:f,end:ended,interrupt,work};
  });
  return {pause,initialCompleted:completed,orphans:settled,orphanObserved:settled.length>0};
}

async function stopFromUI(task){
  await open(task);
  const button='.agent-composer .agent-stop-run[title="停止本轮"]';
  await click(button);
  return until(async()=>{
    const s=await state(task.taskId);
    const events=eventRows(task.taskId,['task.user_stopped']);
    return !s.run?.busy&&events.length&&{snapshot:s,event:events.at(-1)};
  },'user Stop on actual task '+task.title,15000);
}
async function approveWriterAfter61(child){
  const req=await until(async()=>{
    const snapshot=await state(child.childTaskId);
    return snapshot.requests.find(r=>r.class==='native'&&r.kind==='command_approval'&&r.origin.taskId===child.childTaskId);
  },'original writer emitted a real native approval after admission');
  assert(pendingChildDecision(JSON.stringify(req.payload),writerFile));
  const startedAt=Date.now();
  await until(async()=>{
    const s=await state(child.childTaskId);
    const same=s.requests.find(row=>row.requestId===req.requestId);
    assert.equal(same?.revision,req.revision);
    assert.deepEqual(same.origin,req.origin);
    assert(!existsSync(join(cwd,writerFile)));
    return Date.now()-startedAt>=61000;
  },'real exact original child approval waits beyond 60 seconds',70000);
  const waitingMs=Date.now()-startedAt;
  await open(rootTask);
  await app.waitFor('('+selected('.agent-request')+'?.innerText ?? "").includes("来自子任务")',8000);
  assert(pendingChildDecision(await app.evaluate(selected('.agent-request')+'?.innerText'),writerFile));
  await app.screenshot(join(out,'02-original-child-approval-after-61s.png'));
  const options='.agent-request .agent-request-options button';
  for(const label of ['批准一次','批准']){
    const choice=options+'[aria-label='+tab(label)+']';
    if(await app.evaluate('Boolean('+selected(choice)+')')){
      await click(choice);
      await click('.agent-request .agent-confirm-choice');
      return {requestId:req.requestId,revision:req.revision,waitingMs,origin:req.origin};
    }
  }
  assert.fail('actual child command expected a normal approve option');
}

async function main(fixture){
  if(independent){
    phase='hold a genuinely independent native Codex active goal';
    await warm(independent);
    const active=await beginGoal(independent,input.independent);
    await until(()=>flow.state.independentSeen,'independent native provider turn is held');
    const native=await until(async()=>{
      const b=bindings(independent.taskId).find(row=>row.binding_id===active.goal.bindingId);
      const r=runs(independent.taskId).at(-1);
      const latest=(await state(independent.taskId)).turns.findLast(t=>t.status==='started');
      return b?.native_id&&r?.pid&&latest?.native_turn_id&&{binding:b,run:r,turn:latest,goal:active.goal,queue:byQueue(independent.taskId)};
    },'independent exact native binding, active run, and original active turn');
    assert.deepEqual(native.queue,[]);
    result.independentBefore=native;
  }

  phase='real parent goal and real native delegation of one writer and one reader';
  await warm(rootTask);
  const toggle='[data-testid="agent-delegation-toggle"]';
  await click(toggle);
  await app.waitFor(selected(toggle)+'?.getAttribute("aria-pressed")==="true"',8000);
  const originalGoal=(await beginGoal(rootTask,input.objective)).goal;
  result.goalInitial=originalGoal;
  if(kind==='claude'){
    const started=await until(async()=>flow.state.directNativeClaudeGoal?'native-goal':
      flow.state.slashAsPlainText&&!(await state(rootTask.taskId)).run?.busy?'plain-slash':false,
    'actual Claude native goal directive or acknowledged bare slash fallback');
    result.claudeGoalEntry=started;
    if(started==='plain-slash')await send(input.initial);
  }
  const before=await until(async()=>{
    const s=await state(rootTask.taskId);
    const f=await relations(rootTask.taskId);
    const parentRun=runs(rootTask.taskId).at(-1);
    const binding=bindings(rootTask.taskId).find(row=>row.binding_id===originalGoal.bindingId);
    const turn=s.turns.findLast(t=>t.status==='started'&&t.run_id===parentRun?.run_id);
    return flow.state.receipts.writer&&flow.state.receipts.reader&&s.run?.busy&&f.children.length===2&&parentRun?.pid&&binding?.native_id&&turn?.native_turn_id&&
      {children:f.children,parentRun,binding,turn};
  },'actual durable native receipts and held original parent');
  const writer=before.children.find(row=>row.childTaskId===flow.state.receipts.writer.childTaskId);
  const readerChild=before.children.find(row=>row.childTaskId===flow.state.receipts.reader.childTaskId);
  assert(writer&&readerChild);
  assert.equal(writer.access,'write');
  assert.equal(writer.workspaceMode,'shared');
  assert.equal(readerChild.access,'read');
  assert.equal((await state(writer.childTaskId)).selection.driverId,engineFor(kind,'writer')==='claude'?'claude-sdk':'codex-app-server');
  assert.equal((await state(readerChild.childTaskId)).selection.driverId,'codex-app-server');
  await until(()=>flow.state.children.reader.seen,'trusted read child actually starts while original writer still holds cwd');
  assert(!flow.state.children.writer.seen);
  assert(!existsSync(join(cwd,writerFile)));
  assert.deepEqual(byQueue(readerChild.childTaskId),[]);
  const concurrentRead=await state(rootTask.taskId);
  assert(concurrentRead.run?.busy&&concurrentRead.run.runId===before.parentRun.run_id);
  result.readerStartedWhileParentHeld=flow.state.children.reader.at;
  result.family={writer,reader:readerChild,rootOriginal:before.parentRun,binding:before.binding,rootTurn:before.turn};
  result.wireOriginalSince=(await available()).find(row=>row.pid===before.parentRun.pid)?.seq;
  assert(result.wireOriginalSince,'actual process wire belongs to original parent PID');
  await app.screenshot(join(out,'01-real-family-before-root-finishes.png'));

  phase='root finishes and pauses before the original executor drains and lets the shared writer start';
  flow.state.parentGate.release();
  const waited=await until(async()=>{
    const s=await state(rootTask.taskId);
    const recorded=runs(rootTask.taskId).find(r=>r.run_id===before.parentRun.run_id);
    const pause=intents(rootTask.taskId).find(row=>row.action==='goal_pause'&&row.state==='done');
    if(s.goal?.status!=='paused'||s.goal?.pausedReason!=='waiting_children'||!recorded?.ended_at||!pause||
      !flow.state.children.writer.seen||!flow.state.children.reader.seen)return false;
    const owned=(await available()).find(row=>row.pid===recorded.pid);
    return owned?.exit&&{snapshot:s,recorded,pause,owned,binding:before.binding};
  },'true waiting_children plus original process exit and both native children observed',45000);
  assert.equal(waited.snapshot.goal.revision,originalGoal.revision);
  assert.equal(waited.snapshot.goal.bindingId,originalGoal.bindingId);
  assert.equal(waited.pause.result.bindingId,originalGoal.bindingId);
  assert.equal(waited.pause.result.revision,originalGoal.revision);
  const writerFirst=flow.state.children.writer.at;
  assert(Date.parse(waited.recorded.ended_at)<=writerFirst);
  assert(waited.owned.exit.at<=writerFirst);
  const readerQueue=byQueue(readerChild.childTaskId);
  const writerQueue=byQueue(writer.childTaskId);
  assert.equal(writerQueue.filter(q=>q.state==='active'&&q.kind==='write').length,1);
  assert.deepEqual(readerQueue,[]);
  const knownOwner=await verifyOwnerEnded(waited.recorded,[waited.owned]);
  result.waiting={goal:waited.snapshot.goal,pause:waited.pause,drained:knownOwner,writerFirst,writerQueue,readerQueue,
    wire:goalWire(waited,waited.owned,kind,writerFirst,before.turn)};
  await app.waitFor(selected(fullGoal)+'?.innerText.includes("等子任务，已自动暂停")',8000);
  await app.screenshot(join(out,'01-waiting-goal-after-own-drain.png'));

  if(independent){
    phase='independent active goal survives same-Git shared delegation and writer admission';
    const old=result.independentBefore;
    const current=await state(independent.taskId);
    const same=current.turns.find(t=>t.turn_id===old.turn.turn_id);
    const observed=(await available()).find(proc=>proc.pid===old.run.pid);
    assert.equal(current.goal.status,'active');
    assert.equal(current.goal.revision,old.goal.revision);
    assert.equal(current.goal.bindingId,old.binding.binding_id);
    assert.equal(current.run.runId,old.run.run_id);
    assert.deepEqual(same,old.turn);
    assert.equal(observed?.exit,null);
    assert(!observed.events.some(row=>row.method==='turn/interrupt'||(row.method==='thread/goal/set'&&row.status==='paused')));
    assert.equal(nativeIdentity(old.run.pid).startedAt,old.run.process_started_at);
    assert.deepEqual(byQueue(independent.taskId),[]);
    result.independentDuring={goal:current.goal,sameTurn:same,observed};
  }

  if(mode==='user-stop'){
    phase='user stops the waiting root without canceling the independent child executions';
    const stopped=await stopFromUI(rootTask);
    assert.equal(stopped.event.payload.subtree,false);
    assert.equal(stopped.snapshot.goal.bindingId,originalGoal.bindingId);
    assert.equal(stopped.snapshot.goal.objective,input.objective);
    assert.equal(stopped.snapshot.goal.pausedReason,'user');
    assert.equal(stopped.snapshot.goal.status,'paused');
    result.userStop={action:stopped.event,goal:stopped.snapshot.goal};
    await app.screenshot(join(out,'02-waiting-root-stopped.png'));
  }

  if(mode==='child-cancel'){
    phase='user cancels only the waiting family writer from the actual relation row';
    const lineage='.agent-lineage-toggle';
    if(!await app.evaluate('Boolean('+selected('.agent-lineage')+')'))await click(lineage);
    await click(`.agent-lineage .agent-child-card[data-child-id="${writer.childTaskId}"] button[aria-label^="停止子任务"]`);
    const canceled=await until(async()=>{
      const r=(await relations(rootTask.taskId)).children.find(row=>row.childTaskId===writer.childTaskId);
      return r?.state==='canceled'&&r;
    },'real child cancellation is reflected by product');
    flow.state.children.writer.canceled=true;
    result.childCanceled=canceled;
  }

  phase='finish actual children and examine the real parent route';
  flow.state.children.writer.gate.release();
  if(mode==='child-approval-61')result.businessApproval=await approveWriterAfter61(writer);
  flow.state.children.reader.gate.release();
  const outcome=await until(async()=>{
    const rs=await relations(rootTask.taskId),s=await state(rootTask.taskId);
    const items=s.items.filter(i=>i.type==='notification'&&[writer.childTaskId,readerChild.childTaskId].includes(i.payload?.childTaskId));
    const writerMode=mode==='child-failed'?'failed':mode==='child-cancel'?'canceled':'completed';
    if(items.length!==2||!items.some(i=>i.payload.childTaskId===writer.childTaskId&&i.payload.status===writerMode))return false;
    if(mode==='user-stop')return !s.run?.busy&&{s,rs,items};
    if(flow.state.seen.length!==2||!includesAnswer(s,markers.goalDone))return false;
    const completed=s.turns.filter(turn=>turn.source_kind==='notification'&&turn.status==='completed');
    if(completed.length!==2)return false;
    const recorded=intents(rootTask.taskId).filter(row=>row.action==='goal_resume');
    result.notificationsSettled={goal:s.goal,completed,observedIntents:recorded,at:Date.now()};
    if(s.goal?.status==='paused'&&s.goal.pausedReason==='user'&&!recorded.some(row=>row.state==='intended'))
      throw Error('Both notification rounds completed; original goal marked user-paused without a test Stop');
    const nativeClaudeCompleted=kind==='claude'&&['cleared','complete'].includes(s.goal?.status)&&
      flow.state.goalJudges?.some(judgment=>judgment.ok&&judgment.seen===2);
    return (s.goal?.status==='active'||nativeClaudeCompleted)&&recorded.some(row=>row.state==='done')&&{s,rs,items};
  },'both real notifications complete without provider gating, then exact original goal resumes or stays stopped',45000);
  const readerNotice=outcome.items.find(i=>i.payload.childTaskId===readerChild.childTaskId);
  assert.equal(readerNotice?.payload.status,'completed');
  assert(flow.state.children.reader.commandReceived?.includes(baselineContent));
  assert.equal(fixture.baseline,digest(join(cwd,baselineFile)));
  assert.equal(fixture.readRevision(),fixture.revision);
  if(mode==='child-approval-61'){
    assert.equal(readFileSync(join(cwd,writerFile),'utf8'),markers.writerDone+'\n');
    assert(flow.state.children.writer.commandReceived?.includes(cwd));
  }else{
    assert(!existsSync(join(cwd,writerFile)));
    if(mode!=='child-failed'&&mode!=='child-cancel')assert(flow.state.children.writer.completedWithoutTool);
  }
  const allIntents=intents(rootTask.taskId);
  const allRuns=runs(rootTask.taskId);
  const endWire=await available();
  result.final={goal:outcome.s.goal,children:outcome.rs.children,notices:outcome.items.map(i=>i.payload),nativeRoutes:flow.state.seen,
    intents:allIntents,runs:allRuns,bindings:bindings(rootTask.taskId)};
  assert.equal(result.final.bindings.length,1);
  assert.equal(result.final.bindings[0].native_id,before.binding.native_id);
  assert.equal(outcome.s.goal?.revision,originalGoal.revision);
  if(mode==='user-stop'){
    assert.deepEqual(flow.state.seen,[]);
    assert(!allIntents.some(row=>row.action==='goal_resume'&&row.state==='done'));
    assert.equal(outcome.s.goal.pausedReason,'user');
    await pause(2200);
    assert.equal(runs(rootTask.taskId).length,allRuns.length);
    assert.deepEqual(flow.state.seen,[]);
  }else{
    const resume=allIntents.find(row=>row.action==='goal_resume'&&row.state==='done');
    assert(resume&&resume.result.bindingId===originalGoal.bindingId&&resume.result.revision===originalGoal.revision);
    const accepted=outcome.s.turns.filter(t=>t.source_kind==='notification'&&t.status==='completed');
    assert.equal(accepted.length,2);
    assert(accepted.every(t=>t.run_id!==before.parentRun.run_id));
    const actual=allRuns.filter(r=>accepted.some(t=>t.run_id===r.run_id));
    assert(actual.every(r=>r.binding_id===before.binding.binding_id&&r.generation>before.parentRun.generation));
    const wire=actual.map(r=>endWire.find(proc=>proc.pid===r.pid));
    if(kind==='codex'){
      assert(wire.some(proc=>proc?.events?.some(e=>e.direction==='send'&&e.method==='thread/resume'&&e.threadId===before.binding.native_id)));
      assert(wire.some(proc=>{
        const active=proc?.events.find(e=>e.direction==='send'&&e.method==='thread/goal/set'&&e.status==='active'&&e.threadId===before.binding.native_id);
        return active&&proc.events.some(e=>e.direction==='recv'&&e.id===active.id&&e.method===active.method&&
          e.status==='active'&&e.threadId===before.binding.native_id&&e.createdAt===waited.pause.result.native.createdAt);
      }),'original native goal confirmed active after same-session wake');
    }else{
      assert(wire.some(proc=>proc?.resumeArg===before.binding.native_id&&proc.events.some(e=>e.method==='system/init'&&e.sessionId===before.binding.native_id)));
    }
    result.final.successorNative=wire;
  }
  await open(rootTask);
  await app.screenshot(join(out,'03-goal-and-current-native-child-results.png'));
  if(independent){
    const last=await state(independent.taskId),original=result.independentBefore;
    assert.equal(last.goal.status,'active');
    assert.equal(last.run?.runId,original.run.run_id);
    assert.deepEqual(last.turns.find(t=>t.turn_id===original.turn.turn_id),original.turn);
    result.independentAfter={goal:last.goal,run:last.run,turn:last.turns.find(t=>t.turn_id===original.turn.turn_id)};
    await stopFromUI(independent);
    flow.state.independentGate.release();
  }
  if(kind==='codex'&&mode!=='user-stop'){
    phase='cleanup after acceptance proof captured while the original goal is active';
    await until(async()=>{
      const s=await state(rootTask.taskId);
      return flow.state.postNotificationAutoTurn||!['working','waiting'].includes(s.status);
    },'real goal auto turnaround or the original task naturally settles after verification');
    const s=await state(rootTask.taskId);
    if(['working','waiting'].includes(s.status)){
      const cleanup=await stopFromUI(rootTask);
      result.postProofStop={event:cleanup.event,goal:cleanup.snapshot.goal};
    }
  }
}

try{
  const fixture=await config();
  await main(fixture);
  result.passed=true;
}catch(error){
  result.failure={phase,error:String(error.stack??error)};
  if(appTrusted)try{result.visible=await app.evaluate('document.body.innerText.slice(0,12000)');await app.screenshot(join(out,'99-failure.png'));}catch{}
}finally{
  flow?.close();
  if(app&&!appTrusted)try{result.unverifiedOwnLaunchExit=await app.crash();}catch(error){result.cleanupError=String(error);}
  if(appTrusted){
    try{
      if(!result.passed){
        const active=(await app.invoke('agentTasks.list')).filter(row=>!row.parentTaskId&&['working','waiting'].includes(row.status));
        result.failureCleanup=active.map(row=>row.taskId);
        for(const row of active)await app.invoke('agentTasks.stop',row.taskId,true);
      }
      result.preQuit=(await app.invoke('agentTasks.list')).map(({taskId,status})=>({taskId,status}));
      if(result.passed)assert(!result.preQuit.some(row=>['working','waiting'].includes(row.status)));
      result.nativeWire=await available();
      await app.mainEvaluate(`(() => {const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(process.pid!==${app.processId}||E.app.getPath('userData')!==${tab(data)}||process.execPath!==${tab(executable)})throw Error('Wrong isolated App');
        globalThis.__a70NativeTap?.restore();delete globalThis.__a70NativeTap;
        setTimeout(()=>E.app.quit(),50);return true;
      })()`);
      result.exit=await app.waitForExit(24000);
    }catch(error){result.quitError=String(error);try{result.forced=await app.crash();}catch(e){result.cleanupError=String(e);}}
    result.rendererErrors=app.rendererErrors;
    writeFileSync(join(out,'app.log'),app.logs(),{mode:0o600});
    try{
      const db=join(data,'smartdd.db'),liveMode=result.exit?.code!==0||result.exit.signal!==null||existsSync(db+'-wal');
      const rows=existsSync(db)?sql('SELECT pid,process_started_at FROM capability_run_processes WHERE pid IS NOT NULL AND run_id IN (SELECT run_id FROM capability_runs WHERE owner_pid=?)',[app.processId],!liveMode):[];
      const ids=[result.app?.birth,...rows.map(row=>({pid:row.pid,startedAt:row.process_started_at}))].filter(Boolean);
      result.exactProcessesAfter=[...new Map(ids.map(row=>[row.pid+'/'+row.startedAt,row])).values()].map(born=>({born,after:nativeIdentity(born.pid)}));
    }catch(error){result.processProofError=String(error);}
  }
  if(listener){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.listenerClosed=!server.listening;
  if(flow)result.fixtureState={receipts:flow.state.receipts,seen:flow.state.seen,unnotifiedRequests:flow.state.unnotifiedRequests??0,postNotificationAutoTurn:flow.state.postNotificationAutoTurn??false,goalJudges:flow.state.goalJudges??[],writerFailure:flow.state.children.writer.failureReceipt??null};
  result.passed=Boolean(result.passed&&result.exit?.code===0&&result.exit.signal===null&&!result.rendererErrors?.length&&result.listenerClosed&&result.exactProcessesAfter?.length>=4&&
    result.exactProcessesAfter.every(({born,after})=>born.startedAt&&(after.state==='stopped'||after.state==='running'&&after.startedAt!==born.startedAt)));
  writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({out,passed:result.passed,phase,exit:result.exit,error:result.failure}));
}
if(!result.passed)process.exitCode=2;
