#!/bin/bash
set -euo pipefail
[[ $# == 2 && "$1" =~ ^[0-9a-f]{40}$ && "$2" =~ ^[0-9a-f]{64}$ ]] || {
  printf '%s\n' 'usage: run-developer.sh <frozen source commit> <compiled worker SHA-256>' >&2
  exit 64
}
fixture=/private/tmp/willyou-m14-stage6.WRvdST/g04/prep-next/a34
repo=/private/tmp/willyou-m14-stage6.WRvdST/source
[[ $(/usr/bin/git -C "$repo" rev-parse HEAD) == "$1" ]]
read -r worker_sha _ < <(/usr/bin/shasum -a 256 "$repo/out/main/agent-diff-worker.js")
[[ "$worker_sha" == "$2" ]]
[[ ! -e "$fixture/integration-verdict.json" ]] || {
  printf '%s\n' 'Preserve the integration verdict before another run.' >&2
  exit 65
}
/bin/mkdir -p "$fixture/home" "$fixture/tmp"
cd "$fixture"
exec /usr/bin/env -i PATH=/Users/liubu/.local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin HOME="$fixture/home" TMPDIR="$fixture/tmp"   LANG=en_US.UTF-8 TZ=Asia/Singapore ELECTRON_RUN_AS_NODE=1 GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_NOSYSTEM=1 GIT_TERMINAL_PROMPT=0   "$repo/node_modules/electron/dist/Electron.app/Contents/MacOS/Electron" "$repo/node_modules/vitest/vitest.mjs" run --config "$fixture/vitest.config.mts"
