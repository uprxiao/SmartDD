import assert from 'node:assert/strict';
const sha=/^[a-f0-9]{64}$/;
const uuid=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
export const skillName='m14-a23-local-team';
export const peer='A23 Claude peer';
export const relativeProgram='scripts/a23-role.mjs';
export const warmMarker='A23_CATALOG_READY';
export function skillText(){
  return `---
name: ${skillName}
description: Use for a safe one-child delegation rehearsal in a private A23 project.
---

This is a one-child host collaboration rehearsal. Do the actions, then report the receipts; prose about what you would do does not finish the rehearsal.

1. Open this selected Skill, then run the read-only Node resource at "./${relativeProgram}" relative to this Skill directory. Keep its exact printed capsule value. Do not log in, access a remote host, or write any project file.
2. Call the host tool named wy_targets. Select exactly the available profile named "${peer}". Use its current profileId and revision from that result; do not guess either value.
3. Call the host tool named wy_delegate exactly once. Use a fresh requestKey, the profileId and corresponding profileRevision, a short child title, the shared workspace mode, and write-type scheduling. The instructions must give the exact printed capsule value and tell the child to reply with it only, using no native tools and changing no file. Do not use a native Task or spawn_agent tool instead of wy_delegate.
4. Report that host receipt and end your turn, so the shared child can start. When the original child result arrives, acknowledge it without creating another child.
`;
}

export function toolKind(payload){
  const name=payload?.name;
  if(typeof name!=='string')return null;
  for(const kind of ['wy_targets','wy_delegate']){
    if(name===kind||name.endsWith('/'+kind)||name.endsWith('__'+kind))return kind;
  }
  return null;
}

function outputJson(payload){
  const output=payload.output;
  if(output?.isError||payload.error)return null;
  if(output?.structuredContent)return output.structuredContent;
  const text=typeof output==='string'?output:(output?.content??[]).filter(row=>row.type==='text').map(row=>row.text).join('\n');
  if(!text)return null;
  try{return JSON.parse(text);}catch{return null;}
}

/** Validate host tool frames and exact accepted child against independent task storage and reader output. */
export function correlate({items,rows,expectedProfile,capsule}){
  assert.match(expectedProfile,uuid);
  assert.match(capsule,/^A23_ROLE_[0-9a-f]{32}$/);
  const callRows=items.filter(item=>item.type==='tool_call'&&toolKind(item.payload)).map(item=>({
    turnId:item.turnId,ordinal:item.ordinal??0,kind:toolKind(item.payload),request:item.payload.input,receipt:outputJson(item.payload)}));
  const validCalls=callRows.filter(row=>row.kind==='wy_delegate'&&row.receipt?.childTaskId);
  if(!validCalls.length)return null;
  assert.equal(validCalls.length,1,'the real model must only accept a single delegation in the fresh parent task');
  const [delegated]=validCalls;
  assert.match(delegated.receipt.childTaskId,uuid);
  assert.match(delegated.receipt.delegationId,uuid);
  const request=delegated.request;
  assert.equal(request.profileId,expectedProfile);
  assert.match(request.profileRevision,sha);
  assert.equal(request.workspaceMode??'shared','shared');
  assert.equal(request.access,'write');
  assert(request.instructions.includes(capsule),'capsule was available only through the selected Skill resource');
  const targets=callRows.find(row=>row.kind==='wy_targets'&&row.turnId===delegated.turnId&&
    row.ordinal<delegated.ordinal&&row.receipt?.targets?.some(t=>t.profileId===expectedProfile&&t.name===peer&&
      t.available===true&&t.revision===request.profileRevision));
  assert(targets,'actual selected Skill used the authentic native target revision before delegation');
  assert.equal(rows.length,1,'one persisted delegation in this parent');
  const [row]=rows;
  assert.equal(row.delegation_id,delegated.receipt.delegationId);
  assert.equal(row.child_task_id,delegated.receipt.childTaskId);
  assert.equal(row.request_key,request.requestKey);
  if(row.delivery_state!=='delivered')return null;
  const source=items.find(item=>item.type==='notification'&&item.payload?.childTaskId===row.child_task_id&&item.payload.status==='completed');
  if(!source)return null;
  assert(source.payload.summary.includes(capsule));
  const observation=items.find(item=>item.type==='command_execution'&&item.turnId===delegated.turnId&&
    String(item.payload?.command).includes(relativeProgram)&&String(item.payload?.output).includes(capsule));
  assert(observation,'actual native resource returned the capsule in this same skill turn');
  return {targets,delegated,source,resourceItem:observation.itemId,childId:row.child_task_id};
}

export function summarizeCapacity(issued){
  assert.equal(issued.length,5);
  const keys=new Set(issued.map(row=>row.delegationId));
  assert.equal(keys.size,5);
  const active=issued.filter(row=>row.state==='running');
  const queued=issued.filter(row=>row.state==='queued');
  assert.equal(active.length,4);
  assert.equal(queued.length,1);
  assert.equal(queued[0].ordinal,5);
  assert.equal(queued[0].runCount,0);
  assert(active.every(row=>row.runCount===1&&row.access==='read'));
  return {running:active.map(row=>row.delegationId),queued:queued[0].delegationId,verdict:'accepted-queued-not-rejected'};
}
