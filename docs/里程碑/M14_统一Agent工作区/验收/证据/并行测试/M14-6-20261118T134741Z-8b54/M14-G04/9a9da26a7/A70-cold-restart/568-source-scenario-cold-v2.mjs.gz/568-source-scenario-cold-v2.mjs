import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron,pause } from '../../../g03/prep-fef791bc6/electron-harness.mjs';
import {redirectHomeAndObserve} from './home-cold.mjs';
import {makeColdFlow,coldText} from './flow-cold.mjs';
import {exactPackagedSite,armGoalRestart,assertBeforeResume} from './goal-restart-checkpoint.mjs';
import { isM14PreEntryRun } from '../../../g03/prep-fef791bc6/electron-isolation-paths.mjs';
import {installNativeTap} from './native-tap.mjs';
import {baselineContent,baselineFile,input,markers,models,profileFixture} from './flow-v2.mjs';
import {sendAssistant} from '../../a60-prep/provider-contract.mjs';
import {ensureRecoveredWorkspace} from './workspace-ui-cold-v2.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out]=process.argv.slice(2);
const commit='9a9da26a785ef3b4bb35ad1d757bfb0cdbcad030',asar='3f8d39d0458accff2138e7e9a2c0309c8d47f1fb51437daf4f32dfe38857d357';
const vcs='svn',kind='codex',mode='cold-positive';
assert.equal(process.argv.length,3);
const bundle=join(base,'package/mac-arm64/WillYou.app/Contents'),executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g04\/attempt-[0-9]{3}$/);
assert.match(commit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(realpathSync(executable),executable);
assert.equal(digest(join(bundle,'Resources/app.asar')),asar);
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
const checkpointProof=exactPackagedSite(asar);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A70',sourceCommit:commit,asar,kind,vcs,mode,actions:[],requests:[],passed:false};
let app,rootTask,flow,appTrusted=false,listener=false,phase='isolated fixture',owner='original';
result.apps={};
const cwd=join(root,'project');
const tab=JSON.stringify;
for(const name of ['scenario-cold-v2.mjs','workspace-ui-cold-v2.mjs','native-tap.mjs','flow-v2.mjs','flow-cold.mjs','home-cold.mjs','goal-restart-checkpoint.mjs','run-a70-cold-v2.sh'])
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const relations=id=>app.invoke('agentTasks.relations',id);
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));

async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
function sql(query,args=[],cold=false){
  const db=join(data,'smartdd.db');assert.equal(realpathSync(db),db);
  if(cold)assert.equal(existsSync(db+'-wal'),false,'Cold sqlite cannot ignore committed WAL data');
  const py='import sqlite3,json,pathlib,sys;c=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+"?mode=ro"+("&immutable=1" if sys.argv[4]=="true" else ""),uri=True);c.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in c.execute(sys.argv[2],json.loads(sys.argv[3]))]))';
  return JSON.parse(execFileSync('/usr/bin/python3',['-c',py,db,query,JSON.stringify(args),String(cold)],{encoding:'utf8',timeout:10000}));
}



function sseTool(res,native,model,call){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const emit=(type,value)=>res.write('event: '+type+'\ndata: '+JSON.stringify({type,...value})+'\n\n');
  if(native==='claude'){
    emit('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});
    emit('content_block_start',{index:0,content_block:{type:'tool_use',id:call.callId,name:call.tool.name,input:{}}});
    emit('content_block_delta',{index:0,delta:{type:'input_json_delta',partial_json:JSON.stringify(call.args)}});
    emit('content_block_stop',{index:0});
    emit('message_delta',{delta:{stop_reason:'tool_use'},usage:{output_tokens:1}});
    emit('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item={id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,
      ...(call.tool.namespace?{namespace:call.tool.namespace}:{}),name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'};
    emit('response.created',{response:{id,object:'response',model,status:'in_progress',output:[]}});
    emit('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    emit('response.output_item.done',{output_index:0,item});
    emit('response.completed',{response:{id,object:'response',model,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
const server=createServer(async(req,res)=>{
  const requestOwner=owner;
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      return res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
    }
    const native=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!native){res.writeHead(404);return res.end();}
    assert([req.headers.authorization,req.headers['x-api-key']].some(k=>k==='magpie-'+native||k==='Bearer magpie-'+native));
    let bytes=0;const chunks=[];
    for await(const b of req){bytes+=b.length;assert(bytes<2*1024*1024);chunks.push(b);}
    const body=JSON.parse(Buffer.concat(chunks));
    assert(Object.values(models).includes(body.model));
    const row={at:Date.now(),native,owner:requestOwner,model:body.model};
    result.requests.push(row);
    const action=await flow.next(native,body,requestOwner);
    Object.assign(row,{kind:action.type,callId:action.call?.callId??null,tool:action.call?.tool?.name??null,readyAt:Date.now(),...(action.proof?{proof:action.proof}:{})});
    if(res.destroyed||action.hold)return;
    if(action.call)sseTool(res,native,body.model,action.call);
    else sendAssistant(res,{kind:native,model:body.model,text:action.answer});
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.writeHead(400);
    res.end();
  }
});
function eventRows(taskId,types){
  if(!types.length)return [];
  return sql('SELECT seq,event_type,payload,created_at FROM agent_events WHERE task_id=? AND event_type IN ('+types.map(()=>'?').join(',')+') ORDER BY seq',
    [taskId,...types]).map(({payload,...row})=>({...row,payload:JSON.parse(payload)}));
}
function intents(taskId){
  return sql("SELECT intent_id,action,state,result_json,created_at,updated_at FROM agent_intents WHERE task_id=? AND action IN ('goal_pause','goal_resume') ORDER BY rowid",[taskId])
    .map(({result_json,...row})=>({...row,result:result_json?JSON.parse(result_json):null}));
}
const bindings=taskId=>sql('SELECT binding_id,native_id,driver_id FROM agent_bindings WHERE task_id=?',[taskId]);
const runs=taskId=>sql('SELECT run_id,binding_id,generation,pid,process_started_at,owner_pid,owner_started_at,started_at,ended_at,state FROM capability_runs WHERE task_id=? ORDER BY started_at',[taskId]);
const byQueue=taskId=>sql('SELECT task_id,run_id,directory_identity,state,kind FROM agent_directory_queue WHERE task_id=?',[taskId]);
const available=()=>app.mainEvaluate('globalThis.__a70NativeTap.snapshot()');
const includesAnswer=(s,name)=>s.items.some(i=>i.type==='assistant_message'&&i.payload?.text===name);
const fullGoal='[data-testid="agent-goal"]';

function setupRepository(){
  const local=(exe,args)=>execFileSync(exe,args,{cwd:root,encoding:'utf8',env:{...env,PATH:'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'},timeout:15000}).trim();
  let readRevision;
  if(vcs==='git'){
    mkdirSync(cwd,{mode:0o700});
    const git=(...args)=>local('/usr/bin/git',['-C',cwd,...args]);
    git('init','-qb','main');
    assert.equal(git('remote'),'');
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    git('add',baselineFile);
    git('-c','user.name=Fixture','-c','user.email=a70@example.invalid','-c','commit.gpgsign=false','commit','-qm','A70 baseline');
    readRevision=()=>git('rev-parse','HEAD');
  }else{
    const repository=join(root,'svn-repository'),config=join(root,'svn-config');
    mkdirSync(config,{mode:0o700});
    const svn=(...args)=>local('/opt/homebrew/bin/svn',[...args,'--non-interactive','--config-dir',config]);
    local('/opt/homebrew/bin/svnadmin',['create',repository]);
    svn('checkout','file://'+repository,cwd);
    assert.equal(svn('info','--show-item','wc-root',cwd),cwd);
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    svn('add',join(cwd,baselineFile));
    svn('commit','-m','Synthetic A70 baseline',cwd);
    readRevision=()=>svn('info','--show-item','revision',join(cwd,baselineFile));
  }
  assert.equal(realpathSync(cwd),cwd);
  const revision=readRevision(), baseline=digest(join(cwd,baselineFile));
  result.repository={cwd,vcs,revision,baseline};
  return {revision,baseline,readRevision};
}

const testRef=()=>{const rootPath=join(data,'smartdd.db');assert.equal(realpathSync(rootPath),rootPath);return rootPath;};
const save=(name,value)=>writeFileSync(join(out,name),JSON.stringify(value,null,2)+'\n',{mode:0o600});
const exactBirth=(pid,born)=>{const after=nativeIdentity(pid);return {pid,born,after,alive:after.state==='running'&&after.startedAt===born};};
function processesFor(pid){
  return sql(`SELECT DISTINCT p.pid,p.process_started_at,r.task_id FROM capability_runs r
    JOIN capability_run_processes p ON p.run_id=r.run_id WHERE r.owner_pid=? AND p.pid IS NOT NULL`,[pid]);
}

async function boot(label,tap){
  const proof={};
  appTrusted=false;
  app=await openElectron({executable,userData:data,env,inspectMain:true,startupMainHook:async info=>
    Object.assign(proof,await redirectHomeAndObserve({...info,home,exe:executable,data,tap}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert.equal(proof.workerInspectorFlagRemoved,true);
  assert.equal(proof.observedBeforeEntry,label==='recovered');
  appTrusted=true;
  const birth=nativeIdentity(app.processId);
  assert.equal(birth.state,'running');assert(birth.startedAt);
  result.apps[label]={identity,birth,boot:proof,pid:app.processId,startedAt:Date.now()};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
}

async function setup(){
  const fixture=setupRepository();
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listener=true;resolve();});});
  await boot('original');
  await app.invoke('agents.refreshTools');
  const claude='/Users/liubu/.local/share/claude/versions/2.1.326';
  assert.equal(realpathSync(claude),claude);
  const registered=await app.invoke('agents.customToolPath','claude',claude);
  assert.equal(registered.tool?.version,'2.1.326');
  const tools=await app.invoke('agents.tools');
  const native=Object.fromEntries(['codex','claude'].map(k=>{
    const record=tools.find(t=>t.kind===k&&t.installed&&t.version===(k==='claude'?'2.1.326':'0.169.0'));
    assert(record,'real supported native program '+k);
    return [k,record];
  }));
  const tap={cwd,home,data,codex:realpathSync(native.codex.customPath??native.codex.executable),claude};
  result.nativePrograms=tap;
  await app.mainEvaluate(`(() => {
    const m=process.getBuiltinModule('module'),{app}=m.createRequire(process.execPath)('electron');
    if(!app.isPackaged||process.pid!==${app.processId}||app.getPath('home')!==${tab(home)}||app.getPath('userData')!==${tab(data)})
      throw Error('Wrong private App for passive observer');
    globalThis.__a70NativeTap=(${installNativeTap.toString()})({childProcess:process.getBuiltinModule('child_process'),fs:process.getBuiltinModule('fs')},${tab(tap)});
    m.syncBuiltinESMExports();return true;
  })()`);
  const profiles={};
  for(const {role,kind:runner,provider} of profileFixture('codex','normal',origin).filter(row=>row.role!=='reader')){
    const saved=await app.invoke('agents.saveProvider',provider);
    const record=await app.invoke('agents.save',{name:'A70 cold '+role,toolId:native[runner].id,source:'provider',
      providerId:saved.id,models:[models[role]],defaultModel:models[role],isDefault:role==='parent'});
    profiles[role]=record.id;
  }
  assert.notEqual(profiles.parent,profiles.writer);
  const project=await app.invoke('projects.create',{name:'A70 cold exact SVN',aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  const title='A70 Codex cold positive';
  const task=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title,profileId:profiles.parent,model:models.parent,tier:'ask'});
  rootTask={taskId:task.taskId,title};
  result.tasks={root:rootTask};
  flow=makeColdFlow(profiles.writer);
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(toggle)+'?.innerText.includes("已开启")'))await click(toggle);
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  await click('[data-testid="nav-home"]');
  return {fixture,tap};
}

function readBoundary(parent,child,attemptId){
  const code=`
import json,pathlib,sqlite3,sys
d=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+'?mode=ro',uri=True)
d.row_factory=sqlite3.Row
d.execute('BEGIN')
parent,child,attempt=sys.argv[2:5]
rows=lambda query,*params:[dict(r) for r in d.execute(query,params)]
goal=rows("SELECT binding_id AS bindingId,revision,status,paused_reason AS pausedReason,objective FROM agent_goals WHERE task_id=?",parent)
intents=rows("SELECT action,state,result_json FROM agent_intents WHERE task_id=? AND action IN ('goal_pause','goal_resume') ORDER BY rowid",parent)
childTurns=rows("SELECT task_id AS taskId,turn_id AS turnId,native_turn_id AS nativeTurnId,status,run_id FROM agent_turns WHERE task_id=? AND source_kind='delegation' ORDER BY rowid",child)
attemptRow=rows("SELECT attempt_id,child_turn_id,notified_at FROM agent_delegation_attempts WHERE attempt_id=?",attempt)
childRuns=rows("SELECT run_id,binding_id,generation,pid,process_started_at,owner_pid,owner_started_at,state FROM capability_runs WHERE task_id=? ORDER BY started_at",child)
notice=rows("SELECT item_id,payload_ref FROM agent_items WHERE task_id=? AND type='notification' AND json_extract(payload_ref,'$.attemptId')=?",parent,attempt)
inputRows=rows("SELECT turn_id,native_turn_id,run_id,status,source_kind FROM agent_turns WHERE task_id=? AND client_input_id=?",parent,'result-'+attempt)
print(json.dumps(dict(goal=goal,intents=intents,childTurns=childTurns,attempt=attemptRow,childRuns=childRuns,notice=notice,inputRows=inputRows)))
d.rollback()
`;
  const checked=JSON.parse(execFileSync('/usr/bin/python3',['-c',code,testRef(),parent,child,attemptId],{encoding:'utf8',timeout:2500}));
  assert.equal(checked.goal.length,1);assert.equal(checked.attempt.length,1);
  return checked;
}
async function original(tap){
  phase='actual original started Codex goal, real one-child SVN delegation';
  const parent=rootTask.taskId;
  await open(rootTask);
  await send(input.warm);
  await until(async()=>{const s=await state(parent);return !s.run?.busy&&includesAnswer(s,markers.warm);},'actual native warmup');
  const toggle='[data-testid="agent-delegation-toggle"]';
  await click(toggle);
  await app.waitFor(selected(toggle)+'?.getAttribute("aria-pressed")==="true"',8000);
  await send('/goal '+input.objective);
  const established=await until(async()=>{
    const s=await state(parent),current=runs(parent).at(-1);
    const turn=s.turns.findLast(row=>row.status==='started'&&row.run_id===current?.run_id);
    const binding=bindings(parent).find(row=>row.binding_id===s.goal?.bindingId);
    return s.goal?.status==='active'&&s.goal.objective===input.objective&&flow.state.receipt&&current?.pid&&binding?.native_id&&turn?.native_turn_id&&
      {goal:s.goal,binding,run:current,turn};
  },'actual original goal and delegated writer reach durable acceptance');
  const child=flow.state.receipt.childTaskId;
  assert.equal((await relations(parent)).children.find(row=>row.childTaskId===child)?.access,'write');
  assert(!flow.state.childSeen);
  flow.state.pendingParent.release();
  const first=await until(async()=>{
    const s=await state(parent),p=intents(parent).find(row=>row.action==='goal_pause'&&row.state==='done');
    const end=runs(parent).find(row=>row.run_id===established.run.run_id);
    const raw=(await available()).find(proc=>proc.pid===established.run.pid);
    return s.goal?.status==='paused'&&s.goal.pausedReason==='waiting_children'&&p&&end?.ended_at&&raw?.exit&&flow.state.childSeen&&{goal:s.goal,p,end,raw};
  },'actual pause, old owner exit, and serial child admitted');
  const oldWire=first.raw;
  assert.equal(first.goal.revision,established.goal.revision);
  assert.equal(first.p.result.native.threadId,established.binding.native_id);
  assert.equal(first.p.result.native.status,'paused');
  const nativeCompleted=oldWire.events.find(row=>row.method==='turn/completed'&&row.turnId===established.turn.native_turn_id&&row.status==='completed');
  const nativePaused=oldWire.events.find(row=>row.method==='thread/goal/set'&&row.direction==='send'&&row.status==='paused');
  assert(nativeCompleted?.seq<nativePaused?.seq&&oldWire.exit.at<=flow.state.childStartedAt);
  assert.equal(byQueue(child).filter(row=>row.state==='active').length,1);
  assert.equal(exactBirth(first.end.pid,first.end.process_started_at).alive,false);
  await app.waitFor(selected(fullGoal)+'?.innerText.includes("等子任务，已自动暂停")',8000);
  await app.screenshot(join(out,'01-original-waiting-goal.png'));
  const wire=await available();
  const appOriginal=result.apps.original;
  const hold=await armGoalRestart(app,checkpointProof,{runtime:root,cwd,parent,child,pid:appOriginal.pid,goal:first.goal});
  result.checkpoint={proof:checkpointProof,lineNumber:hold.lineNumber,marker:hold.marker};
  flow.state.pendingChild.release();
  phase='read durable original checkpoint and terminate its precise own App';
  const marker=await until(()=>existsSync(hold.marker)&&JSON.parse(readFileSync(hold.marker,'utf8')),'truthful breakpoint marker',25000);
  const before=readBoundary(parent,child,marker.attemptId);
  const expected={parent,child,bindingId:established.binding.binding_id,nativeId:established.binding.native_id,revision:established.goal.revision};
  assert.equal(before.intents.filter(row=>row.action==='goal_pause'&&row.state==='done').length,1);
  assertBeforeResume({marker,goal:before.goal[0],pause:first.p.result,
    resumes:before.intents.filter(row=>row.action==='goal_resume').length,resultCount:before.notice.length+before.inputRows.length,
    child:before.childTurns[0],expected,pid:appOriginal.pid});
  assert.equal(before.childTurns.length,1);assert.equal(before.childRuns.length,1);
  assert.equal(before.attempt[0].notified_at,null);
  assert.equal(before.attempt[0].child_turn_id,marker.childTurn);
  assert.equal(before.childRuns[0].owner_pid,appOriginal.pid);
  assert(flow.state.seen.length===0&&flow.state.childReplyCount===1);
  const processes=processesFor(appOriginal.pid);
  assert(processes.length>=3&&processes.every(p=>p.process_started_at));
  save('01-before-crash.json',{expected,marker,before,processes,wire,identity:appOriginal});
  assert.deepEqual(nativeIdentity(appOriginal.pid),appOriginal.birth);
  assert(Date.now()-marker.at<14000,'checkpoint no longer guaranteed held');
  result.apps.original.rendererErrors=app.rendererErrors;
  writeFileSync(join(out,'original-app.log'),app.logs(),{mode:0o600});
  result.crashExit=await app.crash();
  assert.deepEqual(result.crashExit,{pid:appOriginal.pid,code:null,signal:'SIGKILL'});
  assert.equal(exactBirth(appOriginal.pid,appOriginal.birth.startedAt).alive,false);
  app=undefined;appTrusted=false;owner='recovered';
  return {marker,before,established,expected,processes,tap,previousPause:first.p.result};
}

async function resumed(previous,fixture){
  phase='boot the same private data and observe autonomous recovery before any UI action';
  const actionCount=result.actions.length,parent=rootTask.taskId;
  await boot('recovered',previous.tap);
  const fresh=result.apps.recovered;
  assert.notEqual(fresh.pid,result.apps.original.pid);
  const settled=await until(()=>{
    const facts=readBoundary(parent,previous.expected.child,previous.marker.attemptId);
    return facts.inputRows.length===1&&facts.inputRows[0].status==='completed'&&
      facts.intents.some(row=>row.action==='goal_resume'&&row.state==='done')&&facts;
  },'real cold result and automatic same-goal intent settle');
  assert.deepEqual(settled.childTurns,previous.before.childTurns);
  assert.deepEqual(settled.childRuns.map(({run_id,pid,generation,owner_pid})=>({run_id,pid,generation,owner_pid})),
    previous.before.childRuns.map(({run_id,pid,generation,owner_pid})=>({run_id,pid,generation,owner_pid})));
  assert.equal(settled.attempt[0].attempt_id,previous.marker.attemptId);
  assert(settled.attempt[0].notified_at);
  assert.equal(settled.notice.length,1);
  const note=JSON.parse(settled.notice[0].payload_ref);
  assert.equal(note.childTaskId,previous.expected.child);assert.equal(note.status,'completed');
  assert(note.summary.includes(coldText.childFinished));
  assert.equal(flow.state.seen.length,1);
  assert.equal(flow.state.childReplyCount,1);
  assert.equal(result.requests.filter(row=>row.model===models.writer&&row.owner==='recovered').length,0);
  assert.equal(settled.goal[0].bindingId,previous.expected.bindingId);
  assert.equal(settled.goal[0].revision,previous.expected.revision);
  assert.equal(settled.goal[0].status,'active');
  const persisted=settled.intents.filter(row=>row.action==='goal_resume');
  assert.equal(persisted.length,1);
  assert.deepEqual(JSON.parse(persisted[0].result_json),previous.previousPause);
  const receipt=settled.inputRows[0];
  const run=runs(parent).find(row=>row.run_id===receipt.run_id);
  assert.equal(run.owner_pid,fresh.pid);assert.equal(run.owner_started_at,fresh.birth.startedAt);
  assert.equal(run.binding_id,previous.expected.bindingId);
  assert(run.generation>previous.established.run.generation);
  const native=(await available()).find(row=>row.pid===run.pid);
  assert(native,'pre-entry native observer must see the actual recovered parent spawn');
  const threadId=previous.expected.nativeId;
  const starts=native.events.filter(e=>e.direction==='send'&&e.method==='thread/resume');
  assert.equal(starts.length,1);assert.equal(starts[0].threadId,threadId);
  const prior=native.events.find(e=>e.direction==='recv'&&e.method==='thread/goal/get'&&e.threadId===threadId&&e.seq<starts[0].seq);
  assert(prior&&prior.status==='paused'&&prior.createdAt===previous.previousPause.native.createdAt&&prior.updatedAt===previous.previousPause.native.updatedAt);
  const activation=native.events.find(e=>e.direction==='send'&&e.method==='thread/goal/set'&&e.status==='active'&&e.threadId===threadId);
  const ack=native.events.find(e=>e.direction==='recv'&&e.method==='thread/goal/set'&&e.status==='active'&&e.threadId===threadId&&e.id===activation?.id);
  assert(activation&&ack&&ack.createdAt===previous.previousPause.native.createdAt);
  assert(activation.seq>starts[0].seq);
  const retired=await until(()=>{
    const rows=previous.processes.map(row=>exactBirth(row.pid,row.process_started_at));
    return rows.every(row=>!row.alive)&&rows;
  },'all exact original native and bridge births gone');
  assert.equal(result.actions.length,actionCount);
  assert.equal(fixture.readRevision(),fixture.revision);
  assert.equal(fixture.baseline,digest(join(cwd,baselineFile)));
  result.autonomous={beforeAnyRecoveredInput:true,observedAt:Date.now(),actionCount,facts:settled,run,note,prior,starts,activation,ack,retired,native,seen:flow.state.seen};
  save('02-recovered-autonomous.json',result.autonomous);
  phase='enable the M14 workspace in the recovered renderer after autonomous proof';
  result.workspaceUi={};
  await ensureRecoveredWorkspace({app,click,actions:result.actions,autonomous:result.autonomous,row:result.workspaceUi});
  save('03-recovered-workspace.json',result.workspaceUi);
  phase='open original task to verify UI, then stop the live goal for cleanup';
  await open(rootTask);
  await app.waitFor('document.body.innerText.includes('+tab(coldText.woke)+')',18000);
  const goalStatus=await state(parent);
  assert.equal(goalStatus.goal?.bindingId,previous.expected.bindingId);
  assert.equal(goalStatus.goal?.status,'active');
  result.recoveredUi={taskId:parent,title:rootTask.title,visibleResult:coldText.woke,
    visibleGoal:await app.evaluate(selected(fullGoal)+'?.innerText'),goal:goalStatus.goal};
  assert(result.recoveredUi.visibleGoal?.includes(input.objective));
  await app.screenshot(join(out,'02-recovered-original-goal.png'));
  await click(fullGoal+' .agent-goal-actions button','暂停');
  await until(async()=>(await state(parent)).goal?.status==='paused','actual post-evidence goal pause');
  const s=await state(parent);
  if(['working','waiting'].includes(s.status)){
    await click('.agent-composer .agent-stop-run[title="停止本轮"]');
    await until(async()=>!(await state(parent)).run?.busy,'actual cleanup stop on recovered original parent');
  }
}

try{
  const {fixture,tap}=await setup();
  const proof=await original(tap);
  await resumed(proof,fixture);
  result.passed=true;
}catch(error){
  result.failure={phase,error:String(error.stack??error)};
  if(appTrusted&&phase!=='read durable original checkpoint and terminate its precise own App')try{
    result.visible=await app.evaluate('document.body.innerText.slice(0,12000)');
    await app.screenshot(join(out,'99-failed.png'));
  }catch{}
}finally{
  flow?.close();
  if(app&&!appTrusted)try{result.unverifiedOwnLaunchExit=await app.crash();}catch(error){result.cleanupError=String(error);}
  if(appTrusted){
    try{
      const trusted=result.apps[owner];
      assert(trusted&&trusted.pid===app.processId);
      if(!result.passed){
        const active=(await app.invoke('agentTasks.list')).filter(row=>!row.parentTaskId&&['working','waiting'].includes(row.status));
        for(const row of active)await app.invoke('agentTasks.stop',row.taskId,true);
        result.failureCleanup=active.map(row=>row.taskId);
      }
      await until(async()=>!(await app.invoke('agentTasks.list')).some(row=>['working','waiting'].includes(row.status)),'normal quit prerequisites settle',14000);
      const owned=processesFor(app.processId);
      result.nativeWire=await available();
      await app.mainEvaluate(`(() => {const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(process.pid!==${app.processId}||E.app.getPath('userData')!==${tab(data)}||process.execPath!==${tab(executable)})throw Error('Wrong private App');
        globalThis.__a70NativeTap?.restore();delete globalThis.__a70NativeTap;
        setTimeout(()=>E.app.quit(),50);return true;
      })()`);
      result.exit=await app.waitForExit(26000);
      result.exactProcessesAfter=[trusted.birth,...owned.map(x=>({pid:x.pid,startedAt:x.process_started_at}))].map(i=>exactBirth(i.pid,i.startedAt));
    }catch(error){
      result.quitError=String(error);
      try{result.fallbackExit=await app.crash();}catch(e){result.cleanupError=String(e);}
    }
    result.apps[owner].rendererErrors=app.rendererErrors;
    writeFileSync(join(out,owner+'-app.log'),app.logs(),{mode:0o600});
  }
  if(listener){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.listenerClosed=!server.listening;
  result.passed=Boolean(result.passed&&result.crashExit?.signal==='SIGKILL'&&result.exit?.code===0&&result.exit.signal===null&&
    result.exit.pid===result.apps.recovered?.pid&&result.autonomous?.retired?.every(r=>!r.alive)&&result.exactProcessesAfter?.length>=3&&
    result.exactProcessesAfter.every(row=>!row.alive)&&Object.values(result.apps).every(row=>!row.rendererErrors?.length)&&result.listenerClosed);
  save('result.json',result);
  console.log(JSON.stringify({passed:result.passed,out,crashExit:result.crashExit,exit:result.exit,failure:result.failure}));
}
if(!result.passed)process.exitCode=2;
