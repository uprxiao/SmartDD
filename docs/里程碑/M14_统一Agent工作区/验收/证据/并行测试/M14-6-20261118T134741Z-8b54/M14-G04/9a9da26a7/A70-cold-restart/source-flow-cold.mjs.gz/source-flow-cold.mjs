import assert from 'node:assert/strict';
import {codexToolCall,codexToolReply,listedAvailable} from '../../../g03/prep-next/a26-recheck/codex-mcp.mjs';
import {latestUserText} from '../../../g03/prep-next/a32-recheck/protocol.mjs';
import {input,markers,models,parseChildNotice} from './flow-v2.mjs';

export const coldText={rootFinished:'A70_COLD_ORIGINAL_PARENT_FINISHED',childInput:'A70_COLD_SINGLE_WRITE_ROLE',
  childFinished:'A70_COLD_NATIVE_WRITER_DONE',woke:'A70_COLD_SAME_GOAL_RECEIVED_ORIGINAL_CHILD'};
const gate=()=>{let unblock;return {wait:new Promise(done=>{unblock=done;}),release:()=>unblock()};};
export function makeColdFlow(writerProfile){
  const state={step:0,childSeen:false,receipt:null,seen:[],pendingChild:gate(),pendingParent:gate(),closing:false,childReplyCount:0};
  const calls={};
  function call(body,name,args){
    const value=codexToolCall(body,name,args);
    calls[name]=value.callId;
    return {type:name,call:value};
  }
  return {state,async next(native,body,owner){
    if(state.closing)return {type:'cleanup',answer:'A70 private cleanup'};
    const latest=latestUserText(native,body).trim();
    if(body.model===models.writer){
      assert.equal(owner,'original','cold recovery must never replay a completed child');
      assert.equal(native,'claude');
      assert(latest.endsWith(coldText.childInput));
      assert.equal(state.childSeen,false);
      state.childSeen=true;
      state.childStartedAt=Date.now();
      await state.pendingChild.wait;
      state.childReplyCount++;
      return {type:'original-writer-completed',answer:coldText.childFinished};
    }
    assert.equal(body.model,models.parent);
    assert.equal(native,'codex');
    if(latest.endsWith(input.warm)){
      assert.equal(owner,'original');
      return {type:'warm',answer:markers.warm};
    }
    const note=parseChildNotice(native,body);
    if(note){
      assert.equal(owner,'recovered','original host must stop before delivery');
      assert.equal(note.childTaskId,state.receipt.childTaskId);
      assert.equal(note.attempt,1);
      assert.equal(note.status,'completed');
      assert.deepEqual(state.seen,[],'original result should be accepted only once');
      state.seen.push({...note,at:Date.now()});
      return {type:'recovered-original-child-notice',answer:coldText.woke};
    }
    if(owner==='recovered'){
      assert(state.seen.length===1,'recovery cannot open an autonomous provider turn before the true result');
      return {type:'post-proof-hold',hold:true};
    }
    if(state.step===0){
      assert(JSON.stringify(body).includes(input.objective));
      state.step++;
      return call(body,'wy_targets',{});
    }
    if(state.step===1){
      const target=listedAvailable(codexToolReply(body,calls.wy_targets),writerProfile);
      state.step++;
      return call(body,'wy_delegate',{requestKey:'a70-cold-original-write',profileId:target.profileId,profileRevision:target.revision,
        model:models.writer,access:'write',workspaceMode:'shared',title:'A70 original cold writer',instructions:coldText.childInput});
    }
    if(state.step===2){
      const receipt=codexToolReply(body,calls.wy_delegate);
      assert.match(receipt.childTaskId,/^[a-f0-9-]{36}$/);
      assert.equal(receipt.state,'queued');
      assert.equal(receipt.workspaceMode,'shared');
      state.receipt=receipt;
      state.step++;
      await state.pendingParent.wait;
      return {type:'original-parent-finish',answer:coldText.rootFinished};
    }
    return {type:'pre-drain-orphan-hold',hold:true};
  },close(){state.closing=true;state.pendingParent.release();state.pendingChild.release();}};
}
