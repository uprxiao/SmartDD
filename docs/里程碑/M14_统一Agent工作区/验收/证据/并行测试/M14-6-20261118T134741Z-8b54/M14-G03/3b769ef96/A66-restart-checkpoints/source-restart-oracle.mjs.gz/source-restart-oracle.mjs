import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync,realpathSync } from 'node:fs';
import { join } from 'node:path';
import { readonlyQuery } from '../../a67-tier-matrix/readonly-db.mjs';

const id=/^[a-f0-9-]{36}$/;
const sha=/^[a-f0-9]{40}$/;
const validRoot=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}\/runtime-[A-Za-z0-9]+$/;
const text=(...args)=>execFileSync('/usr/bin/git',args,{encoding:'utf8',timeout:10000}).trim();

export function readRecovery(runtime, checkpoint, exitOptions){
  assert.match(runtime,validRoot);
  assert.equal(realpathSync(runtime),runtime);
  const repo=join(runtime,'repo'), data=join(runtime,'data'), home=join(runtime,'home');
  for (const path of [repo,data,home])assert.equal(realpathSync(path),path);
  assert.match(checkpoint.child,id);
  assert.match(checkpoint.parent,id);
  assert.match(checkpoint.base,sha);
  const query=(sql,args)=>readonlyQuery(data,sql,args,exitOptions).rows;
  const [workspace]=query("SELECT workspace_id,task_id,child_task_id,path,base_commit,branch,state,deps_result FROM agent_workspaces WHERE task_id=? AND child_task_id=?",[checkpoint.parent,checkpoint.child]);
  assert(workspace);
  assert(workspace.path.startsWith(join(home,'.willyou/worktrees')+'/'));
  assert.equal(realpathSync(workspace.path),workspace.path);
  assert.equal(workspace.base_commit,checkpoint.base);
  assert.equal(workspace.branch,checkpoint.branch);
  if(checkpoint.path)assert.equal(checkpoint.path,workspace.path);
  const [attempt]=query("SELECT a.attempt_id,a.notified_at,a.child_turn_id,a.commit_range,d.delivery_state FROM agent_delegation_attempts a JOIN agent_delegations d ON d.delegation_id=a.delegation_id WHERE d.parent_task_id=? AND d.child_task_id=? ORDER BY a.ordinal DESC LIMIT 1",[checkpoint.parent,checkpoint.child]);
  assert(attempt);
  if(checkpoint.attempt)assert.equal(checkpoint.attempt,attempt.attempt_id);
  const [extent]=query("SELECT COUNT(*) AS n FROM agent_workspaces WHERE task_id=? AND child_task_id=?",[checkpoint.parent,checkpoint.child]);
  const intents=query("SELECT intent_id,action,target_ref,expected_parent,state,json_extract(result_json,'$.head') recovered_head FROM agent_intents WHERE (task_id=? AND action='worktree_add' AND target_ref=?) OR (task_id=? AND action='child_result_commit') ORDER BY rowid",[checkpoint.parent,workspace.path,checkpoint.child]);
  const notices=query("SELECT item_id,json_extract(payload_ref,'$.status') AS status,json_extract(payload_ref,'$.commits.head') AS head FROM agent_items WHERE task_id=? AND type='notification' AND json_extract(payload_ref,'$.attemptId')=?",[checkpoint.parent,attempt.attempt_id]);
  const receipts=query("SELECT turn_id,run_id,status FROM agent_turns WHERE task_id=? AND client_input_id=?",[checkpoint.parent,'result-'+attempt.attempt_id]);
  const provenance=query("SELECT commit_sha,intent_id,attempt_id,workspace_id FROM agent_commit_provenance WHERE attempt_id=?",[attempt.attempt_id]);
  const processes=query("SELECT r.task_id,r.run_id,r.state AS run_state,p.kind,p.pid,p.process_started_at,p.state FROM capability_runs r JOIN capability_run_processes p ON p.run_id=r.run_id WHERE r.task_id IN (?,?) ORDER BY r.started_at,p.kind",[checkpoint.parent,checkpoint.child]);
  const matches=text('-C',repo,'worktree','list','--porcelain').split('\n\n')
    .filter(entry=>entry.split('\n').includes('worktree '+workspace.path));
  const workHead=text('-C',workspace.path,'rev-parse','HEAD');
  const git={workHead,workBranch:text('-C',workspace.path,'rev-parse','--abbrev-ref','HEAD'),
    parents:text('-C',workspace.path,'rev-parse','HEAD^@'),
    message:text('-C',workspace.path,'show','-s','--format=%B','HEAD'),
    childCommits:Number(text('-C',workspace.path,'rev-list','--count',workspace.base_commit+'..HEAD')),
    repoHead:text('-C',repo,'rev-parse','HEAD'),registrations:matches};
  return {attempt,workspace,extent:extent.n,intents,notices,receipts,provenance,processes,git};
}

export function readMarker(file,expectedOwnerPid){
  assert.match(file,/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}\/runtime-[A-Za-z0-9]+\/checkpoint-(?:worktree-built|commit-landed|notification-pending)\.json$/);
  assert.equal(realpathSync(file),file);
  const marker=JSON.parse(readFileSync(file,'utf8'));
  assert.equal(marker.ownerPid,expectedOwnerPid);
  assert(Number.isSafeInteger(marker.at));
  return marker;
}

export function verifyBeforeCrash(stage,marker,observed){
  const {workspace,attempt,git,provenance,intents,notices,receipts,extent}=observed;
  assert.equal(extent,1);
  assert.equal(git.registrations.length,1);
  assert.equal(git.workBranch,workspace.branch);
  assert.equal(git.repoHead,workspace.base_commit);
  assert.equal(notices.length,0);
  assert.equal(receipts.length,0);
  assert.equal(attempt.notified_at,null);
  if(stage==='worktree-built'){
    const original=intents.find(row=>row.intent_id===marker.intent);
    assert.equal(original?.action,'worktree_add');
    assert.equal(original?.state,'intended');
    assert.equal(workspace.state,'preparing');
    assert.equal(attempt.child_turn_id,null);
    assert.equal(git.workHead,workspace.base_commit);
    assert.equal(git.childCommits,0);
  }else{
    assert.equal(workspace.state,'ready');
    assert.equal(git.childCommits,1);
    assert.equal(git.parents,workspace.base_commit);
    const active=intents.find(row=>row.action==='child_result_commit' && row.expected_parent===workspace.base_commit);
    assert(active);
    assert(git.message.split('\n').includes('WillYou-Intent: '+active.intent_id));
    if(stage==='commit-landed'){
      assert.equal(active.intent_id,marker.intent);
      assert.equal(active.state,'intended');
      assert.equal(provenance.length,0);
      assert.equal(attempt.commit_range,null);
    }else if(stage==='notification-pending'){
      assert.equal(attempt.attempt_id,marker.attempt);
      assert.equal(active.state,'done');
      assert.equal(provenance.length,1);
      assert.equal(provenance[0].commit_sha,marker.commit);
      assert.deepEqual(JSON.parse(attempt.commit_range).commits,[marker.commit]);
    }else assert.fail('Unknown isolated checkpoint');
  }
}

export function verifyAfterRecovery(stage,before,after){
  assert.equal(after.workspace.workspace_id,before.workspace.workspace_id);
  assert.equal(after.attempt.attempt_id,before.attempt.attempt_id);
  assert.equal(after.workspace.path,before.workspace.path);
  assert.equal(after.workspace.branch,before.workspace.branch);
  assert.equal(after.workspace.state,'ready');
  assert.equal(after.extent,1);
  assert.equal(after.git.registrations.length,1);
  assert.equal(after.git.repoHead,before.git.repoHead);
  assert.equal(after.git.parents,after.workspace.base_commit);
  assert.equal(after.git.childCommits,1);
  if(stage!=='worktree-built')assert.equal(after.git.workHead,before.git.workHead);
  const intents=after.intents.filter(row=>row.action==='child_result_commit');
  assert.equal(intents.length,1);
  assert.equal(intents[0].state,'done');
  assert.equal(after.provenance.length,1);
  assert.equal(after.provenance[0].intent_id,intents[0].intent_id);
  assert.equal(after.provenance[0].commit_sha,after.git.workHead);
  assert.equal(after.provenance[0].attempt_id,after.attempt.attempt_id);
  assert.deepEqual(JSON.parse(after.attempt.commit_range).commits,[after.git.workHead]);
  assert.equal(after.notices.length,1);
  assert.equal(after.notices[0].status,'completed');
  assert.equal(after.notices[0].head,after.git.workHead);
  assert(after.attempt.notified_at);
  assert.equal(after.receipts.length,1);
  assert.equal(after.receipts[0].status,'completed');
}
