import assert from 'node:assert/strict';

export const readerWitness='A70_FIXED_SOURCE_WITNESS';
export const writerWitness='A70_LOCAL_SERIAL_WRITER_ACK';
export const finalWitness='A70_LOCAL_BOTH_REAL_CHILDREN_OBSERVED';
export const objective=[
 'Delegate through WillYou tools in this isolated repository. First use wy_targets.',
 'Dispatch one read-only child using profile A70 reader codex. Instruct it to read a70-baseline.txt via cat and report the real contents.',
 'Dispatch one shared-directory write-role child using profile A70 writer claude. It should answer A70_LOCAL_SERIAL_WRITER_ACK without changing files. Keep its write role for this queue check.',
 'End this native turn after both delegations. Do not call a shell tool in the parent, poll, or mark the goal complete before both child results arrive.',
 'Upon each host result notification use wy_observe to fetch that result. Once you have observed both results, say A70_LOCAL_BOTH_REAL_CHILDREN_OBSERVED and finish.',
].join(' ');

export function requestForLocal(kind, payload, model){
  assert(['claude','codex'].includes(kind));
  assert.equal(typeof payload.model,'string');
  assert.equal(model,'qwen3-coder:30b');
  const local={...payload,model};
  const omitted=[];
  if(kind==='codex'&&Array.isArray(local.tools)){
    local.tools=local.tools.filter(tool=>{
      if(tool.type==='custom'&&tool.name==='apply_patch'){omitted.push(tool.name);return false;}
      return true;
    });
    assert(omitted.length<=1);
  }
  return {local,omitted};
}

export function codexResults(payload){
  const input=payload.input??[];
  return input.filter(item=>item.type==='function_call_output'&&typeof item.call_id==='string').map(item=>{
    const call=input.find(candidate=>candidate.type==='function_call'&&candidate.call_id===item.call_id);
    const output=typeof item.output==='string'?item.output:JSON.stringify(item.output??[]);
    const name=call?.name??item.name??'';
    return {callId:item.call_id,isExecCommand:name==='exec_command',isObserve:name==='wy_observe'||name.endsWith('__wy_observe'),
      hasReaderWitness:output.includes(readerWitness),hasWriterWitness:output.includes(writerWitness)};
  });
}

export function successfulGoalReactivate(events,threadId,createdAt){
  const method='thread/goal/set';
  const request=events.find(e=>e.direction==='send'&&e.method===method&&e.threadId===threadId&&e.status==='active');
  const reply=request&&events.find(e=>e.direction==='recv'&&e.id===request.id&&e.method===method&&e.status==='active'&&e.threadId===threadId&&
    e.createdAt===createdAt&&e.seq>request.seq);
  return reply&&{request,reply};
}
