import assert from 'node:assert/strict';
import { execFileSync,spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import {createServer} from 'node:http';
import {join} from 'node:path';
import {openElectron,pause} from '../../prep-fef791bc6/electron-harness.mjs';
import {redirectHome} from '../../prep-fef791bc6/home-redirect-main.mjs';
import {isM14PreEntryRun} from '../../prep-fef791bc6/electron-isolation-paths.mjs';
import {installNativeTap} from '../../../g04/prep-next/a70/native-tap.mjs';
import {baselineFile,baselineContent,models,profileFixture,parseChildNotice} from '../../../g04/prep-next/a70/flow-v2.mjs';
import {openPrivateModel,provider as localProvider,model} from '../../../local-model/ollama-private.mjs';
import {forwardResponse} from '../../claude-prep-1214412aa/a19-forward-response.mjs';
import {requestForLocal,objective,readerWitness,writerWitness,finalWitness} from './oracle.mjs';

import { registerNativePrograms } from './native-programs.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,commit,asar,lease]=process.argv.slice(2);
assert.equal(lease,'sole-app-and-local-model-lease','No App or inference without explicit coordinator lease');
const kind='claude',vcs='svn',mode='normal';
const bundle=join(base,'package/mac-arm64/WillYou.app/Contents'),executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-[0-9]{3}$/);
assert.match(commit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(realpathSync(executable),executable);
assert.equal(digest(join(bundle,'Resources/app.asar')),asar);
assert.deepEqual(Object.keys(process.env).filter(key=>/KEY|TOKEN|PROXY/.test(key)),[]);
for(const port of [3425,3426]){
 const check=spawnSync('/usr/sbin/lsof',['-nP','-tiTCP:'+port,'-sTCP:LISTEN'],{encoding:'utf8',timeout:5000});
 assert.equal(check.status,1,'Expected private runtime port free: '+port);
 assert(!check.stdout&& !check.stderr);
}
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A70',sourceCommit:commit,asar,kind,vcs,mode,scope:'Focused R positive local model, real native link and workflow. Writer role confirms admission without mutation.',actions:[],requests:[],passed:false};
let app,rootTask,modelState,appTrusted=false,listener=false,phase='isolated fixture';
const cwd=join(root,'project');
const tab=JSON.stringify;
for(const name of ['scenario.mjs','oracle.mjs','native-programs.mjs','run-a70-real-local.sh','SHA256SUMS'])
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const relations=id=>app.invoke('agentTasks.relations',id);
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));

async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
function sql(query,args=[],cold=false){
  const db=join(data,'smartdd.db');assert.equal(realpathSync(db),db);
  if(cold)assert.equal(existsSync(db+'-wal'),false,'Cold sqlite cannot ignore committed WAL data');
  const py='import sqlite3,json,pathlib,sys;c=sqlite3.connect(pathlib.Path(sys.argv[1]).as_uri()+"?mode=ro"+("&immutable=1" if sys.argv[4]=="true" else ""),uri=True);c.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in c.execute(sys.argv[2],json.loads(sys.argv[3]))]))';
  return JSON.parse(execFileSync('/usr/bin/python3',['-c',py,db,query,JSON.stringify(args),String(cold)],{encoding:'utf8',timeout:10000}));
}



function eventRows(taskId,types){
  if(!types.length)return [];
  return sql('SELECT seq,event_type,payload,created_at FROM agent_events WHERE task_id=? AND event_type IN ('+types.map(()=>'?').join(',')+') ORDER BY seq',
    [taskId,...types]).map(({payload,...row})=>({...row,payload:JSON.parse(payload)}));
}
function intents(taskId){
  return sql("SELECT intent_id,action,state,result_json,created_at,updated_at FROM agent_intents WHERE task_id=? AND action IN ('goal_pause','goal_resume') ORDER BY rowid",[taskId])
    .map(({result_json,...row})=>({...row,result:result_json?JSON.parse(result_json):null}));
}
const bindings=taskId=>sql('SELECT binding_id,native_id,driver_id FROM agent_bindings WHERE task_id=?',[taskId]);
const runs=taskId=>sql('SELECT run_id,binding_id,generation,pid,process_started_at,owner_pid,owner_started_at,started_at,ended_at,state FROM capability_runs WHERE task_id=? ORDER BY started_at',[taskId]);
const byQueue=taskId=>sql('SELECT task_id,run_id,directory_identity,state,kind FROM agent_directory_queue WHERE task_id=?',[taskId]);
const available=()=>app.mainEvaluate('globalThis.__a70NativeTap.snapshot()');
const includesAnswer=(s,name)=>s.items.some(i=>i.type==='assistant_message'&&i.payload?.text===name);
const fullGoal='[data-testid="agent-goal"]';

function setupRepository(){
  const local=(exe,args)=>execFileSync(exe,args,{cwd:root,encoding:'utf8',env:{...env,PATH:'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'},timeout:15000}).trim();
  let readRevision;
  if(vcs==='git'){
    mkdirSync(cwd,{mode:0o700});
    const git=(...args)=>local('/usr/bin/git',['-C',cwd,...args]);
    git('init','-qb','main');
    assert.equal(git('remote'),'');
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    git('add',baselineFile);
    git('-c','user.name=Fixture','-c','user.email=a70@example.invalid','-c','commit.gpgsign=false','commit','-qm','A70 baseline');
    readRevision=()=>git('rev-parse','HEAD');
  }else{
    const repository=join(root,'svn-repository'),config=join(root,'svn-config');
    mkdirSync(config,{mode:0o700});
    const svn=(...args)=>local('/opt/homebrew/bin/svn',[...args,'--non-interactive','--config-dir',config]);
    local('/opt/homebrew/bin/svnadmin',['create',repository]);
    svn('checkout','file://'+repository,cwd);
    assert.equal(svn('info','--show-item','wc-root',cwd),cwd);
    writeFileSync(join(cwd,baselineFile),baselineContent+'\n',{flag:'wx',mode:0o600});
    svn('add',join(cwd,baselineFile));
    svn('commit','-m','Synthetic A70 baseline',cwd);
    readRevision=()=>svn('info','--show-item','revision',join(cwd,baselineFile));
  }
  assert.equal(realpathSync(cwd),cwd);
  const revision=readRevision(), baseline=digest(join(cwd,baselineFile));
  result.repository={cwd,vcs,revision,baseline};
  return {revision,baseline,readRevision};
}

async function config(){
  const fixture=setupRepository();
  const modelRoot=join(root,'local-model');mkdirSync(modelRoot,{mode:0o700});
  modelState=await openPrivateModel(modelRoot);
  result.localModel=modelState.provenance;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listener=true;resolve();});});
  const boot={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,startupMainHook:async info=>Object.assign(boot,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid]})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted=true;
  const birth=nativeIdentity(app.processId);
  assert(birth.state==='running'&&birth.startedAt);
  result.app={identity,boot,birth};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  const native=await registerNativePrograms((channel,...args)=>app.invoke(channel,...args));
  const ownerPaths={codex:native.codex.executable,claude:native.claude.executable};
  result.nativeDetection=Object.fromEntries(Object.entries(native).map(([kind,tool])=>[kind,{id:tool.id,version:tool.version,executable:tool.executable}]));
  result.nativePrograms=ownerPaths;
  await app.mainEvaluate(`(() => {
    const load=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json');
    const {app}=load('electron');
    if(!app.isPackaged||process.pid!==${app.processId}||app.getPath('home')!==${tab(home)}||app.getPath('userData')!==${tab(data)})
      throw Error('Wrong private App for passive native tap');
    globalThis.__a70NativeTap=(${installNativeTap.toString()})({childProcess:load('node:child_process'),fs:load('node:fs')},
      ${tab({cwd,home,data,...ownerPaths})});
    return true;
  })()`);
  const profileIds={},providerIds=new Set();
  for(const {role,kind:runner,provider} of profileFixture(kind,mode,origin)){
    const saved=await app.invoke('agents.saveProvider',{...provider,name:'A70 local Qwen '+role});
    assert(!providerIds.has(saved.id),'provider/tool pairs must be distinct for simultaneously tested roles');
    providerIds.add(saved.id);
    const row=await app.invoke('agents.save',{name:'A70 '+role+' '+runner,toolId:native[runner].id,source:'provider',
      providerId:saved.id,models:[models[role]],defaultModel:models[role],isDefault:role==='parent'});
    profileIds[role]=row.id;
  }
  assert.equal(providerIds.size,Object.keys(profileIds).length);
  const project=await app.invoke('projects.create',{name:'A70 exact '+vcs,aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  const task=async role=>{
    const title='A70 '+role+' '+kind+' '+vcs;
    const row=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title,profileId:profileIds[role],model:models[role],tier:'ask'});
    return {taskId:row.taskId,title};
  };
  rootTask=await task('parent');
  result.tasks={root:rootTask};
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(toggle)+'?.innerText.includes("已开启")'))await click(toggle);
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  await click('[data-testid="nav-home"]');
  return fixture;
}
async function verifyOwnerEnded(original,rows){
  const wire=rows.find(owner=>owner.pid===original.pid);
  assert(wire?.exit,'original real native ChildProcess exit record');
  const kernel=nativeIdentity(original.pid);
  assert(kernel.state==='stopped'||kernel.state==='running'&&kernel.startedAt!==original.process_started_at);
  assert.equal(original.owner_pid,app.processId);
  assert.equal(original.owner_started_at,result.app.birth.startedAt);
  return {wire,kernel};
}
function goalWire(waited,rootOwned,rootKind,childFirst,rootTurn){
  const nativeId=waited.binding.native_id;
  if(rootKind==='claude'){
    const blocked=rootOwned.events.find(f=>f.direction==='send'&&f.method==='hook/Stop'&&f.continued===false);
    assert(blocked,'real original Claude Stop callback never answered continue:false');
    const matched=rootOwned.events.find(f=>f.direction==='recv'&&f.method==='hook/Stop'&&f.id===blocked.id);
    assert(matched&&matched.sessionId===nativeId&&matched.seq<blocked.seq);
    assert(blocked.at<=childFirst);
    assert(!rootOwned.events.some(event=>event.method==='tool/bash'),'no real parent shell polling before serial hand-off');
    return {trigger:matched,blocked,parentBashInvocations:0};
  }
  const pause=rootOwned.events.find(f=>f.direction==='send'&&f.method==='thread/goal/set'&&f.threadId===nativeId&&f.status==='paused');
  const completed=rootOwned.events.find(f=>f.direction==='recv'&&f.method==='turn/completed'&&f.status==='completed'&&f.turnId===rootTurn.native_turn_id&&f.seq<(pause?.seq??0));
  assert(pause&&completed,'missing genuine Codex completed event and immediate host pause');
  assert.equal(pause.threadId,nativeId);
  assert(pause.at<=childFirst);
  const orphans=rootOwned.events.filter(f=>f.direction==='recv'&&f.method==='turn/started'&&f.seq>completed.seq);
  const settled=orphans.map(f=>{
    const interrupt=rootOwned.events.find(i=>i.direction==='send'&&i.method==='turn/interrupt'&&i.turnId===f.turnId);
    const ended=rootOwned.events.find(i=>i.direction==='recv'&&i.method==='turn/completed'&&i.turnId===f.turnId);
    const work=rootOwned.events.filter(i=>i.method==='item/started'&&i.turnId===f.turnId);
    assert(interrupt&&ended&&f.seq<interrupt.seq&&interrupt.seq<ended.seq);
    assert.equal(ended.status,'interrupted');
    assert.deepEqual(work,[]);
    assert.ok(ended.at<=childFirst);
    return {start:f,end:ended,interrupt,work};
  });
  return {pause,initialCompleted:completed,orphans:settled,orphanObserved:settled.length>0};
}


const childRequests = { reader:[], writer:[] };
let releaseWriter;
const writerGate = new Promise(resolve=>{releaseWriter=resolve;});
const server = createServer(async(req,res)=>{
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({data:[models.parent,models.reader,models.writer].map(id=>({id}))}));
      return;
    }
    const native=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!native){res.statusCode=404;res.end();return;}
    assert([req.headers.authorization,req.headers['x-api-key']].some(token=>token==='magpie-'+native||token==='Bearer magpie-'+native));
    let bytes=0;
    const parts=[];
    for await(const part of req){bytes+=part.length; assert(bytes<6*1024*1024); parts.push(part);}
    const body=JSON.parse(Buffer.concat(parts));
    const role=['parent','reader','writer'].find(name=>models[name]===body.model);
    assert(role && (role==='parent'?'claude':'codex')===native);
    assert(result.requests.length<45,'Bounded real model trial');
    const {local,omitted}=requestForLocal(native,body,model);
    const quoted=JSON.stringify(native==='claude'?body.messages:body.input);
    const scope={role,native,at:Date.now(),bytes,omitted,readerCanary:quoted.includes(readerWitness), writerCanary:quoted.includes(writerWitness)};
    if(role==='parent')scope.notification=parseChildNotice('claude',body);
    result.requests.push(scope);
    if(role!=='parent')childRequests[role].push(scope);
    if(role==='writer'&&childRequests.writer.length===1)await writerGate;
    if(res.destroyed)return;
    const target=localProvider+url.pathname;
    assert.equal(new URL(target).origin,'http://127.0.0.1:3426');
    const headers={'content-type':'application/json'};
    if(native==='claude'){
      headers['anthropic-version']=req.headers['anthropic-version']??'2023-06-01';
      if(req.headers['anthropic-beta'])headers['anthropic-beta']=req.headers['anthropic-beta'];
    }
    await forwardResponse(res,signal=>fetch(target,{method:'POST',headers,body:JSON.stringify(local),redirect:'error',signal}),scope,180000);
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.writeHead(400);
    res.end();
  }
});

async function main(fixture){
  phase='warm real local Claude tool session';
  await open(rootTask);
  await send('Reply exactly A70_LOCAL_WARM and do not call tools.');
  await until(async()=>{const s=await state(rootTask.taskId);return !s.run?.busy&&includesAnswer(s,'A70_LOCAL_WARM')&&s;},'private local Claude takes actual warm turn',180000);
  const toggle='[data-testid="agent-delegation-toggle"]';
  await click(toggle);
  await app.waitFor(selected(toggle)+'?.getAttribute("aria-pressed")==="true"',10000);
  phase='natural-language goal and real delegation in SVN';
  await send('/goal '+objective);
  const waiting=await until(async()=>{
    const snap=await state(rootTask.taskId), family=await relations(rootTask.taskId);
    if(snap.requests.length)throw Error('Unexpected approval in the unattended positive case');
    if(snap.goal?.status!=='paused'||snap.goal.pausedReason!=='waiting_children'||family.children.length!==2||!childRequests.writer.length||!childRequests.reader.length)return false;
    const pause=intents(rootTask.taskId).find(row=>row.action==='goal_pause'&&row.state==='done');
    const binding=bindings(rootTask.taskId).find(row=>row.binding_id===snap.goal.bindingId);
    if(!pause||!binding?.native_id)return false;
    const before=runs(rootTask.taskId).find(run=>run.binding_id===binding.binding_id);
    const owner=(await available()).find(row=>row.pid===before?.pid);
    return before?.ended_at&&owner?.exit&&{snap,family,pause,binding,before,owner};
  },'true pause, same parent identity, and both genuine child lanes',320000);
  const {snap,family,pause,binding,before,owner}=waiting;
  const writer=family.children.find(child=>child.access==='write');
  const readonly=family.children.find(child=>child.access==='read');
  assert(writer && readonly);
  assert.equal(writer.workspaceMode,'shared');
  assert.equal(snap.goal.objective,objective);
  assert.equal(pause.result.bindingId,binding.binding_id);
  assert.equal(pause.result.revision,snap.goal.revision);
  const writerFirst=childRequests.writer[0].at;
  assert(Date.parse(before.ended_at)<=writerFirst);
  assert(owner.exit.at<=writerFirst);
  const writerQueue=byQueue(writer.childTaskId),readerQueue=byQueue(readonly.childTaskId);
  assert.equal(writerQueue.filter(row=>row.kind==='write'&&row.state==='active').length,1);
  assert.deepEqual(readerQueue,[]);
  result.waiting={goal:snap.goal,binding,writer,reader:readonly,writerQueue,readerQueue,paused:pause,
    oldOwner:await verifyOwnerEnded(before,[owner]),hook:goalWire(waiting,owner,'claude',writerFirst,null)};
  await app.waitFor(selected(fullGoal)+'?.innerText.includes("等子任务，已自动暂停")',8000);
  await app.screenshot(join(out,'01-real-local-model-wait.png'));
  releaseWriter();
  phase='real two child notifications wake original Claude session';
  const outcome=await until(async()=>{
    const stateNow=await state(rootTask.taskId);
    const notices=stateNow.items.filter(item=>item.type==='notification'&&[writer.childTaskId,readonly.childTaskId].includes(item.payload?.childTaskId));
    const turns=stateNow.turns.filter(t=>t.source_kind==='notification'&&t.status==='completed');
    const resume=intents(rootTask.taskId).find(row=>row.action==='goal_resume'&&row.state==='done');
    if(resume&&notices.length===2&&turns.length===2&&!stateNow.run?.busy&&stateNow.items.some(i=>i.type==='assistant_message'&&i.payload?.text?.includes(finalWitness)))return {stateNow,notices,turns,resume};
    return false;
  },'actual model naturally responds after both host notices and original session resumes',320000);
  assert.deepEqual(new Set(outcome.notices.map(i=>i.payload.childTaskId)),new Set([writer.childTaskId,readonly.childTaskId]));
  assert(outcome.notices.every(i=>i.payload.status==='completed'));
  assert.equal(outcome.resume.result.revision,snap.goal.revision);
  assert.equal(outcome.resume.result.bindingId,binding.binding_id);
  for(const [task,witness,role] of [[readonly,readerWitness,'reader'],[writer,writerWitness,'writer']]) {
    const child=await state(task.childTaskId);
    assert(child.items.some(item=>item.type==='assistant_message'&&item.payload?.text?.includes(witness)));
    assert.equal(child.selection.driverId,'codex-app-server');
    assert(childRequests[role].every(request=>request.upstreamStatus===200));
  }
  assert(childRequests.reader.some(request=>request.readerCanary),'real read-only native tool output includes disk canary');
  const routed=result.requests.filter(request=>request.role==='parent'&&request.notification).map(request=>request.notification);
  assert.deepEqual(new Set(routed.map(notice=>notice.childTaskId)),new Set([writer.childTaskId,readonly.childTaskId]));
  assert(routed.every(notice=>notice.status==='completed'&&notice.attempt===1));
  assert.equal(bindings(rootTask.taskId).length,1);
  const parentRuns=runs(rootTask.taskId),wires=await available();
  const successors=outcome.turns.map(turn=>parentRuns.find(run=>run.run_id===turn.run_id));
  assert(successors.every(run=>run?.binding_id===binding.binding_id&&run.generation>before.generation));
  assert(successors.every(run=>wires.find(p=>p.pid===run.pid)?.events?.some(event=>event.method==='system/init'&&event.sessionId===binding.native_id)));
  assert.equal(fixture.readRevision(),fixture.revision);
  assert.equal(digest(join(cwd,baselineFile)),fixture.baseline);
  result.final={goal:outcome.stateNow.goal,notices:routed,resume:outcome.resume,parentRuns,successors};
  await app.screenshot(join(out,'02-real-local-model-resumed.png'));
}

try{
  const fixture=await config();
  await main(fixture);
  result.passed=true;
}catch(error){
  result.failure={phase,error:String(error.stack??error)};
  if(appTrusted)try{result.visible=await app.evaluate('document.body.innerText.slice(0,9000)');await app.screenshot(join(out,'99-failure.png'));}catch{}
}finally{
  releaseWriter();
  if(appTrusted){
    try{
      if(!result.passed){
        for(const task of (await app.invoke('agentTasks.list')).filter(row=>!row.parentTaskId&&['working','waiting'].includes(row.status)))
          await app.invoke('agentTasks.stop',task.taskId,true);
      }
      result.nativeWire=await available();
      await app.mainEvaluate(`(() => {const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(process.pid!==${app.processId}||E.app.getPath('userData')!==${tab(data)}||process.execPath!==${tab(executable)})throw Error('Wrong isolated App');
        globalThis.__a70NativeTap?.restore();delete globalThis.__a70NativeTap;
        setTimeout(()=>E.app.quit(),150);return true;})()`,{label:'a70-schedule-owned-app-quit',synchronous:true});
    }catch(error){result.quitError=String(error);}
    try {result.exit=await app.waitForExit(27000);}
    catch(error){result.exitError=String(error);try{result.fallback=await app.crash();}catch{}}
    result.rendererErrors=app.rendererErrors;
    writeFileSync(join(out,'app.log'),app.logs(),{mode:0o600});
    try{
      const db=join(data,'smartdd.db'),cold=result.exit?.pid===app.processId&&result.exit.code===0&&result.exit.signal===null&&!existsSync(db+'-wal');
      const owners=sql('SELECT pid,process_started_at FROM capability_run_processes WHERE pid IS NOT NULL AND run_id IN (SELECT run_id FROM capability_runs WHERE owner_pid=?)',[app.processId],cold);
      result.exitProcesses=owners.map(row=>{
        const observed=nativeIdentity(row.pid);
        assert(observed.state==='stopped'||observed.startedAt!==row.process_started_at);
        return {...row,observed};
      });
    }catch(error){result.processProofError=String(error);}
  } else if(app)try{result.unverifiedOwnLaunchExit=await app.crash();}catch(error){result.cleanupError=String(error);}
  if(listener){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.listenerClosed=!server.listening;
  if(modelState)try{result.modelExit=await modelState.stop();}catch(error){result.modelExitError=String(error);}
  result.modelPortReleased=spawnSync('/usr/sbin/lsof',['-nP','-tiTCP:3426','-sTCP:LISTEN'],{encoding:'utf8',timeout:5000}).status===1;
  result.passed=Boolean(result.passed&&result.exit?.code===0&&result.exit.signal===null&&!result.rendererErrors?.length&&result.exitProcesses?.length>=3&&
    result.modelExit?.code===0&&result.listenerClosed&&result.modelPortReleased&&!result.serverError);
  writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({out,passed:result.passed,phase,exit:result.exit,error:result.failure,modelExit:result.modelExit}));
}
if(!result.passed)process.exitCode=2;
