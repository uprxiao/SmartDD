#!/bin/bash
set -euo pipefail
c=/private/tmp/willyou-m14-stage6.WRvdST
dir="$c/g03/prep-next/a70-real-local"
node_bin=/Users/liubu/.hermes/node/bin/node
clean=(/usr/bin/env -i PATH='/Users/liubu/.hermes/node/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin' LANG=en_US.UTF-8 TZ=Asia/Singapore)
[[ "$#" -eq 1 ]]
cd "$c/source"
"${clean[@]}" "$node_bin" -e 'const a=require("node:assert/strict");a.equal(process.execPath,process.argv[1]);a.equal(process.version,"v22.23.1");a.equal(typeof WebSocket,"function")' "$node_bin"
if [[ "$1" == --preflight-entry ]]; then
  exec "${clean[@]}" "$node_bin" "$dir/scenario.mjs" "$c/g03/attempt-999" '' '' no-lease
fi
[[ "$1" =~ ^attempt-[0-9]{3}$ ]]
[[ "${M14_A70_REAL_LOCAL_LEASE:-}" == sole-app-and-local-model-lease ]]
[[ "${M14_EXPECTED_SOURCE_COMMIT:-}" =~ ^[a-f0-9]{40}$ ]]
[[ "${M14_EXPECTED_ASAR_SHA256:-}" =~ ^[a-f0-9]{64}$ ]]
[[ ! -e "$c/g03/$1" ]]
exec "${clean[@]}" "$node_bin" "$dir/scenario.mjs" "$c/g03/$1" "$M14_EXPECTED_SOURCE_COMMIT" "$M14_EXPECTED_ASAR_SHA256" "$M14_A70_REAL_LOCAL_LEASE"
