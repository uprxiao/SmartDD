import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {existsSync,mkdirSync,readFileSync,realpathSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';

export const homeBase='/private/tmp/willyou-m14-stage6.WRvdST';
export const timing={productionMs:120000,fixtureCeilingMs:145000,minLiveMs:115000,maxLiveMs:137000};
export const title='A66 同名中文 Projects with Spaces';
export const childTitle='A66 Final Boundary Writer';
export const branch='feature/0.1.14';
export const mappedDir='packages/web';
export const canary='probe-result.txt';
export const childBytes='A66_CHILD_WORKTREE_ONLY\n';
export const markers={start:'a66-timeout-start.json',end:'a66-timeout-end.json',output:'A66_OFFLINE_FIXTURE_HOLD_STARTED',signal:'A66_OFFLINE_FIXTURE_TERMINATED'};
const privateRoot=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/(?:attempt-\d{3}|prep-next\/a66-final-gaps\/preflight-[A-Za-z0-9]+)\/runtime-[A-Za-z0-9]+$/;
export const hash=/^[a-f0-9]{40}$/;
const shQuote=s=>"'"+s.replaceAll("'","'\\''")+"'";
const nodePath='/Users/liubu/.hermes/node/bin/node';

export function assertRoot(root){
  assert.match(root,privateRoot);
  assert.equal(realpathSync(root),root);
}
export function safeGit(cwd,args,env){
  assert.equal(realpathSync(cwd),cwd);
  return execFileSync('/usr/bin/git',['-C',cwd,...args],{encoding:'utf8',env,timeout:10000}).trim();
}
export function installScript(root){
  assertRoot(root);
  return [
    "import assert from 'node:assert/strict';",
    "import {realpathSync,writeFileSync} from 'node:fs';",
    "import {join} from 'node:path';",
    "const root="+JSON.stringify(root)+", cwd=realpathSync(process.cwd());",
    "const prefix=join(root,'home/.willyou/worktrees')+'/';",
    "assert(cwd.startsWith(prefix)&&cwd.endsWith('/packages/web')&&!/\\s/.test(cwd));",
    "assert.equal(process.env.HOME,join(root,'home'));",
    "const at=Date.now(),pid=process.pid,ppid=process.ppid;",
    "const write=(name,obj)=>writeFileSync(join(cwd,name),JSON.stringify(obj)+'\\n',{mode:0o600,flag:'wx'});",
    "write("+JSON.stringify(markers.start)+",{cwd,at,pid,ppid});",
    "console.error("+JSON.stringify(markers.output)+");",
    "process.once('SIGTERM',()=>{write("+JSON.stringify(markers.end)+",{cwd,at:Date.now(),pid,signal:'SIGTERM'});",
    "console.error("+JSON.stringify(markers.signal)+");process.exit(143);});",
    "setTimeout(()=>{write("+JSON.stringify(markers.end)+",{cwd,at:Date.now(),pid,signal:'fixture-deadline'});process.exit(81);},"+timing.fixtureCeilingMs+");",
  ].join('\n')+'\n';
}

export function seed(root,slot,environment,axis){
  assertRoot(root);
  assert(['a','b'].includes(slot)&&['timeout','names-path'].includes(axis));
  const repo=join(root,'repo-'+slot),cwd=join(repo,mappedDir);
  mkdirSync(cwd,{recursive:true,mode:0o700});
  const env={...environment,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0'};
  const git=(where,...args)=>safeGit(where,args,env);
  const initial=slot==='a'?'AUTHORED_A\n':'AUTHORED_B\n';
  const put=(path,data)=>writeFileSync(path,data,{mode:0o600,flag:'wx'});
  put(join(repo,'.gitignore'),'node_modules/\n'+markers.start+'\n'+markers.end+'\n');
  put(join(repo,'original.txt'),initial);
  put(join(cwd,'README.md'),'Private synthetic repository '+slot+'\n');
  if(axis==='timeout'){
    assert.equal(slot,'a');
    const name='a66-timeout-probe',version='1.0.0';
    put(join(cwd,'package.json'),JSON.stringify({name,version,private:true,scripts:{postinstall:nodePath+' ./hold-install.mjs'}}));
    put(join(cwd,'package-lock.json'),JSON.stringify({name,version,lockfileVersion:3,requires:true,
      packages:{'':{name,version,hasInstallScript:true}}}));
    put(join(cwd,'hold-install.mjs'),installScript(root));
  }else put(join(cwd,'pom.xml'),'<project><modelVersion>4.0.0</modelVersion></project>\n');
  git(repo,'init','-qb',branch);
  git(repo,'config','--local','user.name','A66 Local Fixture');
  git(repo,'config','--local','user.email','a66-fixture@example.invalid');
  git(repo,'config','--local','commit.gpgSign','false');
  git(repo,'add','-A');
  git(repo,'commit','-qm','A66 isolated base '+slot);
  const base=git(repo,'rev-parse','HEAD');
  writeFileSync(join(repo,'original.txt'),'DIRTY_'+slot+'\n',{mode:0o600});
  assert.equal(git(repo,'remote'),'');
  assert.equal(git(repo,'status','--porcelain'),'M original.txt');
  const external=join(root,'manual-worktree-'+slot);
  const manual='Git private worktree '+slot;
  assert.match(base,hash);
  const manualCommand='/usr/bin/git -C '+shQuote(repo)+' worktree add -b a66-shell-created-'+slot+' '+shQuote(external)+' '+base;
  return {slot,repo,cwd,base,env,git,initial,external,manualCommand,manual};
}

export function verifyWorkspace(workspace,fixture,project,root){
  assert.equal(workspace.repo_root,fixture.repo);
  assert.equal(workspace.base_commit,fixture.base);
  assert.equal(workspace.state,'ready');
  assert.equal(realpathSync(workspace.path),workspace.path);
  const prefix=join(root,'home/.willyou/worktrees')+'/';
  assert(workspace.path.startsWith(prefix));
  assert(/^[\x21-\x7e]+$/.test(workspace.path));
  const [segment]=workspace.path.slice(prefix.length).split('/');
  assert(segment.endsWith('-'+project.id.replace(/[^a-zA-Z0-9]/g,'').slice(0,6)));
  assert(segment.startsWith('a66-projects-with-spaces-'));
  assert.equal(readFileSync(join(workspace.path,'original.txt'),'utf8'),fixture.initial);
  const mapped=join(workspace.path,mappedDir);
  assert.equal(realpathSync(mapped),mapped);
  assert(!existsSync(join(fixture.cwd,markers.start)));
  return {mapped,segment};
}
export const writeCommand=mapped=>"printf 'A66_CHILD_WORKTREE_ONLY\\n' > "+shQuote(join(mapped,canary))+' && pwd -P';
