#!/bin/bash
set -euo pipefail
candidate=/private/tmp/willyou-m14-stage6.WRvdST
driver_dir="$candidate/g03/prep-next/a66-pm-recovery/restart"
driver="$driver_dir/a66-restart-packaged-v6.mjs"
node_bin='/Users/liubu/.hermes/node/bin/node'
codex_bin='/Users/liubu/.local/lib/node_modules/@openai/codex/bin/codex.js'
clean=(/usr/bin/env -i PATH='/Users/liubu/.hermes/node/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
  LANG=en_US.UTF-8 TZ=Asia/Singapore M14_SMOKE_CLAUDE='/Users/liubu/.local/share/claude/versions/2.1.326' M14_SMOKE_CODEX="$codex_bin")
runtime=$("${clean[@]}" "$node_bin" -e 'const a=require("node:assert/strict"); a.equal(process.execPath,process.argv[1]); a.equal(process.version,"v22.23.1"); a.equal(typeof WebSocket,"function"); a.equal(typeof fetch,"function"); console.log(JSON.stringify({executable:process.execPath,version:process.version,webSocket:typeof WebSocket,fetch:typeof fetch}));' "$node_bin")
if [[ "$#" -eq 2 && "$1" == --preflight-entry ]]; then
  [[ "$2" == notification-pending || "$2" == commit-landed || "$2" == worktree-built ]]
  cd "$candidate/source"
  # Exercise the exact entry file and stage with an intentionally invalid lease.
  exec "${clean[@]}" "$node_bin" "$driver" "$candidate/g03/attempt-999" "$2" no-lease
fi
if [[ "$#" -eq 1 && "$1" == --preflight ]]; then
  echo "$runtime"
  private_probe=$(/usr/bin/mktemp -d "$driver_dir/cli-preflight.XXXXXXXX")
  /bin/mkdir -p "$private_probe/home/.codex"
  "${clean[@]}" HOME="$private_probe/home" CODEX_HOME="$private_probe/home/.codex" TMPDIR="$private_probe" "$codex_bin" --version
  exit 0
fi
[[ "$#" -eq 2 ]]
[[ "$1" =~ ^attempt-[0-9]{3}$ ]]
[[ "$2" == notification-pending || "$2" == commit-landed || "$2" == worktree-built ]]
[[ "${M14_A66_RESTART_LEASE:-}" == isolated-acceptance-lease ]]
cd "$candidate/source"
out="$candidate/g03/$1"
[[ ! -e "$out" ]]
echo "$runtime"
status=0
"${clean[@]}" "$node_bin" "$driver" "$out" "$2" "$M14_A66_RESTART_LEASE" || status=$?
if [[ -d "$out" ]]; then
  /bin/cp "$driver_dir/run-a66-restart-v6.sh" "$out/source-run-a66-restart-v6.sh"
  echo "$runtime" > "$out/node-runtime.json"
fi
exit "$status"
