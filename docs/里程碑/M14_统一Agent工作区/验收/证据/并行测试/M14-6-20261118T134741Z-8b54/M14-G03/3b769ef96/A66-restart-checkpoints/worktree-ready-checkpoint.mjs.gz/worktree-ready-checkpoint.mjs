import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync,realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { candidate,expectedAsar } from './checkpoints.mjs';

const sourceBoundary={
  before:'emit(input.childTaskId, "workspace.ready", { path: path2, branch });',
  transactionEnd:'});',
  hit:'return { workspace: this.workspace(input.childTaskId), cwd: childCwd };',
  after:'} catch (e) {',
};
const approved=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/(?:attempt-\d{3}|prep-next\/a66-pm-recovery\/restart\/preflight-[A-Za-z0-9]+)\/runtime-[A-Za-z0-9]+$/;
const id=/^[a-f0-9-]{36}$/;

const activeArchive=join(candidate,'package/mac-arm64/WillYou.app/Contents/Resources/app.asar');
export const preservedArchive=join(candidate,'package-3b769ef96/mac-arm64/WillYou.app/Contents/Resources/app.asar');

export function worktreeReadyAnchor(archive=activeArchive){
  assert([activeArchive,preservedArchive].includes(archive),'Unexpected archive');
  assert.equal(realpathSync(archive),archive);
  assert.equal(createHash('sha256').update(readFileSync(archive)).digest('hex'),expectedAsar);
  const loader=createRequire(import.meta.url);
  const asar=loader('/Users/liubu/hx/4.uprxiao/SmartDD/node_modules/.pnpm/@electron+asar@3.4.1/node_modules/@electron/asar');
  const source=asar.extractFile(archive,'out/main/index.js');
  const lines=source.toString().split('\n').map(line=>line.trim());
  const hits=lines.flatMap((line,index)=>line===sourceBoundary.hit&&lines[index-2]===sourceBoundary.before&&
    lines[index-1]===sourceBoundary.transactionEnd&&lines[index+1]===sourceBoundary.after?[index]:[]);
  assert.equal(hits.length,1);
  return {lineNumber:hits[0],statement:sourceBoundary.hit,
    mainSha256:createHash('sha256').update(source).digest('hex')};
}

export function createWorktreeReadyCondition({runtime,parent,repo,pid,timeout=16000}){
  assert.match(runtime,approved);
  assert.equal(realpathSync(runtime),runtime);
  assert.match(parent,id);
  assert.equal(repo,join(runtime,'repo'));
  assert(Number.isSafeInteger(pid)&&pid>1);
  assert(Number.isSafeInteger(timeout)&&timeout>=0&&timeout<=18000);
  const artifact=join(runtime,'checkpoint-worktree-built.json');
  const prefix=join(runtime,'home/.willyou/worktrees')+'/';
  const condition='(()=>{if(process.pid!=='+pid+' || input.parentTaskId!=='+JSON.stringify(parent)+
    ' || repo.root!=='+JSON.stringify(repo)+' || !path2.startsWith('+JSON.stringify(prefix)+'))return false;'+
    'const fs=process.getBuiltinModule("fs"), file='+JSON.stringify(artifact)+';if(fs.existsSync(file))return false;'+
    'fs.writeFileSync(file,JSON.stringify({stage:"worktree-built",ownerPid:process.pid,at:Date.now(),parent:input.parentTaskId,'+
    'child:input.childTaskId,intent,workspaceId:id2,path:path2,branch,base}),{flag:"wx",mode:0o600});'+
    'Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,'+timeout+');return false;})()';
  return {artifact,condition};
}

export async function armWorktreeReady(app,proof,options){
  assert.equal(app.processId,options.pid);
  assert.equal(proof.asarHash,expectedAsar);
  const anchor=worktreeReadyAnchor();
  assert.equal(anchor.mainSha256,proof.mainSha256);
  const {artifact,condition}=createWorktreeReadyCondition(options);
  const expression='(async()=>{const key=Symbol.for("a66-isolated-checkpoint");'+
    'if(globalThis[key])throw Error("A66 checkpoint already armed");'+
    'const session=new (process.getBuiltinModule("inspector").Session)();session.connect();'+
    'const post=(name,args={})=>new Promise((resolve,reject)=>session.post(name,args,(err,result)=>err?reject(err):resolve(result)));'+
    'const urls=new Set();session.on("Debugger.scriptParsed",event=>urls.add(event.params.url));'+
    'await post("Debugger.enable");'+
    'const hits=[...urls].filter(url=>url.endsWith("/Contents/Resources/app.asar/out/main/index.js"));'+
    'if(hits.length!==1){session.disconnect();throw Error("Exact packaged main must be loaded");}'+
    'const set=await post("Debugger.setBreakpointByUrl",{url:hits[0],lineNumber:'+anchor.lineNumber+',condition:'+JSON.stringify(condition)+'});'+
    'if(set.locations.length!==1||set.locations[0].lineNumber!=='+anchor.lineNumber+'){'+
    'await post("Debugger.disable");session.disconnect();throw Error("Packaged ready checkpoint relocated or ambiguous");}'+
    'globalThis[key]=session;return {url:hits[0],...set};})()';
  const armed=await app.mainEvaluate(expression);
  assert.equal(armed.locations.length,1);
  return {...armed,...anchor,artifact};
}

export function verifyReadyBeforeNative(marker,observed,acceptedChildTurn,actualChildRunCount){
  const {workspace,attempt,git,extent,intents,notices,receipts,provenance}=observed;
  assert.equal(workspace.workspace_id,marker.workspaceId);
  assert.equal(workspace.path,marker.path);
  assert.equal(workspace.state,'ready');
  assert.equal(JSON.parse(workspace.deps_result).state,'skipped');
  assert.equal(extent,1);
  assert.equal(git.registrations.length,1);
  assert.equal(git.workBranch,marker.branch);
  assert.equal(git.workHead,marker.base);
  assert.equal(git.repoHead,marker.base);
  assert.equal(git.childCommits,0);
  const original=intents.find(row=>row.intent_id===marker.intent);
  assert.equal(original?.action,'worktree_add');
  assert.equal(original?.state,'done');
  assert.equal(attempt.delivery_state,'queued');
  assert.equal(attempt.notified_at,null);
  assert.equal(attempt.commit_range,null);
  assert.match(attempt.child_turn_id,id);
  assert.equal(acceptedChildTurn.turn_id,attempt.child_turn_id);
  assert.equal(acceptedChildTurn.client_input_id,'delegate-'+attempt.attempt_id);
  assert.equal(acceptedChildTurn.source_kind,'delegation');
  assert.equal(acceptedChildTurn.status,'accepted');
  assert.equal(acceptedChildTurn.run_id,null);
  assert.equal(actualChildRunCount,0);
  assert.equal(provenance.length,0);
  assert.equal(notices.length,0);
  assert.equal(receipts.length,0);
}

export function verifyReadyAfterNative(marker,before,after,actualChildTurn){
  assert.equal(after.attempt.child_turn_id,before.attempt.child_turn_id);
  assert.equal(actualChildTurn.turn_id,before.attempt.child_turn_id);
  assert.equal(actualChildTurn.status,'completed');
  assert.match(actualChildTurn.run_id,id);
  const intents=after.intents.filter(row=>row.action==='worktree_add');
  assert.equal(intents.length,1);
  assert.equal(intents[0].intent_id,marker.intent);
  assert.equal(intents[0].state,'done');
}
