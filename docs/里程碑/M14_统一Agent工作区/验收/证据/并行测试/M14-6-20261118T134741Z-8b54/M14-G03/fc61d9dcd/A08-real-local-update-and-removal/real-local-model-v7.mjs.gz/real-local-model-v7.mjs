import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { dirname, join } from 'node:path';
import { openElectron, pause } from '../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../prep-fef791bc6/home-redirect-main.mjs';
import { forwardResponse } from '../../claude-prep-1214412aa/a19-forward-response.mjs';
import { isA08OwnedApproval } from './owned-approval-v3.mjs';
import { openPrivateModel, provider as localProvider, model } from '../../../local-model/ollama-private.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,sourceCommit,testKind]=process.argv.slice(2);
assert(['claude','codex'].includes(testKind));
const testedKinds=[testKind];
const executable=process.env.M14_ACCEPTANCE_APP;
const asar=process.env.M14_EXPECTED_ASAR_SHA256;
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-[0-9]+$/);
assert.match(sourceCommit??'',/^[0-9a-f]{40}$/);
assert.match(asar??'',/^[0-9a-f]{64}$/);
assert.equal(process.cwd(),join(base,'source'));
assert.equal(executable,join(base,'package/mac-arm64/WillYou.app/Contents/MacOS/WillYou'));
assert.equal(realpathSync(executable),executable);
assert.equal(readFileSync(join(base,'source-commit.txt'),'utf8').trim(),sourceCommit);
assert.equal(createHash('sha256').update(readFileSync(join(base,'package/mac-arm64/WillYou.app/Contents/Resources/app.asar'))).digest('hex'),asar);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-')));
const home=join(root,'home'), userData=join(root,'data'), cwd=join(root,'work');
for(const dir of [home,userData,cwd])mkdirSync(dir,{mode:0o700});
assert(!existsSync(join(cwd,'.git'))&&!existsSync(join(cwd,'.svn')));
const env={
  HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  npm_config_cache:join(root,'npm-cache'),npm_config_offline:'true',npm_config_audit:'false',npm_config_fund:'false',
  npm_config_userconfig:join(root,'test-npm-empty-user'),npm_config_globalconfig:join(root,'test-npm-empty-global'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',
  ENABLE_TOOL_SEARCH:'false',NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',
  HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
};
assert.deepEqual(Object.keys(process.env).filter(k=>/KEY|TOKEN|PROXY/.test(k)),[]);
const modelRoot=join(root,'local-model');
mkdirSync(modelRoot,{mode:0o700});
let modelState;
const hookResult={};
const result={bootstrap:hookResult,sourceCommit,asar,executable,scope:'A08: packaged App and real native CLI; keyless local Qwen3-Coder; Codex adapter omits only unsupported, unused freeform apply_patch',testKind,
  observations:[],requests:[],actions:[],status:'failed'};
const port=3425;
const origin='http://127.0.0.1:'+port;
let app;
const selectorExpr = selector => `document.querySelector(${JSON.stringify(selector)})`;
async function click(selector, text = null) {
  const query = text ? `[...document.querySelectorAll(${JSON.stringify(selector)})].filter(item => item.innerText.includes(${JSON.stringify(text)}))`
    : `[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const hit = `(() => {
    const nodes = ${query};
    const node = nodes.length === 1 && nodes[0];
    if (!node || node.disabled) return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});
    const rect=node.getBoundingClientRect(), x=rect.x+rect.width/2, y=rect.y+rect.height/2;
    return rect.width&&rect.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;
  })()`;
  await app.waitFor('Boolean('+hit+')',10000);
  const point=await app.evaluate(hit);
  assert(point, 'Expected visible unique control: ' + selector + ' ' + (text ?? ''));
  for (const type of ['mousePressed', 'mouseReleased']) {
    await app.cdp('Input.dispatchMouseEvent', { type, ...point, button: 'left', clickCount: 1 });
  }
  result.actions.push({ selector, text, ...point });
}



const name = 'm14-a08-synthetic-check';
const source = join(home, '.claude', 'skills', name);
const entry = join(source, 'SKILL.md');
const relativeProgram = 'scripts/a08-proof.mjs';
const resource = join(source, relativeProgram);
const composer = '.agent-task-view textarea';
const row = '[data-testid="sidebar-agent-task"]';
const marker = () => 'A08_EXEC_' + randomUUID().replaceAll('-', '');
const expected = [marker(), marker()];
const title = kind => 'A08 ' + kind + ' relative resource';
const configSha = () => [entry,resource].map(path => createHash('sha256').update(readFileSync(path)).digest('hex'));
const sanitized = value => String(value);
const check = (label, ok) => {
  result.observations.push({ label, ok: Boolean(ok) });
  assert(ok, label);
};
function observedTools(kind,body) {
  result.advertised ??= {};
  if(!result.advertised[kind]) result.advertised[kind]=(body.tools??[]).map(t=>typeof t.name==='string'?t.name:t.type);
}
const server = createServer(async (req,res) => {
  try {
    const path = new URL(req.url, origin).pathname;
    if (path.endsWith('/models')) {
      res.writeHead(200, { 'content-type':'application/json' });
      res.end(JSON.stringify({ data: [{ id:model }] }));
      return;
    }
    const kind = path.endsWith('/messages') ? 'claude' : path.endsWith('/responses') ? 'codex' : null;
    if (req.method !== 'POST' || !kind) { res.writeHead(404); res.end(); return; }
    const chunks = [];
    let bytes = 0;
    for await (const chunk of req) { bytes+=chunk.length; assert(bytes<6*1024*1024); chunks.push(chunk); }
    const body = JSON.parse(Buffer.concat(chunks).toString());
    assert.equal(body.model,model);
    const content = JSON.stringify(kind==='claude' ? body.messages : body.input);
    observedTools(kind,body);
    const toolOutput = kind==='claude' ? body.messages?.flatMap(message => Array.isArray(message.content) ? message.content : []).filter(block => block.type==='tool_result')
      : body.input?.filter(item => item.type==='function_call_output');
    const observed = { kind, versionOutputs: expected.map(value => JSON.stringify(toolOutput??[]).includes(value)),
      mentionsRelativeProgram: content.includes(relativeProgram), bytes };
    result.requests.push(observed);
    assert(result.requests.length<=80, 'Bounded synthetic trial');
    const endpoint = localProvider + (kind==='claude' ? '/v1/messages' : '/v1/responses');
    assert.equal(new URL(endpoint).origin,'http://127.0.0.1:3426');
    const headers = { 'content-type':'application/json' };
    if (kind==='claude') {
      headers['anthropic-version'] = req.headers['anthropic-version']??'2023-06-01';
      if(req.headers['anthropic-beta']) headers['anthropic-beta']=req.headers['anthropic-beta'];
    }
    const originalTools=body.tools??[];
    if(kind==='codex') {
      const omit=tool=>tool?.type==='custom' && tool.name==='apply_patch';
      body.tools=originalTools.filter(tool=>!omit(tool));
      observed.compatibilityOmitted=originalTools.filter(omit).map(tool=>tool.name);
      assert(observed.compatibilityOmitted.length<=1);
      assert(body.tools.some(tool=>tool.type==='function'&&tool.name==='exec_command'), 'Original native execution function must remain');
    }
    await forwardResponse(res, signal => fetch(endpoint, { method:'POST', headers, body:JSON.stringify(body), redirect:'error', signal }), observed, 180000);
  } catch (error) {
    result.serverError=sanitized(error.message);
    if(!res.headersSent) res.writeHead(500);
    res.end();
  }
});
async function until(read, label, timeout=25000) {
  const limit=Date.now()+timeout;
  do {
    if (result.serverError) throw Error(result.serverError);
    const value=await read();
    if (value) return value;
    await pause(100);
  } while (Date.now()<limit);
  throw Error('Timed out: '+label);
}
async function navigate(task, label) {
  await click(row+'[data-task-id="'+task.taskId+'"]');
  await app.waitFor('document.querySelector(".agent-task-head h1")?.textContent==='+JSON.stringify(label), 12000);
}
async function input(text) {
  await click(composer);
  await app.cdp('Input.insertText',{ text });
}
async function send() { await click('.agent-task-view button[type="submit"]'); }
async function allowFixtureOnly() {
  const pending = await app.evaluate('document.querySelector(".agent-request")?.innerText??""');
  if (!pending) return;
  const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);
  assert.equal(snap.requests.length,1,'There must be exactly one authentic native request on this fixture');
  const request=snap.requests[0];
  if(!isA08OwnedApproval(request,{workingDir:cwd,scratch:root,skillName:name,entry,resource})) {
    result.unexpectedRequest={kind:request.kind,payload:request.payload};
    throw Error('Unexpected request outside the exact Skill or relative resource');
  }
  (result.approvedFixtureRequests??=[]).push({kind:request.kind,payload:request.payload});
  const button = '.agent-request [role="option"][aria-label="批准"],.agent-request [role="option"][aria-label="批准一次"]';
  if (await app.evaluate('Boolean('+selectorExpr(button)+')')) {
    await click(button);
    await click('.agent-confirm-choice');
    await app.waitFor('!document.querySelector(".agent-request")',12000);
  }
}
let phase='isolated setup';
let liveTask;
try {
  mkdirSync(dirname(resource),{ recursive:true,mode:0o700 });
  modelState=await openPrivateModel(modelRoot);
  result.localModel=modelState.provenance;
  writeFileSync(entry,'---\nname: '+name+'\ndescription: Read-only synthetic M14 A08 resource verification.\n---\n\nRun the Node program at `./'+relativeProgram+'` relative to this Skill directory. Locate this SKILL.md and use the program beside it. Do not modify any file. Return the exact stdout value from that program.\n');
  writeFileSync(resource,'console.log('+JSON.stringify(expected[0])+');\n');
  const before=configSha();
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
  app=await openElectron({ executable,userData,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(hookResult,await redirectHome({...info,home})) });
  const identity=await app.mainEvaluate(`(() => {
    const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
    return [E.app.isPackaged,E.app.getPath('userData'),E.app.getPath('home'),process.env.HOME,process.execPath,process.pid];
  })()`);
  assert.deepEqual(identity,[true,userData,home,home,executable,app.processId]);
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await app.invoke('agents.refreshTools');
  const claude=await app.invoke('agents.customToolPath','claude',process.env.M14_SMOKE_CLAUDE);
  assert.equal(claude.tool.version,'2.1.326');
  const available=await app.invoke('agents.tools');
  const provider=await app.invoke('agents.saveProvider',{name:'A08 synthetic gateway',preset:'magpie',
    endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
  const profiles={};
  for(const kind of ['claude','codex']) {
    const tool=available.find(tool=>tool.kind===kind&&tool.installed);
    assert(tool);
    profiles[kind]=await app.invoke('agents.save',{name:'A08 '+kind,toolId:tool.id,source:'provider',providerId:provider.id,models:[model],defaultModel:model,isDefault:kind==='claude'});
  }
  const project=await app.invoke('projects.create',{name:'A08 synthetic managed skill',aliases:[],description:'',rulesPath:null},[{label:'work',path:cwd}]);
  await click('[data-testid="nav-settings"]');
  const feature='[data-testid="m14-toggle"]';
  if(!(await app.evaluate(selectorExpr(feature)+'?.innerText.includes("已开启")'))) await click(feature);
  await app.waitFor(selectorExpr(feature)+'?.innerText.includes("已开启")',12000);
  phase='discover and adopt in the actual Skills screen';
  await click('[data-testid="nav-home"]');
  await click('[data-testid="nav-apps"]');
  await click('button.m10-nav','技能');
  await app.waitFor('Array.from(document.querySelectorAll("button.m13-cap")).some(el=>el.innerText.includes('+JSON.stringify(name)+'))',18000);
  await click('button.m13-cap',name);
  await click('[role=dialog] button.m10-button.primary','纳管');
  await until(async()=>{
    const inventory=await app.invoke('capabilities.managedList');
    return inventory.items?.find(skill=>skill.name===name&&skill.managed);
  },'the source skill is managed');
  await app.screenshot(join(out,'01-managed-source.png'));
  await click('[role=dialog] button[aria-label="关闭"]');
  await click('[data-testid="nav-home"]');

  const warm='A08 setup. Respond only READY_A08. Do not call any tool or change any file.';
  result.scriptProof=[];
  const create=async(kind,label)=>app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd,title:label,profileId:profiles[kind].id,model,tier:'ask'});
  async function runSkill(kind,label,version) {
    liveTask=await create(kind,label);
    await navigate(liveTask,label);
    await input(warm);
    await send();
    await until(async()=>{const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);return snap.items.some(item=>item.type==='assistant_message'&&item.payload?.text?.includes('READY_A08'));},'warm native catalog',210000);
    await input('$'+name.slice(0,-5));
    const menu='.agent-menu [role="option"]';
    await app.waitFor('Array.from(document.querySelectorAll('+JSON.stringify(menu)+')).some(e=>e.innerText.includes('+JSON.stringify(name)+'))',14000);
    await app.screenshot(join(out,kind+'-'+version+'-menu.png'));
    await click(menu,name);
    const text=await app.evaluate(selectorExpr(composer)+'?.value');
    check(kind+' chose the skill using the real picker',text.includes(name));
    await app.cdp('Input.insertText',{text:' Work in this task only. Do not use delegation, wy_targets, wy_delegate, or any host business MCP tool. Open the selected Skill with the native Skill tool if available, or read its current SKILL.md from its published location. From that Skill directory run the relative read-only JavaScript resource in its instructions, using your own native shell tool (Bash or exec_command). Do not alter files or access the network. Report the exact stdout. If the Skill cannot be opened in two attempts, say so and stop.'});
    await send();
    const resolved=await until(async()=>{
      await allowFixtureOnly();
      const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);
      return !snap.run?.busy&&snap.items.some(item=>item.type==='assistant_message'&&item.payload?.text?.includes(expected[version]));
    },kind+' real tool then correct private script output',210000);
    check(kind+' returned the exact script output',resolved&&result.requests.some(row=>row.kind===kind&&row.versionOutputs[version]));
    const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);
    const confirmations=snap.items.filter(item=>item.type==='command_execution'&&JSON.stringify(item.payload).includes(relativeProgram));
    result.scriptProof.push({kind,version,taskId:liveTask.taskId,confirmations});
    check(kind+' has a native execution receipt for the selected script',confirmations.some(item=>JSON.stringify(item.payload.output??item.payload.result).includes(expected[version])));
    await app.screenshot(join(out,kind+'-'+version+'-result.png'));
  }
  phase='real model calls the published relative program';
  for(const kind of testedKinds) await runSkill(kind,title(kind),0);
  check('original skill and script kept original hashes',JSON.stringify(configSha())===JSON.stringify(before));
  phase='new task observes changed resource';
  writeFileSync(resource,'console.log('+JSON.stringify(expected[1])+');\n');
  const updated=configSha();
  assert.equal(updated[0],before[0]);
  assert.notEqual(updated[1],before[1]);
  for(const kind of testedKinds) await runSkill(kind,title(kind)+' updated',1);
  check('app preserved the source as updated by the fixture',JSON.stringify(configSha())===JSON.stringify(updated));
  phase='new task excludes physically removed Skill';
  assert.equal(realpathSync(source),source);
  assert(source.startsWith(home+'/.claude/skills/'));
  rmSync(source,{recursive:true});
  const absence='A08 confirm source removal. Say READY_A08_REMOVED only. Do not call tools.';
  for(const kind of testedKinds) {
    const label=title(kind)+' removed';
    liveTask=await create(kind,label);
    await navigate(liveTask,label);
    await input(absence);
    await send();
    const current=await until(async()=>{
      const snap=await app.invoke('agentTasks.snapshot',liveTask.taskId);
      return !snap.run?.busy && snap.run?.catalog && snap.items.some(item=>item.type==='assistant_message'&&item.payload?.text?.includes('READY_A08_REMOVED')) ? snap : null;
    },kind+' fresh native catalog after removal',210000);
    check(kind+' no longer publishes the deleted source',!current.run.catalog.skills.some(skill=>skill.name.includes(name)));
    await input('$'+name.slice(0,-5));
    check(kind+' picker does not show the deleted source',!await app.evaluate('Array.from(document.querySelectorAll(".agent-menu [role=option]")).some(el=>el.innerText.includes('+JSON.stringify(name)+'))'));
    await app.screenshot(join(out,kind+'-removed.png'));
  }
  result.status='passed-initial';
} catch (error) {
  result.phase=phase;
  result.error=sanitized(error.stack??error);
  if(app) try {
    await app.screenshot(join(out,'99-failure.png'));
    result.visible=sanitized(await app.evaluate('document.body.innerText.slice(-2600)'));
  } catch {}
} finally {
  if(app) {
    try {
      if(liveTask && result.status==='failed') await app.invoke('agentTasks.stop',liveTask.taskId,true);
      await app.mainEvaluate(`(() => {
        const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(E.app.getPath('userData')!==${JSON.stringify(userData)})throw Error('Wrong App');
        setTimeout(()=>E.app.quit(),50);return true;
      })()`);
      result.exit=await app.waitForExit(20000);
    } catch(error) {
      result.exitError=sanitized(error);
      try{result.forcedExit=await app.crash();}catch{}
    }
    result.rendererErrors=app.rendererErrors.map(sanitized);
    writeFileSync(join(out,'app.log'),sanitized(app.logs()),{mode:0o600});
  }
  server.closeAllConnections();
  await new Promise(resolve=>server.close(resolve));
  if(modelState) result.modelExit=await modelState.stop();
  writeFileSync(join(out,'result.json'),sanitized(JSON.stringify(result,null,2)),{mode:0o600});
}
if(result.status!=='passed-initial'||result.exit?.code!==0||result.rendererErrors?.length||result.modelExit?.code!==0)process.exitCode=1;
