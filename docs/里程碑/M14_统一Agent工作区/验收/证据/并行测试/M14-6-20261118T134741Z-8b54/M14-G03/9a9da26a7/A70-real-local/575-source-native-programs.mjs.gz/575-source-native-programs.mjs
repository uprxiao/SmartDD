import assert from 'node:assert/strict';
import { accessSync,constants,realpathSync } from 'node:fs';

export const pinnedPrograms={
  claude:{path:'/Users/liubu/.local/share/claude/versions/2.1.326',version:'2.1.326'},
  codex:{path:'/Users/liubu/.local/lib/node_modules/@openai/codex/bin/codex.js',version:'0.169.0'},
};

export async function registerNativePrograms(invoke){
  const configured={};
  for(const [kind,{path,version}] of Object.entries(pinnedPrograms)){
    assert.equal(realpathSync(path),path);
    accessSync(path,constants.X_OK);
    const receipt=await invoke('agents.customToolPath',kind,path);
    const tool=receipt.tool;
    assert.equal(tool?.kind,kind,'Native tool kind mismatch for '+kind);
    assert.equal(tool.installed,true,'Selected native executable is not installed: '+kind);
    assert.equal(tool.version,version,receipt.error);
    assert.equal(tool.executable,path);
    assert.equal(tool.customPath,path);
    configured[kind]=tool;
  }
  return configured;
}
