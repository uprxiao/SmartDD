import assert from 'node:assert/strict';
import {latestUserText,claudeReply} from '../a32-recheck/protocol.mjs';
import {listedAvailable,codexToolCall} from '../a26-recheck/codex-mcp.mjs';
import {getCall} from '../a67-tier-matrix/merge-flow.mjs';
import {childTitle,markers,writeCommand} from './fixture.mjs';

export const models={parent:'a66-final-claude',child:'a66-final-codex'};
export const parentInput=slot=>'A66_FINAL_GAP_PARENT_'+slot;
export const childInput=slot=>'A66_FINAL_GAP_CHILD_'+slot;
export const done={parent:'A66 FINAL PROBE PARENT CONTINUED',child:'A66 FINAL PROBE CHILD COMPLETED',notice:'A66 FINAL PROBE RESULT RECEIVED'};
const timeoutPattern=/宿主命令超时或输出超限/;

function rawClaudeReply(body,id){
  const found=(body.messages??[]).flatMap(row=>Array.isArray(row.content)?row.content:[])
    .filter(row=>row.type==='tool_result'&&row.tool_use_id===id);
  assert.equal(found.length,1);
  const [reply]=found;
  return {isError:reply.is_error===true,text:typeof reply.content==='string'?reply.content:reply.content.filter(item=>item.type==='text').map(item=>item.text).join('\n')};
}

export function verifyExplicitPathRejection(reply){
  assert.equal(reply.isError,true);
  const {error}=JSON.parse(reply.text);
  assert.equal(error.code,'INVALID_INPUT');
  assert.equal(error.effectState,'not-started');
  const issues=JSON.parse(error.message);
  assert.equal(issues.length,1,'A valid key must leave only the workspacePath validation issue');
  assert.equal(issues[0].code,'unrecognized_keys');
  assert.deepEqual(issues[0].keys,['workspacePath']);
  return error;
}

export function makeProbe({fixture,axis,targetId,verifyManual,verifyNoAccepted,readWorkspace}){
  const {slot,base}=fixture;
  const state={parent:'initial',child:'initial',toolEvents:[],notices:[],issues:[]};
  const invoke=(body,kind,role,tool,args)=>{
    const call=kind==='claude'?getCall(body,kind,tool,args):codexToolCall(body,tool,args);
    state[role+'CallId']=call.callId;
    state.toolEvents.push({role,tool,args,id:call.callId,at:Date.now()});
    return {type:role+'-'+tool,call};
  };
  const delegate=(body,manualPath)=>{
    const args={requestKey:'a66-final-path-key-'+slot,profileId:state.target.profileId,profileRevision:state.target.revision,
      title:childTitle,model:models.child,instructions:childInput(slot),access:'write',workspaceMode:'worktree'};
    const extra=manualPath?{...args,workspacePath:fixture.external}:args;
    return invoke(body,'claude','parent','wy_delegate',extra);
  };
  return {state,async next(kind,body){
    const text=latestUserText(kind,body);
    if(body.model===models.parent){
      assert.equal(kind,'claude');
      if(text.includes('宿主子任务结果通知')){
        assert(state.receipt&&text.includes(state.receipt.childTaskId));
        assert.equal(state.notices.length,0);
        state.notices.push({text,at:Date.now()});
        return {type:'native-result-notice',answer:done.notice};
      }
      if(text.includes('宿主合并核对失败：')){
        assert.equal(state.notices.length,1);
        return {type:'separate-merge-diagnostic',answer:'A66 merge is outside this isolation probe.'};
      }
      if(state.parent==='initial'){
        assert(text.includes(parentInput(slot)));
        state.parent='targets';
        return invoke(body,'claude','parent','wy_targets',{});
      }
      if(state.parent==='targets'){
        state.target=listedAvailable(JSON.parse(claudeReply(body,state.parentCallId)),targetId);
        if(axis==='names-path'&&slot==='a'){
          state.parent='await-manual-git';
          return invoke(body,'claude','parent','Bash',{command:fixture.manualCommand,description:'A66 isolated manual Git worktree'});
        }
        state.parent='await-valid-delegate';
        return delegate(body,false);
      }
      if(state.parent==='await-manual-git'){
        const reply=rawClaudeReply(body,state.parentCallId);
        assert.equal(reply.isError,false,'Manual bounded Git worktree failed: '+reply.text);
        state.manual=await verifyManual(reply.text);
        state.parent='await-rejected-path';
        return delegate(body,true);
      }
      if(state.parent==='await-rejected-path'){
        const reply=rawClaudeReply(body,state.parentCallId);
        state.issues.push(verifyExplicitPathRejection(reply));
        await verifyNoAccepted();
        state.parent='await-valid-delegate';
        return delegate(body,false);
      }
      assert.equal(state.parent,'await-valid-delegate');
      const receipt=JSON.parse(claudeReply(body,state.parentCallId));
      assert.equal(receipt.baseCommit,base);
      assert.equal(receipt.uncommittedFiles,1);
      assert.equal(receipt.workspaceMode,'worktree');
      assert.match(receipt.childTaskId,/^[a-f0-9-]{36}$/);
      state.receipt=receipt;
      state.parent='done';
      return {type:'accepted-explicit-child',answer:done.parent};
    }
    assert.equal(body.model,models.child);
    assert.equal(kind,'codex');
    if(state.child==='initial'){
      assert(text.includes(childInput(slot))&&text.includes(base)&&text.includes('1 个未提交文件'));
      if(axis==='timeout'){
        const nativeContext=JSON.stringify(body.input);
        assert(nativeContext.includes('依赖安装失败'));
        assert(timeoutPattern.test(nativeContext));
        assert(nativeContext.includes(markers.output));
        state.timeoutInNativeInput=true;
      }
      const {mapped}=await readWorkspace();
      state.child='writing';
      state.childMapped=mapped;
      return invoke(body,'codex','child','exec_command',{cmd:writeCommand(mapped),workdir:mapped,max_output_tokens:150});
    }
    assert.equal(state.child,'writing');
    const matches=(body.input??[]).filter(i=>i.type==='function_call_output'&&i.call_id===state.childCallId);
    assert.equal(matches.length,1);
    assert(JSON.stringify(matches[0].output).includes(state.childMapped));
    assert(!/Operation not permitted|Permission denied|exited with code [1-9]/i.test(JSON.stringify(matches[0].output)));
    state.child='done';
    return {type:'native-child-complete',answer:done.child};
  }};
}
