import { dirname, isAbsolute, resolve } from 'node:path';
import { realpathSync } from 'node:fs';

const token = `(?:"([/a-zA-Z0-9._-]+)"|'([/a-zA-Z0-9._-]+)'|([/a-zA-Z0-9._-]+))`;
const program = new RegExp(`^(?:cd ${token} && )?(?:node|/usr/local/bin/node|/opt/homebrew/bin/node) ${token}$`);

export function isA08OwnedApproval(request, { workingDir, scratch, skillName, entry, resource }) {
  const value=request?.payload;
  const within=(file, expected)=>{
    if(typeof file!=='string' || !isAbsolute(file) || !file.startsWith(scratch+'/')) return false;
    try {return realpathSync(file)===realpathSync(expected);} catch {return false;}
  };
  if (request?.class!=='native') return false;
  if (request.kind==='tool_approval'&&value?.tool==='Read') return within(value.input?.file_path, entry);
  if (request.kind==='tool_approval'&&value?.tool==='Skill') return value.input?.skill===skillName;
  const clause = request.kind==='command_approval'&&value?.tool==='Bash' ? {command:value.input?.command, cwd:workingDir}
    : request.kind==='command_approval'&&value?.method==='item/commandExecution/requestApproval' ? value.params : null;
  if(!clause || typeof clause.command!=='string' || !clause.cwd?.startsWith(scratch+'/')) return false;
  const shellWrapper = request.kind==='command_approval' && value?.method==='item/commandExecution/requestApproval'
    ? /^\/bin\/(?:bash|sh|zsh) -c (?:'([^']+)'|"([^"\\]+)")$/.exec(clause.command) : null;
  const wrapped=shellWrapper?.[1]??shellWrapper?.[2];
  if(wrapped && (clause.commandActions?.length!==1 || clause.commandActions[0].command!==wrapped)) return false;
  const match = program.exec(wrapped ?? clause.command);
  if(!match)return false;
  const [,doubleCd,singleCd,plainCd,doubleFile,singleFile,plainFile]=match;
  const base=resolve(clause.cwd,doubleCd??singleCd??plainCd??'.');
  if(!base.startsWith(scratch+'/')) return false;
  const file=resolve(base,doubleFile??singleFile??plainFile);
  return within(file,resource) && dirname(file).startsWith(scratch+'/');
}
