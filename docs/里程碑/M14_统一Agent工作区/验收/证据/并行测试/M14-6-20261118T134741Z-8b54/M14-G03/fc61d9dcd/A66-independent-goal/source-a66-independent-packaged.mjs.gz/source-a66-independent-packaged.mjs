import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash,randomUUID } from 'node:crypto';
import { copyFileSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { basename,join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openElectron,pause } from '../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../prep-fef791bc6/electron-isolation-paths.mjs';
import {readonlyQuery} from '../a67-tier-matrix/readonly-db.mjs';
import {npmIsolation} from '../a20-queued-and-preparing/git-fixture.mjs';
import {homeBase,title,canary,childBytes,seed,verifyWorkspace} from '../a66-final-gaps/fixture.mjs';
import {makeProbe,models as delegationModels,parentInput,done} from '../a66-final-gaps/probe-flow.mjs';
import {goalFixture,makeGoalLane} from './goal-lane.mjs';
const models={...delegationModels,independent:goalFixture.model};
import {mergeSettled,resultReady} from '../a66-final-gaps/settlement-oracle.mjs';

const [out,axis,sourceCommit,asar,lease]=process.argv.slice(2);
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}$/);
assert.equal(axis,'independent-goal','Run only the independent goal fixture');
assert.equal(lease,'isolated-acceptance-lease','Coordinator must grant the sole packaged App and 3425 slot');
assert.match(sourceCommit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
const bundle=join(homeBase,'package/mac-arm64/WillYou.app/Contents');
const executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
for(const file of [executable,reader])assert.equal(realpathSync(file),file);
assert.equal(realpathSync(process.cwd()),join(homeBase,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceCommit);
const sha=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(sha(join(bundle,'Resources/app.asar')),asar);
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
const claude=process.env.M14_SMOKE_CLAUDE,codex=process.env.M14_SMOKE_CODEX;
assert.match(claude??'',/^\/Users\/[^/]+\/\.local\/share\/claude\/versions\/2\.1\.326$/);
assert.match(codex??'',/^\/Users\/[^/]+\/\.local\/lib\/node_modules\/@openai\/codex\/bin\/codex\.js$/);
assert.equal(realpathSync(claude),claude);
assert.equal(realpathSync(codex),codex);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});
mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const origin='http://127.0.0.1:3425';
const env={...npmIsolation(root),HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_CACHE_HOME:join(home,'.cache'),XDG_DATA_HOME:join(home,'.local/share'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',NO_PROXY:'127.0.0.1,localhost',no_proxy:'127.0.0.1,localhost',
  HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  http_proxy:'http://127.0.0.1:1',https_proxy:'http://127.0.0.1:1',all_proxy:'http://127.0.0.1:1',
  npm_config_ignore_scripts:'false'};
const result={caseId:'M14-A66',axis,sourceCommit,asar,scope:'A/I isolated real packaged App, real native local executors, loopback synthetic model',
  root,actions:[],requests:[],workspaceUi:{},projects:[],runs:[],passed:false};
for(const name of [basename(fileURLToPath(import.meta.url)),'goal-lane.mjs','run-a66-independent-goal.sh',
  '../a66-final-gaps/fixture.mjs','../a66-final-gaps/probe-flow.mjs','../a66-final-gaps/settlement-oracle.mjs']){
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+basename(name)));
}
const independentLane=makeGoalLane();
result.independentLane=independentLane.state;
let app,active,independent,appTrusted=false,listening=false,phase='isolated setup';
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const sql=(query,args=[],options)=>readonlyQuery(data,query,args,options).rows;
const kernel=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));
const save=(name,value)=>writeFileSync(join(out,name),JSON.stringify(value,null,2)+'\n',{mode:0o600});

function providerResponse(res,protocol,model,{answer,call}){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const event=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
  if(protocol==='claude'){
    event('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,
      usage:{input_tokens:1,output_tokens:0}}});
    event('content_block_start',{index:0,content_block:call?
      {type:'tool_use',id:call.callId,name:call.tool.name,input:{}}:{type:'text',text:''}});
    event('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(call.args)}:{type:'text_delta',text:answer}});
    event('content_block_stop',{index:0});
    event('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});
    event('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item=call?{id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,...(call.tool.namespace?{namespace:call.tool.namespace}:{}),
      name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'}:
      {id:'msg_'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:answer,annotations:[]}]};
    event('response.created',{response:{id,status:'in_progress',output:[]}});
    event('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    if(!call)event('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:answer});
    event('response.output_item.done',{output_index:0,item});
    event('response.completed',{response:{id,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text,mode='queue'){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click(mode==='steer'?'.agent-composer button[aria-label="插话"]':'.agent-composer button[type="submit"]');
}
async function ensureWorkspaceUi(label){
  await app.waitFor('Boolean(document.querySelector("[data-testid=nav-settings]"))',10000,{navigation:true});
  const flag=await app.evaluate('localStorage.getItem("willyou-m14-agent-workspace")');
  const row=result.workspaceUi[label]={flagBefore:flag,beforeActions:result.actions.length,at:Date.now()};
  assert(flag===null||flag==='true'||flag==='false');
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  await app.waitFor('Boolean('+selected(toggle)+')',12000,{navigation:true});
  row.labelBefore=await app.evaluate(selected(toggle)+'?.innerText');
  assert.equal(row.labelBefore?.includes('已开启'),flag==='true');
  if(flag!=='true'){
    await click(toggle);
    row.featureEnabledInTestSetup=true;
  }else row.featureEnabledInTestSetup=false;
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  assert.equal(await app.evaluate('localStorage.getItem("willyou-m14-agent-workspace")'),'true');
  row.flagAfter='true';
  await click('[data-testid="nav-home"]');
  row.afterActions=result.actions.length;
  row.finishedAt=Date.now();
}
const server=createServer(async(req,res)=>{
  const context=active;
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
      return;
    }
    const kind=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!kind){res.statusCode=404;res.end();return;}
    assert([req.headers.authorization,req.headers['x-api-key']].some(token=>token==='magpie-'+kind||token==='Bearer magpie-'+kind));
    let size=0;
    const chunks=[];
    for await(const bytes of req){size+=bytes.length;assert(size<2*1024*1024);chunks.push(bytes);}
    const payload=JSON.parse(Buffer.concat(chunks));
    assert(Object.values(models).includes(payload.model));
    const isIndependent=payload.model===goalFixture.model;
    assert(isIndependent||context,'Unexpected family request before fixture is ready');
    const event={kind,model:payload.model,slot:isIndependent?'independent':context.fixture.slot,at:Date.now()};
    result.requests.push(event);
    const action=await (isIndependent?independentLane:context.flow).next(kind,payload);
    Object.assign(event,{type:action.type,call:action.call?.tool.name,answeredAt:Date.now()});
    if(!res.destroyed)providerResponse(res,kind,payload.model,action);
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.statusCode=500;
    res.end();
  }
});

async function startApp(){
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listening=true;resolve();});});
  const boot={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(boot,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted=true;
  result.app={pid:app.processId,identity,boot,born:kernel(app.processId)};
  assert.equal(result.app.born.state,'running');
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  const profiles={};
  for(const [role,kind,path,version] of [['parent','claude',claude,'2.1.326'],['child','codex',codex,'0.169.0'],['independent','codex',codex,'0.169.0']]){
    const detection=await app.invoke('agents.customToolPath',kind,path);
    assert.equal(detection.tool?.version,version,detection.error);
    assert.equal(detection.tool?.executable,path);
    const model=models[role];
    const provider=await app.invoke('agents.saveProvider',{name:'A66 Final '+role,preset:'magpie',
      endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
    const profile=await app.invoke('agents.save',{name:'A66 final '+role+' '+kind,toolId:detection.tool.id,source:'provider',
      providerId:provider.id,models:[model],defaultModel:model,isDefault:role==='parent'});
    profiles[role]=profile.id;
  }
  return profiles;
}
const projectFor=fixture=>app.invoke('projects.create',{name:title,aliases:[],description:'',rulesPath:null},
  [{label:'A66 private project directory',path:fixture.cwd}]);
async function prepareRun(fixture,project,profiles){
  const taskTitle='A66 isolated original parent '+fixture.slot;
  const task=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd:fixture.cwd,title:taskTitle,
    profileId:profiles.parent,model:models.parent,tier:'ask'});
  const parent={taskId:task.taskId,title:taskTitle};
  const workspace=()=>{
    const rows=sql('SELECT w.*,a.attempt_id,a.child_turn_id,a.commit_range,a.notified_at,d.delivery_state FROM agent_workspaces w JOIN agent_delegations d ON d.child_task_id=w.child_task_id JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id WHERE d.parent_task_id=?',[parent.taskId]);
    return rows.length===1&&rows[0];
  };
  const flow=makeProbe({fixture,axis,targetId:profiles.child,
    async readWorkspace(){
      const row=await until(()=>{const ready=workspace();return ready?.state==='ready'&&ready},'registered child workspace');
      const mapped=verifyWorkspace(row,fixture,project,root);
      await independentLane.holdChild({childId:row.child_task_id,cwd:mapped.mapped,workspaceId:row.workspace_id});
      return mapped;
    },
  });
  return {fixture,project,parent,flow,workspace};
}

async function inspectComplete(run){
  const {fixture,project,parent,flow,workspace}=run;
  const completed=await until(()=>{
    const row=workspace();
    if(!row)return false;
    const receipts=sql("SELECT turn_id,status FROM agent_turns WHERE task_id=? AND client_input_id=?",[parent.taskId,'result-'+row.attempt_id]);
    return resultReady(row,receipts);
  },'same actual parent result receipt fully completes',53000);
  const {workspace:row,receipt}=completed;
  const {mapped,segment}=verifyWorkspace(row,fixture,project,root);
  const range=JSON.parse(row.commit_range);
  assert.deepEqual(range.commits,[range.head]);
  assert.equal(range.base,fixture.base);
  assert.equal(range.head,fixture.git(row.path,'rev-parse','HEAD'));
  assert.equal(fixture.git(row.path,'rev-parse','HEAD^'),fixture.base);
  assert.equal(readFileSync(join(mapped,canary),'utf8'),childBytes);
  assert.equal(fixture.git(fixture.repo,'rev-parse','HEAD'),fixture.base);
  assert.equal(readFileSync(join(fixture.repo,'original.txt'),'utf8'),'DIRTY_'+fixture.slot+'\n');
  const provenance=sql('SELECT commit_sha,intent_id FROM agent_commit_provenance WHERE attempt_id=?',[row.attempt_id]);
  assert.equal(provenance.length,1);
  assert.equal(provenance[0].commit_sha,range.head);
  assert(fixture.git(row.path,'show','-s','--format=%B','HEAD').split('\n').includes('WillYou-Intent: '+provenance[0].intent_id));
  const notifications=sql("SELECT item_id FROM agent_items WHERE task_id=? AND type='notification' AND json_extract(payload_ref,'$.attemptId')=?",[parent.taskId,row.attempt_id]);
  assert.equal(notifications.length,1);
  const child=sql('SELECT turn_id,status,started_at FROM agent_turns WHERE turn_id=?',[row.child_turn_id]);
  assert.equal(child.length,1);
  assert.equal(child[0].status,'completed');
  assert.equal((await state(row.child_task_id)).cwd,mapped);
  const settled=await until(async()=>{
    const ids=[parent.taskId,row.child_task_id];
    const turns=sql("SELECT turn_id,task_id,client_input_id,status FROM agent_turns WHERE task_id IN (?,?)",ids);
    const runs=sql("SELECT run_id,task_id,state,ended_at FROM capability_runs WHERE task_id IN (?,?)",ids);
    const processes=sql("SELECT p.kind,p.state,p.pid,p.process_started_at FROM capability_run_processes p JOIN capability_runs r ON r.run_id=p.run_id WHERE r.task_id IN (?,?)",ids);
    const [merge]=sql("SELECT COALESCE(json_extract(d.target_json,'$.mergeFailures'),0) AS failures,a.merge_check_json AS check_json FROM agent_delegations d JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id WHERE d.parent_task_id=? AND d.child_task_id=? AND a.attempt_id=?",[...ids,row.attempt_id]);
    const visibleTasks=await app.invoke('agentTasks.list');
    const task=visibleTasks.find(item=>item.taskId===parent.taskId),child=visibleTasks.find(item=>item.taskId===row.child_task_id);
    return mergeSettled({turns,runs,processes,merge,task,child});
  },'real parent result, two persisted merge diagnoses and no remaining active original run',40000);
  save('settled-'+fixture.slot+'.json',settled);
  await open(parent);
  await app.waitFor('document.body.innerText.includes('+JSON.stringify(done.notice)+')',20000,{navigation:true});
  await app.screenshot(join(out,'02-'+fixture.slot+'-real-parent-result.png'));
  const evidence={slot:fixture.slot,projectId:project.id,workspace:row,segment,mapped,child:child[0],receipt,settled,
    notifications,provenance,actualFlow:flow.state};
  result.runs.push(evidence);
  save('proof-'+fixture.slot+'.json',evidence);
  return evidence;
}

function persistedInput(taskId,text){
  return sql("SELECT turn_id,run_id,native_turn_id,status,source_kind,client_input_id FROM agent_turns WHERE task_id=? AND json_extract(input_ref,'$.text')=?",[taskId,text]);
}
const dirQueue=id=>sql("SELECT state FROM agent_directory_queue WHERE task_id=? AND state IN ('queued','active')",[id]);
const ownedRun=id=>sql("SELECT run_id,binding_id,pid,process_started_at,state FROM capability_runs WHERE run_id=?",[id])[0];

async function stableIndependent(task,prior){
  const snap=await state(task.taskId);
  assert.equal(snap.goal?.status,'active');
  assert.equal(snap.goal.bindingId,prior.goal.bindingId);
  assert.equal(snap.goal.revision,prior.goal.revision);
  assert.equal(snap.run?.runId,prior.run.run_id);
  const actual=ownedRun(prior.run.run_id);
  assert.equal(actual.state,'active');
  assert.equal(actual.pid,prior.run.pid);
  const birth=kernel(prior.run.pid);
  assert.equal(birth.startedAt,prior.run.process_started_at);
  const turn=snap.turns.find(entry=>entry.turn_id===prior.turn.turn_id);
  assert.equal(turn?.status,'started');
  assert.equal(turn.native_turn_id,prior.turn.native_turn_id);
  assert.deepEqual(dirQueue(task.taskId),[]);
  return {goal:snap.goal,run:actual,turn,birth};
}

async function execute(){
  const fixture=seed(root,'a',env,'names-path');
  const profiles=await startApp();
  const project=await projectFor(fixture);
  result.projects.push({id:project.id,name:project.name});
  active=await prepareRun(fixture,project,profiles);
  const independentTitle='A66 independent native Codex goal';
  const task=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd:fixture.cwd,title:independentTitle,
    profileId:profiles.independent,model:models.independent,tier:'ask'});
  independent={taskId:task.taskId,title:independentTitle};
  assert.notEqual(independent.taskId,active.parent.taskId);
  assert.equal((await state(independent.taskId)).cwd,fixture.cwd);
  assert.equal((await state(active.parent.taskId)).cwd,fixture.cwd);
  await ensureWorkspaceUi('original');

  phase='turn on and hold actual independent Codex goal';
  await open(independent);
  await send(goalFixture.warm);
  await until(async()=>{
    const cached=await state(independent.taskId);
    return independentLane.state.phase==='warmed'&&!cached.run?.busy&&cached.items.some(item=>item.payload?.text===goalFixture.warmed);
  },'native independent warmup receives the first reply');
  independentLane.expectGoal();
  await send('/goal '+goalFixture.objective);
  const first=await until(async()=>{
    const snap=await state(independent.taskId);
    if(snap.goal?.objective!==goalFixture.objective||snap.goal.status!=='active'||!snap.run?.busy||!snap.run.steer||independentLane.state.phase!=='held')return false;
    const turn=snap.turns.findLast(row=>row.status==='started');
    const run=ownedRun(snap.run.runId);
    const binding=sql('SELECT native_id FROM agent_bindings WHERE binding_id=?',[snap.goal.bindingId])[0];
    return turn?.native_turn_id&&run?.pid&&binding?.native_id&&{goal:snap.goal,run,turn,nativeThreadId:binding.native_id};
  },'real independent goal, same owner birth, and active native turn');
  first.birth=kernel(first.run.pid);
  assert.equal(first.birth.startedAt,first.run.process_started_at);
  assert.deepEqual(dirQueue(independent.taskId),[]);
  result.independentBefore=first;

  phase='same Git repository starts real explicit worktree while independent target remains active';
  await open(active.parent);
  await click('[data-testid="agent-delegation-toggle"]');
  await app.waitFor(selected('[data-testid="agent-delegation-toggle"]')+'?.getAttribute("aria-pressed")==="true"',12000);
  await send(parentInput(fixture.slot));
  await until(()=>independentLane.state.childHeld&&active.flow.state.receipt,'real worktree child has already entered its own provider');
  const workspace=active.workspace();
  assert.equal(workspace.child_task_id,active.flow.state.receipt.childTaskId);
  assert.equal(workspace.state,'ready');
  assert.equal(workspace.repo_root,fixture.repo);
  const [childRun]=sql("SELECT task_id,pid,process_started_at,state FROM capability_runs WHERE task_id=?",[workspace.child_task_id]);
  assert.equal(childRun.state,'active');
  assert.equal(kernel(childRun.pid).startedAt,childRun.process_started_at);
  assert.notEqual(childRun.pid,first.run.pid);
  assert.deepEqual(dirQueue(workspace.child_task_id),[]);
  result.concurrent={worktree:workspace,worktreeChildRun:childRun,independent:await stableIndependent(independent,first)};

  phase='same independent task queues regular input and steers the original live native turn';
  await open(independent);
  await send(goalFixture.queued);
  const queued=await until(()=>{
    const items=persistedInput(independent.taskId,goalFixture.queued);
    return items.length===1&&items[0].status==='accepted'&&items[0];
  },'ordinary input reaches only the independent task queue before the original round ends');
  assert.equal(queued.run_id,null);
  assert.equal(queued.native_turn_id,null);
  await send(goalFixture.steered,'steer');
  const steered=await until(()=>{
    const items=persistedInput(independent.taskId,goalFixture.steered);
    return items.length===1&&items[0].status==='started'&&items[0];
  },'real native steer acceptance is recorded during original independent goal');
  assert.equal(steered.run_id,first.run.run_id);
  assert.equal(steered.native_turn_id,first.turn.native_turn_id);
  const records=sql("SELECT payload FROM agent_events WHERE task_id=? AND event_type='turn.steered' AND json_extract(payload,'$.turnId')=?",[independent.taskId,steered.turn_id]);
  assert.equal(records.length,1);
  assert.equal(JSON.parse(records[0].payload).nativeTurnId,first.turn.native_turn_id);
  assert.deepEqual(persistedInput(independent.taskId,goalFixture.queued),[queued]);
  result.inputWhileIndependentHeld={queued,steered,steerEvent:JSON.parse(records[0].payload),same:await stableIndependent(independent,first)};
  await app.screenshot(join(out,'01-original-goal-and-real-steer.png'));

  phase='complete same native goal and dispatch accepted input before worktree child is released';
  independentLane.releaseGoal();
  const continued=await until(async()=>{
    const snap=await state(independent.taskId);
    const inputs=persistedInput(independent.taskId,goalFixture.queued);
    return snap.goal?.status==='complete'&&independentLane.state.phase==='queue-finished'&&inputs.length===1&&inputs[0].status==='completed'&&{snap,input:inputs[0]};
  },'ordinary same-task input really completes while the private child is held',50000);
  assert.equal(continued.snap.goal.bindingId,first.goal.bindingId);
  assert.equal(continued.input.turn_id,queued.turn_id);
  assert.equal(continued.input.run_id,first.run.run_id);
  assert.notEqual(continued.input.native_turn_id,first.turn.native_turn_id);
  assert.equal(persistedInput(independent.taskId,goalFixture.steered)[0].status,'completed');
  assert(independentLane.state.toolReceipt.goal.status==='complete');
  assert.equal(independentLane.state.childReleasedAt,undefined);
  assert.deepEqual(dirQueue(independent.taskId),[]);
  const unrelatedPaused=sql("SELECT action FROM agent_intents WHERE task_id=? AND action IN ('goal_pause','goal_resume')",[independent.taskId]);
  assert.deepEqual(unrelatedPaused,[]);
  assert(continued.snap.items.some(item=>item.payload?.text===goalFixture.queueDone));
  result.independentContinued={goal:continued.snap.goal,input:continued.input,steer:persistedInput(independent.taskId,goalFixture.steered)[0],
    proofBeforeChildRelease:Date.now(),sameInitialBirth:kernel(first.run.pid)};
  assert.equal(result.independentContinued.sameInitialBirth.startedAt,first.run.process_started_at);
  save('independent-proof.json',{first,concurrent:result.concurrent,inputs:result.inputWhileIndependentHeld,continued:result.independentContinued,native:independentLane.state.actual});
  await app.screenshot(join(out,'02-new-input-delivered-before-child-release.png'));

  phase='release only the worktree child and verify exact one commit and notification';
  independentLane.releaseChild();
  await inspectComplete(active);
}
try{await execute();result.passed=true;}
catch(error){result.failure={phase,error:String(error.stack??error)};save('failure.json',result.failure);}
finally{
  independentLane.close();
  if(app){
    if(appTrusted)try{
      result.pending=(await app.invoke('agentTasks.list')).filter(task=>['working','waiting'].includes(task.status)).map(task=>task.taskId);
      if(result.failure&&result.pending.length){
        for(const id of [active?.parent.taskId,independent?.taskId])if(id&&result.pending.includes(id))await app.invoke('agentTasks.stop',id,true);
        result.stopCleanup=true;
      }
      await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");if(process.pid!=='+app.processId+'||E.app.getPath("userData")!=='+JSON.stringify(data)+')throw Error("Wrong private test instance");setTimeout(()=>E.app.quit(),50);return true;})()');
    }catch(error){result.quitError=String(error);}
    try{result.exit=await app.waitForExit(27000);}
    catch(error){result.quit2Error=String(error);try{result.fallback=await app.crash();}catch{}}
    result.rendererErrors=app.rendererErrors;
    if(result.exit?.code===0&&result.exit.signal===null&&result.exit.pid===app.processId)try{
      const rows=sql("SELECT p.kind,p.pid,p.process_started_at,p.state FROM capability_run_processes p WHERE p.run_id IN (SELECT run_id FROM capability_runs WHERE owner_pid=?)",[app.processId],{exit:result.exit,expectedPid:app.processId});
      assert(rows.length>0);
      result.exitProcesses=rows.map(row=>{
        assert.equal(row.state,'exited');
        const observed=kernel(row.pid);
        assert(observed.state==='stopped'||observed.startedAt!==row.process_started_at);
        return {...row,observed};
      });
    }catch(error){result.exitProcessError=String(error);}
  }
  if(listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.portReleased=!server.listening;
  result.passed=result.passed&&result.exit?.code===0&&result.exit.signal===null&&result.portReleased&&
   
    !result.rendererErrors?.length&&!result.exitProcessError&&!result.serverError&&!result.stopCleanup;
  save('result.json',result);
  console.log(JSON.stringify({passed:result.passed,axis,exit:result.exit,portReleased:result.portReleased,error:result.failure??result.serverError??result.exitProcessError}));
}
if(!result.passed)process.exitCode=2;
