import assert from 'node:assert/strict';

const incomplete=new Set(['accepted','dispatching','started']);
const busy=new Set(['working','waiting']);

export function resultReady(workspace,receipts){
  if(workspace?.delivery_state!=='delivered')return false;
  assert(receipts.length<=1,'One exact result input per attempt');
  const [receipt]=receipts;
  if(!receipt||incomplete.has(receipt.status))return false;
  assert.equal(receipt.status,'completed','Actual parent did not complete the delegated result');
  return {workspace,receipt};
}

export function mergeSettled({turns,runs,processes,merge,task,child}){
  if(turns.some(row=>incomplete.has(row.status)))return false;
  if(runs.some(row=>!['stopped','failed'].includes(row.state)))return false;
  if(processes.some(row=>!['exited','canceled'].includes(row.state)))return false;
  if(!merge?.check_json)return false;
  const outcome=JSON.parse(merge.check_json);
  if(!outcome.pass&&merge.failures<2)return false;
  if(!task||!child||busy.has(task.status)||busy.has(child.status))return false;
  if(!outcome.pass)assert.equal(task.status,'needs_attention','An intentionally unmerged branch must settle at needs_attention');
  return {turns,runs,processes,merge,task,child};
}
