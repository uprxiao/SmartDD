import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createWriteStream, mkdirSync, readFileSync, realpathSync, statSync, symlinkSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';

export const model = 'qwen3-coder:30b';
export const provider = 'http://127.0.0.1:3426';
const rootPrefix = '/private/tmp/willyou-m14-stage6.WRvdST/';
const installedCache = '/Users/liubu/.ollama/models';
const manifestRel = 'manifests/registry.ollama.ai/library/qwen3-coder/30b';

export async function openPrivateModel(root) {
  assert(root.startsWith(rootPrefix) && realpathSync(root) === root);
  const modelStore = join(root, 'cache');
  const home = join(root, 'home');
  const runtime = join(root, 'tmp');
  const manifest = readFileSync(join(installedCache, manifestRel));
  const provenance = { model, manifestSha256:createHash('sha256').update(manifest).digest('hex'), blobInventory:[] };
  const parsed = JSON.parse(manifest);
  mkdirSync(join(modelStore,'blobs'),{recursive:true,mode:0o700});
  mkdirSync(dirname(join(modelStore,manifestRel)), {recursive:true,mode:0o700});
  for (const dir of [home,runtime]) mkdirSync(dir,{mode:0o700});
  writeFileSync(join(modelStore,manifestRel),manifest,{mode:0o400,flag:'wx'});
  for (const item of [parsed.config,...parsed.layers]) {
    assert(/^sha256:[a-f0-9]{64}$/.test(item.digest) && Number.isSafeInteger(item.size));
    const name = item.digest.replace(':','-');
    const source = realpathSync(join(installedCache,'blobs',name));
    assert(source.startsWith(installedCache+'/blobs/') && statSync(source).size === item.size);
    symlinkSync(source,join(modelStore,'blobs',name));
    provenance.blobInventory.push({digest:item.digest,size:item.size});
  }
  const log = createWriteStream(join(root,'ollama.log'),{mode:0o600,flags:'wx'});
  const child = spawn('/usr/local/bin/ollama',['serve'],{cwd:root,env:{
    HOME:home,TMPDIR:runtime,PATH:'/usr/bin:/bin:/usr/sbin:/sbin', LANG:'en_US.UTF-8',
    OLLAMA_HOST:'127.0.0.1:3426', OLLAMA_MODELS:modelStore, OLLAMA_NO_CLOUD:'1', OLLAMA_NOPRUNE:'1',
    OLLAMA_CONTEXT_LENGTH:'32768', OLLAMA_KEEP_ALIVE:'2m', OLLAMA_NUM_PARALLEL:'1', OLLAMA_MAX_LOADED_MODELS:'1',
    HTTP_PROXY:'http://127.0.0.1:1', HTTPS_PROXY:'http://127.0.0.1:1', ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'127.0.0.1,localhost',
  },stdio:['ignore','pipe','pipe']});
  child.stdout.pipe(log,{end:false});child.stderr.pipe(log,{end:false});
  const closed = new Promise(resolve=>{
    child.on('error', error=>resolve({error:error.message,pid:child.pid}));
    child.on('close', (code,signal)=>resolve({code,signal,pid:child.pid}));
  });
  const stop = async()=>{
    if (child.exitCode===null && child.signalCode===null) child.kill('SIGTERM');
    let result = await Promise.race([closed,delay(10000,null,{ref:false})]);
    if(!result){ child.kill('SIGKILL'); result=await closed; }
    await new Promise(resolve=>log.end(resolve));
    return result;
  };
  try {
    for(const endpoint of ['/api/version','/api/tags']){
      let answer;
      const deadline=Date.now()+10000;
      while(Date.now()<deadline){
        if(child.exitCode!==null || child.signalCode!==null) throw Error('Private model server exited before startup');
        answer=await fetch(provider+endpoint,{redirect:'error',signal:AbortSignal.timeout(500)}).then(r=>r.ok?r.json():null).catch(()=>null);
        if(answer)break;
        await delay(100);
      }
      assert(answer,'Private loopback transport did not start');
      if(endpoint.endsWith('version'))provenance.version=answer.version;
      else assert.deepEqual(answer.models.map(x=>x.name),[model]);
    }
    return {provenance, stop};
  } catch(error) {
    await stop();
    throw error;
  }
}

if (process.argv[1]===fileURLToPath(import.meta.url)) {
  const root=process.argv[2];
  assert(root?.startsWith(rootPrefix+'local-model/probe-'));
  mkdirSync(root,{mode:0o700});
  const state=await openPrivateModel(root);
  const result={...state.provenance,requests:[]};
  const name='verify_fixture_value';
  const prompt='Call the available verify_fixture_value tool with value equal to M14-PROBE-ONLY. Do not answer with prose.';
  const schema={type:'object',properties:{value:{type:'string'}},required:['value'],additionalProperties:false};
  const requests=[
    ['/v1/messages',{model,stream:false,max_tokens:150,messages:[{role:'user',content:prompt}],tools:[{name,description:'Record one test string',input_schema:schema}]}],
    ['/v1/responses',{model,stream:false,max_output_tokens:256,input:prompt,tools:[{type:'function',name,description:'Record one test string',parameters:schema,strict:true}]}],
  ];
  try {
    for(const [endpoint,body] of requests){
      const response=await fetch(provider+endpoint,{method:'POST',headers:{'content-type':'application/json','anthropic-version':'2023-06-01'},body:JSON.stringify(body),redirect:'error',signal:AbortSignal.timeout(120000)});
      const raw=await response.text();
      let json;try{json=JSON.parse(raw);}catch{}
      const candidate=endpoint.endsWith('messages')?json?.content?.find(row=>row.type==='tool_use'):json?.output?.find(row=>row.type==='function_call');
      const payload=(candidate?.arguments && JSON.parse(candidate.arguments)) ?? candidate?.input;
      result.requests.push({endpoint,status:response.status,tool:candidate?.name,exact:payload?.value==='M14-PROBE-ONLY',
        usage:json?.usage,err:response.ok?null:raw.slice(0,500)});
    }
    result.passed=result.requests.every(x=>x.status===200&&x.tool===name&&x.exact);
  } catch(error) {
    result.error=String(error);
  } finally {
    result.exit=await state.stop();
    writeFileSync(join(root,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  }
  console.log(JSON.stringify({passed:result.passed,requests:result.requests,exit:result.exit,error:result.error}));
  if(!result.passed)process.exitCode=1;
}
