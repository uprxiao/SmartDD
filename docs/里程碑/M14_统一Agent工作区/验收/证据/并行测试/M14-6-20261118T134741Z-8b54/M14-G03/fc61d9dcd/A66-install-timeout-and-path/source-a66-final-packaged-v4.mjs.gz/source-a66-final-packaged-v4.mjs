import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash,randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { basename,join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openElectron,pause } from '../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../prep-fef791bc6/electron-isolation-paths.mjs';
import {readonlyQuery} from '../a67-tier-matrix/readonly-db.mjs';
import {npmIsolation} from '../a20-queued-and-preparing/git-fixture.mjs';
import {homeBase,timing,title,canary,childBytes,markers,seed,verifyWorkspace} from './fixture.mjs';
import {makeProbe,models,parentInput,done} from './probe-flow.mjs';
import {mergeSettled,resultReady} from './settlement-oracle.mjs';
import {syncFixtureSidebar} from './sidebar-fixture-sync.mjs';

const [out,axis,sourceCommit,asar,lease]=process.argv.slice(2);
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}$/);
assert(['timeout','names-path'].includes(axis),'Use one exact A66 probe axis');
assert.equal(lease,'isolated-acceptance-lease','Coordinator must grant the sole packaged App and 3425 slot');
assert.match(sourceCommit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
const bundle=join(homeBase,'package/mac-arm64/WillYou.app/Contents');
const executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
for(const file of [executable,reader])assert.equal(realpathSync(file),file);
assert.equal(realpathSync(process.cwd()),join(homeBase,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceCommit);
const sha=path=>createHash('sha256').update(readFileSync(path)).digest('hex');
assert.equal(sha(join(bundle,'Resources/app.asar')),asar);
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
const claude=process.env.M14_SMOKE_CLAUDE,codex=process.env.M14_SMOKE_CODEX;
assert.match(claude??'',/^\/Users\/[^/]+\/\.local\/share\/claude\/versions\/2\.1\.326$/);
assert.match(codex??'',/^\/Users\/[^/]+\/\.local\/lib\/node_modules\/@openai\/codex\/bin\/codex\.js$/);
assert.equal(realpathSync(claude),claude);
assert.equal(realpathSync(codex),codex);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});
mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const origin='http://127.0.0.1:3425';
const env={...npmIsolation(root),HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_CACHE_HOME:join(home,'.cache'),XDG_DATA_HOME:join(home,'.local/share'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',NO_PROXY:'127.0.0.1,localhost',no_proxy:'127.0.0.1,localhost',
  HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  http_proxy:'http://127.0.0.1:1',https_proxy:'http://127.0.0.1:1',all_proxy:'http://127.0.0.1:1',
  npm_config_ignore_scripts:'false'};
const result={caseId:'M14-A66',axis,sourceCommit,asar,scope:'A/I isolated real packaged App, real native local executors, loopback synthetic model',
  root,actions:[],requests:[],workspaceUi:{},projects:[],runs:[],passed:false};
for(const name of [basename(fileURLToPath(import.meta.url)),'fixture.mjs','probe-flow.mjs','run-a66-final-v4.sh','settlement-oracle.mjs','sidebar-fixture-sync.mjs']){
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
}
let app,active,appTrusted=false,listening=false,phase='isolated setup';
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const sql=(query,args=[],options)=>readonlyQuery(data,query,args,options).rows;
const kernel=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));
const readJson=file=>JSON.parse(readFileSync(file,'utf8'));
const save=(name,value)=>writeFileSync(join(out,name),JSON.stringify(value,null,2)+'\n',{mode:0o600});

function providerResponse(res,protocol,model,{answer,call}){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const event=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
  if(protocol==='claude'){
    event('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,
      usage:{input_tokens:1,output_tokens:0}}});
    event('content_block_start',{index:0,content_block:call?
      {type:'tool_use',id:call.callId,name:call.tool.name,input:{}}:{type:'text',text:''}});
    event('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(call.args)}:{type:'text_delta',text:answer}});
    event('content_block_stop',{index:0});
    event('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});
    event('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item=call?{id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,...(call.tool.namespace?{namespace:call.tool.namespace}:{}),
      name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'}:
      {id:'msg_'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:answer,annotations:[]}]};
    event('response.created',{response:{id,status:'in_progress',output:[]}});
    event('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    if(!call)event('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:answer});
    event('response.output_item.done',{output_index:0,item});
    event('response.completed',{response:{id,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
async function ensureWorkspaceUi(label){
  await app.waitFor('Boolean(document.querySelector("[data-testid=nav-settings]"))',10000,{navigation:true});
  const flag=await app.evaluate('localStorage.getItem("willyou-m14-agent-workspace")');
  const row=result.workspaceUi[label]={flagBefore:flag,beforeActions:result.actions.length,at:Date.now()};
  assert(flag===null||flag==='true'||flag==='false');
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  await app.waitFor('Boolean('+selected(toggle)+')',12000,{navigation:true});
  row.labelBefore=await app.evaluate(selected(toggle)+'?.innerText');
  assert.equal(row.labelBefore?.includes('已开启'),flag==='true');
  if(flag!=='true'){
    await click(toggle);
    row.featureEnabledInTestSetup=true;
  }else row.featureEnabledInTestSetup=false;
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  assert.equal(await app.evaluate('localStorage.getItem("willyou-m14-agent-workspace")'),'true');
  row.flagAfter='true';
  await click('[data-testid="nav-home"]');
  row.afterActions=result.actions.length;
  row.finishedAt=Date.now();
}
const server=createServer(async(req,res)=>{
  const context=active;
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
      return;
    }
    const kind=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!kind){res.statusCode=404;res.end();return;}
    assert(context,'Unexpected actual native request before fixture is ready');
    assert([req.headers.authorization,req.headers['x-api-key']].some(token=>token==='magpie-'+kind||token==='Bearer magpie-'+kind));
    let size=0;
    const chunks=[];
    for await(const bytes of req){size+=bytes.length;assert(size<2*1024*1024);chunks.push(bytes);}
    const payload=JSON.parse(Buffer.concat(chunks));
    assert(Object.values(models).includes(payload.model));
    const event={kind,model:payload.model,slot:context.fixture.slot,at:Date.now()};
    result.requests.push(event);
    const action=await context.flow.next(kind,payload);
    Object.assign(event,{type:action.type,call:action.call?.tool.name,answeredAt:Date.now()});
    if(!res.destroyed)providerResponse(res,kind,payload.model,action);
  }catch(error){
    result.serverError??=String(error.stack??error);
    if(!res.headersSent)res.statusCode=500;
    res.end();
  }
});

async function startApp(){
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listening=true;resolve();});});
  const boot={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(boot,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted=true;
  result.app={pid:app.processId,identity,boot,born:kernel(app.processId)};
  assert.equal(result.app.born.state,'running');
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  const profiles={};
  for(const [role,kind,path,version] of [['parent','claude',claude,'2.1.326'],['child','codex',codex,'0.169.0']]){
    const detection=await app.invoke('agents.customToolPath',kind,path);
    assert.equal(detection.tool?.version,version,detection.error);
    assert.equal(detection.tool?.executable,path);
    const model=models[role];
    const provider=await app.invoke('agents.saveProvider',{name:'A66 Final '+role,preset:'magpie',
      endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
    const profile=await app.invoke('agents.save',{name:'A66 final '+role+' '+kind,toolId:detection.tool.id,source:'provider',
      providerId:provider.id,models:[model],defaultModel:model,isDefault:role==='parent'});
    profiles[role]=profile.id;
  }
  return profiles;
}
const projectFor=fixture=>app.invoke('projects.create',{name:title,aliases:[],description:'',rulesPath:null},
  [{label:'A66 private project directory',path:fixture.cwd}]);
async function prepareRun(fixture,project,profiles){
  const taskTitle='A66 isolated original parent '+fixture.slot;
  const task=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd:fixture.cwd,title:taskTitle,
    profileId:profiles.parent,model:models.parent,tier:'ask'});
  const parent={taskId:task.taskId,title:taskTitle};
  const workspace=()=>{
    const rows=sql('SELECT w.*,a.attempt_id,a.child_turn_id,a.commit_range,a.notified_at,d.delivery_state FROM agent_workspaces w JOIN agent_delegations d ON d.child_task_id=w.child_task_id JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id WHERE d.parent_task_id=?',[parent.taskId]);
    return rows.length===1&&rows[0];
  };
  const flow=makeProbe({fixture,axis,targetId:profiles.child,
    verifyManual(reply){
      assert.equal(realpathSync(fixture.external),fixture.external);
      const registrations=fixture.git(fixture.repo,'worktree','list','--porcelain');
      assert(registrations.split('\n').includes('worktree '+fixture.external));
      assert.equal(fixture.git(fixture.external,'rev-parse','HEAD'),fixture.base);
      return {reply,path:fixture.external,branch:'a66-shell-created-'+fixture.slot,head:fixture.base};
    },
    verifyNoAccepted(){
      assert.equal(sql('SELECT count(*) AS n FROM agent_delegations WHERE parent_task_id=?',[parent.taskId])[0].n,0);
      assert.equal(sql('SELECT count(*) AS n FROM agent_workspaces WHERE path=?',[fixture.external])[0].n,0);
    },
    async readWorkspace(){return verifyWorkspace(await until(()=>{const row=workspace();return row?.state==='ready'&&row},'registered child workspace'),fixture,project,root);},
  });
  return {fixture,project,parent,flow,workspace};
}

async function approveManualIfNeeded(run){
  const {parent,fixture}=run;
  const pending=(await state(parent.taskId)).requests.filter(item=>item.class==='native'&&item.origin.taskId===parent.taskId);
  if(!pending.length)return;
  assert.equal(pending.length,1);
  const [request]=pending;
  if(result.manualApproval?.requestId===request.requestId)return;
  assert(JSON.stringify(request.payload).includes(fixture.manualCommand),'Only the exact isolated Git fixture command may be approved');
  await open(parent);
  const approve='.agent-request-options button:is([aria-label="批准"],[aria-label*="批准一次"])';
  await click(approve);
  await click('.agent-request .agent-confirm-choice');
  result.manualApproval={requestId:request.requestId,taskId:parent.taskId};
}

async function verifyActualTimeout(run){
  const {fixture,workspace,flow}=run;
  const held=await until(()=>{
    const current=workspace();
    if(!current)return false;
    const marker=join(current.path,'packages/web',markers.start);
    return existsSync(marker)&&{row:current,holder:readJson(marker)};
  },'actual npm ci local lifecycle entered the held workspace',25000);
  assert.equal(held.row.state,'preparing');
  assert.equal(held.holder.cwd,join(held.row.path,'packages/web'));
  const birth=kernel(held.holder.pid);
  assert.equal(birth.state,'running');
  assert(birth.startedAt);
  assert.equal(flow.state.child,'initial');
  assert.equal(sql('SELECT count(*) AS n FROM capability_runs WHERE task_id=?',[held.row.child_task_id])[0].n,0);
  assert.equal(fixture.git(fixture.repo,'rev-parse','HEAD'),fixture.base);
  result.timeoutHeld={row:held.row,hold:held.holder,birth,at:Date.now()};
  save('timeout-before.json',result.timeoutHeld);
  await app.screenshot(join(out,'01-live-preparing-timeout.png'));
  const final=await until(()=>{const row=workspace();return row?.state==='ready'&&row},'real 120-second host timeout',timing.maxLiveMs);
  const marker=join(held.holder.cwd,markers.end);
  assert(existsSync(marker),'Exact held fixture must report host termination');
  const stopped=readJson(marker);
  assert.equal(stopped.pid,held.holder.pid);
  assert.equal(stopped.signal,'SIGTERM');
  const elapsed=stopped.at-held.holder.at;
  assert(elapsed>=timing.minLiveMs&&elapsed<=timing.maxLiveMs,JSON.stringify({elapsed,timing}));
  const observed=kernel(held.holder.pid);
  assert(observed.state==='stopped'||observed.startedAt!==birth.startedAt);
  const deps=JSON.parse(final.deps_result);
  assert.deepEqual([deps.state,deps.command,deps.args,deps.cwd,deps.code],['failed','npm',['ci'],held.holder.cwd,-1]);
  assert(deps.detail.includes('宿主命令超时或输出超限')&&deps.detail.includes(markers.output));
  assert.equal(existsSync(join(fixture.cwd,markers.start)),false);
  assert.equal(existsSync(join(fixture.cwd,markers.end)),false);
  result.timeoutConfirmed={deps,started:held.holder,terminated:stopped,elapsed,observed};
  save('timeout-after.json',result.timeoutConfirmed);
}
async function inspectComplete(run){
  const {fixture,project,parent,flow,workspace}=run;
  const completed=await until(()=>{
    const row=workspace();
    if(!row)return false;
    const receipts=sql("SELECT turn_id,status FROM agent_turns WHERE task_id=? AND client_input_id=?",[parent.taskId,'result-'+row.attempt_id]);
    return resultReady(row,receipts);
  },'same actual parent result receipt fully completes',53000);
  const {workspace:row,receipt}=completed;
  const {mapped,segment}=verifyWorkspace(row,fixture,project,root);
  const range=JSON.parse(row.commit_range);
  assert.deepEqual(range.commits,[range.head]);
  assert.equal(range.base,fixture.base);
  assert.equal(range.head,fixture.git(row.path,'rev-parse','HEAD'));
  assert.equal(fixture.git(row.path,'rev-parse','HEAD^'),fixture.base);
  assert.equal(readFileSync(join(mapped,canary),'utf8'),childBytes);
  assert.equal(fixture.git(fixture.repo,'rev-parse','HEAD'),fixture.base);
  assert.equal(readFileSync(join(fixture.repo,'original.txt'),'utf8'),'DIRTY_'+fixture.slot+'\n');
  const provenance=sql('SELECT commit_sha,intent_id FROM agent_commit_provenance WHERE attempt_id=?',[row.attempt_id]);
  assert.equal(provenance.length,1);
  assert.equal(provenance[0].commit_sha,range.head);
  assert(fixture.git(row.path,'show','-s','--format=%B','HEAD').split('\n').includes('WillYou-Intent: '+provenance[0].intent_id));
  const notifications=sql("SELECT item_id FROM agent_items WHERE task_id=? AND type='notification' AND json_extract(payload_ref,'$.attemptId')=?",[parent.taskId,row.attempt_id]);
  assert.equal(notifications.length,1);
  const child=sql('SELECT turn_id,status,started_at FROM agent_turns WHERE turn_id=?',[row.child_turn_id]);
  assert.equal(child.length,1);
  assert.equal(child[0].status,'completed');
  assert.equal((await state(row.child_task_id)).cwd,mapped);
  if(axis==='timeout'){
    assert(flow.state.timeoutInNativeInput);
    const childRequest=result.requests.find(event=>event.slot===fixture.slot&&event.type==='child-exec_command');
    assert(childRequest.at>=result.timeoutConfirmed.terminated.at);
  }
  if(fixture.slot==='a'&&axis==='names-path'){
    assert.equal(flow.state.issues.length,1);
    assert.equal(sql('SELECT count(*) AS n FROM agent_workspaces WHERE path=?',[fixture.external])[0].n,0);
    assert.equal(fixture.git(fixture.external,'status','--porcelain'),'');
    assert.equal(fixture.git(fixture.external,'rev-parse','HEAD'),fixture.base);
  }
  const settled=await until(async()=>{
    const ids=[parent.taskId,row.child_task_id];
    const turns=sql("SELECT turn_id,task_id,client_input_id,status FROM agent_turns WHERE task_id IN (?,?)",ids);
    const runs=sql("SELECT run_id,task_id,state,ended_at FROM capability_runs WHERE task_id IN (?,?)",ids);
    const processes=sql("SELECT p.kind,p.state,p.pid,p.process_started_at FROM capability_run_processes p JOIN capability_runs r ON r.run_id=p.run_id WHERE r.task_id IN (?,?)",ids);
    const [merge]=sql("SELECT COALESCE(json_extract(d.target_json,'$.mergeFailures'),0) AS failures,a.merge_check_json AS check_json FROM agent_delegations d JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id WHERE d.parent_task_id=? AND d.child_task_id=? AND a.attempt_id=?",[...ids,row.attempt_id]);
    const visibleTasks=await app.invoke('agentTasks.list');
    const task=visibleTasks.find(item=>item.taskId===parent.taskId),child=visibleTasks.find(item=>item.taskId===row.child_task_id);
    return mergeSettled({turns,runs,processes,merge,task,child});
  },'real parent result, two persisted merge diagnoses and no remaining active original run',40000);
  save('settled-'+fixture.slot+'.json',settled);
  await open(parent);
  await app.waitFor('document.body.innerText.includes('+JSON.stringify(done.notice)+')',20000,{navigation:true});
  await app.screenshot(join(out,'02-'+fixture.slot+'-real-parent-result.png'));
  const evidence={slot:fixture.slot,projectId:project.id,workspace:row,segment,mapped,child:child[0],receipt,settled,
    notifications,provenance,actualFlow:flow.state};
  result.runs.push(evidence);
  save('proof-'+fixture.slot+'.json',evidence);
  return evidence;
}

async function runProbe(fixture,project,profiles){
  active=await prepareRun(fixture,project,profiles);
  if(fixture.slot==='b'){
    const taskId=active.parent.taskId;
    const [stored]=sql('SELECT project_id,cwd FROM tasks WHERE id=?',[taskId]);
    assert.deepEqual(stored,{project_id:project.id,cwd:fixture.cwd});
    const scoped=await syncFixtureSidebar(app,project.id,taskId);
    result.projectBFixtureUi={...scoped,stored};
    save('project-b-fixture-sidebar.json',result.projectBFixtureUi);
  }
  await open(active.parent);
  await click('[data-testid="agent-delegation-toggle"]');
  await app.waitFor(selected('[data-testid="agent-delegation-toggle"]')+'?.getAttribute("aria-pressed")==="true"',12000);
  await send(parentInput(fixture.slot));
  await until(async()=>{
    if(axis==='names-path'&&fixture.slot==='a')await approveManualIfNeeded(active);
    return active.flow.state.receipt;
  },'actual parent tool returns durable delegation receipt',35000);
  if(axis==='timeout')await verifyActualTimeout(active);
  return inspectComplete(active);
}

async function execute(){
  const a=seed(root,'a',env,axis);
  const b=axis==='names-path'?seed(root,'b',env,axis):null;
  const profiles=await startApp();
  const oldProjects=await app.invoke('projects.list',{includeArchived:true});
  assert(Array.isArray(oldProjects)&&oldProjects.length===0);
  const projectA=await projectFor(a);
  result.projects.push({id:projectA.id,name:projectA.name});
  await ensureWorkspaceUi('original');
  phase=axis==='timeout'?'real isolated dependency timeout':'active Chinese project and manual worktree rejection';
  const first=await runProbe(a,projectA,profiles);
  if(axis==='timeout')return;
  assert.equal(first.workspace.branch, 'feature/0.1.14_willyou_a66-final-boundary-writer');
  phase='same name conflict and two legitimate project identities';
  let duplicate;
  try{await projectFor(b);}catch(error){duplicate=String(error);}
  assert(duplicate?.includes('已有同名项目'));
  const archived=await app.invoke('projects.setArchived',projectA.id,true);
  assert(archived.archivedAt!==null);
  const projectB=await projectFor(b);
  assert.equal(projectB.name,projectA.name);
  assert.notEqual(projectB.id,projectA.id);
  result.projects.push({id:projectB.id,name:projectB.name});
  const second=await runProbe(b,projectB,profiles);
  assert.equal(first.workspace.branch,second.workspace.branch);
  assert.notEqual(first.segment,second.segment);
  assert.notEqual(first.workspace.path,second.workspace.path);
  assert.equal(realpathSync(first.workspace.path),first.workspace.path);
  assert.equal(realpathSync(second.workspace.path),second.workspace.path);
  const projectRows=sql('SELECT id,name,archived_at FROM projects WHERE id IN (?,?) ORDER BY archived_at',[projectA.id,projectB.id]);
  assert.equal(projectRows.length,2);
  assert(projectRows.every(row=>row.name===title));
  assert(projectRows.some(row=>row.id===projectA.id&&row.archived_at)&&projectRows.some(row=>row.id===projectB.id&&!row.archived_at));
  result.sameName={duplicate,projects:projectRows,projectSegments:[first.segment,second.segment],sameBranch:first.workspace.branch};
}

try{await execute();result.passed=true;}
catch(error){result.failure={phase,error:String(error.stack??error)};save('failure.json',result.failure);}
finally{
  if(app){
    if(appTrusted)try{
      result.pending=(await app.invoke('agentTasks.list')).filter(task=>['working','waiting'].includes(task.status)).map(task=>task.taskId);
      if(result.failure&&result.pending.length&&active){
        await app.invoke('agentTasks.stop',active.parent.taskId,true);
        result.stopCleanup=true;
      }
      await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");if(process.pid!=='+app.processId+'||E.app.getPath("userData")!=='+JSON.stringify(data)+')throw Error("Wrong private test instance");setTimeout(()=>E.app.quit(),50);return true;})()');
    }catch(error){result.quitError=String(error);}
    try{result.exit=await app.waitForExit(27000);}
    catch(error){result.quit2Error=String(error);try{result.fallback=await app.crash();}catch{}}
    result.rendererErrors=app.rendererErrors;
    if(result.exit?.code===0&&result.exit.signal===null&&result.exit.pid===app.processId)try{
      const rows=sql("SELECT p.kind,p.pid,p.process_started_at,p.state FROM capability_run_processes p WHERE p.run_id IN (SELECT run_id FROM capability_runs WHERE owner_pid=?)",[app.processId],{exit:result.exit,expectedPid:app.processId});
      assert(rows.length>0);
      result.exitProcesses=rows.map(row=>{
        assert.equal(row.state,'exited');
        const observed=kernel(row.pid);
        assert(observed.state==='stopped'||observed.startedAt!==row.process_started_at);
        return {...row,observed};
      });
    }catch(error){result.exitProcessError=String(error);}
  }
  if(listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.portReleased=!server.listening;
  if(result.timeoutHeld){
    const {hold,birth}=result.timeoutHeld;
    const waitUntil=hold.at+timing.fixtureCeilingMs+4000;
    let observed;
    do{
      observed=kernel(hold.pid);
      if(observed.state!=='running'||observed.startedAt!==birth.startedAt)break;
      await pause(150);
    }while(Date.now()<waitUntil);
    result.holderAtTeardown={observed,retired:observed.state!=='running'||observed.startedAt!==birth.startedAt};
  }
  result.passed=result.passed&&result.exit?.code===0&&result.exit.signal===null&&result.portReleased&&
    (!result.timeoutHeld||result.holderAtTeardown.retired)&&
    !result.rendererErrors?.length&&!result.exitProcessError&&!result.serverError&&!result.stopCleanup;
  save('result.json',result);
  console.log(JSON.stringify({passed:result.passed,axis,exit:result.exit,portReleased:result.portReleased,error:result.failure??result.serverError??result.exitProcessError}));
}
if(!result.passed)process.exitCode=2;
