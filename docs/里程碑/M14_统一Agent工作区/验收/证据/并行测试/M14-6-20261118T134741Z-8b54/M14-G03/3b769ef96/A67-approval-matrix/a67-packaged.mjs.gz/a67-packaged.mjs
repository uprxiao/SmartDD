import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash,randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,readdirSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron,pause } from '../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../prep-fef791bc6/electron-isolation-paths.mjs';
import { createFixture } from './repo-fixture.mjs';
import { chooseFocusedTier, selector as tierSelector, tab, tierState } from '../a26-recheck/tier-input.mjs';
import { parseCodexRollout } from '../a26-codex-rollout.mjs';
import { readonlyQuery } from './readonly-db.mjs';
import { childWrite,createFlow,file,markers,models,title,values } from './merge-flow.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST';
const [out,commit,asar,kind,repository,scenario,tier='ask']=process.argv.slice(2);
const bundle=join(base,'package/mac-arm64/WillYou.app/Contents'),executable=join(bundle,'MacOS/WillYou'),reader=join(bundle,'Resources/native/willyou-process-identity');
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-[0-9]{3}$/);
assert.match(commit??'',/^[0-9a-f]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()),join(base,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(realpathSync(executable),executable);
assert.equal(digest(join(bundle,'Resources/app.asar')),asar);
assert(['claude','codex'].includes(kind));
assert(['ordinary','linked'].includes(repository));
assert(['clean','conflict','overlap','reject','leave','staged'].includes(scenario));
assert(['ask','auto','full'].includes(tier));
assert(tier!=='auto'||kind==='codex','Only Codex has native auto_review');
assert(scenario!=='reject'||tier==='ask','A reject uses the genuine manual request panel');
if(tier==='full')assert.equal(process.env.M14_A67_CONFIRM_AUTHORIZED_FULL,'1',
  'The Full Access A67 rows require separately documented explicit authorization');
for(const key of Object.keys(process.env))if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-'))),home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A67',sourceCommit:commit,asar,kind,tier,repository,scenario,layer:'A/I native App and local original executors with scripted model',actions:[],requests:[],approvals:[],tierEvents:[],passed:false};
for(const name of ['a67-packaged.mjs','repo-fixture.mjs','merge-flow.mjs']) copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
let app,appTrusted=false,flow,fixture,parent,phase='isolated setup',listening=false;
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const state=id=>app.invoke('agentTasks.snapshot',id);
const relations=id=>app.invoke('agentTasks.relations',id);
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));

function providerResponse(res,protocol,model,{answer,call}){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const event=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
  if(protocol==='claude'){
    event('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,
      usage:{input_tokens:1,output_tokens:0}}});
    event('content_block_start',{index:0,content_block:call?
      {type:'tool_use',id:call.callId,name:call.tool.name,input:{}}:{type:'text',text:''}});
    event('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(call.args)}:{type:'text_delta',text:answer}});
    event('content_block_stop',{index:0});
    event('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});
    event('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item=call?{id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,...(call.tool.namespace?{namespace:call.tool.namespace}:{}),
      name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'}:
      {id:'msg_'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:answer,annotations:[]}]};
    event('response.created',{response:{id,status:'in_progress',output:[]}});
    event('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    if(!call)event('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:answer});
    event('response.output_item.done',{output_index:0,item});
    event('response.completed',{response:{id,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
function sql(query,args=[]){return readonlyQuery(data,query,args).rows;}


const server=createServer(async(req,res)=>{
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
      return;
    }
    const protocol=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!protocol){res.statusCode=404;res.end();return;}
    const publicToken='magpie-'+protocol;
    assert([req.headers.authorization,req.headers['x-api-key']].some(key=>key===publicToken||key==='Bearer '+publicToken));
    let size=0;const chunks=[];
    for await(const bytes of req){size+=bytes.length;assert(size<2*1024*1024);chunks.push(bytes);}
    const payload=JSON.parse(Buffer.concat(chunks));
    if(!Object.values(models).includes(payload.model)){
      result.unsupportedReviewerPayload={at:Date.now(),knownFixtureModel:false,shape:Object.keys(payload).sort()};
      assert.fail('Unrecognized native endpoint request; stopped without synthesizing an auto-review decision');
    }
    const row={at:Date.now(),protocol,model:payload.model};
    result.requests.push(row);
    const action=await flow.next(protocol,payload);
    Object.assign(row,{type:action.type,tool:action.call?.tool.name??null,callId:action.call?.callId??null,answeredAt:Date.now()});
    if(!res.destroyed)providerResponse(res,protocol,payload.model,action);
  }catch(error){
    result.serverError=String(error.stack??error);
    if(!res.headersSent)res.statusCode=500;
    res.end();
  }
});

function rowsFor(childId){
  return sql("SELECT d.child_task_id,d.delivery_state,d.target_json,a.attempt_id,a.notified_at,a.commit_range,a.merge_check_json,w.path,w.base_commit,w.branch FROM agent_delegations d JOIN agent_delegation_attempts a ON a.delegation_id=d.delegation_id JOIN agent_workspaces w ON w.child_task_id=d.child_task_id WHERE d.parent_task_id=? AND d.child_task_id=?",[parent.taskId,childId]);
}
async function exactRange(receipt,sha,message){
  const rows=rowsFor(receipt.childTaskId);
  assert.equal(rows.length,1);
  const [row]=rows;
  const range=JSON.parse(row.commit_range);
  assert.deepEqual(range.commits,[sha]);
  assert.equal(range.head,sha);
  assert.equal(range.branch,row.branch);
  assert.equal(range.base,fixture.base);
  const provenance=sql("SELECT intent_id,commit_sha,kind FROM agent_commit_provenance WHERE attempt_id=?",[row.attempt_id]);
  assert.equal(provenance.length,1);
  assert.equal(provenance[0].kind,'child_result');
  assert.equal(provenance[0].commit_sha,sha);
  assert.equal(fixture.gitAt(row.path,'rev-parse','HEAD^'),fixture.base);
  assert(fixture.gitAt(row.path,'log','-1','--format=%B').split('\n').includes('WillYou-Intent: '+provenance[0].intent_id));
  const notices=sql("SELECT payload_ref FROM agent_items WHERE task_id=? AND type='notification' AND json_extract(payload_ref,'$.attemptId')=?",[parent.taskId,row.attempt_id]);
  assert.equal(notices.length,1);
  const [notification]=notices.map(row=>JSON.parse(row.payload_ref));
  assert.deepEqual(notification.commits,range);
  result.notice={range,provenance,resultStatus:notification.status,exactNativePrompt:message};
  result.childId=receipt.childTaskId;
}
async function handleApproval(task,expected,deny=false,allowClick=true){
  const request=(await state(task.taskId)).requests.find(item=>item.class==='native'&&item.kind==='command_approval'&&item.origin.taskId===task.taskId);
  if(!request||result.approvals.some(row=>row.id===request.requestId)) return;
  if(!allowClick){
    result.unexpectedManualRequest={id:request.requestId,origin:request.origin,kind:request.kind};
    assert.fail('Unexpected manual approval in '+tier+' for the exact parent command');
  }
  assert(expected,'Unexpected native approval on this run');
  const containsCommand=value=>typeof value==='string' ? value.includes(expected) :
    Boolean(value&&typeof value==='object'&&Object.values(value).some(containsCommand));
  assert(containsCommand(request.payload),'The request is for a different Git command or cwd');
  await open(task);
  const label=deny?'.agent-request .agent-request-options button:is(.deny,[aria-label="拒绝"],[aria-label="取消"])':
    '.agent-request .agent-request-options button:is([aria-label="批准"],[aria-label="批准一次"])';
  await click(label);
  const selectedLabel=await app.evaluate(selected(label)+'?.getAttribute("aria-label")');
  await click('.agent-request .agent-confirm-choice');
  result.approvals.push({id:request.requestId,origin:request.origin,command:expected,selectedLabel,deny});
}

async function setup(){
  fixture=createFixture(root,env,repository);
  result.fixture={root,cwd:fixture.cwd,repo:fixture.repo,base:fixture.base,branch:fixture.branch};
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{listening=true;resolve()});});
  const boot={};
  app=await openElectron({executable,userData:data,env,inspectMain:true,startupMainHook:async info=>Object.assign(boot,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted=true;
  result.app={pid:app.processId,identity,boot,birth:nativeIdentity(app.processId)};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
  await app.invoke('agents.refreshTools');
  if(kind==='claude'){
    const cli=process.env.M14_SMOKE_CLAUDE;
    assert.match(cli??'',/^\/Users\/[^/]+\/\.local\/share\/claude\/versions\/2\.1\.326$/);
    const custom=await app.invoke('agents.customToolPath','claude',cli);
    assert.equal(custom.tool?.version,'2.1.326');
  }
  const tools=await app.invoke('agents.tools');
  const providers={};
  const profiles={};
  for(const [role,executor] of [['parent',kind],['child','codex']]){
    const verified=tools.find(tool=>tool.kind===executor&&tool.installed&&tool.version===(executor==='codex'?'0.169.0':'2.1.326'));
    assert(verified);
    const model=models[role];
    const provider=await app.invoke('agents.saveProvider',{name:'A67 fixture '+role,preset:'magpie',
      endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
    providers[role]=provider.id;
    const profile=await app.invoke('agents.save',{name:'A67 '+role+' '+executor,toolId:verified.id,source:'provider',
      providerId:provider.id,models:[model],defaultModel:model,isDefault:role==='parent'});
    profiles[role]=profile.id;
  }
  assert.notEqual(providers.parent,providers.child);
  const project=await app.invoke('projects.create',{name:'A67 exact isolated Git '+repository,aliases:[],description:'',rulesPath:null},[{label:'work',path:fixture.cwd}]);
  const parentTitle='A67 actual parent merge '+scenario;
  const created=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd:fixture.cwd,title:parentTitle,
    profileId:profiles.parent,model:models.parent,tier:'ask'});
  parent={taskId:created.taskId,title:parentTitle};
  flow=createFlow({scenario,kind,tier,targetId:profiles.child,cwd:fixture.cwd,recordNotice:exactRange,workFor:async id=>{
    const [row]=await until(()=>{const rows=rowsFor(id);return rows.length===1&&rows;},'real child worktree registration');
    assert.equal(row.base_commit,fixture.base);
    assert(row.path.startsWith(join(home,'.willyou/worktrees')+'/'));
    assert.equal(realpathSync(row.path),row.path);
    return row.path;
  }});
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(toggle)+'?.innerText.includes("已开启")'))await click(toggle);
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  await click('[data-testid="nav-home"]');
  await open(parent);
  assert.equal((await state(parent.taskId)).cwd,fixture.cwd);
  await setRealTier();
  await click('[data-testid="agent-delegation-toggle"]');
  await app.waitFor(selected('[data-testid="agent-delegation-toggle"]')+'?.getAttribute("aria-pressed")==="true"',12000);
}

async function setRealTier(){
  if(tier==='ask'){assert.equal((await state(parent.taskId)).selection.tier,'ask');return;}
  await app.cdp('Runtime.enable');
  app.onCDP('Runtime.consoleAPICalled', event=>{
    const message=event.args?.[0]?.value;
    if(typeof message==='string'&&message.startsWith('A26_SELECT_EVENT '))
      result.tierEvents.push(JSON.parse(message.slice('A26_SELECT_EVENT '.length)));
  });
  await click('.agent-task-view textarea');
  await tab(app);
  assert((await app.evaluate(tierState))?.active,'Actual tier field must own keyboard focus');
  await chooseFocusedTier(app,tier);
  const confirmation='[data-testid="agent-confirm-full"]';
  if(tier==='full'){
    await app.waitFor('Boolean('+selected(confirmation)+')',10000);
    assert.equal((await state(parent.taskId)).selection.tier,'ask','No full access before actual UI confirmation');
    await click(confirmation);
    result.fullUiConfirmed=true;
  }
  await app.waitFor(selected(tierSelector)+'?.value==='+JSON.stringify(tier),10000);
  await until(async()=> (await state(parent.taskId)).selection.tier===tier,'actual saved parent tier');
  await until(()=>result.tierEvents.some(event=>event.type==='change'&&event.value===tier&&event.trusted),'trusted UI tier change',8000);
}

function nativeCodexPolicy(nativeTurnId){
  const dir=join(data,'agents','codex');
  for(const relative of readdirSync(dir,{recursive:true}).filter(name=>/(?:^|\/)rollout-.*\.jsonl$/.test(name))){
    const record=parseCodexRollout(readFileSync(join(dir,relative),'utf8'),nativeTurnId);
    if(record)return record;
  }
}

async function execute(){
  phase='normal user input, genuine delegation and baseline receipt';
  await send(markers.parent);
  const receipt=await until(()=>flow.state.receipt&&flow.state.childStep==='gated'&&flow.state.receipt,'genuine exact child worktree receipt');
  const child={taskId:receipt.childTaskId,title};
  assert.equal(receipt.baseCommit,fixture.base);
  await until(async()=>{
    const snap=await state(parent.taskId);
    return !snap.run?.busy&&snap.items.some(item=>item.type==='assistant_message'&&item.payload.text===markers.delegated);
  },'original parent finished while child input is still gated');
  fixture.prepare(scenario);
  result.beforeMerge={head:fixture.git('rev-parse','HEAD'),branch:fixture.branch,content:readFileSync(join(fixture.cwd,file),'utf8'),
    status:fixture.git('status','--porcelain')};
  const [childWorkspace]=rowsFor(child.taskId);
  assert.equal(fixture.gitAt(childWorkspace.path,'rev-parse','HEAD'),fixture.base);
  await app.screenshot(join(out,'01-before-native-merge.png'));
  flow.release();
  phase='real native child writes, host commits, parent handles exact notice';
  const outcome=await until(async()=>{
    if(flow.state.childStep==='writing')await handleApproval(child,childWrite(childWorkspace.path));
    if(flow.state.commands.length)await handleApproval(parent,flow.state.commands.at(-1).command,scenario==='reject',tier==='ask');
    const [row]=rowsFor(child.taskId);
    if(!row?.merge_check_json||!flow.state.done)return;
    const snap=await state(parent.taskId);
    const finished=!snap.run?.busy&&!snap.requests.length&&!snap.queuedTotal;
    const merge=JSON.parse(row.merge_check_json);
    const failures=JSON.parse(row.target_json).mergeFailures;
    if(finished&&(['leave','reject','staged'].includes(scenario)?failures===2&&flow.state.retryNotices.length===1:merge.pass))
      return {merge,failures,snap,row};
  },'actual parent turn and host merge verification',45000);
  const commands=flow.state.commands;
  result.outcome={merge:outcome.merge,failures:outcome.failures,attemptId:outcome.row.attempt_id,parent:parent.taskId,
    status:outcome.snap.status,commands,retryNotices:flow.state.retryNotices,
    afterHead:fixture.git('rev-parse','HEAD'),originalBranch:fixture.branch,relativeGitStatus:fixture.git('status','--porcelain')};
  const parentApprovals=result.approvals.filter(row=>row.origin.taskId===parent.taskId);
  const privilegedCommands=commands.filter(command=>command.approvalExpected);
  const nativeRequests=sql("SELECT request_id,status,kind,origin_json FROM agent_requests WHERE task_id=? AND class='native' AND kind='command_approval' ORDER BY created_at",[parent.taskId]);
  const observedApprovals = parentApprovals.map(row=>row.command);
  const requiredApprovals = privilegedCommands.map(row=>row.command);
  assert.deepEqual(observedApprovals.filter(command=>requiredApprovals.includes(command)),requiredApprovals,
    'Every Git write in request mode must have an exact matching approval');
  const declaredCommands = commands.map(row=>row.command);
  assert.deepEqual(observedApprovals,declaredCommands.filter(command=>observedApprovals.includes(command)),
    'Additional native prompts may only be for commands actually issued in this test');
  if (tier !== 'ask') assert.equal(observedApprovals.length,0);
  assert.equal(nativeRequests.length,parentApprovals.length,'Every parent approval must be backed by one real durable request; zero in auto/full');
  assert(nativeRequests.every((row,index)=>row.request_id===parentApprovals[index].id&&row.status==='resolved'));
  result.nativeRequests=nativeRequests;
  assert(commands.every(row=>row.receipt));
  if(kind==='codex'){
    const actualTurn=sql("SELECT native_turn_id FROM agent_turns WHERE task_id=? AND source_kind='notification' AND json_extract(input_ref,'$.text') LIKE '%宿主子任务结果通知%' ORDER BY rowid LIMIT 1",[parent.taskId])[0];
    assert(actualTurn?.native_turn_id);
    result.nativePolicy=await until(()=>nativeCodexPolicy(actualTurn.native_turn_id),'exact Codex native turn policy',7000);
    const {approval,sandbox,reviewer}=result.nativePolicy;
    const expected=tier==='full'?['never','danger-full-access','user']:['on-request','workspace-write',tier==='auto'?'auto_review':'user'];
    assert.deepEqual([approval,sandbox,reviewer],expected);
    assert(commands.filter(command=>command.command.startsWith('/usr/bin/git ')).every(command=>command.requestedNativeEscalation===(tier!=='full')));
  }
  if(tier==='auto'){
    const approvedNotices=outcome.snap.items.filter(item=>item.type==='system_notice'&&item.payload.title==='自动审批检查'&&
      /^approved(?:$| · )/.test(item.payload.detail??''));
    assert.equal(approvedNotices.length,commands.filter(command=>command.autoReviewExpected).length,'Automatic lane needs one genuine native completed approved event per Git command');
    result.autoReviews=approvedNotices.map(item=>({itemId:item.itemId,detail:item.payload.detail}));
    await app.waitFor('Array.from(document.querySelectorAll(".agent-system-notice summary")).some(e=>e.innerText.includes("自动审批检查"))',8000);
    await app.screenshot(join(out,'04-native-auto-approval-outcomes.png'));
  }
  assert.equal(fixture.git('rev-parse','--abbrev-ref','HEAD'),fixture.branch);
  assert.equal(fixture.git('remote'),'');
  assert.deepEqual(sql("SELECT intent_id FROM agent_intents WHERE action='auto_commit' AND task_id=?",[parent.taskId]),[]);
  await open(parent);
  if(['reject','leave','staged'].includes(scenario)){
    assert(!outcome.merge.pass);
    assert.equal(result.outcome.afterHead,result.beforeMerge.head);
    assert.equal(outcome.failures,2);
    assert.equal(commands.length,scenario==='staged'?3:1,'No fallback command after the exact requested stop point');
    if(scenario==='reject'){
      assert(parentApprovals[0].deny);
      assert.equal(readFileSync(join(fixture.cwd,file),'utf8'),values.base);
      assert(!existsSync(fixture.gitPath('CHERRY_PICK_HEAD')));
    }else{
      assert(!parentApprovals[0].deny);
      assert(outcome.merge.inProgress.includes('CHERRY_PICK_HEAD'));
      assert(existsSync(fixture.gitPath('CHERRY_PICK_HEAD')));
      const current=readFileSync(join(fixture.cwd,file),'utf8');
      if(scenario==='staged'){
        assert.equal(current,values.resolved);
        assert.equal(outcome.merge.conflictMarkers,'');
        assert.equal(fixture.git('diff','--cached','--name-only'),file);
      }else assert(current.includes('<<<<<<<'));
    }
    await app.waitFor(selected('.agent-merge-banner')+'?.innerText.includes("需要你处理")',9000);
    await app.screenshot(join(out,'02-merge-needs-handling.png'));
    return;
  }
  assert(outcome.merge.pass&&outcome.merge.branchOk);
  assert.deepEqual(outcome.merge.inProgress,[]);
  assert.deepEqual(outcome.merge.missingCommits,[]);
  assert.equal(outcome.merge.conflictMarkers,'');
  assert.equal(readFileSync(join(fixture.cwd,file),'utf8'),scenario==='clean'?values.child:values.resolved);
  assert(fixture.git('log','-1','--format=%B').includes('(cherry picked from commit '+result.notice.range.head+')'));
  assert.equal(result.outcome.relativeGitStatus,'');
  const summary='.agent-child-summary > details';
  await app.waitFor('Boolean('+selected(summary)+')',10000);
  const readLabels=()=>app.evaluate('({panel:'+selected(summary)+'?.innerText||"", visible:document.querySelector(".agent-task-view")?.innerText||"", open:'+selected(summary)+'?.open})');
  const expanded=await readLabels();
  await app.screenshot(join(out,'02-expanded-merge-outcome.png'));
  if(expanded.open)await click(summary+' > summary');
  await app.waitFor(selected(summary)+'?.open===false',8000);
  const collapsed=await readLabels();
  await app.screenshot(join(out,'03-collapsed-merge-outcome.png'));
  result.mergeUi={expandedLabel:/合并核对通过|已核实合入/.exec(expanded.panel)?.[0]??null,
    collapsedLabel:/合并核对通过|已核实合入/.exec(collapsed.visible)?.[0]??null,formalLabelWithCollapse:collapsed.visible.includes('合并核对通过')};
  if(!result.mergeUi.formalLabelWithCollapse)result.presentationGap='正式通过文案或折叠保留缺失';
}

try{
  await setup();
  await execute();
  result.passed=!result.presentationGap;
}catch(error){
  result.failure={phase,error:String(error.stack??error)};
  if(appTrusted)try{await app.screenshot(join(out,'99-failure.png'));}catch{}
}finally{
  if(flow)flow.close();
  if(app){
    try{
      const list=await app.invoke('agentTasks.list');
      result.pending=list.filter(task=>['working','waiting'].includes(task.status)).map(task=>task.taskId);
      if(result.failure&&result.pending.length&&parent){
        await app.invoke('agentTasks.stop',parent.taskId,true);
        result.cleanupStopped=true;
      }
      await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");if(process.pid!=='+app.processId+'||E.app.getPath("userData")!=='+JSON.stringify(data)+') throw Error("Wrong private instance");setTimeout(()=>E.app.quit(),50);return true})()');
    }catch(error){result.quitCall=String(error);}
    try{result.exit=await app.waitForExit(22000);}
    catch(error){result.quitError=String(error);try{result.cleanup=await app.crash();}catch{}}
    result.rendererErrors=app.rendererErrors;
    if(result.exit?.code===0&&result.exit.signal===null&&result.exit.pid===app.processId&&parent)try{
      const {rows,mode}=readonlyQuery(data,"SELECT p.kind,p.pid,p.process_started_at,p.state FROM capability_run_processes p WHERE p.run_id IN (SELECT run_id FROM capability_runs WHERE owner_pid=?)",[app.processId],{exit:result.exit,expectedPid:app.processId});
      result.exitDatabaseMode=mode;
      assert(rows.length>0);
      result.exitProcesses=rows.map(row=>{
        const now=nativeIdentity(row.pid);
        assert.equal(row.state,'exited');
        assert(now.state==='stopped'||now.state==='running'&&now.startedAt!==row.process_started_at);
        return {...row,observed:now};
      });
    }catch(error){result.exitProcessError=String(error);}
  }
  if(listening){server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
  result.portReleased=!server.listening;
  result.passed=result.passed&&result.exit?.code===0&&result.exit.signal===null&&result.portReleased&&
    !result.rendererErrors?.length&&!result.exitProcessError&&!result.serverError&&!result.cleanupStopped;
  writeFileSync(join(out,'result.json'),JSON.stringify(result,null,2)+'\n',{mode:0o600});
  console.log(JSON.stringify({passed:result.passed,scenario,ui:result.mergeUi,error:result.failure,exit:result.exit,portReleased:result.portReleased}));
}
if(!result.passed)process.exitCode=2;

