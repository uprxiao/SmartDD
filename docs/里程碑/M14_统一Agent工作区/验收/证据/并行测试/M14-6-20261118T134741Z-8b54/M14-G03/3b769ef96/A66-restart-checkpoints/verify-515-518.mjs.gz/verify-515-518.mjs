import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync,readFileSync } from 'node:fs';
import { join } from 'node:path';
import { readRecovery,verifyAfterRecovery,verifyBeforeCrash } from './restart-oracle.mjs';
import { verifyReadyBeforeNative,verifyReadyAfterNative } from './worktree-ready-checkpoint.mjs';
import { readonlyQuery } from '../../a67-tier-matrix/readonly-db.mjs';

const base='/private/tmp/willyou-m14-stage6.WRvdST/g03';
const digest=filename=>createHash('sha256').update(readFileSync(filename)).digest('hex');
const readJson=path=>JSON.parse(readFileSync(path,'utf8'));
const proved=[];
for(const n of [515,516,518]){
  const path=join(base,'attempt-'+n);
  const result=readJson(join(path,'result.json'));
  const checkpoint=readJson(join(path,'before-checkpoint.json'));
  const saved=readJson(join(path,'after-normal-exit.json'));
  const native=readJson(join(path,'native-notice.json'));
  const options={exit:result.normalExit,expectedPid:result.apps.recovered.pid};
  assert.deepEqual(result.normalExit,{pid:result.apps.recovered.pid,code:0,signal:null});
  assert.deepEqual(result.crashExit,{pid:result.apps.original.pid,code:null,signal:'SIGKILL'});
  assert.equal(result.portReleased,true);
  assert.equal(result.serverError,undefined);
  assert.equal(result.exitProcessError,undefined);
  assert.equal(result.passed,false);
  assert.equal(result.apps.original.rendererErrors.length+result.apps.recovered.rendererErrors.length,0);
  const {marker,observed:before}=checkpoint;
  const {data,root}=result.fixture;
  assert(!existsSync(join(data,'smartdd.db-wal')));
  const after=readRecovery(root,marker,options);
  assert.deepEqual(after,saved.observed);
  const ready=result.stage==='worktree-built';
  if(ready)verifyReadyBeforeNative(marker,before,checkpoint.child.turn,checkpoint.child.runs.length);
  else verifyBeforeCrash(result.stage,marker,before);
  verifyAfterRecovery(result.stage,before,after);
  assert.equal(after.attempt.child_turn_id,before.attempt.child_turn_id);
  assert.equal(after.attempt.delivery_state,'delivered');
  assert.equal(native.attemptId,after.attempt.attempt_id);
  assert.equal(native.sha,after.git.workHead);
  assert.equal(native.childId,marker.child);
  const recoveredChildRequests=result.requests.filter(row=>row.owner==='recovered'&&row.kind==='codex');
  if(ready){
    assert.deepEqual(recoveredChildRequests.map(row=>row.type),['child-exec_command','child-native-completed']);
    assert.equal(result.requests.filter(row=>row.owner==='original'&&row.kind==='codex').length,0);
  }else assert.equal(recoveredChildRequests.length,0);
  const actual=result.requests.filter(row=>row.type==='real-recovered-notice');
  assert.equal(actual.length,1);
  assert.equal(actual[0].owner,'recovered');
  const query=(sql,args)=>readonlyQuery(data,sql,args,options);
  const {rows:receiptOwners,mode}=query("SELECT r.run_id,r.owner_pid,r.owner_started_at,r.task_id,r.state,t.client_input_id,t.status turn_status FROM agent_turns t JOIN capability_runs r ON r.run_id=t.run_id WHERE t.turn_id=?", [after.receipts[0].turn_id]);
  assert.equal(mode,'immutable-after-exit');
  assert.equal(receiptOwners.length,1);
  const [owner]=receiptOwners;
  assert.equal(owner.owner_pid,result.apps.recovered.pid);
  assert.equal(owner.owner_started_at,result.apps.recovered.birth.startedAt);
  assert.equal(owner.task_id,marker.parent);
  assert.equal(owner.client_input_id,'result-'+after.attempt.attempt_id);
  assert.equal(owner.turn_status,'completed');
  const child= query("SELECT t.turn_id,t.status,r.owner_pid,r.owner_started_at FROM agent_turns t JOIN capability_runs r ON r.run_id=t.run_id WHERE t.turn_id=?",[after.attempt.child_turn_id]).rows;
  assert.equal(child.length,1);
  const intendedOwner=ready?result.apps.recovered:result.apps.original;
  assert.equal(child[0].owner_pid,intendedOwner.pid);
  assert.equal(child[0].owner_started_at,intendedOwner.birth.startedAt);
  if(ready){
    verifyReadyAfterNative(marker,before,after,saved.child.turn);
    assert.equal(saved.child.runs.length,1);
    assert.equal(saved.child.runs[0].owner_pid,intendedOwner.pid);
    assert.equal(saved.child.runs[0].state,'stopped');
  }
  assert.equal(child[0].status,'completed');
  const lines=query("SELECT json_extract(payload_ref,'$.text') text FROM agent_items WHERE task_id=? AND turn_id=? AND type='assistant_message'",[marker.parent,after.receipts[0].turn_id]).rows;
  assert(lines.some(line=>line.text?.includes('A66 PARENT READ RECOVERED CHILD RESULT')));
  assert(after.processes.every(row=>row.state==='exited'));
  const log=join(data,'Local Storage/leveldb/000003.log');
  const level=readFileSync(log);
  for(const encoding of ['utf8','utf16le']){
    assert(!level.includes(Buffer.from('willyou-m14-agent-workspace',encoding)));
  }
  proved.push({attempt:n,stage:result.stage,status:'durable-and-native-recovery-proved; renderer navigation incomplete',
    original:result.crashExit,recovered:result.normalExit,mode,notificationId:after.notices[0].item_id,receiptOwner:owner,
    childRunOwner:child[0],childOriginallyAcceptedWithoutRun:ready,resultAssistantPersisted:true,workspace:after.workspace.workspace_id,childSha:after.git.workHead,
    sameBranch:before.workspace.branch===after.workspace.branch,originalRunCount:after.processes.filter(row=>before.processes.some(b=>b.run_id===row.run_id)).length/2,
    recoveredNativeAttempts:result.requests.filter(row=>row.owner==='recovered').map(row=>row.type),
    rendererM14FlagFoundInLevelDbLog:false,logBytes:level.length,
    evidenceSha256:Object.fromEntries(['before-checkpoint.json','after-normal-exit.json','native-notice.json','result.json','runtime'].map(name=>[name,digest(name==='runtime'?log:join(path,name))])),
    failure:result.failure.error.split('\n').slice(0,4).join('\n')});
}

const consolePath=join(base,'attempt-517.console.log');
const log=readFileSync(consolePath,'utf8');
assert(log.includes('a66-restart-packaged-v3.mjs:19'));
assert(log.includes("assert(['commit-landed','notification-pending'].includes(stage))"));
assert(!existsSync(join(base,'attempt-517')));
proved.push({attempt:517,stage:'worktree-built',status:'launcher v4 misrouted to v3; no isolated run directory; no App launch',
  evidenceSha256:digest(consolePath)});
console.log(JSON.stringify(proved,null,2));
