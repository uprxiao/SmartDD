import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron, pause } from '../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../prep-fef791bc6/electron-isolation-paths.mjs';
import { readonlyQuery } from '../a67-tier-matrix/readonly-db.mjs';
import { prefix, target, sibling, descriptions, marker, phases, kinds, seed, fingerprint, updateTarget, removeTarget, projectionState, inspectOptions, requestSummary } from './fixture.mjs';
import { writeEvents, writeResponses } from './responses.mjs';

const base = '/private/tmp/willyou-m14-stage6.WRvdST';
const bundle = join(base, 'package/mac-arm64/WillYou.app/Contents');
const executable = join(bundle, 'MacOS/WillYou');
const identityReader = join(bundle, 'Resources/native/willyou-process-identity');
const pinnedFix = '9a9da26a785ef3b4bb35ad1d757bfb0cdbcad030';
const [out, sourceCommit, asar, lease] = process.argv.slice(2);
assert.equal(lease, 'isolated-acceptance-lease', 'Coordinator must grant the sole App and 3425 slot');
assert.match(out ?? '', /^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}$/);
assert.match(sourceCommit ?? '', /^[a-f0-9]{40}$/);
assert.match(asar ?? '', /^[a-f0-9]{64}$/);
assert.equal(realpathSync(process.cwd()), join(base, 'source'));
for (const file of [executable, identityReader]) assert.equal(realpathSync(file), file);
assert.equal(execFileSync('/usr/bin/git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), sourceCommit);
execFileSync('/usr/bin/git', ['merge-base', '--is-ancestor', pinnedFix, sourceCommit]);
assert.equal(createHash('sha256').update(readFileSync(join(bundle, 'Resources/app.asar'))).digest('hex'), asar);
for (const key of Object.keys(process.env)) {
  if (/^(ANTHROPIC|OPENAI|DEEPSEEK|CLAUDE_CODE_OAUTH|CODEX_API_KEY)/i.test(key)) assert(!process.env[key], 'Use the clean fixture environment');
}
const tools = {
  claude: { path: '/Users/liubu/.local/share/claude/versions/2.1.326', version: '2.1.326' },
  codex: { path: '/Users/liubu/.local/lib/node_modules/@openai/codex/bin/codex.js', version: '0.169.0' },
};
for (const { path } of Object.values(tools)) assert.equal(realpathSync(path), path);
mkdirSync(out, { mode: 0o700 });
const root = realpathSync(mkdtempSync(join(out, 'runtime-')));
const home = join(root, 'home'), data = join(root, 'data'), cwd = join(root, 'work');
for (const directory of [home, data, cwd]) mkdirSync(directory, { mode: 0o700 });
assert(isM14PreEntryRun(executable, data, home));
for (const name of ['scenario.mjs','fixture.mjs','responses.mjs','run-a08.sh','SHA256SUMS']) copyFileSync(new URL(name, import.meta.url), join(out, 'source-'+name));
const origin = 'http://127.0.0.1:3425';
const model = 'deepseek-flash';
const env = {
  HOME: home, CODEX_HOME: join(home,'.codex'), CLAUDE_CONFIG_DIR: join(home,'.claude'), TMPDIR: root,
  XDG_CONFIG_HOME: join(home,'.config'), XDG_DATA_HOME: join(home,'.local/share'), XDG_CACHE_HOME: join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null', GIT_TERMINAL_PROMPT: '0', ENABLE_TOOL_SEARCH: 'false',
  NO_PROXY: '127.0.0.1,localhost', no_proxy: '127.0.0.1,localhost',
  HTTP_PROXY: 'http://127.0.0.1:1', HTTPS_PROXY: 'http://127.0.0.1:1', ALL_PROXY: 'http://127.0.0.1:1',
  http_proxy: 'http://127.0.0.1:1', https_proxy: 'http://127.0.0.1:1', all_proxy: 'http://127.0.0.1:1',
};
const result = { caseId:'M14-A08', sourceCommit, asar, root, scope:'A/I; exact packaged App and original local native processes; synthetic loopback responder; never executes a Skill script',
  actions:[], requests:[], adopted:[], runs:[], mutation:{}, status:'failed' };
const save = (name, value) => writeFileSync(join(out,name), JSON.stringify(value,null,2)+'\n', { mode:0o600 });
const sql = (query,args = [], options) => readonlyQuery(data,query,args,options).rows;
const kernel = pid => JSON.parse(execFileSync(identityReader,[String(pid)],{ encoding:'utf8', timeout:3000 }));
const element = selector => `document.querySelector(${JSON.stringify(selector)})`;
let app, appTrusted = false, active, phase = 'fixture setup';

const server = createServer(async (req, res) => {
  try {
    assert.equal(req.socket.remoteAddress, '127.0.0.1');
    const url = new URL(req.url, origin);
    assert.equal(url.origin, origin);
    if (req.method === 'GET' && ['/models','/v1/models'].includes(url.pathname)) {
      res.setHeader('content-type','application/json');
      res.end(JSON.stringify({ data:[{ id:model }] }));
      return;
    }
    const kind = url.pathname === '/v1/messages' ? 'claude' : url.pathname === '/v1/responses' ? 'codex' : null;
    if (req.method !== 'POST' || !kind) { res.statusCode=404; res.end(); return; }
    assert(active && kind === active.kind, 'Unexpected native request or stale runtime identity');
    assert([req.headers.authorization,req.headers['x-api-key']].some(token => token === 'magpie-'+kind || token === 'Bearer magpie-'+kind), 'Expected only preset synthetic authorization');
    let size = 0;
    const chunks = [];
    for await (const bytes of req) { size+=bytes.length; assert(size<2*1024*1024); chunks.push(bytes); }
    const payload = JSON.parse(Buffer.concat(chunks));
    assert.equal(payload.model, model);
    const descriptionExposure = requestSummary(payload, kind, active.phase);
    assert(!result.requests.some(row => row.kind === kind && row.phase === active.phase), 'Unexpected repeat request for fixture turn');
    result.requests.push({ kind, phase:active.phase, bytes:size, descriptionExposure, at:Date.now() });
    if (kind === 'claude') writeEvents(res, model, active.answer);
    else writeResponses(res, model, active.answer);
  } catch(error) {
    result.serverError = String(error.message);
    if (!res.headersSent) res.writeHead(500);
    res.end();
  }
});

async function until(read, reason, timeout = 20000) {
  const deadline = Date.now()+timeout;
  do {
    if (result.serverError) throw Error(result.serverError);
    const value = await read();
    if (value) return value;
    await pause(100);
  } while (Date.now()<deadline);
  throw Error('Timed out: '+reason);
}

async function click(selector, text = null) {
  const list = `[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted = text === null ? list : `${list}.filter(node => node.innerText.includes(${JSON.stringify(text)}))`;
  const hit = `(() => {
    const nodes=${wanted}, node=nodes.length===1&&nodes[0];
    if(!node||node.disabled) return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});
    const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;
  })()`;
  await app.waitFor('Boolean('+hit+')',12000);
  const point=await app.evaluate(hit);
  assert(point);
  for (const type of ['mousePressed','mouseReleased']) await app.cdp('Input.dispatchMouseEvent',{ type,...point, button:'left', clickCount:1 });
  result.actions.push({ selector,text,...point });
}
const composer = '.agent-task-view textarea';
const menu = '.agent-menu [role="option"]';
async function input(text) {
  await app.waitFor('Boolean('+element(composer)+')',10000);
  await click(composer);
  await app.cdp('Input.insertText',{ text });
  assert.equal(await app.evaluate(element(composer)+'?.value'), text);
}
async function adopt(name) {
  await app.waitFor(`Array.from(document.querySelectorAll('button.m13-cap')).some(e=>e.innerText.includes(${JSON.stringify(name)}))`,18000);
  await click('button.m13-cap',name);
  await click('[role=dialog] button.m10-button.primary','纳管');
  const registered = await until(async () => (await app.invoke('capabilities.managedList')).items.find(skill => skill.name===name && skill.managed && skill.enabled),name+' adopted');
  assert.equal(registered.sourcePath, join(home,'.claude/skills',name,'SKILL.md'));
  result.adopted.push({ id:registered.id, name, sourcePath:registered.sourcePath, managed:registered.managed, enabled:registered.enabled });
  await app.screenshot(join(out,'00-adopt-'+name+'.png'));
  await click('[role=dialog] button[aria-label="关闭"]');
}

const dbRun = (runId, taskId) => sql(`SELECT r.run_id,r.task_id,r.generation,r.state,r.owner_pid,r.owner_started_at,b.binding_id,b.native_id,b.driver_id,b.state_root,t.turn_id,t.status,t.ended_at,p.pid,p.process_started_at,p.state AS process_state
  FROM capability_runs r JOIN agent_bindings b ON b.binding_id=r.binding_id JOIN agent_turns t ON t.run_id=r.run_id
  JOIN capability_run_processes p ON p.run_id=r.run_id AND p.kind='cli' WHERE r.run_id=? AND r.task_id=?`,[runId,taskId]);
const targetRoot = (kind, run) => kind==='claude' ? join(run.state_root,'skills') : join(home,'.agents/skills');
function placements(kind, run, expectedPhase) {
  const parent = targetRoot(kind,run);
  return [target,sibling].map(name => {
    const rows = sql('SELECT name,capability_id,target_root FROM capability_skill_placements WHERE target_root=? AND name=?',[parent,name]);
    if(name!==target||expectedPhase!=='removed') {
      assert.equal(rows.length,1);
      assert.equal(rows[0].capability_id,result.adopted.find(skill => skill.name===name).id);
    }
    const link = projectionState(join(parent,name),home,name);
    if (name===target && expectedPhase==='removed') assert.notEqual(link.state,'resolved');
    else {
      assert.equal(link.state,'resolved');
      assert.equal(link.description,descriptions[name===sibling?'survivor':expectedPhase]);
    }
    return { name, ...link, recorded:rows.length===1 };
  });
}
async function runCatalog(kind, currentPhase, project, profiles) {
  phase = currentPhase+' '+kind+' native catalog and picker';
  const title = 'A08 '+currentPhase+' '+kind;
  const task = await app.invoke('agentTasks.create',{ projectId:project.id,dirId:project.dirs[0].id,cwd,title,profileId:profiles[kind],model,tier:'ask' });
  const row = '[data-testid="sidebar-agent-task"][data-task-id="'+task.taskId+'"]';
  await click(row);
  await app.waitFor(element('.agent-task-head h1')+'?.textContent==='+JSON.stringify(title),12000);
  const prompt = marker(kind,currentPhase)+' Reply with the requested marker only; do not call tools or change files.';
  const answer = 'READY_'+marker(kind,currentPhase);
  active = { kind,phase:currentPhase,taskId:task.taskId,answer };
  await input(prompt);
  await click('.agent-task-view button[type="submit"]');
  const snapshot = await until(async () => {
    const state = await app.invoke('agentTasks.snapshot',task.taskId);
    const catalog = state.run?.catalog;
    if (!catalog?.skills?.some(skill => skill.name===sibling) || state.run.busy) return null;
    if (!state.items.some(item => item.type==='assistant_message' && item.payload?.text?.trim()===answer)) return null;
    return state;
  },'finished native turn and published survivor for '+title,60000);
  const nativeCatalog = inspectOptions(snapshot.run.catalog.skills,kind,currentPhase,'native catalog');
  const [run,...duplicates] = dbRun(snapshot.run.runId,task.taskId);
  assert(run && !duplicates.length && run.status==='completed' && run.ended_at);
  assert.equal(run.owner_pid,app.processId);
  assert.equal(run.owner_started_at,result.app.born.startedAt);
  assert.equal(run.driver_id,kind==='claude'?'claude-sdk':'codex-app-server');
  assert.equal(run.generation,1);
  assert.match(run.native_id,/^[0-9a-f-]{36}$/);
  assert(run.state_root.startsWith(join(data,'agents',kind)+'/'));
  assert(!result.runs.some(previous => ['run_id','task_id','binding_id','native_id','process_started_at'].some(key => previous.run[key]===run[key])), 'Expected new native identity for every fixture task');
  const cli = kernel(run.pid);
  assert.equal(cli.state,'running');
  assert.equal(cli.startedAt,run.process_started_at);
  assert.equal(run.process_state,'active');
  const notices = snapshot.items.filter(item => ['system_notice','error'].includes(item.type)).map(item => ({ type:item.type,code:item.payload?.code,detail:item.payload?.detail,title:item.payload?.title,severity:item.payload?.severity }));
  // A stale persisted adoption can warn for the one deleted source while its handler continues.
  // An actual startup/scan error, warning about another Skill, or blocked run fails this axis.
  for (const notice of notices) {
    if (notice.type==='system_notice' && notice.severity==='info' && notice.detail==='ready' && /^MCP 启动 · (smartdd_project|wy)_[a-f0-9]+$/.test(notice.title??'')) continue;
    assert(currentPhase==='removed' && notice.code==='managedSkillUnavailable' && notice.detail==='Skill 来源缺少普通 SKILL.md 文件', `Unexpected native/host notice ${JSON.stringify(notice)}`);
  }
  const proof = { kind,phase:currentPhase,run,cli,nativeCatalog,notices,placements:placements(kind,run,currentPhase),warmReply:answer };
  result.runs.push(proof);
  assert.equal(result.requests.filter(request => request.kind===kind && request.phase===currentPhase).length,1);
  await input('$'+prefix);
  await app.waitFor(`Array.from(document.querySelectorAll(${JSON.stringify(menu)})).some(node=>node.querySelector('b')?.textContent===${JSON.stringify('$'+sibling)})`,14000);
  const observed = await app.evaluate(`Array.from(document.querySelectorAll(${JSON.stringify(menu)})).map(node=>({name:node.querySelector('b')?.textContent?.slice(1)??'',description:node.querySelector('small')?.textContent??undefined}))`);
  proof.picker = inspectOptions(observed,kind,currentPhase,'visible picker');
  await app.screenshot(join(out,currentPhase+'-'+kind+'-picker.png'));
  const pick = currentPhase==='removed' ? sibling : target;
  await click(menu,'$'+pick);
  proof.inserted = await app.evaluate(element(composer)+'?.value');
  assert.equal(proof.inserted,'$'+pick+' ');
  active = null;
}

try {
  result.mutation.baseline = seed(home);
  await new Promise((resolve,reject) => { server.once('error',reject); server.listen(3425,'127.0.0.1',resolve); });
  const boot = {};
  app = await openElectron({ executable,userData:data,env,inspectMain:true,startupMainHook:async info => Object.assign(boot,await redirectHome({...info,home})) });
  const verified = await app.mainEvaluate(`(() => {
    const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
    return [E.app.isPackaged,E.app.getPath('userData'),E.app.getPath('home'),process.env.HOME,process.execPath,process.pid];
  })()`);
  assert.deepEqual(verified,[true,data,home,home,executable,app.processId]);
  assert(boot.workerInspectorFlagRemoved);
  appTrusted = true;
  result.app = { pid:app.processId,verified,boot,born:kernel(app.processId) };
  assert.equal(result.app.born.state,'running');
  await app.cdp('Emulation.setDeviceMetricsOverride',{ width:1440,height:900,deviceScaleFactor:1,mobile:false });
  const toolIds = {};
  for(const kind of kinds) {
    const detection = await app.invoke('agents.customToolPath',kind,tools[kind].path);
    assert.equal(detection.tool?.version,tools[kind].version,detection.error);
    assert.equal(detection.tool?.executable,tools[kind].path);
    toolIds[kind] = detection.tool.id;
  }
  const provider = await app.invoke('agents.saveProvider',{ name:'A08 synthetic catalog gateway',preset:'magpie',
    endpoints:{ responses:origin+'/v1',anthropic:origin+'/' },models:[{ id:model,name:model }] });
  const profiles = {};
  for (const kind of kinds) {
    const profile = await app.invoke('agents.save',{ name:'A08 catalog '+kind,toolId:toolIds[kind],source:'provider',providerId:provider.id,models:[model],defaultModel:model,isDefault:kind==='claude' });
    profiles[kind] = profile.id;
  }
  const project = await app.invoke('projects.create',{ name:'A08 isolated Skill catalog',aliases:[],description:'',rulesPath:null },[{ label:'work',path:cwd }]);
  await click('[data-testid="nav-settings"]');
  const flag = '[data-testid="m14-toggle"]';
  if(!(await app.evaluate(element(flag)+'?.innerText.includes("已开启")'))) await click(flag);
  await app.waitFor(element(flag)+'?.innerText.includes("已开启")',12000);
  await click('[data-testid="nav-home"]');
  phase = 'adopt both fixture Skills in the actual library';
  await click('[data-testid="nav-apps"]');
  await click('button.m10-nav','技能');
  for (const name of [target,sibling]) await adopt(name);
  await click('[data-testid="nav-home"]');
  // Leave the Skills screen before the mutations. Its mount-time scan would intentionally revoke dangling links.
  for (const kind of kinds) await runCatalog(kind,'baseline',project,profiles);
  phase = 'update only the selected source description';
  result.mutation.updated = updateTarget(home,result.mutation.baseline);
  for (const kind of kinds) await runCatalog(kind,'updated',project,profiles);
  phase = 'delete exact fixture source while both projections still exist';
  result.mutation.removed = removeTarget(home,result.mutation.updated);
  result.mutation.preFreshProjection = result.runs.filter(proof=>proof.phase==='updated').map(proof => {
    const parent=targetRoot(proof.kind,proof.run);
    const missing=projectionState(join(parent,target),home,target),surviving=projectionState(join(parent,sibling),home,sibling);
    assert.equal(missing.state,'dangling');
    assert.equal(surviving.state,'resolved');
    return { kind:proof.kind, missing,surviving };
  });
  save('pre-fresh-source-deletion.json',result.mutation);
  for (const kind of kinds) await runCatalog(kind,'removed',project,profiles);
  assert.deepEqual(fingerprint(home),result.mutation.removed);
  assert.equal(result.runs.length,kinds.length*phases.length);
  assert(!result.serverError);
  result.status = 'passed-catalog-lifecycle';
} catch(error) {
  result.failure = { phase,error:String(error.stack??error) };
  if (appTrusted) try {
    await app.screenshot(join(out,'99-failure.png'));
    result.visible = await app.evaluate('document.body.innerText.slice(-2600)');
  } catch {}
} finally {
  if (app) {
    if (appTrusted) try {
      result.pending = (await app.invoke('agentTasks.list')).filter(task=>['working','waiting'].includes(task.status)).map(task=>task.taskId);
      if (result.failure && active && result.pending.includes(active.taskId)) {
        await app.invoke('agentTasks.stop',active.taskId,true);
        result.stopCleanup = active.taskId;
      }
      await app.mainEvaluate(`(() => {
        const E=process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
        if(process.pid!==${app.processId}||E.app.getPath('userData')!==${JSON.stringify(data)}) throw Error('Wrong fixture App');
        setTimeout(()=>E.app.quit(),50); return true;
      })()`);
    } catch(error) { result.quitError=String(error); }
    try { result.exit=await app.waitForExit(27000); }
    catch(error) { result.quitWaitError=String(error); try { result.fallback=await app.crash(); } catch {} }
    result.rendererErrors = app.rendererErrors;
    writeFileSync(join(out,'app.log'),app.logs(),{ mode:0o600 });
    if (result.exit?.code===0 && result.exit.signal===null && result.exit.pid===app.processId && result.runs.length) try {
      const rows=sql('SELECT p.kind,p.pid,p.process_started_at,p.state,p.run_id FROM capability_run_processes p JOIN capability_runs r ON p.run_id=r.run_id WHERE r.owner_pid=?',[app.processId],{ exit:result.exit,expectedPid:app.processId });
      assert(rows.length>=result.runs.length);
      result.exitProcesses=rows.map(row => {
        if (row.state==='canceled' && row.pid===null) return row;
        assert.equal(row.state,'exited');
        const observed=kernel(row.pid);
        assert(observed.state==='stopped'||observed.startedAt!==row.process_started_at);
        return {...row,observed};
      });
    } catch(error) { result.exitProcessError=String(error); }
  }
  if (server.listening) {
    server.closeAllConnections();
    await new Promise(resolve=>server.close(resolve));
  }
  result.portReleased=!server.listening;
  save('result.json',result);
}
if (result.status!=='passed-catalog-lifecycle'||result.exit?.code!==0||result.exit.signal!==null||result.rendererErrors?.length||result.exitProcessError||!result.portReleased||result.serverError) process.exitCode=1;
