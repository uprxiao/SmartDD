#!/bin/bash
set -euo pipefail
candidate=/private/tmp/willyou-m14-stage6.WRvdST
dir="$candidate/g03/prep-next/a66-independent-goal-v2"
driver="$dir/a66-independent-packaged.mjs"
node_bin='/Users/liubu/.hermes/node/bin/node'
claude='/Users/liubu/.local/share/claude/versions/2.1.326'
codex='/Users/liubu/.local/lib/node_modules/@openai/codex/bin/codex.js'
clean=(/usr/bin/env -i PATH='/Users/liubu/.hermes/node/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
  LANG=en_US.UTF-8 TZ=Asia/Singapore M14_SMOKE_CLAUDE="$claude" M14_SMOKE_CODEX="$codex")
[[ "$#" -eq 2 && "$2" == independent-goal ]]
cd "$candidate/source"
"${clean[@]}" "$node_bin" -e 'const a=require("node:assert/strict"); a.equal(process.execPath,process.argv[1]); a.equal(process.version,"v22.23.1"); a.equal(typeof WebSocket,"function");' "$node_bin"
if [[ "$1" == --preflight-entry ]]; then
  exec "${clean[@]}" "$node_bin" "$driver" "$candidate/g03/attempt-999" "$2" "" "" no-lease
fi
[[ "$1" =~ ^attempt-[0-9]{3}$ ]]
[[ "${M14_A66_FINAL_LEASE:-}" == isolated-acceptance-lease ]]
[[ "${M14_EXPECTED_SOURCE_COMMIT:-}" =~ ^[a-f0-9]{40}$ ]]
[[ "${M14_EXPECTED_ASAR_SHA256:-}" =~ ^[a-f0-9]{64}$ ]]
[[ ! -e "$candidate/g03/$1" ]]
exec "${clean[@]}" "$node_bin" "$driver" "$candidate/g03/$1" "$2" "$M14_EXPECTED_SOURCE_COMMIT" "$M14_EXPECTED_ASAR_SHA256" "$M14_A66_FINAL_LEASE"
