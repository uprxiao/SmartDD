import assert from 'node:assert/strict';
import {codexToolCall,codexToolReply} from '../a26-recheck/codex-mcp.mjs';
import {defer,latestUserText} from '../a32-recheck/protocol.mjs';

export const goalFixture={
  model:'a66-independent-codex',objective:'A66_INDEPENDENT_GOAL_STAYS_ACTIVE',
  warm:'A66_INDEPENDENT_WARM',warmed:'A66 INDEPENDENT WARM COMPLETE',
  queued:'A66_INDEPENDENT_ORDINARY_INPUT',steered:'A66_INDEPENDENT_SAME_TURN_STEER',
  goalDone:'A66 INDEPENDENT NATIVE GOAL COMPLETE',queueDone:'A66 INDEPENDENT QUEUED INPUT DELIVERED',
};
const userTexts=body=>(body.input??[]).filter(row=>row.role==='user').flatMap(row=>typeof row.content==='string'?[row.content]:
  Array.isArray(row.content)?row.content.filter(part=>part.type==='input_text'||part.type==='text').map(part=>part.text):[]);

export function makeGoalLane(){
  const independentGate=defer(),childGate=defer();
  const state={phase:'warm',childHeld:false,closed:false,actual:[]};
  return {state,expectGoal(){
    assert.equal(state.phase,'warmed');
    state.phase='goal-pending';
  },async holdChild(details){
    assert(!state.closed&&!state.childHeld);
    state.childHeld=true;
    state.childDetails={...details,at:Date.now()};
    await childGate.promise;
    assert(!state.closed);
  },releaseGoal(){
    assert.equal(state.phase,'held');
    independentGate.release();
  },releaseChild(){
    assert(state.childHeld&&state.phase==='queue-finished');
    childGate.release();
    state.childReleasedAt=Date.now();
  },close(){
    state.closed=true;
    independentGate.release();
    childGate.release();
  },async next(kind,body){
    assert.equal(kind,'codex');
    assert.equal(body.model,goalFixture.model);
    if(state.closed)return {type:'fixture-cleanup',answer:'A66 fixture closing'};
    const latest=latestUserText(kind,body).trim();
    if(state.phase==='warm'){
      assert(latest.includes(goalFixture.warm));
      state.phase='warmed';
      state.actual.push({stage:'warm',at:Date.now()});
      return {type:'goal-warm',answer:goalFixture.warmed};
    }
    if(state.phase==='goal-pending'){
      state.phase='held';
      state.actual.push({stage:'native-goal-held',at:Date.now()});
      await independentGate.promise;
      if(state.closed)return {type:'fixture-cleanup',answer:'A66 fixture closing'};
      const call=codexToolCall(body,'update_goal',{status:'complete'});
      assert(call.tool.parameters?.properties?.status?.enum?.includes('complete')||call.tool.parameters?.properties?.status?.type==='string');
      state.goalCallId=call.callId;
      state.phase='complete-reply';
      return {type:'same-native-update-goal',call};
    }
    if(state.phase==='complete-reply'){
      const receipt=codexToolReply(body,state.goalCallId);
      assert.equal(receipt.goal?.objective,goalFixture.objective);
      assert.equal(receipt.goal.status,'complete');
      const payloadSeesSteer=userTexts(body).some(text=>text.includes(goalFixture.steered));
      assert(!userTexts(body).some(text=>text.includes(goalFixture.queued)),'Queued input must not enter the original native turn');
      state.actual.push({stage:'native-update-receipt',at:Date.now(),payloadSeesSteer});
      state.toolReceipt=receipt;
      state.phase='queue-pending';
      return {type:'native-goal-done',answer:goalFixture.goalDone};
    }
    if(state.phase==='queue-pending'){
      assert(latest.includes(goalFixture.queued),'Ordinary accepted user input must be the actual next native user request');
      assert(!state.childReleasedAt,'Child became available before testing independent queue dispatch');
      state.actual.push({stage:'native-new-input',at:Date.now()});
      state.phase='queue-finished';
      return {type:'goal-following-ordinary-input',answer:goalFixture.queueDone};
    }
    throw Error('Unexpected native independent request in '+state.phase);
  }};
}
