import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { existsSync, realpathSync } from 'node:fs';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

export function databaseMode(database, normalExit, expectedPid){
  const checkpointed=normalExit?.pid===expectedPid && Number.isSafeInteger(expectedPid) &&
    expectedPid>1 && normalExit.code===0 && normalExit.signal===null && !existsSync(database+'-wal');
  return checkpointed?'immutable-after-exit':'live-readonly';
}

export function readonlyQuery(userData,query,args=[],options={}){
  const database=join(userData,'smartdd.db');
  assert.equal(realpathSync(database),database);
  const mode=databaseMode(database,options.exit,options.expectedPid);
  const uri=pathToFileURL(database).href+'?mode=ro'+(mode==='immutable-after-exit'?'&immutable=1':'');
  const script='import sqlite3,json,sys;c=sqlite3.connect(sys.argv[1],uri=True);c.row_factory=sqlite3.Row;print(json.dumps([dict(r) for r in c.execute(sys.argv[2],json.loads(sys.argv[3]))]));c.close()';
  const rows=JSON.parse(execFileSync('/usr/bin/python3',['-c',script,uri,query,JSON.stringify(args)],{encoding:'utf8',timeout:10000}));
  if(mode==='immutable-after-exit')assert(!existsSync(database+'-wal'),'Refuse an immutable result if a WAL appeared during the query');
  return {rows,mode};
}
