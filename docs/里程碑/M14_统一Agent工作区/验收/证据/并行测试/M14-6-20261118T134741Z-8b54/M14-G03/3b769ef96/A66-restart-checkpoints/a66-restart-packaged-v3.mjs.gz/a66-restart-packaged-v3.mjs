import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { copyFileSync,existsSync,mkdirSync,mkdtempSync,readFileSync,realpathSync,writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { openElectron,pause } from '../../../prep-fef791bc6/electron-harness.mjs';
import { redirectHome } from '../../../prep-fef791bc6/home-redirect-main.mjs';
import { isM14PreEntryRun } from '../../../prep-fef791bc6/electron-isolation-paths.mjs';
import { createFixture } from '../../a67-tier-matrix/repo-fixture.mjs';
import { readonlyQuery } from '../../a67-tier-matrix/readonly-db.mjs';
import { file, values } from '../../a67-tier-matrix/merge-flow.mjs';
import { armCheckpoint, candidate, expectedAsar, extractCheckpointProof, sourceCommit } from './checkpoints.mjs';
import { makeFlow, childTitle, models, texts } from './recovery-flow.mjs';
import { readMarker, readRecovery, verifyAfterRecovery, verifyBeforeCrash } from './restart-oracle.mjs';

const [out,stage,permission] = process.argv.slice(2);
assert.match(out??'',/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/attempt-\d{3}$/);
assert(['commit-landed','notification-pending'].includes(stage));
assert.equal(permission,'isolated-acceptance-lease','Coordinator must grant the sole packaged App and 3425 slot');
const bundle=join(candidate,'package/mac-arm64/WillYou.app/Contents');
const executable=join(bundle,'MacOS/WillYou');
const reader=join(bundle,'Resources/native/willyou-process-identity');
assert.equal(realpathSync(process.cwd()),join(candidate,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),sourceCommit);
assert.equal(realpathSync(executable),executable);
for(const key of Object.keys(process.env)) {
  if(/^(ANTHROPIC|CLAUDE_CODE_OAUTH|OPENAI|DEEPSEEK|CODEX_API_KEY)/i.test(key))assert(!process.env[key]);
}
const proof=extractCheckpointProof();
assert.equal(proof.asarHash,expectedAsar);
const claude=process.env.M14_SMOKE_CLAUDE;
assert.match(claude??'',/^\/Users\/[^/]+\/\.local\/share\/claude\/versions\/2\.1\.326$/);
assert.equal(realpathSync(claude),claude);
const codex=process.env.M14_SMOKE_CODEX;
assert.match(codex??'',/^\/Users\/[^/]+\/\.local\/lib\/node_modules\/@openai\/codex\/bin\/codex\.js$/);
assert.equal(realpathSync(codex),codex);
mkdirSync(out,{mode:0o700});
const root=realpathSync(mkdtempSync(join(out,'runtime-')));
const home=join(root,'home'),data=join(root,'data');
mkdirSync(home,{mode:0o700});
mkdirSync(data,{mode:0o700});
assert(isM14PreEntryRun(executable,data,home));
const env={HOME:home,CODEX_HOME:join(home,'.codex'),CLAUDE_CONFIG_DIR:join(home,'.claude'),TMPDIR:root,
  XDG_CONFIG_HOME:join(home,'.config'),XDG_DATA_HOME:join(home,'.local/share'),XDG_CACHE_HOME:join(home,'.cache'),
  GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_TERMINAL_PROMPT:'0',ENABLE_TOOL_SEARCH:'false',
  NO_PROXY:'127.0.0.1,localhost',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',
  COREPACK_ENABLE_NETWORK:'0',YARN_ENABLE_NETWORK:'0',npm_config_offline:'true',npm_config_update_notifier:'false'};
const origin='http://127.0.0.1:3425';
const result={caseId:'M14-A66',layer:'A/I packaged App and real native executors with local scripted model',
  stage,sourceCommit,asar:expectedAsar,checkpointProof:proof,actions:[],requests:[],apps:{},passed:false};
for(const name of ['a66-restart-packaged-v3.mjs','checkpoints.mjs','restart-oracle.mjs','recovery-flow.mjs','run-a66-restart-v3.sh']){
  copyFileSync(new URL(name,import.meta.url),join(out,'source-'+name));
}
let app,flow,fixture,parent,marker,before,after;
let owner='original',phase='isolated setup',trusted=false,startedListening=false;
const selected=selector=>'document.querySelector('+JSON.stringify(selector)+')';
const nativeIdentity=pid=>JSON.parse(execFileSync(reader,[String(pid)],{encoding:'utf8',timeout:3000}));
const state=id=>app.invoke('agentTasks.snapshot',id);
const sql=(statement,args=[],options)=>readonlyQuery(data,statement,args,options).rows;
const save=(filename,value)=>writeFileSync(join(out,filename),JSON.stringify(value,null,2)+'\n',{mode:0o600});
const pathContains=(text,childId)=>text.includes(childId)&&text.includes('宿主子任务结果通知');

function providerResponse(res,protocol,model,{answer,call}){
  res.writeHead(200,{'content-type':'text/event-stream'});
  const event=(type,value)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...value})}\n\n`);
  if(protocol==='claude'){
    event('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model,content:[],stop_reason:null,
      usage:{input_tokens:1,output_tokens:0}}});
    event('content_block_start',{index:0,content_block:call?
      {type:'tool_use',id:call.callId,name:call.tool.name,input:{}}:{type:'text',text:''}});
    event('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(call.args)}:{type:'text_delta',text:answer}});
    event('content_block_stop',{index:0});
    event('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});
    event('message_stop',{});
  }else{
    const id='resp_'+randomUUID();
    const item=call?{id:'fc_'+randomUUID(),type:'function_call',call_id:call.callId,...(call.tool.namespace?{namespace:call.tool.namespace}:{}),
      name:call.tool.name,arguments:JSON.stringify(call.args),status:'completed'}:
      {id:'msg_'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:answer,annotations:[]}]};
    event('response.created',{response:{id,status:'in_progress',output:[]}});
    event('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});
    if(!call)event('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:answer});
    event('response.output_item.done',{output_index:0,item});
    event('response.completed',{response:{id,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
  }
  res.end();
}
async function until(fn,label,timeout=35000){
  const end=Date.now()+timeout;
  while(Date.now()<end){
    if(result.serverError)throw Error(result.serverError);
    const value=await fn();if(value)return value;
    await pause(95);
  }
  throw Error('Timed out: '+label);
}
async function click(selector,text=null){
  const list=`[...document.querySelectorAll(${JSON.stringify(selector)})]`;
  const wanted=text===null?list:`${list}.filter(node=>node.innerText.includes(${JSON.stringify(text)}))`;
  const hit=`(() => {const nodes=${wanted},node=nodes.length===1&&nodes[0];if(!node||node.disabled)return null;
    node.scrollIntoView({block:'nearest',inline:'nearest'});const r=node.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
    return r.width&&r.height&&node.contains(document.elementFromPoint(x,y))?{x,y}:null;})()`;
  await app.waitFor('Boolean('+hit+')',11000);
  const point=await app.evaluate(hit);assert(point);
  await app.cdp('Input.dispatchMouseEvent',{type:'mouseMoved',...point});
  for(const type of ['mousePressed','mouseReleased'])await app.cdp('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1});
  result.actions.push({selector,text,...point});
}
async function open(task){
  const row=`[data-testid="sidebar-agent-task"][data-task-id="${task.taskId}"]`;
  await app.waitFor('Boolean('+selected(row)+')',18000,{navigation:true});
  await click(row);
  await app.waitFor(selected('.agent-task-head h1')+'?.textContent==='+JSON.stringify(task.title),15000);
}
async function send(text){
  const editor='.agent-composer textarea';
  await click(editor);
  await app.cdp('Input.insertText',{text});
  assert.equal(await app.evaluate(selected(editor)+'?.value'),text);
  await click('.agent-composer button[type="submit"]');
}
const server=createServer(async(req,res)=>{
  const requestOwner=owner;
  try{
    assert.equal(req.socket.remoteAddress,'127.0.0.1');
    const url=new URL(req.url,origin);
    assert.equal(url.origin,origin);
    if(req.method==='GET'&&['/models','/v1/models'].includes(url.pathname)){
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({data:Object.values(models).map(id=>({id}))}));
      return;
    }
    const kind=url.pathname==='/v1/messages'?'claude':url.pathname==='/v1/responses'?'codex':null;
    if(req.method!=='POST'||!kind){res.statusCode=404;res.end();return;}
    assert([req.headers.authorization,req.headers['x-api-key']].some(token=>token==='magpie-'+kind||token==='Bearer magpie-'+kind));
    let size=0;
    const chunks=[];
    for await(const bytes of req){size+=bytes.length;assert(size<2*1024*1024);chunks.push(bytes);}
    const payload=JSON.parse(Buffer.concat(chunks));
    assert(Object.values(models).includes(payload.model),'Unrecognized native model; no automatic approval synthesized');
    const row={at:Date.now(),kind,owner:requestOwner,model:payload.model};
    result.requests.push(row);
    const action=await flow.next(kind,payload,requestOwner);
    Object.assign(row,{type:action.type,tool:action.call?.tool.name??null,callId:action.call?.callId??null,answeredAt:Date.now()});
    if(!res.destroyed)providerResponse(res,kind,payload.model,action);
  }catch(error){
    if(!result.serverError)result.serverError=String(error.stack??error);
    if(!res.headersSent)res.statusCode=500;
    res.end();
  }
});
function runsFor(appPid,options){
  return sql("SELECT r.task_id,r.run_id,r.state AS run_state,p.kind,p.pid,p.process_started_at,p.state FROM capability_runs r JOIN capability_run_processes p ON p.run_id=r.run_id WHERE r.owner_pid=? ORDER BY r.started_at,p.kind",[appPid],options);
}
function classifyRetirement(rows){
  return rows.map(row=>{
    assert(Number.isSafeInteger(row.pid)&&row.pid>1&&row.process_started_at);
    const observed=nativeIdentity(row.pid);
    return {...row,observed,aliveSameBirth:observed.state==='running'&&observed.startedAt===row.process_started_at};
  });
}
async function boot(label){
  const bootReceipts={};
  trusted=false;
  app=await openElectron({executable,userData:data,env,inspectMain:true,
    startupMainHook:async info=>Object.assign(bootReceipts,await redirectHome({...info,home}))});
  const identity=await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");return [E.app.isPackaged,E.app.getPath("userData"),E.app.getPath("home"),process.execPath,process.pid];})()');
  assert.deepEqual(identity,[true,data,home,executable,app.processId]);
  assert(bootReceipts.workerInspectorFlagRemoved);
  trusted=true;
  const birth=nativeIdentity(app.processId);
  assert.equal(birth.state,'running');
  assert(birth.startedAt);
  result.apps[label]={pid:app.processId,identity,birth,boot:bootReceipts,startedAt:Date.now()};
  await app.cdp('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
}

async function recordNotice(childId,message){
  assert(marker&&before&&pathContains(message,childId),'Actual original child ID must appear in the recovered native prompt');
  const observed=readRecovery(root,marker);
  assert.equal(observed.attempt.attempt_id,before.attempt.attempt_id);
  assert.equal(observed.notices.length,1);
  assert.equal(observed.git.workHead,before.git.workHead);
  assert(message.includes(observed.git.workHead),'Recovered native prompt must carry the exact original Git hash');
  assert.equal(observed.notices[0].head,observed.git.workHead);
  result.nativeNotice={childId,attemptId:observed.attempt.attempt_id,sha:observed.git.workHead,prompt:message,at:Date.now()};
  save('native-notice.json',result.nativeNotice);
  return result.nativeNotice;
}

async function setup(){
  fixture=createFixture(root,env,'ordinary');
  assert.equal(fixture.cwd,join(root,'repo'));
  result.fixture={root,home,data,cwd:fixture.cwd,base:fixture.base,branch:fixture.branch};
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(3425,'127.0.0.1',()=>{startedListening=true;resolve();});});
  await boot('original');
  await app.invoke('agents.refreshTools');
  const custom=await app.invoke('agents.customToolPath','claude',claude);
  assert.equal(custom.tool?.version,'2.1.326');
  const codexTool=await app.invoke('agents.customToolPath','codex',codex);
  assert.equal(codexTool.tool?.executable,codex);
  assert.equal(codexTool.tool?.version,'0.169.0',codexTool.error);
  result.nativeExecutors={claude:{executable:claude,version:custom.tool.version},
    codex:{executable:codex,version:codexTool.tool.version}};
  const tools=await app.invoke('agents.tools');
  const profiles={},providers={};
  for(const [role,kind,version] of [['parent','claude','2.1.326'],['child','codex','0.169.0']]){
    const tool=tools.find(tool=>tool.kind===kind&&tool.installed&&tool.version===version);
    assert(tool,'Expected verifiable original native '+kind+' '+version);
    const model=models[role];
    const provider=await app.invoke('agents.saveProvider',{name:'A66 cold isolated '+role,preset:'magpie',
      endpoints:{responses:origin+'/v1',anthropic:origin+'/'},models:[{id:model,name:model}]});
    providers[role]=provider.id;
    const profile=await app.invoke('agents.save',{name:'A66 cold '+role+' '+kind,toolId:tool.id,source:'provider',
      providerId:provider.id,models:[model],defaultModel:model,isDefault:role==='parent'});
    profiles[role]=profile.id;
  }
  assert.notEqual(providers.parent,providers.child);
  const project=await app.invoke('projects.create',{name:'A66 cold isolated Git',aliases:[],description:'',rulesPath:null},
    [{label:'work',path:fixture.cwd}]);
  const title='A66 Cold Original Parent';
  const created=await app.invoke('agentTasks.create',{projectId:project.id,dirId:project.dirs[0].id,cwd:fixture.cwd,title,
    profileId:profiles.parent,model:models.parent,tier:'ask'});
  parent={taskId:created.taskId,title};
  result.originalParent=parent;
  flow=makeFlow({targetId:profiles.child,recordNotice,getWorkspace:async id=>{
    const workspace=await until(()=>{
      const rows=sql("SELECT path,base_commit,branch,state FROM agent_workspaces WHERE task_id=? AND child_task_id=?",[parent.taskId,id]);
      return rows.length===1&&rows[0].state==='ready'&&rows[0];
    },'real created child worktree');
    assert.equal(workspace.base_commit,fixture.base);
    assert(workspace.path.startsWith(join(home,'.willyou/worktrees')+'/'));
    assert.equal(realpathSync(workspace.path),workspace.path);
    return workspace;
  }});
  await click('[data-testid="nav-settings"]');
  const toggle='[data-testid="m14-toggle"]';
  if(!await app.evaluate('Boolean('+selected(toggle)+')'))await click('.settings-nav button.nav-row','常规');
  if(!await app.evaluate(selected(toggle)+'?.innerText.includes("已开启")'))await click(toggle);
  await app.waitFor(selected(toggle)+'?.innerText.includes("已开启")',14000);
  await click('[data-testid="nav-home"]');
  await open(parent);
  const snapshot=await state(parent.taskId);
  assert.equal(snapshot.cwd,fixture.cwd);
  assert.equal(snapshot.selection.tier,'ask');
  await click('[data-testid="agent-delegation-toggle"]');
  await app.waitFor(selected('[data-testid="agent-delegation-toggle"]')+'?.getAttribute("aria-pressed")==="true"',12000);
}
function guardedExecutorProcesses(rows){
  assert(rows.length>0,'Native capability process records are required');
  assert(rows.some(row=>row.kind==='cli'));
  return classifyRetirement(rows);
}
async function closeNormally(){
  const originalPid=app.processId;
  const label=result.apps.recovered?.pid===originalPid?'recovered':'original';
  if(trusted){
    try{
      const list=await app.invoke('agentTasks.list');
      const active=list.filter(task=>['working','waiting'].includes(task.status));
      result.pendingAtTeardown=active.map(task=>({taskId:task.taskId,status:task.status}));
      if(result.failure&&active.length&&parent){
        await app.invoke('agentTasks.stop',parent.taskId,true);
        result.cleanupStopped=true;
      }
      await app.mainEvaluate('(() => {const E=process.getBuiltinModule("module").createRequire(process.cwd()+"/package.json")("electron");if(process.pid!=='+originalPid+'||E.app.getPath("userData")!=='+JSON.stringify(data)+')throw Error("Wrong private test instance");setTimeout(()=>E.app.quit(),50);return true;})()');
    }catch(error){result.quitCall=String(error);}
  }
  try{result.normalExit=await app.waitForExit(27000);}
  catch(error){
    result.normalExitError=String(error);
    try{result.fallbackExit=await app.crash();}catch(crashError){result.fallbackExitError=String(crashError);}
  }
  if(result.apps[label])result.apps[label].rendererErrors=app.rendererErrors;
}
async function execute(){
  phase='arm exact packaged boundary';
  const original=app;
  const initial=result.apps.original;
  const armed=await armCheckpoint(app,proof,{stage,runtime:root,parent:parent.taskId,repo:fixture.repo,pid:initial.pid});
  result.armed=armed;
  phase='real original parent input and original delegated child';
  await send(texts.parent);
  await until(()=>flow.state.receipt&&flow.state.child==='gated','real parent delegation receipt and gated native child');
  const childId=flow.state.receipt.childTaskId;
  result.childId=childId;
  await app.waitFor('document.body.innerText.includes('+JSON.stringify(texts.parentDone)+')',30000);
  await until(()=>{
    const [turn]=sql("SELECT status FROM agent_turns WHERE task_id=? AND source_kind='user' ORDER BY accepted_at DESC LIMIT 1",[parent.taskId]);
    return turn?.status==='completed';
  },'original parent user turn completed');
  await app.screenshot(join(out,'01-original-parent-before-checkpoint.png'));
  flow.releaseChild();

  phase='facts at exact external effect boundary';
  await until(()=>existsSync(armed.artifact),'independent marker from the fixed packaged checkpoint');
  marker=readMarker(armed.artifact,initial.pid);
  assert.equal(marker.stage,stage);
  assert.equal(marker.parent,parent.taskId);
  assert.equal(marker.child,childId);
  assert.equal(marker.base,fixture.base);
  assert.equal(flow.state.child,'done');
  before=readRecovery(root,marker);
  save('before-checkpoint.json',{marker,observed:before});
  verifyBeforeCrash(stage,marker,before);
  assert.equal(readFileSync(join(before.workspace.path,file),'utf8'),values.child);
  assert.equal(readFileSync(join(fixture.repo,file),'utf8'),values.base);
  result.preCrashProcesses=guardedExecutorProcesses(runsFor(initial.pid));
  assert.deepEqual(nativeIdentity(initial.pid),initial.birth);
  assert(Date.now()-marker.at<14500,'Checkpoint may no longer hold the genuine boundary');
  phase='controlled exit of exact isolated original App';
  result.apps.original.rendererErrors=original.rendererErrors;
  result.crashExit=await original.crash();
  assert.deepEqual(result.crashExit,{pid:initial.pid,code:null,signal:'SIGKILL'});
  const departed=nativeIdentity(initial.pid);
  assert(departed.state==='stopped'||departed.startedAt!==initial.birth.startedAt);
  result.originalBirthAfterCrash=departed;
  app=undefined;
  trusted=false;
  owner='recovered';

  phase='relaunch same data and observe genuine result receipt';
  await boot('recovered');
  assert.notEqual(result.apps.recovered.pid,initial.pid);
  await open(parent);
  await until(()=>flow.state.nativeNotices.length===1,'genuine actual Claude child-result notification');
  await app.waitFor('document.body.innerText.includes('+JSON.stringify(texts.result)+')',35000);
  await until(()=>{
    after=readRecovery(root,marker);
    return after.receipts.length===1&&after.receipts[0].status==='completed';
  },'actual original parent result input completes on reopened App');
  save('after-restart.json',{marker,observed:after});
  verifyAfterRecovery(stage,before,after);
  assert.equal(flow.state.commands.length,1);
  assert.equal(result.requests.filter(row=>row.model===models.child&&row.owner==='recovered').length,0);
  assert.equal((await state(parent.taskId)).cwd,fixture.cwd);
  await until(async()=>{
    const tasks=(await app.invoke('agentTasks.list')).filter(task=>[parent.taskId,childId].includes(task.taskId));
    return tasks.length===2&&tasks.every(task=>!['working','waiting'].includes(task.status));
  },'the original parent and child settle after result notification');
  await app.screenshot(join(out,'02-recovered-real-parent.png'));
  result.oldProcessesAfterRecovery=await until(()=>{
    const rows=classifyRetirement(result.preCrashProcesses);
    return rows.every(row=>!row.aliveSameBirth)&&rows;
  },'exact old CLI and capability bridge births retire');
  result.passed=true;
}

try{
  await setup();
  await execute();
}catch(error){
  result.failure={phase,error:String(error.stack??error)};
  save('failure.json',result.failure);
}finally{
  if(flow)flow.close();
  if(app)await closeNormally();
  if(result.normalExit?.code===0&&result.normalExit.signal===null&&result.apps.recovered?.pid===result.normalExit.pid&&marker)try{
    const options={exit:result.normalExit,expectedPid:result.normalExit.pid};
    const closed=readRecovery(root,marker,options);
    save('after-normal-exit.json',{marker,observed:closed});
    verifyAfterRecovery(stage,before,closed);
    const rows=guardedExecutorProcesses(runsFor(result.normalExit.pid,options));
    assert(rows.every(row=>row.state==='exited'&&!row.aliveSameBirth));
    result.recoveredProcessesAfterExit=rows;
  }catch(error){result.exitProcessError=String(error.stack??error);}
  if(startedListening){
    server.closeAllConnections();
    await new Promise(resolve=>server.close(resolve));
  }
  result.portReleased=!server.listening;
  result.passed=result.passed&&result.portReleased&&result.normalExit?.code===0&&result.normalExit.signal===null&&
    result.apps.recovered?.pid===result.normalExit.pid&&Object.values(result.apps).every(entry=>!entry.rendererErrors?.length)&&
    !result.serverError&&!result.cleanupStopped&&!result.normalExitError&&!result.exitProcessError;
  save('result.json',result);
  console.log(JSON.stringify({passed:result.passed,out,stage,crashExit:result.crashExit,normalExit:result.normalExit,
    portReleased:result.portReleased,error:result.failure??result.exitProcessError??result.serverError}));
}
if(!result.passed)process.exitCode=2;
