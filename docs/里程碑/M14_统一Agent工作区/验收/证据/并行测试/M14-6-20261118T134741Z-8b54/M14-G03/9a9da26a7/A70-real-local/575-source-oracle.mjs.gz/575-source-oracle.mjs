import assert from 'node:assert/strict';

export const readerWitness='A70_FIXED_SOURCE_WITNESS';
export const writerWitness='A70_LOCAL_SERIAL_WRITER_ACK';
export const finalWitness='A70_LOCAL_BOTH_REAL_CHILDREN_OBSERVED';
export const objective=[
 'Delegate through WillYou tools in this isolated repository. First use wy_targets.',
 'Dispatch one read-only child using profile A70 reader codex. Instruct it to read a70-baseline.txt via cat and report the real contents.',
 'Dispatch one shared-directory write-role child using profile A70 writer codex. It should answer A70_LOCAL_SERIAL_WRITER_ACK without changing files. Keep its write role for this queue check.',
 'End this native turn after both delegations. Do not poll, use Bash, or complete the objective before both child results arrive.',
 'Upon each host result notification use wy_observe to fetch that result. Once you have observed both results, say A70_LOCAL_BOTH_REAL_CHILDREN_OBSERVED and finish.',
].join(' ');

export function requestForLocal(kind, payload, model){
  assert(['claude','codex'].includes(kind));
  assert.equal(typeof payload.model,'string');
  assert.equal(model,'qwen3-coder:30b');
  const local={...payload,model};
  const omitted=[];
  if(kind==='codex'&&Array.isArray(local.tools)){
    local.tools=local.tools.filter(tool=>{
      if(tool.type==='custom'&&tool.name==='apply_patch'){omitted.push(tool.name);return false;}
      return true;
    });
    assert(omitted.length<=1);
  }
  return {local,omitted};
}
