import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync,realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { join } from 'node:path';

export const candidate='/private/tmp/willyou-m14-stage6.WRvdST';
export const sourceCommit='3b769ef96372f0e36f1621ad34c3ebd113fd1b91';
export const expectedAsar='e60e2232b3267530f813e5ec8b58e718b47840c16aaccfeb61bf0c0862509c83';
const pack=join(candidate,'package/mac-arm64/WillYou.app/Contents/Resources/app.asar');
const pinnedAsarModule='/Users/liubu/hx/4.uprxiao/SmartDD/node_modules/.pnpm/@electron+asar@3.4.1/node_modules/@electron/asar';
const approvedRuntime=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/(?:attempt-\d{3}|prep-next\/a66-pm-recovery\/restart\/preflight-[A-Za-z0-9]+)\/runtime-[A-Za-z0-9]+$/;
const uniqueId=/^[a-f0-9-]{36}$/;
export const stages=['worktree-built','commit-landed','notification-pending'];
const sourceSites={
  'worktree-built':{
    before:'await this.effect(input.childTaskId, repo.root, ["worktree", "add", "-b", branch, path2, base], signal);',
    hit:'release();',
    after:'const childCwd = this.worktreeCwd({ path: path2, repo_root: repo.root }, repo.cwd, true);',
    guard:'input.parentTaskId===PARENT && repo.root===REPO && path2.startsWith(HOME_WORKTREES)',
    capture:'{parent:input.parentTaskId,child:input.childTaskId,intent:id2,path:path2,branch,base}',
  },
  'commit-landed':{
    before:'await this.effect(taskId, workspace.path, ["commit", "-m", message2, "-m", \x60WillYou-Intent: \x24{id2}\x60]);',
    hit:'const head = await this.git(workspace.path, "rev-parse", "HEAD");',
    after:'if (await this.git(workspace.path, "rev-parse",',
    guard:'workspace.task_id===PARENT && workspace.repo_root===REPO && workspace.path.startsWith(HOME_WORKTREES)',
    capture:'{parent:workspace.task_id,child:taskId,intent:id2,path:workspace.path,branch:workspace.branch,base:before}',
  },
  'notification-pending':{
    before:'const result2 = { sourceKind: "child_result", delegationId: row.delegation_id, childTaskId: row.child_task_id, attemptId: a.attempt_id,',
    hit:'this.d.store.tx(() => {',
    after:'const resultItemId = this.d.store.addHostItem(row.parent_task_id, null, "notification", result2);',
    guard:'row.parent_task_id===PARENT && target.parentCwd===REPO && !!commits && commits.commits.length===1',
    capture:'{parent:row.parent_task_id,child:row.child_task_id,attempt:a.attempt_id,commit:commits.head,branch:commits.branch,base:commits.base}',
  },
};

export function findSites(source){
  const lines=source.split('\n');
  return Object.fromEntries(stages.map(stage=>{
    const info=sourceSites[stage];
    const matches=lines.map((line,index)=>line.trim().startsWith(info.before)&&
      lines[index+1]?.trim()===info.hit&&lines[index+2]?.trim().startsWith(info.after)?index+1:-1)
      .filter(index=>index>=0);
    assert.equal(matches.length,1,'Exactly one known packaged statement for '+stage);
    return [stage,{lineNumber:matches[0],statement:info.hit}];
  }));
}
export function extractCheckpointProof(){
  assert.equal(realpathSync(pack),pack);
  const asarHash=createHash('sha256').update(readFileSync(pack)).digest('hex');
  assert.equal(asarHash,expectedAsar);
  const loader=createRequire(import.meta.url);
  const tool=loader(pinnedAsarModule);
  const source=tool.extractFile(pack,'out/main/index.js');
  return {sourceCommit,asarHash,mainSha256:createHash('sha256').update(source).digest('hex'),sites:findSites(source.toString())};
}
export function checkpointCondition({stage,runtime,parent,repo,pid,timeout=16000}){
  const info=sourceSites[stage];
  assert(info);
  assert.match(runtime,approvedRuntime);
  assert.equal(realpathSync(runtime),runtime);
  assert.match(parent,uniqueId);
  assert.equal(repo,join(runtime,'repo'));
  assert(Number.isSafeInteger(pid)&&pid>1);
  assert(Number.isSafeInteger(timeout)&&timeout>=0&&timeout<=22000);
  const fields={PARENT:parent,REPO:repo,HOME_WORKTREES:join(runtime,'home/.willyou/worktrees')+'/'};
  const actual=info.guard.replace(/\b(?:PARENT|REPO|HOME_WORKTREES)\b/g,name=>JSON.stringify(fields[name]));
  const artifact=join(runtime,'checkpoint-'+stage+'.json');
  const condition='(()=>{if(process.pid!=='+pid+' || !('+actual+'))return false;'+
    'const fs=process.getBuiltinModule("fs"); const file='+JSON.stringify(artifact)+';'+
    'if(fs.existsSync(file))return false;'+
    'fs.writeFileSync(file,JSON.stringify({stage:'+JSON.stringify(stage)+',ownerPid:process.pid,at:Date.now(),...'+info.capture+'}),{flag:"wx",mode:0o600});'+
    'Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,'+timeout+');return false;})()';
  return {condition,artifact};
}

// Call only after the harness verifies the one isolated App and sets up its original tasks.
// The bounded diagnostic gate changes elapsed time only. It does not alter routes, Git, or SQLite.
export async function armCheckpoint(app,proof,options){
  assert.equal(options.pid,app.processId);
  assert.equal(proof.asarHash,expectedAsar);
  const {lineNumber,statement}=proof.sites[options.stage];
  const {condition,artifact}=checkpointCondition({...options,timeout:16000});
  const command='(async()=>{const S=Symbol.for("a66-isolated-checkpoint");'+
    'if(globalThis[S])throw Error("Only one fixed boundary per App");'+
    'const session=new (process.getBuiltinModule("inspector").Session)();session.connect();'+
    'const post=(name,args={})=>new Promise((resolve,reject)=>session.post(name,args,(err,result)=>err?reject(err):resolve(result)));'+
    'const urls=new Set();session.on("Debugger.scriptParsed",event=>urls.add(event.params.url));'+
    'await post("Debugger.enable");const candidates=[...urls].filter(url=>url.endsWith("/Contents/Resources/app.asar/out/main/index.js"));'+
    'if(candidates.length!==1){await post("Debugger.disable");session.disconnect();throw Error("Exact packaged main not available");}'+
    'const armed=await post("Debugger.setBreakpointByUrl",{url:candidates[0],lineNumber:'+lineNumber+',condition:'+JSON.stringify(condition)+'});'+
    'if(armed.locations.length!==1||armed.locations[0].lineNumber!=='+lineNumber+'){'+
    'await post("Debugger.disable");session.disconnect();throw Error("Packaged breakpoint relocated or ambiguous");}'+
    'globalThis[S]=session;return {url:candidates[0],...armed};})()';
  const result=await app.mainEvaluate(command);
  assert.equal(result.locations.length,1);
  return {...result,artifact,lineNumber,statement};
}
