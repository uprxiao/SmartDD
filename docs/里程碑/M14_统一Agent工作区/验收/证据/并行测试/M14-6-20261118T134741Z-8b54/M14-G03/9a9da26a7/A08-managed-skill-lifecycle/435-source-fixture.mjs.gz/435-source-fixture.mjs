import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, readlinkSync, realpathSync, rmdirSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

export const prefix = 'm14-a08-synthetic-';
export const target = prefix + 'check';
export const sibling = prefix + 'survivor';
export const descriptions = {
  baseline: 'A08 exact original description Alpha',
  updated: 'A08 exact revised description Beta',
  survivor: 'A08 exact same-folder survivor Gamma',
};
export const digest = path => createHash('sha256').update(readFileSync(path)).digest('hex');
const script = 'scripts/a08-proof.mjs';
const sourceDir = home => join(home, '.claude', 'skills');
const content = (_name, description) => `---\nname: ${_name}\ndescription: ${description}\n---\n\nThe isolated read-only fixture resource is \`./${script}\`.\n`;
export const marker = (kind, phase) => `A08_CATALOG_LIFECYCLE_${kind.toUpperCase()}_${phase.toUpperCase()}`;
export const phases = ['baseline', 'updated', 'removed'];
export const kinds = ['claude', 'codex'];

export function seed(home) {
  assert.equal(realpathSync(home), home);
  for (const [name, description] of [[target, descriptions.baseline], [sibling, descriptions.survivor]]) {
    const source = join(sourceDir(home), name);
    mkdirSync(join(source, 'scripts'), { recursive: true, mode: 0o700 });
    writeFileSync(join(source, 'SKILL.md'), content(name, description), { flag: 'wx', mode: 0o600 });
    writeFileSync(join(source, script), `console.log(${JSON.stringify(name)});\n`, { flag: 'wx', mode: 0o600 });
  }
  return fingerprint(home);
}

export function fingerprint(home) {
  return Object.fromEntries([target, sibling].map(name => {
    const path = join(sourceDir(home), name);
    if (!existsSync(path)) return [name, null];
    assert.equal(realpathSync(path), path);
    return [name, { entry: digest(join(path, 'SKILL.md')), resource: digest(join(path, script)) }];
  }));
}

export function updateTarget(home, baseline) {
  assert.deepEqual(fingerprint(home), baseline);
  const entry = join(sourceDir(home), target, 'SKILL.md');
  assert(lstatSync(entry).isFile());
  writeFileSync(entry, content(target, descriptions.updated), { mode: 0o600 });
  const after = fingerprint(home);
  assert.notEqual(after[target].entry, baseline[target].entry);
  assert.equal(after[target].resource, baseline[target].resource);
  assert.deepEqual(after[sibling], baseline[sibling]);
  return after;
}

export function removeTarget(home, updated) {
  assert.deepEqual(fingerprint(home), updated);
  const path = join(sourceDir(home), target);
  assert.equal(realpathSync(path), path);
  assert.deepEqual(readdirSync(path).sort(), ['SKILL.md', 'scripts']);
  assert.deepEqual(readdirSync(join(path, 'scripts')), ['a08-proof.mjs']);
  assert.equal(realpathSync(join(path, script)), join(path, script));
  assert.equal(realpathSync(join(path, 'SKILL.md')), join(path, 'SKILL.md'));
  unlinkSync(join(path, script));
  rmdirSync(join(path, 'scripts'));
  unlinkSync(join(path, 'SKILL.md'));
  rmdirSync(path);
  const after = fingerprint(home);
  assert.equal(after[target], null);
  assert.deepEqual(after[sibling], updated[sibling]);
  return after;
}

export function projectionState(path, home, name) {
  assert(path.startsWith(join(home, '..') + '/') && path.endsWith('/' + name), 'Projection must remain in the fixture');
  const source = join(sourceDir(home), name);
  const stat = lstatSync(path, { throwIfNoEntry: false });
  if (!stat) return { path, source, state: 'absent' };
  assert(stat.isSymbolicLink(), 'Expected a real owned projection link');
  assert.equal(readlinkSync(path), source);
  if (!existsSync(path)) return { path, source, state: 'dangling' };
  assert.equal(realpathSync(path), source);
  const entryPath = join(path, 'SKILL.md');
  const description = /^description: ([^\n]+)$/m.exec(readFileSync(entryPath, 'utf8'))?.[1];
  assert(description);
  return { path, source, state: 'resolved', description, sha256: digest(entryPath) };
}

export function inspectOptions(options, kind, phase, layer) {
  assert(Array.isArray(options), `${layer} missing actual options`);
  const entries = options.filter(option => option.name.startsWith(prefix));
  assert.deepEqual(entries.map(option => option.name).sort(), phase === 'removed' ? [sibling] : [target, sibling]);
  if (kind === 'codex') {
    assert.equal(entries.find(option => option.name === sibling).description, descriptions.survivor);
    if (phase !== 'removed') assert.equal(entries.find(option => option.name === target).description, descriptions[phase]);
  }
  return entries;
}

export function requestSummary(payload, kind, phase) {
  const request = JSON.stringify(kind === 'claude' ? payload.messages : payload.input);
  assert(request.includes(marker(kind, phase)), 'Wrong fresh native user request');
  for (const otherKind of kinds) for (const otherPhase of phases) {
    if (otherKind !== kind || otherPhase !== phase) assert(!request.includes(marker(otherKind, otherPhase)), 'Fresh native request carried older marker');
  }
  const visible = JSON.stringify({ messages: payload.messages, input: payload.input, system: payload.system, instructions: payload.instructions, tools: payload.tools });
  const summary = Object.fromEntries(Object.entries(descriptions).map(([key, value]) => [key, visible.includes(value)]));
  if (phase === 'baseline') assert(!summary.updated);
  if (phase === 'updated') assert(!summary.baseline);
  if (phase === 'removed') assert(!summary.baseline && !summary.updated && !visible.includes(target));
  return summary;
}
