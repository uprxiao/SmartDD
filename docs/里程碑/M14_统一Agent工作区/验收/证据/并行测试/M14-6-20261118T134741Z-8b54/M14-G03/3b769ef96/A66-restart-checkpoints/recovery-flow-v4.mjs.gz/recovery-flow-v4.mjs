import assert from 'node:assert/strict';
import { join } from 'node:path';
import { getCall,childWrite,values,file } from '../../a67-tier-matrix/merge-flow.mjs';
import { codexToolCall,listedAvailable } from '../../a26-recheck/codex-mcp.mjs';
import { claudeReply,defer,latestUserText } from '../../a32-recheck/protocol.mjs';

export const models={parent:'a66-cold-claude-parent',child:'a66-cold-codex-child'};
export const childTitle='A66 Cold Recovery Child';
export const texts={
  parent:'A66_COLD_DELEGATION_REAL_INPUT',
  child:'A66_COLD_WORKTREE_NATIVE_WRITE',
  parentDone:'A66 ORIGINAL PARENT ACCEPTED',
  childDone:'A66 CHILD COMPLETED EXACT FIXTURE',
  result:'A66 PARENT READ RECOVERED CHILD RESULT',
  mergeFollowup:'A66 MERGE IS OUTSIDE THIS RECOVERY TEST',
};
const forbidden=/(?:git push|git reset|git checkout|git clean)/i;

export function makeFlow({targetId,getWorkspace,recordNotice,childRunOwner="original"}){
  const state={parent:'initial',child:'initial',released:false,closed:false,childGate:defer(),commands:[],nativeNotices:[]};
  const call=(body,key,tool,args)=>{
    const full=key==='parent'?getCall(body,'claude',tool,args):codexToolCall(body,tool,args);
    state[key+'Call']=full.callId;
    return {type:key+'-'+tool,call:full};
  };
  return {state,usePersistedAcceptance(childId){
    assert.equal(childRunOwner,'recovered');
    assert(['delegating','recovery'].includes(state.parent));
    assert.match(childId,/^[a-f0-9-]{36}$/);
    if(state.receipt)assert.equal(state.receipt.childTaskId,childId);
    state.persistedChildId=childId;
  },releaseChild(){
    assert(!state.released);
    state.released=true;
    state.childGate.release();
  },close(){
    state.closed=true;
    state.childGate.release();
  },async next(kind,body,owner){
    assert(!state.closed);
    const prompt=latestUserText(kind,body);
    if(body.model===models.parent){
      assert.equal(kind,'claude');
      if(state.parent==='initial'){
        assert(prompt.includes(texts.parent));
        state.parent='targets';
        return call(body,'parent','wy_targets',{});
      }
      if(state.parent==='targets'){
        const target=listedAvailable(JSON.parse(claudeReply(body,state.parentCall)),targetId);
        state.parent='delegating';
        return call(body,'parent','wy_delegate',{requestKey:'a66-worktree-crash-private',profileId:target.profileId,
          profileRevision:target.revision,title:childTitle,instructions:texts.child,model:models.child,
          access:'write',workspaceMode:'worktree'});
      }
      if(state.parent==='delegating'&&owner==='original'){
        state.receipt=JSON.parse(claudeReply(body,state.parentCall));
        assert.equal(state.receipt.workspaceMode,'worktree');
        assert.match(state.receipt.childTaskId,/^[a-f0-9-]{36}$/);
        state.parent='recovery';
        return {type:'parent-original-complete',answer:texts.parentDone};
      }
      if(prompt.includes('宿主子任务结果通知')){
        const childId=state.receipt?.childTaskId??state.persistedChildId;
        assert(childId&&prompt.includes(childId));
        assert.equal(owner,'recovered','The child result must reach only the new App, after the fault');
        assert.equal(state.nativeNotices.length,0,'Duplicate result passed to the actual native agent');
        const notice=await recordNotice(childId,prompt);
        state.nativeNotices.push({owner,attempt:notice.attemptId,sha:notice.sha});
        return {type:'real-recovered-notice',answer:texts.result};
      }
      if(prompt.includes('宿主合并核对失败：')){
        assert.equal(owner,'recovered');
        assert.equal(state.nativeNotices.length,1);
        return {type:'separate-merge-followup',answer:texts.mergeFollowup};
      }
      throw Error('Unexpected original Claude request outside isolated recovery stages');
    }
    assert.equal(body.model,models.child);
    assert.equal(kind,'codex');
    assert.equal(owner,childRunOwner,'Child native traffic must use the expected App generation');
    if(state.child==='initial'){
      assert(prompt.includes(texts.child));
      state.child='gated';
      await state.childGate.promise;
      assert(!state.closed);
      const workspace=await getWorkspace(state.receipt?.childTaskId??state.persistedChildId);
      assert.equal(prompt.includes(workspace.base_commit),true,'Child actual prompt must carry the frozen base');
      const command=childWrite(workspace.path);
      assert(!forbidden.test(command));
      state.child='writing';
      const action=call(body,'child','exec_command',{cmd:command,workdir:workspace.path,max_output_tokens:200});
      state.commands.push({owner,command,callId:action.call.callId,expectedFile:join(workspace.path,file),values:values.child});
      return action;
    }
    assert.equal(state.child,'writing','Recovery attempted to repeat a completed original child input');
    const receipts=(body.input??[]).filter(row=>row.type==='function_call_output'&&row.call_id===state.childCall);
    assert.equal(receipts.length,1);
    const response=JSON.stringify(receipts[0].output);
    const command=state.commands[0];
    assert(response.includes(command.expectedFile.slice(0,-file.length-1)));
    assert(!/Permission denied|Operation not permitted|exited with code [1-9]/i.test(response));
    state.child='done';
    return {type:'child-native-completed',answer:texts.childDone};
  }};
}
