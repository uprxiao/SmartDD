import assert from 'node:assert/strict';

export const executors=[
  {kind:'claude',tier:'ask'}, {kind:'claude',tier:'full'},
  {kind:'codex',tier:'ask'}, {kind:'codex',tier:'auto'}, {kind:'codex',tier:'full'},
];
export const scenarios=['clean','conflict','overlap'];
export function makeMatrix(repo,initial,{fullAllowed=false,selection='all'}={}){
  assert(['ordinary','linked','both'].includes(repo));
  assert(['all','authorized','ask','codex-auto','full'].includes(selection));
  assert(Number.isSafeInteger(initial)&&initial>=1);
  const repositories=repo==='both'?['ordinary','linked']:[repo];
  const all=repositories.flatMap(repository=>executors.flatMap(({kind,tier})=>scenarios.map(scenario=>({repository,kind,tier,scenario}))));
  assert(initial+all.length-1<1000,'A67 matrix needs a contiguous three-digit evidence sequence');
  return all.map((cell,index)=>{
    const attempt='attempt-'+String(initial+index).padStart(3,'0');
    const eligible=selection==='all'||selection==='authorized'||
      selection===cell.tier||selection==='codex-auto'&&cell.tier==='auto';
    return {...cell,attempt,status:!eligible?'unselected':cell.tier==='full'&&!fullAllowed?'awaiting-explicit-full-authorization':'ready'};
  });
}

