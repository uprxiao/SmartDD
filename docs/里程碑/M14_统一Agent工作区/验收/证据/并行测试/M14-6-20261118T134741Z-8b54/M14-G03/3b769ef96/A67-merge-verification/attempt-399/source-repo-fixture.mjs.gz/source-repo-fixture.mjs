import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdirSync,lstatSync,realpathSync,writeFileSync } from 'node:fs';
import { isAbsolute,join } from 'node:path';
import { file,values } from './merge-flow.mjs';

const isolated=/^\/private\/tmp\/willyou-m14-stage6\.WRvdST\/g03\/(?:attempt-\d{3}|prep-next\/a66-a67-current\/preflight-[A-Za-z0-9]+)\/runtime-[A-Za-z0-9]+$/;
export function createFixture(root,passedEnv,repository){
  assert.match(root,isolated);
  assert.equal(realpathSync(root),root);
  assert(['ordinary','linked'].includes(repository));
  const env={PATH:process.env.PATH,LANG:'en_US.UTF-8',...passedEnv};
  const repo=join(root,'repo');
  mkdirSync(repo,{mode:0o700});
  const gitAt=(where,...args)=>execFileSync('/usr/bin/git',['-C',where,...args],{env,encoding:'utf8',timeout:10000}).trim();
  const primary=(...args)=>gitAt(repo,...args);
  primary('init','-qb','main');
  primary('config','--local','user.name','A67 Synthetic Fixture');
  primary('config','--local','user.email','a67-fixture@example.invalid');
  primary('config','--local','user.useConfigOnly','true');
  primary('config','--local','commit.gpgSign','false');
  writeFileSync(join(repo,file),values.base,{mode:0o600,flag:'wx'});
  writeFileSync(join(repo,'pom.xml'),'<project><modelVersion>4.0.0</modelVersion></project>\n',{mode:0o600,flag:'wx'});
  primary('add','--',file,'pom.xml');
  primary('commit','-qm','Isolated A67 base');
  const base=primary('rev-parse','HEAD');
  const cwd=repository==='linked'?join(root,'linked'):repo;
  const branch=repository==='linked'?'a67-linked-parent':'main';
  if(repository==='linked')primary('worktree','add','-qb',branch,cwd,base);
  assert.equal(lstatSync(join(cwd,'.git')).isFile(),repository==='linked');
  const git=(...args)=>gitAt(cwd,...args);
  assert.equal(git('config','--local','user.email'),'a67-fixture@example.invalid');
  assert.equal(git('rev-parse','HEAD'),base);
  assert.equal(git('status','--porcelain'),'');
  assert.equal(git('remote'),'');
  const gitPath=name=>{
    assert(['CHERRY_PICK_HEAD','MERGE_HEAD','REBASE_HEAD'].includes(name));
    const path=git('rev-parse','--git-path',name);
    return isAbsolute(path)?path:join(cwd,path);
  };
  function prepare(scenario){
    assert.equal(git('rev-parse','HEAD'),base,'Only legitimate original fixture state may be staged');
    if(['conflict','overlap','leave'].includes(scenario))
      writeFileSync(join(cwd,file),values.parent,{mode:0o600});
    if(['conflict','leave'].includes(scenario)){
      git('add','--',file);
      git('commit','-qm','A67 known conflicting parent change');
    }
    if(scenario==='overlap')assert.equal(git('status','--porcelain'),'M '+file);
    else assert.equal(git('status','--porcelain'),'');
  }
  return {env,repo,base,cwd,branch,git,gitAt,gitPath,prepare};
}

