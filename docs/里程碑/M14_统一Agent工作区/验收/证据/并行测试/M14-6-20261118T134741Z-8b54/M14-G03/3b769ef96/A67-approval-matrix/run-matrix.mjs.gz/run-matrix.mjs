import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { existsSync,readFileSync,writeFileSync } from 'node:fs';
import { dirname,join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeMatrix } from './matrix-plan.mjs';

const shared='/private/tmp/willyou-m14-stage6.WRvdST';
const group=join(shared,'g03');
const directory=dirname(fileURLToPath(import.meta.url));
const [repository,start,selection='authorized',mode='plan',batchName]=process.argv.slice(2);
assert.match(start??'',/^[1-9]\d{0,2}$/);
assert(['plan','execute'].includes(mode));
const fullAllowed=process.env.M14_A67_CONFIRM_AUTHORIZED_FULL==='1';
const rows=makeMatrix(repository,Number(start),{fullAllowed,selection});
if(mode==='plan'){
  assert(batchName===undefined);
  console.log(JSON.stringify({repository,fullAllowed,mode,rows},null,2));
  process.exit(0);
}
assert.match(batchName??'',/^batch-[a-z0-9-]{4,60}$/);
const log=join(directory,batchName+'.json');
assert(!existsSync(log));
const commit=process.env.M14_EXPECTED_SOURCE_COMMIT,asar=process.env.M14_EXPECTED_ASAR_SHA256;
assert.match(commit??'',/^[a-f0-9]{40}$/);
assert.match(asar??'',/^[a-f0-9]{64}$/);
assert.equal(process.cwd(),join(shared,'source'));
assert.equal(execFileSync('/usr/bin/git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),commit);
assert.equal(process.env.M14_A67_APP_SLOT_GRANTED,'1','Use execute only in the coordinator granted common App/3425 slot');
const ready=rows.filter(row=>row.status==='ready');
assert(ready.length>0);
for(const row of ready) {
  assert(!existsSync(join(group,row.attempt))&&!existsSync(join(group,row.attempt+'.console.log')),
    'Existing attempt or log: '+row.attempt);
}
const result={repository,mode,batchName,sourceCommit:commit,asar,fullAllowed,startedAt:new Date().toISOString(),rows};
const record=()=>writeFileSync(log,JSON.stringify(result,null,2)+'\n',{mode:0o600});
record();
for(const row of ready){
  row.status='running';
  row.startedAt=new Date().toISOString();
  record();
  const execution=spawnSync(join(directory,'run-a67.sh'),[row.attempt,row.kind,row.repository,row.scenario,row.tier],
    {stdio:'inherit',env:process.env});
  row.code=execution.status;
  row.signal=execution.signal;
  row.finishedAt=new Date().toISOString();
  const resultPath=join(group,row.attempt,'result.json');
  if(existsSync(resultPath)){
    const actual=JSON.parse(readFileSync(resultPath,'utf8'));
    row.evidence=resultPath;
    row.result={normalExit:actual.exit?.code===0&&actual.exit?.signal===null,portReleased:actual.portReleased===true,
      packagePass:actual.passed===true,phase:actual.failure?.phase??null,ui:actual.mergeUi??null};
  }
  row.status=row.code===0&&row.result?.packagePass?'passed':'failed';
  record();
  if(execution.error||row.code===125||!row.result?.normalExit||!row.result?.portReleased){
    result.abort='Could not prove both an original App normal exit and listener release from '+row.attempt;
    break;
  }
}
result.finishedAt=new Date().toISOString();
record();
process.exitCode=ready.every(row=>row.status==='passed')?0:2;

