'use strict';
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const {lstatSync,readFileSync,readdirSync} = require('node:fs');
const {join,relative,sep} = require('node:path');
const hash = value => createHash('sha256').update(value).digest('hex');
function compare(a,b) { const aa=Array.from(a,c=>c.codePointAt(0)),bb=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(aa.length,bb.length);i++)if(aa[i]!==bb[i])return aa[i]-bb[i];return aa.length-bb.length; }
function canonical(value) { if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort(compare).map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';return JSON.stringify(value); }
const safe = path => typeof path==='string' && path.length>0 && path.length<=1024 && path===path.normalize('NFC') && !/[\\:\x00-\x1f\x7f-\x9f\u202a-\u202e\u2066-\u2069]/u.test(path) && path.split('/').every(p=>p&&p!=='.'&&p!=='..'&&!/[. ]$/.test(p)&&!/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p));
function readJson(path) { const stat=lstatSync(path);assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=4*1024*1024,'Bounded regular bundle metadata');return JSON.parse(readFileSync(path,'utf8')); }
function tree(root,relative) { let dir=root;for(const part of relative.split('/')){dir=join(dir,part);const stat=lstatSync(dir);assert(stat.isDirectory()&&!stat.isSymbolicLink(),'No linked bundle directories');}return dir; }
function names(root,dir=root) { return readdirSync(dir).flatMap(name=>{const path=join(dir,name),stat=lstatSync(path);assert(!stat.isSymbolicLink()&&(stat.isFile()||stat.isDirectory()),'No links or special bundle files');return stat.isDirectory()?names(root,path):[relative(root,path).split(sep).join('/')];}).sort(compare); }
function fullTree(root,path,manifestName,expectedHash) {
  assert(safe(path),'Safe indexed bundle path');const dir=tree(root,path),manifest=readJson(join(dir,manifestName));assert.equal(hash(canonical(manifest)),expectedHash,'Original complete manifest hash');assert(Array.isArray(manifest.files)&&manifest.files.length>0&&manifest.files.length<=4096,'Bounded complete inventory');
  const entries=manifest.files.map(f=>f.path);assert(entries.every(p=>safe(p)&&p!==manifestName),'Safe manifest file paths');assert.equal(new Set(entries.map(p=>p.toLowerCase())).size,entries.length,'Unique case-folded inventory');assert.deepEqual(names(dir),[...entries,manifestName].sort(compare),'Exact complete file inventory');let total=0;
  for(const file of manifest.files){const target=join(dir,file.path),stat=lstatSync(target);assert(stat.isFile()&&!stat.isSymbolicLink(),'Regular owned resource');assert(Number.isSafeInteger(file.size)&&file.size>=0&&file.size<=64*1024*1024,'Bounded resource size');total+=file.size;assert(total<=256*1024*1024,'Bounded bundle bytes');assert.equal(stat.size,file.size,'Original resource size');assert.equal(hash(readFileSync(target)),file.sha256,'Original resource bytes');assert.equal(stat.mode&0o111,file.executable?0o100:0,'Original executable marker');}
  return {manifest,dir};
}
function verifyCapabilityBundles(root,expectedVersion,options={}) {
  const rootStat=lstatSync(root);assert(rootStat.isDirectory()&&!rootStat.isSymbolicLink(),'Regular capability resource root');const index=readJson(join(root,'index.json'));assert.equal(index.schema,'willyou-capability-bundles-v1','Capability index schema');assert.equal(index.build.appVersion,expectedVersion,'Capability App version');assert(!index.build.testFixture||options.allowTestFixture===true,'Test-only compatibility distribution cannot be released');const {indexHash,...content}=index;assert.equal(hash(canonical(content)),indexHash,'Capability index hash');assert.equal(hash(canonical({adapters:index.adapters,runtimes:index.runtimes,apps:index.apps})),index.build.resourceSetHash,'Complete resource-set hash');
  assert.deepEqual(index.adapters.map(a=>a.agentId+'@'+a.version).sort(),['claude-code@1.0.0','claude-code@1.1.0','claude-code@1.2.0','claude-code@1.3.0','claude-code@1.4.0','codex@1.0.0','codex@1.1.0','codex@1.2.0','codex@1.3.0','codex@1.4.0','codex@1.5.0','codex@1.6.0'],'Retained original/legacy adapters and the Codex 0.166.0 baseline');const modules=readJson(join(__dirname,'../../src/shared/application-module-catalog.json')).applications;const expectedApps=index.build.testFixture?modules.filter(m=>m.capabilities.some(c=>c.contractMajors.includes(1))):modules;assert.deepEqual(index.apps.map(a=>a.appId).sort(),expectedApps.map(m=>m.appId).sort(),'All compiled built-in applications');assert.equal(new Set(index.runtimes.map(r=>r.hash)).size,index.runtimes.length,'Unique runtime records');
  for(const a of index.adapters){assert.equal(a.path,`adapters/${a.agentId}/${a.version}/${a.hash}`);const {manifest}=fullTree(root,a.path,'bundle.json',a.hash);assert.equal(manifest.schema,'willyou-owned-bundle-v1');assert.equal(manifest.metadata.agentId,a.agentId);assert.equal(manifest.metadata.version,a.version);}
  for(const r of index.runtimes){assert.equal(r.path,`runtimes/${r.hash}`);const {manifest}=fullTree(root,r.path,'runtime.json',r.hash);assert.equal(manifest.schema,'smartdd-app-runtime-v1');assert.equal(manifest.id,r.id);assert.equal(manifest.protocolMajor,r.protocolMajor);assert.equal(manifest.bridgeEntry,r.bridgeEntry);assert(manifest.files.some(f=>f.path===r.bridgeEntry),'Complete runtime entry');}
  const apps=[];
  for(const a of index.apps){
    assert.equal(a.path,`apps/${a.appId}/${a.version}/${a.hash}`);const {manifest,dir}=fullTree(root,a.path,'manifest.json',a.hash);
    assert(['smartdd-app-package-v1','smartdd-app-package-v2'].includes(manifest.schema),'Supported package schema');assert.equal(manifest.appId,a.appId);assert.equal(manifest.version,a.version);assert.equal(manifest.dataApi,1);
    assert(index.runtimes.some(r=>r.id===manifest.runtime.id&&r.hash===manifest.runtime.hash&&r.protocolMajor===manifest.runtime.protocolMajor),'Original runtime dependency');
    const files=new Set(manifest.files.map(f=>f.path));for(const skill of manifest.skills)assert(files.has(skill.entry)&&skill.entry.startsWith(skill.path+'/')&&skill.entry.endsWith('/SKILL.md'),'Complete Skill entry');
    for(const contract of manifest.connectionContracts)assert(files.has(contract.inputSchemaPath),'Complete connection contract');
    let tools;
    if(manifest.schema==='smartdd-app-package-v1'){
      assert(files.has(manifest.adapter.entry),'Complete CJS adapter entry');assert(files.has('adapter/operations.json'),'Complete fixed operation table');
      const operations=readJson(join(dir,'adapter/operations.json'));assert.equal(operations.appId,a.appId);assert.equal(operations.version,a.version);assert.deepEqual(Object.keys(operations.operations).sort(),manifest.tools.map(t=>t.name).sort(),'Exact fixed tool routes');
      for(const tool of manifest.tools){const op=operations.operations[tool.name];assert(op.method.startsWith(a.appId+'.'),'Application-scoped Data API method');assert.equal(op.semantics==='read',tool.annotations.readOnlyHint,'Original read/write semantics');if(op.semantics==='write')assert.equal(op.retry,'never','Writes never use transport retries');}
      tools=manifest.tools;
    }else{
      const compiled=modules.find(m=>m.appId===a.appId);assert(compiled&&manifest.module.id===a.appId&&compiled.contractMajors.includes(manifest.module.contractMajor),'Compiled trusted module');
      assert(manifest.files.every(f=>!f.executable&&!/\.(?:[cm]?js|node|wasm|py|sh|exe|dll|dylib)$/i.test(f.path)),'V2 is data-only');
      assert.equal(new Set(manifest.capabilities.map(c=>c.id)).size,manifest.capabilities.length,'Unique capabilities');tools=[];
      for(const capability of manifest.capabilities){
        const policy=compiled.capabilities.find(c=>c.id===capability.id&&c.contractMajors.includes(capability.contractMajor));assert(policy,'Compiled capability contract');
        for(const key of ['semantics','permission','retry','slots','protection','approval'])assert.equal(canonical(capability[key]??null),canonical(policy[key]??null),'Trusted capability '+key);
        assert(files.has(capability.inputSchemaPath)&&files.has(capability.outputSchemaPath),'Complete capability contracts');
        assert.equal(!!capability.binding.mcp+!!capability.binding.cli,1,'One primary capability entry');
        if(capability.semantics!=='read'){assert(capability.protection&&capability.retry==='never'&&!capability.binding.fallback,'Protected writes have one entry');}
        const binding=capability.binding.mcp??capability.binding.fallback?.mcp;if(binding)tools.push({...capability,name:binding.tool});
      }
    }
    for(const tool of tools){assert(Buffer.byteLength('mcp__wy_'+'0'.repeat(24)+'__'+tool.name)<=64,'Portable built-in native tool-name budget');assert(files.has(tool.inputSchemaPath)&&files.has(tool.outputSchemaPath),'Complete tool contracts');assert.equal(readJson(join(dir,tool.inputSchemaPath)).type,'object');assert.equal(readJson(join(dir,tool.outputSchemaPath)).type,'object');assert(manifest.permissions.includes(tool.permission),'Declared original permission');}
    apps.push({appId:a.appId,version:a.version,hash:a.hash,skills:manifest.skills.length,tools:tools.length,files:manifest.files.length});
  }
  return {indexHash,resourceSetHash:index.build.resourceSetHash,adapters:index.adapters.length,runtimes:index.runtimes.length,apps};
}
module.exports={verifyCapabilityBundles};
if(require.main===module)process.stdout.write(JSON.stringify(verifyCapabilityBundles(process.argv[2],process.argv[3]))+'\n');
