import { applicationChildEnvironment } from './launch-env';
import { AgentTransferService } from './core/ai/agent-transfer';
import {BrowserService} from './core/browser/service';
import {installBrowserProjectDefaults} from './core/applications/browser-project-defaults';
import {pluginHostReadOnlyRoots} from './core/applications/plugins/host-paths';
import {existsSync,readFileSync} from 'node:fs';
import { voiceErrorsZh, voiceErrorsEn } from '@shared/voice-errors';
import { join } from 'node:path';
import { app, BrowserWindow, dialog, ipcMain, globalShortcut, Notification, shell } from 'electron';
import {
  aiProfilesChangedEvent,
  applicationsChangedEvent,
  browserChangedEvent,
  browserAccessChangedEvent,
  browserShortcutEvent,
  menuOpenSettingsEvent,
  menuToggleLeftSidebarEvent,
  ptyDataEvent,
  ptyExitEvent,
  tasksChangedEvent,
  voiceStatusChangedEvent,
  voiceGlobalErrorEvent,
  fileCloseEvent,
} from '@shared/events';
import { createEventEmitter } from '@shared/ipc/events';
import { registerRPCRouter, rpcErrorMessage } from '@shared/ipc/rpc';
import { buildAppMenu } from './app/menu';
import { appIcon } from './app/icon';
import { applyNativeTheme, createMainWindow, getMainWindow, isMainRenderer, markAppQuitting } from './app/window';
import { AiProfileService } from './core/ai/ai-profile-service';
import { AgentService } from './core/ai/agent-service';
import { ProviderService } from './core/ai/provider-service';
import { AgentRuntimeService } from './core/ai/agent-runtime';
import { AgentToolService } from './core/ai/agent-tools';
import { migrateAgentProfiles } from './core/ai/agent-migration';
import { ProfileHealth } from './core/ai/profile-health';
import { CapabilityService } from './core/capabilities/capability-service';
import { CapabilityRegistryService } from './core/capabilities/capability-registry';
import { McpProjectionService } from './core/capabilities/mcp-projection';
import { capabilityScanContexts } from './core/capabilities/scan-contexts';
import { managedSourceProfiles } from './core/capabilities/managed-source-profiles';
import { SkillProjectionService } from './core/capabilities/skill-projection';
import { ResourceStore } from './core/applications/resource-store';
import {MacProcessIdentityReader} from './core/applications/process-identity';
import {CodexInitializationCoordinator} from './core/applications/codex-initialization';
import { AgentSupportService } from './core/applications/agent-support-service';
import { ApplicationService } from './core/applications/application-service';
import { ManagedTaskCapabilities } from './core/applications/task-capability-launcher';
import { ProjectService } from './core/projects/project-service';
import { SettingsStore } from './core/settings/settings-service';
import { TaskService } from './core/tasks/task-service';
import { openDbClient, type DbClient } from './db/client';
import { runBundledMigrations } from './db/migrations';
import { openManagedDatabase } from './db/managed-client';
import { recoverBuiltinActivation,activateBuiltinDistribution,builtinActivationRequired } from './core/applications/activation-startup';
import { runProbes } from './probes';
import { PtyManager } from './pty-manager';
import { PtyAccess, registerPtyInput } from './pty-access';
import { createRpcRouter } from './rpc';
import { randomUUID as agentInstanceId } from 'node:crypto';
import { createAgentWorkspace } from './core/agent/wiring';
import { agentTaskEvent, agentTaskLiveEvent } from '@shared/events';
import { safeStorageCipher } from './safe-storage-cipher';
import { SecretsStore } from './secrets';
import { VoiceService } from './core/voice/voice-service';
import { TypelessAdapter } from './core/voice/typeless-adapter';
import { configureAppIdentity } from './app/identity';
import { ProjectTransferService } from './core/projects/transfer-service';
import { NativeFileBroker } from './core/files/native-broker';
import { FileSourceResolver } from './core/files/sources';
import { FileRootsService } from './core/files/roots';
import { FileRecoveryStore } from './core/files/recovery-store';
import { FileService } from './core/files/file-service';
import type { FileCloseRequest } from '@shared/files';
import { FileDiagramRenderer } from './core/files/diagram-renderer';
import { installMediaProtocol, installViewerAssets, registerViewerAssetScheme } from './core/files/viewer-assets';

// A supported Electron Node launch executes the requested CJS without loading
// this browser entry. Reaching it with Node intent means the fuse ignored that
// intent; refuse before opening user data or a second normal App.
const embeddedNodeModeRejected = process.env.ELECTRON_RUN_AS_NODE === '1';
if (embeddedNodeModeRejected) {
  process.stderr.write('WillYou application bridge unavailable: HOST_INCOMPATIBLE\n');
  app.exit(1);
} else {
  // Preserve both the existing data root and Electron's safeStorage identity.
  configureAppIdentity(app, process.env.SMARTDD_USER_DATA);
  registerViewerAssetScheme();
}

const isProbeMode = process.env.SMARTDD_PROBE === '1';

function baseEnv(): Record<string, string> {
  return applicationChildEnvironment(process.env);
}

const events = createEventEmitter({
  emit: (channel, data) => {
    getMainWindow()?.webContents.send(channel, data);
  },
  on: (channel, cb) => {
    const listener = (_e: Electron.IpcMainEvent, data: unknown) => cb(data);
    ipcMain.on(channel, listener);
    return () => ipcMain.off(channel, listener);
  },
});

/** A database we cannot migrate is fatal: running on a half-known schema risks the data. */
function openDatabase(dbFile: string): DbClient {
  const client = openDbClient(dbFile);
  try {
    const applied = runBundledMigrations(client.sqlite);
    if (applied.length) console.log(`[db] applied migrations: ${applied.join(', ')}`);
    return client;
  } catch (e) {
    client.close();
    throw new Error(`数据库迁移失败（${dbFile}）：${rpcErrorMessage(e)}`);
  }
}

async function main(): Promise<void> {
  await app.whenReady();
  installViewerAssets(join(app.getAppPath(), 'out/renderer/pdf-assets'));
  // Publish our own Chromium AX tree before first focus. This does not grant
  // macOS Accessibility permission; it lets the voice bridge see empty inputs
  // without waiting for an external screen reader to activate the tree.
  if (process.platform === 'darwin') app.setAccessibilitySupportEnabled(true);
  // Packaged macOS apps use the bundle's ICNS; dev runs otherwise show Electron's icon.
  if (!app.isPackaged) app.dock?.setIcon(appIcon);
  const dbFile = join(app.getPath('userData'), 'smartdd.db');
  let client: DbClient;
  try {
    client = process.platform === 'darwin' ? await openManagedDatabase(dbFile,{processes:new MacProcessIdentityReader(app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity')),activationRequired:store=>{try{return builtinActivationRequired(store,app.isPackaged?join(process.resourcesPath,'capability-bundles'):join(app.getAppPath(),'out/capability-bundles'));}catch{console.warn('[applications] Distribution upgrade preflight unavailable');return false;}},activate:(store,lease)=>activateBuiltinDistribution(store,lease,app.isPackaged?join(process.resourcesPath,'capability-bundles'):join(app.getAppPath(),'out/capability-bundles')),recoverActivation:(store,lease,id)=>recoverBuiltinActivation(store,lease,id,app.isPackaged?join(process.resourcesPath,'capability-bundles'):join(app.getAppPath(),'out/capability-bundles'))}) : openDatabase(dbFile);
  } catch (e) {
    const message = rpcErrorMessage(e);
    if (isProbeMode) process.stderr.write(`${message}\n`);
    else dialog.showErrorBox('WillYou 无法启动', message);
    app.exit(1);
    return;
  }

  if (isProbeMode) {
    const results = await runProbes(client, dbFile, baseEnv());
    process.stdout.write(`${JSON.stringify({ app: app.getVersion(), electron: process.versions.electron, results }, null, 2)}\n`);
    client.close();
    app.exit(results.every((r) => r.ok) ? 0 : 1);
    return;
  }

  const settings = new SettingsStore(client.db);
  const secrets = new SecretsStore(client.db, safeStorageCipher);
  const projects = new ProjectService(client.db, secrets, Date.now, () => projectTransfer.keys.cleanup());
  const aiProfiles = new AiProfileService(client.db, secrets);
  try { migrateAgentProfiles(client.db); }
  catch {
    dialog.showErrorBox('WillYou 无法启动', '智能体配置迁移失败，原配置已保留。请检查数据库后重试。');
    client.close(); app.exit(1); return;
  }
  const agents = new AgentService(client.db, secrets);
  const providers = new ProviderService(client.db, secrets, agents);
  const agentTransfer = new AgentTransferService(client.db,secrets,agents,providers);
  const agentTools = new AgentToolService(agents, { env: baseEnv });
  void agentTools.refresh().catch(() => console.warn('[agents] Tool detection incomplete; retry from agent settings'));
  const projectTransfer = new ProjectTransferService({ db: client.db, secrets, projects, profiles: aiProfiles, userData: app.getPath('userData'), appVersion: app.getVersion(), env: baseEnv });
  try { projectTransfer.recover(); }
  catch { console.warn('[project-transfer] recovery pending: check managed-key storage before importing'); }
  const capabilities = new CapabilityService({ db: client.db, projects, secrets, userData: app.getPath('userData') });
  let applications:ApplicationService|undefined;
  const capabilityRegistry=new CapabilityRegistryService(client.db,()=>capabilityScanContexts(app.getPath('home'),baseEnv(),managedSourceProfiles(app.getPath('userData'),aiProfiles.list(),agents.configs(),agents.providers()),projects.listProjects().flatMap(p=>projects.getProject(p.id).dirs.map(dir=>dir.path))),()=>Date.now(),{revoke:id=>skillProjection.revoke(id),afterScan:()=>skillProjection.reconcileSources(),pluginSkills:()=>applications?.plugins?.catalog().flatMap(plugin=>{
    const stored=applications!.plugins!.lifecycle.packages.get(plugin.hash!);
    return stored.plugin.skills.map(skill=>({appId:plugin.appId,pluginName:plugin.displayName,id:skill.id,path:join(stored.directory,skill.path),version:plugin.version!,enabled:plugin.enabled}));
  })??[]});
  const skillProjection=new SkillProjectionService(client.db,capabilityRegistry);
  const mcpProjection:McpProjectionService=new McpProjectionService(capabilityRegistry,{userData:app.getPath('userData'),executable:process.execPath,profileEnvironment:(id):Record<string,string>=>agentRuns.sourceEnvironment(id)});
  const agentRuns:AgentRuntimeService=new AgentRuntimeService({db:client.db,agents,tools:agentTools,providers,profiles:aiProfiles,userData:app.getPath('userData'),baseEnv,permissionPreferences:()=>settings.get('agentPermissions'),skills:skillProjection,mcp:mcpProjection});
  const scanManagedCapabilities=()=>{try{capabilityRegistry.scan();}catch{console.warn('[capabilities] Static discovery incomplete; retry from skills');}};
  scanManagedCapabilities();
  let agentSupport: AgentSupportService | undefined;
  try {
    agentSupport = new AgentSupportService(new ResourceStore(client.sqlite,app.getPath('userData'),undefined,{processes:new MacProcessIdentityReader(app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity'))}),capabilities,app.isPackaged ? join(process.resourcesPath,'capability-bundles') : join(app.getAppPath(),'out/capability-bundles'));
    await agentSupport.initialize();
  } catch { console.warn('[applications] Local capability resources unavailable; ordinary task launch remains available'); }
  const health = new ProfileHealth({
    profiles: aiProfiles,
    baseEnv,
    onChanged: (change) => events.emit(aiProfilesChangedEvent, change),
  });
  const ptys = new PtyManager();
  ptys.on('exit',()=>queueMicrotask(scanManagedCapabilities));
  let browser:BrowserService|undefined;
  const browserOrphans=()=>{void browser?.reconcile().catch(()=>console.warn('[browser] orphan-page/profile cleanup pending'));};
  const agentProcesses=new MacProcessIdentityReader(app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity'));
  const agentWorkspace=createAgentWorkspace({sqlite:client.sqlite,agents,providers,userData:app.getPath('userData'),baseEnv,processes:agentProcesses,
    host:{instanceId:agentInstanceId(),pid:process.pid,startedAt:agentProcesses.read(process.pid)?.startedAt??null},emitEvent:e=>events.emit(agentTaskEvent,e),emitLive:e=>events.emit(agentTaskLiveEvent,e),ptys});
  const tasks = new TaskService({
    db: client.db,
    ptys,
    profiles: aiProfiles,
    agentRuns,
    projects,
    baseEnv,
    health,
    capabilities,
    codexInitialization:process.platform==='darwin'?new CodexInitializationCoordinator(app.getPath('userData'),new MacProcessIdentityReader(app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity'))):undefined,
    onChanged: () => {events.emit(tasksChangedEvent, undefined);browserOrphans();},
  });

  const fileBroker = new NativeFileBroker(app.isPackaged ? join(process.resourcesPath, 'native/willyou-files') : join(app.getAppPath(), 'out/native/willyou-files'));
  const fileSources = new FileSourceResolver(client.db);agentWorkspace.attachFiles(fileSources);
  const diagrams = new FileDiagramRenderer(join(app.getAppPath(), 'out/renderer'), process.env.ELECTRON_RENDERER_URL);
  const engineConfiguration = (engine: 'tex' | 'office' | 'libreoffice') => process.platform === 'darwin' ? { directory: app.isPackaged ? join(process.resourcesPath, 'native', engine) : join(app.getAppPath(), 'out/native', engine), userData: app.getPath('userData'), packagePath: app.isPackaged ? join(process.resourcesPath, '../..') : undefined } : undefined;
  const files = new FileService(new FileRootsService(fileSources, fileBroker), fileBroker, new FileRecoveryStore(fileBroker, app.getPath('userData'), fileSources), diagrams, { get: () => settings.get('fileOpener'), set: (value) => settings.update('fileOpener', value) }, engineConfiguration('tex'), engineConfiguration('office'), undefined, engineConfiguration('libreoffice'), undefined, undefined, { get: () => settings.get('fileViewers'), set: value => settings.update('fileViewers', value) }, { get: () => settings.get('fileLanguages'), set: value => settings.update('fileLanguages', value) });
  void files.tex.recover().catch((error) => console.warn('[files/tex] Temporary compilation cleanup pending:', error));
  void files.office.recover().catch((error) => console.warn('[files/office] Temporary calculation cleanup pending:', error));
  // Isolated acceptance may exercise the bounded binary branch with the same
  // packaged code. This changes transport only, never its file authorization.
  if (process.env.SMARTDD_USER_DATA && process.env.SMARTDD_M9_MEDIA_BINARY === '1') console.info('[files] Isolated media acceptance: binary transport');
  installMediaProtocol(files.media, files.resources, Boolean(process.env.SMARTDD_USER_DATA && process.env.SMARTDD_M9_MEDIA_BINARY === '1'));

  ptys.on('data', (ptyId: string, data: string) => events.emit(ptyDataEvent, { ptyId, data }));
  ptys.on('exit', (ptyId: string, code: number) => events.emit(ptyExitEvent, { ptyId, code }));
  const ptyAccess = new PtyAccess({
    trusted: isMainRenderer,
    activePty: (id) => tasks.activePty(id) ?? agentWorkspace.terminals?.activePty(id) ?? null,
    alive: (id) => ptys.has(id),
    write: (id, data) => ptys.write(id, data),
    resize: (id, cols, rows) => ptys.resize(id, cols, rows),
    killTask: (id) => { if (agentWorkspace.terminals?.activePty(id)) agentWorkspace.terminals.close(id); else tasks.kill(id); },
    observedInput:(event,target,data)=>applications?.observeInput(event,target,data),
  });
  registerPtyInput(ipcMain, ptyAccess);

  let managedTasks:ManagedTaskCapabilities|undefined;
  try {
    if(agentSupport){
      const browserRoot=app.isPackaged?join(process.resourcesPath,'agent-browser'):join(app.getAppPath(),'out/agent-browser');
      if(process.platform==='darwin'&&existsSync(join(browserRoot,'SOURCE.json'))){
        const source=JSON.parse(readFileSync(join(browserRoot,'SOURCE.json'),'utf8')),binary=source.files.find((file:{arch:string})=>file.arch===process.arch);
        if(binary)browser=new BrowserService({sqlite:agentSupport.store.sqlite,userData:app.getPath('userData'),helper:{executable:join(browserRoot,binary.path),sha256:binary.sha256,processes:new MacProcessIdentityReader(app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity'))},taskProject:id=>(agentSupport.store.sqlite.prepare('SELECT project_id FROM tasks WHERE id=?').get(id) as {project_id:string|null}|undefined)?.project_id??null,taskDirectory:id=>(agentSupport.store.sqlite.prepare('SELECT cwd FROM tasks WHERE id=?').get(id) as {cwd:string}|undefined)?.cwd??null,window:getMainWindow,changed:taskId=>events.emit(browserChangedEvent,{taskId}),accessChanged:()=>events.emit(browserAccessChangedEvent,{}),shortcut:(taskId,action)=>events.emit(browserShortcutEvent,{taskId,action})});
      }
      await browser?.reconcile();
      applications=new ApplicationService(agentSupport.store,{browser,openPluginUrl:url=>shell.openExternal(url),plugins:process.platform==='darwin'?{bundledZentao:app.isPackaged?join(process.resourcesPath,'plugins/zentao'):join(app.getAppPath(),'out/plugins/zentao'),runtime:{executable:process.execPath,readOnlyRoots:pluginHostReadOnlyRoots(app.getAppPath(),process.execPath),keychainRoots:[join(app.getPath('home'),'Library/Keychains'),'/Library/Keychains']}}:undefined,distributionRoot:app.isPackaged?join(process.resourcesPath,'capability-bundles'):join(app.getAppPath(),'out/capability-bundles'),secrets,projects,tasks,workspaceFiles:files,activePty:id=>tasks.activePty(id),terminal:{access:ptyAccess,bracketedPaste:id=>ptys.bracketedPaste(id),write:(id,data)=>ptys.writeControlled(id,data)},requireSender:event=>ptyAccess.requireSender(event),mailWorker:join(app.getAppPath(),'out/main/m10-mail-reader.js'),foxmailNative:app.isPackaged?join(process.resourcesPath,'native/willyou-foxmail'):join(app.getAppPath(),'out/native/willyou-foxmail'),changed:change=>{events.emit(applicationsChangedEvent,change);void agentWorkspace.requests.reconcile();if(change?.kind!=='plugin-runtime'&&change?.kind!=='plugin-approval')managedTasks?.syncSkillLibrary();}});

      await applications.recover();
      if(browser)installBrowserProjectDefaults(projects,applications.selections,()=>events.emit(applicationsChangedEvent,undefined));
      if(process.platform==='darwin'&&process.arch==='arm64'&&['ready','partial'].includes(agentSupport.status().state)){
        managedTasks=await ManagedTaskCapabilities.open(agentSupport,capabilities,applications,{helper:app.isPackaged?join(process.resourcesPath,'native/willyou-process-identity'):join(app.getAppPath(),'out/native/willyou-process-identity'),cliPath:app.isPackaged?join(process.resourcesPath,'native/willyou-app'):join(app.getAppPath(),'out/native/willyou-app'),skillLibraryHome:app.getPath('home'),cleanupUnattributable:app.isPackaged,stopPty:id=>ptys.kill(id)});
        tasks.attachManagedCapabilities(managedTasks);
        agentWorkspace.attachBusiness(managedTasks);if(browser)agentWorkspace.attachBrowser(browser);
      }
    }
  } catch {console.warn('[applications] Local business recovery pending; check application diagnostics');}

  const voice = new VoiceService({
    adapter: new TypelessAdapter(app.isPackaged ? join(process.resourcesPath, 'native/smartdd-voice') : join(app.getAppPath(), 'out/native/smartdd-voice')),
    settings: { get: () => settings.get('voice'), save: (value) => settings.update('voice', value) },
    shortcuts: globalShortcut,
    focused: () => Boolean(getMainWindow()?.isFocused()),
    ptyAlive: (id) => ptys.has(id),
    changed: () => events.emit(voiceStatusChangedEvent, undefined),
    globalError: (error) => {
      events.emit(voiceGlobalErrorEvent, error);
      if (getMainWindow()?.isFocused()) return;
      const chinese = settings.get('general').language === 'zh-CN';
      const notification = new Notification({ title: chinese ? 'WillYou 语音输入' : 'WillYou Voice Input', body: chinese ? voiceErrorsZh[error] : voiceErrorsEn[error] });
      notification.show();
    },
  });
  await voice.start();

  const showWindow = async () => {
    const win = getMainWindow() ?? (await createMainWindow());
    win.show();
    return win;
  };
  const rebuildMenu = () =>
    buildAppMenu(settings.get('general').language, {
      openSettings: () => void showWindow().then(() => events.emit(menuOpenSettingsEvent, undefined)),
      toggleLeftSidebar: () => events.emit(menuToggleLeftSidebarEvent, undefined),
    });

  registerRPCRouter(
    createRpcRouter({
      files,
      trustedRenderer: isMainRenderer,
      projectTransfer,
      voice,
      client,
      dbFile,
      settings,
      projects,
      aiProfiles,
      agents,
      agentTools,
      providers,
      agentTransfer,
      health,
      tasks,
      capabilities,
      capabilityRegistry,
      onCapabilityChanged:()=>managedTasks?.syncSkillLibrary(),
      agentSupport,
      applications,
      browser,
      agentWorkspace,
      onProjectDeleted:()=>{events.emit(tasksChangedEvent,undefined);browserOrphans();},
      onTaskProfilesChanged:()=>events.emit(tasksChangedEvent,undefined),
      ptys,
      ptyAccess,
      baseEnv,
      onSettingChanged: (key) => {
        if (key === 'theme') applyNativeTheme(settings.get('theme'));
        if (key === 'general') rebuildMenu();
      },
    }),
    ipcMain
  );

  applyNativeTheme(settings.get('theme'));
  rebuildMenu();
  await createMainWindow();

  app.on('activate', () => void showWindow());

  let quitConfirmed = false, quitPending = false;
  app.on('before-quit', (event) => {
    if (quitConfirmed) return;
    event.preventDefault();
    if (quitPending) return;
    // 新任务区正在工作或等待处理的任务也计入（复核 CR05）。
    const agentBusy = agentWorkspace.tasks.list().filter(t => t.status === 'working' || t.status === 'waiting').length;
    if (ptys.count > 0 || agentBusy > 0) {
      const choice = dialog.showMessageBoxSync({
        type: 'warning',
        buttons: ['退出', '取消'],
        defaultId: 1,
        cancelId: 1,
        message: `有 ${ptys.count + agentBusy} 个任务正在运行`,
        detail: '退出 WillYou 会结束这些终端进程。重新打开后可在侧栏中点任务恢复（resume）。',
      });
      if (choice !== 0) {
        return;
      }
    }
    quitPending = true;
    void (async () => {
      const win = getMainWindow();
      if (win) {
        const contents = win.webContents, frame = contents.mainFrame;
        const owner = `${contents.id}:${frame.processId}:${frame.routingId}`;
        const send = (request: FileCloseRequest) => {
          if (contents.isDestroyed() || contents.mainFrame !== frame) throw new Error('原文件界面已经关闭');
          contents.send(fileCloseEvent.name, request);
        };
        const resume = () => { try { send({ id: '', action: 'resume' }); } catch { /* Original renderer is gone. */ } };
        let reply = await files.closer.request(owner, 'save', send);
        if (!reply.ready) {
          const choice = await dialog.showMessageBox(win, {
            type: 'warning', buttons: ['继续查看', '放弃修改并退出'], defaultId: 0, cancelId: 0,
            message: '部分文件尚未保存',
            detail: `${reply.failures.slice(0, 8).map((failure) => `${failure.name}\n${failure.message}`).join('\n\n')}\n\n放弃只结束当前编辑；存在版本冲突的恢复材料会保留。`,
          });
          if (choice.response !== 1) { resume(); return; }
          reply = await files.closer.request(owner, 'discard', send);
          if (!reply.ready) {
            await dialog.showMessageBox(win, { type: 'warning', buttons: ['继续查看'], message: '未能确认放弃修改', detail: reply.failures.slice(0, 8).map((failure) => failure.message).join('\n') });
            resume(); return;
          }
        }
        // Await the renderer's unload permission, too. Sending without an ack
        // can race Chromium's beforeunload and strand a confirmed quit.
        const commit = await files.closer.request(owner, 'commit', send);
        if (!commit.ready) { resume(); return; }
      }
      // 退出已确认（含未保存文件的选择）后，才关闭新任务的 Agent 运行与手动终端，并等其收口再关数据库（复核 CR05）。
      await agentWorkspace.closeAll().catch(() => {});
      tasks.dispose();
      ptys.killAll();
      // Keep read-only native evidence and storage available until owned run
      // shutdown has drained. Revocation itself still happens immediately.
      try { await managedTasks?.dispose(); } finally { await applications?.dispose(); }
      quitConfirmed = true; markAppQuitting(); app.quit();
    })().catch((error) => {
      const win = getMainWindow();
      if (win) win.webContents.send(fileCloseEvent.name, { id: '', action: 'resume' });
      dialog.showErrorBox('文件保存确认未完成', rpcErrorMessage(error));
    }).finally(() => { quitPending = false; });
  });
  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
  app.on('will-quit', () => {
    files.tex.dispose();
    files.office.dispose();
    files.pptx.dispose();
    files.officePages.dispose();
    diagrams.dispose();
    files.searcher.dispose();
    void files.watcher.dispose();
    fileBroker.dispose();
    projectTransfer.disposeAll();
    voice.dispose();
    tasks.dispose();
    ptys.killAll();
    capabilities.dispose();
    client.close();
  });
}

if (!embeddedNodeModeRejected) main().catch((e) => {
  console.error(e);
  app.exit(1);
});
