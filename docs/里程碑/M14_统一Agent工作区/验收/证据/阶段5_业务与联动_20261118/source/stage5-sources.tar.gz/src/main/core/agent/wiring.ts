import { realpathSync } from 'node:fs';
import { attachAgentBrowserRequests } from './business-browser';
import { HostBusinessRequests } from './host-business-requests';
import { MessageLinks } from './message-links';
import type { SourceResolver } from '../files/roots';
import { TurnDiffs } from './turn-diffs';
// M14 统一 Agent 工作区的主进程装配：配置档案解析、本机程序发现、托管文件落盘与事件推送。
import { randomUUID } from 'node:crypto';
import { join } from 'node:path';
import type BetterSqlite3 from 'better-sqlite3';
import { codeAgentKindSchema } from '@shared/ai-agents';
import type { AgentService } from '../ai/agent-service';
import type { ProviderService } from '../ai/provider-service';
import type { ProcessIdentityReader } from '../applications/process-identity';
import { materializeAgentPlan } from '../ai/agent-launch-files';
import { AgentStore, sha256, type StoredEvent } from './agent-store';
import { AgentRunService, type LiveListener } from './agent-run-service';
import { AgentTaskService, boundedEvent, type LaunchResolver } from './agent-task-service';
import { probeAndRecord } from './discovery';
import { resolveProfileLaunch } from './profile-launch';
import { DRIVERS } from './registry';
import type { DriverId } from './capabilities';
import { DriverError } from './driver';
import { tiersFor } from './permissions';
import { AgentManualTerminals } from './manual-terminal';
import { canonicalPath } from './identity';
import { homedir } from 'node:os';
import type { ManagedTaskCapabilities } from '../applications/task-capability-launcher';
import { DelegationService } from './delegation-service';
import { runWorkspaceCommand, GitWorkspaces } from './git-workspaces';
import { ownedWorkspaceCommand } from './owned-command';


export interface AgentWorkspaceDeps {
  sqlite: BetterSqlite3.Database;
  agents: AgentService;
  providers: ProviderService;
  userData: string;
  baseEnv(): Record<string, string>;
  processes: ProcessIdentityReader;
  host: { instanceId: string; pid: number; startedAt: string | null };
  emitEvent(e: StoredEvent): void;
  emitLive(e: { taskId: string; runId: string; itemKey: string; text: string }): void;
  ptys?: import('./manual-terminal').TerminalPtys;
}

export function driverForKind(kind: string): DriverId {
  const k = codeAgentKindSchema.safeParse(kind);
  if (!k.success) throw new DriverError('UNSUPPORTED', `暂不支持的执行器：${kind}`);
  return k.data === 'codex' ? 'codex-app-server' : 'claude-sdk';
}

export function createAgentWorkspace(d: AgentWorkspaceDeps) {
  let business: ManagedTaskCapabilities | undefined;
  // 超限正文转 artifact（技术方案 §3.1，复核 U01），与附件副本同在用户数据目录。
  const store = new AgentStore(d.sqlite, { artifactDir: join(d.userData, 'agent-artifacts') });
  // 上一宿主留下的运行：先收口，再按准确出生身份结束仍在运行的原生进程（取不到身份则不动）。
  for (const r of store.recoverOrphanRuns(d.host.instanceId)) {
    if (r.pid && r.processStartedAt && d.processes.state({ pid: r.pid, startedAt: r.processStartedAt }) === 'running') { try { process.kill(r.pid, 'SIGTERM'); } catch { /* 已退出 */ } }
  }
  const runs = new AgentRunService({ store, drivers: DRIVERS, processes: d.processes, host: d.host });
  const config = (profileId: string) => {
    const c = d.agents.configs().find(x => x.id === profileId);
    if (!c) throw new DriverError('REJECTED', '智能体已删除，请重新选择');
    if (c.source === 'legacy') throw new DriverError('UNSUPPORTED', '旧配置不能用于新任务，请另选智能体');
    return c;
  };
  const resolveLaunch: LaunchResolver = async ({ taskId, profileId, cwd, model, carryExtensions }) => {
    const c = config(profileId);
    const tool = d.agents.tools().find(t => t.id === c.toolId);
    if (!tool) throw new DriverError('REJECTED', 'Code Agent 已删除，请重新检测');
    const provider = c.providerId ? d.agents.providers().find(p => p.id === c.providerId) : undefined;
    const kind = codeAgentKindSchema.parse(c.kind);
    const connection = provider ? d.providers.runtimeConnection(provider.id, kind) : undefined;
    const base = d.baseEnv();
    const input = { config: c, tool, provider, key: connection?.target.key, cwd, userData: d.userData, runId: randomUUID(), baseEnv: base, model, carryExtensions };
    let launch = resolveProfileLaunch(input);
    const old = taskId ? store.bindingLaunch(taskId, profileId) : undefined;
    const withoutExtensions = (x: Record<string, unknown>) => Object.fromEntries(Object.entries(x).filter(([k]) => k !== 'extensions'));
    if (old && old.frozen.cwd === canonicalPath(cwd) && old.frozen.stateRoot === canonicalPath(launch.stateRoot) && JSON.stringify(withoutExtensions(old.frozen.compatibility)) === JSON.stringify(withoutExtensions(launch.compatibility))) {
      launch = resolveProfileLaunch({ ...input, carryExtensions: old.frozen.compatibility.extensions !== false });
    }
    const probe = await probeAndRecord(store, launch.driverId, { env: base, executable: launch.command });
    if (probe.state === 'unsupported' || !probe.realpath || !probe.version) throw new DriverError('UNSUPPORTED', probe.missing ? `${probe.reason}。${probe.missing.hint}` : probe.reason ?? '执行器不可用');
    connection?.assertCurrent();
    const expectedConfig = JSON.stringify({ kind: c.kind, source: c.source, providerId: c.providerId, toolId: c.toolId, models: c.models, defaultModel: c.defaultModel });
    const expectedCwd = canonicalPath(cwd), expectedStateRoot = canonicalPath(launch.stateRoot);
    const assertCurrent = () => {
      connection?.assertCurrent();
      if (canonicalPath(cwd) !== expectedCwd || canonicalPath(launch.stateRoot) !== expectedStateRoot) throw new DriverError('REJECTED', '工作目录或配置根的物理身份已变化，请重新选择');
      const current = config(profileId);
      if (JSON.stringify({ kind: current.kind, source: current.source, providerId: current.providerId, toolId: current.toolId, models: current.models, defaultModel: current.defaultModel }) !== expectedConfig) throw new DriverError('REJECTED', '配置已变化，原选择预检失效，请重新选择或发送');
    };
    assertCurrent();
    materializeAgentPlan(launch.plan, d.userData, cwd);
    const env = probe.shellPath ? { ...launch.env, PATH: probe.shellPath } : launch.env;
    return { driverId: launch.driverId, executable: { path: probe.realpath, version: probe.version }, env, stateRoot: launch.stateRoot, compatibility: launch.compatibility, model: launch.model, extraArgs: launch.extraArgs, settingSources: launch.settingSources, capabilities: probe.capabilities, assertCurrent,
      integrate: async context => {
        if (!business || !taskId || probe.capabilities.mcp.state !== 'enabled') return undefined;
        const task = store.task(taskId); if (!task?.project_id) return undefined;
        assertCurrent();
        const actual = resolveProfileLaunch({ ...input, runId: context.runId, carryExtensions: launch.compatibility.extensions !== false });
        materializeAgentPlan(actual.plan, d.userData, cwd);
        if(!business.supportsAgentDelivery(actual.plan.profile.runner,probe.version!)){store.addHostItem(taskId,null,'system_notice',{code:'businessCapabilitiesUnverified',detail:'当前执行器版本的业务 Skill／MCP／CLI 交付尚未验证；本轮保留对话与代码能力，不注入未经验证的业务通道。'});return undefined;}
        const result = await business.prepareAgent({ ...context, version: probe.version!, assertCurrent, task: { projectId: task.project_id, taskId, profile: { ...actual.plan.profile, command: probe.realpath! }, cwd, home: base.HOME ?? homedir(), stateRoot: actual.stateRoot, claudeConfigExplicit: true, mode: context.nativeId ? 'resume' : 'new', sessionId: context.nativeId ?? null, previous: null, newTask: !context.nativeId, signal: new AbortController().signal, environment: { ...actual.env, ...(probe.shellPath ? { PATH: probe.shellPath } : {}) } } });
        return { ...result, env: { ...actual.env, ...result.env }, extraArgs: [...actual.extraArgs, ...(result.extraArgs ?? [])] };
      },
    };
  };
  const tasks = new AgentTaskService({ store, runs, resolveLaunch, profileDriver: id => driverForKind(config(id).kind), profileName: id => d.agents.configs().find(c => c.id === id)?.name ?? '已删除的配置', userData: d.userData });
  const ownedCommand = ownedWorkspaceCommand({processes:d.processes,env:d.baseEnv,blocked:(options,_proof,detail)=>{if(options.taskId)store.addHostItem(options.taskId,null,'system_notice',{code:'host_job_drain_unknown',detail});}});
  const git = new GitWorkspaces({ store, command:(cwd,command,args,timeout,options)=>options?ownedCommand(cwd,command,args,timeout,options):runWorkspaceCommand(cwd,command,args,timeout), home: d.baseEnv().HOME ?? homedir(), recoverySafe: async taskId => {
    const rows = store.sqlite.prepare('SELECT run_id,state,pid FROM capability_runs WHERE task_id=?').all(taskId) as { run_id: string; state: string; pid: number | null }[];
    for (const r of rows) {
      if (!['stopped', 'failed'].includes(r.state) || r.pid && !await runs.drainNativeGroup(r.run_id)) return false;
      if (store.sqlite.prepare("SELECT 1 FROM capability_run_processes WHERE run_id=? AND state NOT IN ('exited','canceled')").get(r.run_id) || store.sqlite.prepare("SELECT 1 FROM capability_run_activities WHERE run_id=? AND state='active'").get(r.run_id)) return false;
    }
    return true;
  } });
  const delegationProfile = (id: string) => { const c = config(id), provider = c.providerId ? d.agents.providers().find(p => p.id === c.providerId) : undefined; return { profileId: id, driverId: driverForKind(c.kind), name: c.name, models: c.models, available: c.available, trustedRead: c.kind === 'codex' && c.source === 'provider', revision: sha256(JSON.stringify({ config: c, providerRevision: provider?.identityRevision })) }; };
  const delegations = new DelegationService({ store, runs, tasks, git, profile: delegationProfile, profiles: () => d.agents.configs().filter(c => c.source !== 'legacy' && c.available).map(c => delegationProfile(c.id)),
    roots: taskId => { const w = git.workspace(taskId); if (w?.state === 'ready') return [w.path]; const roots = (store.sqlite.prepare('SELECT path FROM project_dirs').all() as { path: string }[]).map(r => r.path); const task = store.task(taskId); return task?.project_id ? roots : task ? [task.cwd] : []; },
    project: id => id ? (store.sqlite.prepare('SELECT id,name FROM projects WHERE id=?').get(id) as { id: string; name: string } | undefined) ?? { id, name: 'project' } : { id: 'unscoped', name: 'project' },
    drained: async runId => { if (!await runs.drainNativeGroup(runId)) return false; if (store.run(runId)?.state === 'orphaned') await business?.recoverAgentRun(runId); const processes = store.sqlite.prepare("SELECT 1 FROM capability_run_processes WHERE run_id=? AND state NOT IN ('exited','canceled')").get(runId); const activities = store.sqlite.prepare("SELECT 1 FROM capability_run_activities WHERE run_id=? AND state='active'").get(runId); return !processes && !activities; },
  });
  const requests = new HostBusinessRequests({store,run:taskId=>runs.runForTask(taskId),hasOwner:taskId=>!!runs.runForTask(taskId)||!!runs.closingForTask(taskId),notify:(taskId,id,text,wake)=>tasks.enqueueHost(taskId,id,text,'notification',wake),acquire:(taskId,_operation,signal)=>delegations.acquireBusiness(taskId,signal)});tasks.attachBusiness(requests);
  const diffs=new TurnDiffs({store,storage:join(d.userData,'agent-diffs'),excluded:[d.userData,join(d.baseEnv().HOME??homedir(),'.willyou')],stable:(taskId,turnId)=>{const run=runs.runForTask(taskId);return !delegations.businessBusy(taskId)&&(!run||!runs.busy(run.runId)&&!runs.nativeBusy(run.runId))&&!store.sqlite.prepare("SELECT 1 FROM agent_turns WHERE task_id=? AND turn_id<>? AND status IN ('dispatching','started')").get(taskId,turnId);},changed:taskId=>store.tx(emit=>emit(taskId,'diff.changed',{}))});tasks.attachDiffs(diffs,taskId=>{const run=runs.runForTask(taskId);return delegations.businessBusy(taskId)||!!run&&runs.nativeBusy(run.runId);});
  let links:MessageLinks|undefined;
  void git.recoverIntents().catch(() => { /* explicit needs_review records retain ownership */ });
  store.subscribe((e: StoredEvent) => d.emitEvent(boundedEvent(e)));
  const live: LiveListener = ({ taskId, runId, event }) => { if (event.type === 'message.delta') d.emitLive({ taskId, runId, itemKey: event.nativeItemId, text: event.text }); };
  runs.onLive(live);
  /** 首页与任务页的智能体列表：只列可用于新任务的配置，带执行器与可选档位。 */
  const profiles = () => d.agents.configs().filter(c => c.source !== 'legacy' && codeAgentKindSchema.safeParse(c.kind).success).map(c => {
    const driverId = driverForKind(c.kind);
    return { profileId: c.id, name: c.name, kind: c.kind, driverId, source: c.source, models: c.models, defaultModel: c.defaultModel, available: c.available, isDefault: c.isDefault, tiers: tiersFor(driverId), extensionSupport: driverId === 'codex-app-server' ? 'partial' as const : 'full' as const };
  });
  const terminals = d.ptys ? new AgentManualTerminals({ ptys: d.ptys, baseEnv: d.baseEnv, taskCwd: id => { const t = store.task(id); if (!t || t.archived_at) throw new DriverError('REJECTED', '任务不存在或已归档'); return t.cwd; } }) : undefined;
  return { store, runs, tasks, profiles, terminals, git, delegations, requests, diffs,applicationReference:(sender:import('../applications/execution-context').ApplicationUiSender,taskId:string,source:import('@shared/application-terminal').ApplicationTerminalSource)=>{if(!business)throw new Error('业务服务不可用');return business.agentReference(sender,taskId,source);},plugins:(taskId:string)=>{if(!store.task(taskId))throw new Error('任务不存在');return business?.taskPlugins(taskId)??[];}, openHomeTerminal:(projectId:string,dirId:string,size?:{cols:number;rows:number})=>{if(!terminals)throw new Error('终端不可用');const dir=store.sqlite.prepare('SELECT d.path FROM project_dirs d JOIN projects p ON p.id=d.project_id WHERE d.id=? AND p.id=? AND p.archived_at IS NULL').get(dirId,projectId) as {path:string}|undefined;if(!dir)throw new Error('首页目录没有登记在当前项目');const cwd=realpathSync(dir.path),terminalKey='home-shell-'+sha256(projectId+dirId+cwd).slice(0,32);return{...terminals.openAt(terminalKey,cwd,size),terminalKey};}, get links(){return links;}, attachBrowser:(browser:import('../browser/service').BrowserService)=>attachAgentBrowserRequests({store,requests,browser,context:runId=>{if(!business)throw new Error('应用运行通道不可用');return business.agentContext(runId);},enabled:taskId=>{if(!business)throw new Error('应用通道不可用');business.assertAgentApplication(taskId,'browser');}}), attachFiles:(sources:SourceResolver)=>{links=new MessageLinks(store,sources,d.baseEnv().HOME??homedir());}, attachBusiness: (value: ManagedTaskCapabilities) => { business = value;tasks.attachHumanRecorder((runId,sender,text,sequence)=>value.recordAgentHumanInput(runId,sender,text,sequence)); value.attachAgentTools(delegations);value.attachAgentRequests(store,requests,(taskId,id,text)=>tasks.enqueueHost(taskId,id,text,'notification',true)); }, closeAll: async () => { await requests.close(); await delegations.close(); terminals?.closeAll(); await runs.closeAll(); await diffs.close(); } };
}
export type AgentWorkspace = ReturnType<typeof createAgentWorkspace>;
