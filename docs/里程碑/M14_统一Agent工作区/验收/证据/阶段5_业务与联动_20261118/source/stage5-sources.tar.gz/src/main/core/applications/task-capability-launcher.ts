import { AgentBusinessTools } from './agent-business-tools';
import {SkillObservationMonitor} from './skill-observation-monitor';
import {BridgeSupervisor} from './bridge-supervisor';
import {nativeCapabilityPreparation} from './native-preparation-diagnostics';
import {nativeCapabilityConflicts} from './native-application-conflicts';
import {withCoordinatorLock} from './coordinator-lock';
import {withResourceLock} from './resource-lock';
import {ensureStoreDirectory} from './package-files';
import {assertNoPendingApplicationSwitch} from './application-run-policy';
import type {ManagedCapabilityRestriction} from './launch-restriction';
import { mkdirSync, writeFileSync,readFileSync } from 'node:fs';
import { delimiter,dirname, join } from 'node:path';
import { ApplicationError } from '@shared/applications';
import { applicationMcpServerName, type CapabilitySessionSnapshot } from '@shared/application-session';
import type { RuntimeSnapshot } from '@shared/capabilities';
import { CapabilityService, MCP_CAPABILITY, type PreparedRuntime } from '../capabilities/capability-service';
import { projectCapabilityEnabled, type ProjectCapabilitySetting } from '../projects/project-capability-setting';
import type { TaskCapabilityLaunch, TaskCapabilityLauncher } from '../tasks/capability-lifecycle';
import type { AgentSupportService } from './agent-support-service';
import type { ApplicationService } from './application-service';
import type { ResourceRecord } from './resource-store';
import { CapabilitySessionRegistry, canonicalFuturePath, type StoredCapabilitySession } from './session-registry';
import { CapabilityRunRegistry, type RunBindingRevision, type OwnedCapabilityRun } from './run-registry';
import { ApplicationAdapterRegistry } from './application-adapter-registry';
import { ApplicationToolService } from './tool-service';
import { PrivateApplicationBroker } from './private-broker';
import {ApplicationCliGateway} from './cli-gateway';
import {CurrentApplicationAuthorization} from './current-authorization';
import {SkillLibraryService} from './skill-library-service';
import {cleanupPreLibraryCopies} from './legacy-copy-cleanup';
import {retirePreLibraryResources,type PreLibraryRetirement} from './retire-pre-library-resources';
import {codexProfileArgsForCli} from './codex-effective-sandbox';
import type {CliSandboxPlan} from './capability-delivery-adapters';
import {verifyClaudeCliSandbox} from './claude-effective-sandbox';
import {verifyCodexCliSandbox} from './codex-effective-sandbox';
import {createApplicationRunPlan,selectCapabilityEntry,type RunPlanAvailability} from './run-plan';

import { AgentBridgeProcesses } from './agent-bridge-processes';
import {RunBackendAuthority} from './run-backend-authority';
import { MacProcessIdentityReader, type ProcessIdentityReader } from './process-identity';
import { MacUnixPeerIdentityReader, type UnixPeerIdentityReader } from './unix-peer-identity';
import { inspectNativeLaunch, type NativeLaunchContext, type TaskLaunchInput } from './native-launch-context';
import { canonicalJson, digest } from './manifest';
import {legacyRuntimeMetadata} from './legacy-task-evidence';
import {EmbeddedNodeRuntime} from './embedded-node-runtime';
import {builtinApplicationModules} from './modules';
import {FrozenPluginSkills,type FrozenPluginSkillSet} from './plugins/frozen-skills';
import {prepareCodexTaskServer,type CodexTaskServerRequest,type PrivateCodexTaskServer} from './codex-task-server';
import {codexClientArgs} from './codex-client-args';
import type { AgentHostTools } from './agent-host-tools';
import type { RunIntegration } from '../agent/run-integration';
import type { DriverOpenOptions } from '../agent/driver';
import { RuntimeRegistry } from './runtime-registry';
import { verifyPackageTree } from './package-files';
import type { BridgeResponse } from '@shared/application-bridge';
/** Resource kinds only pre-R1.0 launches used (shared discovery, per-session projections, Claude plugin, M4 originals). */
const RETIRED_RESOURCE_KINDS:ReadonlySet<string>=new Set(['session-projection','claude-projection-source','claude-projection-archive','claude-delivery','agent-projection','legacy-agent-projection','legacy-static-plugin','legacy-plugin-source']);
interface ActiveLaunch {run:OwnedCapabilityRun;runtime?:PreparedRuntime;codex?:PrivateCodexTaskServer;releasing?:Promise<void>}
export interface TaskCapabilityLauncherOptions {
  helper: string;
  cliPath?:string;
  inspectSandbox?:(input:TaskLaunchInput,native:NativeLaunchContext)=>Promise<CliSandboxPlan>;
  stopPty(ptyId:string):void;
  processes?:ProcessIdentityReader;
  peers?:UnixPeerIdentityReader;
  inspectNative?:(input:TaskLaunchInput)=>Promise<NativeLaunchContext>;
  probeApplicationRuntime?:(signal:AbortSignal)=>Promise<boolean>;
  /** Host-only dependency for isolated software tests; no RPC/config surface. */
  prepareCodexServer?:(request:CodexTaskServerRequest)=>Promise<PrivateCodexTaskServer>;
  pollMs?:number;
  /** R16: HOME whose `.agents/skills` (and each Agent's link directory) holds the single WillYou Skill library. Omitted: no library delivery. */
  skillLibraryHome?:string;
  /** Packaged App only: also remove pre-R1.0 copies whose markers name no data directory (M4 copies, coordination root). */
  cleanupUnattributable?:boolean;
}
/** Production composition. Credentials, native PIDs and resource identities never come from RPC. */
export class ManagedTaskCapabilities implements TaskCapabilityLauncher {
  private readonly agentServices=new Map<import('@shared/application-capabilities').ApplicationEntry,ApplicationToolService>();
  private agentBusiness?:AgentBusinessTools;
  attachAgentRequests(store:import('../agent/agent-store').AgentStore,requests:import('../agent/host-business-requests').HostBusinessRequests,notify:(taskId:string,id:string,text:string)=>void){if(this.agentBusiness)return;this.agentBusiness=new AgentBusinessTools({store,requests,runs:this.runs,applications:this.applications,services:this.agentServices,notify});}

  private hostTools?: AgentHostTools;
  attachAgentTools(tools: AgentHostTools) { this.hostTools = tools; }
  private readonly planningAgents=new Map<string,NativeLaunchContext>();
  private readonly planningCliPolicies=new Map<string,CliSandboxPlan>();
  readonly cli?:ApplicationCliGateway;
  private cliReady=false;
  readonly sessions:CapabilitySessionRegistry;
  readonly runs:CapabilityRunRegistry;
  private readonly authorization:CurrentApplicationAuthorization;
  readonly bridges:AgentBridgeProcesses;
  readonly backends:RunBackendAuthority;
  readonly broker:PrivateApplicationBroker;
  readonly bridgeRecovery=new BridgeSupervisor();
  private readonly skillObservations=new SkillObservationMonitor(async(taskId,runId)=>{await this.applications.sessionDiagnostics.collectSkillObservations(taskId,runId);},undefined,runId=>this.applications.sessionDiagnostics.forgetSkillObservations(runId));
  private readonly recoveryServices=new Map<string,string>();
  private readonly active=new Map<string,ActiveLaunch>();
  private readonly pending=new Set<Promise<TaskCapabilityLaunch>>();
  private readonly stopping=new Map<string,Promise<void>>();
  private readonly processes:ProcessIdentityReader;
  private readonly embeddedNode=new EmbeddedNodeRuntime();
  private readonly timer:ReturnType<typeof setInterval>;
  readonly recoveryWarnings:{homeId:string;code:string}[]=[];
  private readonly library?:SkillLibraryService;
  private readonly pluginSkills?:FrozenPluginSkills;
  /** Last pre-R1.0 copy cleanup (diagnostics). */
  legacyCleanup:import('./legacy-copy-cleanup').LegacyCopyCleanup|null=null;
  /** Last retirement of pre-R1.0 resource records (diagnostics). */
  retirement:PreLibraryRetirement|null=null;
  private closed=false;private closing?:Promise<void>;private sweeping=false;
  private constructor(private readonly support:AgentSupportService,private readonly capabilities:CapabilityService,private readonly applications:ApplicationService,private readonly options:TaskCapabilityLauncherOptions){
    const store=support.store;this.processes=options.processes??new MacProcessIdentityReader(options.helper);
    this.sessions=new CapabilitySessionRegistry(store,{assertInitialSelection:snapshot=>this.assertInitialSelection(snapshot),verifyExtraResource:(resource,snapshot)=>this.verifyResource(resource,snapshot)});
    this.authorization=new CurrentApplicationAuthorization(store,applications.builtin);
    if(applications.plugins)this.pluginSkills=new FrozenPluginSkills(store,applications.plugins.lifecycle);
    if(options.skillLibraryHome)this.library=new SkillLibraryService(store,applications.builtin,{home:options.skillLibraryHome,targets:()=>support.adapters.deliveryAdapters.libraryTargets(),added:appId=>{const state=applications.selections.catalogState(appId as Parameters<typeof applications.selections.catalogState>[0]);return state.added&&state.enabled;},standardSkills:()=>(store.sqlite.prepare('SELECT skill_id AS skillId,hash FROM skill_versions WHERE active=1 ORDER BY skill_id').all() as {skillId:string;hash:string}[]).filter(s=>capabilities.globalEnabled(s.skillId)).map(s=>({skillId:s.skillId,files:Object.fromEntries(Object.entries(support.legacy.verify(store.get('standard-skill:'+s.skillId+':'+s.hash))).map(([path,text])=>[path,Buffer.from(text,'utf8')]))}))});
    this.runs=new CapabilityRunRegistry(store,this.sessions,{processes:this.processes,currentAuthorization:context=>this.authorization.view(context),createPlan:(snapshot,snapshotHash,runId,pinnedBindings)=>{
      // R17: the plan records what the Agent loads at this launch, i.e. the project's current applications (not the
      // session's creation record), so the resume advice compares against what this run actually loaded.
      const apps=this.authorization.selectedApps(snapshot.projectId),bindings=pinnedBindings?[...pinnedBindings,...this.authorization.bindings(snapshot.projectId,apps.filter(a=>a.appId!=='mail'&&a.appId!=='browser').map(a=>a.appId))]:this.authorization.bindings(snapshot.projectId,apps.map(a=>a.appId));
      const selected={...snapshot,packages:apps.map(a=>this.authorization.packageSelection(snapshot.projectId,a.packageHash,bindings,[])),standardSkills:[]} as CapabilitySessionSnapshot;
      const sources=selected.packages.map(p=>{const application=applications.builtin.retainedMetadata(p.packageHash);return{packageHash:p.packageHash,manifest:application.manifest,capabilities:builtinApplicationModules.capabilityViews(application.manifest)};});
      // R16: Skills come from the machine-wide library; a run plan carries no per-run Skill copies.
      const available=this.cliAvailability(snapshot.taskId),skills=snapshot.runner==='claude-code'||snapshot.runner==='codex'&&this.planningAgents.get(snapshot.taskId)?.version==='0.167.1'?this.pluginSkills?.describe(selected,runId,available)?.skills??[]:[];
      return createApplicationRunPlan({runId,snapshotHash,snapshot:selected,applications:sources,skills,available,sandbox:this.planningCliPolicies.has(snapshot.taskId)?{source:this.planningCliPolicies.get(snapshot.taskId)!.source,digest:this.planningCliPolicies.get(snapshot.taskId)!.digest}:undefined,cliVersion:this.planningAgents.get(snapshot.taskId)?.version??'unverified'});
    },assertCurrent:snapshot=>{
      // Application enablement and current slots belong to each business call, not Agent liveness.
      const project=store.sqlite.prepare('SELECT archived_at FROM projects WHERE id=?').get(snapshot.projectId) as {archived_at:number|null}|undefined;
      if(!project||project.archived_at!==null)throw new ApplicationError('SCOPE_DENIED','项目已删除或归档，不能继续使用此运行');
    },revoke:runId=>{const recoveryService=this.recoveryServices.get(runId);if(recoveryService)this.bridgeRecovery.revoke(runId,recoveryService);this.broker?.revokeRun(runId);this.cli?.revokeRun(runId);this.bridges?.revokeRun(runId);this.backends?.revokeRun(runId);const entry=this.active.get(runId),backend=entry?.codex?.stop();if(entry)this.options.stopPty(entry.run.ptyId);return backend;}});
    this.backends=new RunBackendAuthority(this.runs,options.peers??new MacUnixPeerIdentityReader(options.helper),this.processes,{pollMs:options.pollMs});
    this.bridges=new AgentBridgeProcesses(this.runs,options.peers??new MacUnixPeerIdentityReader(options.helper),this.processes,{pollMs:options.pollMs,additionalRoot:this.backends});
    const applicationTools = new ApplicationToolService(store,this.runs,new ApplicationAdapterRegistry(store,applications.data),{additional:applications.plugins?.tools});this.agentServices.set('mcp',applicationTools);
    const agentRun = (runId: string) => !!(store.sqlite.prepare('SELECT binding_id FROM capability_runs WHERE run_id=?').get(runId) as { binding_id?: string } | undefined)?.binding_id;
    this.broker=new PrivateApplicationBroker(this.runs,{
      clearMemory: runId => applicationTools.clearMemory(runId),
      list: async runId => { const list = await applicationTools.list(runId); if (!this.hostTools || !agentRun(runId)) return list; return this.runs.withActivity(runId, async context => ({ ...list, tools: [...list.tools, ...this.hostTools!.list(context)] })); },
      call: async (runId, id, call, signal) => {
        if (!call.operation.startsWith('wy_')) {
          const row = store.sqlite.prepare("SELECT d.access FROM capability_runs r JOIN agent_delegations d ON d.child_task_id=r.task_id WHERE r.run_id=? AND r.binding_id IS NOT NULL").get(runId) as { access: string } | undefined;
          if (row?.access === 'read') {
            const context = this.runs.assertActive(runId), tool = (await applicationTools.list(runId)).tools.find(t => t.name === call.operation && t.contractMajor === call.contractMajor);
            const external = context.snapshot.schema === 3 && context.snapshot.externalPlugins?.some(p => p.capabilities.some(c => c.mcpTool === call.operation || c.aliases.includes(call.operation)));
            if (!tool?.annotations.readOnlyHint || tool.annotations.destructiveHint || external) return { schema: 1, id, status: 'error', error: { code: 'SCOPE_DENIED', message: '只读角色拒绝写入或未经宿主证明的插件。调用 wy_request_write 并结束本轮后排队。', layer: 'auth', retryable: false, attemptCount: 0, retryExhausted: false, effectState: 'not-started', nextAction: '申请写入资格并结束本轮' } } as BridgeResponse;
          }
          return applicationTools.call(runId,id,call,signal);
        }
        try {
          if (!this.hostTools || !agentRun(runId) || call.contractMajor !== 1 || call.connectionId !== null) throw new ApplicationError('SCOPE_DENIED', '此运行未启用宿主委派工具');
          const value = await this.runs.withActivity(runId, context => this.hostTools!.call(context, call.operation, call.arguments, signal ?? context.signal));
          return { schema: 1, id, status: 'ok', value } as BridgeResponse;
        } catch (e) { return { schema: 1, id, status: 'error', error: { code: e instanceof ApplicationError ? e.code : 'INVALID_INPUT', message: (e as Error).message.slice(0, 1000), layer: 'auth', retryable: false, attemptCount: 0, retryExhausted: false, effectState: 'not-started', nextAction: '核对收据及子任务状态后再操作' } } as BridgeResponse; }
      },
    },{rejectedPeer:async(socket,runId,bridge)=>{if(agentRun(runId))await this.bridges.observeRejected(socket,runId,bridge);},attachPeer:(socket,runId,bridge)=>this.bridges.attach(socket,runId,bridge),authenticated:(runId,bridgeId)=>applications.sessionDiagnostics.bridgeAuthenticated(runId,bridgeId),disconnected:(runId)=>this.bridgeDisconnected(runId),rejectedReplacement:(runId,bridgeId)=>this.bridges.revokeBridge(runId,bridgeId)});
    if(options.cliPath)try{const cliTools=new ApplicationToolService(store,this.runs,new ApplicationAdapterRegistry(store,applications.data),{entry:'cli',additional:applications.plugins?.tools});this.agentServices.set('cli',cliTools);const identity={path:canonicalFuturePath(options.cliPath),sha256:digest(readFileSync(options.cliPath))};this.cli=new ApplicationCliGateway(this.runs,cliTools,options.peers??new MacUnixPeerIdentityReader(options.helper),{executable:identity,additionalRoot:this.backends});this.cliProof=Object.freeze(identity);}catch{/* Missing CLI resources retain the approved read-only MCP fallback. */}
    applications.sessionDiagnostics.attach({deliveryAdapters:support.adapters.deliveryAdapters,channelConnected:id=>this.broker.hasAuthenticated(id),recoveryIssue:id=>{const server=this.recoveryServices.get(id);const result=server?this.bridgeRecovery.inspect(id,server)?.result:undefined;return result&&result.code!=='CONNECTED'?result.code:null;},verify:(resource,snapshot)=>this.verifyResource(resource,snapshot)});
    this.timer=setInterval(()=>{void this.sweep();},Math.max(20,options.pollMs??500));this.timer.unref();
  }
  static async open(support:AgentSupportService,capabilities:CapabilityService,applications:ApplicationService,options:TaskCapabilityLauncherOptions):Promise<ManagedTaskCapabilities>{
    const result=new ManagedTaskCapabilities(support,capabilities,applications,options);
    try{await result.runs.recover();
      for(const issue of result.pluginSkills?.recover()??[])result.recoveryWarnings.push({homeId:'plugin-skills:'+issue.runId,code:issue.code});
      if(options.skillLibraryHome)try{result.legacyCleanup=cleanupPreLibraryCopies({home:options.skillLibraryHome,storeId:support.store.storeId,unattributable:options.cleanupUnattributable===true});}catch(error){result.recoveryWarnings.push({homeId:'legacy-copy-cleanup',code:error instanceof ApplicationError?error.code:'RESOURCE_RECOVERY_REQUIRED'});}
      try{result.retirement=await retirePreLibraryResources(support.store);}catch(error){result.recoveryWarnings.push({homeId:'pre-library-retirement',code:error instanceof ApplicationError?error.code:'RESOURCE_RECOVERY_REQUIRED'});}
      result.syncSkillLibrary();await result.broker.start();if(result.cli)try{await result.cli.start();result.cliReady=true;}catch{await result.cli.close();}applications.attachRuns(result.runs);return result;}catch(error){await result.dispose();throw error;}
  }
  /** Converge the Skill library after startup and every application change; a failure never blocks tasks. */
  syncSkillLibrary(claudeStateRoot?:string):void{
    if(!this.library)return;
    try{this.library.sync(claudeStateRoot);this.recoveryWarnings.splice(0,this.recoveryWarnings.length,...this.recoveryWarnings.filter(w=>w.homeId!=='skill-library'));}
    catch(error){if(!this.recoveryWarnings.some(w=>w.homeId==='skill-library'))this.recoveryWarnings.push({homeId:'skill-library',code:error instanceof ApplicationError?error.code:'RESOURCE_RECOVERY_REQUIRED'});}
  }
  skillLibraryConflicts(){return this.library?.conflicts()??[];}
  coordinateRestore<T>(work:()=>Promise<T>,signal:AbortSignal):Promise<T>{
    // Separate H scope: serialize restore/copy admissions across normal hosts,
    // including different tasks targeting the same native SID. Never hold C over I/O.
    return withCoordinatorLock(ensureStoreDirectory(this.support.store.root,'locks/native-history'),'catalog',work,{signal,timeoutMs:15000,processes:this.processes});
  }
  async assertHistoryCopyAllowed(input:{taskId:string;from:string;to:string;cwd:string;sessionId:string;home:string}):Promise<void>{
    await withResourceLock(this.support.store.root,()=>{this.sessions.assertHistoryCopyAllowed(input);});
  }
  /**
   * R1.0 §3.5: applications enabled or upgraded since this library run started that its Agent sees only after a
   * resume (declared per Agent: in-session Skill reload, in-session MCP reload). Removals need no resume.
   */
  resumeAdvice(taskId:string):import('@shared/tasks').TaskResumeAdvice|null{
    for(const entry of this.active.values()){
      const record=this.runs.get(entry.run.runId);if(record.taskId!==taskId||record.state!=='active')continue;
      const context=this.runs.bridgePreparation(entry.run.runId),plan=context.plan;if(!plan)return null;
      if(this.support.adapters.get(context.snapshot.adapterBinding.hash).metadata.skillDelivery!=='library')return null;
      const library=this.support.adapters.deliveryAdapters.get(context.snapshot.runner).library,names:string[]=[];
      for(const app of this.selectedApps(context.snapshot.projectId)){
        if(plan.applications.some(a=>a.appId===app.appId&&a.packageHash===app.packageHash))continue;
        const manifest=this.applications.builtin.retainedMetadata(app.packageHash).manifest;
        const usesMcp=builtinApplicationModules.capabilityViews(manifest).some(c=>selectCapabilityEntry(c,{mcp:true,cli:plan.grades.cli}).entry==='mcp');
        if(!library.skillsReloadInSession||usesMcp&&!library.mcpReloadInSession)names.push(builtinApplicationModules.module(app.appId).presentation.displayName);
      }
      return names.length?{applications:names}:null;
    }
    return null;
  }
  private cliAvailability(taskId:string):RunPlanAvailability{const policy=this.planningCliPolicies.get(taskId);return{mcp:true,cli:this.cliReady&&policy?.available===true,reason:policy?.available?undefined:policy&&'reason'in policy?policy.reason:'cli-entry-unavailable'};}
  private async configureCli(input:TaskLaunchInput,native:NativeLaunchContext,snapshot:CapabilitySessionSnapshot){
    const delivery=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner);
    if(!this.cliReady||!delivery.entryDelivery('cli')||this.support.adapters.get(snapshot.adapterBinding.hash).metadata.cliEntry!=='supported')return;
    // §15.4: the CLI sandbox is delivered only for a version whose declared levels include L0.cli; undeclared versions fail closed.
    if(!this.support.adapters.effective(snapshot.adapterBinding.hash,native.version).levels.includes('L0.cli'))return;
    const inspect=this.options.inspectSandbox??delivery.effectiveSandbox;

    if(!inspect)return;
    const policy=await inspect.call(delivery,input,native);
    this.planningCliPolicies.set(input.taskId,policy);
  }

  private bindings(projectId:string,appIds:readonly string[]):RunBindingRevision[]{return this.authorization.bindings(projectId,appIds);}

  private assertInitialSelection(snapshot:CapabilitySessionSnapshot):void{
    assertNoPendingApplicationSwitch(this.support.store,snapshot);
    const store=this.support.store,apps=this.selectedApps(snapshot.projectId);
    if(canonicalJson(apps)!==canonicalJson(snapshot.packages.map(p=>({appId:p.appId,packageHash:p.packageHash}))))throw new ApplicationError('RESOURCE_STATE_CHANGED','准备期间项目应用或默认版本已变化');
    const bindings=this.bindings(snapshot.projectId,snapshot.packages.map(p=>p.appId));
    for(const app of snapshot.packages){const current=bindings.filter(b=>b.appId===app.appId&&b.connectionId).map(b=>({bindingId:`${snapshot.projectId}:${app.appId}:${b.slot}`,connectionId:b.connectionId!,identityRevision:b.identityRevision!}));if(canonicalJson(current)!==canonicalJson(app.bindings))throw new ApplicationError('RESOURCE_STATE_CHANGED','准备期间项目连接选择已变化');}
    if(snapshot.schema===3&&this.applications.plugins&&canonicalJson(snapshot.externalPlugins??[])!==canonicalJson(this.applications.plugins.selections(snapshot.projectId)))throw new ApplicationError('RESOURCE_STATE_CHANGED','准备期间插件或启动连接已变化');
    const settings=store.sqlite.prepare('SELECT id,project_id AS projectId,capability_id AS capabilityId,enabled FROM project_capabilities WHERE project_id=?').all(snapshot.projectId) as ProjectCapabilitySetting[];
    if(projectCapabilityEnabled(settings,snapshot.projectId,MCP_CAPABILITY)!==snapshot.mcp.some(m=>m.kind==='legacy-project-context'))throw new ApplicationError('RESOURCE_STATE_CHANGED','准备期间项目上下文选择已变化');
  }
  /** Pre-R1.0 references stay recorded until adoption releases them, but no launch is backed by them any more. */
  private verifyResource(resource:ResourceRecord,snapshot:CapabilitySessionSnapshot):void{
    if(resource.kind==='agent-adapter')this.support.adapters.verifyReference(resource,snapshot);
    else if(RETIRED_RESOURCE_KINDS.has(resource.kind))throw new ApplicationError('RESOURCE_RECOVERY_REQUIRED','R1.0 之前的投影资源不再用于启动');
    else this.support.legacy.verify(resource);
  }
  private selectedApps(projectId:string):{appId:string;packageHash:string}[]{return this.authorization.selectedApps(projectId);}

  /** Every version of an Agent uses the library; prefer the adapter that declares this version. */
  private libraryAdapter(runner:string,cliVersion:string|undefined){
    const candidates=this.support.status().adapters.filter(a=>a.agentId===runner&&this.support.adapters.get(a.hash).metadata.skillDelivery==='library');
    return candidates.find(a=>cliVersion!==undefined&&a.cliVersions.includes(cliVersion))??candidates[0];
  }
  prepare(input:TaskLaunchInput):Promise<TaskCapabilityLaunch>{const work=this.prepareOnce(input);this.pending.add(work);void work.finally(()=>{this.pending.delete(work);this.planningAgents.delete(input.taskId);this.planningCliPolicies.delete(input.taskId);}).catch(()=>{});return work;}
  private async prepareOnce(input:TaskLaunchInput):Promise<TaskCapabilityLaunch>{
    if(this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','任务能力准备已取消');
    let native:NativeLaunchContext|undefined,unavailable:string|undefined;
    try{const delivery=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner);native=await(this.options.inspectNative??delivery.inspectNative).call(delivery,input);}catch(error){if(input.signal.aborted||error instanceof ApplicationError&&error.code==='CANCELED')throw error;if(!(error instanceof ApplicationError)||error.code!=='AGENT_ADAPTER_UNSUPPORTED')throw error;unavailable=error.code;}
    if(native)this.planningAgents.set(input.taskId,native);
    // Later native checks and the CLI PATH must see the terminal's PATH; the app's own PATH is bare when started from the Dock.
    return this.prepareCurrent(native?.shellPath?{...input,environment:{...input.environment,PATH:native.shellPath}}:input,native,unavailable);
  }
  /** R1.0 production launch: the library when the Agent can use it, otherwise native only; never the shared discovery catalog. */
  private async prepareCurrent(input:TaskLaunchInput,native:NativeLaunchContext|undefined,unavailable:string|undefined):Promise<TaskCapabilityLaunch>{
    if(native){const library=await this.libraryLaunch(input,native);if(library)return this.prepareLibrary(input,native,library);}
    const runner=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner).id,code=unavailable??'AGENT_ADAPTER_UNSUPPORTED';
    if(input.previous?.sessionCapabilities){
      const pointer=input.previous.sessionCapabilities;if(pointer.taskId!==input.taskId)throw new ApplicationError('SNAPSHOT_CORRUPT','任务指针不属于当前会话');
      const current=await this.sessions.get(input.taskId);
      if(current.snapshot.projectId!==input.projectId||current.pointer.snapshotHash!==pointer.snapshotHash)throw new ApplicationError('SNAPSHOT_CORRUPT','任务指针与原会话快照不同');
      return this.prepareUnavailableSession(input,current,native,code);
    }
    if(input.newTask){
      const adapter=this.libraryAdapter(runner,native?.version);
      if(!adapter)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','本版本未准备此Agent适配资源');
      const current=await this.sessions.create(this.createLibrarySnapshot(input,native?.version??'unverified',adapter.hash),input.home);
      await this.sessions.addLegacyRuntimeReference(input.taskId,current.pointer.snapshotHash,this.capabilities.runtimeIdentity().hash);
      return this.prepareUnavailableSession(input,current,native,code);
    }
    // History without a session record (before M10): native only.
    if(input.previous&&!legacyRuntimeMetadata.safeParse(input.previous).success)throw new ApplicationError('SNAPSHOT_CORRUPT','原能力快照格式不支持，保留原记录并阻止受管恢复');
    const recorded=this.support.store.sqlite.prepare('SELECT schema_version,legacy_status FROM capability_session_snapshots WHERE task_id=?').get(input.taskId) as {schema_version:number;legacy_status:string}|undefined;
    if(recorded&&(recorded.schema_version!==0||recorded.legacy_status!=='history-unknown'))throw new ApplicationError('SNAPSHOT_CORRUPT','任务指针缺失或原历史已待核查，保留原登记且不降级重建');
    await this.sessions.holdUnknown({taskId:input.taskId,projectId:input.projectId,runner,stateRoot:input.stateRoot,cwd:input.cwd,sessionId:input.sessionId,reason:'history-unknown'});
    return this.prepareNativeHistory(input,native,unavailable);
  }
  /** The library adapter that serves this launch: a resumed library session, or a new task on a declared Agent version. */
  private async libraryLaunch(input:TaskLaunchInput,native:NativeLaunchContext):Promise<{adapterHash:string;current?:StoredCapabilitySession}|undefined>{
    const runner=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner).id;
    if(input.previous?.sessionCapabilities){
      const pointer=input.previous.sessionCapabilities;if(pointer.taskId!==input.taskId)return undefined;
      const recorded=this.support.store.sqlite.prepare('SELECT snapshot_json FROM capability_session_snapshots WHERE task_id=?').get(input.taskId) as {snapshot_json:string}|undefined;
      let hash:string|undefined;try{hash=JSON.parse(recorded?.snapshot_json??'null')?.adapterBinding?.hash;}catch{return undefined;}
      if(!hash)return undefined;let library:boolean;try{library=this.support.adapters.get(hash).metadata.skillDelivery==='library';}catch{return undefined;}
      if(!library)return this.adoptLibrarySession(input,native,runner);
      const current=await this.sessions.get(input.taskId);
      if(current.snapshot.projectId!==input.projectId)throw new ApplicationError('SNAPSHOT_CORRUPT','任务项目与原会话身份不符');
      if(current.pointer.snapshotHash!==pointer.snapshotHash)throw new ApplicationError('SNAPSHOT_CORRUPT','任务指针与原会话快照不同');
      await this.sessions.verifyNativeIdentity(input.taskId,{runner,stateRoot:input.nativeRestore?.from??input.stateRoot,cwd:input.cwd,sessionId:input.sessionId,home:input.home});
      if(this.applications.plugins||input.nativeRestore)return{adapterHash:hash,current:await this.sessions.adoptLibrary(input.taskId,current.pointer.snapshotHash,this.createLibrarySnapshot(input,native.version,hash),{
        copy:input.nativeRestore,home:input.home,commit:input.commitSessionSnapshot?(before,after)=>{
          if(input.signal.aborted)throw new ApplicationError('CANCELED','历史目录提交已取消');
          input.commitSessionSnapshot!({pointer:before.pointer,native:before.snapshot.native},{pointer:after.pointer,native:after.snapshot.native});
        }:undefined,
      })};
      return{adapterHash:hash,current};
    }
    if(!input.newTask)return undefined;
    const adapter=this.libraryAdapter(runner,native.version);
    return adapter?{adapterHash:adapter.hash}:undefined;
  }
  /** S4: a pre-R1.0 session becomes a library session on resume. Any failure keeps the original path so the task still starts. */
  private async adoptLibrarySession(input:TaskLaunchInput,native:NativeLaunchContext,runner:string):Promise<{adapterHash:string;current:StoredCapabilitySession}|undefined>{
    const adapter=this.libraryAdapter(runner,native.version);if(!adapter)return undefined;
    try{
      const pointer=input.previous!.sessionCapabilities!,old=await this.sessions.get(input.taskId);
      if(old.snapshot.projectId!==input.projectId||old.pointer.snapshotHash!==pointer.snapshotHash||old.retention!=='active')return undefined;
      await this.sessions.verifyNativeIdentity(input.taskId,{runner,stateRoot:input.stateRoot,cwd:input.cwd,sessionId:input.sessionId,home:input.home});
      if((await this.sessions.references(input.taskId)).filter(r=>r.refKind==='legacy-runtime').length!==1)return undefined;
      // Nothing after the adoption may fail back to the old path: the stored pointer has already moved.
      return{adapterHash:adapter.hash,current:await this.sessions.adoptLibrary(input.taskId,old.pointer.snapshotHash,this.createLibrarySnapshot(input,native.version,adapter.hash))};
    }catch(error){
      if(input.signal.aborted||error instanceof ApplicationError&&error.code==='CANCELED')throw error;if(!(error instanceof ApplicationError))throw error;
      // Once adopted, the old path no longer matches the stored pointer: report instead of falling back.
      const now=this.support.store.sqlite.prepare('SELECT snapshot_json FROM capability_session_snapshots WHERE task_id=?').get(input.taskId) as {snapshot_json:string}|undefined;
      try{if(this.support.adapters.get(JSON.parse(now?.snapshot_json??'null')?.adapterBinding?.hash).metadata.skillDelivery==='library')throw error;}catch(checked){if(checked===error)throw error;}
      return undefined;
    }
  }
  /** Pinned bridge runtime shared by every registered application package. */
  private applicationRuntimeHash():string|null{
    for(const appId of builtinApplicationModules.appIds()){const active=this.applications.builtin.packages.active(appId);if(active)return this.applications.builtin.retainedMetadata(active.packageHash).manifest.runtime.hash;}
    return null;
  }
  /** Audit record of the session; what it may call is decided per call (R17), and Skills come from the library (R16). */
  private createLibrarySnapshot(input:TaskLaunchInput,agentVersion:string,adapterHash:string):CapabilitySessionSnapshot{
    const runner=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner).id,adapter=this.support.adapters.get(adapterHash).metadata;
    const apps=this.selectedApps(input.projectId),bindings=this.bindings(input.projectId,apps.map(a=>a.appId)),packages=apps.map(a=>this.authorization.packageSelection(input.projectId,a.packageHash,bindings,[]));
    const runtimeHash=packages[0]?.runtimeHash??this.applicationRuntimeHash(),appMcp=applicationMcpServerName(digest(input.taskId));
    if(new Set(packages.map(p=>p.runtimeHash)).size>1)throw new ApplicationError('HOST_INCOMPATIBLE','本次应用选择使用了不兼容的桥运行版本');
    const mcp:CapabilitySessionSnapshot['mcp']=runtimeHash?[{kind:'applications',serverName:appMcp,protocolMajor:1,runtimeHash}]:[];
    const externalPlugins=this.applications.plugins?.selections(input.projectId);
    if(this.capabilities.enabled(input.projectId,MCP_CAPABILITY))mcp.push({kind:'legacy-project-context',serverName:'smartdd_project_'+digest(input.taskId).slice(0,12),protocolMajor:1,runtimeHash:this.capabilities.runtimeIdentity().hash});
    const toolNames=[...packages.flatMap(p=>Object.keys(p.toolContractMajors)),...(externalPlugins??[]).flatMap(p=>p.capabilities.flatMap(c=>[c.mcpTool,...c.aliases]))];
    return{schema:3,taskId:input.taskId,projectId:input.projectId,createdAt:new Date().toISOString(),runner,adapterBinding:{id:runner,version:adapter.version,hash:adapterHash,projectionFormatVersion:1,nativeToolNames:Object.fromEntries(toolNames.map(name=>[name,'mcp__'+appMcp+'__'+name]))},native:{sessionId:input.sessionId,stateRoot:input.stateRoot,cwd:input.cwd},agentAtCreation:{version:agentVersion,adapterRevision:1},catalogGeneration:'library',packages,...(externalPlugins?{externalPlugins}:{}),standardSkills:[],mcp,provenance:'created'};
  }
  /** M14 binds capabilities to a real SDK/app-server run, never to a synthetic PTY process. */
  private cliProof?:import('../agent/host-cli-command').HostBusinessCli;
  supportsAgentDelivery(runner:string,version:string){const adapter=this.libraryAdapter(this.support.adapters.deliveryAdapters.forRunner(runner).id,version);return !!adapter&&this.support.adapters.levels(adapter.hash,version).includes('L0.mcp');}
  taskPlugins(taskId:string){const task=this.support.store.sqlite.prepare('SELECT project_id FROM tasks WHERE id=?').get(taskId) as {project_id:string|null}|undefined;if(!task?.project_id)return[];const result=this.selectedApps(task.project_id).map(p=>({id:p.appId,name:this.applications.builtin.retainedMetadata(p.packageHash).manifest.displayName}));for(const p of this.applications.plugins?.selections(task.project_id)??[]){const state=this.applications.plugins!.lifecycle.state(p.appId);if(state.hash)result.push({id:p.appId,name:this.applications.plugins!.lifecycle.packages.get(state.hash).plugin.manifest.displayName});}return result;}
  async agentReference(sender:import('./execution-context').ApplicationUiSender,taskId:string,raw:import('@shared/application-terminal').ApplicationTerminalSource){
    const {applicationTerminalSourceSchema,applicationReferenceText,terminalSourceApp}=await import('@shared/application-terminal');
    const source=applicationTerminalSourceSchema.parse(raw),store=this.support.store;
    const task=()=>{const t=store.sqlite.prepare('SELECT t.project_id,a.archived_at FROM agent_tasks a JOIN tasks t ON t.id=a.task_id WHERE a.task_id=?').get(taskId) as {project_id:string|null;archived_at:string|null}|undefined;if(!t?.project_id||t.archived_at||!store.sqlite.prepare('SELECT 1 FROM projects WHERE id=? AND archived_at IS NULL').get(t.project_id))throw new ApplicationError('SCOPE_DENIED','引用目标任务或项目已不可用');return t;};
    const projectId=task().project_id!;
    if(source.kind==='pluginAction'){const value=this.applications.pluginReviewAction(sender,source.actionId);if(value.kind!=='insertTerminal'||value.appId!==source.appId||value.projectId!==projectId)throw new ApplicationError('SCOPE_DENIED','插件原对象不属于目标项目');task();return{taskId,projectId,text:value.text};}
    const appId=terminalSourceApp(source);this.applications.selections.requireEnabled(projectId,appId);
    const selected=this.selectedApps(projectId).find(p=>p.appId===appId);if(!selected)throw new ApplicationError('SCOPE_DENIED','目标项目没有选用此应用');const pack=this.applications.builtin.retainedMetadata(selected.packageHash),policy=canonicalJson(this.applications.selections.policyStamp(projectId,appId));
    if(source.kind==='skill'){if(!pack.manifest.skills.some(s=>s.id===source.skillId))throw new ApplicationError('SCOPE_DENIED','此应用没有声明该Skill');}
    else if(source.kind==='draft'){const value=await this.applications.viewDraft(sender,projectId,source.draftId,source.revision);if(value.draft.contentHash!==source.contentHash||(store.sqlite.prepare('SELECT current_revision FROM mail_drafts WHERE id=? AND project_id=?').get(source.draftId,projectId) as {current_revision:number}|undefined)?.current_revision!==source.revision)throw new ApplicationError('REVISION_CONFLICT','草稿已更新，请重新查看后插入');}
    else {const slot=source.kind==='zentao'?'zentao':'foxmail',binding=this.applications.selections.connectionSlot(projectId,appId,slot),connection=this.applications.connections.get(source.reference.connectionId);if(binding.connectionId!==connection.id||binding.identityRevision!==source.reference.identityRevision||connection.identityRevision!==source.reference.identityRevision||!connection.enabled||connection.authorization!=='connected')throw new ApplicationError('SCOPE_DENIED','引用不是目标项目当前选用的来源');if(source.kind==='zentao')this.applications.data.zentao.assertStoredReference(projectId,source.objectKind,source.reference);else await this.applications.contexts.withUi(sender,{projectId,appId:'mail',action:'ui.mail.reference.prepare',operations:['mail.read'],semantics:'read'},context=>this.applications.mailReads.source(context,source.reference));}
    if(task().project_id!==projectId||canonicalJson(this.applications.selections.policyStamp(projectId,appId))!==policy)throw new ApplicationError('RESOURCE_STATE_CHANGED','准备引用期间项目授权已经变化');
    return{taskId,projectId,text:applicationReferenceText(source)};
  }
  recordAgentHumanInput(runId:string,sender:import('./execution-context').ApplicationUiSender,text:string,sequence:number){const context=this.runs.assertActive(runId),row=this.support.store.sqlite.prepare('SELECT pty_id FROM capability_runs WHERE run_id=? AND binding_id IS NOT NULL').get(runId) as {pty_id:string}|undefined;if(row)this.applications.nativeInputs.observeAgent(sender,context,row.pty_id,text,sequence);}
  agentContext(runId:string){return this.runs.assertActive(runId);}
  assertAgentApplication(taskId:string,appId:'browser'|'mail'|'zentao'|'sample-kv'){const task=this.support.store.sqlite.prepare('SELECT project_id FROM tasks WHERE id=?').get(taskId) as {project_id:string}|undefined;if(!task)throw new ApplicationError('SCOPE_DENIED','任务不存在');this.applications.selections.requireApplicationEnabled(task.project_id,appId);}
  async prepareAgent(input: { runId: string; bindingId: string; generation: number; task: TaskLaunchInput; version: string; assertCurrent(): void }): Promise<RunIntegration> {
    if (this.closed) throw new ApplicationError('CANCELED', '应用服务已关闭');
    const store = this.support.store, task = input.task, runner = this.support.adapters.deliveryAdapters.forRunner(task.profile.runner).id;
    const adapter = this.libraryAdapter(runner, input.version); if (!adapter) throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED', '没有此执行器的受控交付资源');
    input.assertCurrent(); this.syncSkillLibrary(task.profile.runner === 'claude' ? task.stateRoot : undefined);
    const native = await (this.options.inspectNative ?? inspectNativeLaunch)(task);
    const snapshot = this.createLibrarySnapshot(task, input.version, adapter.hash), bytes = canonicalJson(snapshot), hash = digest(bytes);
    const server = snapshot.mcp.find(m => m.kind === 'applications');
    if (!server) throw new ApplicationError('CAPABILITY_UNAVAILABLE', '应用桥资源尚未准备');
    if (native.inventory.some(x => x.kind === 'mcp' && x.name === server.serverName)) throw new ApplicationError('AGENT_CAPABILITY_NAME_CONFLICT', '用户 MCP 已使用 WillYou 服务名，未覆盖');
    const bindings = this.applications.builtinPreferences.capture(task.projectId);
    const selection=JSON.parse((store.sqlite.prepare('SELECT selection_json FROM agent_tasks WHERE task_id=?').get(task.taskId) as {selection_json:string}).selection_json),role=store.sqlite.prepare('SELECT access FROM agent_delegations WHERE child_task_id=?').get(task.taskId) as {access:string}|undefined;
    // The driver supplies the effective per-turn tier. Inspect the same host choice, retaining all other source flags.
    const args:string[]=[];for(let i=0;i<task.profile.args.length;i++){const a=task.profile.args[i];if(['--permission-mode','--sandbox','-s','--ask-for-approval','-a','--setting-sources'].includes(a)){i++;continue;}if(['--dangerously-bypass-approvals-and-sandbox','--yolo','--approve-for-me','--not-so-yolo','--full-auto'].includes(a))continue;args.push(a);}
    if(task.profile.runner==='codex')args.push('--sandbox',selection.tier==='full'?'danger-full-access':'workspace-write');else args.push('--setting-sources','user','--permission-mode',selection.tier==='full'?'bypassPermissions':'default');
    const cliTask={...task,profile:{...task.profile,args}};
    if(role?.access!=='read')await this.configureCli(cliTask,native,snapshot);
    const cliPolicy=this.planningCliPolicies.get(task.taskId);
    const available: RunPlanAvailability = { cli: !!this.cli&&this.cliReady&&cliPolicy?.available===true&&role?.access!=='read', mcp: true };
    const skills = this.pluginSkills?.describe(snapshot, input.runId, available);
    if (skills) { this.pluginSkills!.checkNative(skills, native); this.pluginSkills!.materialize(skills); }
    const sources = snapshot.packages.map(p => { const application = this.applications.builtin.retainedMetadata(p.packageHash); return { packageHash: p.packageHash, manifest: application.manifest, capabilities: builtinApplicationModules.capabilityViews(application.manifest) }; });
    const plan = createApplicationRunPlan({ runId: input.runId, snapshotHash: hash, snapshot, applications: sources, skills: skills?.skills ?? [], available, sandbox:cliPolicy?.available?{source:cliPolicy.source,digest:cliPolicy.digest}:undefined, cliVersion: input.version });
    const resourceIds = [...new Set([`agent-adapter:${snapshot.runner}:${adapter.hash}`, ...snapshot.packages.flatMap(p => ['app:' + p.packageHash, 'runtime:' + p.runtimeHash]), ...snapshot.mcp.map(m => (m.kind === 'applications' ? 'runtime:' : 'legacy-runtime:') + m.runtimeHash)])];
    const verify = async () => {
      this.support.adapters.verify(adapter.hash);
      for (const p of snapshot.packages) { const installed = this.applications.builtin.retainedMetadata(p.packageHash); verifyPackageTree(join(store.root, installed.relativePath), installed, store.storeId); new RuntimeRegistry(store).verify(p.runtimeHash); }
      new RuntimeRegistry(store).verify(server.runtimeHash);
      if (skills) this.pluginSkills!.verify(skills);
    };
    let nativeStarted=false;
    const assertCurrent = () => { input.assertCurrent();if(!nativeStarted&&cliPolicy?.available){if('runner' in cliPolicy)verifyClaudeCliSandbox(cliPolicy);else verifyCodexCliSandbox(cliPolicy);} assertNoPendingApplicationSwitch(store, snapshot); if (skills) this.pluginSkills!.verify(skills); };
    // Per-binding version records coexist with M13's task snapshots; no global session pointer is rewritten.
    store.sqlite.transaction(() => {
      const reserved = store.sqlite.prepare("SELECT c.capability_session_id,c.snapshot_json FROM capability_runs r JOIN agent_capability_sessions c ON c.capability_session_id=r.capability_session_id WHERE r.run_id=? AND r.binding_id=? AND r.state='preparing' AND r.pid IS NULL").get(input.runId, input.bindingId) as { capability_session_id: string; snapshot_json: string } | undefined;
      if (!reserved || JSON.parse(reserved.snapshot_json).kind !== 'run_preparing' || JSON.parse(reserved.snapshot_json).runId !== input.runId) throw new ApplicationError('SNAPSHOT_IMMUTABLE', '本次运行的能力预留已变化，不能替换');
      const frozen = JSON.stringify({ kind: 'business', snapshot, runId: input.runId });
      store.sqlite.prepare('UPDATE agent_capability_sessions SET content_hash=?,snapshot_json=? WHERE capability_session_id=?').run(digest(frozen), frozen, reserved.capability_session_id);
    })();
    const run = await this.runs.adoptAgentRun(input.runId, input.bindingId, { session: { snapshot, pointer: { schema: 3, taskId: task.taskId, snapshotHash: hash }, selectionHash: hash, discoveryHome: task.home, retention: 'active', legacyStatus: 'created' }, resourceIds, bindings, plan, verify, assertCurrent });
    let bridge: Awaited<ReturnType<PrivateApplicationBroker['prepare']>> | undefined;
    try {
      await run.prepare();
      store.sqlite.transaction(()=>{for(const resourceId of resourceIds){const resource=store.get(resourceId);for(const [ownerKind,ownerId] of [['run',input.runId],['binding',input.bindingId]])store.sqlite.prepare('INSERT OR IGNORE INTO agent_resource_refs(owner_kind,owner_id,resource_kind,resource_id,hold_reason,created_at) VALUES(?,?,?,?,?,?)').run(ownerKind,ownerId,resource.kind,resourceId,JSON.stringify({contentHash:resource.contentHash,generation:resource.generation}),new Date().toISOString());}})();
      bridge = await this.broker.prepare(run, server.serverName, assertCurrent);
      const projectMcp=snapshot.mcp.find(m=>m.kind==='legacy-project-context');let runtime:PreparedRuntime|undefined;
      if(projectMcp){if(native.inventory.some(x=>x.kind==='mcp'&&x.name===projectMcp.serverName))throw new ApplicationError('AGENT_CAPABILITY_NAME_CONFLICT','用户 MCP 已使用项目上下文名称');runtime=this.capabilities.prepare({projectId:task.projectId,taskId:task.taskId,runner:task.profile.runner,cwd:task.cwd,home:task.home,profileArgs:task.profile.args,previous:task.previous,managed:{runId:run.runId,runtimeHash:projectMcp.runtimeHash,mcpName:projectMcp.serverName}});}
      const mcpServers: NonNullable<DriverOpenOptions['mcpServers']> = { [server.serverName]: { command: process.execPath, args: [join(store.root, 'runtime', server.runtimeHash, 'mcp-bridge.cjs'), '--bootstrap', bridge.bootstrapPath], env: { ELECTRON_RUN_AS_NODE: '1' } } };
      if(projectMcp&&runtime)mcpServers[projectMcp.serverName]={command:'python3',args:[join(store.root,'runtime',projectMcp.runtimeHash,'context_mcp.py'),join(store.root,'runs',task.projectId,task.taskId,run.runId,'context.json')],env:{}};
      const extraArgs: string[] = [];let cliEnvironment:Record<string,string>={},claudeSettings:Record<string,unknown>|undefined;
      if(available.cli&&this.cli&&cliPolicy?.available){
        const cliSandbox='runner' in cliPolicy?{runner:'claude-code' as const,endpoint:this.cli.endpoint,kind:cliPolicy.kind,source:cliPolicy.source,digest:cliPolicy.digest}:{endpoint:this.cli.endpoint,kind:cliPolicy.kind,parent:cliPolicy.parent,networkProxy:cliPolicy.networkProxy,enableNetwork:cliPolicy.enableNetwork,existingNames:cliPolicy.existingNames,source:cliPolicy.source,digest:cliPolicy.digest};
        const overlay=this.support.adapters.planLibrary(adapter.hash,{snapshot,runId:run.runId,cliVersion:input.version,currentExecutable:process.execPath,native:{...snapshot.native,runner:snapshot.runner,home:task.home},inventory:native.inventory,planHash:plan.planHash,cliSandbox,mcp:[]});
        if(task.profile.runner==='codex')extraArgs.push(...overlay.args);else{const at=overlay.args.indexOf('--settings');if(at>=0)claudeSettings=JSON.parse(overlay.args[at+1]);}
        cliEnvironment={...this.cli.issue(run).environment,PATH:dirname(this.options.cliPath!)+delimiter+(task.environment.PATH??'')};
      }
      const role = store.sqlite.prepare("SELECT access FROM agent_delegations WHERE child_task_id=?").get(task.taskId) as { access: string } | undefined;
      if (role?.access === 'read' && task.profile.runner === 'codex') { const disabled = native.inventory.filter(e => e.kind === 'mcp' && e.name !== server.serverName); if (disabled.length) extraArgs.push('-c', `mcp_servers={${disabled.map(e => `${JSON.stringify(e.name)}={enabled=false}`).join(',')}}`); }
      if (task.profile.runner === 'codex') for (const [name, m] of Object.entries(mcpServers)) extraArgs.push('-c', `mcp_servers.${name}={command=${JSON.stringify(m.command)},args=${JSON.stringify(m.args)},env={ELECTRON_RUN_AS_NODE="1"},default_tools_approval_mode="approve",startup_timeout_sec=30,tool_timeout_sec=120}`);
      this.active.set(run.runId, { run,...(runtime?{runtime}:{}) });
      return {
        extraArgs, mcpServers,env:{...runtime?.env,...cliEnvironment},claudeSettings,...(available.cli&&this.options.cliPath?{hostBusinessCli:this.cliProof}:{}),
        plugins: task.profile.runner === 'claude' ? skills?.claudeRoots.map(path => ({ type: 'local' as const, path })) : undefined,
        skillRoots: task.profile.runner === 'codex' ? skills?.codexRoots.map((path, i) => ({ path, name: skills.skills[i].nativeName })) : undefined,
        assertCurrent, beforeFork: async () => { assertCurrent(); await bridge!.bridge.arm(); await run.cli.arm(); },
        attached: async pid => {await run.cli.attach(pid);nativeStarted=true;this.applications.nativeMessages.register(run.runId,input.version,run.signal);},
        exited: async () => { await run.cli.exited(); const deadline = Date.now() + 20_000; while (!['stopped', 'failed'].includes(this.runs.get(run.runId).state)) { if (Date.now() >= deadline) throw new ApplicationError('RESOURCE_BUSY', '业务或桥进程尚未排空'); await new Promise(r => setTimeout(r, 50)); } },
        cancelBeforeFork: async () => { this.broker.revokeRun(run.runId); await run.cli.cancelUnforked!(); await bridge!.bridge.releaseUnclaimed?.(); await run.stop('agent-unforked'); },
      };
    } catch (e) { this.broker.revokeRun(run.runId); await run.cli.cancelUnforked?.().catch(() => {}); await run.stop('agent-prepare-failed').catch(() => {}); throw e; }
  }
  private async prepareLibrary(input:TaskLaunchInput,native:NativeLaunchContext,selected:{adapterHash:string;current?:StoredCapabilitySession}):Promise<TaskCapabilityLaunch>{
    let current=selected.current;
    if(!current){
      current=await this.sessions.create(this.createLibrarySnapshot(input,native.version,selected.adapterHash),input.home);
      await this.sessions.addLegacyRuntimeReference(input.taskId,current.pointer.snapshotHash,this.capabilities.runtimeIdentity().hash);
    }
    const snapshot=current.snapshot,stored=current;
    // M10 rule kept in R1.0: while a stop-before-switch connection change is pending, no run of the project forks.
    let frozenSkills:FrozenPluginSkillSet|undefined,frozenPolicy:CliSandboxPlan|undefined;
    const gate=()=>{if(frozenPolicy){if('runner'in frozenPolicy)verifyClaudeCliSandbox(frozenPolicy);else verifyCodexCliSandbox(frozenPolicy);}assertNoPendingApplicationSwitch(this.support.store,{projectId:input.projectId,packages:this.selectedApps(input.projectId)});if(frozenSkills){this.pluginSkills!.verify(frozenSkills);if(snapshot.schema===3&&canonicalJson(this.applications.plugins?.selections(input.projectId)??[])!==canonicalJson(snapshot.externalPlugins??[]))throw new ApplicationError('RESOURCE_STATE_CHANGED','启动前插件或连接选择已变化，请重新启动');}};gate();
    this.syncSkillLibrary(input.profile.runner==='claude'?input.stateRoot:undefined);
    await this.configureCli(input,native,snapshot);
    const checkedPolicy=this.planningCliPolicies.get(input.taskId);if(checkedPolicy?.available)frozenPolicy=checkedPolicy;
    if(this.support.adapters.versionSupport(snapshot.adapterBinding.hash,native.version)==='unsupported')return this.prepareUnavailableSession(input,stored,native,'AGENT_ADAPTER_UNSUPPORTED');
    const bridgeReady=!snapshot.mcp.some(m=>m.kind==='applications')||await(this.options.probeApplicationRuntime?.(input.signal)??this.embeddedNode.check(input.signal));
    const run=await this.runs.reserve({taskId:input.taskId,snapshotHash:stored.pointer.snapshotHash,bindings:this.applications.builtinPreferences.capture(input.projectId),bindingMode:'run'}),entry:ActiveLaunch={run};this.active.set(run.runId,entry);
    try{
      const legacy=(await this.sessions.references(input.taskId)).filter(r=>r.refKind==='legacy-runtime');if(legacy.length!==1)throw new ApplicationError('RESOURCE_RECOVERY_REQUIRED','原启动资源身份缺失或重复');
      // A user MCP, Skill or native tool already holding one of our names keeps the user's entry; ours is not mounted.
      const facets=nativeCapabilityConflicts(snapshot,native,undefined,this.support.adapters.deliveryAdapters),appConflict=facets.applications.size>0;
      const projectMcp=snapshot.mcp.find(m=>m.kind==='legacy-project-context'),mcpName=projectMcp&&!facets.projectMcp&&this.capabilities.enabled(input.projectId,MCP_CAPABILITY)?projectMcp.serverName:null;
      await run.prepare();
      const runtime=this.capabilities.prepare({projectId:input.projectId,taskId:input.taskId,runner:input.profile.runner,cwd:input.cwd,home:input.home,profileArgs:input.profile.args,previous:input.previous,managed:{runId:run.runId,runtimeHash:legacy[0].refHash,mcpName}});entry.runtime=runtime;runtime.snapshot.sessionCapabilities=stored.pointer;
      const issues=[...(bridgeReady?[]:['HOST_INCOMPATIBLE']),...(appConflict||facets.projectMcp?['AGENT_CAPABILITY_NAME_CONFLICT']:[])];
      if(issues.length)runtime.snapshot.selfCheck={status:'failed',issues:[...new Set([...runtime.snapshot.selfCheck.issues,...issues])],at:Date.now()};
      const planned=this.runs.bridgePreparation(run.runId).plan;if(!planned)throw new ApplicationError('RESOURCE_RECOVERY_REQUIRED','本次运行身份记录缺失');
      const mcp=snapshot.mcp.filter(m=>m.kind==='applications'?bridgeReady&&!appConflict:m.serverName===mcpName).map(m=>({kind:m.kind,serverName:m.serverName,command:m.kind==='applications'?process.execPath:'python3',args:m.kind==='applications'?[join(this.support.store.root,'runtime',m.runtimeHash,'mcp-bridge.cjs'),'--bootstrap',join(this.support.store.root,'pending-bootstrap.json')]:[join(this.support.store.root,'runtime',m.runtimeHash,'context_mcp.py'),join(this.support.store.root,'runs',input.projectId,input.taskId,run.runId,'context.json')],env:m.kind==='applications'?{ELECTRON_RUN_AS_NODE:'1'}:{} as Record<string,string>}));
      const policy=this.planningCliPolicies.get(input.taskId);let cliEnvironment:Readonly<Record<string,string>>|undefined,cliSandbox:NonNullable<import('@shared/agent-adapters').LibraryLoadRequest['cliSandbox']>|undefined;
      if(planned.grades.cli&&this.cli&&policy?.available){
        cliSandbox='runner'in policy?{runner:'claude-code',endpoint:this.cli.endpoint,kind:policy.kind,source:policy.source,digest:policy.digest}:{endpoint:this.cli.endpoint,kind:policy.kind,parent:policy.parent,networkProxy:policy.networkProxy,enableNetwork:policy.enableNetwork,existingNames:policy.existingNames,source:policy.source,digest:policy.digest};
        cliEnvironment=this.cli.issue(run).environment;runtime.secretValues.push(cliEnvironment.WILLYOU_RUN_TOKEN);
      }
      const bridgeEntry=mcp.find(m=>m.kind==='applications');let bridge:Awaited<ReturnType<PrivateApplicationBroker['prepare']>>|undefined;
      if(bridgeEntry){bridge=await this.broker.prepare(run,bridgeEntry.serverName);bridgeEntry.args[2]=bridge.bootstrapPath;}
      const profileArgs=cliEnvironment&&policy?.available&&!('runner'in policy)?codexProfileArgsForCli(input.profile.args,policy,native.version):input.profile.args;
      let clientProfileArgs:string[]|undefined;
      const launchEnvironment=cliEnvironment?{...runtime.env,...cliEnvironment,PATH:dirname(this.options.cliPath!)+delimiter+(input.environment.PATH??'')}:runtime.env;
      // A plan the adapter still refuses (another collision, unsupported mechanism) leaves the ordinary Agent: native only.
      let plan:import('@shared/agent-adapters').AgentLoadPlan|undefined,planIssue:'AGENT_ADAPTER_UNSUPPORTED'|'AGENT_CAPABILITY_NAME_CONFLICT'|undefined;
      try{plan=this.support.adapters.planLibrary(snapshot.adapterBinding.hash,{snapshot,runId:run.runId,cliVersion:native.version,currentExecutable:process.execPath,native:{...snapshot.native,runner:snapshot.runner,home:input.home},inventory:native.inventory,planHash:planned.planHash,...(cliSandbox?{cliSandbox}:{}),mcp});
        if((snapshot.runner==='claude-code'||snapshot.runner==='codex'&&native.version==='0.167.1')&&this.pluginSkills&&bridgeReady&&!appConflict){const set=this.pluginSkills.describe(snapshot,run.runId,this.cliAvailability(input.taskId));if(canonicalJson(set?.skills??[])!==canonicalJson(planned.skills))throw new ApplicationError('RESOURCE_STATE_CHANGED','插件 Skill 来源在准备期间已变化');if(set){this.pluginSkills.checkNative(set,native);this.pluginSkills.materialize(set);frozenSkills=set;
          if(snapshot.runner==='claude-code')plan.args.push(...set.claudeRoots.flatMap(root=>['--plugin-dir',root]));
          else{const request:CodexTaskServerRequest={task:input,native,run,skills:set,profileArgs:[...profileArgs],managedArgs:[...plan.args],environment:{...launchEnvironment},storeId:this.support.store.storeId};entry.codex=await(this.options.prepareCodexServer?.(request)??prepareCodexTaskServer(request,this.backends,this.processes));const client=codexClientArgs(profileArgs,plan.args,input.mode==='resume');clientProfileArgs=client.profile;plan.args=[...client.managed,'--remote',entry.codex.url];}
        }}
      }
      catch(error){if(error instanceof ApplicationError&&(error.code==='AGENT_ADAPTER_UNSUPPORTED'||error.code==='AGENT_CAPABILITY_NAME_CONFLICT'))planIssue=error.code;else throw error;}
      if(bridgeEntry&&plan)this.registerBridgeRecovery(run,bridgeEntry.serverName,snapshot.adapterBinding.hash,native.version);
      const configPaths:string[]=[],root=dirname(runtime.snapshot.manifestPath);
      for(const[name,text]of Object.entries(plan?.files??{})){mkdirSync(root,{recursive:true,mode:0o700});writeFileSync(join(root,name),text,{flag:'wx',mode:0o600});configPaths.push(join(root,name));}
      try{await this.applications.sessionDiagnostics.prepared({schema:2,capabilities:nativeCapabilityPreparation(snapshot,planIssue?{applications:[],standardPaths:[],mcpNames:[],issue:planIssue}:{applications:appConflict?[]:snapshot.packages.map(p=>p.appId),standardPaths:[],mcpNames:runtime.snapshot.mcp.map(m=>m.name).filter(name=>name===mcpName||name!==projectMcp?.serverName),facets,...(bridgeReady?{}:{applicationIssue:'HOST_INCOMPATIBLE'}),projectMcpEnabled:this.capabilities.enabled(input.projectId,MCP_CAPABILITY)}),runId:run.runId,selectionHash:stored.selectionHash,cliVersion:native.version,adapterHash:snapshot.adapterBinding.hash,state:planIssue?'unavailable':'prepared',issueCode:planIssue??null,manifestPath:runtime.snapshot.manifestPath,configPaths,preparedAt:new Date().toISOString()});}catch{/* Display evidence never grants capability or blocks the Agent. */}
      if(this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','任务能力准备已取消');
      try{this.applications.nativeMessages.register(run.runId,native.version,run.signal);}catch{/* Missing origin evidence grants nothing. */}
      let phase:'prepared'|'restricting'|'native-only'|'arming'='prepared',effective=true,prepared=runtime;
      const narrow=async(reason:string,cause?:ManagedCapabilityRestriction):Promise<TaskCapabilityLaunch>=>{
        if(phase!=='prepared'||this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','此启动不能再撤去应用注入');
        phase='restricting';this.broker.revokeRun(run.runId);this.cli?.revokeRun(run.runId);await entry.codex?.stop();await bridge?.bridge.cancelBeforeLaunch();
        await this.runs.restrictToNative(run.runId,cause);effective=false;prepared.release();prepared=this.unavailableRuntime(input,stored,run.runId,cause?.issueCode??'AGENT_ADAPTER_UNSUPPORTED');
        prepared.snapshot.selfCheck?.issues.push(reason);entry.runtime=prepared;launch.runtime=prepared;launch.args=[];launch.profileArgs=undefined;launch.env={};launch.initialInput=undefined;phase='native-only';return launch;
      };
      const launch:TaskCapabilityLaunch={ptyId:run.ptyId,runtime,args:plan?.args??[],profileArgs:clientProfileArgs??(cliEnvironment&&policy?.available?profileArgs:undefined),env:launchEnvironment,command:native.command,
        ...(entry.codex?.initializationProcess?{codexInitializer:()=>entry.codex!.initializationProcess!()}:{}),
        assertBeforeFork:()=>{if(effective)gate();},
        nativeOnly:reason=>narrow(reason),
        beforeSpawn:async()=>{if(this.closed||input.signal.aborted||!['prepared','native-only'].includes(phase))throw new ApplicationError('CANCELED','启动已取消或窗口已使用');const nativeOnly=phase==='native-only';if(effective)gate();phase='arming';if(!nativeOnly&&effective){await entry.codex?.start();gate();await bridge?.bridge.arm();}await run.cli.arm();},
        spawned:async pid=>{await run.cli.attach(pid??0);if(effective)this.skillObservations.start(input.taskId,run.runId,run.signal);},
        initialInput:(sender,text)=>this.applications.nativeInputs.observeLaunch(sender,{taskId:input.taskId,ptyId:run.ptyId},text),
        cancelBeforeFork:async()=>{if(entry.codex){await run.cli.cancelUnforked!();await run.stop('native-fork-not-attempted');await entry.codex.stop();}else await run.cancelBeforeFork();await this.releaseStopped(entry);},spawnFailed:()=>run.stop('native-fork-error').then(()=>this.releaseStopped(entry)),exited:()=>run.cli.exited().then(()=>this.releaseStopped(entry)),stop:reason=>this.stopWithSkillHistory(input.taskId,entry,reason),
        bindNative:async id=>{const known=await this.sessions.get(input.taskId),bound=await this.sessions.bindNativeSession(input.taskId,known.pointer.snapshotHash,{...snapshot.native,runner:snapshot.runner,sessionId:id});prepared.snapshot.sessionCapabilities=bound.pointer;if(effective)this.skillObservations.start(input.taskId,run.runId,run.signal);}};
      return planIssue?narrow(planIssue,{reason:'managed_capabilities_unavailable',issueCode:planIssue}):launch;

    }catch(error){await run.stop('prepare-failed').catch(()=>{});await this.releaseStopped(entry);throw error;}
  }
  private async prepareUnavailableSession(input:TaskLaunchInput,current:StoredCapabilitySession,native:NativeLaunchContext|undefined,unavailable:string|undefined):Promise<TaskCapabilityLaunch>{
    const snapshot=current.snapshot,adapter=this.support.adapters.get(snapshot.adapterBinding.hash);
    const run=await this.runs.reserveFixedNativeGuard({taskId:input.taskId,projectId:input.projectId,runner:snapshot.runner,snapshotHash:current.pointer.snapshotHash,resourceIds:[`agent-adapter:${snapshot.runner}:${snapshot.adapterBinding.hash}`],...(snapshot.legacyBinding||unavailable?{restriction:{reason:'managed_capabilities_unavailable' as const,issueCode:unavailable==='AGENT_ADAPTER_UNSUPPORTED'||unavailable==='AGENT_CAPABILITY_NAME_CONFLICT'?unavailable:'RESOURCE_RECOVERY_REQUIRED' as const}}:{}),verify:async()=>{
      this.support.adapters.verify(snapshot.adapterBinding.hash);
      if(!input.newTask)await this.sessions.verifyNativeIdentity(input.taskId,{runner:snapshot.runner,stateRoot:input.stateRoot,cwd:input.cwd,sessionId:input.sessionId,home:input.home});
    }}),entry:ActiveLaunch={run};this.active.set(run.runId,entry);
    try{
      await run.prepare();
      const issue=snapshot.legacyBinding?unavailable??'RESOURCE_RECOVERY_REQUIRED':unavailable??'CAPABILITY_UNAVAILABLE',runtime=this.unavailableRuntime(input,current,run.runId,issue);if((!native||!adapter.metadata.cliVersions.includes(native.version))&&!runtime.snapshot.selfCheck?.issues.includes('AGENT_ADAPTER_UNSUPPORTED'))runtime.snapshot.selfCheck?.issues.push('AGENT_ADAPTER_UNSUPPORTED');entry.runtime=runtime;
      if(this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','原会话原生启动已取消');
      try{await this.applications.sessionDiagnostics.prepared({schema:2,capabilities:nativeCapabilityPreparation(snapshot,{applications:[],standardPaths:[],mcpNames:[],issue}),runId:run.runId,selectionHash:current.selectionHash,cliVersion:native?.version??null,adapterHash:snapshot.adapterBinding.hash,state:'unavailable',issueCode:issue,manifestPath:runtime.snapshot.manifestPath,configPaths:[],preparedAt:new Date().toISOString()});}catch{/* Display evidence grants nothing. */}
      let phase:'prepared'|'native-only'|'arming'='prepared';
      const launch:TaskCapabilityLaunch={ptyId:run.ptyId,runtime,args:[],env:{},command:native?.command,assertBeforeFork:()=>{},nativeOnly:async reason=>{
        if(phase!=='prepared'||this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','原生启动窗口已使用');
        launch.args=[];runtime.snapshot.selfCheck?.issues.push(reason);phase='native-only';return launch;
      },beforeSpawn:async()=>{if(this.closed||input.signal.aborted||!['prepared','native-only'].includes(phase))throw new ApplicationError('CANCELED','原会话启动已取消或窗口已使用');phase='arming';await run.cli.arm();},spawned:pid=>run.cli.attach(pid??0),cancelBeforeFork:()=>run.cancelBeforeFork().then(()=>this.releaseStopped(entry)),spawnFailed:()=>run.stop('native-fork-error').then(()=>this.releaseStopped(entry)),exited:()=>run.cli.exited().then(()=>this.releaseStopped(entry)),stop:reason=>run.stop(reason).then(()=>this.releaseStopped(entry)),bindNative:async id=>{const known=await this.sessions.get(input.taskId),bound=await this.sessions.bindNativeSession(input.taskId,known.pointer.snapshotHash,{...snapshot.native,runner:snapshot.runner,sessionId:id});runtime.snapshot.sessionCapabilities=bound.pointer;}};
      return launch;
    }catch(error){await run.stop('unavailable-prepare-failed').catch(()=>{});await this.releaseStopped(entry);throw error;}
  }
  private async prepareNativeHistory(input:TaskLaunchInput,native:NativeLaunchContext|undefined,unavailable:string|undefined):Promise<TaskCapabilityLaunch>{
    const runner:string=this.support.adapters.deliveryAdapters.forRunner(input.profile.runner).id,adapter=this.libraryAdapter(runner,native?.version);if(!adapter)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','缺少原生历史隔离所需适配资源');
    // A native-only guard grants no application bridge and keeps the native argv/config untouched.
    const nativeUnverified=Boolean(!native||unavailable||!this.support.adapters.get(adapter.hash).metadata.cliVersions.includes(native.version));
    const record=this.support.store.sqlite.prepare("SELECT snapshot_hash AS hash FROM capability_session_snapshots WHERE task_id=? AND schema_version=0 AND retention_state='hold'").get(input.taskId) as {hash:string}|undefined;if(!record)throw new ApplicationError('SESSION_ON_HOLD','缺少原历史保留依据');
    const run=await this.runs.reserveNativeGuard({taskId:input.taskId,projectId:input.projectId,runner,snapshotHash:record.hash,resourceIds:[`agent-adapter:${runner}:${adapter.hash}`],verify:async()=>{this.support.adapters.verify(adapter.hash);}}),entry:ActiveLaunch={run};this.active.set(run.runId,entry);
    try{
      await run.prepare();
      const check:RuntimeSnapshot['selfCheck']={status:'failed',issues:['HISTORY_CAPABILITIES_UNKNOWN',...(nativeUnverified?['AGENT_ADAPTER_UNSUPPORTED']:[])],at:Date.now()},runtime:PreparedRuntime={persistSnapshot:false,args:[],env:{},secretValues:[],snapshot:{runId:run.runId,projectId:input.projectId,configVersion:input.previous?.configVersion??0,configHash:record.hash,manifestPath:input.previous?.manifestPath??join(this.support.store.root,'sessions',input.taskId,'snapshot.json'),auditPath:input.previous?.auditPath??join(this.support.store.root,'resource-audit',input.projectId,input.taskId+'.jsonl'),skills:[],mcp:[],selfCheck:check},wrap:(command,argv)=>({command,args:argv}),check:()=>check,release:()=>{}};entry.runtime=runtime;
      if(this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','原生历史启动已取消');
      let phase:'prepared'|'native-only'|'arming'='prepared';
      const launch:TaskCapabilityLaunch={ptyId:run.ptyId,runtime,args:[],env:{},command:native?.command,assertBeforeFork:()=>{},nativeOnly:async reason=>{
        if(phase!=='prepared'||this.closed||input.signal.aborted)throw new ApplicationError('CANCELED','原生历史启动窗口已使用');
        await this.runs.restrictToNative(run.runId);launch.args=[];for(const issue of ['AGENT_ADAPTER_UNSUPPORTED',reason])if(!check.issues.includes(issue))check.issues.push(issue);phase='native-only';return launch;
      },beforeSpawn:async()=>{if(this.closed||input.signal.aborted||!['prepared','native-only'].includes(phase))throw new ApplicationError('CANCELED','原生历史启动已取消或窗口已使用');phase='arming';await run.cli.arm();},spawned:pid=>run.cli.attach(pid??0),cancelBeforeFork:()=>run.cancelBeforeFork().then(()=>this.releaseStopped(entry)),spawnFailed:()=>run.stop('native-fork-error').then(()=>this.releaseStopped(entry)),exited:()=>run.cli.exited().then(()=>this.releaseStopped(entry)),stop:reason=>run.stop(reason).then(()=>this.releaseStopped(entry))};
      return launch;
    }catch(error){await run.stop('history-prepare-failed').catch(()=>{});await this.releaseStopped(entry);throw error;}
  }
  private unavailableRuntime(input:TaskLaunchInput,current:StoredCapabilitySession,runId:string,code:string):PreparedRuntime{
    const check:RuntimeSnapshot['selfCheck']={status:'failed',issues:[code],at:Date.now()};
    return{args:[],env:{},secretValues:[],snapshot:{runId,projectId:input.projectId,configVersion:input.previous?.configVersion??0,configHash:current.selectionHash,manifestPath:join(this.support.store.root,'sessions',input.taskId,'snapshot.json'),auditPath:join(this.support.store.root,'resource-audit',input.projectId,input.taskId+'.jsonl'),skills:[],mcp:[],selfCheck:check,sessionCapabilities:current.pointer},wrap:(command,args)=>({command,args}),check:()=>check,release:()=>{}};
  }
  private registerBridgeRecovery(run:OwnedCapabilityRun,server:string,adapterHash:string,cliVersion:string):void {
    const recovery=this.support.adapters.recovery(adapterHash,cliVersion);
    const authorize=()=>{
        if(run.signal.aborted||this.closed||this.runs.get(run.runId).state!=='active')throw new ApplicationError('CANCELED','原运行已停止');
        const context=this.runs.bridgePreparation(run.runId);
        // Shared transport may recover for a still-enabled original application, never an added one.
        const permitted=context.snapshot.packages;
        const eligible=permitted.some(pack=>this.support.store.sqlite.prepare('SELECT 1 FROM application_catalog_state c JOIN application_project_settings p ON p.app_id=c.app_id WHERE c.app_id=? AND p.project_id=? AND c.added=1 AND c.enabled=1 AND p.enabled=1 AND p.pending_operation_id IS NULL').get(pack.appId,context.snapshot.projectId));
        if(!eligible)throw new ApplicationError('SCOPE_DENIED','原运行应用已停用或正在变更，不能重新签发工具通道');
      };
    this.bridgeRecovery.register(run.runId,server,{
      capability:recovery.capability,evidence:recovery.evidence,
      validate:async()=>authorize(),
      ...(recovery.replace?{replace:async(attempt:{instanceId:string;generation:number;signal:AbortSignal})=>{
        const prepared=await this.broker.prepare(run,server,authorize);let connected=false;
        const cancel=()=>{this.bridges.revokeBridge(run.runId,prepared.bridge.processId);return prepared.cancel().catch(()=>undefined);};
        const aborted=()=>{void cancel();};attempt.signal.addEventListener('abort',aborted,{once:true});
        try{
          if(attempt.signal.aborted)return false;
          await prepared.bridge.arm();
          if(attempt.signal.aborted)return false;
          const handshake=this.broker.waitForAuthentication(run.runId,prepared.bridge.processId,attempt.signal);
          await recovery.replace!({runId:run.runId,serverName:server,bridgeInstanceId:prepared.bridge.processId,generation:attempt.generation,bootstrapPath:prepared.bootstrapPath,signal:attempt.signal});
          const authenticated=await handshake;authorize();connected=authenticated;
          return connected&&!attempt.signal.aborted;
        }finally{attempt.signal.removeEventListener('abort',aborted);if(!connected||attempt.signal.aborted)await cancel();}
      }}:{}),
    });
    this.recoveryServices.set(run.runId,server);
  }
  private bridgeDisconnected(runId:string):void {
    const server=this.recoveryServices.get(runId),entry=this.active.get(runId);
    if(!server||!entry||entry.run.signal.aborted||this.closed||this.broker.hasAuthenticated(runId))return;
    const state=this.bridgeRecovery.inspect(runId,server);if(!state||state.revoked)return;
    if(state.result?.code==='CONNECTED')this.bridgeRecovery.beginRecovery(runId,server,state.generation,'disconnected');
    const generation=this.bridgeRecovery.inspect(runId,server)!.generation;
    // Unsupported native versions report unavailable; never stop/resume their Agent.
    void this.bridgeRecovery.prepareReplacement(runId,server,generation);
  }
  private stopWithSkillHistory(taskId:string,entry:ActiveLaunch,reason?:string):Promise<void>{
    const previous=this.stopping.get(entry.run.runId);if(previous)return previous;
    const finish=this.applications.sessionDiagnostics.prepareStop(taskId,entry.run.runId);
    const work=(async()=>{try{await entry.run.stop(reason);}finally{await finish();}await this.releaseStopped(entry);})();
    this.stopping.set(entry.run.runId,work);
    void work.finally(()=>{if(this.stopping.get(entry.run.runId)===work)this.stopping.delete(entry.run.runId);}).catch(()=>{});
    return work;
  }
  private releaseStopped(entry:ActiveLaunch):Promise<void>{if(this.runs.get(entry.run.runId).state!=='stopped')return Promise.resolve();if(entry.releasing)return entry.releasing;const work=(async()=>{await entry.codex?.stop();if(entry.codex?.recoveryWarnings.length)this.recoveryWarnings.push({homeId:'codex-server:'+entry.run.runId,code:'RESOURCE_RECOVERY_REQUIRED'});entry.runtime?.release();try{this.pluginSkills?.release(entry.run.runId);}catch(error){this.recoveryWarnings.push({homeId:'plugin-skills:'+entry.run.runId,code:error instanceof ApplicationError?error.code:'RESOURCE_RECOVERY_REQUIRED'});}const server=this.recoveryServices.get(entry.run.runId);if(server)this.bridgeRecovery.release(entry.run.runId,server);this.recoveryServices.delete(entry.run.runId);this.active.delete(entry.run.runId);})();entry.releasing=work;void work.catch(()=>{entry.releasing=undefined;});return work;}
  async recoverAgentRun(runId: string) {
    const row = this.support.store.sqlite.prepare('SELECT binding_id FROM capability_runs WHERE run_id=?').get(runId) as { binding_id: string | null } | undefined;
    if (!row?.binding_id) throw new ApplicationError('SCOPE_DENIED', '不是 M14 的原运行');
    return this.runs.recover(runId);
  }
  private async sweep():Promise<void>{if(this.sweeping)return;this.sweeping=true;try{await Promise.allSettled([...this.active.values()].map(entry=>this.releaseStopped(entry)));}finally{this.sweeping=false;}}
  tombstone(taskId:string):Promise<void>{return this.sessions.tombstone(taskId);}
  activeTaskIds(projectId:string):ReadonlySet<string>{return new Set((this.support.store.sqlite.prepare("SELECT task_id AS id FROM capability_runs WHERE project_id=? AND state NOT IN ('stopped','failed')").all(projectId) as {id:string}[]).map(r=>r.id));}
  dispose():Promise<void>{if(this.closing)return this.closing;this.closed=true;this.skillObservations.close();clearInterval(this.timer);this.closing=(async()=>{await Promise.allSettled([...this.pending]);const finishes=[...this.active.values()].filter(entry=>!this.stopping.has(entry.run.runId)).map(entry=>this.applications.sessionDiagnostics.prepareStop(this.runs.get(entry.run.runId).taskId,entry.run.runId));const results=await Promise.allSettled([...this.stopping.values(),this.runs.dispose(),this.bridges.dispose(),this.backends.dispose(),this.broker.close(),...(this.cli?[this.cli.close()]:[])]);await Promise.allSettled(finishes.map(finish=>finish()));const deadline=performance.now()+2000;do{await this.sweep();if(!this.active.size)break;await new Promise<void>(done=>setTimeout(done,10));}while(performance.now()<deadline);if(results.some(result=>result.status==='rejected'))throw new ApplicationError('RUN_STOP_FAILED','部分运行关闭尚未完成；私有通道已撤销，未知占用继续保留');})();return this.closing;}
}
