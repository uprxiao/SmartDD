from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'joint.sql';t=p.read_text().replace('target_revision INTEGER NOT NULL);','target_revision INTEGER NOT NULL,attempt_id TEXT REFERENCES m14_attempt(id));')
t=t.replace('request_key TEXT PRIMARY KEY REFERENCES m14_outbox(id)','request_key TEXT PRIMARY KEY REFERENCES m14_attempt(id)')
t+='''
CREATE TABLE m14_attempt(id TEXT PRIMARY KEY,effect_id TEXT NOT NULL REFERENCES m14_outbox(id),number INTEGER NOT NULL CHECK(number>0),run_id TEXT UNIQUE REFERENCES capability_runs(run_id),owner_instance TEXT,owner_pid INTEGER,owner_started_at TEXT,target_profile_id TEXT NOT NULL,target_revision INTEGER NOT NULL,state TEXT NOT NULL CHECK(state IN ('pending','owned','closed-unforked','unknown')),UNIQUE(effect_id,number));
CREATE TABLE m14_attempt_recovery(attempt_id TEXT NOT NULL REFERENCES m14_attempt(id),claim TEXT NOT NULL,decision TEXT NOT NULL,next_attempt_id TEXT REFERENCES m14_attempt(id),owner_pid INTEGER NOT NULL,owner_started_at TEXT NOT NULL,PRIMARY KEY(attempt_id,claim));
''';p.write_text(t)
p=r/'joint.mjs';t=p.read_text();t="import {claimEffect} from './recovery.mjs';\n"+t
old=".run(effectId,delegationId,profile.id,input.revision);";new=old+"\n  f.sqlite.prepare(\"INSERT INTO m14_attempt(id,effect_id,number,target_profile_id,target_revision,state) VALUES(?,?,1,?,?,'pending')\").run(effectId,effectId,profile.id,input.revision);f.sqlite.prepare('UPDATE m14_outbox SET attempt_id=? WHERE id=?').run(effectId,effectId);";assert old in t;t=t.replace(old,new)
start=t.index('export function claim(');end=t.index('\nexport function childSnapshot',start);t=t[:start]+"export const claim=(f,id)=>claimEffect(f,id);"+t[end:]
t=t.replace('reserveProgrammaticOnce(id,row.claim,','reserveProgrammaticOnce(row.attempt_id,row.claim,');p.write_text(t)
p=r/'run-registry.ts.variant';t=p.read_text();old="SELECT o.*,d.child_task,t.binding_id FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id WHERE o.id=?";new="SELECT o.*,d.child_task,t.binding_id FROM m14_attempt a JOIN m14_outbox o ON o.id=a.effect_id AND o.attempt_id=a.id JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id WHERE a.id=?";assert old in t;t=t.replace(old,new)
old="UPDATE m14_outbox SET state='reserved',run_id=? WHERE id=? AND state='claimed' AND claim=?";new="UPDATE m14_outbox SET state='reserved',run_id=? WHERE attempt_id=? AND state='claimed' AND claim=?";assert old in t;t=t.replace(old,new)
old="if(changed.changes!==1)throw new ApplicationError('SCOPE_DENIED','EFFECT_RESERVATION_CONFLICT');";new=old+"this.store.sqlite.prepare('UPDATE m14_attempt SET run_id=? WHERE id=?').run(runId,request.key);";assert old in t;t=t.replace(old,new);p.write_text(t)
p=r/'execution.mjs';t=p.read_text().replace("SELECT target_profile_id,target_revision FROM m14_outbox WHERE run_id=?","SELECT target_profile_id,target_revision FROM m14_attempt WHERE run_id=?");p.write_text(t)
