import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {connect} from './connect.mjs';
import {claim,childSnapshot,prepareChild} from './joint.mjs';
import {recoverEffect,state} from './recovery.mjs';
const [specPath,id,mode,point]=process.argv.slice(2),f=connect(JSON.parse(readFileSync(specPath)));
process.on('message',()=>{});process.send({ready:true,pid:process.pid,identity:f.reader.read(process.pid),registry:f.programmaticRuns.instanceId});await new Promise(r=>process.once('message',r));
const hold=async reached=>{process.send({reached,effect:state(f,id)});await new Promise(()=>{});};
try{
 if(mode==='recover'){const result=await recoverEffect(f,id,point);process.send({result});f.sqlite.close();process.disconnect();}
 else{
  const row=claim(f,id),snapshot=childSnapshot(f,row),scope=await f.programmaticSessions.createProgrammatic(row.binding_id,snapshot,f.home);if(point==='after-publication')await hold(point);
  const run=await f.programmaticRuns.reserveProgrammaticOnce(row.attempt_id,row.claim,{...scope,bindings:[]});f.handles.push(run);if(point==='after-reservation')await hold(point);
  const prepared=await prepareChild(f,id);assert.equal(prepared.child.run,run);if(point==='after-plan')await hold(point);
  f.sqlite.prepare("UPDATE m14_outbox SET state='dispatching' WHERE id=?").run(id);await run.cli.arm();if(point==='after-arm')await hold(point);
  if(point==='after-process-exit'){
   const child=spawn('/bin/sh',['-c','read -r line'],{stdio:['pipe','ignore','ignore']});const exited=new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',(code,signal)=>resolve({pid:child.pid,code,signal}));});process.send({ownedChildSpawn:child.pid});
   try{const identity=f.reader.read(child.pid);assert(identity);await run.cli.attach(identity.pid,identity.startedAt);child.stdin.end('done\n');const exit=await exited;await run.cli.exited();await run.stop('harmless-owned-child-exit');assert.equal(f.reader.state(identity),'stopped');process.send({ownedChildExit:exit});}finally{if(child.exitCode===null&&child.signalCode===null){child.kill('SIGTERM');await exited;}}
   await hold(point);
  }
  throw Error('UNKNOWN_CHECKPOINT');
 }
}catch(e){process.send({error:e.stack});for(const h of f.handles)await h.stop('worker-error');f.sqlite.close();process.exitCode=1;process.disconnect();}
