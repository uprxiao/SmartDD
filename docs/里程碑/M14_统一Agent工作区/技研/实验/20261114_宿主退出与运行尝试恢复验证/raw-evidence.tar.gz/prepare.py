from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_宿主退出与运行尝试恢复验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==11 and not result.get('error');attempt=Path(result['out']);assert json.loads((attempt/'result.json').read_text())==result
sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[s['path']]=s
 for o in b.get('outputs',[]):
  assert sha(Path(o['file']).read_bytes())==o['sha256'];assert sha((attempt/Path(o['file']).name).read_bytes())==o['sha256']
  for p in o.get('patches',[]):assert sha(Path(p['path']).read_bytes())==p['beforeHash'];assert sha((root/(Path(p['path']).name+'.variant')).read_bytes())==p['afterHash']
for n in ['probe.mjs','worker.mjs','connect.mjs','recovery.mjs','joint.mjs','joint.sql','execution.mjs','candidate.cjs','profile.cjs']:assert (root/n).read_bytes()==(attempt/n).read_bytes(),n
negative=json.loads((root/'baseline-negative.json').read_text());assert negative['status']=='reproduced' and negative['attemptOwner']!=negative['runOwner']
runtime=json.loads((root/'runtime-audit.json').read_text());assert len(runtime['attempts'])==3;assert sum(a['killedWorkers']for a in runtime['attempts'])==20
refs=[(repo,'src/main/core/applications/run-recovery.ts'),(repo,'src/main/core/applications/run-registry.ts'),(repo,'src/main/core/applications/resource-lock.ts'),(t3,'apps/server/src/orchestration-v2/EffectOutbox.ts'),(t3,'apps/server/src/orchestration-v2/ProviderRuntimeRecoveryService.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,p in refs],'scope':'Actual recovery and process identities with isolated multi-attempt queue/schema/source variants; T3 source review only. Original run recovery has not been modified.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('baseline-negative.json',json.dumps(negative,indent=2)),('runtime-audit.json',json.dumps(runtime,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2))]:put(exp/n,data)
put(exp/'README.md',f'''# 宿主退出与独立运行尝试：隔离技术验证

日期：2026-11-14。对应 R02／06／08／10，Q04／13／24／48；技术方案 §7.1.2，验证账 §4.46。当前仍是设计和独立验证，不是产品开发或产品验收。

## 解决的问题

前批子创建→能力发布→直接预留→宿主计划→原生初始化只验证同进程重试，一 effect 一 run 的候选无法安全表达宿主退出后的下一运行。本批增加独立 attempt：稳定逻辑 child／delegation／effect 保持，尝试记录编号、owner、目标修订及原 run。当前队列只指向当前 attempt；历史 run 请求、计划和回执保留。实际 SmartDD run recovery 先处理旧 owner／进程／租约，再由候选根据是否确实未启动决定是否分配下一 attempt。

在同一临时 SQLite／资源根下，真实子宿主重新连接当前实际组件。各 worker 的 PID 和内核出生身份来自实际 MacProcessIdentityReader，主驱动只 SIGKILL 自己捕获的 ChildProcess。子目录均独立，不验证 SVN 共享写入策略。

## 结果

最终 `{attempt.name}` 的 C01–C11 通过：十个宿主 worker 被 SIGKILL，两个并发恢复 worker 正常退出，一个真实父 Codex 和一个恢复后的子 Codex 完成初始化并退出，另有一个用于反例的无害 shell 子进程已退出。三轮留存合计二十个 SIGKILL、四个正常恢复 worker、五个原生初始化退出及两个 shell 退出；数量不作为产品或全局研究通过数。

| 项 | 真实执行与结论 |
| --- | --- |
| C01 | 能力发布 COMMIT 后终止 worker；无 run，重新领取同 attempt、同 child／cap，不重复发布 |
| C02 | run／请求收据 COMMIT 后终止；实际 recovery 取消 reserved 进程、停止旧 run 并释放租约，原子创建 attempt 2；旧 claim 拒绝，新 run generation 为 2，旧请求记录保留 |
| C03 | ExecutionPlan／delivery COMMIT 后终止；旧 delivery abandoned、旧计划字节保留；下一尝试真实 Codex 初始化成功 |
| C04 | arm 后、无 PID 时终止；实际 recovery 保留 orphaned／recovery-required，候选记 unknown，无第二 attempt |
| C05 | 两个真实恢复进程同时处理同一死亡宿主；只产生一个下一 attempt 和一份恢复决策 |
| C06 | 宿主退出后换 Key；允许旧资源收尾，但不以新配置自动派发，不创建下一尝试 |
| C07 | 下一 attempt 插入后注入事务异常；队列指针／恢复收据／新 attempt 回滚，已完成的旧 run recovery 保留；再次对账只产生一次推进 |
| C08 | 原 worker 仍活着时拒绝接管；捕获并确认其退出后才允许恢复 |
| C09 | 显式夹具模拟 owner 观察 unknown 时保留状态；换回实际 reader 证明 stopped 后才能推进 |
| C10 | 真正启动、attach 并结束一个无害 shell，旧 run 已 stopped，再终止宿主；候选仍保留 unknown，不将 run stopped 当成从未执行 |
| C11 | 复制 claim token 给另一个 registry 不能预留运行；还须核对 attempt owner 的实例／PID／出生身份 |

`attempt-RnhFMP` 的原十项通过，但不含新增的 C11。扩展检查后 `attempt-Jp30uP` 复现：仅比较 claim token 时，另一 registry 成功创建了与 attempt owner 不同的 run。原数据库保存两份实际 owner ID；候选补完整 owner 核验后最终全批通过。这是研究候选缺口，不是生产缺陷。另保留 profile-build 漏拷贝 throwing node-pty stub 的准备失败；修复拷贝前没有启动实验或原生进程。

## 约束与参考

T3 EffectOutbox.claimNext 通过条件 UPDATE 领取并增加 attempt_count、记录 workerId；succeed 仍要求原 lease_owner。ProviderRuntimeRecoveryService 还按原生是否接受及消息来源筛选可恢复项，不把通用重试次数等同于外部操作恰好一次。WillYou 参考领取归属和分类恢复原则，继续使用自己的进程出生身份、资源租约和业务证据，不能仅复制重试计数。

原 run／资源恢复和队列推进是两个可重入阶段。第二阶段失败不撤销已经完成的资源收尾；下一次读取当前持久状态再推进。新 attempt／恢复决策／当前指针同事务提交，原 run、计划和目标事实不覆盖。目标修订固定到每次 attempt，旧计划读取通过旧 attempt 核对，不能只联查已经指向新 run 的 outbox。

只有 owner 确认死亡、旧 run 终态且已撤权、所有进程均为未派发取消且无 PID、无活动／历史调用活动记录、租约已释放、准备交付已放弃等证据同时满足，候选才允许下一尝试。已 armed 而无 PID、曾有实际子进程、来源不明或 owner 仍活跃都不自动重试。当前尚未用业务调用回执替代这些保守判据，不能扩大到已发送模型输入／外部写入。

## 范围和未决项

本批是 worker 的真实进程退出，父主驱动保持运行；不是整个 Electron App／操作系统重启。恢复后只执行 Codex 初始化，没有 Claude 原生恢复、thread/start、模型回合、Skill／业务 MCP 或外部写入。能力包、业务资源、凭据及加密器仍为隔离夹具。C10 的 shell 只等待 stdin 后退出，不是 Agent 工具执行的完整替代。

每轮故意保留 C04 的 armed 无 PID 数据和资源占用作为 unknown 证据，不通过清表／改终态强行释放；所有捕获 OS 进程均确认已退出。实际原生派发后失联、后台后代范围、首次 native ID 修订后的来源复用、业务在途调用和结果投递仍须分别对账，不能凭本轮未启动恢复推定已解决。

新的 attempt 表和 outbox 指针只存在临时 Schema，未实施旧实验格式或应用版本升级。真实迁移器、生产启动协调及持久事件投影未接入；没有修改实际 run-recovery.ts。

## 证据与复跑

[最终结果](result.json)、[有效 owner 负对照](baseline-negative.json)、[进程收尾与保留未知状态](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[全部轮次与数据库](raw-evidence.tar.gz)。归档 {len(files)} 个文件、{len(dbs)} 份 SQLite；完整性／外键通过，{len(sources)} 个构建输入复核。

在新临时目录恢复匹配依赖／源码与最终生成的 variant，依次成功运行 `node build.mjs`、`node profile-build.mjs`、`node probe.mjs`。最终 variant 已含 owner 修正，不重复套用 extend 脚本。使用归档的独立配置和合成凭据，不连接用户库；只管理本轮捕获的子进程。版本和程序 hash 见运行审计。
''')
section='''#### 7.1.2 宿主退出后的运行尝试与恢复

逻辑委派／子任务、队列 effect、运行 attempt 和 run 分别保留身份。每次 attempt 固定目标配置／修订、编号、领取 owner 和最终 run；outbox 指向当前 attempt，运行请求收据按 attempt 去重。旧 attempt／run／执行计划不随重试覆盖。原生首次身份、输入接受及业务回执仍独立记账，不将 attempt 编号当作原生幂等键。

领取既要核对 claim token，也要核对签发宿主实例、PID 和出生身份。预留 run 的实际 owner 必须与该 attempt 的 owner 一致；已复现只凭 token 会让另一 registry 预留出不同 owner 的负例。下一尝试的准备仍检查当前目标与业务政策，接受时修订失效则阻塞，不回退到最新默认配置。

| 宿主退出后的证据 | 恢复动作 |
| --- | --- |
| owner 仍活跃或内核观察未知 | 保留领取与资源，不接管 |
| 来源已发布、尚无 run，确认旧 owner 死亡 | 保留同 child／cap 和 attempt，记录原领取的恢复事实，再重新领取 |
| 旧 run 被实际 recovery 停止／撤权，所有进程确定未派发，资源及准备引用已释放 | 保留旧收据／run／计划，原子提交新 attempt、恢复决策和 outbox 指针；新 run 分配下一 generation |
| 已 arm 但无 PID／范围不明 | unknown，保留恢复所需占用，不按超时重新启动 |
| 有过实际进程或输入派发，即使 run 已 stopped | 停止仅证明生命周期收尾；按原生／业务回执对账，不自动视为从未执行 |
| 目标配置失效 | 旧运行仍可清理，新的派发阻塞并保留原选择 |

[实际宿主退出实验](实验/20261114_宿主退出与运行尝试恢复验证/README.md)把上述未启动分支接到真实进程身份、当前 run recovery、delivery 和新尝试：发布后／预留后／计划后／arm 后 SIGKILL、并发恢复、配置变化及事务失败取得限定证据，恢复后的新 run 完成 Codex 初始化。原 run 恢复与队列推进允许分阶段提交：第二阶段失败时，第一阶段已完成的资源收尾不回滚；重试读取持久事实，避免再次创建 attempt。旧计划按自己的 attempt 校验目标，不能联查已切到新 run 的队列当前指针。

本批保守的未派发证明要求所有进程为无 PID 的 canceled、无调用活动记录、run 终态且撤权、租约释放及准备交付放弃；并不覆盖完整 Agent 后代和业务写入。曾运行进程的反例保持 unknown，不能为了自动恢复而放宽判据。完整 App 重启、原生已接受后的恢复、首次 native 修订及业务在途仍须补证；候选新表不是应用迁移实现。

'''
def tech(t):
 old='崩溃恢复后若需要新的运行尝试，必须保留原 receipt／run 历史，在证明旧执行范围排空及是否派发后分配独立 attempt／generation，再原子关联队列；本批一 effect 一 run 的候选尚未实现此恢复协议。禁止删除旧收据、换 token 后直接重新启动。首次 native ID 已修订后的发布收据查询、完整业务桥及共享目录仍按各自缺口验证。'
 new='崩溃恢复后若需要新的运行尝试，必须保留原 receipt／run 历史，在证明旧执行范围排空及是否派发后分配独立 attempt／generation，再原子关联队列；一 effect 一 run 的早期候选不足以表达该协议。§7.1.2 已补独立 attempt 及实际宿主退出下的未启动恢复证据。禁止删除旧收据、换 token 后直接重新启动。首次 native ID 已修订后的发布收据查询、完整业务桥及共享目录仍按各自缺口验证。'
 assert old in t;t=t.replace(old,new);t=t.replace('真实宿主崩溃后的接管、下一运行尝试、首次 native 回调及业务桥仍待联合；不能以初始化成功声称完整恢复或对话通过。','§7.1.2 已补未启动分支的真实宿主退出与下一运行尝试；已派发／范围未知时的对账、首次 native 回调及业务桥仍待联合，不能以初始化成功声称完整恢复或对话通过。');assert '#### 7.1.2 'not in t;t=t.replace('### 7.2 结果观察、父 Provider 切换与模式切换',section+'### 7.2 结果观察、父 Provider 切换与模式切换');return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.46 宿主退出与独立运行尝试恢复

[恢复实验](实验/20261114_宿主退出与运行尝试恢复验证/README.md)最终 C01–C11 以真实 worker SIGKILL 和实际 MacProcessIdentityReader／run recovery，验证发布后复用来源、未启动 run 收尾后新 attempt／generation、旧计划保留、两恢复进程竞争、目标变化、推进事务回滚、活跃／未知 owner 保留，以及 armed 无 PID 不重试。新尝试完成 Codex 初始化；有过实际无害 shell 的 stopped run 仍保留派发未知，未自动重跑。

扩展 C11 复现只凭 claim token 会生成与 attempt owner 不同的 run；补实例／PID／出生身份校验后通过。保存原十项绿测、有效负对照、最终全批及准备阶段漏 stub 错误。最终十个捕获 worker 被终止、两个恢复 worker 正常退出、两个原生初始化和一个 shell 均退出；保留故意的 unknown 数据／租约，不伪造释放。完整 App 重启、Claude 原生恢复、真实输入／业务在途、后代范围、首次 native 修订与版本迁移仍未覆盖。T0.1 §7.1.2 固化恢复边界；Q04／13／24／48 保持部分。

'''
def account(t):
 assert '### 4.46 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q04','Q13','Q24','Q48']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.46 补真实宿主退出后的未启动对账、独立 attempt／generation 与 Codex 初始化，已派发／业务未知仍不自动重试 |';t='\n'.join(lines)+'\n'
 old='下一项优先验证 D01／D02／D06 的真实宿主恢复接缝：§4.45 已把子创建、新来源／预留、配置／计划及两端初始化联合，并验证同进程提交后抛错重试；仍需在宿主退出后核验持久回执、原 owner／进程范围、实际 run recovery 与下一 attempt 的原子分配，区分未 fork 可恢复和已派发／unknown 不重发。其余观察竞争／父切换、业务权限、运行范围、资源分发、性能及界面状态设计继续按矩阵推进。这是临时技术验证，不是产品接线授权；局部联合通过不替其他 D 项关闭。'
 new='§4.45 已补子创建到两端初始化与同进程重试；§4.46 补真实宿主退出后未启动 run 的对账、独立下一 attempt、并发恢复及 Codex 初始化。接下来优先核验首次 native 身份修订后，发布收据／固定来源／当前修订／运行尝试如何继续读取与恢复；已派发输入、业务在途和未知原生范围不得借未启动重试规则放行。观察竞争／父切换、业务权限、运行范围、资源分发、性能及界面状态仍按矩阵推进。这是临时技术验证，不是产品接线授权；局部联合通过不替其他 D 项关闭。'
 assert old in t;t=t.replace(old,new)
 t=t.replace('剩余决定性验证：新联合链的真实宿主崩溃接管、下一运行尝试及首次 native 回调；发布提交后跨宿主恢复；','§4.46 又补真实宿主退出后的未启动接管与下一运行尝试。剩余决定性验证：原生已派发／后台范围不明时的对账、首次 native 回调与来源复用；完整 App 重启／业务在途恢复；')
 t=t.replace('§4.32 补同库逻辑创建／outbox 和跨 run 去重；继续验证完整计划／资源准备与实际 worker 联合、socket 消费窗口、','§4.32 补同库逻辑创建／outbox 和跨 run 去重；§4.45–4.46 补新来源／计划到初始化及真实 worker 退出后的未启动恢复。继续验证已派发输入／完整业务和结果链联合、socket 消费窗口、')
 return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：新子任务链已补真实宿主退出后的未启动恢复、独立运行尝试与并发对账，恢复后的 run 完成 Codex 初始化；复制 claim 不能越过 owner 身份核验，见[技术方案 §7.1.2](技研/技术方案.md)。已派发／armed 无 PID 的情况继续保持未知；没有模型任务、完整 App 重启或业务验收。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续收口，优先核验首次 native 身份修订后固定来源、当前修订、发布收据和运行尝试的读写／恢复关系；已派发及业务在途另行对账。结果观察竞争、安装／版本／平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources)}))
