from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil,re

root=Path(__file__).resolve().parent
repo=Path('/Users/hx/projects/SmartDD')
base=Path('docs/里程碑/M14_统一Agent工作区')
experiment=base/'技研/实验/20261114_研究证据时效与入口恢复复验'
stage=root/'publication'
sha=lambda b:hashlib.sha256(b).hexdigest()
audit=json.loads((root/'result.json').read_text())
results={k:json.loads((root/k/'latest.json').read_text()) for k in ['handoff','recovery']}
for r in results.values(): assert r['passed']==5 and r['error'] is None
source_files=['src/main/core/applications/session-registry.ts','src/main/core/ai/agent-native-state.ts','src/main/core/ai/agent-native-state.test.ts']
source_review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':audit['t3Head'],'builds':{k:json.loads((root/k/'build.json').read_text()) for k in results},'sources':[{'path':str(repo/f),'sha256':sha((repo/f).read_bytes())} for f in source_files],'boundary':'Actual current components plus existing isolated candidate handoff SQL and browser retention predicate. No M14 product wiring, Claude copy execution, native provider turns or T3 execution.'}
for b in source_review['builds'].values():
 for e in b['sources']+b['outputs']: assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
(root/'source-review.json').write_text(json.dumps(source_review,ensure_ascii=False,indent=2)+'\n')
combined={'audit':audit,'revalidation':results,'boundary':source_review['boundary']}
(root/'combined-result.json').write_text(json.dumps(combined,ensure_ascii=False,indent=2)+'\n')
files=[root/f for f in ['audit.py','result.json','original-drivers.json','prepare.py','source-review.json','combined-result.json']]
for k,r in results.items():
 files += [p for p in (root/k).iterdir() if p.is_file()]
 files += [p for p in Path(r['out']).rglob('*') if p.is_file()]
files=sorted(set(files))
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files: tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
entries=[]
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 original=repo/rel;dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 entries.append({'path':str(rel),'before':sha(original.read_bytes()) if original.exists() else None,'after':sha(data)})
readme='''# 研究证据时效与入口恢复复验

日期：2026-11-14。关联 D01／D04、Q49／50 及业务恢复边界。当前 SmartDD 基线 `5a9e04382441e24624cb94635f9d902c543a03d7`。本轮为证据审计与既有隔离实验复验，不是产品验收或新增功能。

## 为什么补跑

逐一核对验证账 §4.74–4.87 对应的 14 份实验归档：归档摘要、内部文件清单及各文件摘要全部匹配。只比对 source-review 中明确记录的仓库绝对路径，不把临时相对路径解析成仓库文件，也不推断未记录输入。入口交接有 8 条、业务恢复有 10 条已记录源码摘要与当前源码不同；其他批次所记录的仓库来源未发现差异。这不是对全部历史实验或所有运行依赖的时效背书。

两批旧结果保留原基线；在全新临时子目录复制原驱动，分别以当前源码重建 actual bundle，未修改原断言。入口交接驱动、候选 migration／DDL 与业务恢复驱动均与原件摘要一致。浏览器候选只在内存变换清理 SQL，不修改产品源码。新构建的全部 379／387 条输入与输出在运行后再次核对一致。

## 当前源码复验

| 场景 | 结果及边界 |
| --- | --- |
| E01–E05：运行停止、真实子进程退出、业务活动排空、未知写门禁、身份抢占、并发交接与封闭旧入口 | 5 项通过；受控 Node 子进程 exit 0。未知业务行由夹具注入，尚未接 SDK adoption、真实 PTY 或完整持久恢复 |
| B01–B05：浏览器恢复、保留 unknown 的候选清理、读取恢复、邮件恢复及独立结果账 | 5 项通过；SMTP 调用为 0，无浏览器动作。B01 是负例复现：当前七天清理仍会删除未决记录；通过表示观察成立，不表示产品已修复 |

两套 SQLite 最终完整性和外键检查通过。邮件租约释放不等于发送结果确定；只查 application_invocations 仍会遗漏浏览器、邮件及项目级写入。这些结论可继续用于当前设计，但不升级为完整交接服务通过。

## 设计修正

源码复核另发现：当前 CapabilitySessionRegistry 已支持带可信 ClaudeRestoreReceipt 的历史复制交接，保留旧根的历史身份占用，并要求 Task 指针提交回调。旧设计“状态根必须保持一致”过于绝对。技术方案 §11.2 改为默认保持原根，已有受管复制路径须保留来源、目标、收据、旧根占用及原子提交；该路径涉及原生历史，不是复制整个 SVN 工程。

本批没有实际执行历史复制／adoptLibrary 路径；其与 M14 多 binding 的别名冲突、复制后提交失败、重启及回退还需隔离验证。不能由函数存在或 E04 的普通身份冲突证明这些分支已通过。

## 复现

归档中的 handoff、recovery 两目录分别运行 `node build.mjs`；recovery 追加 `node build-candidate.mjs`；随后各执行 `node probe.mjs`。需原记录所列固定 esbuild／SQLite 依赖及本机进程身份助手。audit.py 默认审计历史 §4.74–4.87，后续源码变化会如实记录差异，不能把新摘要回填旧实验。

[汇总](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
'''
put(experiment/'README.md',readme)
put(experiment/'result.json',(root/'combined-result.json').read_bytes())
put(experiment/'source-review.json',(root/'source-review.json').read_bytes())
put(experiment/'archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
put(experiment/'raw-evidence.tar.gz',archive.read_bytes())

ledger_rel=base/'技研/全局设计验证账.md';ledger=(repo/ledger_rel).read_text()
new='''### 4.88 研究证据时效与入口恢复复验

[本轮审计与复验](实验/20261114_研究证据时效与入口恢复复验/README.md)核对 §4.74–4.87 的 14 份归档及内部摘要，全部匹配；两批早期 source-review 的当前仓库输入出现 8／10 条变化。在新临时目录以当前源码重建后，原入口交接 E01–05、业务恢复 B01–05 均通过，原断言不变，当前 379／387 条构建输入与产物再次核对一致。真实受控子进程 exit 0，无原生 Agent 或 SMTP 调用。

负例仍成立：当前浏览器七天清理会丢失未决记录；候选保留条件仅在实验中。邮件释放租约仍不等于结果确定，单一调用账仍不足以开放新写者。不是生产修复或完整迁移证明。

源码还确认当前已有带可信收据的 Claude 历史根复制与原子指针提交，T0.1 §11.2 的绝对“状态根不变”已改为默认不变、受管复制单独交接且保留旧身份。此次仅源码核对，未跑该复制路径；下一份决定性证据是旧根别名占用、复制后提交失败及恢复与多 binding 的兼容，而非重复普通同根恢复。§7.1 同步近期证据和具体剩余分支，Q 状态及总数不提高。

'''
assert '### 4.88 ' not in ledger
ledger=ledger.replace('## 5. 失败与驱动修正',new+'## 5. 失败与驱动修正',1)
lines=ledger.splitlines()
updates={
'D01':('§4.73 已补固定版本原生工具历史在程序化／非交互 CLI 间往返与缺失拒绝，未替代上述产品入口与排他交接。分批证据不能直接相加成上述联合链','§4.73 已补固定版本工具历史往返；§4.74／4.88 已补实际 owner 排空与候选旧入口封口，§4.76 已补当前迁移器版本拒绝／提交镜像恢复。剩余是最终多 binding Schema、完整 adoption、跨宿主交接恢复及旧包边界；当前源码另有受管 Claude 历史根复制，必须核验旧根占用、提交失败与多 binding 的兼容，不能一律要求状态根不变。分批证据不相加为完整链'),
'D02':('继续核验最终联合、同连接并发与原生命令审批；两端权限档位、原生子 Agent 可控边界、启动材料与实际 fork 间失效、完整 scope／未知退出；第三适配器复用真实 owner／业务边界。版本／能力未知不能按成功处理','§4.80–4.81 已补两端 ask／full 与 Codex auto_review 成功、拒绝、异常及在途取消；§4.78–4.79／4.87 已补原生子节点、固定后代停止与提问身份。继续验证最终请求账联合、并发／恢复、受管设置与历史权限继承、原生禁用及动态后代／业务排空、启动材料到 fork 间失效、完整 scope／未知退出，以及第三适配器复用实际 owner／业务边界。固定版本局部证据不推导完整或未来版本兼容'),
'D04':('邮件来源／预检／最终授权、插件实时版本与审阅、浏览器 run 授权、四类 MCP 独立释放。分别通过的组件不相加成端到端证据','§4.75／4.88 已补当前独立业务结果账恢复，§4.77 已补实际文件查看器 MCP 的 run／文档生命周期；继续验证完整业务汇总门禁、邮件来源／预检／最终授权、插件实时版本与审阅、浏览器 run 授权及四类 MCP 联合释放。分别通过的组件不相加成端到端证据'),
'D06':('子问题和取消迟到回应（§4.59 已补实际插件审批，§4.60 已补原生 form 回调，递归取消与已发回应对账未证）','宿主委派子问题和取消迟到回应（§4.59 已补实际插件审批、§4.60–4.61 已补原生 form／候选回应账，仍缺 host_delegated 问题与实际 run 的联合；§4.79／4.87 是 provider_native 固定后代停止／提问身份，不能替代宿主问题账、动态递归或已发回应对账）')
}
for idx,line in enumerate(lines):
 for key,(old,replacement) in updates.items():
  if line.startswith('| '+key+' '):
   assert old in line,key
   lines[idx]=line.replace(old,replacement)
ledger='\n'.join(lines)+'\n'
ledger=ledger.replace('截至 §4.87，56 个宽口径问题项中','截至 §4.88，56 个宽口径问题项中')
put(ledger_rel,ledger)

tech_rel=base/'技研/技术方案.md';tech=(repo/tech_rel).read_text()
old='交接由宿主统一服务负责，输入为 task／binding、预期当前快照修订和目的入口；原生 ID、规范状态根、cwd 及历史来源必须保持一致。'
new='交接由宿主统一服务负责，输入为 task／binding、预期当前快照修订和目的入口；原生 ID、cwd 及历史来源必须保持一致，默认沿用原规范状态根。已存在的受管历史复制按下述独立合同移交，不能任意改写状态根。'
assert old in tech;tech=tech.replace(old,new,1)
anchor='T3 ProviderSessionManager.releaseEntry 将订阅排空、scope 关闭、工具事件补记及释放记录分层处理；'
para='''[当前源码与原入口复验](实验/20261114_研究证据时效与入口恢复复验/README.md)补充现有兼容要求：CapabilitySessionRegistry.adoptLibrary 已允许凭进程内可信 ClaudeRestoreReceipt 迁移 Claude 历史根，要求复制前及提交时校验来源／目标字节、无活动 run、同任务／原生 ID／cwd、目标身份无冲突和 Task 指针提交回调；旧根经 capability_snapshot_versions 继续保留身份占用。M14 必须接住这个既有入口与历史来源，不能只迁移当前 identity_root，遗漏旧根别名后把同一历史再授予另一任务。默认不搬动历史，确需复用已有复制路径时记录来源与目标并验证原子提交／失败恢复；这是该会话文件和同名子树的复制，不是 SVN 项目快照。该分支本轮为源码证据，完整多 binding 映射、提交失败、崩溃与回退继续待验，不由普通同根身份冲突检查替代。

'''
assert anchor in tech;tech=tech.replace(anchor,para+anchor,1)
put(tech_rel,tech)

readme_rel=base/'README.md';s=(repo/readme_rel).read_text()
s=re.sub(r'^最新进展：.*$', '最新进展：已核对近期实验归档并用当前源码补跑入口交接／业务恢复；同步修正受管历史根复制的迁移边界及剩余验证清单。见[证据时效与复验](技研/实验/20261114_研究证据时效与入口恢复复验/README.md)，数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',s,flags=re.M)
s=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)优先验证现有历史根复制／旧根占用与多 binding 迁移、提交失败恢复，再推进宿主委派问题账及完整运行／业务联合；资源占用与恢复清理继续保留具体未决项。',s,flags=re.M)
put(readme_rel,s)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')
shutil.copyfile('/private/tmp/willyou-m14-native-child-elicitation-probe/publish.py',root/'publish.py')
print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'auditArchives':len(audit['results']),'revalidationChecks':sum(r['passed'] for r in results.values())}))
