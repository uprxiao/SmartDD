from pathlib import Path
import hashlib,json,re,tarfile,subprocess

repo=Path('/Users/hx/projects/SmartDD')
base=repo/'docs/里程碑/M14_统一Agent工作区'
ledger=(base/'技研/全局设计验证账.md').read_text()
part=ledger[ledger.index('### 4.74 '):ledger.index('## 5. 失败')]
names=list(dict.fromkeys(re.findall(r'\]\((实验/[^)]+/README\.md)(?:#[^)]*)?\)',part)))
sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def refs(v):
    if isinstance(v,dict):
        if isinstance(v.get('path'),str) and 'sha256' in v: yield v
        for x in v.values(): yield from refs(x)
    elif isinstance(v,list):
        for x in v: yield from refs(x)

results=[]
cache={}
for link in names:
    p=base/'技研'/Path(link).parent
    manifest=json.loads((p/'archive-manifest.json').read_text())
    archive=p/'raw-evidence.tar.gz'
    assert filehash(archive)==manifest['archiveSha256'],str(archive)
    expected={x['path']:x['sha256'] for x in manifest['files']}
    found={}
    with tarfile.open(archive,'r:gz') as tf:
        for member in tf:
            if member.isfile():
                f=tf.extractfile(member)
                found[member.name]=hashlib.file_digest(f,'sha256').hexdigest()
    assert expected==found, str(p)
    review=json.loads((p/'source-review.json').read_text())
    checked=0;stale=[];missing=[]
    seen=set()
    for x in refs(review):
        if not Path(x['path']).is_absolute(): continue
        f=Path(x['path']).resolve()
        if not (f.is_relative_to(repo) or f.is_relative_to('/Users/hx/projects/t3code')): continue
        pair=(str(f),x['sha256'])
        if pair in seen: continue
        seen.add(pair);checked+=1
        if not f.is_file(): missing.append(str(f));continue
        actual=cache.setdefault(str(f),filehash(f))
        if actual!=x['sha256']: stale.append({'path':str(f),'recorded':x['sha256'],'current':actual})
    results.append({'experiment':str(p.relative_to(base)),'archiveSha256':manifest['archiveSha256'],'verifiedArchivedFiles':len(found),'currentRepositorySourceEntries':checked,'changedSourceEntries':stale,'missingSources':missing})
    print(json.dumps({'experiment':p.name,'files':len(found),'sources':checked,'changed':len(stale),'missing':len(missing)},ensure_ascii=False),flush=True)

out={'kind':'evidence-audit-not-runtime-retest','smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C','/Users/hx/projects/t3code','rev-parse','HEAD'],text=True).strip(),'scope':'Ledger sections 4.74 through 4.87; archive integrity and explicitly recorded current repository source hashes only; no new native execution or product acceptance. Hash matches do not prove coverage. Unlisted inputs are not inferred unchanged.','results':results}
Path('/private/tmp/willyou-m14-closure-audit/result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
