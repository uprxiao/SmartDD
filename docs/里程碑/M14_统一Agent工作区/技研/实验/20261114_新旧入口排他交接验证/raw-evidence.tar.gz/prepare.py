from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_新旧入口排他交接验证';stage=root/'publication';entries=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==5 and result['error']is None
attempt=Path(result['out']);build=json.loads((root/'build.json').read_text())
for s in build['sources']+build['outputs']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
expanded=[]
for p in [repo/'src/main/db/migrations.ts',repo/'src/main/core/capabilities/assets.ts']:
 for pattern in re.findall(r"import\.meta\.glob\('([^']+)'",p.read_text()):
  pattern=pattern.replace('@root/','')
  for f in repo.glob(pattern):
   if f.is_file():expanded.append({'path':str(f),'sha256':sha(f.read_bytes())})
db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()==('ok',);assert db.execute('pragma foreign_key_check').fetchall()==[];assert db.execute("select count(*) from capability_runs where state not in ('stopped','failed')").fetchone()==(0,);assert db.execute("select count(*) from capability_resource_leases where state<>'released'").fetchone()==(0,);db.close()
refs=[t3/'apps/server/src/orchestration-v2/ProviderSessionManager.ts',repo/'src/main/core/applications/run-recovery.ts',repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/session-registry.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'build':build,'expandedAssets':expanded,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'kernelHelper':{'path':'/private/tmp/willyou-m14-owner-probe/process-identity','sha256':sha(Path('/private/tmp/willyou-m14-owner-probe/process-identity').read_bytes())},'candidateScope':'Prior m14 schema/migration copied unchanged. Minimal seal admission in probe.mjs is a research candidate, not full programmatic adoption. Actual current registries are unmodified. Unknown write and reconciliation are explicit synthetic DB fixtures.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
runtime={'realOwnedGenericChild':json.loads((attempt/'process-identity.json').read_text()),'exit':{'code':0,'signal':None},'sqliteIntegrity':'ok','foreignKeys':[],'unresolvedRuns':0,'unreleasedLeases':0,'paidModelRequests':0,'externalBusinessWrites':0,'initialBuildFailure':'Vite glob expansion included directories (EISDIR); filtered regular files before successful build. No experiment ran before successful build.','productChanges':0}
(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
files=[root/n for n in ['build.mjs','build.json','actual.cjs','migration.mjs','candidate.sql','probe.mjs','source-review.json','runtime-audit.json','prepare.py']]+sorted(attempt.iterdir())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:
  assert p.is_file();tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files],'sqliteIntegrityAndForeignKeys':[{'path':str((attempt/'final.sqlite').relative_to(root)),'integrity':'ok','foreignKeys':[]}]}
for name,data in [('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtime,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)),('raw-evidence.tar.gz',archive.read_bytes())]:put(exp/name,data)
put(exp/'README.md','''# 新旧入口排他交接：独立技术验证

范围：当前 SmartDD CapabilitySessionRegistry／CapabilityRunRegistry／运行恢复代码，真实自有 Node 子进程及 macOS 进程出生身份，旧候选 SQLite 映射和本轮最小交接门禁。五项检查通过。没有启动模型、PTY、SDK，也没有修改产品代码。

| 检查 | 实际证据 |
| --- | --- |
| E01 停止调用返回 | 实际 stop 返回 stopping；进程仍在、业务 Promise 未结束，候选迁移拒绝 |
| E02 子进程退出 | 收到真实 exit 0 后记录退出；业务活动尚未结束，run 仍 stopping，迁移仍拒绝 |
| E03 业务结果未知 | 活动完成后 run 停止、租约释放；显式注入一条合法 unknown 写记录。结构迁移成功，但新增入口门禁拒绝并保持 legacy |
| E04 身份冲突 | 新绑定不能抢已有旧会话；旧注册器创建与新绑定冲突的原生 ID 时由 SQL 守卫拒绝，整个旧创建事务回滚 |
| E05 排他交接 | 合成对账后，旧摘要拒绝；两个同时发起的门禁调用只成功一个；旧 reserve 被 SQL 守卫拒绝且没有新增 run／租约；历史快照仍可读 |

E03 是候选组合的反例：结构迁移只证明数据可映射，不证明可执行新任务。它不是当前产品已有 SDK 切换功能的缺陷。本轮 unknown 写由夹具注入，后续“对账为未开始”也是夹具，不代表真实外部系统结果可以自动确定。E05 仅将原 binding 的 entry_mode 封口为 programmatic，phase 仍为 historical；没有伪装成 prepared，也没有借已有“全新会话”发布接口导入旧原生 ID。

实现时复用原 binding、native ID、根目录及不可变历史；在同一资源锁和写事务中检查当前来源、未决运行／进程／业务与修订，写入交接状态并封住旧写入口。随后另行验证投影、执行配置及资源计划，再进入可启动状态。失败或宿主退出必须保留可读历史、交接阶段和可对账记录，不能靠解开旧 SQL 守卫、清空未知状态或新建原生 ID 恢复。程序化到兼容 CLI 也应通过统一 owner，不能让旧 TaskService 绕过它。

T3 参考 ProviderSessionManager.releaseEntry：区分活动、订阅排空、scope 关闭及持久释放记录，排空后补记迟到工具事件。WillYou 应借鉴这些分层，但还须检查自己独立的业务调用／邮件／浏览器等结果账；T3 的 session 关闭不能替 WillYou 证明外部写已完成。

证据边界：真实普通子进程；不是原生 Agent 或 PTY。并发是两个宿主调用竞争同一资源锁／事务，不是本轮跨宿主 SIGKILL。只执行 application_invocations 的未知写门禁反例；其他业务表、完整 adoption／准备／恢复、项目写者范围与真实 TaskService 尚待联合。Q49 仍为部分。无新产品通过项。

复跑：先在 SmartDD cwd 运行 build.mjs，再运行 probe.mjs。依赖位于既有隔离目录，源码、依赖输入、生成 bundle 与进程 helper 均记录摘要。初次构建将 glob 中目录作为文件读取导致 EISDIR；过滤目录后成功，实验首跑即五项通过。

[结果](result.json) · [运行审计](runtime-audit.json) · [源码依据](source-review.json) · [归档摘要](archive-manifest.json) · [原始脚本与 SQLite](raw-evidence.tar.gz)。
''')
section='''### 11.2 结构迁移与执行入口交接分离

[入口交接实验](实验/20261114_新旧入口排他交接验证/README.md)验证现有 run 生命周期：stop 返回和 CLI 真实退出都不等于业务活动排空；实际活动完成前 run 保持 stopping、资源占用保留，候选迁移拒绝。活动排空后也须独立检查持久业务结果。一个已 stopped 的 run 可以关联 unknown 写；本轮合法夹具证明此前结构映射会成功保留它，因此**映射完成不能直接作为 SDK／CLI 新入口启动许可**。

交接由宿主统一服务负责，输入为 task／binding、预期当前快照修订和目的入口；原生 ID、规范状态根、cwd 及历史来源必须保持一致。在资源锁和同步写事务内重新核验运行、全部进程、活动、租约、未决写及当前来源，原子记录交接阶段并封闭旧入口。应用调用之外，邮件、浏览器、数据操作等独立持久账也须通过各自对账接口汇总，不只扫描 application_invocations；同项目写者仍受 SVN／Git 工作区规则约束。状态未知时保留历史可读和恢复提示，禁止静默重发或授予新写者。

本轮门禁验证了旧／新原生身份双向冲突拒绝、过期快照拒绝、两次并发交接仅一次成功，以及封口后的旧 reserve 整体回滚。它只完成“检查与旧入口封口”，原绑定仍 historical，不是 SDK 可启动证明。后续 adoption 必须复用原 binding、历史和资源引用，完成受管投影、执行配置及原生恢复校验才标记 prepared；不得把既有原生 ID 塞入仅允许全新 ID 的发布路径。交接阶段／恢复记录与资源保护须在宿主退出后可继续核验，准备失败不能直接重新开放旧写入口。兼容 CLI 应走统一执行 owner，而不是回退到绕开 owner 的旧 TaskService。

T3 ProviderSessionManager.releaseEntry 将订阅排空、scope 关闭、工具事件补记及释放记录分层处理；参考其生命周期边界，但 WillYou 的业务结果账仍是独立事实。当前最小门禁和合成未知写仅提供合同证据；全部业务汇总、真实 PTY、完整准备／回退和交接崩溃恢复尚未证明。Q49 保持部分。

'''
def tech(t):
 assert '### 11.2 'not in t;return t.replace('## 12. 运行资源、配置与版本',section+'## 12. 运行资源、配置与版本')
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 assert '### 4.74 'not in t
 t=t.replace('真实 PTY／TaskService、原生身份排他交接、未知业务写、旧任务只读与跨版本回退仍待验','§4.74 补实际停止／活动排空、双向身份冲突及最小原子封口，合成 unknown 写证明结构映射不等于启动许可；真实 PTY／TaskService、完整交接与业务对账、旧任务只读及跨版本回退仍待验')
 return t.replace('## 5. 失败与驱动修正','''### 4.74 新旧入口排他交接与业务未知门禁

[五项独立检查](实验/20261114_新旧入口排他交接验证/README.md)通过。当前实际运行注册器、自有真实 Node 进程与进程出生身份验证：stop 返回、CLI exit 均不能越过未结束业务活动；活动结束后运行／租约正确收束。候选结构迁移保留合法 unknown 写并成功，新增最小原子门禁则拒绝新入口，明确迁移与启动授权不是同一动作。

补旧／新身份双向抢占拒绝、旧注册创建事务回滚、过期摘要拒绝、并发仅一方封口和旧 reserve 拒绝无残余。封口保留原 binding／native ID／历史，phase 仍 historical，不是完整 SDK adoption。unknown 写和对账结果显式夹具；无原生 Agent、PTY、模型或外部业务。本轮未覆盖其他业务结果账、跨宿主交接崩溃及完整准备恢复，Q49 仍部分；设计更新 §11.2。SQLite 完整性／外键通过，真实子进程 exit 0，无未决 run 或租约。

## 5. 失败与驱动修正''')
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：新旧入口交接的五项检查通过，确认停止、进程退出、业务排空与结果对账必须分开；结构迁移可保留未知写，但新执行入口应被阻止。双向身份冲突及原子封口取得局部证据，见[技术方案 §11.2](技研/技术方案.md)。仍无产品代码修改。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)核对独立业务结果账的交接阻挡、历史迁移／数据版本合同和剩余设计未知；不重复已通过的格式往返与停止排空，不把最小封口当作完整 SDK 接线。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'stagedFiles':len(entries),'checks':result['passed'],'archiveFiles':len(files),'sourceInputs':len(build['sources']),'expandedAssets':len(expanded)}))
