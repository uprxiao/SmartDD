import assert from 'node:assert/strict';
import {fork} from 'node:child_process';
import {once} from 'node:events';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync} from 'node:fs';
import actual from './actual.cjs';
import {migrate,claimBinding} from './migration.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
const {runFixture,MacProcessIdentityReader,withResourceLock}=actual;
const checks=[],deferred=()=>Promise.withResolvers();let f,child,exit,run,activity,release,problem;
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
function snapshot(){const db=f.sqlite;return{runs:db.prepare('SELECT * FROM capability_runs').all(),processes:db.prepare('SELECT * FROM capability_run_processes').all(),activities:db.prepare('SELECT * FROM capability_run_activities').all(),leases:db.prepare('SELECT * FROM capability_resource_leases').all(),invocations:db.prepare('SELECT * FROM application_invocations').all()};}
async function seal(scope){
 return withResourceLock(f.store.root,()=>f.sqlite.transaction(()=>{
  const db=f.sqlite,b=db.prepare('SELECT b.*,c.current_hash FROM m14_binding b JOIN m14_cap c USING(binding_id) WHERE b.binding_id=?').get(scope.bindingId);
  assert(b&&b.task_id===scope.taskId&&b.current_hash===scope.hash&&b.native_id===scope.nativeId&&b.entry_mode==='legacy','STALE_HANDOFF');
  assert(!db.prepare("SELECT 1 FROM capability_runs WHERE task_id=? AND (state NOT IN ('stopped','failed') OR revocation_state<>'revoked')").get(b.task_id),'RUN_UNRESOLVED');
  assert(!db.prepare("SELECT 1 FROM capability_run_processes p JOIN capability_runs r USING(run_id) WHERE r.task_id=? AND p.state NOT IN ('exited','canceled')").get(b.task_id),'PROCESS_UNRESOLVED');
  assert(!db.prepare("SELECT 1 FROM capability_run_activities a JOIN capability_runs r USING(run_id) WHERE r.task_id=? AND a.state='active'").get(b.task_id),'ACTIVITY_UNRESOLVED');
  assert(!db.prepare("SELECT 1 FROM capability_resource_leases l JOIN capability_runs r ON r.run_id=l.owner_id WHERE l.owner_kind='run' AND r.task_id=? AND l.state<>'released'").get(b.task_id),'LEASE_UNRESOLVED');
  assert(!db.prepare("SELECT 1 FROM application_invocations WHERE task_id=? AND semantics='write' AND (state='running' OR effect_state='unknown')").get(b.task_id),'BUSINESS_OUTCOME_UNRESOLVED');
  db.prepare("UPDATE m14_binding SET entry_mode='programmatic' WHERE binding_id=? AND entry_mode='legacy'").run(b.binding_id);
  return{bindingId:b.binding_id,nativeId:b.native_id,hash:b.current_hash,phase:b.phase};
 }).immediate());
}
try{
 const reader=new MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');f=await runFixture(reader);
 const nativeId=randomUUID(),bound=await f.sessions.bindNativeSession(f.snapshot.taskId,f.session.pointer.snapshotHash,{runner:f.snapshot.runner,...f.snapshot.native,sessionId:nativeId});
 const input={taskId:f.snapshot.taskId,snapshotHash:bound.pointer.snapshotHash,bindings:[]};run=await f.runs.reserve(input);await run.prepare();await run.cli.arm();
 writeFileSync(out+'/child.cjs',"process.send('ready');process.on('message',m=>{if(m==='stop'){process.disconnect();process.exit(0);}});\n");
 child=fork(out+'/child.cjs',[],{stdio:['ignore','pipe','pipe','ipc']});exit=once(child,'exit');await once(child,'message');const identity=reader.read(child.pid);assert(identity);await run.cli.attach(child.pid,identity.startedAt);save('process-identity.json',identity);
 const entered=deferred();release=deferred();activity=f.runs.withActivity(run.runId,async ctx=>{entered.resolve();await release.promise;return{aborted:ctx.signal.aborted};});await entered.promise;
 await check('E01','stop returns while owned child and activity remain; migration refuses',async()=>{const stopped=await run.stop();assert.equal(stopped.state,'stopping');await assert.rejects(migrate(f.sqlite),/run unresolved/);assert(!f.sqlite.inTransaction);save('before-exit.json',snapshot());return{state:stopped.state,child:reader.state(identity),migrationRejected:true};});
 await check('E02','real child exit is insufficient while activity remains',async()=>{child.send('stop');const [code,signal]=await exit;assert.equal(code,0);assert.equal(signal,null);await run.cli.exited();assert.equal(reader.state(identity),'stopped');assert.equal(f.runs.get(run.runId).state,'stopping');await assert.rejects(migrate(f.sqlite),/run unresolved/);save('after-exit-before-drain.json',snapshot());return{code,signal,activeBusiness:1,migrationRejected:true};});
 let scope,unknownId;
 await check('E03','drain permits schema mapping but unknown write still requires independent handoff gate',async()=>{
  release.resolve();assert.deepEqual(await activity,{aborted:true});assert.equal(f.runs.get(run.runId).state,'stopped');
  unknownId=randomUUID();f.sqlite.prepare("INSERT INTO application_invocations(operation_id,run_id,request_id,request_hash,project_id,task_id,app_id,package_hash,tool_name,contract_major,semantics,state,effect_state,started_at) VALUES(?,?,?,?,?,?,'fixture','fixture','write',1,'write','unknown','unknown',?)").run(unknownId,run.runId,randomUUID(),'a'.repeat(64),f.snapshot.projectId,f.snapshot.taskId,new Date().toISOString());
  assert.equal(await migrate(f.sqlite),'migrated');const b=f.sqlite.prepare('SELECT * FROM m14_binding WHERE task_id=?').get(f.snapshot.taskId);scope={bindingId:b.binding_id,taskId:b.task_id,hash:bound.pointer.snapshotHash,nativeId};
  await assert.rejects(seal(scope),/BUSINESS_OUTCOME_UNRESOLVED/);assert.equal(f.sqlite.prepare('SELECT entry_mode FROM m14_binding WHERE binding_id=?').get(b.binding_id).entry_mode,'legacy');save('unknown-write.json',snapshot());
  return{schemaMigrationPassedWithUnknownWrite:true,activationRefused:true,unknownWriteSeeded:true,noExternalWritePerformed:true};
 });
 await check('E04','native identity cannot be assigned to another task in either registry direction',async()=>{
  assert.throws(()=>claimBinding(f.sqlite,{taskId:'other-new-task',runner:f.snapshot.runner,identityRoot:f.snapshot.native.stateRoot,nativeId,cwd:f.snapshot.native.cwd}),/legacy native identity already owned/);
  const otherNative=randomUUID();claimBinding(f.sqlite,{taskId:'new-only-task',runner:f.snapshot.runner,identityRoot:f.snapshot.native.stateRoot,nativeId:otherNative,cwd:f.snapshot.native.cwd});
  const other={...structuredClone(bound.snapshot),taskId:'other-old-task',native:{...bound.snapshot.native,sessionId:otherNative}};
  await assert.rejects(f.sessions.create(other,f.home),/M14_NATIVE_IDENTITY_CONFLICT/);assert(!f.sqlite.prepare('SELECT 1 FROM capability_session_snapshots WHERE task_id=?').get(other.taskId));
  return{newCannotStealOld:true,oldCannotStealNew:true,oldCreateRolledBack:true};
 });
 await check('E05','stale source and concurrent handoff refuse; legacy writer sealed after one admission',async()=>{
  // Controlled reconciliation fixture only; no claim of automatic external reconciliation.
  f.sqlite.prepare("UPDATE application_invocations SET state='failed',effect_state='not-started',ended_at=? WHERE operation_id=?").run(new Date().toISOString(),unknownId);
  await assert.rejects(seal({...scope,hash:'0'.repeat(64)}),/STALE_HANDOFF/);
  const attempts=await Promise.allSettled([seal(scope),seal(scope)]);assert.equal(attempts.filter(x=>x.status==='fulfilled').length,1);assert.match(attempts.find(x=>x.status==='rejected').reason.message,/STALE_HANDOFF/);
  const before=snapshot();await assert.rejects(f.runs.reserve(input),/M14_LEGACY_WRITER_SEALED/);assert.deepEqual(snapshot(),before);
  const b=f.sqlite.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(scope.bindingId);assert.equal(b.native_id,nativeId);assert.equal(b.phase,'historical');assert.equal(f.sessions.read(scope.taskId).pointer.snapshotHash,scope.hash);
  return{oneWinner:true,oldReservationRolledBack:true,originalSnapshotReadable:true,nativeIdPreserved:true,programmaticPreparationNotImplemented:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
finally{
 release?.resolve();if(activity)await activity.catch(()=>{});
 if(child&&child.exitCode===null&&child.signalCode===null){child.kill('SIGTERM');await exit;}
 if(f){if(run)try{const row=f.sqlite.prepare('SELECT state FROM capability_run_processes WHERE process_id=?').get(run.cli.processId);if(row&&!['exited','canceled'].includes(row.state))await run.cli.exited();}catch{}
  save('final-state.json',snapshot());assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(out+'/final.sqlite');save('fixture.json',{root:f.root});f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,scope:'Actual current registry + real owned generic Node process; candidate schema mapping and minimal atomic admission gate. Synthetic unknown write; no native model, PTY, SDK activation, production implementation or external business reconciliation.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
