process.send('ready');process.on('message',m=>{if(m==='stop'){process.disconnect();process.exit(0);}});
