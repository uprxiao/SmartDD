import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,copyFileSync,symlinkSync} from 'node:fs';
import {join,dirname} from 'node:path';
import actual from './actual.cjs';
import {migrate} from './migration.mjs';
import {installRetainedClaims} from './retained.mjs';
import {bindNativeLocked} from './programmatic-prior.mjs';
import {installProgrammaticClaimSources,bindNativeClaimLocked} from './claims-joint.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
for(const n of ['probe.mjs','claims-joint.mjs','programmatic-prior.mjs','migration.mjs','candidate.sql','claims.mjs','retained.mjs','build.mjs','build.json'])copyFileSync(root+'/'+n,out+'/'+n);
const checks=[];let error;
const rows=db=>Object.fromEntries(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(({name})=>[name,db.prepare('SELECT * FROM '+name+' ORDER BY 1').all()]));
async function fixture(){
 const f=await actual.runFixture();let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});const id=randomUUID();current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:id});
 const from=current.snapshot.native.stateRoot,to=join(f.root,'copied'),cwd=current.snapshot.native.cwd,source=join(from,'projects',actual.encodeClaudeDir(cwd),id+'.jsonl');mkdirSync(dirname(source),{recursive:true});mkdirSync(to);writeFileSync(source,'SYNTHETIC_HISTORY\n');
 const receipt=actual.copyClaudeSession({from,to,cwd,sessionId:id,nativeTarget:false});current=await f.sessions.adoptLibrary(current.snapshot.taskId,current.pointer.snapshotHash,{...current.snapshot,native:{...current.snapshot.native,stateRoot:to}},{copy:receipt,home:f.home,commit:()=>{assert(f.sqlite.inTransaction);}});
 await migrate(f.sqlite,async point=>{if(point==='before-drop'){installRetainedClaims(f.sqlite);installProgrammaticClaimSources(f.sqlite);}});
 return {...f,current,id,from,to,cwd};
}
function planned(f,stateRoot=f.from){
 const db=f.sqlite,taskId=randomUUID(),bindingId=randomUUID(),cap=randomUUID();
 const snapshot=actual.storedCapabilitySessionSnapshotSchema.parse({...f.current.snapshot,taskId,native:{...f.current.snapshot.native,stateRoot,sessionId:null}}),json=actual.canonicalJson(snapshot),hash=actual.digest(json);
 db.transaction(()=>{
 db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,identity_root,native_id,cwd,entry_mode,phase) VALUES(?,?,?,?,NULL,?,'programmatic','prepared')").run(bindingId,taskId,snapshot.runner,stateRoot,snapshot.native.cwd);
 db.prepare("INSERT INTO m14_cap VALUES(?,?,?,'active',NULL)").run(cap,taskId,bindingId);
 db.prepare('INSERT INTO m14_revision VALUES(?,?,?,?,?,?,?)').run(cap,taskId,bindingId,hash,json,3,actual.selectionHash(snapshot));
 db.prepare('INSERT INTO m14_ref SELECT ?,?,ref_id,ref_kind,ref_hash,relative_path,? FROM capability_session_refs WHERE task_id=?').run(cap,hash,taskId,f.current.snapshot.taskId);
 db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(hash,cap);
 }).immediate();return{scope:{taskId,bindingId,capabilitySessionId:cap,snapshotHash:hash},snapshot};
}
const native=(p,id)=>({runner:p.snapshot.runner,...p.snapshot.native,sessionId:id});
const fixed=(f,p,id,options)=>f.sqlite.transaction(()=>bindNativeClaimLocked(f.store,p.scope,native(p,id),options)).immediate();
async function check(id,title,fn){const f=await fixture();try{const evidence=await fn(f);checks.push({id,title,status:'passed',evidence});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save(id+'-state.json',rows(f.sqlite));assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.runs.dispose();await f.sqlite.backup(out+'/'+id+'.sqlite');save(id+'-fixture.json',{root:f.root});f.sqlite.close();}}
try{
 await check('J01','prior programmatic native publication ignores retained historical claims',async f=>{
  const p=planned(f),old=f.sqlite.prepare('SELECT * FROM m14_native_claim WHERE identity_root=? AND native_id=?').get(f.from,f.id);assert(old&&old.binding_id!==p.scope.bindingId);
  const next=f.sqlite.transaction(()=>bindNativeLocked(f.store,p.scope,native(p,f.id))).immediate();assert(next.snapshotHash!==p.scope.snapshotHash);
  assert.equal(f.sqlite.prepare('SELECT native_id FROM m14_binding WHERE binding_id=?').get(p.scope.bindingId).native_id,f.id);
  return{negative:true,priorCandidateAcceptedRetainedIdentity:true,retainedClaimStillOwnedByOriginalBinding:true,productNotAffected:true};
 });
 await check('J02','joint claim rejects old-root collision and keeps all rows unchanged',async f=>{
  const p=planned(f),before=rows(f.sqlite);assert.throws(()=>fixed(f,p,f.id),/NATIVE_CLAIM_CONFLICT/);assert.deepEqual(rows(f.sqlite),before);
  const alias=join(f.root,'alias');symlinkSync(f.from,alias);const p2=planned(f,alias),prior=rows(f.sqlite);assert.throws(()=>fixed(f,p2,f.id),/NATIVE_ROOT_NOT_CANONICAL/);assert.deepEqual(rows(f.sqlite),prior);
  return{historicalConflictDenied:true,nonCanonicalRootRejected:true,allRowsUnchanged:true};
 });
 await check('J03','new native publication records immutable source and repeat is idempotent',async f=>{
  const p=planned(f),id=randomUUID(),next=fixed(f,p,id),before=rows(f.sqlite);assert.deepEqual(fixed(f,p,id),next);assert.deepEqual(rows(f.sqlite),before);
  const source=f.sqlite.prepare('SELECT * FROM m14_programmatic_claim_source WHERE binding_id=?').get(p.scope.bindingId);assert.equal(source.snapshot_hash,next.snapshotHash);assert.equal(source.native_id,id);
  assert.throws(()=>f.sqlite.prepare('DELETE FROM m14_native_claim WHERE binding_id=?').run(p.scope.bindingId),/FOREIGN KEY/);
  assert.throws(()=>f.sqlite.prepare('DELETE FROM m14_revision WHERE cap_id=? AND snapshot_hash=?').run(next.capabilitySessionId,next.snapshotHash),/FOREIGN KEY/);
  return{sourceRevisionRetained:true,sameIdentityRepeatUnchanged:true,claimAndSourceDeletionDenied:true};
 });
 await check('J04','actual legacy session creation cannot take a programmatically claimed identity',async f=>{
  const p=planned(f),id=randomUUID();fixed(f,p,id);const before=f.sqlite.prepare('SELECT * FROM capability_session_snapshots ORDER BY task_id').all();
  await assert.rejects(f.sessions.create({...p.snapshot,taskId:randomUUID(),native:{...p.snapshot.native,sessionId:id}},f.home),/CONFLICT|占用|owned/);
  assert.deepEqual(f.sqlite.prepare('SELECT * FROM capability_session_snapshots ORDER BY task_id').all(),before);
  return{actualSessionRegistryRejected:true,legacySnapshotsUnchanged:true};
 });
 await check('J05','revision and claim source are one rollback unit',async f=>{
  const p=planned(f),id=randomUUID(),before=rows(f.sqlite);
  for(const point of ['after-native-revision','after-claim-source']){assert.throws(()=>fixed(f,p,id,{checkpoint:p=>{if(p===point)throw Error('CONTROLLED_ABORT:'+point);}}),/CONTROLLED_ABORT/);assert.deepEqual(rows(f.sqlite),before);}
  fixed(f,p,id);return{twoTransactionCutPointsRolledBack:true,explicitRetryAfterRollbackSucceeded:true,noNativeProcessOrInputDispatched:true};
 });
 await check('J06','second programmatic binding cannot publish the same native identity',async f=>{
  const p=planned(f),q=planned(f),id=randomUUID();fixed(f,p,id);const before=rows(f.sqlite);assert.throws(()=>fixed(f,q,id),/NATIVE_CLAIM_CONFLICT/);assert.deepEqual(rows(f.sqlite),before);
  return{sharedClaimTableProtectsBothEntryModes:true,losingBindingUnchanged:true};
 });
}catch(e){error=e.stack;process.exitCode=1;}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:error??null,scope:'Shared isolated DB combines prior retained-history claim projection and programmatic first-native publication. Actual current session registry/copy service/migrations plus candidate SQL and publication; no SDK, native processes, business admission, GC integration or product modifications.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
