from pathlib import Path
import json,hashlib,tarfile,subprocess,sqlite3
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_程序化首次绑定与保留身份联合验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
audit=[]
for a in sorted(root.glob('attempt-*')):
 for p in a.glob('J??.sqlite'):
  db=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()[0]=='ok';assert not db.execute('pragma foreign_key_check').fetchall();assert not db.execute("SELECT 1 FROM capability_runs WHERE state NOT IN ('stopped','failed')").fetchone();assert not db.execute("SELECT 1 FROM capability_resource_leases WHERE state<>'released'").fetchone();db.close();audit.append(str(p.relative_to(root)))
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'actualSources':b,'candidateInputs':{n:sha((root/n).read_bytes()) for n in ['candidate.sql','migration.mjs','claims.mjs','retained.mjs','programmatic-prior.mjs','claims-joint.mjs']},'provenance':{'candidate.sql,migration.mjs,claims.mjs,retained.mjs':'Copied retained-claims research candidate, not production SQL','programmatic-prior.mjs':'Copied prior business-mcp-joint candidate first-native binding, no changes','claims-joint.mjs':'New research wrapper and exact owner/source FK; no product edit'},'actual':['Current CapabilitySessionRegistry','copyClaudeSession/adoptLibrary','Current bundled migrations','ResourceStore fixture'],'controlled':['FixtureProcessReader','Synthetic native history bytes','Programmatic prepared binding/source setup','First-native callback arguments, no SDK process'],'audit':{'databases':audit,'integrity':'ok','foreignKeys':'ok','activeRuns':0,'unreleasedLeases':0},'limits':['No real native process/callback or full programmatic launch','No common run admission service/business result/recovery integration','No multi-process contention or SIGKILL, transaction cuts are synchronous throws','No generic FK equivalence proof for all claim-source types','Research schema extension only; production migration, GC and supported downgrade remain open']}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['actual.cjs','build.mjs','build.json','probe.mjs','candidate.sql','migration.mjs','claims.mjs','retained.mjs','programmatic-prior.mjs','claims-joint.mjs','source-review.json','prepare.py']]
for d in sorted(root.glob('attempt-*')):files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 程序化首次绑定与保留身份联合验证

日期：2026-11-14。D01，关联 Q13／Q46–50。将 §4.92–93 的历史身份占用投影与早批程序化首次 native ID 绑定候选放到同一隔离库，发现并修正两处候选缺口。最终 attempt-jqDtPY 六项通过，未改产品源码。

## 范围和来源

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，当前实际服务重新构建，379 项输入摘要复核。实际服务建立合法 schema-3 会话、绑定合成 native ID、复制合成历史并提交 adoptLibrary，形成旧根／当前根；迁移候选在同库投影两种根的占用。程序化 prepared binding 和源修订通过夹具创建，首次回调参数为合成，没有 SDK、原生进程或模型。

复用 retained-claims 的 migration／SQL／claim／retained 模块，以及 business-mcp-joint 的 programmatic 首次绑定函数。新增 claims-joint 将原函数包在共享 claim 检查、来源写入和同一事务中。此为固定文件摘要的研究组合，不是最终产品 Schema 或完整 TaskService。

## 六项检查

| 检查 | 结论 |
| --- | --- |
| J01 旧候选反例 | 原 programmatic bindNativeLocked 只查当前 legacy identity；迁移复制后，另一 binding 可在旧根绑定仍由原历史占用的 native ID。原占用还在，因此是候选漏检，不是原产品错误 |
| J02 共享占用 | 新候选先查 canonical root／runner／native ID 的共享 claim，历史冲突拒绝且全库不变；非规范根明确拒绝，要求调用方先完成可信路径解析 |
| J03 来源与重放 | 首次绑定保存精确 cap／revision／task／binding 来源；同 ID 重复调用不增加记录；占用及被引用来源不可删除。扩展后的跨 binding 错配来源也由数据库拒绝 |
| J04 旧入口 | 新绑定建立占用后，实际旧 CapabilitySessionRegistry.create 无法认领该身份；原旧快照不变 |
| J05 原子回滚 | 新 revision 写入后、来源 claim 写入后分别注入异常，整个事务回滚；在未启动任何原生输入前可显式重试 |
| J06 新入口互斥 | 两个 prepared 程序化 binding 先后尝试同一身份，第二个被共享 claim 拒绝且保持原状态；不是跨进程竞争证明 |

## 保留的失败

attempt-QdauFs 的原六项通过，但当时 J03 未覆盖跨 binding 来源误关联。扩展用例后，attempt-nCn1ZW 的 J03 因缺少预期异常失败：来源表分别外键关联 claim 的身份三元组和 revision，却没有证明二者属于同一 task／binding。修正 claims-joint 的 SQL：为 claim 建立包含 task／binding 的唯一键，来源以对应复合外键关联，再复验得到 attempt-jqDtPY。三次原始脚本、SQL、结果和数据库全部保留。

这不是修改断言掩盖失败，也不是把当前产品标记为有此缺陷。J01 始终保留旧候选反例；实际产品的 session 创建仅用来验证共库守卫适用性。

## 设计影响与未验项

首次原生身份发布必须与历史占用读取使用同一冲突域；只检查 capability_session_identities 当前根或 binding 当前根不够。新 claim 同时保存来源 revision，其 task／binding／cap 的归属必须与 claim owner 在数据库关系上相等。旧历史来源与新程序化来源可分表，但不能凭两条独立外键推断两端 owner 一致。

准备 binding、正式原生回调、owner、run generation、准入和业务结果仍要联合；本轮没有把合成回调当可信原生来源。正式迁移版本、全写入口、合法后续根变化／释放／降级、GC 和崩溃恢复未关闭。受控同步异常只证明 SQLite 原子性，不替代 SIGKILL／多宿主接管。

所有保存数据库完整性／外键通过，没有活动 run 或未释放租约。复现：固定 build.mjs 依赖构建，执行 node probe.mjs；不需要网络或账号。见[结果](result.json)、[来源及清理审计](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text();old='| 身份占用来源 | 历史 claim 关联经过 Schema／摘要／任务核验的原 snapshot revision，必要来源受外键／保留规则保护；新建 claim 的原生证据按 §3.2.9 保存。来源损坏／歧义保持待核查，不凭 JSON 存在授予占用或执行权限 |';new='| 身份占用来源 | 历史 claim 关联经过 Schema／摘要／任务核验的原 snapshot revision；程序化 claim 关联精确 capability revision，来源 task／binding 必须与 claim owner 由复合关系保证一致，不能只分别外键到两端。必要来源受删除保护，新建 claim 的可信原生证据按 §3.2.9 保存；损坏／歧义保持待核查，不凭 JSON 存在授予占用或执行权限 |';assert old in t;t=t.replace(old,new,1)
needle='首次 native ID 的写入必须在同一协调边界和数据库事务更新：'
start=t.index(needle);end=t.index('\n\n',start)
t=t[:end]+'''\n\n[程序化首次绑定与保留身份联合实验](实验/20261114_程序化首次绑定与保留身份联合验证/README.md)复现早批 programmatic 候选只查旧当前 identity、遗漏已复制历史根 claim 的问题。候选先核共享占用，再原子更新 native revision／current pointer／claim 和精确来源；实际旧 create、新入口冲突、同 ID 重放和两个中途回滚检查通过。新增来源表最初仅独立外键到 claim 与 revision，仍允许跨 binding 错配；失败后补含 task／binding 的复合约束，反例被拒绝。正式模型必须保证 claim owner 与 source owner 相同；这一约束不能只留在写入函数中。实验使用合成首次回调、真实旧会话／复制服务和同库候选，真实 owner／run 准入及 SDK 回调联合仍待验。'''+t[end:];put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.103 ' not in t
add='''### 4.103 程序化首次绑定与保留历史身份联合

[六项共享身份检查](实验/20261114_程序化首次绑定与保留身份联合验证/README.md)将当前实际旧会话／复制服务、保留历史占用与程序化首次 native ID 候选放在同一隔离库。复现旧 programmatic 候选只查当前 legacy identity、遗漏旧历史根占用；共享 claim 守卫修正后拒绝冲突，实际旧 create 也不能认领新绑定身份，同 ID 重放不增记录，两个事务切点整体回滚。

扩展 J03 复现新来源表的跨 binding 错配：分别指向 claim 身份与 revision 的外键不保证两者 owner 相同。补 task／binding 复合约束后最终六项通过，初次通过、扩展失败和最终记录均保留。当前 379 项构建输入复核，所有保存数据库完整性／外键通过、无活动 run／未释放租约。程序化 prepared 来源与 native 回调仍合成，没有 SDK、运行准入、业务链或宿主崩溃；正式 Schema／全写入口／GC 和降级未关闭。T0.1 §3.2.2／3.2.9 已合并这两项开发约束。

''';t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D01 '):
  c=l.split('|');c[2]=' §4.29／33–48／73–76／88–93／103 已覆盖关键局部，§4.103 补保留历史与程序化首次绑定共库冲突及精确来源外键，修正两项候选缺口。下一步固定同一研究 Schema 修订，联合真实 owner／运行准入、旧写入口及资源保留读取；验证复制中途、合法历史续写后的恢复、旧根释放／回退和异常来源。要求同一状态库的原子提交／失败／接管证据，不把合成回调和分散候选通过拼接为完整迁移 ';lines[i]='|'.join(c)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.102，56','截至 §4.103，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：程序化首次绑定与保留历史共库验证发现两处候选缺口：遗漏旧根占用、来源外键未约束同一绑定。修正隔离候选后六项检查通过，设计已补共享占用与复合关系要求。见[实验记录](技研/实验/20261114_程序化首次绑定与保留身份联合验证/README.md)；未改产品代码，统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'databasesAudited':len(audit),'archiveBytes':archive.stat().st_size}))
