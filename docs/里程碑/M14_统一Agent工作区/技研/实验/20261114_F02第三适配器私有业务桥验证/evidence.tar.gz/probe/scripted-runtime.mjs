import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {once} from 'node:events';
const pending=new Map();let bridge,closed,sequence=0;
function request(method,params){const id=++sequence;return new Promise((resolve,reject)=>{pending.set(id,{resolve,reject});bridge.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');});}
async function command(m){
 if(m.kind==='start'){
  bridge=spawn(m.bridge.command,m.bridge.args,{env:m.bridge.env,stdio:['pipe','pipe','pipe']});closed=once(bridge,'exit');bridge.stderr.pipe(process.stderr);
  createInterface({input:bridge.stdout}).on('line',line=>{const v=JSON.parse(line),p=pending.get(v.id);if(p){pending.delete(v.id);v.error?p.reject(Error(JSON.stringify(v.error))):p.resolve(v.result);}});
  const init=await request('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'scripted-third-adapter',version:'1.0.0'}});bridge.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n');
  const tools=await request('tools/list',{});return{pid:process.pid,bridgePid:bridge.pid,init,tools};
 }
 if(m.kind==='call')return request('tools/call',{name:m.name,arguments:m.args});
 if(m.kind==='close'){bridge.stdin.end();const exit=await closed;return{bridgeExit:exit};}
 throw Error('UNKNOWN_SCRIPTED_COMMAND');
}
const input=createInterface({input:process.stdin});let queue=Promise.resolve();input.on('line',line=>{const m=JSON.parse(line);queue=queue.then(async()=>{try{process.stdout.write(JSON.stringify({id:m.id,result:await command(m)})+'\n');}catch(e){process.stdout.write(JSON.stringify({id:m.id,error:e.message})+'\n');}if(m.kind==='close')input.close();});});
input.on('close',()=>{if(bridge?.exitCode===null)bridge.stdin.end();process.stdin.destroy();});
