from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_问题正常退役与宿主退出恢复验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());cr=json.loads((root/'recovery-latest.json').read_text());assert r['passed']==6 and r['error'] is None and cr['passed']==3 and cr['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
s=json.loads((Path(r['out'])/'host-state.json').read_text());assert sorted(x['cancel_requested'] for x in s['requests'])==[0,0,1];assert all(x['liveness']=='expired' and x['close_evidence'] is None for x in s['requests']);assert len(s['retirements'])==3
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'boundary':r['scope'],'recoveryBoundary':cr['scope'],'candidateChange':'Bind request to actual owned run while active; on terminal native process and run, atomically expire old callback and persist runtime-ended evidence. Does not manufacture native request closure, cancellation or consumption.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','ledger.mjs','ledger.sql','probe.mjs','recovery.mjs','mcp.mjs','model.mjs','native-inputs.mjs','migration.mjs','candidate.sql','source-review.json','prepare.py']]
attempts=sorted(root.glob('attempt-*'));recovery_dirs=sorted(p for p in root.glob('recovery-*') if p.is_dir())
for a in attempts+recovery_dirs:files.extend(p for p in a.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'recovery':cr,'normalAttempts':[json.loads((a/'result.json').read_text()) for a in attempts if (a/'result.json').exists()],'interruptedAttempts':[a.name for a in attempts if not (a/'result.json').exists()],'note':'Three intentionally killed hosts have checkpoint/native traces and parent-recorded SIGKILL outcomes instead of child final result. First normal pass predates addition of recovery checkpoints; final normal pass uses the archived final candidate.'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 问题正常退役与宿主退出恢复验证

日期：2026-11-14。关联 D06、Q11／26／27。修正上轮研究驱动将正常收尾也写成取消的局限；只改临时研究候选，没有修改产品代码。

## 结果

最终同库 SDK 场景六项通过：保留同文子问题隔离、父候选指针变化、取消兄弟隔离和同 native session 新代次旧回应拒绝；新增正常／取消差异与事务失败回滚。三处真实宿主 SIGKILL 恢复检查也通过。

| 分支 | 实际证据 |
| --- | --- |
| 正常 B／A2 完成 | 实际 MCP 收到答案，native 退出 0；实际 run stopped 后，问题 expired、cancel_requested=0、答案 submitted；等待入口结束，close_evidence 仍为空，消费不作通用确认 |
| 主动停止 A1 | 先记录取消并关闭发送 gate，再 interrupt；native 退出 1，cancel_requested=1，未记录用户答案；不影响 B |
| 错误退役 | 活跃 run 不准退役，复制出来的句柄被拒绝；正常退役重复执行幂等，晚到新回答被拒绝 |
| 事务故障 | 在退役证据插入后、活性更新前触发 SQLite 错误，证据与活性整体回滚；重试只退役，不重发答案 |
| 退役前宿主退出 | 原生子进程均已退出；新宿主将旧 open 入口置 expired，保留 submitted 与无取消意图，不重建回调 |
| 退役事务中宿主退出 | SQLite 回滚未提交证据及活性变更；恢复与上一分支一致，没有半条提交 |
| 退役后宿主退出 | 保留已提交 runtime-ended 证据、expired 与原决定；重复恢复结果相同，不生成 native resolved 或自动重试 |

三个退出检查点均先核对实际 PID／出生身份，旧宿主仍运行时恢复被拒绝；只终止驱动捕获的研究宿主。每个宿主的三个原生进程在 SIGKILL 前已退出。三份恢复库及最终正常库外键／完整性通过。首次正常实验六项通过后增加退出检查点，最终版本再跑六项通过；不把重复执行另算新覆盖。

## 设计决定

请求活性与取消意图分开。运行结束只证明旧回调失效；没有精确原生请求关闭证据时，保守记 expired 并附 runtime-ended 原因，而非伪造 closed／resolved。正常提交的答案继续保留 submitted；显示层由取消意图、退役原因、投递事实分别构造状态，不能把 expired 一律显示为“已取消”。

候选在实际 run 活跃时，以原生回调的私有句柄绑定真实注册器和原运行句柄；退役复核原 task／run／snapshot、实际 stopped 状态和原生 PID 出生身份已停止。在同一事务保存退役原因并结束旧等待入口。恢复仍要求旧问题宿主确认停止，不复造活句柄或自动重发。原生结束和业务副作用结果保持分离。

这是固定 Claude SDK 0.3.321／native 2.1.321 与本机合成模型／MCP 的独立研究。父子关系和回应账仍为候选；没有真实用户审批、实际父 Provider 切换、Codex 混合委派、完整 delegate／outbox、业务在途写或 UI。退出实验发生在所有原生进程已结束后，不覆盖原生仍活跃、发送未确认或外部副作用未决的宿主退出；那些分支不能由本轮结论放行。

## 复现与来源

固定依赖和本机监听权限具备时依次执行 `node build.mjs`、`node probe.mjs`、`node recovery.mjs`。归档包含最终驱动、379 条源码输入摘要、真实原生帧、两轮正常结果、三个主动终止现场和恢复数据库。模型与答案均为合成内容，隔离 HOME／配置，无付费模型服务。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
old='实验同时暴露收尾边界：驱动对正常完成也调用 cancel，不能把该 expired／cancel_requested 终态作为产品正常关闭依据。运行退役、用户取消意图、原生请求结束和回应投递分别记录；无精确对应的原生关闭证据时只关闭失效入口并保留投递事实，不补造批准／取消。正常终态、问题账恢复及真实 UI／业务联合仍需验证。'
new='''该实验曾暴露驱动对正常完成也调用 cancel 的局限；后续[正常退役与宿主退出实验](实验/20261114_问题正常退役与宿主退出恢复验证/README.md)已在同库真实 Claude 子运行中区分：正常运行退出后结束旧回答入口，cancel_requested 保持 0，已提交答案保持 submitted；主动停止才记录取消意图。缺精确原生关闭证据时记 expired 并保存独立 runtime-ended 原因，不伪造 closed／resolved，也不将 expired 一律显示为“已取消”。实际原生进程与 run 停止后，同事务写退役证据并改变活性；事务失败整体回滚，重试不重发答案。

三个真实宿主退出窗口覆盖退役前、事务中及提交后；恢复保留取消区别和已提交答案，不复造回调或消费 ACK。此时所有原生进程已退出，不证明原生仍活跃、发送未确认或业务在途写的恢复。运行退役、用户取消、原生请求结束和回应投递继续分别记录；完整混合委派、真实 UI／业务和其余退出窗口仍待联合。'''
assert old in t;t=t.replace(old,new,1)
t=t.replace('人工审批、正常关闭与取消恢复的完整接线仍待验证。','正常退役／取消区别及原生退出后的问题账恢复已补限定证据；人工审批与完整接线仍待验证。',1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.95 ' not in t
t=t.replace('父指针为候选，正常关闭／真实 UI／业务与崩溃联合仍待验 |','父指针为候选；§4.95 补正常退役／主动取消区别、事务失败与原生已退出后三处真实宿主 SIGKILL 恢复，真实 UI／业务、原生仍活跃及混合链仍待验 |',1)
add='''### 4.95 正常请求退役与宿主退出恢复

[最终六项运行检查及三个宿主退出窗口](实验/20261114_问题正常退役与宿主退出恢复验证/README.md)补上 §4.94 驱动的收尾局限：正常 B／A2 不再设置取消意图，保留已提交答案；实际 run／原生进程结束后，候选同事务写 runtime-ended 证据并使旧入口失效。主动取消 A 保持单独事实；活跃运行、复制句柄和晚到回答拒绝，数据库注入失败不留半条退役。

退役前、事务中、提交后三个真实研究宿主 SIGKILL 后，新进程恢复均不重发、不复造回调，正常 cancel_requested=0、submitted 和未知原生消费保持；事务中未提交证据回滚。三次终止前原生进程已全部退出，不能据此宣称原生仍活跃或业务在途写的恢复完成。此前正常六项在加检查点前已通过，最终版本复验六项，不重复累计覆盖。Q26 继续部分；无产品代码、真实 UI／审批或完整混合委派接线。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
t=t.replace('仍缺正常关闭／取消区别、混合 Provider 与崩溃恢复','§4.95 又补正常退役／取消区别及原生退出后三处宿主恢复；仍缺混合 Provider、原生仍活跃与完整业务链的联合恢复',1)
t=t.replace('截至 §4.94，56 个宽口径问题项中','截至 §4.95，56 个宽口径问题项中',1).replace('Q26 已补同库子问题与实际 run 联合，正常关闭、完整业务及恢复仍未关闭。','Q26 已补同库子问题、正常退役／取消与原生退出后的问题账恢复，完整业务、混合链及其余恢复窗口仍未关闭。',1)
assert len(re.findall(r'^\| Q\d{2} \|',t,re.M))==56;put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();t=re.sub(r'^最新进展：.*$','最新进展：正常问题退役与主动取消已在隔离候选中分离，补了事务回滚和原生退出后三处宿主退出恢复证据。见[正常退役与恢复实验](技研/实验/20261114_问题正常退役与宿主退出恢复验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续验证混合 Provider 委派问题、原生仍活跃时的回应恢复与完整业务联合，并核对迁移／资源剩余约束；局部恢复通过不代表完整委派链完成。',t,flags=re.M);put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-host-question-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'normalChecks':r['passed'],'recoveryWindows':cr['passed']}))
