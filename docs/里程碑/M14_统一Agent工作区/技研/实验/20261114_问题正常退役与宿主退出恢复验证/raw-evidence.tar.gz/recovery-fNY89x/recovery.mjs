import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdtempSync,writeFileSync,appendFileSync,readFileSync,copyFileSync} from 'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import * as ledger from './ledger.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/recovery-'),checks=[],workers=[],reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
const save=(name,value)=>writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('WATCHDOG:'+label)),20000))]).finally(()=>clearTimeout(timer));};
for(const n of ['recovery.mjs','probe.mjs','ledger.mjs','ledger.sql','build.json'])copyFileSync(root+'/'+n,out+'/'+n);
let error;
try{
 for(const cut of ['before-retire','retirement-inserted','after-retire']){
  const checkpoint=Promise.withResolvers();checkpoint.promise.catch(()=>{});
  const p=spawn(process.execPath,[root+'/probe.mjs'],{cwd:root,env:{PATH:'/usr/bin:/bin',HOME:out,TMPDIR:out,WY_RETIREMENT_CUT:cut},stdio:['ignore','pipe','pipe']});
  const worker={cut,pid:p.pid,exit:null};workers.push(worker);
  const exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(code,signal)=>{worker.exit={code,signal};resolve();});});
  p.stderr.on('data',b=>appendFileSync(out+'/'+cut+'-stderr.log',b));
  const lines=createInterface({input:p.stdout});lines.on('line',line=>{appendFileSync(out+'/'+cut+'-stdout.jsonl',line+'\n');try{const v=JSON.parse(line);if(v.type==='checkpoint')checkpoint.resolve(v);else if(v.error)checkpoint.reject(Error(v.error));}catch(e){checkpoint.reject(e);}});
  let db;
  try{
   const cp=await deadline(checkpoint.promise,cut);assert.equal(cp.point,cut);assert.deepEqual(reader.read(p.pid),cp.identity);assert(cp.processes.length===3&&cp.processes.every(x=>x.exit!==null));save(cut+'-checkpoint.json',cp);
   db=new Database(cp.db);db.pragma('foreign_keys=ON');const store=new actual.ResourceStore(db,cp.root,undefined,{processes:reader});
   await assert.rejects(ledger.recover(store,reader,cp.requestId),/OLD_OWNER_LIVE_OR_UNKNOWN/);
   p.kill('SIGKILL');await deadline(exit,cut+' exit');assert.equal(worker.exit.signal,'SIGKILL');assert.equal(reader.state(cp.identity),'stopped');
   const before=ledger.inspect(store,cp.requestId),retirement=db.prepare('SELECT * FROM m14_request_retirement WHERE request_id=?').get(cp.requestId);
   assert.equal(before.request.liveness,cut==='after-retire'?'expired':'open');assert.equal(!!retirement,cut==='after-retire');assert.equal(before.request.cancel_requested,0);assert.equal(before.decision.delivery,'submitted');
   const recovered=await ledger.recover(store,reader,cp.requestId),again=await ledger.recover(store,reader,cp.requestId);assert.deepEqual(again,recovered);
   assert.equal(recovered.request.liveness,'expired');assert.equal(recovered.request.cancel_requested,0);assert.equal(recovered.request.close_evidence,null);assert.equal(recovered.decision.delivery,'submitted');assert.equal(recovered.liveGrant,false);assert.equal(recovered.automaticRetry,false);assert.equal(recovered.view.consumption,'unproven');assert(!recovered.view.awaitingUser&&!recovered.view.awaitingNative);
   assert.equal(db.prepare("SELECT COUNT(*) AS n FROM capability_runs WHERE state!='stopped'").get().n,0);assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);
   await db.backup(out+'/'+cut+'.sqlite');save(cut+'-result.json',{before,recovered,retirement:retirement??null});
   checks.push({cut,status:'passed',nativeExitedBeforeHostKill:true,retirementCommitted:!!retirement,cancelFlag:0,delivery:'submitted',nativeConsumption:'unproven',noRetryOrLiveGrant:true});
  }finally{db?.close();if(p.exitCode===null&&p.signalCode===null){p.kill('SIGTERM');await deadline(exit,'cleanup');}lines.close();}
 }
}catch(e){error=e.stack;process.exitCode=1;}
const result={out,checks,workers,error:error??null,passed:checks.length,scope:'Three real host SIGKILL windows after actual Claude processes exit, using actual shared SQLite and ResourceStore. Candidate request retirement and recovery only; no business side effects, native request reopen, exact native-close acknowledgement or UI.'};save('result.json',result);writeFileSync(root+'/recovery-latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
