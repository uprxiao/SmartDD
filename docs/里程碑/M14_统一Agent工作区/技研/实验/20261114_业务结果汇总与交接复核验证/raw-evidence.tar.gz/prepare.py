from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_业务结果汇总与交接复核验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==9 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
refs=['src/main/core/applications/execution-context.ts','src/main/core/applications/mail-execution-service.ts','src/main/core/browser/operations.ts','src/main/core/applications/run-registry.ts','drizzle/0012_application_invocations.sql','drizzle/0016_application_data_operations.sql','drizzle/0030_browser_operations.sql']
t3=Path('/Users/hx/projects/t3code/apps/server/src/orchestration-v2/ProviderSessionManager.ts')
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':x,'sha256':sha((repo/x).read_bytes())} for x in refs],'t3':{'path':str(t3),'sha256':sha(t3.read_bytes()),'head':'f313d0a6cb843551fb60e57a454a71e71a3a8c04','observation':'releaseEntry separately drains subscribers, closes scope and writes release records; tool items interrupted is not proof of external business outcome; source inspection only'},'scope':r['scope'],'findings':['Current data execution-context records CANCELED as cancelled even for write without a separate effect field; cancellation alone is insufficient evidence of no external effect.','Read-only semantics establish no-write-effect, not successful delivery.','Four business ledgers need independent source coverage; required-source failure cannot be an empty list.','Source content fingerprint recheck in immediate transaction detects tested precommit changes, but no proof of complete launch arbitration or postcommit business exclusion.'],'candidateLimits':['Selected metadata only, no production event projection or native launch','No real mailbox, browser or plugin write','OwnerState for mail recovery controlled','Unknown/nonempty module targets intentionally unverified; object-level scope not implemented','Terminal executed mail result decoder not integrated; such rows conservatively unverified','Reads all historical source rows in candidate; no performance or migration coverage proof','No proof that schema-empty database contains complete prior history','No binding/generation/command admission integration; run-state DB check is not OS-process proof']}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','summary.mjs','fixture-mail.mjs','probe.mjs','audit.json','source-review.json','prepare.py']]
for d in sorted(root.glob('attempt-*')):files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 业务结果汇总与交接复核验证

日期：2026-11-14。D04，关联 Q09／Q37–42、Q49。目标是验证独立业务账的遗漏、状态解释、作用域和最终复核。仅改临时研究脚本和 M14 文档；不实施产品功能，不调用真实模型或外部业务。

当前 SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7` 的迁移、run registry、资源协调锁及 MailExecutionService 重新构建，387 条输入摘要核对通过。使用实际 runFixture，prepare 后以持有的 cancelBeforeFork 收口，未启动原生进程。MailExecutionService.recover 的 ownerState 固定为 stopped；记录由合法合成行提供，SMTP submit 始终未调用。汇总与准入回执是临时候选，不是实际产品服务。

## 九项检查

| 检查 | 结果与证据边界 |
| --- | --- |
| S01 | 实际运行账 stopped 后，空业务账允许写入研究交接回执；不产生 SDK 启动或业务授权 |
| S02 | 通用调用、浏览器、无 task 的项目 UI 数据写和邮件 unknown 同时进入汇总；同字符串 operationId 不跨来源擅自合并；邮件实际恢复释放租约后仍阻止交接 |
| S03 | succeeded＋unknown、failed＋未知 effect 仍待核实；write cancelled 保守为 unknown；read cancelled 是读取未完成、无写副作用，不是业务成功 |
| S04 | 能确定属于另一项目的 UI 操作不阻断当前项目；缺失 run／task、归属冲突、无项目连接管理记录保留 unverified；尚无对象级解析能力 |
| S05 | 一个邮件 intent 的授权／执行关联作为一个项目解释；实际恢复将未使用授权 stale／grant revoked；缺失所指 execution 拒绝，未生成新发送权 |
| S06 | 最终事务重新读取所选证据并校验摘要，发现预览后的插入、无时间戳变动的状态修改和删除；不能沿用旧预览。状态修改是合成 SQL，不是业务对账接口证明 |
| S07 | 回执插入后触发 SQLite ABORT，事务无残留；实际 registry 的 prepared run 阻止新回执，之后以本宿主未 fork 证明停止 |
| S08 | 必需来源表暂不可读时返回 coverage unverified，不伪装为空集合、不放行；表恢复后外键完整 |
| S09 | 未经业务模块解析的非空 targets 保持 unverified，不根据对象名字猜允许范围 |

最终 attempt-xxtGFP 九项通过；第一次 attempt-c93kTI 八项通过后，复核认为 resolved-read 不能表达“取消读取但无写副作用”，故改为 read-incomplete 并显式分开写副作用判据，同时补未知 targets 检查。两份驱动与结果均保留，最终证据以第二次为准；没有把首次结果改写成最终版本。

独立只读审计：两条成功研究回执、所有实际 run stopped、无原生 PID、租约全部 released，SQLite integrity／foreign_key_check 通过；SMTP 调用数 0。

## 设计变化

- 数据操作 cancelled 没有独立 effect 证明。源码 catch 可把 write 的 CANCELED 写成 cancelled，不能据此推导未执行或自动重试；这是源码路径与合成行验证，没有执行真实外部写来证明某次取消产生了副作用。
- 将业务结果、运行活性、读取交付、审批和允许动作分别解释；汇总无待处理写不等于所有读取成功。
- 最终交接事务要核对来源修订／内容和覆盖范围。候选只检测预览与事务之间的变化，不证明事务后不存在新业务，也不证明未知历史从未发生。
- T3 的 releaseEntry 分别处理订阅排空、scope 关闭和释放记录；被打断的工具条目并非外部副作用结果。WillYou 的业务账继续独立解释，不从 T3 session 状态推导邮件／数据库完成。

## 未关闭范围

候选全表读取仅用于小型合成库，不是可直接投入产品的查询或性能方案。非空 targets、无归属连接管理记录和已执行邮件终态尚未接实际模块解码器，当前保守限制较宽；不能宣称完整业务汇总或精细化受限继续已经就绪。通用调用与 data operation 是否属于同次动作，需要实际来源关联后再去重；本轮只验证不因字符串相同误合并。

完整交接还须联合 binding／generation、原生与后台执行范围、工作区写权、真实业务上下文／最终授权及所有写入口的协调边界。摘要不授予权限，研究回执不触发新 run；关闭窗口后的变化、宿主崩溃、持久来源覆盖／清理墓碑和大数据量仍待验证。其他业务如文件／SSH 不因四类账为空就被视为不存在。

复现：具备归档 build.mjs 指向的固定本机依赖时，在解包目录运行 `node build.mjs`、`node probe.mjs`；使用隔离 SQLite，无真实账号。见 [结果](result.json)、[来源及边界](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
old='当前仅取得独立账遗漏反例及恢复合同证据，完整聚合服务尚未实现。'
new='[汇总与交接复核实验](实验/20261114_业务结果汇总与交接复核验证/README.md)已在当前实际 Schema／运行账和邮件恢复器上验证四来源纳入、无 task 项目操作、邮件关系归并、作用域冲突、预览后变更与缺来源拒绝；聚合及交接回执为隔离候选，完整产品服务尚未实现。'
assert old in t;t=t.replace(old,new,1)
needle='限制应落在有证据的范围：'
addition='''**终态标签不代替副作用证明。** 当前数据操作账没有独立 effect_state，execution-context 的 CANCELED 分支可把写操作记为 cancelled；汇总不得因此推导未执行或允许自动重发。业务模块有充分回执时按回执解释，否则写入效果保留 unknown。只读取消／失败虽不产生该合同下的写副作用，仍是读取未完成，UI 不能显示业务成功。已执行邮件的 server-accepted／failed 由邮件模块校验结果及收件人范围；不由通用聚合器仅凭字符串归类。通用调用与数据操作即使 ID 相同，也须有实际映射证据才归并。

**来源覆盖与最终准入。** 汇总返回来源覆盖版本、源记录关联与修订；未知格式、缺表、损坏关联不能作为零条结果。浏览器无 project_id 时核对 task／run 的归属，冲突或无法定位保持 unverified。数据 targets 和无项目连接管理操作由业务模块提供可验证范围，未经解析不得猜测无关或开放对象级继续。最终准入在共同资源协调边界和写事务内重新取得所需证据，校验预览修订，再联合 binding／generation、原生活性、后台作用域和目录写权作决定。候选九项检查只证明所选字段的插入／修改／删除和回执回滚，没有证明完整写入口排他或事务后的准入有效期。生产实现需让相关写入口遵守相同协调协议，或以持久预约及再次消费校验覆盖该间隙；不能把哈希相同作为独立启动许可。对已清理历史保留覆盖缺口和未决索引，不因当前表存在且为空宣称历史完整。

'''
assert needle in t;t=t.replace(needle,addition+needle,1)
put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.99' not in t
add='''### 4.99 业务结果汇总与最终交接复核

[九项隔离检查](实验/20261114_业务结果汇总与交接复核验证/README.md)在当前实际迁移／run registry／资源锁／邮件恢复器上验证候选四来源汇总。已 stopped 且邮件租约 released 仍保留未知发送；无 task 的项目 UI 写纳入，同 ID 不跨来源猜测合并，邮件关联作为单项。外项目已知记录不误挡；缺归属、冲突、缺表、未知 effect／targets 保持未核实。最终事务发现预览后的插入、无时间戳状态变更和删除，回执失败整体回滚，prepared run 拒绝。

源码复核补充 write cancelled 不等于没有副作用，读取无写副作用不等于读取成功。第一轮八项通过后修正候选的读取分类并补对象解码边界，最终九项通过；两次原始记录保留。当前无原生 fork、SMTP 或真实业务写；所有 run stopped、租约 released、完整性／外键通过。尚未接实际对象范围与已执行邮件回执解码、完整业务授权／所有写入口准入、清理覆盖和大库性能；本轮不提升任何 Q 为整项关闭。T0.1 §9.2.1 已合并语义与最终准入限制。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| D04 '):
  cols=line.split('|');cols[2]=' §4.99 已补实际 Schema 下的候选四来源汇总、状态／归属冲突与最终复核。下一步接业务模块的 typed targets／邮件执行结果与范围解码，联合真实上下文／预检／最终授权、插件版本／审阅、浏览器 run 授权及四类 MCP 释放；再与 D01 同库运行准入／所有写入口共享协调边界，验证提交后的变更与恢复。未决索引、清理覆盖和大库查询不能由小库全表实验代替 ';lines[i]='|'.join(cols)
 if line.startswith('| Q09 '):lines[i]=line[:-1].rstrip()+'；§4.99 补四来源候选汇总与最终复核，实际对象／邮件解码和全入口准入仍待验 |'
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.98，56','截至 §4.99，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('最新进展：'):lines[i]='最新进展：当前实际业务 Schema／运行账与邮件恢复器上的九项候选汇总和交接复核通过，明确取消写入、读取交付与副作用结果的不同语义。见[实验记录](技研/实验/20261114_业务结果汇总与交接复核验证/README.md)；仅为独立研究，数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if line.startswith('下一步：'):lines[i]='下一步：推进[验证账 D04](技研/全局设计验证账.md#71-当前全局收口方式)的实际业务对象／邮件回执解码与上下文授权，再联合同库身份／资源／运行准入及所有写入口；现有局部证据按边界复用，产品 UI／安装验收保持后续阶段。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files)},ensure_ascii=False))
