import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync,copyFileSync} from 'node:fs';
import actual from './actual.cjs';
import {preview,admit} from './summary.mjs';
import {makeMailFactory} from './fixture-mail.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-');
for(const name of ['probe.mjs','summary.mjs','fixture-mail.mjs','build.mjs','build.json'])copyFileSync(root+'/'+name,out+'/'+name);
const save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
let f,run,mail,error,submissions=0;const checks=[];
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});save(id+'.json',evidence);}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
try{
 f=await actual.runFixture(undefined,{application:true});
 const db=f.sqlite,task=f.snapshot.taskId,hash='a'.repeat(64),stamp=new Date().toISOString();
 const insert=(table,row)=>db.prepare(`INSERT INTO ${table}(${Object.keys(row).join(',')}) VALUES(${Object.keys(row).map(()=>'?').join(',')})`).run(...Object.values(row));
 const taskRow=(id,project)=>insert('tasks',{id,project_id:project,cwd:f.snapshot.native.cwd,runner:'claude-code',title:'synthetic summary fixture',created_at:1,updated_at:1});taskRow(task,'p1');
 db.exec("INSERT INTO projects(id,name,created_at,updated_at) VALUES('p2','unrelated synthetic project',1,1)");taskRow('other-task','p2');
 db.exec('CREATE TABLE research_handoff_receipts(id TEXT PRIMARY KEY,project_id TEXT,summary_digest TEXT)');
 run=await f.create();await run.prepare();await run.cancelBeforeFork();
 const clear=()=>{for(const table of ['mail_send_grants','mail_send_executions','mail_send_intents','mail_draft_revisions','mail_drafts','browser_operations','application_data_operations','application_invocations'])db.prepare('DELETE FROM '+table).run();};
 const ui=(state='unknown',project='p1',semantics='write',id=randomUUID())=>{insert('application_data_operations',{operation_id:id,caller_kind:'ui',scope_kind:project?'project':'connection-management',project_id:project,app_id:f.application.appId,package_hash:f.application.packageHash,data_api:1,action:'ui.zentao.work',semantics,scope_hash:hash,state,started_at:stamp});return id;};
 const browser=(state='unknown',effect='unknown',tid=task,rid=run.runId)=>{const id=randomUUID();insert('browser_operations',{run_id:rid,request_id:id,task_id:tid,command:'click',state,effect_state:effect,created_at:1,updated_at:1});return id;};
 const invocation=(id=randomUUID())=>{insert('application_invocations',{operation_id:id,run_id:run.runId,request_id:randomUUID(),request_hash:hash,project_id:'p1',task_id:task,app_id:f.application.appId,package_hash:f.application.packageHash,tool_name:'smartdd_zentao_write_v1',contract_major:1,semantics:'write',state:'unknown',effect_state:'unknown',started_at:stamp});return id;};
 const makeMail=makeMailFactory(f,run,insert),unused=new Proxy({},{get(){throw Error('Non-recovery dependency used');}});
 mail=new actual.MailExecutionService(f.store,unused,unused,unused,{ownerState:()=> 'stopped'},{submit:async()=>{submissions++;throw Error('SMTP forbidden');}});
 await check('S01','actual stopped registry is separate from candidate business admission',async()=>{
  const r=db.prepare('SELECT state FROM capability_runs WHERE run_id=?').get(run.runId);assert.equal(r.state,'stopped');
  const s=preview(db,'p1');assert.equal(s.items.length,0);const receipt=await admit(f.store,'p1',s.digest);
  return{run:r,receipt,nativeForked:false};
 });
 await check('S02','four independent ledgers survive stopped run and released mail lease',async()=>{
  const id=invocation();ui('unknown','p1','write',id);browser();const sent=makeMail('executing');await mail.recover();
  assert.equal(db.prepare('SELECT state FROM capability_resource_leases WHERE lease_id=?').get(sent.lease).state,'released');
  const s=preview(db,'p1');assert.deepEqual(s.items.map(i=>i.source).sort(),['browser','data','invocation','mail']);assert(s.items.every(i=>i.blocked));
  assert.equal(s.items.filter(i=>i.id===id).length,2);await assert.rejects(admit(f.store,'p1',s.digest),/BUSINESS_UNRESOLVED/);
  save('four-source-summary.json',s);return{count:s.items.length,sameIdNotMerged:true,mailLeaseReleased:true,unknownMailRetained:true};
 });
 clear();
 await check('S03','state labels and cancelled writes do not erase uncertain effects',async()=>{
  browser('succeeded','unknown');browser('failed','future-effect');ui('cancelled');ui('cancelled','p1','read');
  const s=preview(db,'p1');assert.equal(s.items.filter(i=>i.blocked).length,3);assert(s.items.some(i=>i.source==='data'&&i.outcome==='unknown'));assert(s.items.some(i=>i.outcome==='resolved-read'));
  return{items:s.items,writeCancellationMapping:'current execution-context catch branch plus synthetic legal row; not real external write'};
 });
 clear();
 await check('S04','known unrelated project excluded; unidentified and conflicting ownership retained',async()=>{
  ui('unknown','p2');assert.equal(preview(db,'p1').items.length,0);
  const id=browser('unknown','unknown','missing-task','missing-run');let s=preview(db,'p1');assert.equal(s.items.length,1);assert.equal(s.items[0].outcome,'unverified');
  db.prepare('DELETE FROM browser_operations WHERE request_id=?').run(id);browser('unknown','unknown','other-task',run.runId);
  s=preview(db,'p1');assert.equal(s.items.length,1);assert.equal(s.items[0].scope.verified,false);
  db.exec('DELETE FROM browser_operations');ui('unknown',null);s=preview(db,'p1');assert.equal(s.items.length,1);assert.equal(s.items[0].outcome,'unverified');
  return{otherProjectNotBlocked:true,missingIdentityRetained:true,conflictRetained:true,connectionManagementUnscoped:true,scope:'No module-specific object resolver; unresolved ownership conservatively blocks this candidate'};
 });
 clear();
 await check('S05','mail intent and revoked approval form one non-executable result',async()=>{
  const m=makeMail('authorized');await mail.recover();const s=preview(db,'p1');assert.equal(s.items.length,1);assert.equal(s.items[0].outcome,'resolved-not-submitted');assert.equal(s.items[0].authorization,'revoked');assert.equal(s.blocked,false);
  db.prepare('UPDATE mail_send_intents SET execution_id=? WHERE id=?').run(randomUUID(),m.intent);const broken=preview(db,'p1');assert.equal(broken.items[0].outcome,'unverified');await assert.rejects(admit(f.store,'p1',broken.digest),/BUSINESS_UNRESOLVED/);
  return{singleMailItem:true,unusedApprovalRevoked:true,brokenExecutionReferenceBlocks:true,noSendAuthorityCreated:true};
 });
 clear();
 await check('S06','final source reread detects late insertion, mutation and removal without timestamps',async()=>{
  const empty=preview(db,'p1'),id=ui();await assert.rejects(admit(f.store,'p1',empty.digest),/SOURCE_CHANGED/);
  const unknown=preview(db,'p1');db.prepare("UPDATE application_data_operations SET state='failed' WHERE operation_id=?").run(id);
  await assert.rejects(admit(f.store,'p1',unknown.digest),/SOURCE_CHANGED/);
  const settled=preview(db,'p1');assert.equal(settled.blocked,false);db.prepare('DELETE FROM application_data_operations WHERE operation_id=?').run(id);
  await assert.rejects(admit(f.store,'p1',settled.digest),/SOURCE_CHANGED/);
  const current=preview(db,'p1');const receipt=await admit(f.store,'p1',current.digest);
  return{insertionDetected:true,mutationDetectedWithoutTimestamp:true,deletionDetected:true,receipt,settlement:'synthetic SQL transition only; not a validated business reconciliation endpoint'};
 });
 await check('S07','candidate receipt transaction rolls back and actual registry preparation blocks admission',async()=>{
  const count=()=>db.prepare('SELECT count(*) n FROM research_handoff_receipts').get().n,n=count();
  db.exec("CREATE TRIGGER research_fail AFTER INSERT ON research_handoff_receipts BEGIN SELECT RAISE(ABORT,'injected receipt failure'); END");
  try{await assert.rejects(admit(f.store,'p1',preview(db,'p1').digest),/injected receipt failure/);assert.equal(count(),n);}finally{db.exec('DROP TRIGGER research_fail');}
  const pending=await f.create();await pending.prepare();
  try{await assert.rejects(admit(f.store,'p1',preview(db,'p1').digest),/RUN_NOT_STOPPED/);assert.equal(count(),n);}finally{await pending.cancelBeforeFork();}
  return{receiptRollback:true,actualPreparedRunBlocks:true,newNativeNotForked:true};
 });
 await check('S08','missing required source is an explicit coverage error, never an empty result',async()=>{
  db.exec('ALTER TABLE browser_operations RENAME TO research_hidden_browser');
  try{const s=preview(db,'p1');assert(s.items.some(i=>i.source==='coverage'&&i.blocked));await assert.rejects(admit(f.store,'p1',s.digest),/BUSINESS_UNRESOLVED/);return{coverageError:s.items.find(i=>i.source==='coverage'),allowed:false};}
  finally{db.exec('ALTER TABLE research_hidden_browser RENAME TO browser_operations');}
 });
 assert.equal(submissions,0);
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 if(mail)await mail.dispose();if(f){assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);await f.runs.dispose();await f.sqlite.backup(out+'/final.sqlite');save('fixture.json',{root:f.root});f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:error??null,submissions,scope:'Current actual migrations, run registry prepare/cancel-before-fork and mail recovery with controlled dead owner; candidate summary/admission over synthetic rows. No SDK/native fork, SMTP, business writes, UI or product changes.'};save('result.json',result);save('../latest.json',result);console.log(JSON.stringify(result));
