import {randomUUID} from 'node:crypto';
export function makeMailFactory(f,run,insert){
const hash="a".repeat(64),now=Date.now(),stamp=new Date(now).toISOString(),day=86400000,owner=randomUUID(),oldOwner={pid:77119,startedAt:"darwin-proc-v1:500:20"};
function mailFixture(state){
 const connection=randomUUID(),draft=randomUUID(),intent=randomUUID(),execution=state==='executing'?randomUUID():null,grant=state==='authorized'?randomUUID():null,lease=randomUUID();
 insert('application_connections',{id:connection,app_id:'mail',provider_id:'smtp',name:'synthetic recovery only',config_json:'{}',revision:1,config_revision:1,identity_revision:1,verified_identity_json:'{}',identity_hash:hash,secret_revision:1,policy_revision:1,enabled:1,auth_state:'disconnected',health:'unverified',created_at:stamp,updated_at:stamp});
 insert('mail_drafts',{id:draft,project_id:'p1',subject:'synthetic',attachment_count:0,current_revision:1,state:execution?'sending':'draft',active_intent_id:intent,last_execution_id:execution,created_at:stamp,updated_at:stamp});
 insert('mail_draft_revisions',{draft_id:draft,revision:1,content_json:'{}',content_hash:hash,created_at:stamp});
 insert('mail_send_intents',{id:intent,project_id:'p1',source_task_id:f.snapshot.taskId,source_run_id:run.runId,operation_id:randomUUID(),request_hash:hash,draft_id:draft,draft_revision:1,draft_content_hash:hash,connection_id:connection,identity_revision:1,config_revision:1,policy_revision:1,binding_revision:1,identity_json:'{}',smtp_config_json:'{}',raw_write_id:randomUUID(),message_id:'<synthetic@example.test>',state,grant_id:grant,execution_id:execution,owner_instance_id:owner,owner_pid:oldOwner.pid,owner_started_at:oldOwner.startedAt,created_at:stamp,updated_at:stamp});
 if(execution)insert('mail_send_executions',{id:execution,intent_id:intent,project_id:'p1',draft_id:draft,draft_revision:1,review_hash:hash,state:'executing',secret_revision:1,owner_instance_id:owner,started_at:stamp});
 if(grant)insert('mail_send_grants',{id:grant,intent_id:intent,source:'renderer-confirmation',evidence_id:randomUUID(),evidence_hash:hash,review_hash:hash,evidence_json:'{}',state:'active',expires_at:new Date(now+day).toISOString(),created_at:stamp});
 insert('capability_resource_leases',{lease_id:lease,resource_id:f.application.resourceId,owner_kind:'mail-send',owner_id:intent,host_instance_id:owner,pid:oldOwner.pid,process_started_at:oldOwner.startedAt,state:'active',created_at:stamp});return{intent,draft,execution,grant,lease};
}

return mailFixture;
}
