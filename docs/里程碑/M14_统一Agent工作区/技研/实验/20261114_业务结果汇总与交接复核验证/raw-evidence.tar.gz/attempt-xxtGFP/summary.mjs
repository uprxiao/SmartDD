import {createHash,randomUUID} from 'node:crypto';
import actual from './actual.cjs';
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const selects={
 invocation:'SELECT operation_id,run_id,task_id,project_id,app_id,package_hash,tool_name,contract_major,connection_id,request_hash,semantics,state,effect_state,error_code,attempt_count,ended_at FROM application_invocations ORDER BY operation_id',
 browser:'SELECT run_id,request_id,task_id,page_id,command,state,effect_state,updated_at FROM browser_operations ORDER BY run_id,request_id',
 data:'SELECT operation_id,caller_kind,scope_kind,project_id,task_id,run_id,app_id,package_hash,data_api,action,semantics,state,targets_json,scope_hash,error_code,attempt_count,ended_at FROM application_data_operations ORDER BY operation_id',
 intent:'SELECT id,project_id,source_task_id,source_run_id,draft_id,draft_revision,connection_id,identity_revision,config_revision,policy_revision,binding_revision,review_hash,state,execution_id,grant_id,error_code,updated_at FROM mail_send_intents ORDER BY id',
 execution:'SELECT id,intent_id,project_id,draft_id,draft_revision,state,ended_at FROM mail_send_executions ORDER BY id',
 grant:'SELECT id,intent_id,state,expires_at FROM mail_send_grants ORDER BY id',
};
function identity(db,project,task,run){
 const t=task?db.prepare('SELECT project_id FROM tasks WHERE id=?').get(task):null;
 const r=run?db.prepare('SELECT task_id,project_id FROM capability_runs WHERE run_id=?').get(run):null;
 const projects=[project,t?.project_id,r?.project_id].filter(Boolean);
 const bad=(run&&!r)||(r&&r.task_id!==task)||new Set(projects).size!==1;
 return {projectId:bad?null:projects[0],taskId:task??null,runId:run??null,verified:!bad&&projects.length>0};
}
function effect(row){
 if(['accepted','running'].includes(row.state))return 'pending';
 if(row.state==='unknown'||row.effect_state==='unknown')return 'unknown';
 if(!['not-started','read-only','completed'].includes(row.effect_state))return 'unverified';
 if(row.state==='failed')return 'resolved-failed';
 return row.state==='succeeded'?'resolved':'unverified';
}
export function readSummary(db,projectId){
 const items=[];
 const add=(source,id,row,scope,outcome,extra={})=>{
  if(scope.verified&&scope.projectId!==projectId)return;
  const resolved=outcome.startsWith('resolved');
  items.push({source,id,scope,outcome:scope.verified?outcome:'unverified',blocked:!scope.verified||(!resolved&&!extra.noWriteEffect),evidence:row,...extra});
 };
 try{
  const raw=Object.fromEntries(Object.entries(selects).map(([k,q])=>[k,db.prepare(q).all()]));
  for(const r of raw.invocation)add('invocation',r.operation_id,r,identity(db,r.project_id,r.task_id,r.run_id),effect(r));
  for(const r of raw.browser)add('browser',r.run_id+':'+r.request_id,r,identity(db,null,r.task_id,r.run_id),effect(r));
  for(const r of raw.data){
   let outcome=r.semantics==='read'?(r.state==='succeeded'?'resolved-read':'read-incomplete'):({succeeded:'resolved',failed:'resolved-failed',running:'pending',unknown:'unknown',cancelled:'unknown'}[r.state]??'unverified');
   try{const targets=JSON.parse(r.targets_json);if(!Array.isArray(targets)||targets.length>0)outcome='unverified';}catch{outcome='unverified';}
   // This probe does not decode module-specific targets or grant object-level continuation.
   add('data',r.operation_id,r,identity(db,r.project_id,r.task_id,r.run_id),outcome,{noWriteEffect:r.semantics==='read'&&outcome!=='unverified'});
  }
  for(const r of raw.intent){
   const es=raw.execution.filter(e=>e.intent_id===r.id),gs=raw.grant.filter(g=>g.intent_id===r.id);
   const e=es.find(e=>e.id===r.execution_id),g=gs.find(g=>g.id===r.grant_id);
   const broken=(r.execution_id&&!e)||(r.grant_id&&!g)||es.length>1||es.some(e=>e.project_id!==r.project_id||e.draft_id!==r.draft_id||e.draft_revision!==r.draft_revision)||(e&&e.state!==r.state);
   let outcome='unverified';
   if(broken)outcome='unverified';
   else if(r.state==='unknown'||e?.state==='unknown')outcome='unknown';
   else if(['executing','preparing','authorized','awaiting-authorization'].includes(r.state))outcome='pending';
   else if(!e&&['stale','canceled'].includes(r.state)&&gs.every(g=>g.state!=='active'))outcome='resolved-not-submitted';
   else if(!e&&r.state==='failed'&&r.error_code==='PREPARATION_INTERRUPTED')outcome='resolved-not-submitted';
   // Executed terminal receipts still require the mail module's result decoder.
   add('mail',r.id,{intent:r,executions:es,grants:gs},identity(db,r.project_id,r.source_task_id,r.source_run_id),outcome,{authorization:g?.state??'none'});
  }
  for(const [source,rows] of [['execution',raw.execution],['grant',raw.grant]])for(const row of rows)if(!raw.intent.some(i=>i.id===row.intent_id))add('orphan-mail-'+source,row.id,row,{verified:false,projectId:null},'unverified');
 }catch(error){items.push({source:'coverage',id:'required-source',scope:{projectId,verified:false},outcome:'unverified',blocked:true,error:String(error.message)});}
 items.sort((a,b)=>(a.source+':'+a.id).localeCompare(b.source+':'+b.id));
 return{projectId,items,digest:hash({projectId,items}),blocked:items.some(i=>i.blocked)};
}
export const preview=(db,projectId)=>db.transaction(()=>readSummary(db,projectId)).deferred();
export async function admit(store,projectId,expectedDigest){
 return actual.withResourceLock(store.root,()=>store.sqlite.transaction(()=>{
  const summary=readSummary(store.sqlite,projectId);
  if(summary.digest!==expectedDigest)throw Error('SOURCE_CHANGED');
  if(summary.blocked)throw Error('BUSINESS_UNRESOLVED');
  const active=store.sqlite.prepare("SELECT run_id FROM capability_runs WHERE project_id=? AND state NOT IN ('stopped','failed')").all(projectId);
  if(active.length)throw Error('RUN_NOT_STOPPED');
  const id=randomUUID();store.sqlite.prepare('INSERT INTO research_handoff_receipts(id,project_id,summary_digest) VALUES(?,?,?)').run(id,projectId,summary.digest);
  return{id,summaryDigest:summary.digest,scope:'research receipt only; no native launch or authorization'};
 }).immediate());
}
