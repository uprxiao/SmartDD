import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,renameSync,utimesSync,unlinkSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import actual from '/private/tmp/willyou-m14-viewer-lifetime-probe/actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
const sha=b=>createHash('sha256').update(b).digest('hex'),checks=[],calls=[];
const {runFixture,MacProcessIdentityReader,FileService,FileRootsService,FileRecoveryStore,FileSourceResolver,NativeFileBroker,drizzle}=actual;
let f,files,broker,problem;
const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save('checks.json',checks)}};
try {
 const build=JSON.parse(readFileSync('/private/tmp/willyou-m14-viewer-lifetime-probe/build.json','utf8'));for(const x of [...build.sources,...build.outputs])assert.equal(sha(readFileSync(x.path)),x.sha256,x.path);
 const nativeBuild=JSON.parse(readFileSync('/private/tmp/willyou-m14-git-probe/build.json','utf8'));for(const x of nativeBuild.files)assert.equal(sha(readFileSync(x.path)),x.sha256,x.path);
 const native='/private/tmp/willyou-m14-git-probe/file-broker';assert.equal(sha(readFileSync(native)),JSON.parse(readFileSync('/private/tmp/willyou-m14-git-probe/broker-result.json')).helperSha256);
 save('input-hashes.json',{bundle:build,nativeBuild,native:{path:native,sha256:sha(readFileSync(native))}});
 f=await runFixture(new MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'));
 const cwd=f.snapshot.native.cwd;mkdirSync(cwd,{recursive:true});mkdirSync(f.root+'/userdata',{recursive:true});
 f.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,1,1)').run(f.snapshot.taskId,f.snapshot.projectId,cwd,'claude-code','synthetic read dependencies');
 execFileSync('/opt/homebrew/bin/svnadmin',['create',f.root+'/svn-repository']);execFileSync('/opt/homebrew/bin/svn',['checkout','file://'+f.root+'/svn-repository',cwd],{encoding:'utf8'});
 mkdirSync(cwd+'/src');mkdirSync(cwd+'/unrelated');writeFileSync(cwd+'/src/item.txt','AAAA');writeFileSync(cwd+'/unrelated/unread.txt','not an analysis dependency');utimesSync(cwd+'/src/item.txt',1700000000,1700000000);
 execFileSync('/opt/homebrew/bin/svn',['add','src','unrelated'],{cwd,encoding:'utf8'});execFileSync('/opt/homebrew/bin/svn',['commit','-m','synthetic fixture baseline'],{cwd,encoding:'utf8'});
 const resolver=new FileSourceResolver(drizzle(f.sqlite));broker=new NativeFileBroker(native);const request=broker.request.bind(broker);broker.request=async(input,...args)=>{calls.push({operation:input.operation,relativePath:input.relativePath,root:input.root?.path});return request(input,...args)};
 files=new FileService(new FileRootsService(resolver,broker),broker,new FileRecoveryStore(broker,f.root+'/userdata',resolver));
 const owner='research-reader',scope=await files.openScope(owner,{kind:'task',taskId:f.snapshot.taskId}),cap=scope.roots.find(x=>x.source==='task-cwd');assert(cap);
 const at=relativePath=>({lease:cap.lease,generation:cap.generation,relativePath}),list=()=>files.list(owner,at('src')),open=()=>files.open(owner,at('src/item.txt'));
 let doc=await open();const initial=await files.read(owner,doc.ref),before=structuredClone(initial.document.revision),listing=await list();
 await check('R01','same size and restored mtime still changes content revision',async()=>{
  writeFileSync(cwd+'/src/item.txt','BBBB');utimesSync(cwd+'/src/item.txt',1700000000,1700000000);
  const afterList=await list();assert.deepEqual(afterList,listing);
  await assert.rejects(files.chunk(owner,doc.ref,0,4,before.hash),e=>e.code==='CHANGED');
  const conflict=await files.save(owner,{ref:doc.ref,opId:randomUUID(),bufferVersion:1,baseHash:before.hash,base64:Buffer.from('STALE').toString('base64')});assert.equal(conflict.state,'conflict');assert.equal(readFileSync(cwd+'/src/item.txt','utf8'),'BBBB');
  const current=await files.refresh(owner,doc.ref);assert.equal(current.revision.size,before.size);assert.equal(current.revision.modifiedNs,before.modifiedNs);assert.equal(current.revision.inode,before.inode);assert.notEqual(current.revision.hash,before.hash);
  return{before,after:current.revision,directoryListIdentical:true,staleChunkRejected:true,staleSave:conflict};
 });
 await check('R02','same content replacement is not the original physical file',async()=>{
  const old=await files.refresh(owner,doc.ref);renameSync(cwd+'/src/item.txt',cwd+'/held-original.txt');writeFileSync(cwd+'/src/item.txt','BBBB');utimesSync(cwd+'/src/item.txt',1700000000,1700000000);
  await assert.rejects(files.chunk(owner,doc.ref,0,4,old.revision.hash),e=>e.code==='CHANGED');
  const conflict=await files.save(owner,{ref:doc.ref,opId:randomUUID(),bufferVersion:2,baseHash:old.revision.hash,base64:Buffer.from('STALE').toString('base64')});assert.equal(conflict.state,'conflict');
  const current=await files.refresh(owner,doc.ref);assert.equal(current.revision.hash,old.revision.hash);assert.notEqual(current.revision.inode,old.revision.inode);assert.equal(readFileSync(cwd+'/src/item.txt','utf8'),'BBBB');
  return{before:old.revision,after:current.revision,staleChunkRejected:true,staleSave:conflict,contentHashAloneInsufficient:true};
 });
 await check('R03','negative lookup and directory membership require a new observation',async()=>{
  let missing;try{await files.open(owner,at('src/new.txt'))}catch(e){missing={code:e.code,message:e.message}}assert(missing);
  const previous=await list();writeFileSync(cwd+'/src/new.txt','new file');const added=await list();assert(!previous.some(x=>x.name==='new.txt'));assert(added.some(x=>x.name==='new.txt'));const created=await files.open(owner,at('src/new.txt'));unlinkSync(cwd+'/src/new.txt');await assert.rejects(files.read(owner,created.ref));const removed=await list();assert(!removed.some(x=>x.name==='new.txt'));
  return{missing,previous,added,removed,oldAbsenceCannotBeReused:true,deletedDocumentReadRejected:true};
 });
 await check('R04','preflight does not lock out later external writes',async()=>{
  const validated=await files.read(owner,doc.ref);const revision=structuredClone(validated.document.revision);writeFileSync(cwd+'/src/item.txt','CCCC');
  const conflict=await files.save(owner,{ref:doc.ref,opId:randomUUID(),bufferVersion:3,baseHash:revision.hash,base64:Buffer.from('STALE').toString('base64')});assert.equal(conflict.state,'conflict');assert.equal(readFileSync(cwd+'/src/item.txt','utf8'),'CCCC');
  const reread=await files.read(owner,doc.ref);assert.equal(Buffer.from(reread.base64,'base64').toString(),'CCCC');assert.notEqual(reread.document.revision.hash,revision.hash);
  return{validated:revision,after:reread.document.revision,save:conflict,noAtomicReadSetClaim:true};
 });
 await check('R05','physical root replacement revokes the original lease',async()=>{
  renameSync(cwd,cwd+'-held');mkdirSync(cwd+'/src',{recursive:true});writeFileSync(cwd+'/src/item.txt','replacement root');await assert.rejects(files.read(owner,doc.ref),e=>e.code==='STALE_ROOT');
  assert.throws(()=>files.roots.require(owner,cap),e=>e.code==='UNTRUSTED');assert.equal(readFileSync(cwd+'/src/item.txt','utf8'),'replacement root');assert.equal(readFileSync(cwd+'-held/src/item.txt','utf8'),'CCCC');
  return{oldRootRevoked:true,replacementUntouched:true,oldWorkingCopyPreserved:true};
 });
 await check('R06','on-demand reads never ask broker to hash unrelated project files',async()=>{
  const content=calls.filter(x=>['stat','read','chunk'].includes(x.operation));assert(content.length>0);assert(content.every(x=>['src/item.txt','src/new.txt'].includes(x.relativePath)));assert(!calls.some(x=>x.relativePath==='unrelated/unread.txt'));return{requestedContentPaths:[...new Set(content.map(x=>x.relativePath))],contentRequestCount:content.length,notFullProjectSnapshot:true,notLargeProjectPerformanceProof:true};
 });
 save('svn-status.json',{status:execFileSync('/opt/homebrew/bin/svn',['status'],{cwd:cwd+'-held',encoding:'utf8'})});
}catch(e){problem=e.stack;process.exitCode=1}
finally {if(files){files.closeOwner('research-reader');await files.watcher.dispose()}broker?.dispose();save('broker-requests.json',calls);if(f){save('fixture.json',{root:f.root});f.sqlite.close()}}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,failed:checks.filter(x=>x.status==='failed').length,error:problem??null,scope:'Actual FileSourceResolver/FileService/roots and original native file broker in a local synthetic SVN working copy. No SDK, unified read-dependency service, product wiring, whole-project snapshot or performance claim.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,failed:result.failed,error:result.error}));
