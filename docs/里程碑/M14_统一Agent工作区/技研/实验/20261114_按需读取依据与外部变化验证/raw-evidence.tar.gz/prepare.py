from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_按需读取依据与外部变化验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['failed']==0 and not r['error'];p=Path(r['out']);inputs=json.loads((p/'input-hashes.json').read_text())
for x in inputs['bundle']['sources']+inputs['bundle']['outputs']+inputs['nativeBuild']['files']+[inputs['native']]:assert sha(Path(x['path']).read_bytes())==x['sha256']
refs=[repo/'src/main/core/files/file-service.ts',repo/'src/main/core/files/roots.ts',repo/'src/shared/files.ts',repo/'native/files/broker.mm']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'bundle':'Unchanged previously built actual services; every 718 source hash and output hash rechecked before execution. Electron stub forbids window allocation; none used.','native':inputs['native'],'nativeSourceManifest':inputs['nativeBuild'],'svnVersion':subprocess.check_output(['/opt/homebrew/bin/svn','--version','--quiet'],text=True).strip(),'scope':'Actual file service and native broker, local SVN fixture. No new read-dependency coordinator, SDK read interception, GUI, distributed snapshot, whole-tree hashing or large-workspace performance test.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[(root/n,n)for n in ['probe.mjs','prepare.py','source-review.json']]+[(f,str(f.relative_to(root)))for f in sorted(p.iterdir())if f.is_file()]+[(Path('/private/tmp/willyou-m14-viewer-lifetime-probe/actual.cjs'),'dependencies/actual.cjs'),(Path('/private/tmp/willyou-m14-viewer-lifetime-probe/build.mjs'),'dependencies/build.mjs'),(Path('/private/tmp/willyou-m14-viewer-lifetime-probe/electron-stub.cjs'),'dependencies/electron-stub.cjs')]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x,n in files:tar.add(x,arcname=n,recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':n,'sha256':sha(x.read_bytes())}for x,n in files]}
for n,v in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 按需读取依据与外部变化验证

日期：2026-11-14。关联 R09／Q33。独立技术验证，不是产品验收。

## 实际路径

使用未改的 FileSourceResolver、FileService、FileRootsService、FileRecoveryStore 和原生文件代理，在本机新建 SVN 仓库及工作副本。SQLite 为合成 task 来源；没有 Agent 进程、真实用户数据或网络模型。复用前轮服务 bundle，但执行前核对全部源码及产物哈希；原生文件代理也与先前原始构建和源码摘要一致，没有测试故障注入编译开关。

| 检查 | 实际结果 |
| --- | --- |
| R01 同大小、恢复相同 mtime 的内容修改 | 目录列表完全相同；文件内容摘要改变，旧 chunk 拒绝、旧 baseHash 保存冲突，外部内容保留 |
| R02 相同内容的原子路径替换 | hash 相同、inode 不同；旧 chunk 拒绝，旧文档保存冲突，刷新可见新身份 |
| R03 文件不存在、后创建、后删除 | 初次打开失败；重新列目录发现新增／删除；旧文档删除后不可继续读取 |
| R04 复核后外部再次修改 | 先前读取不锁住外部写入；保存时再次检查并冲突，重读得到新内容 |
| R05 整个根目录被另一目录替换 | 旧读取返回 STALE_ROOT，旧租约撤销；新旧目录内容分别保留 |
| R06 按需范围 | 文件内容请求只涉及 src/item.txt 和 src/new.txt，没有请求读取 unrelated/unread.txt；不代表 I/O 性能测量 |

6 项检查通过；原生代理请求 28 次。所有写入均为合成夹具。这个小 SVN 工作副本只证明非 Git 目录路径可运行，不代表 10GB／高文件数项目性能、SVN update 并发或全项目快照。

## 对设计的约束

FileRevision 的内容 hash 与 device／inode 不能互相替代，size／mtime 也不足以证明内容未变。目录结果只有成员、身份等信息；本次 R01 直接证明列表一致不等于子文件内容一致。目录／glob／搜索结论还包含查询范围、过滤、截断和不存在判断，不能仅记录返回文件的 hash。

当前文件服务不是通用 Agent 读取账：原生 Read、shell、Skill 或第三方 MCP 的任意读取不会因此自动全部登记。M14 必须标明读取依据的覆盖范围，未知／截断不得显示为完整验证；按需重跑相关查询、重读变化文件，不用全库 hash 填补未知。复核后的外部变化仍可能发生，实际写入口必须保留最后冲突检查，raw shell／第三方服务没有同等约束时不能宣称受此保护。

没有实现新的共享目录准入、读取账或多文件原子事务。Q33 保持部分；端到端只读、目录并发完整性、持久化接线与代表性大项目继续待验。

## 证据与复现

[结果](result.json) · [源码与原生摘要](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。

原始 probe.mjs 保留实际执行时的绝对依赖路径。复跑 `node probe.mjs` 需保留前轮 viewer-lifetime bundle、owner-probe 依赖／进程身份工具及 git-probe 文件代理；全部路径与 SHA256 在 input-hashes.json 中。归档另外保存实际 bundle、构建脚本和禁止 Electron 分配的桩，便于审计；它不是脱离原依赖即可运行的发行包。
''')
def tech(t):
 anchor='### 8.2 Git worktree 的起点、准备与成果保留';assert anchor in t and '### 8.1.1 'not in t
 addition='''### 8.1.1 按需读取依据、覆盖范围与复核

[实际文件服务与 SVN 工作副本实验](实验/20261114_按需读取依据与外部变化验证/README.md)验证了可复用的 FileRevision／原生文件代理边界：同大小且恢复相同 mtime 后内容仍可变化，目录列表也可完全相同；相同 hash 的文件仍可能被替换为新 inode。旧 chunk 和旧文档保存均能拒绝相应变化；根目录物理身份变化会撤销旧租约。这是现有文件服务证据，不代表 Agent 全部读取已被接管。

读取依据应携带来源 run／binding／cwd 修订、授权根及物理身份、请求路径与解析路径、读取范围和 FileRevision；查询依据另保存目录／glob／搜索的范围、条件、过滤与返回边界。记录区分完整、截断、未知，保留不存在判断所依赖的查询范围。只记录已返回文件的 hash 会漏掉新增文件、删除项和此前不存在的路径；列表成员一致也不能替代已读内容复核。此处描述待实现的公共合同，不新增一套文件授权或将查看器 owner 直接当作 Agent owner。

汇总或准备写入前，仅对本次声明依赖的文件／查询复核；变化后重读或重跑相关查询，再重建受影响结论。使用当前有效授权重新解析来源，不能用旧 FileRef 绕过 cwd／根变更。查询被截断或无法穷尽时必须说明依据不完整，不能声称“项目中不存在”；不以每回合全盘 hash 或复制整个 SVN 项目补齐未知。

原生 Read、shell、Skill 和第三方 MCP 不自动经过 FileService，适配器只有取得可验证的读取信息才能纳入对应依据；仅解析模型文本、工具名称或提示词不足以声明完整覆盖。已有文件 UI 的版本机制可复用，但通用读取账、覆盖标记与持久恢复仍待实现和联合验证。

复核是当时的观察，不是跨文件事务或外部 IDE／SVN 的写锁。实际写入口继续执行目标身份／版本条件检查；本轮已验证复核之后再发生外改时，现有文件保存仍冲突并保留外部内容。raw shell／第三方写入口若没有等价检查，不能宣称自动获得该保护，也不能因此开放并行只读。目录查询期间成员变化、符号链接与路径竞争、完整准入守卫及大项目开销仍需补验。

'''
 return t.replace(anchor,addition+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.83 'not in t
 add='''### 4.83 按需读取版本与外部变化

[实际文件服务实验](实验/20261114_按需读取依据与外部变化验证/README.md)在本机合成 SVN 工作副本取得六项证据：同大小／同 mtime 内容变更、相同内容物理替换、缺失后新增／删除、复核后外改、整根替换及只访问相关内容路径。旧 chunk／保存拒绝变化，外部内容保留；目录列表一致不代表内容一致，hash 一致不代表物理身份一致。

复用实际 FileSourceResolver／FileService／roots 与原生文件代理，执行前完整核对源码和产物摘要；没有 SDK、统一读取账、全盘快照或大项目性能结论。技术方案 §8.1.1 明确按需文件与查询依据、覆盖／截断／未知及最终写入条件检查。Q33 保持部分；准入守卫、原生与业务路径、目录并发完整性仍待验。

'''
 t=t.replace(anchor,add+anchor).replace('截至 §4.82，56 个宽口径问题项中','截至 §4.83，56 个宽口径问题项中')
 t=t.replace('Q33 本轮取得只读边界反例，由待验推进为部分，未宣称并行只读可用。','Q33 已取得只读边界反例与实际文件版本复核证据，未宣称并行只读可用。')
 old='实际准入守卫、shell／Skill、插件业务及读取依据变化仍待验，不承诺全项目原子快照 |'
 new='§4.83 补实际文件服务的内容／物理替换、缺失增删、复核后外改及根撤销证据；完整准入守卫、shell／Skill、插件业务和查询覆盖仍待验，不承诺全项目原子快照 |';assert old in t;t=t.replace(old,new)
 old='继续验证完整 scope／未知后台、无强制只读时串行准入守卫、路径／fork 竞争及 Git 准备失败对账。';new='§4.82 补外部 MCP 不受原生只读限制的反例，§4.83 补按需文件版本／外部变化；继续验证完整 scope／未知后台、无强制只读时串行准入守卫、查询覆盖、路径／fork 竞争及 Git 准备失败对账。';assert old in t;t=t.replace(old,new)
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：实际文件服务在合成 SVN 工作副本中验证了内容变化、物理替换、缺失增删、根撤销与旧版本保存冲突；目录列表和内容摘要各有边界。见[技术方案 §8.1.1](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对共享目录准入、查询覆盖／并发变化、动态子树和业务排空；真实供应商与产品集成条件独立保留。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'cases':6,'archiveFiles':len(files),'partial':48,'pending':5}))
