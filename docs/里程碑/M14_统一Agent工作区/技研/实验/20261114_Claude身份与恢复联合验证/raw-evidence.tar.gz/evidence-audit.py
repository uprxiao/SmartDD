from pathlib import Path
import json,hashlib,sqlite3
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();result=json.loads((p/'latest.json').read_text());final=Path(result['out']);assert result['passed']==4 and not result.get('error') and result['allocationMode']=='host-allocated'
for n in ['probe.mjs','claude.mjs','programmatic.mjs','native-binding.mjs','joint.mjs','candidate.cjs','profile.cjs']:assert (p/n).read_bytes()==(final/n).read_bytes(),n
sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((p/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[str(Path(s['path']).resolve())]=s
 for o in b.get('outputs',[]):
  assert sha(Path(o['file']).read_bytes())==o['sha256'];assert sha((final/Path(o['file']).name).read_bytes())==o['sha256']
  for patch in o.get('patches',[]):assert sha(Path(patch['path']).read_bytes())==patch['beforeHash'];assert sha((p/(Path(patch['path']).name+'.variant')).read_bytes())==patch['afterHash']
rows=[]
for a in sorted(p.glob('attempt-*')):
 if not (a/'result.json').exists():
  pre=json.loads((a/'preflight-error.json').read_text());assert pre['nativeProcessesStarted']==0;rows.append({'attempt':a.name,'preflight':pre});continue
 r=json.loads((a/'result.json').read_text());c=json.loads((a/'cleanup.json').read_text());assert all(x.get('stopped')for x in c['cleanup']);assert len(c['nativeExits'])==len(c['cleanup']);assert all(x['code']is not None or x['signal']is not None for x in c['nativeExits'])
 requests=[json.loads(x)for x in (a/'mock-requests.jsonl').read_text().splitlines()];assert len(requests)==2
 rows.append({'attempt':a.name,'passed':r['passed'],'failure':r.get('error'),'localMockRequests':len(requests),'exits':c['nativeExits'],'allocationMode':r.get('allocationMode','native-allocated')})
 if r['passed']==4:
  h=json.loads((a/'history-evidence.json').read_text());data=(a/'persisted-transcript.jsonl').read_bytes();assert sha(data)==h['sha256'];assert sha(Path(h['path']).read_bytes())==h['sha256'],'transcript not restored';frames=[json.loads(x)for x in (a/'first-native.jsonl').read_text().splitlines()];init=next(x for x in frames if x.get('subtype')=='init');assert init['session_id']==h['nativeId']
  if (a/'launch-identity.json').exists():
   identity=json.loads((a/'launch-identity.json').read_text());assert identity['expectedNativeId']==h['nativeId']
  messages=json.dumps(requests[1]['body']['messages']);assert all(x in messages for x in ['ISOLATED_FIRST_CONTEXT','ISOLATED_REPLY_1','ISOLATED_SECOND_CONTEXT']);assert 'No conversation found' in (a/'missing-observation.json').read_text()
for db in p.glob('attempt-*/*.sqlite'):
 c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close()
runtime={'attempts':rows,'nativeExitCount':sum(len(r.get('exits',[]))for r in rows),'successfulModes':['native-allocated','host-allocated'],'paidModelCalls':0,'mockRequests':sum(r.get('localMockRequests',0)for r in rows),'sourceInputsUniqueResolved':len(sources),'sdkVersion':'0.3.321','nativeVersion':'2.1.321','nativeSha256':'abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c','exitMeaning':'Code 143 for deliberate owner cancellation; code 1 for missing transcript. Exit evidence is not a claim of all runs succeeding.'}
assert sha(Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk-darwin-arm64/claude').read_bytes())==runtime['nativeSha256'];assert runtime['nativeExitCount']==8
(p/'runtime-audit.json').write_text(json.dumps(runtime,indent=2));print(json.dumps({'attempts':len(rows),'nativeExits':8,'successfulModes':runtime['successfulModes'],'sourceInputs':len(sources)}))
