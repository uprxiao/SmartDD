import assert from 'node:assert/strict';
import {appendFileSync,mkdirSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {deferred} from './launch.mjs';
import {bindOwnedNative} from './native-binding.mjs';
export function claude(out,f,id,mark,{resume}={}){return(spawn,prepared)=>{
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});const input=deferred(),end=deferred(),identity=deferred(),result=deferred(),frames=[];
 const q=query({prompt:(async function*(){const text=await input.promise;if(text!==null)yield{type:'user',uuid:randomUUID(),session_id:resume??'',parent_tool_use_id:null,message:{role:'user',content:text}};await end.promise;})(),options:{pathToClaudeCodeExecutable:prepared.executable,cwd:f.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:prepared.env,mcpServers:{},strictMcpConfig:true,tools:[],permissionMode:'default',maxTurns:1,...(resume?{resume}:{}),stderr:s=>appendFileSync(out+'/'+id+'-stderr.log',s),spawnClaudeCodeProcess:o=>spawn(o.command,o.args,{cwd:f.snapshot.native.cwd,env:prepared.env})}});
 const consume=(async()=>{try{for await(const m of q){frames.push(m);appendFileSync(out+'/'+id+'-native.jsonl',JSON.stringify(m)+'\n');if(m.type==='system'&&m.subtype==='init'){
 assert.equal(m.cwd,f.snapshot.native.cwd);assert.equal(m.claude_code_version,f.runtime.nativeVersion);assert.equal(typeof m.session_id,'string');assert(m.session_id.length);if(resume)assert.equal(m.session_id,resume,'RESUME_CHANGED_ID');
 const native={runner:'claude-code',cwd:m.cwd,stateRoot:f.snapshot.native.stateRoot,sessionId:m.session_id};const scope=await bindOwnedNative(f,f.scope,native);mark('native-identity-bound',{sessionId:m.session_id,scope});identity.resolve({native,scope});}
 if(m.type==='result'){result.resolve(m);}}
 return{finished:true};}catch(e){identity.reject(e);result.reject(e);mark('sdk-error',{message:e.message});return{error:e.stack};}})();
 return{ready:()=>q.initializationResult(),send:text=>input.resolve(text),identity:identity.promise,result:result.promise,frames,consume,close:()=>{input.resolve(null);end.resolve();q.close();}};
};}
