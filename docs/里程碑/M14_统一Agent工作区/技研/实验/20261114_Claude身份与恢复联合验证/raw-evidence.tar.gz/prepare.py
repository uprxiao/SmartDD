from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_Claude身份与恢复联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==4 and not result.get('error');runtime=json.loads((root/'runtime-audit.json').read_text());assert runtime['nativeExitCount']==8
refs=[repo/'src/main/core/applications/session-registry.ts',repo/'src/main/core/applications/run-registry.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputsUniqueResolved':runtime['sourceInputsUniqueResolved'],'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'T3 ensureThread allocates a UUID, query options select sessionId versus resume. Reviewed resumeThread distinguishes live query, empty/conversation transcript and leaves unreadable history to the CLI. Native tests use actual Claude SDK 0.3.321 / native 2.1.321 and local synthetic HTTP replies.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,indent=2))]+[(n,(root/n).read_bytes())for n in ['driver-correction.json','runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# Claude 身份建立与原生恢复：隔离技术验证

2026-11-14；对应 R02／03／04／08／10／12，Q02／13／14／17／48。技术方案 §2.3／§3.2.9，验证账 §4.48。仅技术研究；未修改产品／原型，没有产品验收。

## 路径与结论

使用实际 Claude Agent SDK 0.3.321、其 native 2.1.321，与上一批相同的程序化 run／能力来源／ExecutionPlan／资源交付候选，接实际所有权与私有句柄。只运行一个逻辑任务的 Claude 绑定，未加入父子委派、业务 MCP 或跨 Provider 切换。工具集合为空；模型 API 仅指向 127.0.0.1 临时服务器，由本机返回固定文本，不使用用户凭据或真实供应商。

SDK 初始化响应与 `system/init` 原生会话事件分开观察。两种成功模式在初始化返回时均尚无 init 事件或模型请求；随后第一条隔离输入触发真实 init，通过持有该 run 的适配器核对 cwd／版本／身份并绑定。不可变应用计划、ExecutionPlan、delivery 没有被首次 ID 修订重写，原发布收据可重试。此时间顺序是本版本实验观察，不承诺其他版本必然如此。

结束第一进程后，generation 2 的新 owned run 以 resume 恢复同 ID。第二次真正到达模拟接口的请求同时包含第一条输入、第一条回复和第二条输入，因而证明原生加载了持久历史；不是让模型回答“记得”作为证据。原生历史文件复制留证后暂时移开，第三运行恢复明确报 No conversation found，无 init 身份替换、无新模型请求；清理后原文件恢复且 hash 一致。

## 两种身份分配方式

| 运行 | 分配方式与结果 |
| --- | --- |
| attempt-4EqPhE | 不传 sessionId，由 Claude 产生 ID；H01–H04 通过 |
| attempt-IDYn4o | 宿主先生成 UUID，经 SDK sessionId 传入；真实 init 确认同 ID，H01–H04 通过 |

后者对应 T3 本地实现：`ClaudeAdapterV2.ensureThread` 调用 queryRunner.allocateSessionId（UUID）；运行选项在首次打开使用 sessionId、继续使用 resume。Codex 的 ensureThread 则真正调用 thread/start；因此上层不能统一把 ensureThread 返回或“手里已有 ID”当成原生执行／历史持久化成功。

T3 Claude 的 resumeThread 区分现存 live query 与磁盘 transcript：明确 empty 报错、conversation 标记为已打开以走 resume，读取失败交给 CLI 判断。此源码参考不意味着 T3 对所有损坏／缺失场景都有已执行证据；本批实际验证的是独立 SDK 的既有历史恢复与文件缺失失败。

H01 记录初始化与零请求；H02 记录真实身份及计划不变；H03 记录同 ID 新运行与实际请求历史；H04 记录缺失历史无替换／无模型请求。预分配 ID 在本探针中是适配器参数，不是已经实现了生产持久分配事务；最终 launch Schema 对预分配值和运行来源的绑定仍需在完整合同中实现／核验。

## 失败与清理

第一次启动在本机端口监听时遭沙箱 EPERM，尚未建立 fixture 或启动 native；保留冻结驱动与 preflight-error。允许隔离 loopback 后，attempt-OExKBZ 的 H01／H02 通过，H03 已完成真实恢复及历史检查，但探针误从不含 generation 的公开记录读取字段，得到 undefined。改为按 runId 查询实际行后两模式通过；这是驱动读取错误，不是产品或 SDK 缺陷。

三次实际运行共八个原生进程均有终态退出回执：正常研究停止的进程为 code 143，两个缺失历史反例为 code 1；不称全部“正常成功退出”。六次模型请求均为本机固定响应，真实供应商调用为零。临时 HTTP 服务关闭，移开的历史文件恢复。没有通过名称搜索或终止其他进程。

## 适用边界与证据

此批覆盖两种身份建立、正常新运行恢复及历史缺失。没有完整 App／操作系统重启、原生已接受输入后的失联恢复、业务权限／Skill／MCP 联合、并行委派、外部供应商认证或跨平台证明。init／result 的 session_id 只在归属与来源核对后关联，不能单凭错误 result 中带 ID 就认作成功身份或输入已执行。H04 错误 result 保留原 session_id，但没有建立可用会话。

[结果](result.json)、[驱动修正](driver-correction.json)、[进程及版本审计](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[全部原始证据](raw-evidence.tar.gz)。归档 {len(files)} 个文件、{len(dbs)} 份 SQLite；完整性／外键通过，构建输入按解析路径去重 {runtime['sourceInputsUniqueResolved']} 个。

在新临时目录恢复匹配的依赖与源码，调整绝对路径，运行 build.mjs、profile-build.mjs、probe.mjs 和 probe.mjs --allocated；监听仅限 loopback，使用合成配置。每次按捕获 handle 观察与收尾，不因观察超时盲目再启动。历史文件移动仅针对本轮隔离副本，不能对用户原始会话套用故障注入。
''')
section='''
原生身份的分配、确认和恢复检查是三个独立事实。T3 Claude ensureThread 先分配 UUID，启动选项用 sessionId／resume；T3 Codex ensureThread 调用 thread/start。WillYou 的公共层因此只要求适配器给出明确身份阶段及证据，不把某个方法成功、进程初始化、已有 ID 或 result 带 ID 直接投影成“原生可用／可恢复”。

| 身份事实 | 公共层处理 |
| --- | --- |
| 尚无 ID／适配器预分配候选 ID | 可以保留启动意图；候选 ID 单独纳入版本化 launch 参数与所属 binding／run，不能提前写成已确认 native 身份或授予业务来源可信性 |
| 实际原生协议确认 ID | 按该 provider 的已知事件／响应检查 run、cwd、stateRoot、预期 ID 和协议版本，再走 §3.2.9 原子绑定；同 ID 幂等，不同 ID 按明确重置流程或报错，不能覆盖原绑定 |
| 读取／恢复原生历史 | 独立记录尝试与成功／失败证据；会话已确认并不保证以后历史存在；缺历史不静默创建新身份或重发未知输入 |

[Claude 身份实验](实验/20261114_Claude身份与恢复联合验证/README.md)验证自动 ID 与宿主预分配 ID 两种方式，真实 system/init 都接入相同 owned run 绑定；新进程 resume 的实际请求包含历史，移开隔离历史后明确失败且无新请求。初始化响应与身份事件分开读取；错误 result 也可带原 session_id，不能据此确认成功。预分配值的生产持久事务、最终 launch Schema 和中途崩溃分支仍须遵循完整合同验证，不能直接照搬实验函数。
'''
def tech(t):
 anchor='### 2.4 配置实例准入与第三适配器合同';assert anchor in t;t=t.replace(anchor,section+'\n'+anchor)
 t=t.replace('此次真实 Codex 证据覆盖这条绑定链，Claude 与完整应用中断链仍分别待验。','此次真实 Codex 证据覆盖这条绑定链；§2.3 的 Claude 实验又补自动／预分配 ID 的真实回调与正常新进程恢复，完整应用中断链仍待联合。')
 t=t.replace('首次身份之后的宿主中断、Claude 原生回调与业务在途仍待联合。','首次身份之后的宿主中断与业务在途仍待联合；Claude 正常身份／恢复见 §2.3。')
 t=t.replace('已派发／范围未知时的对账、Claude native 回调及业务桥仍待联合（Codex 首次绑定见 §3.2.9）','已派发／范围未知时的对账及业务桥仍待联合（两端正常首次绑定见 §2.3、§3.2.9）')
 return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.48 Claude 身份、预分配与原生恢复

[Claude 联合实验](实验/20261114_Claude身份与恢复联合验证/README.md)以真实 SDK／native 和本机合成响应验证两种身份：自动分配与 SDK sessionId 预分配。两模式各覆盖初始化／身份事件分离、真实回调绑定而计划不变、新 run／新进程同 ID 恢复及请求中包含历史、缺失历史明确失败而无新 ID／模型请求。T3 ensureThread 的 Claude 分配 UUID 与 Codex thread/start 不同；统一层必须区分身份分配、原生确认和恢复事实。

保留初次 loopback EPERM（native 未启动）和探针误从公开对象读取 generation 的失败；修正查询后两模式通过。八个捕获进程均退出，包含主动停止的 143 与缺历史的 1，不能称全部运行成功。六次请求只发往本机模拟服务，没有实际供应商或业务调用。产品迁移、跨宿主输入／业务恢复、最终预分配 launch Schema 和完整通用协议仍未因此关闭；Q02／13／14／17／48 保持部分。

'''
def account(t):
 assert '### 4.48 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q02','Q13','Q14','Q17','Q48']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.48 补 Claude 自动／预分配 ID、真实回调、带历史恢复及缺失历史失败；未证明跨宿主输入／业务恢复 |';t='\n'.join(lines)+'\n'
 t=t.replace('Claude 真实回调及跨宿主来源复用；','跨宿主来源复用；§4.48 已补 Claude 真实回调及正常恢复；')
 t=t.replace('下一步按矩阵核验跨宿主输入／结果对账、Claude 身份回调及通用合同，','§4.48 已补 Claude 两种身份建立与正常恢复。下一步按矩阵核验跨宿主输入／结果对账及通用合同，')
 return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补 Claude 自动／预分配会话 ID、真实 SDK 回调及新进程恢复的隔离验证，见[技术方案 §2.3](技研/技术方案.md)。本机模拟接口收到含历史的请求；缺失历史时明确失败，没有自动换 ID。结合 Codex 证据，设计已区分 ID 分配、原生确认和可恢复性。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续收口跨宿主输入／结果对账与完整通用协议合同；业务联合、安装／版本／平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs)}))
