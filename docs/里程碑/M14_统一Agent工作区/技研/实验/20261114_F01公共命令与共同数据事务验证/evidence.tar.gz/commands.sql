CREATE TABLE m14_command_receipt(
 caller_key TEXT NOT NULL,command_id TEXT NOT NULL,method TEXT NOT NULL,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 task_id TEXT NOT NULL REFERENCES m14_task_state(task_id),response_json TEXT NOT NULL CHECK(json_valid(response_json)),
 PRIMARY KEY(caller_key,command_id));
CREATE TABLE m14_submission(
 input_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,turn_id TEXT NOT NULL UNIQUE,
 client_key TEXT NOT NULL,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 source TEXT NOT NULL CHECK(source IN ('ui-user','history-transfer','agent-delegation','automatic-followup','child-result')),
 target_json TEXT NOT NULL CHECK(json_valid(target_json)),blocks_json TEXT NOT NULL CHECK(json_valid(blocks_json)),
 FOREIGN KEY(turn_id,task_id,binding_id) REFERENCES m14_turn(id,task_id,binding_id),UNIQUE(task_id,client_key));
CREATE TRIGGER m14_submission_frozen BEFORE UPDATE ON m14_submission BEGIN SELECT RAISE(ABORT,'SUBMISSION_IMMUTABLE');END;
CREATE TRIGGER m14_new_input_needs_submission BEFORE INSERT ON m14_input
 WHEN NOT EXISTS(SELECT 1 FROM m14_submission s WHERE s.input_id=NEW.input_id AND s.task_id=NEW.task_id AND s.binding_id=NEW.binding_id AND s.turn_id=NEW.turn_id AND s.source=NEW.source)
 BEGIN SELECT RAISE(ABORT,'LOGICAL_SUBMISSION_REQUIRED');END;
CREATE TABLE m14_draft(task_id TEXT PRIMARY KEY REFERENCES m14_task_state(task_id),blocks_json TEXT NOT NULL CHECK(json_valid(blocks_json)));
