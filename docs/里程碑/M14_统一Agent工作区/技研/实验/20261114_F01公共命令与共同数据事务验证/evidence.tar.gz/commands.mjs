import {randomUUID,createHash} from 'node:crypto';
import {Command,Target,Event} from './contract.mjs';
export const canonical=x=>JSON.stringify(x&&typeof x==='object'?Array.isArray(x)?x.map(y=>JSON.parse(canonical(y))):Object.fromEntries(Object.keys(x).sort().map(k=>[k,JSON.parse(canonical(x[k]))])):x);
export const hash=x=>createHash('sha256').update(canonical(x)).digest('hex');
const fail=code=>{throw Error(code);};
export function execute(db,raw,context,deps,at=()=>{}){
 const cmd=Command.parse(raw);deps.authorize(context,cmd);const caller=context.callerKey;
 const requestHash=hash({...cmd,serverOrigin:context.originScope??null});
 return db.transaction(()=>{
  const old=db.prepare('SELECT * FROM m14_command_receipt WHERE caller_key=? AND command_id=?').get(caller,cmd.commandId);
  if(old){if(old.request_hash!==requestHash)fail('COMMAND_CONFLICT');return JSON.parse(old.response_json);}
  let taskId,answer;
  const emit=(id,payload)=>{
   const q=db.prepare('UPDATE m14_task_state SET task_seq=task_seq+1 WHERE task_id=? RETURNING task_seq').get(id);if(!q)fail('TASK_STATE_MISSING');
   const ev=Event.parse({protocol:1,databaseId:'isolated-contract-db',taskId:id,taskSeq:q.task_seq,occurredAt:'2026-11-14T00:00:00Z',scope:null,payload});
   db.prepare('INSERT INTO m14_event(task_id,task_seq,protocol,type,payload_json) VALUES(?,?,1,?,?)').run(id,q.task_seq,payload.type,canonical(ev.payload));at('after-event');
  };
  const state=id=>{const s=db.prepare("SELECT * FROM m14_task_state WHERE task_id=? AND record_state='active'").get(id);if(!s)fail('TASK_NOT_ACTIVE');return s;};
  const submission=(task,binding,target,blocks,source,client,reqHash)=>{
   const inputId=randomUUID(),turnId=randomUUID();
   db.prepare("INSERT INTO m14_turn(id,task_id,binding_id,input,state) VALUES(?,?,?,?,'queued')").run(turnId,task,binding,canonical(blocks));at('after-turn');
   db.prepare('INSERT INTO m14_submission VALUES(?,?,?,?,?,?,?,?,?)').run(inputId,task,binding,turnId,client,reqHash,source,canonical(Target.parse(target)),canonical(blocks));
   return {inputId,turnId};
  };
  if(cmd.method==='input.submit'){
   taskId=cmd.taskId;
   const {commandId,...logical}=cmd;const logicalHash=hash(logical);
   const prior=db.prepare('SELECT * FROM m14_submission WHERE task_id=? AND client_key=?').get(taskId,'ui-user:'+cmd.clientInputId);
   if(prior){if(prior.request_hash!==logicalHash||prior.source!=='ui-user')fail('INPUT_CONFLICT');answer={taskId,inputId:prior.input_id,turnId:prior.turn_id,status:'queued'};}
   else{
    const s=state(taskId);if(s.selection_revision!==cmd.expectedSelectionRevision||s.draft_revision!==cmd.expectedDraftRevision)fail('REVISION_CONFLICT');
    const target=deps.resolveTarget(db,taskId,s.active_binding); // current source resolution, no secret in return value
    const created=submission(taskId,s.active_binding,target,cmd.blocks,'ui-user','ui-user:'+cmd.clientInputId,logicalHash);
    db.prepare('UPDATE m14_task_state SET draft_revision=draft_revision+1 WHERE task_id=?').run(taskId);
    db.prepare("INSERT INTO m14_draft VALUES(?,'[]') ON CONFLICT(task_id) DO UPDATE SET blocks_json='[]'").run(taskId);
    emit(taskId,{type:'draft.changed',draftRevision:s.draft_revision+1,blocks:[]});emit(taskId,{type:'input.queued',inputId:created.inputId,turnId:created.turnId,bindingId:s.active_binding});
    answer={taskId,...created,status:'queued'};
   }
  }else if(cmd.method==='delegation.create'){
   const parent=context.originScope;if(!parent)fail('PARENT_REQUIRED');state(parent.taskId);deps.assertParentAndTarget(db,context,cmd);
   const task=randomUUID(),binding=randomUUID(),delegation=randomUUID();taskId=parent.taskId;
   const parentRow=db.prepare('SELECT * FROM tasks WHERE id=?').get(taskId);
   db.prepare('INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,1,1)').run(task,parentRow.project_id,parentRow.cwd,deps.driverFor(cmd.target),'Synthetic child');
   db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,cwd,entry_mode,phase,profile_id,profile_revision) VALUES(?,?,?,?,'programmatic','planned',?,?)").run(binding,task,deps.driverFor(cmd.target),parentRow.cwd,cmd.target.profileId,cmd.target.executionRevision);
   db.prepare("INSERT INTO m14_task_state(task_id,active_binding,record_state) VALUES(?,?,'active')").run(task,binding);at('after-child');
   const created=submission(task,binding,cmd.target,cmd.blocks,'agent-delegation','agent-delegation:'+cmd.commandId,requestHash);
   db.prepare("INSERT INTO m14_delegation VALUES(?,?,?,?,?,?,?,?,'queued')").run(delegation,parent.taskId,parent.bindingId,parent.runId,parent.generation,task,binding,created.turnId);
   const outbox=randomUUID();db.prepare("INSERT INTO m14_outbox(id,delegation_id,child_task,child_binding,state,target_profile_id,target_revision) VALUES(?,?,?,?,'queued',?,?)").run(outbox,delegation,task,binding,cmd.target.profileId,cmd.target.executionRevision);
   answer={taskId,childTaskId:task,delegationId:delegation,outboxId:outbox,...created,status:'queued'};
   // Existing delegation receipt remains an origin projection; generic receipt is command replay authority.
   db.prepare('INSERT INTO m14_receipt VALUES(?,?,?,?,?,?,?,?)').run(taskId,parent.bindingId,parent.runId,parent.generation,cmd.commandId,requestHash,delegation,canonical(answer));
   emit(task,{type:'task.record.changed',recordState:'active',archived:false});emit(taskId,{type:'delegation.changed',delegationId:delegation,childTaskId:task,state:'queued'});
  }else if(cmd.method==='task.delete'){
   taskId=cmd.taskId;state(taskId);
   if(db.prepare("SELECT 1 FROM m14_turn WHERE task_id=? AND state NOT IN('completed','cancelled','failed','not-sent')").get(taskId))fail('TURN_UNRESOLVED');
   deps.assertDeleteEligibility(db,taskId); // F06/F08/F10: must execute in same authoritative gate/transaction, not a preview boolean
   db.prepare("UPDATE m14_task_state SET record_state='retained',active_binding=NULL WHERE task_id=?").run(taskId);
   db.prepare("UPDATE m14_cap SET retention=CASE WHEN retention='hold' THEN 'hold' ELSE 'tombstone' END WHERE task_id=?").run(taskId);
   db.prepare('DELETE FROM tasks WHERE id=?').run(taskId);at('after-delete');
   emit(taskId,{type:'task.record.changed',recordState:'retained',archived:false});answer={taskId,recordState:'retained'};
  }else fail('OUTSIDE_F01');
  at('before-receipt');db.prepare('INSERT INTO m14_command_receipt VALUES(?,?,?,?,?,?)').run(caller,cmd.commandId,cmd.method,requestHash,taskId,canonical(answer));at('before-commit');return answer;
 }).immediate();
}
