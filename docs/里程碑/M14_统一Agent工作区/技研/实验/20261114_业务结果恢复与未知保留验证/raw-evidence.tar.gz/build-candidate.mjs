import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD',path=repo+'/src/main/core/browser/operations.ts',before=readFileSync(path,'utf8');
const old='DELETE FROM browser_operations WHERE created_at < ?',replacement="DELETE FROM browser_operations WHERE created_at < ? AND state IN ('succeeded','failed') AND effect_state IN ('not-started','read-only','completed')";
if(before.split(old).length!==2)throw Error('retention anchor changed');
const after=before.replace("'"+old+"'",JSON.stringify(replacement));writeFileSync(root+'/operations.ts.variant',after);
const r=await build({stdin:{contents:`export {BrowserOperations} from '${path}';`,resolveDir:repo,loader:'ts'},bundle:true,platform:'node',format:'cjs',target:'node22',metafile:true,tsconfig:repo+'/tsconfig.node.json',nodePaths:[root+'/node_modules'],outfile:root+'/candidate.cjs',plugins:[{name:'isolated-retention-query',setup(b){b.onLoad({filter:/\/browser\/operations\.ts$/},()=>({contents:after,loader:'ts'}));}}]});
const sha=b=>createHash('sha256').update(b).digest('hex');writeFileSync(root+'/candidate-build.json',JSON.stringify({source:path,before:sha(before),after:sha(after),output:sha(readFileSync(root+'/candidate.cjs')),sources:Object.keys(r.metafile.inputs).filter(p=>!p.startsWith('<')).map(p=>{const path=p.startsWith('/')?p:process.cwd()+'/'+p;return{path,sha256:sha(readFileSync(path))};}),scope:'Candidate only changes retention DELETE predicate in memory. No source mutation.'},null,2));
