import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync} from 'node:fs';
import actual from './actual.cjs';
import candidate from './candidate.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
const {runFixture,FixtureProcessReader,recoverApplicationReads,MailExecutionService}=actual;
const checks=[];let f,mail,problem,submissions=0;const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
const insert=(table,row)=>f.sqlite.prepare(`INSERT INTO ${table}(${Object.keys(row).join(',')}) VALUES(${Object.keys(row).map(()=>'?').join(',')})`).run(...Object.values(row));
const day=86400000,now=Date.now(),older=now-8*day,stamp=new Date(now).toISOString(),hash='a'.repeat(64),oldOwner={pid:77119,startedAt:'darwin-proc-v1:500:20'},owner=randomUUID();
function operation(semantics='read',state='running'){
 const id=randomUUID(),lease=randomUUID();insert('application_data_operations',{operation_id:id,caller_kind:'ui',scope_kind:'project',project_id:'p1',task_id:null,run_id:null,job_id:null,parent_operation_id:null,app_id:f.application.appId,package_hash:f.application.packageHash,data_api:1,action:'ui.zentao.work',semantics,scope_hash:hash,state,started_at:stamp});
 insert('capability_resource_leases',{lease_id:lease,resource_id:f.application.resourceId,owner_kind:'ui',owner_id:id,host_instance_id:owner,pid:oldOwner.pid,process_started_at:oldOwner.startedAt,state:'active',created_at:stamp});return{id,lease};
}
function mailFixture(state){
 const connection=randomUUID(),draft=randomUUID(),intent=randomUUID(),execution=state==='executing'?randomUUID():null,grant=state==='authorized'?randomUUID():null,lease=randomUUID();
 insert('application_connections',{id:connection,app_id:'mail',provider_id:'smtp',name:'synthetic recovery only',config_json:'{}',revision:1,config_revision:1,identity_revision:1,verified_identity_json:'{}',identity_hash:hash,secret_revision:1,policy_revision:1,enabled:1,auth_state:'disconnected',health:'unverified',created_at:stamp,updated_at:stamp});
 insert('mail_drafts',{id:draft,project_id:'p1',subject:'synthetic',attachment_count:0,current_revision:1,state:execution?'sending':'draft',active_intent_id:intent,last_execution_id:execution,created_at:stamp,updated_at:stamp});
 insert('mail_draft_revisions',{draft_id:draft,revision:1,content_json:'{}',content_hash:hash,created_at:stamp});
 insert('mail_send_intents',{id:intent,project_id:'p1',source_task_id:f.snapshot.taskId,source_run_id:'old-mail-run',operation_id:randomUUID(),request_hash:hash,draft_id:draft,draft_revision:1,draft_content_hash:hash,connection_id:connection,identity_revision:1,config_revision:1,policy_revision:1,binding_revision:1,identity_json:'{}',smtp_config_json:'{}',raw_write_id:randomUUID(),message_id:'<synthetic@example.test>',state,grant_id:grant,execution_id:execution,owner_instance_id:owner,owner_pid:oldOwner.pid,owner_started_at:oldOwner.startedAt,created_at:stamp,updated_at:stamp});
 if(execution)insert('mail_send_executions',{id:execution,intent_id:intent,project_id:'p1',draft_id:draft,draft_revision:1,review_hash:hash,state:'executing',secret_revision:1,owner_instance_id:owner,started_at:stamp});
 if(grant)insert('mail_send_grants',{id:grant,intent_id:intent,source:'renderer-confirmation',evidence_id:randomUUID(),evidence_hash:hash,review_hash:hash,evidence_json:'{}',state:'active',expires_at:new Date(now+day).toISOString(),created_at:stamp});
 insert('capability_resource_leases',{lease_id:lease,resource_id:f.application.resourceId,owner_kind:'mail-send',owner_id:intent,host_instance_id:owner,pid:oldOwner.pid,process_started_at:oldOwner.startedAt,state:'active',created_at:stamp});return{intent,draft,execution,grant,lease};
}
function rows(){return Object.fromEntries(['browser_operations','application_data_operations','mail_send_intents','mail_send_executions','mail_send_grants','capability_resource_leases','application_invocations'].map(t=>[t,f.sqlite.prepare('SELECT * FROM '+t).all()]));}
try{
 f=await runFixture(undefined,{application:true});
 await check('B01','actual seven-day browser cleanup removes unresolved evidence',async()=>{
  const ops=new actual.BrowserOperations(f.sqlite),id=randomUUID();ops.begin('baseline-run',id,f.snapshot.taskId,null,'click');ops.update('baseline-run',id,'running','unknown');f.sqlite.prepare('UPDATE browser_operations SET created_at=? WHERE request_id=?').run(older,id);
  save('baseline-before.json',rows());ops.recover(now);assert.deepEqual(ops.receipt('baseline-run',id),{state:'not-found'});assert.equal(ops.begin('baseline-run',id,f.snapshot.taskId,null,'click').replay,false);save('baseline-after.json',rows());
  f.sqlite.prepare('DELETE FROM browser_operations WHERE run_id=?').run('baseline-run');return{oldRunningRecordDeleted:true,notFound:true,sameKeyNoLongerRecognized:true,noBrowserCommandExecuted:true,liveRunAuthorizationNotBypassed:true};
 });
 let browserIds;
 await check('B02','candidate keeps unknown results while pruning only old proven terminal rows',async()=>{
  const ops=new candidate.BrowserOperations(f.sqlite),cases=[['accepted','not-started',older,true],['running','unknown',older,true],['unknown','unknown',older,true],['failed','unknown',older,true],['succeeded','unknown',older,true],['succeeded','completed',older,false],['failed','not-started',older,false],['succeeded','completed',now,true],['failed','future-effect',older,true]];
  browserIds=cases.map(([state,effect,created])=>{const id=randomUUID();insert('browser_operations',{run_id:'candidate-run',request_id:id,task_id:f.snapshot.taskId,page_id:null,command:'click',state,effect_state:effect,created_at:created,updated_at:created});return id;});
  ops.recover(now);for(let i=0;i<cases.length;i++)assert.equal(!!ops.get('candidate-run',browserIds[i]),cases[i][3]);
  for(const i of [0,1,2])assert.equal(ops.receipt('candidate-run',browserIds[i]).state,'unknown');assert.equal(ops.begin('candidate-run',browserIds[2],f.snapshot.taskId,null,'click').replay,true);
  const before=f.sqlite.prepare('SELECT * FROM browser_operations ORDER BY request_id').all();ops.recover(now);assert.deepEqual(f.sqlite.prepare('SELECT * FROM browser_operations ORDER BY request_id').all(),before);
  return{cases:cases.map((c,i)=>({state:c[0],effect:c[1],old:c[2]===older,retained:c[3],requestId:browserIds[i]})),unknownKeyRetained:true,idempotentRecovery:true,fullRetentionPolicyStillRequired:true};
 });
 let reads,send;
 await check('B03','actual read recovery cancels proven stopped reads but preserves unknown writes',async()=>{
  reads={read:operation(),write:operation('write','unknown')};const reader=new FixtureProcessReader();reader.unknown.add(oldOwner.pid);const pending=await recoverApplicationReads(f.store,reader);assert(pending.pending.some(x=>x.leaseId===reads.read.lease&&x.reason==='owner-unknown'));assert.equal(pending.released.length,0);
  reader.unknown.delete(oldOwner.pid);const settled=await recoverApplicationReads(f.store,reader);assert.deepEqual(settled.released,[reads.read.lease]);assert.equal(f.sqlite.prepare('SELECT state FROM application_data_operations WHERE operation_id=?').get(reads.read.id).state,'cancelled');assert.equal(f.sqlite.prepare('SELECT state FROM application_data_operations WHERE operation_id=?').get(reads.write.id).state,'unknown');assert.equal(f.sqlite.prepare('SELECT state FROM capability_resource_leases WHERE lease_id=?').get(reads.write.lease).state,'active');
  return{ownerStatesControlled:true,readCancelled:true,writeUnknownPreserved:true,writeLeaseRetained:true};
 });
 await check('B04','actual mail recovery releases dead-owner leases while retaining execution unknown and revoking unused grants',async()=>{
  send=mailFixture('executing');const unstarted=mailFixture('authorized');let ownerState='unknown';const unused=new Proxy({},{get(){throw Error('Recovery unexpectedly used a non-recovery dependency');}});
  mail=new MailExecutionService(f.store,unused,unused,unused,{ownerState:()=>ownerState},{submit:async()=>{submissions++;throw Error('SMTP forbidden');}});
  const pending=await mail.recover();assert.deepEqual(new Set(pending.pending),new Set([send.intent,unstarted.intent]));ownerState='stopped';const settled=await mail.recover();assert.deepEqual(new Set(settled.recovered),new Set([send.intent,unstarted.intent]));
  for(const t of ['mail_send_intents','mail_send_executions'])assert.equal(f.sqlite.prepare('SELECT state FROM '+t+' WHERE id=?').get(t.endsWith('intents')?send.intent:send.execution).state,'unknown');
  assert.equal(f.sqlite.prepare('SELECT state FROM mail_send_intents WHERE id=?').get(unstarted.intent).state,'stale');assert.equal(f.sqlite.prepare('SELECT state FROM mail_send_grants WHERE id=?').get(unstarted.grant).state,'revoked');for(const x of [send,unstarted])assert.equal(f.sqlite.prepare('SELECT state FROM capability_resource_leases WHERE lease_id=?').get(x.lease).state,'released');assert.equal(submissions,0);
  return{ownerStatesControlled:true,seededLegalRecoveryRows:true,noPreparationOrActualSmtp:true,executedUnknownRetained:true,unexecutedApprovalStale:true,leasesReleased:true};
 });
 await check('B05','invocation-only gate misses independent browser/mail/project-write records',async()=>{
  assert.equal(f.sqlite.prepare("SELECT count(*) n FROM application_invocations WHERE task_id=? AND semantics='write' AND (state='running' OR effect_state='unknown')").get(f.snapshot.taskId).n,0);
  const scopes={browser:f.sqlite.prepare("SELECT request_id AS id,run_id,task_id,state,effect_state FROM browser_operations WHERE task_id=? AND (state IN ('accepted','running','unknown') OR effect_state NOT IN ('not-started','read-only','completed'))").all(f.snapshot.taskId),mail:f.sqlite.prepare("SELECT i.id,i.source_task_id,e.state FROM mail_send_intents i JOIN mail_send_executions e ON e.intent_id=i.id WHERE i.project_id=? AND (i.source_task_id=? OR i.source_task_id IS NULL) AND e.state IN ('executing','unknown')").all('p1',f.snapshot.taskId),projectWrites:f.sqlite.prepare("SELECT operation_id AS id,caller_kind,project_id,task_id,state FROM application_data_operations WHERE project_id=? AND semantics='write' AND state IN ('running','unknown')").all('p1')};
  assert(scopes.browser.some(x=>x.id===browserIds[2]));assert(scopes.mail.some(x=>x.id===send.intent));assert(scopes.projectWrites.some(x=>x.id===reads.write.id&&x.task_id===null));save('independent-outcomes.json',scopes);return{invocationOnlyEmpty:true,browserUnknown:true,mailUnknownAfterLeaseRelease:true,projectUiWriteWithoutTaskId:true,queryEvidenceNotCompleteAdmissionService:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
finally{
 if(mail)await mail.dispose();if(f){save('final-state.json',rows());assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);await f.sqlite.backup(out+'/final.sqlite');save('fixture.json',{root:f.root});f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:problem??null,submissions,scope:'Actual browser/read/mail recovery over isolated current SQLite with synthetic legal rows and controlled owner states; one candidate retention SQL predicate. No SMTP/browser action/native Agent/host crash or product edit.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
