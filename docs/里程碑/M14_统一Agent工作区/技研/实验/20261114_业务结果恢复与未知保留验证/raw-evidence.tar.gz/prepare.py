from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_业务结果恢复与未知保留验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==5 and result['error']is None and result['submissions']==0;attempt=Path(result['out']);build=json.loads((root/'build.json').read_text());candidate=json.loads((root/'candidate-build.json').read_text())
for s in build['sources']+build['outputs']+candidate['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha((root/'candidate.cjs').read_bytes())==candidate['output'];assert sha((root/'operations.ts.variant').read_bytes())==candidate['after']
expanded=[]
for p in [repo/'src/main/db/migrations.ts',repo/'src/main/core/capabilities/assets.ts']:
 for pattern in re.findall(r"import\.meta\.glob\('([^']+)'",p.read_text()):
  for f in repo.glob(pattern.replace('@root/','')):
   if f.is_file():expanded.append({'path':str(f),'sha256':sha(f.read_bytes())})
db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()==('ok',);assert db.execute('pragma foreign_key_check').fetchall()==[]
held=db.execute("select owner_kind,state from capability_resource_leases where state<>'released'").fetchall();assert held==[('ui','active')];db.close()
refs=[t3/'apps/server/src/orchestration-v2/ProviderSessionManager.ts']+[repo/'src/main/core'/p for p in ['browser/operations.ts','browser/service.ts','applications/read-context-recovery.ts','applications/mail-execution-service.ts','applications/plugins/session-tools.ts','applications/tool-service.ts','applications/execution-context.ts']]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'actualBuild':build,'candidateBuild':candidate,'expandedAssets':expanded,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Unmodified current browser/read/mail recovery over seeded legal SQLite rows. Mail policy owner states and read process reader are controlled fixtures. Mail prepare/auth/SMTP dependencies guarded against calls. Candidate only changes browser cleanup predicate. No live process, SDK, SMTP or browser command.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
runtime={'processesStarted':0,'smtpSubmissions':0,'browserCommands':0,'modelRequests':0,'sqliteIntegrity':'ok','foreignKeys':[],'retainedNegativeFixture':[{'ownerKind':'ui','state':'active','meaning':'synthetic unknown write intentionally preserved; no live process'}],'initialBuildFailure':'Candidate SQL single quotes were placed inside TypeScript single-quoted string; esbuild rejected. The subsequent probe import failed before any fixture was created. Fixed by replacing the entire string literal with JSON-quoted SQL. First actual probe run passed all five checks.','productChanges':0}
(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
files=[root/n for n in ['build.mjs','build.json','actual.cjs','build-candidate.mjs','candidate-build.json','candidate.cjs','operations.ts.variant','probe.mjs','prepare.py','source-review.json','runtime-audit.json']]+sorted(attempt.iterdir());archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:assert p.is_file();tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files],'sqliteIntegrityAndForeignKeys':[{'path':str((attempt/'final.sqlite').relative_to(root)),'integrity':'ok','foreignKeys':[]}]}
for name,data in [('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtime,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)),('raw-evidence.tar.gz',archive.read_bytes())]:put(exp/name,data)
put(exp/'README.md','''# 业务结果恢复与未知保留：独立技术验证

五项检查通过，包含一项明确的现有行为反例及隔离候选修正。实际调用当前 BrowserOperations、recoverApplicationReads、MailExecutionService.recover；SQLite 使用当前迁移及合法合成记录。没有 SMTP、浏览器命令、模型、原生 Agent、宿主崩溃或产品改动。

| 检查 | 实际结果与边界 |
| --- | --- |
| B01 浏览器清理反例 | 超过七天的 running 操作恢复时先标 unknown，随后被无状态限制的清理删除；receipt 返回 not-found，同 key 的 begin 返回非 replay。没有证明过期 run 可通过授权，也没有执行／重复点击 |
| B02 候选保留 | 只改临时构建中的 DELETE 条件；九种状态／effect／年龄组合验证未知及未识别 effect 保留，已知终态旧记录可清理，恢复幂等，同未知 key 仍为 replay |
| B03 数据只读恢复 | 受控 owner unknown 时保持占用；stopped 时当前实际恢复器取消合法 UI read 并释放其租约；合法 write／unknown 记录及租约保持 |
| B04 邮件恢复 | 当前实际恢复器在受控 owner unknown 时等待，stopped 后将 executing 记为 unknown、未执行 authorized 记 stale 并撤销 grant；两者租约都可释放，发送未知仍保留。仅恢复所需数据库夹具，未走 prepare／认证／SMTP |
| B05 独立账遗漏 | application_invocations 为空，但浏览器未知、邮件执行未知及 task_id 为空的项目 UI write／unknown 均存在；按通用调用表或 taskId 单表扫描会漏判 |

源码还确认：外部插件 handler 按冻结／当前 capability 的 semantics 建通用调用账，在实际分发前记录 unknown；它已有来源与审批，不应再创造另一套插件完成事实。浏览器和邮件则有自己的结果账。只读恢复仅覆盖其明确支持的宿主只读消费者，不能推广为所有业务写入均可取消。

设计改动：统一交接服务向各业务模块查询未决事实，区分执行占用、结果未知、未使用授权与可读历史；按 task/run、project 和业务对象保留来源与限制范围。租约释放不等于外部结果确认。旧调用账成功也不能覆盖对应业务账 unknown。缺表、未知格式／归属必须显示证据不足，不能按空结果处理。

浏览器候选仅证明“过期不删除未知”的最小措施。正式迁移还需在 BrowserService 构造／recover 清理前保存未决索引，定义有引用终态／去重记录的保留、明确对账入口和空间治理。不能将过期 not-found 当 not-started；已经丢失的历史无法由本探针恢复。没有实现完整 GC 或永久保留全部操作。

范围与后续：Mail owner 与读取器进程状态是夹具，不是本轮真实宿主退出证据；保留的 active UI lease 也是负例数据，无对应活进程。邮件敏感配置／正文以最小合成字段填充，仅用于 recover，不代表完整业务格式兼容。独立账聚合查询只是遗漏反例，尚非完整 admission 服务。真实业务结算、跨运行读回执、对象级限制、完整迁移／SDK 联调继续验证，Q09／Q37／Q41／Q48／Q49 不整体关闭。

复跑：在 SmartDD cwd 依次运行 build.mjs、build-candidate.mjs、probe.mjs。首次候选构建因 SQL 引号嵌入错误失败，探针随后的缺模块错误发生在创建夹具前；修正字符串构建后首个实际 attempt 五项通过。原始当前源码和候选摘要均保留。

[结果](result.json) · [运行审计](runtime-audit.json) · [源码依据](source-review.json) · [摘要](archive-manifest.json) · [脚本及 SQLite](raw-evidence.tar.gz)。
''')
section='''### 9.2.1 各业务结果账的恢复与交接汇总

[业务恢复实验](实验/20261114_业务结果恢复与未知保留验证/README.md)证明三个事实必须分开：进程／资源占用已释放、等待调用已结束、外部结果已确认。实际 MailExecutionService.recover 可在 owner 已停止后释放 mail-send 租约，同时把已 executing 的发送保持为 unknown；未执行授权则 stale／撤销 grant。实际只读恢复器只取消符合合同的宿主只读操作，不把未知 write 改为取消。不能将它们合并为统一“已恢复成功”。本轮使用受控 owner 状态与数据库夹具，不是完整 SMTP 或崩溃链证据。

| 事实来源 | 汇总依据与约束 |
| --- | --- |
| 通用应用／插件调用 | application_invocations 的 task／run、semantics、state、effect_state；实际插件分发沿用此账。effect unknown 不被 succeeded 标签覆盖 |
| 浏览器 | browser_operations 的 task／run／request／page、state 与 effect；它独立于通用调用账，未识别 effect 保守留待对账 |
| 邮件 | mail_send_intents 与 executions／grants 联查，保持 project、来源 task／run、draft／revision／intent 关系。发送未知、未使用授权、租约释放分别投影 |
| 数据操作 | application_data_operations 的 caller_kind、scope_kind、project、task／run、parent／target、semantics 与 state；项目 UI 操作 task_id 可为空，不能仅按任务筛选 |
| 原生后台／文件／SSH 等未纳入这些账的执行 | 仍由 owner、进程／作用域、工作区写者与适配器证据约束；以上表为空不能证明这些操作不存在 |

拟议宿主接口返回每项的 source、稳定业务 operationId、来源 task／run（可空）、project、业务对象范围、liveness、outcome、授权状态、证据修订与允许的下一动作，不返回可复用凭据。各业务模块解释自己的事实，聚合器不根据名称猜 semantics，也不把同一个邮件执行在多张表的记录算成多个待发任务。业务记录缺失、格式未知或归属不一致返回 unverified；读取和最终交接写事务之间须复核来源修订。当前仅取得独立账遗漏反例及恢复合同证据，完整聚合服务尚未实现。

限制应落在有证据的范围：真实活动／未知执行范围继续阻止工作区写权转移；结果未知禁止自动重发相应操作，不能仅凭它宣称所有进程还活着。已能证明没有关联的任务不应被另一项目的历史未知记录阻断。无法确认对象／运行范围时保守限制有关任务或项目的新执行，并保留可读历史和对账入口；只有实际执行端能强制相应限制时才开放受限继续，不以提示词“只读”替代执行约束。对象级限制和跨运行读回执继续纳入后续验证。

**迁移前必须处理浏览器保留顺序。** 当前 BrowserOperations.recover 无差别删除 created_at 超过七天的记录，本轮实际复现 unknown 证据被删，之后 receipt 为 not-found、同 key 不再识别为 replay。没有证明旧 run 能绕过权限重新执行，但未来交接若把缺记录当未执行，会丢失关键依据。隔离候选限定只清理已知结束且 effect 已确认的旧记录，九种组合及重复恢复通过；它仍不是完整引用／去重保留策略。迁移应在 BrowserService 初始化触发清理前提取／保留未决索引或落实相应保护；未决记录不随普通审计 TTL 删除，已引用终态／去重墓碑另按引用和明确保留合同处理。已丢失记录只声明历史覆盖不足，不补造 not-started。明确业务对账可以更新状态；时间流逝、切换 Provider 或用户关闭任务都不能代替结果证据。

T3 的 provider session 排空与持久释放分层可作为执行侧参考；WillYou 上述业务表是另外的事实来源，不复制 T3 session 状态来替代它们。相关 UI 应分别显示“执行已停止”和“操作结果待核实”，产品 UI 与完整业务回归仍待开发后执行。

'''
def tech(t):
 assert '### 9.2.1 'not in t
 t=t.replace('### 9.3 子运行的插件审批与统一请求入口',section+'### 9.3 子运行的插件审批与统一请求入口')
 t=t.replace('应用调用之外，邮件、浏览器、数据操作等独立持久账也须通过各自对账接口汇总，不只扫描 application_invocations；','应用调用之外，邮件、浏览器、数据操作等独立持久账按 §9.2.1 汇总，不只扫描 application_invocations；')
 return t
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 assert '### 4.75 'not in t
 suffix='；§4.75 补当前浏览器／邮件／只读恢复的独立账证据，发现浏览器七天清理丢失未知记录并验证隔离保留条件；完整业务汇总／对账及迁移接线未完成 '
 lines=t.splitlines()
 for i,line in enumerate(lines):
  if any(line.startswith('| '+q+' |')for q in ['Q09','Q37','Q41','Q48','Q49']):lines[i]=line.rstrip().removesuffix('|').rstrip()+suffix+'|'
 t='\n'.join(lines)+'\n'
 return t.replace('## 5. 失败与驱动修正','''### 4.75 业务结果恢复、独立账遗漏与未知保留

[五项独立检查](实验/20261114_业务结果恢复与未知保留验证/README.md)通过，含当前浏览器清理丢失未知记录反例。真实 BrowserOperations.recover 将超过七天的运行记录先标 unknown 再删除；receipt 返回 not-found，同 key 的 begin 不再标 replay，未执行实际浏览器操作或证明过期 run 可绕过授权。候选仅改临时构建的清理谓词，九种状态／effect／年龄组合及幂等通过。

实际只读恢复在受控 owner stopped 后取消合法只读操作，保留未知写与租约；实际邮件恢复释放旧 owner 租约但保留发送 unknown，撤销未执行授权。合法合成记录证明通用调用账为空时，浏览器／邮件及 task_id 为空的项目 UI 未知写仍可存在。已收口设计 §9.2.1 的各账职责、限制范围、迁移前保留顺序和缺记录不等于未执行。owner 状态／业务行均是夹具，无 SMTP、原生 Agent、浏览器动作或本轮真实崩溃；完整聚合、对象级限制与联合迁移仍待验。保留的 active UI 租约为未知写负例数据，无活进程；SQLite 完整性／外键通过。

## 5. 失败与驱动修正''')
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：业务恢复五项检查通过，确认邮件结果未知可与租约释放并存，单看通用调用账会漏掉独立业务状态；复现浏览器七天清理丢失未知记录，并验证隔离保留条件。见[技术方案 §9.2.1](技研/技术方案.md)。仍未修改产品代码。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续收口历史迁移／数据版本、独立业务汇总及剩余接口未知；以现有证据逐项核对开发边界，不重复本轮恢复单元验证，也不把数据库夹具当作真实业务联调。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'stagedFiles':len(entries),'checks':5,'archiveFiles':len(files),'sourceInputs':len(build['sources']),'candidateSourceInputs':len(candidate['sources'])}))
