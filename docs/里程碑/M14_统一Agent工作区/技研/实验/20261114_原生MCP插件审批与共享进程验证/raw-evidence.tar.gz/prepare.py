from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生MCP插件审批与共享进程验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==3 and not r.get('error');a=Path(r['out']);sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:
  assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());cleanup=json.loads((attempt/'cleanup.json').read_text());assert len(cleanup['nativeExits'])==2 and all(x['code']==(0 if x['driver']=='codex'else 143)for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped'for x in cleanup['cleanup'])
 db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM plugin_runtime_leases WHERE state<>'closed'"]:assert db.execute(query).fetchone()==(0,)
 db.close();attempts.append({'attempt':attempt.name,'passed':result['passed'],'error':result.get('error'),'nativeExits':cleanup['nativeExits'],'modelRequests':len(json.loads((attempt/'models.json').read_text())),'pluginLeases':json.loads((attempt/'plugin-leases.json').read_text()),'finalAllOwnedResourcesSettled':True})
assert len(attempts)==2
calls=json.loads((a/'plugin-calls.json').read_text());inv=json.loads((a/'invocations.json').read_text());approvals=json.loads((a/'approvals.json').read_text());pooled=json.loads((a/'host-pooled-runtime.json').read_text());models=json.loads((a/'models.json').read_text());assert len(calls)==len(inv)==len(approvals)==2 and len(models)==6
assert all(x['state']=='succeeded'and x['attempt_count']==1 and x['effect_state']=='completed'and x['semantics']=='write'for x in inv);assert all(x['state']=='allowed'for x in approvals)
assert {x['scope']['operationId']for x in calls}=={x['operation_id']for x in inv}=={x['operation_id']for x in approvals};assert len({x['task_id']for x in inv})==1 and len({x['run_id']for x in inv})==2
assert pooled['lease']['state']=='running'and all(x['state']=='stopped'for x in pooled['agentRuns'])
for driver in ['codex','claude']:
 rows=[x for x in models if x['driver']==driver];assert len(rows)==3 and 'PRIVATE_BRIDGE_'+driver in json.dumps(rows[1]['body'])and 'APP_NOT_ENABLED'in json.dumps(rows[2]['body'])
runtime={'attempts':attempts,'finalAttempt':a.name,'finalChecks':3,'invocations':inv,'pooledRuntimeBeforeServiceClose':pooled,'initialFailure':'Agent and bridge had stopped, but one host-owned cached plugin process correctly remained running. Probe wrongly demanded every plugin lease close on Agent completion; corrected to preserve host ownership and verify explicit PluginHostService.close.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/plugins/runtime-supervisor.ts',repo/'src/main/core/applications/plugins/session-tools.ts',repo/'src/main/core/applications/plugins/write-approvals.ts',repo/'src/main/core/applications/plugins/host-service.ts',repo/'src/main/core/applications/plugins/process.ts',repo/'src/main/core/applications/private-broker.ts',repo/'src/main/core/applications/tool-service.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Actual plugin host/policy/approval/sandbox/bridge/ToolService. Prior programmatic run/session/retention source variants reused; UI window authority is a private research facade, synthetic plugin code and fake model. No production change.','t3Boundary':'T3 provider boundary remains reference; host-owned pooled plugin lifetime is SmartDD existing behavior, not claimed as a T3 feature.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生私有 MCP、插件审批与共享进程归属

2026-11-14；R02／03／08／10／12，Q09／27／28／40／41。技术方案 §9.5，验证账 §4.65。仅隔离技术研究，产品／共享原型未改。

## 本批实际链路

`Codex／Claude native → stdio MCP → 现有私有 broker／内核 peer → ApplicationToolService → PluginSessionTools → PluginWriteApprovals／实时策略 → PluginLifecycle／沙箱 PluginProcess`

沿用当前程序化 run／binding／执行计划；安装受控 demo-tracker 测试包，由实际包校验和 PluginHostService 接管。插件代码只向自己的临时 privateData 追加合成 calls.log，无网络／真实业务连接，无 Keychain 读取。审批通过之前的“真实 handler”是现有 PluginSessionTools／生命周期／沙箱分发；插件业务代码本身是夹具，不声称验证真实业务插件内容。

## 最终 {a.name}：3 项通过

| 检查 | 证据 |
| --- | --- |
| B01 Codex | 模型驱动真实原生 MCP 写工具调用，实际业务审批阻止派发；错误窗口无权批准，当前隔离窗口回执允许后沙箱插件执行一次。结果进入下一模型请求；运行中停用后第二调用返回 APP_NOT_ENABLED，无第二次写入 |
| B02 Claude／Provider 切换 | 同一逻辑 task 从已排空 Codex 切 Claude，真实 SDK 私有 MCP 走相同审批与写处理器；旧 run 工具／桥入口拒绝，新 run 批准不恢复旧权；两次批准分别属于原 run 和 operationId |
| B03 共享插件进程 | 两个 Agent run 已 stopped、自己的 bridge 已退出时，宿主的同一个插件 invocation 进程仍 running；原 PID／出生身份实际仍存活。明确关闭本次 PluginHostService 后，该进程 stopped、插件租约 closed，其他运行租约 released |

两条 application_invocations 均 write／succeeded／completed／attempt_count=1，和两条 allowed 审批及插件收到的 operationId／runId 一一对应。六次本机模拟模型请求；原生 Codex 回合 completed、Claude success，进程分别受控退出 0／143。每个 Provider 的停用后调用均回到下一模型输入，未执行插件第二次写入。审批窗口是研究 WeakMap 句柄，不是真实 renderer／IPC／真人批准界面。

## 保留的失败与设计修正

初次 attempt-syS9QW 的 B01、B02 已通过；B03 错误要求所有插件租约随 Agent 结束关闭，实际剩一条宿主 invocation 租约 running。源码 PluginRuntimeSupervisor.current 按 appId 复用进程，引用数归零且未 retired／未到回收条件时保留；该进程服务了两个 Provider 的调用，不是原生 Agent 的后代。

因此修正的是实验与设计假设，未改生产实现。最终检查先证实宿主池合法保留，再执行自己的 PluginHostService.close，核验真实退出。初次失败数据库保留 running 行，finally 也已关闭本次宿主；两个批次最终均无遗留运行。两批共四个 native、四个插件进程（各一次 activation／一次复用 invocation），均有最终关闭记录。

## 迁移规则

Agent 生命周期、调用生命周期、宿主插件服务生命周期分开。切 Provider／取消单 run 只撤销该 run 的私有入口和未完成授权，等待属于它的调用结束；不能因同一宿主池进程还活着把任务永远卡在 stopping，也不能直接杀共享插件进程影响其他运行。插件更新／卸载／宿主关闭继续走现有 drain、references、retired 和独立 plugin_runtime_leases，包与私有数据不能因 Agent 租约释放就清理。

共享进程不等于永久业务授权：每次调用仍重新校验原 run、当前安装版本、项目启用、具体审批回执和 operationId。本批同一进程复用时，各 run 的权限与回执仍隔离。是否持有工作目录写权另判；活动／未知的任务调用或有未排空写者时，SVN 目录租约仍阻止交棒。此受控插件仅能写临时私有目录，不证明所有插件后台与项目写入都可安全放行。

未覆盖真实 UI 审批、并发多个 Agent 同时调用、插件更新／卸载竞争、含连接／秘密的插件、真实业务插件内容、父子树、崩溃恢复或跨平台。现有插件沙箱路径由实际代码执行，本批不声称完成沙箱逃逸测试。

## 证据

[结果](result.json)、[原失败／最终池归属审计](runtime-audit.json)、[源码依据](source-review.json)、[摘要](archive-manifest.json)、[驱动／插件源码／协议／数据库](raw-evidence.tar.gz)。{len(files)} 个文件、{len(dbs)} 份 SQLite 完整性／外键通过，{len(sources)} 个构建输入复核。

复跑需固定 SDK/native 和依赖；执行 build.mjs 后 probe.mjs。仅临时 HOME、受控测试包、本机模型端点和捕获的自有进程，不连接真实业务。
''')
section='''### 9.5 原生插件调用与宿主共享进程

[原生 MCP 插件联合实验](实验/20261114_原生MCP插件审批与共享进程验证/README.md)把 §9.4 的合成内置 handler 换成实际 PluginHostService／PluginSessionTools／PluginWriteApprovals／PluginLifecycle／沙箱 PluginProcess。Codex 与 Claude 各经真实私有 stdio MCP 触发写审批，错误窗口拒绝，研究窗口的精确回执允许后才写测试插件 privateData；实时停用阻止后续调用，原生模型收到拒绝。各 run／operationId／审批／调用账相互对应，切换不恢复旧权。

**保留现有插件进程池的宿主归属。** PluginRuntimeSupervisor 按 appId 缓存当前进程，单次调用引用归零不必关闭它。本批两个 Provider 共用同一个实际插件进程：Agent run 与桥均结束后，插件的独立 host lease 仍 running；关闭自己的插件宿主服务后才真实退出。不要把该进程迁到某个 Agent 的独占 scope，也不要让单 run 的 stopped 必须等待整个共享服务关闭。

取消／切换的收口按归属检查：该 run 的私有入口、审批、业务 activity 和原生／桥实例必须结束；宿主插件池继续按现有引用计数、retired／drain、版本和 plugin_runtime_leases 管理。原 run 释放不删除共享插件包／数据，不替其他调用取消授权。共享进程后续接受请求时仍重新核对新 run、当前权限和具体写审批，不沿用上个 Provider 的凭据。

这一区分不放松 SVN 写入约束。任务相关调用仍在途、业务副作用未知，或共享服务持有未排空的工作目录写权时仍须保留对应占用；只有已证明与该目录写入无关的宿主空闲服务才不构成该 run 的排空障碍。本批只验证私有目录写入，插件后台／工作区权限和多任务并发需另验。

原生调用到真实插件宿主链已补证，但插件代码与模型为受控夹具，审批窗口仍是私有句柄 facade。真实 renderer／IPC、业务插件连接与秘密、更新／卸载竞争、父子树及崩溃恢复仍按剩余账推进，不等同于插件业务全面验收。

'''
def tech(t):
 assert '### 9.5 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 t=t.replace('插件更新／卸载与多绑定交叉调用仍须联合验证；本轮仅核对源码。','§9.5 已补同 task 两端原生 MCP／真实插件处理器和宿主进程复用；更新／卸载与同时多绑定调用仍须联合验证。')
 old='业务调用账仍记录真实 run／task／operationId，一次成功只执行一次。bridge、native 和业务 activity 的结束分别核对，再释放运行资源。'
 new='业务调用账仍记录真实 run／task／operationId，一次成功只执行一次。该 run 的 bridge、native 和业务 activity 的结束分别核对，再释放运行资源；宿主共享插件池另按 §9.5 的独立生命周期收口。';assert old in t;t=t.replace(old,new)
 anchor='### 8.2';i=t.find(anchor);assert i!=-1;t=t[:i]+'宿主共享插件进程不能仅按“进程仍存活”归入父 Agent 未排空；其独立归属见 §9.5。任务相关在途调用、未知副作用和工作目录写权仍必须收口，不能借共享服务分类绕过目录单写者约束。\n\n'+t[i:];return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.65 原生 MCP 插件审批与宿主共享进程

[插件原生联合实验](实验/20261114_原生MCP插件审批与共享进程验证/README.md)最终 B01–03 通过：两端真实私有 MCP 触发现有插件写审批，错误窗口拒绝、隔离精确回执批准，实际沙箱测试插件各执行一次；运行中停用返回原生模型，新 Provider 不恢复旧 run 权限。

首批 B03 错误假定 Agent 结束即关闭全部插件进程，实证宿主池仍合法持有 invocation 租约；源码按 appId 复用，修正为保留宿主归属并在本次 PluginHostService.close 后验证真实退出。两批四个 native／四个插件进程最终关闭，原失败保留。技术方案 §9.5、§3.2.1 和 SVN 收口已同步；不含真实 UI、业务插件连接、并发／更新／卸载或崩溃。

'''
def ledger(t):
 assert '### 4.65 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q09','Q27','Q28','Q40','Q41']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.65 补两端原生私有 MCP／实际插件审批与沙箱分发、宿主共享池归属；真实 UI／并发／更新卸载仍待验 |'
 t='\n'.join(lines)+'\n';t=t.replace('继续补实际业务 handler／上下文及在途操作联合','§4.65 又补实际插件处理器／审批／沙箱及宿主共享池；继续补浏览器／邮件等实际上下文、在途操作与插件并发更新联合');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：两端原生私有 MCP 已接现有插件审批与沙箱执行；实证插件进程由宿主复用，Provider 切换不能误杀共享进程或复活旧授权，见[技术方案 §9.5](技研/技术方案.md)。测试插件只写临时私有目录，真实 UI 和业务连接未验，产品未改。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：补共享插件的并发／更新边界和其他实际业务上下文、在途操作；继续回执持久化与宿主恢复。其他责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
