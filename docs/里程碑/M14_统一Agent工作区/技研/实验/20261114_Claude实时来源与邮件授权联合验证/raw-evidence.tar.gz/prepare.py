from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_Claude实时来源与邮件授权联合验证';stage=r/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
result=json.loads((r/'latest.json').read_text());assert result['passed']==4 and result['error'] is None
builds=[json.loads((r/n).read_text()) for n in ['actual-build.json','candidate-build.json']]
for b in builds:
 for x in b['sources']+b['outputs']:assert sha(Path(x['path']).read_bytes())==x['sha256'],x['path']
patches=json.loads((r/'patches.json').read_text())+json.loads((r/'origin-patches.json').read_text())
for x in patches:assert sha(Path(x['file']).read_bytes())==x['before'];assert sha(Path(x['variant']).read_bytes())==x['after']
resources=[];prior=Path('/private/tmp/willyou-m14-live-origin-mail-probe')
for p in sorted((r/'bundles').rglob('*')):
 if p.is_file():
  rel=p.relative_to(r);assert sha(p.read_bytes())==sha((prior/rel).read_bytes());resources.append({'path':str(rel),'sha256':sha(p.read_bytes())})
sdk=Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk');native=sdk.parent/'claude-agent-sdk-darwin-arm64/claude';assert sha(native.read_bytes())=='abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c';assert json.loads((sdk/'package.json').read_text())['version']=='0.3.321'
frames=[json.loads(l) for l in (Path(result['out'])/'A-native.jsonl').read_text().splitlines()];init=next(x for x in frames if x.get('type')=='system' and x.get('subtype')=='init');assert init['claude_code_version']=='2.1.321'
audit=json.loads((r/'audit.json').read_text());tf=t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'builds':builds,'patches':patches,'resources':resources,'sdk':{'version':'0.3.321','files':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in [sdk/'package.json',sdk/'sdk.mjs',sdk/'sdk.d.ts',native]],'nativeReportedVersion':init['claude_code_version']},'t3':{'head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'path':str(tf),'sha256':sha(tf.read_bytes()),'sourceOnly':'claudeEchoedPromptUuids reads user_message_uuids then user_message_uuid; prompt lifecycle kept separate. Did not execute T3 or infer business authorization.'},'actual':['Claude SDK/native owned process, actual private MCP and kernel ancestry','Actual mail sender policy/native authorization/grant/execution and file proof checks','Actual default adapter L3 unsupported gate','Native ToolSearch loads deferred mail v2 schemas'],'candidate':['Same programmatic input/run/reader/identity-comparison research seams as 4.107','Per-run owned native init binds real session before source registration','Input accepted on matching top-level early UUID echo; exact submitted text then matched by raw native UUID/text/file proof'],'controlled':['Synthetic sender/frame, cipher, local model endpoint, SMTP verification and controlled submit','Explicit fixed-version research L3 override; not product support declaration','Prepared binding/source fixtures; bootstrap is internal without user-source receipt'],'failures':{'attempt-GssJXc':'Local model driver assumed immediate MCP schemas; ToolSearch deferred schemas caused MISSING_TOOL then local 500/retries and observation timeout. Native exit143; consumer rejection skipped cli.exited, original DB retains stopping/one active lease. Actual registry recovery on copy after kernel exit clears it.','attempt-ra2BzQ':'ToolSearch and actual draft succeeded; synthetic model parser missed exact native total_tokens reminder appended to JSON. Local 500, native exit143; fixed against retained response before rerun. This is not supplier outage or business failure.','preflight':'First orchestrator command selected not-yet-created workdir and did not spawn; created isolated directory before continuing. No native or data mutation in rejected command.'},'limits':['No actual Electron sender/IPC, real supplier or mail transport','Single thread/run; no provider switch/delegation or crash-persistent live source','No native batching/steering, folded messages/multimodal or all origin/resume_reason variants','Early echo association plus original text/file proof; echo alone is not business permission','No full TypeScript/runtime schema/product compatibility validation'],'audit':audit}
(r/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[p for p in r.iterdir() if p.is_file() and p.name not in ['manifest.json','raw-evidence.tar.gz','publication-audit.json']]
for d in [r/'bundles',r/'failure-recovery',*r.glob('attempt-*')]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
files=sorted(set(files));archive=r/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
man={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(r)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',result),('source-review.json',review),('archive-manifest.json',man)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# Claude 实时来源与邮件授权联合验证

日期：2026-11-14。D04／D05、Q17／Q41，承接 §4.107。Claude SDK 0.3.321／native 2.1.321 已在同一来源、owner 和实际邮件服务合同下完成四项检查。最终 attempt-5LsY47 通过；未修改产品源码。

## 实验边界

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，实际 bundle 681 项输入、候选 685 项输入；当前源码生成的六个研究变体与 §4.107 的职责相同。默认 v2 分发字节未变。真实 SDK 调用固定随 SDK 分发的原生程序，通过 spawn 回调取得实际 PID／出生身份，私有桥由内核祖先证明鉴别。

SDK initializationResult 与真实 system/init 分开：先以一个内部 bootstrap 回合取得实际 session_id，通过 owned run 写入当前身份，完成后再登记业务来源。bootstrap 没有用户来源 receipt，不代表用户批准；本轮为研究前置，不建议产品为了持久化会话自动发送无意义消息。

真实 NativeUserMessages 文件／inode／header／原始记录证明和实际邮件 tryNative／执行链保持。来源账、程序化运行和注入缝为候选；sender／frame 是模拟受信入口，模型、cipher、SMTP 核验和 submit 都是隔离夹具。没有真实 UI、供应商模型、邮件 DATA 或日常配置访问。

## 四项检查

| 检查 | 结果 |
| --- | --- |
| C01 当前支持门槛 | 当前默认 adapter 对 2.1.321 的 L3 返回 unsupported；仅在之后显式打开研究声明，不能将实验计成已发布支持 |
| C02 内部同文 | 内部委派输入具有原生 user 行和 UUID，实际 send_execute 仍返回 AUTHORIZATION_REQUIRED；零授权来源／提交 |
| C03 真实早期关联 | 同文从模拟受信用户入口提交；首个模型请求到达时仍 dispatching／no-match。随后实际 stream_event/message_start 带单一 user_message_uuid，私有通道核对 session／input；原始提交文本与原生 UUID／文件证明匹配后，现有 tryNative 生成唯一 native-user-message 来源并受控提交一次，重放不重复 |
| C04 续接和退出 | 再次内部自动投递同文不生成真人来源；旧来源保留但不再 live，run 结束后 retained／verify 均失效 |

所有四个业务输入的第一份可用回显均为 stream_event/message_start，早于各自 result；不靠终态倒推发送前已授权。回显没有替代原文证明：宿主保存原始提交文本，按原生 UUID 关联文件中的具体用户行，业务服务仍解析精确草稿修订、连接和政策。

实际默认工具发现也已运行：首轮 mail v2 Schema 被延迟，先通过原生 ToolSearch 选择四个具体工具，再执行业务 MCP。SDK allowedTools 不等同于所有 Schema 初始就在模型请求中；显示已连接也不能说明完整工具定义已交付。

最终一个原生进程、一个私有桥、五个回合（含一个 bootstrap）、十一次本机模型请求；一个 run stopped、25 租约 released，完整性／外键通过。三次回环认证、一次受控 submit、零 DATA。唯一业务授权来源只指向三条同文中的用户输入 UUID；未调用 renderer 的发送审阅／授权，项目发件身份确认仍由模拟管理 UI 完成。

## 保留的失败和恢复

GssJXc 的驱动直接寻找延迟工具，产生本机 500／重试并超时，原生退出 143。其收尾等待 SDK consumer 拒绝后跳过了 cli.exited，原库保留 stopping 与一份租约；进程均已终止。保留原库，在单独副本用实际 registry.recover 核对死亡 owner／进程，得到 stopped、24 租约 released。后续驱动确保 consumer 结果不跳过真实 CLI 退出登记，不放宽产品守卫。

ra2BzQ 已通过 ToolSearch 并创建实际草稿；模型驱动仍按纯 JSON 解析，而 Claude 在 tool_result 尾部附加确切的 total_tokens reminder，导致本机 500。先在保留回包上复现并核验仅剥离这一已知尾部的解析器，未知尾部继续拒绝，再进行最终复验。该解析器只用于本机模拟模型，不作为产品业务协议或授权判断。此失败原生也退出 143，但 run 和租约已正确释放。

三个尝试的三原生／三桥身份重新核验均 stopped；每份库完整性／外键通过。原失败停止状态与副本恢复结果分别保留，不能描述成所有原库都正常结束或全部 exit 0。最初目录尚不存在造成的命令前置拒绝未启动任何原生进程。

## T3 对照与迁移决定

只读核对 T3 `f313d0a6cb843551fb60e57a454a71e71a3a8c04`：ClaudeAdapterV2 的 claudeEchoedPromptUuids 优先取 user_message_uuids，再取单一 UUID，并另处理 prompt lifecycle。SDK 本地类型说明也明确早期 assistant／partial frame 的回显及合并输入列表。WillYou 借用关联机制，业务来源／授权仍由自己的宿主和原服务裁定。

本轮只验证单一消息／turn。批量合并、synthetic prompt 中途折入、子线程、resume_reason、缺回显、其他版本不能套用单 UUID 判据。不要用 SDK yield、队列接受或原生 user 角色代替已观察到的回显与精确文件来源；也不因来源尚未就绪自动重新发送用户输入。

Codex 与 Claude 的单 run 来源→邮件权限已分别取得真实运行证据，仍不代表混合切换／委派、持久输入恢复与实际 UI 同一链已通过。来源能力继续按版本独立声明；业务 fallback 保留明确审阅路径。整体 Q 完整关闭数及正式产品用例不增加。

复现：固定依赖／原生 helper／默认分发就绪后，运行 patch.py、origin-patch.py、build.mjs、build.mjs --candidate、probe.mjs、audit.mjs。setup-claude.py 仅记录从前批生成脚本的过程，不重复用于已生成副本。见[结果](result.json)、[来源和逐次审计](source-review.json)、[完整证据](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';s=(repo/rel).read_text();needle='### 6.2 ';assert needle in s
add='''[Claude 实时来源与邮件联合实验](实验/20261114_Claude实时来源与邮件授权联合验证/README.md)进一步在 SDK 0.3.321／native 2.1.321 的真实 owner／私有桥下复用同一业务合同：内部同文被拒绝，受信入口夹具的用户输入经早期 stream_event/message_start 的 UUID 关联及精确原生文件证明后进入实际邮件授权，内部续接与退出使 live 来源失效。首个模型请求到达时来源仍 dispatching；关联证据是在模型响应帧到达后、具体工具执行前取得，不能仅凭请求发出或 SDK yield 推定。当前默认 L3 声明仍拒绝该版本，研究能力覆盖须另行登记，不能放宽现有产品门槛。

Claude 的 user_message_uuid／user_message_uuids 由 Driver 按已验证版本解析，校验当前 private channel、session 和本次输入集合。回显只证明关联，原文仍来自宿主提交及对应原生行。单一 UUID 的本轮证据不覆盖批量合并、synthetic 折入、子线程或 resume_reason；这些情况保留各自来源，不能把最后一个 UUID 当作所有文本的真人授权。实际 sender、跨 Provider／委派和持久来源恢复仍待联合。

**工具连接、工具发现和业务批准分别处理。** 本轮 Claude 的默认工具 Schema 延迟加载，经过原生 ToolSearch 后业务 MCP 才进入模型可调用列表。allowedTools 是运行时工具许可参数，不能被解释为已经交付工具定义或业务写入批准。宿主维持已有 MCP 服务和动态业务权限；Driver 保留对应版本的发现流程，不能为兼容 UI 而绕过业务工具桥。

''';s=s.replace(needle,add+needle,1);put(rel,s)
rel=base/'技研/全局设计验证账.md';s=(repo/rel).read_text();assert '### 4.108 ' not in s
add='''### 4.108 Claude 早期输入关联与实际邮件授权联合

[四项 Claude 检查](实验/20261114_Claude实时来源与邮件授权联合验证/README.md)以 SDK 0.3.321／native 2.1.321 复用 §4.107 的 owner、来源候选、默认 v2 私有桥与实际邮件授权。内部同文拒绝；用户入口夹具的输入在首个模型响应 stream_event/message_start 取得精确 UUID 回显，再核原生文件，实际 tryNative 生成唯一来源并受控提交一次；内部续接不继承 live 来源，退出撤销。默认 L3 仍 unsupported，仅实验显式声明后取得证据。

最终四项通过，一个 native／一桥 stopped，一个 run stopped、25 租约 released；五回合含内部 bootstrap，十一次本机模型请求、三次回环认证、一次受控 submit、零 DATA。实际 ToolSearch 发现延迟工具；SDK 初始化不等于 native init，先取得实际 session 后登记来源。保留驱动漏处理工具发现和结果尾部 reminder 两次失败，均非供应商故障；第一轮 consumer 拒绝导致原库 stopping／一租约，在副本实际恢复为 stopped／24 租约 released。全部已记录原生／桥进程均 stopped，原失败库未改写。

T3 早期 UUID 列表映射只读对照。当前为单消息／turn、模拟 sender／模型／提交；未验实际 UI、批量折入、跨 Provider／委派或输入持久恢复和最终能力登记。T0.1 §6.1 补两端关联差异和工具发现／授权分层。Q 统计不变。

''';s=s.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=s.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D05 '):
  c=l.split('|');c[2]=' §4.55–56／107–108 已有输入去重／宿主退出恢复，以及 Codex 和 Claude 各自真实 run 的实时来源→邮件授权；内部同文不授权、用户回执与原生文件可在工具执行前联合。下一步同一最终命令／覆盖账联合持久恢复与业务来源、跨 Provider／委派、配置修订／附件遗漏及合并输入；派发未知不重发。两端模拟 UI 和研究 L3 声明不代替真实 sender、混合链或产品版本支持 ';lines[i]='|'.join(c)
s='\n'.join(lines)+'\n';s=s.replace('截至 §4.107，56','截至 §4.108，56',1);put(rel,s)
rel=base/'README.md';lines=(repo/rel).read_text().splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：Claude SDK 的四项实时来源／邮件授权联合检查通过，补齐早期 UUID 回显、原生文件证明、内部同文拒绝和退出撤销；与前批 Codex 分别取得真实单 run 证据。见[实验记录](技研/实验/20261114_Claude实时来源与邮件授权联合验证/README.md)。两端产品 L3 门槛仍未声明本次版本，研究使用显式临时声明；未改产品、未发真实邮件。统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04／D05](技研/全局设计验证账.md#71-当前全局收口方式)把两端分别取得的来源证据与同任务切换／委派、持久输入恢复及完整业务准入联合；继续迁移复制恢复、异常 owner、资源保留和支持矩阵。单 run 成功不等于这些联合分支已通过。'
put(rel,'\n'.join(lines)+'\n');(r/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size}))
