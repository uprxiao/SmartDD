import assert from 'node:assert/strict';
import actual from './actual.cjs';
import {decode,claimBinding} from './migration.mjs';
import {installClaims} from './claims.mjs';

export function installRetainedClaims(db){
 assert(db.inTransaction);
 db.exec("CREATE TABLE m14_retained_identity_source(binding_id TEXT PRIMARY KEY REFERENCES m14_binding(binding_id),task_id TEXT NOT NULL UNIQUE REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,snapshot_hash TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('held-known','schema0')))");
 for(const unmapped of db.prepare('SELECT * FROM m14_unmapped').all()){
  const row=db.prepare('SELECT * FROM capability_session_snapshots WHERE task_id=?').get(unmapped.task_id),identity=db.prepare('SELECT * FROM capability_session_identities WHERE task_id=?').get(unmapped.task_id);let v,kind;
  assert(identity,'RETAINED_IDENTITY_UNRESOLVED');
  if([2,3].includes(row.schema_version)){
   v=decode(row);assert.equal(row.retention_state,'hold','RETAINED_STATE_MISMATCH');v={...v,...v.native};kind='held-known';
  }else if(row.schema_version===0){
   assert.equal(actual.digest(row.snapshot_json),row.snapshot_hash,'RETAINED_CONTENT_CORRUPT');v=JSON.parse(row.snapshot_json);
   assert.deepEqual(Object.keys(v).sort(),['schema','taskId','projectId','runner','stateRoot','cwd','sessionId','reason'].sort(),'RETAINED_SCHEMA0_SHAPE');assert.equal(v.schema,0);assert.equal(row.retention_state,'hold');assert(['history-unknown','snapshot-corrupt'].includes(v.reason));assert.equal(v.reason,row.legacy_status);assert.equal(actual.canonicalJson(v),row.snapshot_json);kind='schema0';
  }else throw Error('UNSUPPORTED_RETAINED_SCHEMA');
  assert.equal(v.taskId,row.task_id);assert.equal(v.runner,identity.runner);assert.equal(v.sessionId,identity.session_id);assert.equal(v.cwd,identity.cwd);assert.equal(actual.canonicalFuturePath(v.stateRoot),identity.identity_root,'RETAINED_ROOT_CHANGED');
  const binding=claimBinding(db,{taskId:row.task_id,runner:identity.runner,identityRoot:identity.identity_root,nativeId:identity.session_id,cwd:identity.cwd,legacyTaskId:row.task_id});
  db.prepare('INSERT INTO m14_retained_identity_source VALUES(?,?,?,?)').run(binding,row.task_id,row.snapshot_hash,kind);
 }
 installClaims(db);
}
