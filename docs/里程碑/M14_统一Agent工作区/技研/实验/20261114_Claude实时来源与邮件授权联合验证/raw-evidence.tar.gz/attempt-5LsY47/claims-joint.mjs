import assert from 'node:assert/strict';
import actual from './actual.cjs';
import {bindNativeLocked} from './programmatic-prior.mjs';
import {putClaim} from './claims.mjs';
export function installProgrammaticClaimSources(db){
 assert(db.inTransaction);
 db.exec(`CREATE UNIQUE INDEX m14_native_claim_exact_owner ON m14_native_claim(runner,identity_root,native_id,binding_id,task_id);
 CREATE TABLE m14_programmatic_claim_source(
 runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,
 binding_id TEXT NOT NULL,task_id TEXT NOT NULL,cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,
 PRIMARY KEY(runner,identity_root,native_id,cap_id,snapshot_hash),
 FOREIGN KEY(runner,identity_root,native_id,binding_id,task_id) REFERENCES m14_native_claim(runner,identity_root,native_id,binding_id,task_id) ON DELETE RESTRICT,
 FOREIGN KEY(cap_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash) ON DELETE RESTRICT)`);
}
export function bindNativeClaimLocked(store,scope,native,{checkpoint=()=>{}}={}){
 const db=store.sqlite;assert(db.inTransaction,'TRANSACTION_REQUIRED');
 const canonical=actual.canonicalFuturePath(native.stateRoot);
 assert.equal(native.stateRoot,canonical,'NATIVE_ROOT_NOT_CANONICAL');
 const claim=db.prepare('SELECT * FROM m14_native_claim WHERE runner=? AND identity_root=? AND native_id=?').get(native.runner,canonical,native.sessionId);
 assert(!claim||claim.binding_id===scope.bindingId&&claim.task_id===scope.taskId,'NATIVE_CLAIM_CONFLICT');
 const next=bindNativeLocked(store,scope,native);checkpoint('after-native-revision');
 putClaim(db,scope.bindingId,canonical,native.sessionId);
 db.prepare('INSERT OR IGNORE INTO m14_programmatic_claim_source VALUES(?,?,?,?,?,?,?)').run(native.runner,canonical,native.sessionId,scope.bindingId,scope.taskId,next.capabilitySessionId,next.snapshotHash);
 checkpoint('after-claim-source');return next;
}
