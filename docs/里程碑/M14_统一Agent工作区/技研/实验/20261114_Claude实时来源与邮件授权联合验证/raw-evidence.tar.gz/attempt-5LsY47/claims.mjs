import assert from 'node:assert/strict';
import actual from './actual.cjs';
import {decode,claimBinding,addRevision} from './migration.mjs';
const {canonicalFuturePath}=actual;

export function putClaim(db,bindingId,root,nativeId){
 assert(db.inTransaction);const b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(bindingId);assert(b&&nativeId&&b.native_id===nativeId,'CLAIM_BINDING_IDENTITY');
 const canonical=canonicalFuturePath(root),old=db.prepare('SELECT * FROM m14_native_claim WHERE runner=? AND identity_root=? AND native_id=?').get(b.runner,canonical,nativeId);
 assert(!old||old.binding_id===bindingId&&old.task_id===b.task_id,'NATIVE_CLAIM_CONFLICT');
 db.prepare('INSERT OR IGNORE INTO m14_native_claim VALUES(?,?,?,?,?)').run(b.runner,canonical,nativeId,bindingId,b.task_id);return canonical;
}
export function retainVersionClaim(db,bindingId,row){
 const value=decode(row);if(value.native.sessionId===null)return;
 const b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(bindingId);assert.equal(b.task_id,value.taskId);assert.equal(b.runner,value.runner);
 const canonical=putClaim(db,bindingId,value.native.stateRoot,value.native.sessionId);
 db.prepare('INSERT OR IGNORE INTO m14_native_claim_source VALUES(?,?,?,?)').run(value.runner,canonical,value.native.sessionId,row.snapshot_hash);
}
export function installClaims(db){
 assert(db.inTransaction);
 db.exec(`CREATE TABLE m14_native_claim(runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,binding_id TEXT NOT NULL,task_id TEXT NOT NULL,PRIMARY KEY(runner,identity_root,native_id),FOREIGN KEY(binding_id,task_id,runner) REFERENCES m14_binding(binding_id,task_id,runner));
 CREATE INDEX m14_native_claim_binding ON m14_native_claim(binding_id);
 CREATE TABLE m14_native_claim_source(runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL REFERENCES capability_snapshot_versions(snapshot_hash) ON DELETE RESTRICT,PRIMARY KEY(runner,identity_root,native_id,snapshot_hash),FOREIGN KEY(runner,identity_root,native_id) REFERENCES m14_native_claim(runner,identity_root,native_id) ON DELETE RESTRICT);
 CREATE TRIGGER m14_claim_legacy_insert BEFORE INSERT ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_native_claim c JOIN m14_binding b ON b.binding_id=c.binding_id WHERE c.runner=NEW.runner AND c.identity_root=NEW.identity_root AND c.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_CLAIM_CONFLICT');END;
 CREATE TRIGGER m14_claim_legacy_update BEFORE UPDATE ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_native_claim c JOIN m14_binding b ON b.binding_id=c.binding_id WHERE c.runner=NEW.runner AND c.identity_root=NEW.identity_root AND c.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_CLAIM_CONFLICT');END;`);
 for(const b of db.prepare('SELECT * FROM m14_binding').all()){
  if(b.native_id)putClaim(db,b.binding_id,b.identity_root,b.native_id);
  for(const row of db.prepare('SELECT * FROM capability_snapshot_versions WHERE task_id=?').all(b.legacy_task_id))retainVersionClaim(db,b.binding_id,row);
 }
}
export function claimNew(db,input){return db.transaction(()=>{const identityRoot=canonicalFuturePath(input.identityRoot),bindingId=claimBinding(db,{...input,identityRoot});if(input.nativeId)putClaim(db,bindingId,identityRoot,input.nativeId);return bindingId;}).immediate();}
export function updateCopiedBinding(db,bindingId,after){
 assert(db.inTransaction);const b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(bindingId),cap=db.prepare('SELECT * FROM m14_cap WHERE binding_id=?').get(bindingId);
 assert.equal(b.task_id,after.snapshot.taskId);assert.equal(b.native_id,after.snapshot.native.sessionId);
 db.prepare('UPDATE m14_binding SET identity_root=? WHERE binding_id=?').run(canonicalFuturePath(after.snapshot.native.stateRoot),bindingId);
 const row=db.prepare('SELECT * FROM capability_snapshot_versions WHERE snapshot_hash=?').get(after.pointer.snapshotHash);retainVersionClaim(db,bindingId,row);
 addRevision(db,bindingId,cap.cap_id,row,db.prepare('SELECT * FROM capability_session_refs WHERE task_id=?').all(b.task_id));db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(row.snapshot_hash,cap.cap_id);
}
