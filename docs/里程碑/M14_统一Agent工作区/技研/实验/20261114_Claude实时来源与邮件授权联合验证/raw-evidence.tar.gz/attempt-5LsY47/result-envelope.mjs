export function envelopes(value,out=[]){
 if(typeof value==='string'){
  const raw=value.replace(/^Wall time: [0-9.]+ seconds\nOutput:\n/,'').replace(/\n\n<system-reminder>\n<total_tokens>[0-9]+ tokens left<\/total_tokens>\n<\/system-reminder>$/,'');
  try{envelopes(JSON.parse(raw),out);}catch{}
 }else if(Array.isArray(value))for(const x of value)envelopes(x,out);
 else if(value&&typeof value==='object'){if(value.schema==='willyou-app-result-v2')out.push(value);else for(const x of Object.values(value))envelopes(x,out);}
 return out;
}
