from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD/src/main/core/applications');patches=[];sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
def patch(name,replacements):
 p=repo/(name+'.ts');old=p.read_text();s=old
 for a,b in replacements:
  assert a in s,a;s=s.replace(a,b)
 q=r/(name+'.ts.variant');q.write_text(s);patches.append({'file':str(p),'before':sha(old),'variant':str(q),'after':sha(s)})
patch('native-user-messages',[
 ('this.inputs.match(context, parsed.text, parsed.timestamp)','this.inputs.match(context, parsed.text, parsed.timestamp, parsed.nativeEvidence)'),
 ('timestamp: parsed.timestamp, text:','nativeEvidence: parsed.nativeEvidence, timestamp: parsed.timestamp, text:'),
 ('this.inputs.match(fresh, message.text, message.timestamp)','this.inputs.match(fresh, message.text, message.timestamp, message.nativeEvidence)'),
 ('this.inputs.match(context, message.text, message.timestamp)','this.inputs.match(context, message.text, message.timestamp, message.nativeEvidence)')])
patch('application-service',[
 ('    this.nativeMessages=new NativeUserMessages(', '    if(options.researchInputsFactory)this.nativeInputs=options.researchInputsFactory(this.nativeInputs);\n    this.nativeMessages=new NativeUserMessages('),
 ('try{return new AgentAdapterRegistry(store).levels(hash,version);}catch{return [];}});','try{return options.researchLevels?options.researchLevels(hash,_runner,version):new AgentAdapterRegistry(store).levels(hash,version);}catch{return [];}},options.researchFormats);')])
patch('mail-user-authorizations',[
 ("import { randomUUID } from 'node:crypto';", "import { randomUUID } from 'node:crypto';\nimport {sameInputScope} from '"+str(r/'inputs.mjs')+"';"),
 ('a.ptyId===b.ptyId','sameInputScope(a,b)')])
(r/'origin-patches.json').write_text(json.dumps(patches,indent=2)+'\n')
p=r/'build.mjs';s=p.read_text();s=s.replace('(session-registry|run-registry|run-plan)', '(session-registry|run-registry|run-plan|native-user-messages|application-service|mail-user-authorizations)');s=s.replace("'process-identity':['MacProcessIdentityReader']", "'native-evidence-adapters':['builtinNativeEvidenceAdapters','NativeEvidenceAdapterRegistry'],'native-user-messages':['NativeUserMessages'],'process-identity':['MacProcessIdentityReader']");s=s.replace("scope:'Actual current registry and fixture; Vite glob expansion only. No product source variants.'", "scope:candidate?'Current source plus explicit six research variants; typechecking/product integration not performed.':'Current actual source with Vite glob expansion; synthetic cipher helper.'");p.write_text(s)
