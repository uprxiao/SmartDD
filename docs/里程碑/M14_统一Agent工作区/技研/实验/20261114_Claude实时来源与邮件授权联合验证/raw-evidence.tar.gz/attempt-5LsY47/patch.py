from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD/src/main/core/applications');prior=Path('/private/tmp/willyou-m14-business-mcp-joint-probe');patches=[]
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
def emit(name,s):
 original=(repo/name).read_bytes();(root/(name+'.variant')).write_text(s);patches.append({'file':str(repo/name),'before':hashlib.sha256(original).hexdigest(),'variant':str(root/(name+'.variant')),'after':hashlib.sha256(s.encode()).hexdigest()})
s=(repo/'session-registry.ts').read_text();p=(prior/'session-registry.ts.variant').read_text();start=p.index('  inspectProgrammatic(');end=p.index('  async verifyResources(',start);methods=p[start:end];methods=methods[:methods.index('  async createProgrammatic(')]+methods[methods.index('  async verifyProgrammaticResources('):]
s="import {inspectProgrammatic as readProgrammatic,refs as programmaticRefs} from '"+str(root)+"/programmatic-prior.mjs';\nimport {assertProgrammaticClaim} from '"+str(root)+"/claim-read.mjs';\nexport interface ProgrammaticScope {taskId:string;bindingId:string;capabilitySessionId:string;snapshotHash:string}\n"+s
methods=methods.replace('return readProgrammatic(this.store,scope,(s:CapabilitySessionSnapshot)=>this.expectedSources(s));','const value=readProgrammatic(this.store,scope,(s:CapabilitySessionSnapshot)=>this.expectedSources(s));assertProgrammaticClaim(this.store,scope,value.snapshot);return value;')
s=replace(s,'  async verifyResources(',methods+'  async verifyResources(');emit('session-registry.ts',s)
s=(repo/'run-registry.ts').read_text();s="import {programmaticScopeSchema,refs as programmaticRefs} from '"+str(root)+"/programmatic-prior.mjs';\nimport type {ProgrammaticScope} from './session-registry';\n"+s
s=replace(s,'export interface RunRow {','export interface RunRow { execution_mode?:string;binding_id?:string;capability_session_id?:string;source_snapshot_hash?:string;generation?:number;')
s=replace(s,'interface OwnedRun {','interface OwnedRun { programmatic?:ProgrammaticScope & {generation:number};')
s=replace(s,"const TERMINAL =",'const scopeOf=(row:RunRow):ProgrammaticScope=>({taskId:row.task_id,bindingId:row.binding_id!,capabilitySessionId:row.capability_session_id!,snapshotHash:row.snapshot_hash});\nconst TERMINAL =')
s=replace(s,'    const session = this.sessions.inspectCoordinated(row.task_id);',"    if(owned.programmatic&&(row.execution_mode!=='programmatic'||row.binding_id!==owned.programmatic.bindingId||row.capability_session_id!==owned.programmatic.capabilitySessionId||row.generation!==owned.programmatic.generation||row.source_snapshot_hash!==owned.programmatic.snapshotHash))throw new ApplicationError('SCOPE_DENIED','运行与宿主签发的绑定代次不同');\n    const session = owned.programmatic?this.sessions.inspectProgrammatic(scopeOf(row)):this.sessions.inspectCoordinated(row.task_id);")
s=replace(s,'private closure(taskId: string,guard?:NativeGuard)','private closure(taskId: string,guard?:NativeGuard,scope?:ProgrammaticScope)')
s=replace(s,'):this.store.sqlite.prepare(\'SELECT ref_id,ref_hash,ref_kind,relative_path FROM capability_session_refs','):scope?programmaticRefs(this.store,scope):this.store.sqlite.prepare(\'SELECT ref_id,ref_hash,ref_kind,relative_path FROM capability_session_refs')
s=s.replace('this.closure(row.task_id,owned.guard)','this.closure(row.task_id,owned.guard,owned.programmatic?scopeOf(row):undefined)')
anchor='  private async reserveManaged(input: z.input<typeof reserveSchema>,reservation?: {runId:string;ptyId:string}): Promise<OwnedCapabilityRun> {'
new="""  async reserveProgrammatic(input:ProgrammaticScope & {bindings:RunBindingRevision[];bindingMode?:'current'|'run'}):Promise<OwnedCapabilityRun>{
    if(!this.deps.createPlan)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化运行必须提供固定应用计划');
    const {bindings,bindingMode='current',...scope}=input;const parsed=programmaticScopeSchema.parse(scope);return this.reserveManaged({taskId:parsed.taskId,snapshotHash:parsed.snapshotHash,bindings,bindingMode},undefined,parsed);
  }
  private async reserveManaged(input: z.input<typeof reserveSchema>,reservation?: {runId:string;ptyId:string},programmatic?:ProgrammaticScope): Promise<OwnedCapabilityRun> {"""
s=replace(s,anchor,new);s=replace(s,"let selectionHash = '';","let selectionHash = '',generation=0;")
s=replace(s,'(await this.sessions.get(value.taskId)).snapshot','(programmatic?await this.sessions.getProgrammatic(programmatic):await this.sessions.get(value.taskId)).snapshot')
s=replace(s,'const session = this.sessions.inspectCoordinated(value.taskId); selectionHash = session.selectionHash;','const session = programmatic?this.sessions.inspectProgrammatic(programmatic):this.sessions.inspectCoordinated(value.taskId); selectionHash = session.selectionHash;')
s=replace(s,'const resources=this.closure(value.taskId);','const resources=this.closure(value.taskId,undefined,programmatic);')
start=s.index('      this.store.sqlite.prepare("INSERT INTO capability_runs(');end=s.index('\n',start);old=s[start:end]
new="""      if(programmatic){
        generation=(this.store.sqlite.prepare("UPDATE m14_binding SET run_generation=run_generation+1 WHERE binding_id=? AND task_id=? AND entry_mode='programmatic' AND phase='prepared' RETURNING run_generation").get(programmatic.bindingId,value.taskId) as {run_generation:number}).run_generation;
        this.store.sqlite.prepare("INSERT INTO capability_runs(run_id,task_id,project_id,runner,state,started_at,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id,binding_mode,revocation_state,execution_mode,binding_id,capability_session_id,source_snapshot_hash,generation) VALUES(?,?,?,?,'preparing',?,?,?,?,?,?,?,?,'open','programmatic',?,?,?,?)").run(runId,value.taskId,session.snapshot.projectId,session.snapshot.runner,timestamp,value.snapshotHash,this.instanceId,this.host.pid,this.host.startedAt,canonicalJson(value.bindings),ptyId,value.bindingMode,programmatic.bindingId,programmatic.capabilitySessionId,value.snapshotHash,generation);
      }else{
"""+old+'\n      }';s=s[:start]+new+s[end:]
s=replace(s,'const owned: OwnedRun = { ...(plan?', 'const owned: OwnedRun = { ...(programmatic?{programmatic:{...programmatic,generation}}:{}),...(plan?')
s=replace(s,'if(guard)await guard.verify();else await this.sessions.verifyResources(taskId);','if(guard)await guard.verify();else if(owned.programmatic)await this.sessions.verifyProgrammaticResources(scopeOf(this.row(runId)));else await this.sessions.verifyResources(taskId);')
# Unsupported downgrade needs explicit refusal rather than falling into legacy source loading.
s=replace(s,"      if(!readLaunchRestriction(this.store,runId,result.row.task_id,result.owned.selectionHash))", "      if(result.owned.programmatic)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化原生降级未纳入本次研究');\n      if(!readLaunchRestriction(this.store,runId,result.row.task_id,result.owned.selectionHash))")
s=replace(s,"      const {owned}=this.owner(runId);\n      const guard=", "      const {owned}=this.owner(runId);\n      if(owned.programmatic)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化原生降级未纳入本次研究');\n      const guard=")
emit('run-registry.ts',s)
s=(repo/'run-plan.ts').read_text();old="const row=store.sqlite.prepare('SELECT snapshot_json FROM capability_snapshot_versions WHERE task_id=? AND snapshot_hash=?').get(snapshot.taskId,plan.snapshotHash) as {snapshot_json:string}|undefined;"
new="""const run=store.sqlite.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(plan.runId) as {execution_mode?:string;binding_id?:string;capability_session_id?:string;source_snapshot_hash?:string}|undefined;
  const row=(run?.execution_mode==='programmatic'?store.sqlite.prepare('SELECT snapshot_json FROM m14_revision WHERE task_id=? AND binding_id=? AND cap_id=? AND snapshot_hash=? AND snapshot_hash=?').get(snapshot.taskId,run.binding_id,run.capability_session_id,plan.snapshotHash,run.source_snapshot_hash):store.sqlite.prepare('SELECT snapshot_json FROM capability_snapshot_versions WHERE task_id=? AND snapshot_hash=?').get(snapshot.taskId,plan.snapshotHash)) as {snapshot_json:string}|undefined;"""
s=replace(s,old,new);emit('run-plan.ts',s)
(root/'patches.json').write_text(json.dumps(patches,indent=2)+'\n')
print(json.dumps({'currentSourceVariants':len(patches),'fullOldVariantsCopied':0}))
