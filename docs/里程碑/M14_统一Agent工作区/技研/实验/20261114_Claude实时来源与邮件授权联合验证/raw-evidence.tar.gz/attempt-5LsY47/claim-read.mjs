import assert from 'node:assert/strict';
import actual from './actual.cjs';
export function assertProgrammaticClaim(store,scope,snapshot){
 const native=snapshot.native;if(native.sessionId===null)return;
 const root=actual.canonicalFuturePath(native.stateRoot);assert.equal(native.stateRoot,root,'NATIVE_ROOT_NOT_CANONICAL');
 const claim=store.sqlite.prepare('SELECT 1 FROM m14_native_claim c JOIN m14_programmatic_claim_source s USING(runner,identity_root,native_id,binding_id,task_id) WHERE c.runner=? AND c.identity_root=? AND c.native_id=? AND c.binding_id=? AND c.task_id=? AND s.cap_id=? AND s.snapshot_hash=?').get(snapshot.runner,root,native.sessionId,scope.bindingId,scope.taskId,scope.capabilitySessionId,scope.snapshotHash);
 assert(claim,'PROGRAMMATIC_NATIVE_CLAIM_SOURCE_MISSING');
}
