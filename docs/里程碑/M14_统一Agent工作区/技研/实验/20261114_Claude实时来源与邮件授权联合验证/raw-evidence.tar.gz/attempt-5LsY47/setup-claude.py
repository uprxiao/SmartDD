from pathlib import Path
r=Path(__file__).resolve().parent;p=r/'probe.mjs';s=p.read_text()
s=s.replace("'setup-probe.py'", "'setup-claude.py'")
s=s.replace('ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b','abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c')
s=s.replace("e.child.stdin.end();", "e.stop?.();",1).replace("await e.run.cli.exited();", "await deadline(e.consume,'SDK consumer stopped');await e.run.cli.exited();",1)
s=s.replace("get('codex')", "get('claude-code')").replace("runner==='codex'&&version==='0.167.1'", "runner==='claude-code'&&version==='2.1.321'")
s=s.replace("nativeEvidence:{turnId:value.payload?.internal_chat_message_metadata_passthrough?.turn_id,recordId:value.payload?.id}", "nativeEvidence:{inputId:value.uuid}")
s=s.replace("x.metadata.agentId==='codex'", "x.metadata.agentId==='claude-code'").replace("stateRoot=home+'/.codex'", "stateRoot=home+'/.claude'")
s=s.replace("runner:'codex'", "runner:'claude-code'").replace("id:'codex'", "id:'claude-code'").replace("bindingId,taskId,'codex',stateRoot", "bindingId,taskId,'claude-code',stateRoot")
s=s.replace("assert(e&&broker.hasAuthenticated(e.run.runId));", "assert(e);if(e.phase!=='bootstrap')assert(broker.hasAuthenticated(e.run.runId));")
s=s.replace("reply(res,'codex'", "reply(res,'claude'")
s=s.replace("if(e.phase==='prepare'){", "if(e.phase==='bootstrap'){assert.equal(e.phaseRequests,1);reply(res,'claude',body,{text:'READY'});}else if(e.phase==='prepare'){")
s=s.replace("JSON.stringify(body.input).includes('AUTHORIZATION_REQUIRED')", "JSON.stringify(body.messages).includes('AUTHORIZATION_REQUIRED')")
a="if(e.phaseRequests===1){const observed=await app.nativeMessages.read(e.run.runId);save('live-before-tool.json',{status:observed.status,issueCode:observed.issueCode,messages:observed.messages,ledger:ledger.audit()});assert.equal(observed.status,'matched');assert.equal(observed.messages.length,1);assert(app.nativeMessages.isLive(observed.messages[0]));assert.equal(observed.messages[0].receipt.nativeInputId,e.inputId);assert(await app.nativeMessages.verify(observed.messages[0]));reply(res,'claude',body,{tool:tool('send_execute'),args:{intentId:e.intent.id,expectedReviewHash:e.intent.reviewHash}});}"
b="if(e.phaseRequests===1){const observed=await app.nativeMessages.read(e.run.runId);save('before-assistant-frame.json',{observed,ledger:ledger.audit()});assert.equal(observed.messages.length,0);reply(res,'claude',body,{tool:tool('send_execute'),args:{intentId:e.intent.id,expectedReviewHash:e.intent.reviewHash}});}"
assert a in s;s=s.replace(a,b)
s=s.replace("else if(e.phaseRequests===2){e.result=last('mail.send.execute').intent;", "else if(e.phaseRequests===2){const observed=await app.nativeMessages.read(e.run.runId);save('after-tool-source.json',{observed,ledger:ledger.audit()});assert.equal(observed.status,'matched');assert.equal(observed.messages.length,1);assert.equal(observed.messages[0].receipt.nativeInputId,e.inputId);assert(app.nativeMessages.isLive(observed.messages[0]));assert(await app.nativeMessages.verify(observed.messages[0]));e.result=last('mail.send.execute').intent;")
s=s.replace("const e=await launch('A');ledger=", "const e=await launch('A');const bootstrap=await deadline(e.bootstrapDone,'bootstrap result');assert.equal(bootstrap.is_error,false);ledger=")
s=s.replace("register(e.run.runId,'0.167.1'", "register(e.run.runId,'2.1.321'")
a=s.index(' e.onAccepted=');b=s.index('\n const turn=',a)
s=s[:a]+""" e.onAccepted=m=>{assert.equal(m.session_id,e.nativeId);assert.equal(m.user_message_uuid,e.inputId);assert.equal(m.parent_tool_use_id,null);if(m.user_message_uuids)assert.deepEqual(m.user_message_uuids,[e.inputId]);if(e.acceptedInput===e.inputId)return;e.acceptedInput=e.inputId;ledger.acknowledge(channel,e.inputId,{inputId:m.user_message_uuid,sessionId:m.session_id,text:e.inputText,ackKind:m.type,ackUuid:m.uuid});save(e.phase+'-accepted.json',m);};"""+s[b:]
s=s.replace("e.phase=phase;e.phaseRequests=0;e.inputId=randomUUID();", "e.phase=phase;e.phaseRequests=0;e.inputId=randomUUID();e.inputText=text;")
s=s.replace("assert.equal(result.status,'completed',JSON.stringify({result,modelErrors}));", "assert.equal(result.is_error,false,JSON.stringify({result,modelErrors}));")
s=s.replace("sameText:true,liveNativeReceipt:true,actualFileProof:true", "sameText:true,liveNativeReceipt:true,acceptedInput:e.acceptedInput,actualFileProof:true")
for a,b in [('S01','C01'),('S02','C02'),('S03','C03'),('S04','C04')]:s=s.replace("await check('"+a+"'", "await check('"+b+"'")
a=s.index(" await check('S05'");b=s.index('\n}catch(e)',a);s=s[:a]+s[b:]
s=s.replace('Actual owned Codex and default v2 MCP', 'Actual owned Claude SDK/native and default v2 MCP')
p.write_text(s)
