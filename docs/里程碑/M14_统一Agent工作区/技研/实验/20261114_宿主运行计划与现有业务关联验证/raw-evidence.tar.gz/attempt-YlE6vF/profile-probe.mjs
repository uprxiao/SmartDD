import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,copyFileSync} from 'node:fs';
import actual from './candidate.cjs';
import p from './profile.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/profile-attempt-'),f=await actual.runFixture(),db=p.drizzle(f.sqlite,{schema:p.schema}),cipher={isAvailable:()=>true,encrypt:s=>Buffer.from('fixture:'+s),decrypt:b=>b.toString().slice(8)},secrets=new p.SecretsStore(db,cipher);let now=1000;
const svc=new p.AiProfileService(db,secrets,()=>now),input={name:'isolated',runner:'claude',executable:null,env:[{name:'ANTHROPIC_AUTH_TOKEN',secret:true,value:'synthetic-one'}],args:[],color:null,isDefault:false},checks=[];
for(const n of ['profile-build.mjs','profile-build.json','profile.cjs','profile-probe.mjs'])copyFileSync(root+'/'+n,out+'/'+n);
let error;try{
 const row=svc.create(input);assert.equal(row.runner,'claude');assert.equal(p.builtinRunnerAdapters.get(row.runner).describe().agentId,'claude-code');assert.throws(()=>svc.create({...input,name:'invalid',runner:'claude-code'}));checks.push({id:'C01',status:'passed',finding:'Actual profile runner claude maps to capability agentId claude-code; raw equality is invalid.'});
 const sig=svc.launchSignature(row.id);now=1001;svc.update(row.id,{...input,name:'renamed'});assert.equal(svc.launchSignature(row.id),sig);assert.notEqual(svc.get(row.id).updatedAt,row.updatedAt);checks.push({id:'C02',status:'passed',finding:'Cosmetic rename changes updatedAt while launchSignature stays stable.'});
 const at=svc.get(row.id).updatedAt;svc.update(row.id,{...input,name:'renamed',env:[{...input.env[0],value:'synthetic-two'}]});assert.equal(svc.get(row.id).updatedAt,at);assert.notEqual(svc.launchSignature(row.id),sig);checks.push({id:'C03',status:'passed',finding:'Two updates sharing an injected millisecond leave same updatedAt while secret and launchSignature change.'});
 secrets.delete(p.aiSecretKey(row.id,'ANTHROPIC_AUTH_TOKEN'));assert.throws(()=>svc.resolve(row.id),/缺少令牌/);checks.push({id:'C04',status:'passed',finding:'Missing synthetic secret blocks actual resolve; no fallback.'});
}catch(e){error=e.stack;process.exitCode=1;}finally{await f.sqlite.backup(out+'/final.sqlite');f.sqlite.close();}
const result={out,checks,error,scope:'Actual AiProfileService/SecretsStore with isolated SQLite, fake cipher and controlled clock; no real keychain or model access.'};writeFileSync(out+'/result.json',JSON.stringify(result,null,2));writeFileSync(root+'/profile-latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
