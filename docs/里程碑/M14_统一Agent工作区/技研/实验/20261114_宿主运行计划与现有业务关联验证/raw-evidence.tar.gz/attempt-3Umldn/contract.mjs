import assert from 'node:assert/strict';
import {z} from 'zod';
import actual from './actual.cjs';
const hash=z.string().regex(/^[a-f0-9]{64}$/),id=z.string().min(1);
const ref=z.object({resourceId:id,kind:id,contentHash:hash,relativePath:id,generation:z.number().int().positive()}).strict();
export const planSchema=z.object({schema:z.literal('m14-delivery-receipt-probe-v1'),receiptId:z.uuid(),token:z.uuid(),storeId:z.uuid(),taskId:id,bindingId:z.uuid(),capabilitySessionId:z.uuid(),snapshotHash:hash,runId:z.uuid(),generation:z.number().int().positive(),runner:id,profileId:z.uuid(),profileRevision:z.number().int(),resources:z.array(ref).min(1)}).strict();
export const canonical=actual.canonicalJson,digest=actual.digest;
export function inspect(db,row){
 const plan=planSchema.parse(JSON.parse(row.plan_json));assert.equal(digest(canonical(plan)),row.plan_hash,'PLAN_HASH_CHANGED');
 for(const [key,col]of Object.entries({receiptId:'receipt_id',token:'token',storeId:'store_id',taskId:'task_id',bindingId:'binding_id',capabilitySessionId:'cap_id',snapshotHash:'snapshot_hash',runId:'run_id',generation:'generation'}))assert.equal(plan[key],row[col],'PLAN_IDENTITY_CHANGED:'+key);
 const run=db.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(plan.runId);assert(run&&run.task_id===plan.taskId&&run.binding_id===plan.bindingId&&run.capability_session_id===plan.capabilitySessionId&&run.source_snapshot_hash===plan.snapshotHash&&run.generation===plan.generation&&run.runner===plan.runner,'RUN_SCOPE_CHANGED');
 assert(row.owner_pid===run.owner_pid&&row.owner_started_at===run.owner_started_at&&row.owner_instance===run.owner_instance_id,'OWNER_CHANGED');
 const binding=db.prepare('SELECT * FROM m14_binding WHERE binding_id=? AND task_id=? AND runner=?').get(plan.bindingId,plan.taskId,plan.runner);assert(binding&&binding.profile_id===plan.profileId&&binding.profile_revision===plan.profileRevision,'BINDING_SCOPE_CHANGED');
 assert(db.prepare('SELECT 1 FROM m14_revision WHERE cap_id=? AND task_id=? AND binding_id=? AND snapshot_hash=?').get(plan.capabilitySessionId,plan.taskId,plan.bindingId,plan.snapshotHash),'SOURCE_REVISION_MISSING');
 const pins=db.prepare('SELECT resource_id AS resourceId,kind,content_hash AS contentHash,relative_path AS relativePath,generation FROM m14_delivery_ref WHERE receipt_id=? ORDER BY resource_id').all(row.receipt_id);
 assert.equal(canonical(pins),canonical(plan.resources),'DELIVERY_MEMBERS_CHANGED');
 return{plan,run,binding};
}
