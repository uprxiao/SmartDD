from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_宿主运行计划与现有业务关联验证';entries=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
latest=json.loads((root/'latest.json').read_text());profile=json.loads((root/'profile-latest.json').read_text());assert latest['passed']==11 and not latest.get('error');assert len(profile['checks'])==4 and not profile.get('error')
sources={}
for n in ['build.json','profile-build.json']:
 for s in json.loads((root/n).read_text())['sources']:
  p=Path(s['path']);assert sha(p.read_bytes())==s['sha256'],str(p);sources[str(p)]=s
refs=['src/main/core/ai/ai-profile-service.ts','src/main/core/tasks/runner-adapters.ts','src/main/core/applications/run-plan.ts','src/main/core/applications/current-authorization.ts','src/shared/application-run-plan.ts']
t3=Path('/Users/hx/projects/t3code');trefs=['packages/contracts/src/providerInstance.ts','apps/server/src/provider/ProviderInstallationGate.ts','apps/server/src/orchestration-v2/ProviderSessionManager.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,paths in [(repo,refs),(t3,trefs)]for p in paths],'sourceInputsVerified':len(sources),'profileImportShim':'Unused node-pty import replaced by throwing stub; no PTY executed.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--','src','prototypes','package.json','pnpm-lock.yaml'],text=True)
assert not subprocess.check_output(['git','-C',str(t3),'status','--porcelain'],text=True)
files=[];dbchecks=[]
for p in root.rglob('*'):
 if not p.is_file() or 'node_modules' in p.parts or 'publication' in p.parts or p.name in ['raw-evidence.tar.gz','archive-manifest.json','manifest.json','audit.json']:continue
 if p.suffix not in ['.mjs','.cjs','.json','.sql','.ts','.sqlite','.variant','.py']:continue
 files.append(p)
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbchecks.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbchecks,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
put(exp/'raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes());put(exp/'archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2));put(exp/'result.json',json.dumps({'execution':latest,'profile':profile},ensure_ascii=False,indent=2));put(exp/'source-review.json',json.dumps(review,ensure_ascii=False,indent=2))
readme=f'''# 宿主运行计划与现有业务关联：独立技术实验

日期：2026-11-14。对应 R02／03／08／10／11，Q06／13／20；设计 §3.2.10，验证账 §4.41。仅技术研究；产品、共享原型及真实配置未改动。

## 结论

独立的宿主 ExecutionPlan 可以强关联现有不可变 v1 ApplicationRunPlan，并在同一 C 锁短事务中保存交付 receipt／资源 pins。只有已验证、已提交的宿主计划才可进入候选消费入口；已有 run.prepare 不表示这一步完成。R17 当前业务授权继续由真实 CurrentApplicationAuthorization／ToolService 按调用计算，不改写启动计划。

真实 AiProfileService 还暴露了旧夹具未覆盖的边界：profile runner `claude` 映射到 capability agentId `claude-code`，不能直接比较字符串；updatedAt 对更名会变化，对同一毫秒内的配置修改可能不变，不能作为唯一配置修订。既有 launchSignature 能区分实际启动内容，但包含解密后的值参与计算，只能按内部敏感证据处理，不直接变成公开计划字段。

## 实际执行与失败保留

- `attempt-oXFqDT`：E01–E10 的主体断言完成，收尾误对已停止 run 调用 cancelBeforeFork，整体失败；E11 未运行。只修驱动收尾状态判断。
- `attempt-3Umldn`：原简化 profile 夹具下 E01–E11 通过；不作为真实 profile 接入依据。
- `profile-build-failure-001`：导入被打包的 node-pty 时找不到相对 native 模块，未执行配置用例；改为对未用的发现分支注入必抛错 stub。不是 PTY 或 SDK 运行证据。
- `{Path(profile['out']).name}`：C01–C04 经实际 AiProfileService／SecretsStore 通过，使用独立 SQLite、假加密器与可控时钟。C03 显式固定同一毫秒，不是概率性压力结果。
- `attempt-ka5VCE`：把真实服务创建的 Claude profile 交给旧候选，E01 复现 TARGET_UNAVAILABLE。属于候选设计缺口；没有把生产代码认定为缺陷。
- `attempt-ZYss9X`：修正后通过，但归档前输入摘要审计发现 receipt 解析器修改后未重建内嵌该解析器的 GC 变体；该次不是最终构建依据。保留 build-refresh-note.json 后重建两个 bundle。
- `{Path(latest['out']).name}`：候选 receipt 改为 v2，分别记录 profileRunner 与能力 runner，通过实际 RunnerAdapterRegistry 映射核验；E01–E11 全部通过。没有实现旧研究 receipt v1→v2 升级。

| 检查 | 证明的局部边界 |
| --- | --- |
| E01 | 无宿主计划拒绝读取／消费；提交后关联实际 v1 业务计划，先接管到实际 run lease，再释放准备 pins |
| E02–03 | pins 后／计划后注入异常均整体回滚；原预留 run 与业务计划保留，尚不能派发；重试合法 |
| E04 | 同运行同计划幂等；换 runtime 拒绝；复制序列化 handle 不能取得私有 owned 权限 |
| E05 | 重算 JSON hash 后替换 binding／run／generation／源／adapter／project 仍被关系检查拒绝 |
| E06 | 夹具 configEpoch 变化拒绝消费，但历史审计可读；未接真实配置版本生成 |
| E07–08 | 合成外部程序文件被替换时拒绝，无 PATH fallback；受管资源不在交付闭包时拒绝，成员齐备后可以解析 |
| E09 | 现有 bindNativeSession 经候选事务投影更新 current revision；两个启动计划及 source 不变 |
| E10 | 真实业务服务：未启用拒绝→启用允许一次合成只读 handler→停用后连缓存重试也拒绝；宿主计划不变 |
| E11 | 未知版本／额外密钥字段拒绝；现有 v1 计划仍由原 reader 读取 |
| C01–04 | 实际配置 runner 映射；更名与启动内容不同步；同毫秒换 Key；缺 Key 拒绝且不回退 |

## 适用范围与未证明事项

run 仍由现有 legacy reserve 创建后以夹具补候选关联，未完成新的 programmatic reserve。配置服务创建与 runner 映射是真实实现；configEpoch 是专门夹具表，未宣称已有正式配置／凭据修订事务。程序、SDK、协议版本均标 `fixture-*`，资源文件仅合成内容，没有执行 Agent、PTY、模型请求或真实业务写入。

候选 dispatch 的消费端是同步断言回调，不是 SDK 启动；私有句柄、现有资源租约、R17 及首次身份关联是真实服务路径或已注明的源码变体。没有将 SDK／app-server、完整启动取消器、全部计划读取方、子能力投影／outbox 接入同一最终协议；外部文件校验到真正 exec 的替换窗口未证明。异常回滚不等于 SIGKILL 恢复，本批未杀宿主。旧数据读取能力不等于已完成生产数据库升级／降级。

T3 本地 `ProviderInstanceConfig` 按 driver 分离私有配置；`ProviderSessionManager` 在 installation gate 内调用 adapter.openSession。此为职责划分参考，T3 没有替 SmartDD 提供 R17、source/current 双修订或新配置 revision 的保证。

## 证据与复跑

[结果](result.json)、[源码依据](source-review.json)、[归档哈希](archive-manifest.json)、[原始代码与数据库](raw-evidence.tar.gz)。当前合计 {len(files)} 个归档文件、{len(dbchecks)} 份 SQLite 校验成功、{len(sources)} 个构建输入摘要复核。最终 11 项运行计划检查与 4 项配置检查分属两个 probe，不能合称一次完整产品测试。

归档包含每次驱动／候选快照和构建后的 actual／candidate／profile CJS；恢复到临时目录并提供记录中的 better-sqlite3／zod 依赖后，运行 `node profile-probe.mjs`、`node probe.mjs`。源码重建另需 build.json 记录的原输入及 raw-import 适配；不要把实验表或变体复制到生产仓库。假密钥仅为显式 synthetic 值，不含用户凭据。
'''
put(exp/'README.md',readme)
section='''### 3.2.10 宿主执行计划与应用运行计划强关联

采用独立的宿主 ExecutionPlan，保持现有 v1 ApplicationRunPlan 的业务加载审计职责。前者以严格、版本化结构关联 task／project、binding、能力会话、固定启动源、run／generation、目标配置修订、适配器及运行程序身份、applicationPlanHash、delivery receipt／hash。SDK／原生版本只用于匹配已验证组合，不能替代协议能力检查。真实凭据及完整环境不写入计划；公开诊断只展示允许的来源和版本信息。

[独立关联实验](实验/20261114_宿主运行计划与现有业务关联验证/README.md)在实际 v3 会话、v1 计划、run 所有权和资源库上验证上述核心关联。读取器不能只验 JSON hash：还要从当前 store 核对同一 run、binding、源 revision、receipt、业务计划及适配器。重算 hash 不授权跨身份串用。历史读取与执行许可分别处理，配置失效不使历史审计不可读；序列化对象不能重建进程内 owned 执行句柄。

准备事务将执行计划与交付 pins 一起提交，派发门禁必须检查该提交。原注册器可以先产生 preparing／prepared run 和 v1 业务计划，但在新计划缺失时不得 fork；失败保留可取消／恢复的预留身份，不能按旧 prepared 状态直接继续。接管先形成实际运行租约成员，再释放准备占用；真正原生派发还须通过 §3.3 的同步门禁／attach／退出规则。本批两处异常回滚已验证，没有用异常回滚冒充宿主中断验证。

配置身份必须分层：现有 AiProfileService 的 runner `claude` 经 RunnerAdapterRegistry 映射为能力 agentId `claude-code`，不能对二者裸字符串相等；未来 SDK driver 再由明确的适配注册项解析。这个差异已使早期候选在真实 profile 下失败，候选分别保存并核对两个身份后通过。不要为迁移把旧配置行批量改成能力层名称。

配置修订不得仅复用 updatedAt：实际服务更名也更新时间，同一毫秒的换 Key 可以留下相同时间。目标方案使用宿主维护的单调执行配置修订／凭据版本，覆盖影响执行的命令、参数、环境、账号和来源变化；名称／颜色变动独立处理。现有 launchSignature 可作内部启动内容比较依据，但它基于解密值，不原样作为公开审计／导出字段。缺 Key、commandPending、配置删除与能力不支持在消费前重新检查；外部配置文件的变动也需要来源指纹／失效规则，不能被数据库 revision 替代。本批实际服务已证实时间戳反例，完整 revision 生成与密钥提交事务仍待验证。

R17 不从宿主计划冻结业务权限。应用启用、停用及当前绑定按原业务服务逐次复核；当前业务视图的 planHash 可以与最初 applicationPlanHash 不同，二者各自标明用途。实际 ToolService 已验证启用后调用、停用后拒绝缓存重试，启动记录未改写。原 diagnostics 的直接 SQL、Skill 输入来源、适配器加载和其他业务读者须逐一决定读启动审计还是当前授权；不得把所有读者一律重定向到新 JSON。

受管程序必须处于精确交付资源闭包；用户指定程序仅记录并校验身份，不获得宿主删除权。内容校验不能证明外部文件在校验到 exec 之间不变；新 launcher 与安装协调的联合验证仍需覆盖该窗口。T3 的 instance／driver 分层与 installation gate 可供参考，其机制不能代替 SmartDD 的持久引用和业务授权。

本批最终运行计划 11 项及真实配置服务 4 项为独立局部证据，未启动 Agent。配置 epoch、程序版本／文件、消费回调仍有明确夹具；实际 programmatic reserve、launchId 拆分、SDK／app-server 消费、所有读取方以及旧研究 Schema 升级尚未贯通，不把该候选标为完整运行协议已定稿。

'''
rel=base/'技研/技术方案.md'
def tech(t):
 old='新的宿主 ExecutionPlan 可独立强关联现有 v1 应用计划摘要，避免把业务允许表和运行身份混成一张任意 JSON；该候选取舍仍需完整 Schema／原子存储与所有读取方的实证，不能视为本批已经完成。'
 new='新的宿主 ExecutionPlan 独立强关联现有 v1 应用计划摘要，避免把业务允许表和运行身份混成一张任意 JSON；核心关联与原子存储已取得 §3.2.10 的限定证据，完整协议及所有读取方仍须验证。'
 assert t.count(old)==1;t=t.replace(old,new);assert t.count('### 3.3 真实所有权')==1;return t.replace('### 3.3 真实所有权',section+'### 3.3 真实所有权')
edit(rel,tech)
ledger='''### 4.41 宿主计划与业务计划关联、真实配置反例

[关联实验](实验/20261114_宿主运行计划与现有业务关联验证/README.md)最终 E01–E11 验证候选 ExecutionPlan 与实际 v1 应用计划、run／binding／源 revision／receipt 的强关联，同事务 pins 与 plan 回滚、复制句柄拒绝、运行租约接管、首次 native ID 不改源、R17 按当前启停授权及未知版本拒绝。消费端为同步夹具，不是 SDK／app-server；configEpoch 为夹具，真实 programmatic reserve／所有读取方仍未贯通。

C01–C04 另经实际 AiProfileService／SecretsStore 证实：profile runner claude 与 agentId claude-code 必须映射；更名更新时间但启动签名不变；固定同一毫秒时换 Key 可不改 updatedAt；缺 Key 拒绝。用真实 profile 替代简化夹具时旧候选实际报 TARGET_UNAVAILABLE，修正为分别记录和映射两个身份后重跑全部 E 项通过。单调执行配置修订及其与凭据的原子性仍待设计验证，不能将夹具 epoch 当作现有实现。

保留初轮重复取消导致的收尾失败、原简化夹具绿测、node-pty 导入夹具失败、真实 profile 下红测及最终结果，不按重复执行累计。T0.1 §3.2.10 固化职责和失败边界；Q06／Q13／Q20 保持部分。本批仅技术研究，没有产品开发或产品验收。

'''
def ledger_edit(t):
 assert t.count('## 5. 失败与驱动修正')==1;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 old='§4.40 复现首次 native ID 与候选外键冲突并补源／当前修订分离；下一步优先收口'
 new='§4.40 复现首次 native ID 与候选外键冲突并补源／当前修订分离；§4.41 补宿主计划关联及实际配置标识／时间戳反例；下一步优先收口'
 assert old in t;t=t.replace(old,new)
 for q,tail in [('Q06','§4.41 补实际配置服务的同毫秒换 Key／时间戳反例，执行配置修订生成仍待验'),('Q13','§4.41 补宿主计划与实际 v1 应用计划／run／交付的核心关联和原子准备；完整原生消费及全部读者仍待验'),('Q20','§4.41 复现真实 profile runner 与能力 agentId 裸比较导致误拒绝，映射候选修正通过；完整配置版本／fork 竞争待验')]:
  lines=t.splitlines();idx=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[idx]=lines[idx][:-2]+'；'+tail+' |';t='\n'.join(lines)+'\n'
 return t
edit(base/'技研/全局设计验证账.md',ledger_edit)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：宿主运行计划与现有业务计划的核心关联、原子准备及实时业务权限已有局部证据；接入真实配置服务又发现 runner 标识映射和 updatedAt 不能作为配置版本的边界，已纳入[技术方案 §3.2.10](技研/技术方案.md)。完整程序化启动与所有业务读取方仍待收口。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbchecks),'sources':len(sources),'archiveBytes':(root/'raw-evidence.tar.gz').stat().st_size}))
