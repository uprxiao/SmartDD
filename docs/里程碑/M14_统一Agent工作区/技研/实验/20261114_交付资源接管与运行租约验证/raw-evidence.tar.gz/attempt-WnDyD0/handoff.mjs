import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
const owned=new WeakMap();
export async function withDelivery(store,taskId,resourceId,work){
 const id=randomUUID();return store.use(resourceId,'m14-delivery-probe',id,async directory=>{
  const proof=await actual.withResourceLock(store.root,()=>{
   const lease=store.sqlite.prepare("SELECT * FROM capability_resource_leases WHERE owner_id=? AND owner_kind='m14-delivery-probe' AND state='active'").get(id);assert(lease);
   const ids=store.sqlite.prepare('WITH RECURSIVE needed(id) AS (VALUES(?) UNION SELECT d.dependency_id FROM capability_resource_dependencies d JOIN needed n ON d.resource_id=n.id) SELECT id FROM needed ORDER BY id').all(resourceId),resources=ids.map(({id})=>store.get(id));
   for(const r of resources)assert(r.pathScope==='C'&&r.state==='ready'&&r.integrity==='valid');
   return{store,taskId,resourceId,lease,resources,live:true,adopted:null};
  });
  const token=Object.freeze({id,directory});owned.set(token,proof);
  try{return await work(token);}finally{proof.live=false;owned.delete(token);}
 });
}
export async function adopt(token,runs,run,{fault=false}={}){
 const p=owned.get(token);assert(p?.live,'DELIVERY_HANDLE_INVALID');assert.equal(runs.store,p.store,'STORE_MISMATCH');
 const result=await actual.withResourceLock(p.store.root,()=>p.store.sqlite.transaction(()=>{
  actual.assertOwnedCapabilityRun(runs,run);const context=runs.bridgePreparation(run.runId);assert.equal(context.run.taskId,p.taskId,'TASK_MISMATCH');
  if(p.adopted)assert.equal(p.adopted,run.runId,'ALREADY_ADOPTED');
  const source=p.store.sqlite.prepare('SELECT * FROM capability_resource_leases WHERE lease_id=?').get(p.lease.lease_id);assert(source.state==='active'&&source.owner_id===token.id&&source.host_instance_id===p.store.instanceId,'DELIVERY_LEASE_CHANGED');
  const target=p.store.sqlite.prepare("SELECT * FROM capability_resource_leases WHERE owner_kind='run' AND owner_id=? AND host_instance_id=? AND state='active'").get(run.runId,runs.instanceId);assert(target,'RUN_LEASE_UNAVAILABLE');
  for(const previous of p.resources){const current=p.store.get(previous.resourceId);assert(current.state==='ready'&&current.integrity==='valid'&&current.generation===previous.generation&&current.contentHash===previous.contentHash&&current.relativePath===previous.relativePath,'RESOURCE_CHANGED');
   const old=p.store.sqlite.prepare('SELECT * FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').get(target.lease_id,current.resourceId);if(old)assert(old.content_hash===current.contentHash&&old.generation===current.generation,'LEASE_RESOURCE_CONFLICT');else p.store.sqlite.prepare('INSERT INTO capability_lease_resources VALUES(?,?,?,?)').run(target.lease_id,current.resourceId,current.contentHash,current.generation);
  }
  if(fault)throw Error('fixture-adoption-rollback');
  actual.assertOwnedCapabilityRun(runs,run);return{runId:run.runId,leaseId:target.lease_id,resourceIds:p.resources.map(r=>r.resourceId),preparationLease:p.lease.lease_id};
 }).immediate());p.adopted=run.runId;return result;
}
