from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_邮件实际入口上下文与在途取消验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==8 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
resources=[repo/'scripts/applications/build-bundles.mjs',repo/'scripts/applications/verify-bundles.cjs',repo/'resources/applications/definitions.mjs']
for name in ['resources/applications','resources/agent-adapters']:resources.extend(p for p in (repo/name).rglob('*') if p.is_file())
resources=list(dict.fromkeys(resources))
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'actualServices':['ApplicationService','ApplicationExecutionContexts','MailSendDataService','MailUserAuthorizations','MailSenderIdentity','ApplicationToolService','CapabilityRunRegistry'],'sourceInputs':b,'resourceInputs':[{'path':str(p.relative_to(repo)),'sha256':sha(p.read_bytes())} for p in resources],'fixtureDistribution':{'sourceMode':'retained-v1-test-fixture','index':json.loads((root/'bundles/index.json').read_text()),'adaptation':'Copied build-bundles script only rewrites module import paths and uses test no-execution bridge hash; original application definitions, adapters and resources retained. No actual MCP bridge or native agent executes.'},'controlled':['SecretCipher','renderer event and trust predicate','FixtureProcessReader with controlled active PIDs','MailExecutionOptions.submit'], 'network':'One actual SMTP verify authentication against owned 127.0.0.1 server per successful setup; server rejects DATA; no external address connection','failureClassification':{'attempt-xxoXkH':'environment: sandbox refused loopback listen before checks','attempt-Ctc88c':'driver assertion: expected REVISION_CONFLICT but management proactively invalidates context; source confirms CANCELED, consumed handle then SCOPE_DENIED','bootstrap-warning':'CJS import.meta.url warning before execution; define fixed file URL for createRequire in isolated bundle'},'findings':['Real opaque context and actor lifecycle reject copies and expired references.','Mail identity preflight runs before preparation; final credential handles recheck and are one-use even on rejection.','UI approval for agent intent remains tied to original run; another run or exited origin cannot consume it.','Actual run may be stopped while independent mail-send activity lease is active; producer drain releases lease without rewriting unknown.'],'limits':['No real Electron sender or human approval','No native user-message observation, programmatic input ledger, private MCP transport or SDK in this run','Retained v1 test distribution, not complete default v2 packaged-resource integration','No dynamic native descendants, full launch-admission race/crash or product UI acceptance']}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(root/'bootstrap-warning/README.txt').write_text('Initial CJS build emitted import.meta unavailable warning in AgentAdapterRegistry createRequire; no probe ran with that bundle. The next build defines import.meta.url to an isolated file URL. Source snapshot/build manifest retained; no product edit.\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','build-fixture-bundles.mjs','no-execution-bridge.cjs','probe.mjs','audit.json','source-review.json','prepare.py']]
for d in [root/'bootstrap-warning',root/'bundles',*sorted(root.glob('attempt-*'))]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts)
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 邮件实际入口、上下文与在途取消验证

日期：2026-11-14。D04，关联 Q09／Q12／Q17／Q41／Q49。承接 §4.100 服务基线，这次将实际 ApplicationService、ApplicationExecutionContexts、MailSendDataService、MailUserAuthorizations、MailSenderIdentity、ToolService 和运行注册器放在同一隔离库中。最终 attempt-PhjrjA 八项通过。

## 边界与准备

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，构建 677 条输入摘要已复核。没有产品源码变更。实际连接测试只向本次持有的 127.0.0.1 SMTP 替身发一次认证；服务器拒绝 DATA，发送执行改用受控函数，三次受控 submit 不发送真实邮件。

当前源码的 retained-v1-test-fixture 定义、资源与适配器通过原构建脚本的临时副本生成。该副本只替换导入位置和测试 bridge hash；bridge 内容为立即抛错，禁止执行。实际 BuiltinPackageRegistry 验证并安装测试分发；不是默认 v2 分发／实际 MCP 传输证明。SecretCipher、renderer event／trust predicate、进程身份 reader 为夹具；run 状态变更、业务上下文、权限与凭据句柄、邮件准备／授权／执行逻辑均为当前实际实现。没有真实 Electron 页面、真人批准、原生 Agent 或模型请求。

## 八项检查

| 检查 | 实际结论 |
| --- | --- |
| E01 发件身份 | 未确认身份的 UI 准备在创建 intent 前拒绝；通过实际 projectAction 确认后继续，不能把选择 SMTP 等同于身份确认 |
| E02 不透明身份 | 克隆 context／actor 均拒绝；实际 withUi 返回后原 context／actor 也失效，持久 ID 或 JSON 不能代替当前宿主签发对象 |
| E03 UI 审阅 | 错 frame 拒绝，真实服务消费 display receipt，原 intent 只受控提交一次；重复执行返回同 execution，subject 关系由实际业务写入 |
| E04 Agent 入口 | 实际 ToolService 创建草稿／准备意图、UI 审阅授权；另一 run 执行被拒绝，原 run 执行一次。通用调用／Data API 同 operationId 与 run 关联，targets 固定实际 SMTP 来源 |
| E05 撤销后恢复 | 审阅后停用连接拒绝执行，再启用也不能恢复旧 grant，不改选其他账号 |
| E06 凭据句柄 | 连接管理主动使已固定上下文取消；旧句柄消费 CANCELED，第二次 SCOPE_DENIED，失败也消耗句柄，不返回 secret |
| E07 来源已退出 | 已显示的 Agent 意图在来源 run 退出后不能再授权，未生成 active grant 或发送 |
| E08 在途取消 | run 停止且受控 CLI 退出后运行账为 stopped，未返回的 submit 仍持独立 mail-send active 租约。实际服务排空后租约 released；外部结果继续 unknown，迟到成功不改写、不重发 |

E08 用 Promise 事件门闩观察进入／完成，不以睡眠判断状态。最终四个 run 全 stopped、47 份资源租约全 released，SQLite 完整性与外键通过。所有尝试均已核对运行停止、租约释放，回环服务器通过本次持有的 handle 关闭。

## 失败与修正

- 首次构建 CJS 的 import.meta.url 警告会影响 createRequire；在执行前用隔离 file URL 定义修正，保留初始构建脚本与摘要。
- attempt-xxoXkH 在 sandbox 监听 EPERM，零检查／零认证／零提交；通过工具批准执行同一回环实验后 attempt-afgCqj 五项通过。
- 扩展后的 attempt-Ctc88c 在 E06 失败：驱动预期 REVISION_CONFLICT，但实际管理入口先 contexts.invalidate，因此消费得到 CANCELED。核对 management／record／CredentialHandles 源码后修正精确预期，并新增第二次消费拒绝；没有放宽成“任意错误均通过”。旧失败保留。
- E08 的准备假设曾把邮件活动等同 run counter；源码显示 retainSendActivity 使用独立 ResourceStore.use，所以在执行该分支前改为直接核对 mail-send 租约与原结果。最终观测明确记录 run stopped／mail lease active，而非宣称 run 一直 stopping。

## 设计影响与未验项

统一层只提交任务、动作和审阅引用；实际运行与业务入口重新签发上下文，不从序列化 context、Agent 输出或父任务身份授予权限。发件身份预检、原 intent／run、display receipt、最终来源／凭据消费分别保留，不合并为 approved 布尔值。失效上下文的 CANCELED 是调用状态，不能据此判定外部副作用未发生。

运行、mail-send 等业务租约和结果账是三个事实来源。迁移／交接要按真实业务范围核对独立活动，不能把 run stopped 当成全部业务排空；未决结果对账和活动释放也不能混用。

仍待验证默认 v2 分发及当前程序化新入口／原生用户来源／私有 MCP 与上述服务的联合、跨对象最小限制、所有写入口协调与恢复；真实 UI、真实账号和安装包留在产品阶段。本轮不增加正式产品通过数。

复现：具备 build.mjs 固定依赖后执行构建；在 SmartDD cwd 运行归档的 build-fixture-bundles.mjs 生成私有测试分发，再执行 probe.mjs。回环监听需环境允许；不需要外部账号。见[结果](result.json)、[来源与替身清单](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
needle='### 9.3 子运行的插件审批与统一请求入口'
add='''**实际入口合同。** [八项宿主入口实验](实验/20261114_邮件实际入口上下文与在途取消验证/README.md)已把当前 ApplicationService／ToolService、真实业务上下文、发件身份与审阅授权服务接到同一隔离库。Driver／UI 传入动作与原引用，宿主按当前 run 和调用来源签发不透明 context／actor；这些对象不能序列化传输、从历史恢复或在操作结束后复用。另一 run、已退出的来源 run 和错窗口不能消费原邮件授权。发件身份确认早于 intent 准备，最终凭据句柄在消费时重核且失败也不能再次使用；连接恢复可用不复活旧批准。当前证据使用受控进程身份、renderer 事件和禁止执行桥的 retained-v1 测试分发，默认 v2／实际原生来源与新入口联合仍待验。

**独立业务活动不能从 run 状态推断。** 实际 retainSendActivity 使用独立 mail-send 资源租约；实验已观测 run stopped 时该租约仍 active，直至底层发送 Promise 排空。最终交接同时核对相关运行／后台范围、业务活动与业务结果，按对象／项目限制关联动作，不以一个全局 busy 标志误挡无关任务。连接管理主动取消失效上下文，CANCELED 不表示副作用未发生；独立活动排空也不能覆盖原 unknown。App 关闭等待业务生产者退出的行为须保留，迁移不能绕过这一等待只销毁 SDK 会话。

'''
assert needle in t;t=t.replace(needle,add+needle,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.101 ' not in t
add='''### 4.101 邮件实际入口、上下文与在途取消

[八项实际宿主入口检查](实验/20261114_邮件实际入口上下文与在途取消验证/README.md)将 ApplicationService／ExecutionContexts／MailSendDataService／MailUserAuthorizations／MailSenderIdentity／ToolService 与运行注册器接到同库。发件身份预检、context／actor 不可克隆或过期复用、错窗口／另一 run／已退出来源拒绝、旧批准不随连接恢复、最终凭据句柄一次消费均通过；通用调用与 Data API 由实际服务写入同 operationId／run 和来源 targets。

在途取消实测 run stopped／mail-send lease active 同时成立，服务排空后租约才 released；迟到成功不改原 unknown。最终四 run stopped、47 租约 released，完整性／外键通过。使用受控 renderer／进程身份、retained-v1 禁止执行桥分发和发送替身；一次本机 SMTP 验证认证、三次受控 submit、零 DATA／原生 Agent／真实邮件。保留监听 EPERM 与 E06 驱动误期望 REVISION_CONFLICT 的失败；按实际主动失效链修正为 CANCELED 并验证再次消费拒绝。默认 v2／程序化原生来源／私有桥联合、全入口准入与恢复仍未关闭；设计 §9.2.2／后续 A41 已合并。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| D04 '):
  cols=line.split('|');cols[2]=' §4.99–101 已补候选汇总、实际活动／邮件回执／核实与真实宿主上下文入口；run stopped 不代表独立业务租约释放。下一步把默认 v2／当前程序化新入口的原生输入来源和私有桥接到同一业务链，复用原审批、来源和资源约束；再与 D01 同库准入联合，验证关联对象范围、提交后变化、业务租约／结果修订和崩溃恢复。既有插件／浏览器证据按边界复用，清理覆盖与大库查询另验 ';lines[i]='|'.join(cols)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.100，56','截至 §4.101，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('最新进展：'):lines[i]='最新进展：八项邮件实际宿主入口检查通过，补齐业务上下文、发件身份、原运行授权与独立发送活动的保留合同；run stopped 时邮件租约仍可能 active。见[实验记录](技研/实验/20261114_邮件实际入口上下文与在途取消验证/README.md)；仍是独立研究，统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if line.startswith('下一步：'):lines[i]='下一步：按[验证账 D04](技研/全局设计验证账.md#71-当前全局收口方式)联合默认 v2／程序化入口、原生输入来源与私有业务桥，并接同库准入／对象范围／恢复。已有服务和局部证据复用，真实 UI／安装验收留在产品阶段。'
put(rel,'\n'.join(lines)+'\n')
rel=base/'验收/测试用例.md';t=(repo/rel).read_text();start=t.index('### M14-A41 ');end=t.index('<a id="m14-a42">',start);s=t[start:end]
s=s.replace('核实后修改来源关联或提交另一窗口的矛盾决定。','核实后修改来源关联或提交另一窗口的矛盾决定；发送生产者仍未返回时停止来源 run，核对独立 mail-send 活动直至排空；连接变更后消费已固定凭据句柄。',1)
s=s.replace('不凭当前页或展示合并判定可继续执行。','不凭当前页或展示合并判定可继续执行；run stopped 不代替业务租约排空，迟到结果不覆盖 unknown；句柄消费前重核，失败后不得再次消费，连接恢复不复活旧授权。',1);t=t[:start]+s+t[end:];put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size},ensure_ascii=False))
