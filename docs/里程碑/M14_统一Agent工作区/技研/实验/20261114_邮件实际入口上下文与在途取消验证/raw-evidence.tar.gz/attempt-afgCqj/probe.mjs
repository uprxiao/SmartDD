import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createServer} from 'node:net';
import {EventEmitter} from 'node:events';
import {mkdtempSync,mkdirSync,writeFileSync,copyFileSync,cpSync} from 'node:fs';
import Database from 'better-sqlite3';
import a from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
for(const n of ['probe.mjs','build.mjs','build.json'])copyFileSync(root+'/'+n,out+'/'+n);
const checks=[],owned=[],sockets=new Set();let error,db,app,runs,server,reader,submissions=0,authentications=0,unexpectedData=0,submitBehavior;
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});save(id+'.json',evidence);}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
try{
 db=new Database(out+'/state.sqlite');db.pragma('foreign_keys=ON');a.runBundledMigrations(db);const store=new a.ResourceStore(db,out+'/capabilities'),secrets=a.makeSyntheticSecrets(db),projects=new a.ProjectService(a.drizzle(db,{schema:a.schema}),secrets),project=projects.createProject({name:'Isolated mail entry',aliases:[],description:'',rulesPath:null});
 const projectId=project.id,source=new a.CapabilityBundleSource(root+'/bundles');await new a.RuntimeRegistry(store).install(source.runtime());const trusted=new a.BuiltinPackageRegistry(store),pack=await trusted.install(source,source.index.apps.find(p=>p.appId==='mail'));await trusted.packages.activate(pack.packageHash,0);
 reader=new a.FixtureProcessReader();const wc=Object.assign(new EventEmitter(),{id:101,mainFrame:{processId:9,routingId:1},isDestroyed:()=>false}),sender={sender:wc,senderFrame:wc.mainFrame};
 const requireSender=s=>{if(s.sender!==wc||s.senderFrame!==wc.mainFrame)throw Error('Untrusted fixture window');};
 submitBehavior=(_c,_s,m)=>({state:'server-accepted',complete:true,accepted:m.envelope.to,rejected:[],errorCode:null,smtpCode:250,messageId:m.messageId});
 app=new a.ApplicationService(store,{secrets,projects,tasks:{stopProject:async()=>true,runningInProject:()=>0},requireSender,mailWorker:out+'/unused-mail-worker',foxmailNative:out+'/unused-foxmail',processes:reader,mailSend:{submit:async(...args)=>{submissions++;return submitBehavior(...args);}}});await app.recover();
 server=createServer(socket=>{sockets.add(socket);socket.on('error',()=>{});socket.on('close',()=>sockets.delete(socket));socket.write('220 isolated verification only\r\n');let buffer='';socket.on('data',bytes=>{buffer+=bytes.toString();while(buffer.includes('\r\n')){const n=buffer.indexOf('\r\n'),line=buffer.slice(0,n);buffer=buffer.slice(n+2);if(line.startsWith('EHLO'))socket.write('250-local\r\n250 AUTH PLAIN\r\n');else if(line.startsWith('AUTH PLAIN ')){authentications++;socket.write('235 ok\r\n');}else if(line==='QUIT')socket.end('221 bye\r\n');else{if(line==='DATA')unexpectedData++;socket.write('500 no messages accepted\r\n');}}});});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const tested=await app.testConnection(sender,{name:'Loopback verification',expectedRevision:0,config:{kind:'smtp',host:'127.0.0.1',port:server.address().port,username:'sender@example.test',fromAddress:'sender@example.test',authMode:'password',mode:'plain'},secret:'public-fixture-secret'}),smtp=await app.saveConnection(sender,'mail',tested.operationId,tested.candidateHash);
 await app.setAdded(sender,'mail',true,app.selections.catalogState('mail').revision);await app.select(sender,{projectId,appId:'mail',enabled:true,expectedRevision:app.selections.projectSettings(projectId,'mail').revision,connections:{foxmail:null,smtp:smtp.id}});
 const content={mode:'new',sourceMessageRef:null,senderConnectionId:null,to:['receiver@example.test'],cc:[],bcc:[],subject:'Synthetic only',text:'Public synthetic body',html:null,inReplyTo:null,references:[],attachmentIds:[]};
 const draft=async()=> (await app.contexts.withUi(sender,{projectId,appId:'mail',action:'ui.mail.draft.create',operations:['mail.draft'],semantics:'write'},context=>app.capabilities.forUi(context,'mail.draft.create',{content}))).draft;
 const prepare=async()=>{const d=await draft();return(await app.prepareSend(sender,projectId,{draftId:d.id,expectedRevision:d.revision,expectedContentHash:d.contentHash})).intent;};
 const confirm=async intent=>{const shown=await app.reviewSend(sender,projectId,intent.id);return app.authorizeSend(sender,projectId,{intentId:intent.id,expectedReviewHash:intent.reviewHash,displayReceiptId:shown.displayReceiptId,reviewedUnknownExecutionIds:[]});};
 const execute=intent=>app.executeSend(sender,projectId,{intentId:intent.id,expectedReviewHash:intent.reviewHash});
 await check('E01','actual sender identity preflight rejects before user confirmation',async()=>{
  const d=await draft();await assert.rejects(app.prepareSend(sender,projectId,{draftId:d.id,expectedRevision:d.revision,expectedContentHash:d.contentHash}),{code:'SENDER_IDENTITY_REQUIRED'});
  assert.equal(db.prepare('SELECT count(*) n FROM mail_send_intents').get().n,0);assert.equal(submissions,0);
  const status=await app.projectPolicy(sender,projectId,'mail');assert(status.canConfirm);await app.projectAction(sender,projectId,'mail',{action:'confirm-sender',arguments:{expectedBindingHash:status.bindingHash,confirmed:true}});
  return{preflightRejectedBeforeIntent:true,confirmedThroughActualProjectAction:true,realUser:false};
 });
 await check('E02','host-issued contexts and actors cannot be serialized or reused after return',async()=>{
  let savedContext,savedActor;await app.contexts.withUi(sender,{projectId,appId:'mail',action:'ui.mail.fixture',operations:['mail.draft'],semantics:'read'},async c=>{savedContext=c;savedActor=app.contexts.actor(c);assert.throws(()=>app.contexts.actor({...c}),{code:'SCOPE_DENIED'});assert.throws(()=>app.drafts.list({...savedActor}),{code:'SCOPE_DENIED'});});
  assert.throws(()=>app.contexts.assertActive(savedContext),{code:'SCOPE_DENIED'});assert.throws(()=>app.drafts.list(savedActor),{code:'SCOPE_DENIED'});
  return{clonedContextDenied:true,clonedActorDenied:true,expiredContextAndActorDenied:true};
 });
 await check('E03','actual review receipt is window-bound and sending succeeds once',async()=>{
  const intent=await prepare(),shown=await app.reviewSend(sender,projectId,intent.id),args={intentId:intent.id,expectedReviewHash:intent.reviewHash,displayReceiptId:shown.displayReceiptId,reviewedUnknownExecutionIds:[]};
  await assert.rejects(Promise.resolve().then(()=>app.authorizeSend({...sender,senderFrame:{...sender.senderFrame}},projectId,args)));
  await app.authorizeSend(sender,projectId,args);const before=submissions,sent=(await execute(intent)).intent;assert.equal(sent.state,'server-accepted');assert.equal((await execute(intent)).intent.executionId,sent.executionId);assert.equal(submissions,before+1);
  const subjects=db.prepare("SELECT kind,subject_id FROM application_activity_subjects WHERE kind='mail-send' AND subject_id=?").all(intent.id);assert(subjects.length>0);
  return{wrongFrameDenied:true,executionId:sent.executionId,submissions:1,actualSubjectLinks:subjects.length};
 });
 const adapters=new a.AgentAdapterRegistry(store),adapterSource=source.adapters().find(x=>x.metadata.agentId==='claude-code'&&x.metadata.version==='1.2.0'),adapter=await adapters.install(adapterSource.metadata,adapterSource.files),home=out+'/agent-home',cwd=out+'/project';mkdirSync(home);mkdirSync(cwd);
 const sessions=new a.CapabilitySessionRegistry(store,{assertInitialSelection:s=>{assert.equal(s.packages[0].packageHash,pack.packageHash);},verifyExtraResource:(r,s)=>adapters.verifyReference(r,s)});
 runs=new a.CapabilityRunRegistry(store,sessions,{processes:reader,assertCurrent:()=>{},revoke:()=>{}});app.attachRuns(runs);const tools=new a.ApplicationToolService(store,runs,new a.ApplicationAdapterRegistry(store,app.data),{retryDelays:[0,0]});
 const start=async pid=>{const taskId=randomUUID(),name=a.applicationMcpServerName(a.digest(taskId)),manifest=pack.manifest,decls=a.applicationToolDeclarations(manifest);const snap={schema:2,taskId,projectId,runner:'claude-code',createdAt:new Date().toISOString(),native:{sessionId:null,stateRoot:home+'/.claude',cwd},adapterBinding:{id:'claude-code',version:adapter.metadata.version,hash:adapter.hash,projectionFormatVersion:1,nativeToolNames:Object.fromEntries(decls.map(t=>[t.name,'mcp__'+name+'__'+t.name]))},agentAtCreation:{version:adapter.metadata.cliVersions[0],adapterRevision:1},catalogGeneration:'research-only',packages:[{appId:'mail',version:pack.version,packageHash:pack.packageHash,hashAlgorithm:'app-manifest-v1',hostApi:manifest.hostApi,dataApi:1,runtimeHash:manifest.runtime.hash,toolContractMajors:Object.fromEntries(decls.map(t=>[t.name,t.contractMajor])),skills:manifest.skills.map(skill=>{const native=a.applicationNativeSkillName('mail',skill.id,pack.packageHash);return{skillId:skill.id,nativeName:native,contentHash:a.applicationSkillContentHash(manifest,skill.path),sourceRelativePath:skill.path,projectionPath:store.root+'/sessions/'+taskId+'/claude/plugin/skills/'+native+'/SKILL.md'};}),bindings:[],allowedOperations:manifest.permissions}],standardSkills:[],mcp:[{kind:'applications',serverName:name,protocolMajor:1,runtimeHash:manifest.runtime.hash}],provenance:'created'};
  const session=await sessions.create(snap,home),run=await runs.reserve({taskId,snapshotHash:session.pointer.snapshotHash,bindings:[]});owned.push({run,pid});await run.prepare();await run.cli.arm();reader.identities.set(pid,'darwin-proc-v1:2026:'+pid);await run.cli.attach(pid);return run;};
 const one=await start(99101),two=await start(99102);
 const call=(run,op,args,id=randomUUID())=>tools.call(run.runId,id,{operation:'smartdd_mail_'+op+'_v1',contractMajor:1,connectionId:null,arguments:args});
 const ok=r=>{assert.equal(r.status,'ok',JSON.stringify(r));return r.value;};
 await check('E04','agent run preparation and UI authorization retain exact originating run',async()=>{
  const d=ok(await call(one,'draft_create',{content})).draft,intent=ok(await call(one,'send_prepare',{draftId:d.id,expectedRevision:d.revision,expectedContentHash:d.contentHash})).intent;
  const denied=await call(one,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash});assert.notEqual(denied.status,'ok');await confirm(intent);
  const before=submissions,other=await call(two,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash});assert.notEqual(other.status,'ok');assert.equal(submissions,before);
  const sent=ok(await call(one,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash})).intent;assert.equal(sent.state,'server-accepted');assert.equal(submissions,before+1);save('agent-denials.json',{denied,other});
  const rows=db.prepare('SELECT o.operation_id,o.run_id,o.targets_json,v.run_id AS invocation_run FROM application_data_operations o JOIN application_invocations v ON v.operation_id=o.operation_id WHERE o.run_id=?').all(one.runId);assert(rows.length>=3);assert(rows.every(r=>r.run_id===r.invocation_run));assert(rows.some(r=>JSON.parse(r.targets_json).some(t=>t.id===smtp.id)));
  return{otherRunDenied:true,originalRunSucceeded:true,realContextAndToolService:true,processIdentity:'controlled fixture, no native process',linkedOperationRows:rows.length};
 });
 await check('E05','connection revocation after review prevents execution and does not switch accounts',async()=>{
  const intent=await prepare();await confirm(intent);const c=app.connections.get(smtp.id);await app.setConnectionEnabled(sender,smtp.id,false,c.revision);const before=submissions;await assert.rejects(execute(intent));assert.equal(submissions,before);
  const disabled=app.connections.get(smtp.id);await app.setConnectionEnabled(sender,smtp.id,true,disabled.revision);await assert.rejects(execute(intent));assert.equal(submissions,before);
  return{disabledRejected:true,reenableDoesNotRestoreOldGrant:true,noFallbackConnection:true};
 });
 assert.equal(unexpectedData,0);
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 for(const x of owned){reader.identities.delete(x.pid);try{await x.run.cli.exited();}catch{}}
 if(app)await app.dispose();if(runs)await runs.dispose();for(const s of sockets)s.destroy();if(server?.listening)await new Promise(resolve=>server.close(resolve));
 if(db){save('terminal.json',{runs:db.prepare('SELECT run_id,state FROM capability_runs').all(),leases:db.prepare("SELECT state,count(*) n FROM capability_resource_leases GROUP BY state").all()});assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);await db.backup(out+'/final.sqlite');db.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:error??null,submissions,authentications,unexpectedData,scope:'Actual ApplicationService, execution contexts, mail preflight/authorization/data/ToolService. Synthetic cipher and renderer event; controlled ProcessIdentityReader, no native agent. Loopback SMTP verifies credentials only; submit is controlled function; synthetic trusted distribution uses non-executing bridge. No product edits.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,error:result.error,submissions,authentications}));
