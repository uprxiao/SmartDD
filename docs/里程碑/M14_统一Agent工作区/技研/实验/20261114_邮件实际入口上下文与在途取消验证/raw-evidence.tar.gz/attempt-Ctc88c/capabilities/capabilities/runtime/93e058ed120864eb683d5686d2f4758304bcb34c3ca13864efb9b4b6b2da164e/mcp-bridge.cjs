throw new Error('Research bridge must never execute');
