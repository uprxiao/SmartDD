from pathlib import Path
import json,hashlib,tarfile,re,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');stage=root/'publication';sha=lambda b:hashlib.sha256(b).hexdigest();entries=json.loads((root/'manifest.json').read_text());results={}
for e in entries:
 rel=Path(e['path']);assert rel.is_relative_to('docs/里程碑/M14_统一Agent工作区') and '..' not in rel.parts
 actual=repo/rel;assert (sha(actual.read_bytes())if actual.exists()else None)==e['before'];assert sha((stage/rel).read_bytes())==e['after']
 if rel.suffix=='.md':
  t=(stage/rel).read_text();assert all(l==l.rstrip()for l in t.splitlines()),str(rel)
  for link in re.findall(r'\]\(([^)]+)\)',t):
   link=link.split('#')[0];
   if not link or '://' in link or link.startswith('mailto:'):continue
   target=(stage/rel).parent/link
   if not target.exists():
    relative=target.relative_to(stage);assert (repo/relative).exists(),(str(rel),link)
exp=stage/'docs/里程碑/M14_统一Agent工作区/技研/实验/20261114_原生资源租约与清理计划验证';m=json.loads((exp/'archive-manifest.json').read_text());assert sha((exp/'raw-evidence.tar.gz').read_bytes())==m['archiveSha256']
with tarfile.open(exp/'raw-evidence.tar.gz')as tar:
 for e in m['files']:assert sha(tar.extractfile(e['path']).read())==e['sha256'],e['path']
for n in ['build.json']:
 for s in json.loads((root/n).read_text())['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--','src','prototypes','package.json','pnpm-lock.yaml'],text=True)
assert not subprocess.check_output(['git','-C','/Users/hx/projects/t3code','status','--porcelain'],text=True)
ledger=(stage/'docs/里程碑/M14_统一Agent工作区/技研/全局设计验证账.md').read_text();ids=re.findall(r'^\| (Q\d\d) \|',ledger,re.M);assert len(ids)==56 and len(set(ids))==56
result={'stagedFiles':len(entries),'archiveFiles':len(m['files']),'sqliteVerified':len(m['sqliteIntegrityAndForeignKeys']),'sourceHashesCurrent':True,'localLinks':True,'productAndSharedPrototypeUnchanged':True,'t3Unchanged':True,'QRowsPreserved':56}
(root/'audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
