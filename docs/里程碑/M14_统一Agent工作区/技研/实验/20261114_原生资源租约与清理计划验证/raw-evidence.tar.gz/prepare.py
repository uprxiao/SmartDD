from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生资源租约与清理计划验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==8 and not r.get('error');a=Path(r['out']);b=json.loads((root/'build.json').read_text())
for n in ['build.mjs','build.json','actual.cjs','naive.cjs','candidate.cjs','artifact.mjs','probe.mjs','naive-gc.ts.variant','candidate-gc.ts.variant']:assert (root/n).read_bytes()==(a/n).read_bytes(),n
for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
processes=json.loads((a/'processes.json').read_text());assert len(processes)==2 and all(p['exit']=={'code':0,'signal':None}and not p.get('cleanupKill')for p in processes)
manifest=json.loads(Path('/private/tmp/willyou-m14-package-download-probe/fixtures.json').read_text())['native']['manifest'];main=next(f for f in manifest['files']if f['path']==manifest['entry']);assert main['size']>256*1024*1024
fixture=json.loads((a/'fixture.json').read_text());db=sqlite3.connect('file:'+fixture['db']+'?mode=ro',uri=True);assert db.execute("select count(*) from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;assert db.execute("select count(*) from capability_resource_operations where kind='cleanup-graph'").fetchone()[0]==0
# Verify the complete published native directory independently of the result text.
manifestHash=sha(json.dumps(manifest,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());row=db.execute("select relative_path from capability_resources where resource_id=?",('agent-native-runtime:'+manifestHash,)).fetchone();assert row
for f in manifest['files']:
 p=Path(fixture['storeRoot'])/row[0]/f['path'];h=hashlib.sha256()
 with p.open('rb')as stream:
  for chunk in iter(lambda:stream.read(262144),b''):h.update(chunk)
 assert p.stat().st_size==f['size'] and h.hexdigest()==f['sha256'],f['path']
db.close()
runtime={'attempt':a.name,'processes':processes,'processesExited':2,'remainingRunLeases':0,'cleanupOperationsCreated':0,'nativeFilesVerified':41,'nativeMainBytes':main['size'],'currentGcFileLimitBytes':256*1024*1024,'paidModelTurns':0,'scope':'native-only lifecycle guard; real Codex initialize only; planner candidates, no deletion; unknown identity case uses FixtureProcessReader'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/run-recovery.ts',repo/'src/main/core/applications/resource-gc-plan.ts',repo/'src/main/core/applications/resource-gc-tree.ts',repo/'src/main/core/applications/resource-graph-maintenance.ts',t3/'apps/server/src/provider/CodexInstallation.ts'];review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(b['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'variants':b['outputs'],'sourceFindings':['Current planner accepts application-package root only and does not read capability_lease_resources members.','Current tree collector does not support agent-native-runtime manifest and synchronously reads whole files with 256MiB/file and 512MiB/tree limits.','T3 remove checks install activity, in-memory leases and protected custom paths; this is not a claim of cross-host persistent run GC coverage.']};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and not any(x in p.parts for x in ['node_modules','publication','data','__pycache__']) and p.suffix in ['.mjs','.cjs','.json','.sqlite','.py','.variant','.log'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)]and c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生运行资源租约与清理计划：隔离研究

2026-11-14；R02／08／10／11，Q01／03／48／51／52／53／54；技术方案 §12.1、验证账 §4.53。没有产品代码、共享原型或正式产品验收。

## 关键发现

实际 CapabilityRunRegistry 的 native-only guard 可以把原生包作为固定资源加入同一个 run 的 capability_lease_resources，保留内容 hash 和 generation。但现有 resourceGcPlan 只读取 capability_resource_leases.resource_id，没有读取该租约的全部成员。因此仅允许 agent-native-runtime 种类与根节点的临时反例版本，会把真实运行仍占用的成员列成可删除。实验只检查计划，**没有执行这份错误计划**。

这不是宣称现产品已经删除 Agent 包：产品本来不支持该新种类作为清理根。反例证明未来迁移只加类型白名单会引入缺口。候选 planner 另读默认版本和所有未释放租约成员，验证资源身份／代次，把这些依据纳入 planHash；故障时保留并报告 issue。

当前实际 captureGcTree 也不识别原生清单。本批对小型 native 包调用实际函数得到 HASH_MISMATCH；没有把身份拒绝冒充大小测试。进一步源码核对发现其单文件上限 256 MiB，整树 512 MiB，且同步 readFileSync 整文件；当前 Codex 主程序 {main['size']} 字节大于 268435456 字节。该大小不兼容是源码与真实包尺寸对照证据，不是执行到该分支的动态测试。

## 实际执行：{a.name}

| 检查 | 结果 |
| --- | --- |
| L01 | 实际 guard 预留把 A 原生资源记为 lease member，而非租约主资源；原始 planner 不接受该根，原始 tree capture 不接受其清单 |
| L02 | 故意只扩种类／根的反例 planner 返回 A 可回收，即使实际 run 租约尚在；不执行删除 |
| L03 | 修正候选 planner 后，A→B 默认切换仍保留 A 的 run 占用和 B 的默认占用，A 资源代次不变 |
| L04 | 捕获的真实 Node 子进程读取 A 的受管入口并报告 A；发 stop 后 run 停在 stopping，子进程活着且占用保留；仅在退出回调后释放，B 默认仍保留 |
| L05 | A 可回收的旧计划生成后新建 run；planHash 变化，实际维护入口使用候选 planner 拒绝旧计划；新保留计划同样拒绝，没有进入 capture／move |
| L06 | 原生资源 generation 故障变更后，实际 run.prepare 拒绝，候选 planner 保留并报告成员无效；恢复夹具记录后可取消 |
| L07 | FixtureProcessReader 模拟宿主 unknown、宿主 stopped 但 armed／无 PID；实际恢复器分别保留 unknown／orphaned 与恢复租约。清理由驱动已知没有 spawn 的 cancelUnforked 完成，不假冒发现进程已退出 |
| L08 | 完整实际 Codex 0.167.1 包被 guard 租用，从该发布路径启动 app-server 并收到 initialize 响应；EOF 后真实退出，回调释放租约。未发送 turn 或调用模型 |

两个真实子进程均 code 0，无信号退出或兜底 kill；最终没有未释放 run 租约，也没有 cleanup-graph 操作。最终重新校验 41 个实际原生文件。Node 夹具 A／B 用于升级语义，不能当成两个真实 Agent 版本互换成功；真正的 Codex 场景只证明初始化与运行占用。

## 三份构建的边界

- actual：现有源码，仅适配构建资产 glob 与 CJS import.meta.url。
- naive：故意不完整的反例，仅允许原生资源 kind／root。
- candidate：仅改 planner，补默认版本、租约成员、身份检查和计划 hash；没有修改真正的文件 capture、删除／恢复 final guard 或持久历史资源合同。

固定 guard 是原生生命周期权限，代码明确不授予应用工具／业务凭据。不能拿 L08 代替完整程序化业务 run 的原生资源接入，也不能绕过该边界让业务 run 退化为 native-only。发布时校验了文件，但本批 guard.verify 仍只调用旧会话资源验证；未把“原生清单重验→受管实际 fork”联合封装起来，晚变更／路径替换仍待验证。

默认指针只是一种保留根，不能替代已接受启动材料、历史、准备阶段、安装操作和外部配置引用。实际删除前后的 final guard、崩溃恢复和新引用竞争必须用同一套依据；本批没执行删除，不能宣称原生 GC 完成。大文件清理需要独立预算和流式／worker 方案，不能通过增大旧业务桥限制解决。

## 参考 T3 与 WillYou 的设计取舍

本地 T3 CodexInstallation.remove 在安装进行中或存在运行租约时拒绝卸载，并核对配置中指向受管目录的自定义路径。WillYou 可参考这个用户行为，但应接到自身持久 run／资源成员、默认值和冻结启动依据，而不是只复制一个内存计数。T3 的这段源码没有作为跨进程租约恢复的实验依据。

## 证据

[结果](result.json)、[运行审计](runtime-audit.json)、[源码与变体依据](source-review.json)、[哈希清单](archive-manifest.json)、[脚本、三份构建与数据库](raw-evidence.tar.gz)。{len(files)} 文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(b['sources'])} 个构建输入复核。native 大文件不入文档库。

复跑只在新的临时目录进行，替换记录中的绝对实验路径并安装原依赖，执行 build.mjs 后运行 probe.mjs。候选构建仅供验证，尤其 naive 绝不能用于实际资源删除。不会向用户日常配置、数据库或资源目录写入。
''')
def tech(t):
 anchor='当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、真实磁盘耗尽、真实 run 租约／在用升级／GC、完整 App／系统重启、历史格式兼容或目标平台安装。'
 replacement='''[租约与清理计划实验](实验/20261114_原生资源租约与清理计划验证/README.md)使用实际 native-only guard，把 Agent 原生资源记入 run 的完整租约成员；默认 A→B 后 A 的占用仍在，停止意图不能代替子进程退出。完整 Codex 包初始化及退出回调已验证。该 guard 只有生命周期权限，不提供业务工具授权；正式程序化 run 仍需原生资源与业务计划一起原子预留，不得用 guard 绕过业务接入。

只给现有 GC 增加新 kind／root 不够：反例已证明 planner 漏读 capability_lease_resources 时，会把真实占用成员列为可回收。原生资源的默认值、启动／历史固定引用、安装／准备状态、租约主资源及全部成员都应进入保留依据和计划 hash，实际删除及恢复的最终检查必须使用相同依据。候选 planner 已验证默认／成员保护、旧计划失效、代次冲突和 unknown 占用保留；没有执行原生资源删除，其他固定引用和最终删除守卫仍待联合。

现有 captureGcTree 不认识新原生清单，并使用 256 MiB 单文件／512 MiB 总量预算和同步整文件读取；本轮实际 Codex 主程序 271011440 字节超过前者。原生清理需独立清单验证和适当预算，采用流式或 worker 校验、短最终身份检查及可恢复移动／删除；不直接扩大现有业务资源限制。T3 卸载时检查安装／运行租约和指向受管目录的自定义路径，可参考行为，不能代替 WillYou 持久占用体系。

当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、真实磁盘耗尽、带业务授权的完整 run 资源联合、真正的原生 GC／删除恢复、原生文件晚变更到 fork 的联合封装、完整 App／系统重启、历史格式兼容或目标平台安装。'''
 assert anchor in t;return t.replace(anchor,replacement)
edit(base/'技研/技术方案.md',tech)
section='''### 4.53 原生资源的真实 run 占用与 GC 计划边界

[租约实验](实验/20261114_原生资源租约与清理计划验证/README.md)L01–L08 接实际 native-only guard 与真实进程。租约成员保护 A、默认指针切到 B、stop 后等待实际退出、旧清理计划失效和 generation 冲突均有证据；FixtureProcessReader 分支覆盖 unknown 与 armed／无 PID，未冒充真实宿主死亡。完整 Codex app-server initialize 成功，退出后释放，未发送模型回合。

故意只开放 native kind／root 的反例 planner 漏掉实际 lease member，误判可收集；候选补成员和默认保留后拒绝。本批没有执行任何删除，原生树验证与删除／恢复 final guard 尚未接通。实际旧清理器不识别原生清单；其整文件同步读取与 256 MiB 上限还小于本版 Codex 主程序（源码／尺寸对照）。技术方案 §12.1 已明确独立原生清理合同。

该 guard 不授予业务工具；不能以其通过抵扣完整程序化 run 的业务与原生资源联合。真实 fork 前原生字节再验证、历史／启动固定引用、实际删除恢复、其他平台仍保留。只修改研究文档与临时夹具。

'''
def ledger(t):
 assert '### 4.53 'not in t;t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q01','Q03','Q48','Q51','Q52','Q53','Q54']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.53 补 native-only 实际 run 租约与成员／默认 GC 计划，业务 run 和实际删除未关闭 |'
 t='\n'.join(lines)+'\n';t=t.replace('公网 HTTPS／代理、复制中途、真实 run 租约和遗留准备清理仍待联合。','§4.53 补 native-only 真实 run 占用与成员／默认 GC 计划反例及修正；公网 HTTPS／代理、复制中途、业务 run 资源联合、实际原生清理及遗留准备清理仍待证。');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补实际 run 原生资源占用与 GC 计划验证，见[技术方案 §12.1](技研/技术方案.md)。确认仅开放新资源类型会漏掉租约成员；候选计划补了默认／成员保护，真实 Codex 初始化和退出已验证，但业务 run 联合及实际删除尚未完成。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)补原生资源最终启动／清理合同与业务 run 联合，并继续完整协议、跨宿主输入／结果对账及原业务边界；下载／复制中途、遗留目录、平台、性能和界面状态设计仍保留。当前只做设计与隔离技术验证，不修改产品或共享原型，正式产品验收属于后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(b['sources'])}))
