from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_混合Provider子提问与关闭语义验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==8 and r['error'] is None and r['serverError'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
s=json.loads((Path(r['out'])/'host-state.json').read_text());assert len(s['requests'])==5 and all(x['state']=='stopped' for x in s['runs']) and all(x['state']=='released' for x in s['leases'])
codex=[x for x in s['requests'] if isinstance(json.loads(x['native_json'])['requestId'],int)];assert len(codex)==3 and all(json.loads(x['native_json'])['requestId']==0 and x['liveness']=='closed' and x['close_evidence'] for x in codex);assert sorted(x['cancel_requested'] for x in codex)==[0,0,1]
t3=Path('/Users/hx/projects/t3code');refs=[t3/'apps/server/src/orchestration-v2/Adapters'/n for n in ['ClaudeAdapterV2.ts','CodexAdapterV2.ts']]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'build':b,'t3Sources':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in refs],'t3Boundary':'Read-only source reference: Claude onElicitation maps callback ID and abort into runtime requests; Codex handles supported elicitation in active turn context. Did not execute T3 adapters; experiment is WillYou actual registry plus isolated candidate.','scopeClarification':'Inherited normal-run result scope says no native-close claim; that restriction applies to Claude retirement. This mixed run journals real Codex resolved frames, but does not infer consent or business success from closure.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','fixture.mjs','ledger.mjs','ledger.sql','probe.mjs','mcp.mjs','model.mjs','native-inputs.mjs','migration.mjs','candidate.sql','source-review.json','prepare.py']]
attempts=sorted(root.glob('attempt-*'))
for a in attempts:files.extend(p for p in a.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'scopeClarification':review['scopeClarification'],'actualCodexRequestIds':[json.loads(x['native_json'])['requestId'] for x in codex]}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 混合 Provider 子提问与关闭语义验证

日期：2026-11-14。关联 D02／D06、Q11／26／27／28。真实 Claude SDK 0.3.321／native 2.1.321 与 Codex app-server 0.167.1 接入同一当前会话／运行注册器及 SQLite。父子关系与回应账为临时候选，模型及答案为本机合成内容。

## 八项检查

| 检查 | 实际结果 |
| --- | --- |
| J01 相同问题 | Claude 与 Codex 同时提出相同 message／schema；跨子／父作用域回答拒绝，活跃 run 不准提前退役 |
| J02 父指针变化 | 修改候选父 binding 不改变子问题归属；未执行真实父 Provider 切换 |
| J03 停止 Claude | A1 取消后旧回答拒绝，Codex B1 正常收到 B_ONLY，重复决定不重复发送 |
| J07 停止 Codex | B2 中断后请求收到真实 resolved，但没有用户答案且取消意图为 1；Claude A2 仍在等待用户 |
| J04 Claude 续接 | A2 实际 SDK resume 同一 native session，新 run／generation 拒绝 A1 的旧回答，当前答案抵达 MCP |
| J05 正常／取消 | B1 无取消意图、有已提交答案及精确 Codex 关闭证据；复制句柄拒绝，重复退役幂等，晚到回答拒绝 |
| J06 退役原子性 | Claude A2 已退出后注入活性更新失败，退役证据与状态整体回滚；重试不重发答案 |
| J08 Codex 续接 | B3 实际 thread/resume 原 native thread，连接／run 已换，拒绝 B2 旧回答；MCP 收到 B_NEXT，正常关闭 |

八项通过，八个本机合成模型请求、五个原生进程全部退出。A1 主动中断退出 1，其余退出 0；所有实际 run stopped、租约 released，SQLite 外键及完整性通过。模型请求及业务外部写入均未使用真实服务。

## 关键发现

Codex B1／B2／B3 的 native thread 相同，原生请求 ID 三次都是数字 0；仍须按连接、run、generation 和任务区分，不能依赖 ID 单独去重，不能用真值判断丢弃 0。真实 serverRequest/resolved 经当前连接句柄验证 thread／typed requestId 后入关闭账；本轮正常回答和取消都有 resolved，不能将其当作批准或业务成功。

Claude 使用 SDK callback requestId 回复，没有伪造 Codex 关闭帧。正常运行结束后候选保存 runtime-ended 并使旧入口 expired、cancel_requested=0；主动取消为 1。Codex 的精确 closed 与 Claude 的已退役 expired 可在统一 UI 中都有“无需继续回答”的含义，底层原因与投递证据仍须保留。

结果 JSON 中继承的 no native-close claim 描述只适用于 Claude 的运行退役；本轮 Codex 有实际关闭帧。J05 的 retirementNotNativeClose 表示退役动作自身不创造原生关闭证明，Codex 证明来自独立 journal／apply。原始输出保留，范围在此明确。

## 与 T3 对照及边界

本地 T3 的 ClaudeAdapterV2.onElicitation 使用 SDK callback ID 建立 runtime request，并将 abort 与待决回应清理关联；CodexAdapterV2 在活动 turn 上处理其能回答的 MCP elicitation。参考“各适配器保留协议差异、上层统一请求”的分层，不照抄其审批卡能力为 WillYou 任意表单已支持。此次仅阅读 T3 源码，没有运行 T3 适配器测试。

本轮使用实际注册器，但额外 adapter 资源及选择规则为明确夹具；父子关系不是完整 delegate／outbox 创建服务，尚无实际父切换、真实 UI／业务审批、供应商模型行为或宿主崩溃。上一轮原生全退出后的恢复证据不能扩展成原生仍活跃的恢复。下一步验证宿主死亡而原生进程仍存活／状态未知时，问题入口失效与运行租约保留能否共同成立。

## 复现

固定依赖及本机监听权限具备时执行 `node build.mjs`、`node probe.mjs`。归档包含驱动、夹具、实际构建、379 条输入摘要、五个原生过程／MCP 结果、关闭通知及最终数据库。T3 两个参考文件的版本和摘要记录在来源文件中。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text();anchor='#### 4.4.2 回应账的三个状态与恢复次序'
add='''[混合 Provider 子问题实验](实验/20261114_混合Provider子提问与关闭语义验证/README.md)进一步把真实 Claude／Codex 放在同一当前运行账与候选问题账：两端相同表单不会串答，任一端取消不影响另一端待决或完成；各自 resume 原生会话后旧作用域回答均拒绝。Codex 三次连接中 thread 相同、请求 ID 均为数字 0，身份必须保留连接代次、run／generation 和 typed native ID。原始关闭帧经精确对应入账；正常回答与取消均有 resolved，因此 closed 只结束该请求，决定与业务结果仍单独核对。

统一展示不能反向抹平适配器证据：Codex 有精确关闭通知时保存 closed；Claude 缺对应证据且运行已结束时保存 expired＋runtime-ended。两者均可结束回答入口，但无取消意图时都不显示“用户已取消”，无消费证明时均不补业务成功。宿主崩溃后问题句柄失效与旧原生执行范围排空是两个门槛；即使问题已 expired，存活／身份不明的旧进程仍需保留运行与资源占用，该混合联合窗口尚待验证。

'''
assert anchor in t;t=t.replace(anchor,add+anchor,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.96 ' not in t
t=t.replace('真实 UI／业务、原生仍活跃及混合链仍待验 |','§4.96 又补同库真实 Claude／Codex 子问题、双向取消隔离、各自 resume 与 Codex 精确关闭；真实 UI／业务、原生仍活跃及完整委派链仍待验 |',1)
add='''### 4.96 混合 Provider 子问题与协议关闭差异

[八项检查](实验/20261114_混合Provider子提问与关闭语义验证/README.md)在同库实际会话／运行注册器上连接 Claude SDK 和 Codex app-server，验证同文问题隔离、双向取消不串扰、各自原生会话恢复及旧回答拒绝。Codex 三次连接的同 thread 请求 ID 都为数字 0，必须保留连接代次和 run 身份。其正常与取消两类真实 resolved 均经精确请求关联入账，不当作批准或业务成功；Claude 继续保留运行退役与原生关闭区别。

八个本机合成模型请求、五个原生进程均退出，实际运行／租约已收尾，数据库外键与完整性通过。父指针／委派关系为候选，没有实际父 Provider 切换、业务审批、完整 delegate 服务或 UI。读取 T3 两端适配器作分层对照，未执行 T3。Q26 继续部分；原生仍活跃／状态不明时宿主退出与完整业务恢复仍待联合。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
t=t.replace('仍缺混合 Provider、原生仍活跃与完整业务链的联合恢复','§4.96 已补同库混合 Provider 子问题、双向取消／续接及精确关闭；仍缺原生仍活跃与完整业务链的联合恢复',1)
t=t.replace('截至 §4.95，56 个宽口径问题项中','截至 §4.96，56 个宽口径问题项中',1).replace('完整业务、混合链及其余恢复窗口仍未关闭。','并取得混合 Provider 问题／取消证据；完整业务、完整委派链及其余恢复窗口仍未关闭。',1)
assert len(re.findall(r'^\| Q\d{2} \|',t,re.M))==56;put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();t=re.sub(r'^最新进展：.*$','最新进展：同库 Claude／Codex 子问题、双向取消隔离、原生续接与关闭语义差异已有独立证据。见[混合 Provider 子问题实验](技研/实验/20261114_混合Provider子提问与关闭语义验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)补原生进程仍活跃／状态不明时的宿主退出恢复，联合核对问题入口失效与运行租约保留；完整委派／业务、迁移和资源剩余约束继续保留。',t,flags=re.M);put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-question-retirement-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed']}))
