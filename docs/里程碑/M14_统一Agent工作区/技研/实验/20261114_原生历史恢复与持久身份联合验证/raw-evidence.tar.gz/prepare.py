from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_原生历史恢复与持久身份联合验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
for e in b['variants']:assert sha(Path(e['file']).read_bytes())==e['before'];assert sha(Path(e['variant']).read_bytes())==e['after']
audit=json.loads((root/'audit.json').read_text());assert all(x['currentKernelState']=='stopped' and x['exit']['code']==0 for x in audit['cleanup']);assert audit['methods']['thread/start']==1 and audit['methods']['thread/resume']==6 and 'turn/start' not in audit['methods']
t3file=t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'native':{'kind':'Codex app-server','version':'0.167.1','sha256':'ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b','requests':audit['methods'],'modelTurns':0},'t3Reference':{'head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'path':str(t3file),'sha256':sha(t3file.read_bytes()),'sourceObservations':['ensureThread issues thread/start separately from resumeThread','resumeNativeThread handles archived via thread/unarchive then resume; handles closing via tracked Deferred then resume','Other request errors fail; no general thread/start fallback in this helper'],'scope':'Source reread only. Isolated native archive case mirrors the specific protocol sequence; no T3 adapter execution.'},'candidate':['Current-source programmatic run/session/plan variants and shared claims from 4.104','Owned callback checks and per-run resume observations in isolated SQLite'],'fixtures':['Prepared binding/source and adapter resources','Two explicit developer context injections, not human messages or business authorization','Isolated CODEX_HOME rename/restore after all relevant children stopped','Six registry instances in one host process; no host crash'],'results':['New native process resumes same claimed ID','Legitimate history changes bytes but identity and immutable capability revisions stay fixed','Missing native root returns explicit error; no replacement thread is created','Restored root supports explicit next-run retry','Archived thread resumes only after exact unarchive; failed and successful observations both retained'],'limits':['Native initialized empty history behavior reused from 4.47, not retested here','No model input acceptance or actual supplier authentication','No business result/approval/private MCP chain','No thread-closing race, host SIGKILL, dynamic descendants or unknown process recovery','Resume observation table is research diagnostic storage, not finalized production schema or authorization','No other runtime versions/platforms, product migration, UI or package acceptance'],'audit':audit}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['actual.cjs','candidate.cjs','build.mjs','build.json','patch.py','patches.json','session-registry.ts.variant','run-registry.ts.variant','run-plan.ts.variant','probe.mjs','candidate.sql','migration.mjs','claims.mjs','retained.mjs','programmatic-prior.mjs','claims-joint.mjs','claim-read.mjs','source-review.json','audit.json','prepare.py']]
for d in sorted(root.glob('attempt-*')):files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 原生历史恢复与持久身份联合验证

日期：2026-11-14。D01，关联 Q13／Q46–50。承接 §4.104，在同一候选身份／运行库上实际重启 Codex 并恢复历史，补正常续写、历史缺失和归档分支。attempt-P8gdYT 六项通过，未改产品源码。

## 基线和边界

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，383 项当前源码输入；程序化读取、运行和计划扩展沿用 §4.104 的最小补丁并在本目录重新构建。真实 Codex 0.167.1 固定二进制，六个独立原生进程均由现有内核 helper 校验 PID／出生身份。

实际创建一个线程，显式注入两条合成 developer 研究上下文；不是用户消息、业务批准或模型输入执行证明。没有 turn/start／模型请求。HOME／CODEX_HOME 和所有历史、数据库均位于本次隔离夹具目录；移开／恢复历史前先确认对应进程退出，没有操作用户日常会话。

程序化 prepared binding／source 与适配资源仍为夹具。当前 owner／run 生命周期及资源服务为实际源码加研究扩展；原生恢复观察账是诊断候选，不是正式产品 Schema 或新的执行授权。每次观察记录关联本 run、binding、generation、固定 source、runtime 摘要及预期／返回 native ID；接收后再次核对当前 owned run。协议明确拒绝与无可确认响应分别记录 rejected／unknown，本轮只实际触发 rejected 和 confirmed。

## 六项检查

| 检查 | 实际结论 |
| --- | --- |
| R01 初始历史 | 真实 thread/start 返回 ID，当前 owned run 写入共享 claim／来源；注入合成上下文 A 后退出，rollout 的 session_meta 与原 ID 一致，claim 保留 |
| R02 新进程恢复 | 新注册器／generation 2 的新进程恢复同一 ID；同 ID 回调幂等，binding、cap、revision 和 claim/source 不改变 |
| R03 合法续写 | 通过原生 inject_items 追加上下文 B，历史文件摘要改变且 A／B 均保留；第三个进程仍恢复同一 ID，不能要求历史字节永久等于首次 hash |
| R04 历史缺失 | 所有相关进程退出后移开隔离 CODEX_HOME，新进程对原 ID 返回 no rollout found；记录 rejected，停止本 run，不新建替代 thread，原身份／修订不变 |
| R05 显式恢复 | 恢复原历史目录后，以 generation 5 的新 run 恢复同一 ID；之前的失败记录仍保留，不把旧 run 标为恢复成功 |
| R06 归档分支 | 在隔离线程 archive 并退出，下一新进程 resume 得到归档错误；针对这一明确错误执行同 ID unarchive，再 resume 成功。观察顺序 rejected→confirmed，没有 thread/start 替代 |

R01–R06 均通过，无失败重跑。原空会话取得 ID 但不可恢复的反例复用 §4.47，本轮没有为重复计数重跑。历史摘要用于本次审计，不能证明模型理解、真人来源或固定权限。

## T3 参考与设计边界

只读核对 T3 `f313d0a6cb843551fb60e57a454a71e71a3a8c04` 的 CodexAdapterV2：ensureThread 与 resumeThread 分离；resumeNativeThread 只对 archived 执行 unarchive 后恢复，对 closing 等待记录的关闭事件后重试，其余请求错误继续失败。本轮只在隔离 native 客户端验证归档顺序，没有执行 T3 适配器，也没有验证 closing 并发窗口。

WillYou 保留这一“明确恢复与新建分离”的边界。Driver 根据固定版本解析可识别的恢复错误，宿主保持任务／绑定／来源；恢复原绑定且当前政策允许时，可针对归档执行原 ID 的取消归档／恢复。未知错误、缺历史或身份不符不能回退成新线程。closing 分支须依据真实关闭事件和运行代次处理，不能靠固定睡眠或通用重试；仍待联合。

## 清理和未验项

六进程均 exit 0，再次读取内核确认原身份 stopped；六 run stopped、九份租约 released，SQLite 完整性／外键通过。原协议账仅一个 thread/start、六个 thread/resume、两个 inject_items、一个 archive 和一个 unarchive；零 turn/start。

完整业务准入／私有桥、模型输入、实际用户来源、宿主崩溃及未知后代、合法迁移复制后的跨根恢复、原生降级与资源 GC 仍未联合。没有用一个版本和平台外推全部 CLI／SDK；Q 统计及正式产品用例不增加通过数。

复现：按固定依赖运行 patch.py、build.mjs、probe.mjs，需要归档声明的 Codex 二进制和 macOS 进程身份 helper，无需真实账号。见[结果](result.json)、[来源和审计](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text();old='后继 run 使用自己的 generation 和当次源修订；不得在 run cleanup 中顺带释放原生历史身份。该实验后继 run 只准备未 fork，不能由准入成功推断原生历史可恢复。';new='后继 run 使用自己的 generation 和当次源修订；不得在 run cleanup 中顺带释放原生历史身份。该实验后继 run 只准备未 fork，不能由准入成功推断原生历史可恢复；后续真实恢复证据及其边界见下段。';assert old in t;t=t.replace(old,new,1)
needle='不得为了使空会话“可恢复”自动注入无意义消息。';assert needle in t
add='''\n\n[原生历史与持久身份联合实验](实验/20261114_原生历史恢复与持久身份联合验证/README.md)在同一研究 Schema 和共享 claim 上验证六个真实 Codex 进程：有合成历史时新进程恢复原 ID，合法追加内容后历史摘要改变仍可恢复；移开隔离历史时原生明确拒绝，保留原 binding／revision／claim，停止失败 run；恢复目录后仅以明确的新 run 再次恢复。恢复观察属于对应 run／generation／runtime／来源，不能覆盖前一失败或变为执行授权。历史文件是可合法续写的原生状态，其 hash 用于一次观察／复制审计，不作为永久不变的原生身份键；固定能力快照和启动源摘要仍保持不可变。\n\n**恢复错误由 Driver 按已核验版本分类。** 当前 T3 CodexAdapterV2 将新建与恢复分开，对归档使用同 ID unarchive 后 resume，对 closing 等待已登记的关闭事件后重试，其余错误继续失败。上述实验已在 Codex 0.167.1 验证归档分支，未运行 T3 本身或 closing 竞争。WillYou 在请求恢复原绑定且当前政策允许时处理这类明确状态；缺历史、身份变化、未知协议错误不能通用重试或静默 thread/start。无可确认响应保留 unknown，不能套用原生明确拒绝的处理；宿主失联／关闭事件／原生降级等分支仍按各自合同验证。'''
t=t.replace(needle,needle+add,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.105 ' not in t
add='''### 4.105 原生历史恢复、续写与持久身份联合

[六项原生历史联合检查](实验/20261114_原生历史恢复与持久身份联合验证/README.md)在 §4.104 当前源码变体／共享 claim 上启动六个真实 Codex 0.167.1 进程。有合成 developer 历史时新进程恢复原 ID，合法续写改变 rollout hash 但不改固定 capability revision／claim；移开历史后原生明确拒绝且无替代 thread，恢复目录后新 generation 显式恢复。归档错误经同 ID unarchive／resume 处理，失败与成功观察分别保留。

六项通过、六进程 exit 0 且内核重新核验 stopped；六 run stopped、九租约 released，完整性／外键通过。协议账一个 thread/start、六 resume、两个合成 inject_items、一次 archive／unarchive，零模型 turn。T3 resumeNativeThread／ensureThread／resumeThread 源码只读对照，未运行其适配器；closing 竞争未覆盖。Prepared 来源、适配资源与观察账仍为研究候选，无真实用户授权／业务桥、宿主崩溃／未知后代、产品代码或验收。T0.1 §3.2.9 合并恢复观察和历史可变性合同；不将本轮恢复成功外推其他版本或全量迁移。

''';t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D01 '):
  c=l.split('|');c[2]=' §4.29／33–48／73–76／88–93／103–105 已补历史／首次绑定共库占用、真实 owner／后继准入及同 ID 原生恢复；合法历史续写、缺失／恢复、归档分支取得固定版本证据。下一步固定同一研究 Schema 修订，联合全写入口、迁移复制后的恢复与业务结果准入；补 closing／异常 owner 接管、旧根释放／回退及资源保留读取。§4.105 无模型／业务或宿主崩溃，不能当完整接管通过；要求同库原子提交／失败／恢复证据 ';lines[i]='|'.join(c)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.104，56','截至 §4.105，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：同一研究身份／运行模型上的六项真实 Codex 恢复检查通过，覆盖新进程恢复原 ID、合法历史续写、缺失后保留身份、显式恢复和归档处理。见[实验记录](技研/实验/20261114_原生历史恢复与持久身份联合验证/README.md)；零模型 turn、未改产品代码，统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04](技研/全局设计验证账.md#71-当前全局收口方式)联合迁移复制后的恢复、全写入口及业务结果准入，核对 closing／异常宿主、run-bound 配置、降级和资源保留。固定版本的原生恢复证据不能代替模型输入、业务或完整迁移接管。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size}))
