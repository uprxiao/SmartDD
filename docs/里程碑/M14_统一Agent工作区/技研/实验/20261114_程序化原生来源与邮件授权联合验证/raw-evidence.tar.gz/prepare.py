from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_程序化原生来源与邮件授权联合验证';stage=r/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
result=json.loads((r/'latest.json').read_text());assert result['passed']==5 and result['error'] is None
builds=[json.loads((r/n).read_text()) for n in ['actual-build.json','candidate-build.json']]
for b in builds:
 for x in b['sources']+b['outputs']:assert sha(Path(x['path']).read_bytes())==x['sha256'],x['path']
patches=json.loads((r/'patches.json').read_text())+json.loads((r/'origin-patches.json').read_text())
for x in patches:assert sha(Path(x['file']).read_bytes())==x['before'];assert sha(Path(x['variant']).read_bytes())==x['after']
resources=[];prior=Path('/private/tmp/willyou-m14-programmatic-mail-binding-probe')
for p in sorted((r/'bundles').rglob('*')):
 if p.is_file():
  rel=p.relative_to(r);assert sha(p.read_bytes())==sha((prior/rel).read_bytes());resources.append({'path':str(rel),'sha256':sha(p.read_bytes())})
audit=json.loads((r/'audit.json').read_text());origin=json.loads((r/'origin-audit.json').read_text());tf=t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'builds':builds,'patches':patches,'resources':resources,'native':{'version':'Codex 0.167.1','sha256':'ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b'},'t3':{'head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'path':str(tf),'sha256':sha(tf.read_bytes()),'observation':'item/started and item/completed userMessage can route through emitSubagentUserMessage; provider-native user role also carries subagent conversation. Source read only, not T3 execution or equivalent mail authorization.'},'actual':['Owned real Codex/MCP/kernel peer ancestry','Current source NativeUserMessages file/header/inode/record verification with explicit native identity overlay','Actual mail tryNative/action provenance/grant/execution and default v2 tool bridge','Actual default adapter L3 gate rejects this version before isolated declaration'],'candidate':['Programmatic run/session/plan and claim extensions from 4.104/106','RAM input ledger derived from 4.54, private per-run channel and DB-derived generation/binding','Reader carries native identity through match/verify','ApplicationService research-only injection seams; original legacy inputs retained by composite','Tagged legacy/programmatic scope comparator; standalone branch checks only for multi-message scope'],'controlled':['Fixed-version L3 experimental override after negative default gate; not released compatibility declaration','Synthetic renderer identity and direct management sender confirmation','Synthetic model endpoint, cipher and SMTP submit; loopback connection verification only','Prepared programmatic binding/refs'], 'limits':['No actual Electron sender/IPC or product UI','No persistent input ledger/crash reconciliation, no restore of RAM grants','Single native thread/one binding/one run; no Claude, cross-provider, delegation or native steer/merging/multimodal','Exact draft-reference instruction; multi-message natural-language authorization not integrated in this run','No supplier model/real mail, no platform/version expansion; no TypeScript compile or final runtime schema proof for research seams'],'audit':audit,'originAudit':origin,'auditCorrection':json.loads((r/'audit-correction.json').read_text())}
(r/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[p for p in r.iterdir() if p.is_file() and p.name not in ['manifest.json','raw-evidence.tar.gz','publication-audit.json']]
for d in [r/'bundles',*r.glob('attempt-*')]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
files=sorted(set(files));archive=r/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
man={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(r)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',result),('source-review.json',review),('archive-manifest.json',man)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 程序化原生来源与邮件授权联合验证

日期：2026-11-14。D04／D05、Q17／Q41。承接 §4.54 的来源候选和 §4.106 的实际运行／邮件桥，本轮在同一活跃 run 上取得真正的原生接收通知并核验落盘记录，再通过现有邮件授权和执行服务。attempt-19IQI2 五项通过；未改产品源码。

## 基线与研究接线

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，实际 bundle 681 项输入、候选 685 项输入。三份既有 session／run／plan 变体与三份新增来源研究变体由当前源码生成。NativeUserMessages 只增加原生身份穿透，保留原路径、文件／inode／header／原始记录摘要及当前 owner 复核。ApplicationService 的临时构造注入缝接入来源账和固定版本证据解析；MailUserAuthorizations 的旧 ptyId 比较改为显式分支比较。它们是独立运行草案，未完成正式 TypeScript 接口／运行时 Schema，不可直接作为产品补丁。

真实 Codex 0.167.1 与默认 v2 私有桥由实际内核 helper 核验归属。输入账保留来源、inputId、binding、generation、run、配置摘要、sequence 和私有 channel；从实际 item/completed 的 userMessage 核对 thread／turn／item／clientId／原文后接收。固定 Codex 落盘记录再以 turn 和内容关联，raw record ID 不冒充 live item ID。当前 owner 的 binding／generation 从实际 run 表读取，原生连接结束后不允许继续生成 live 来源。

UI sender／frame 是受控替身，内部与用户入口由研究宿主显式选择；不是实际 Electron 输入。模型为本机合成服务，SMTP 只进行回环认证；发送 submit 为受控函数，没有真实 DATA 或真实账号。项目发件身份仍通过模拟管理 UI 确认，但本轮没有调用邮件发送 reviewSend／authorizeSend，发送授权来自实际 tryNative 链。

## 五项检查

| 检查 | 实际结果 |
| --- | --- |
| S01 版本门槛 | 当前默认 adapter 对 0.167.1 的 L3 来源返回 unsupported／AGENT_ADAPTER_UNSUPPORTED。之后才显式打开临时研究声明以验证候选链；不能把实验当作产品已支持该版本 |
| S02 内部输入 | 内部 agent-delegation 的具体发送原文被 Codex 记录为普通 native user 行，MCP send_execute 仍得到 AUTHORIZATION_REQUIRED；没有业务来源行或提交 |
| S03 用户来源 | 同样文字从模拟受信用户入口提交，取得实际原生接受通知；在模型第一个工具请求之前读到并复核精确原生文件证明。现有 tryNative 解析具体草稿修订，生成唯一 native-user-message 来源和授权，受控提交一次；重放返回同 execution 不重复提交 |
| S04 后续失效 | 内部自动接续再次投递同文，旧用户来源仍可保留历史但不再 latest／live，新内部行不变成人类来源；停止 run 后 retained 和 file verify 均失效 |
| S05 身份比较 | 候选比较器拒绝缺失 binding／generation、不同 run／binding／代次、混用 transport 和 undefined ptyId；保留同一有效 PTY 的 terminal／launch-argument 比较。此项为独立函数检查，不宣称已完成多轮上下文授权联合 |

本轮一个真实 Codex、一个真实桥、四个 turn、九次本机模型请求；一个 run stopped、25 份租约 released，两实际进程身份重新核验 stopped，库完整性／外键通过。三次回环认证、一次受控 submit、零 DATA。没有失败重跑原生进程。

## 交叉审计与参考

原生文件有五条 role=user，其中一条是 harness 环境上下文，当前实际证据解析器排除它，余四条分别对应准备、内部发送、用户发送、内部续接。后三条原文相同，各有独立 turn／clientId；唯一持久业务来源只关联第三条的用户 inputId。首次事后审计脚本误把所有 user 角色都算用户输入而断言失败，改用当前实际解析器后核验通过；保留 audit-correction，未重跑原生实验。

只读核对 T3 `f313d0a6cb843551fb60e57a454a71e71a3a8c04`：CodexAdapterV2 的原生 userMessage 可经 emitSubagentUserMessage 映射子 Agent 对话，不能把原生角色等同为真人授权。未运行 T3 或声称它提供 WillYou 的邮件授权合同。

## 设计结论和剩余项

统一 UI 的用户提交须经过实际可信 IPC sender，再由宿主分配完整输入身份；内部委派／历史／自动接续走另一个入口。实时原生回执与磁盘来源匹配可在本固定版本的工具执行前取得，没必要等待整个 turn 完成后才检查，但不能把这一时序推广到 Claude、steer 或其他版本。匹配失败继续走原有明确业务审阅路径，不能猜配、伪造 PTY 或从数据库恢复 live grant。

这里验证了同 run 的实际来源到实际授权，尚未联合真实 UI、输入账崩溃一致性、跨 Provider／委派、原生多消息合并／附件、Claude 最早回执、多轮指代和产品兼容登记。来源仍是 RAM 候选；持久输入恢复证据见原 §4.56，不把两份分别通过的实验当作一个已完成的崩溃恢复链。Q 宽口径状态及正式产品用例不增加完成数。

复现需先运行 patch.py、origin-patch.py、build.mjs 及 build.mjs --candidate，使用归档指定二进制／helper／分发和固定依赖，再执行 probe.mjs、audit.mjs、origin-audit.mjs。setup-probe.py 保存从前批生成本脚本的过程，不在已生成副本上重复执行。所有环境与数据位于独立临时根。见[结果](result.json)、[来源与审计](source-review.json)、[证据归档](raw-evidence.tar.gz)和[摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';s=(repo/rel).read_text();needle='### 6.2 ';assert needle in s
add='''[程序化原生来源与邮件授权联合实验](实验/20261114_程序化原生来源与邮件授权联合验证/README.md)已把当前 owner／程序化 run、真实 Codex／私有 MCP、来源账候选和实际邮件 tryNative／执行服务串联。同文内部投递被拒绝；模拟受信用户入口的输入取得实时 thread／turn／item／clientId 回执，再通过原生文件证明后，可在工具执行前生成具体草稿授权；内部续接不继承 latest 来源，run 结束使活跃证明失效。该证据限定 Codex 0.167.1、单一输入每 turn、具体草稿引用；没有实际 Electron sender、跨 Provider、Claude、多轮指代或持久来源账恢复。

**业务来源能力须独立登记。** 本轮当前默认 adapter 的 L3 门槛实际返回 unsupported，研究接线显式启用固定版本声明后才执行来源链。普通 SDK 对话／MCP 可用不能自动升级为原生真人来源可证；Driver 版本／协议／证据适配与声明需共同验证。未具备该能力时保留已有明确业务审阅入口，不能伪造 terminal 观察或从原生 role=user 推断授权。T3 原生 userMessage 也用于子 Agent 对话，UI 对话映射不等同于业务许可。

本轮来源比较器将 legacy 的有效 ptyId 与 programmatic 的完整 binding／run／generation 分开，拒绝缺字段及混用；此比较器取得独立分支证据，多消息上下文仍待实际联合。实时回执由固定私有 Driver 通道提供，宿主重新核对当前 owner 和配置摘要，正文／clientId／数据库审计均不能独自签发 live 来源；崩溃后的接受记录对账与业务凭据重建必须分别处理，不能把 §6.2 的持久恢复结果直接转换为内存授权。

'''
s=s.replace(needle,add+needle,1);put(rel,s)
rel=base/'技研/全局设计验证账.md';s=(repo/rel).read_text();assert '### 4.107 ' not in s
add='''### 4.107 程序化原生来源与实际邮件授权联合

[五项检查](实验/20261114_程序化原生来源与邮件授权联合验证/README.md)在真实 Codex 0.167.1／默认 v2 私有桥／当前 owner 及实际邮件服务上验证输入来源。三条同文分别来自内部委派、模拟受信用户入口和内部续接：第一条得到 AUTHORIZATION_REQUIRED；用户输入实时回执与精确原生文件证明在业务工具前可核验，实际 tryNative 生成唯一来源／授权并受控提交一次；后续内部输入不继承 live 来源，run 停止撤销证明。另有程序化／旧 PTY 判别比较的独立分支检查。

一个 native＋一个桥均 stopped，一个 run stopped、25 租约 released，完整性／外键通过；四 turn、九次本机合成模型请求、三次回环认证、一次受控 submit、零 DATA。当前默认 adapter 的 L3 实际仍 unsupported，后续使用显式临时研究声明；不可标为产品兼容已通过。原生五条 user 角色中一条 harness 上下文由实际解析器排除，事后审计初次误计已保留勘误，没有重跑原生实验。

三个新增来源变体由当前源码生成，原文件／inode／header／摘要复核保留；sender、prepared 来源、模型和提交为夹具。尚未实际 UI、持久来源恢复、Claude、跨 Provider／委派、多轮指代、steer／多模态或完整版本登记。T3 原生子对话映射只读对照。T0.1 §6.1 合并能力分级和实时来源合同；Q 统计不变。

''';s=s.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=s.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D05 '):
  c=l.split('|');c[2]=' §4.55–56／107 已有原生输入去重／宿主退出恢复及 Codex 实时来源→实际邮件授权局部联合；内部同文不授权、精确用户回执可在工具前核验。下一步在同一最终命令／覆盖账联合持久恢复与业务来源、Claude 接收窗口、配置修订／附件遗漏、跨 Provider／委派；验证派发未知禁止重发及显式后继 run。模拟 UI 和显式研究 L3 声明不代替真实 sender 或产品版本支持 ';lines[i]='|'.join(c)
s='\n'.join(lines)+'\n';s=s.replace('截至 §4.106，56','截至 §4.107，56',1);put(rel,s)
rel=base/'README.md';lines=(repo/rel).read_text().splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：真实 Codex／私有桥到现有邮件授权的五项来源联合检查通过：内部同文不授予发送权，模拟受信用户输入经实时回执与原生文件核验后生成具体授权，内部续接及运行结束不复活许可。见[实验记录](技研/实验/20261114_程序化原生来源与邮件授权联合验证/README.md)。当前产品版本门槛仍 unsupported，实验使用临时声明；未改产品、未发真实邮件。统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04／D05](技研/全局设计验证账.md#71-当前全局收口方式)联合持久输入恢复与业务来源、迁移复制恢复及完整结果准入，补 Claude／跨 Provider／委派、closing／异常宿主与资源保留；明确产品来源能力支持表。固定 Codex 的同 run 来源证据不替代这些分支。'
put(rel,'\n'.join(lines)+'\n');(r/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size}))
