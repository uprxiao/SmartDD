import {readFileSync} from 'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import {begin} from './preparation.mjs';
process.on('message',()=>{});
const spec=JSON.parse(readFileSync(process.argv[2])),db=new Database(spec.database);db.pragma('foreign_keys=ON');
const store=new actual.ResourceStore(db,spec.root),plan=await begin(store,spec.bindingId,spec.row,spec.refs);
process.send({phase:'reservation-committed',token:plan.token});await new Promise(()=>{});
