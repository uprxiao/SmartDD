CREATE TABLE m14_binding(
 binding_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,runner TEXT NOT NULL,
 identity_root TEXT,native_id TEXT,cwd TEXT NOT NULL,
 legacy_task_id TEXT UNIQUE REFERENCES capability_session_snapshots(task_id),
 entry_mode TEXT NOT NULL CHECK(entry_mode IN ('legacy','programmatic')),
 phase TEXT NOT NULL DEFAULT 'historical' CHECK(phase IN ('historical','planned','preparing','prepared','canceled')),profile_id TEXT,profile_revision INTEGER,
 CHECK(phase IN ('planned','canceled') OR identity_root IS NOT NULL),
 CHECK(phase<>'planned' OR native_id IS NULL),
 UNIQUE(binding_id,task_id),UNIQUE(binding_id,task_id,runner),UNIQUE(runner,identity_root,native_id));
CREATE TABLE m14_cap(
 cap_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,
 retention TEXT NOT NULL CHECK(retention IN ('active','hold','tombstone')),current_hash TEXT,
 UNIQUE(cap_id,task_id,binding_id),
 FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(cap_id,current_hash) REFERENCES m14_revision(cap_id,snapshot_hash) DEFERRABLE INITIALLY DEFERRED);
CREATE TABLE m14_revision(
 cap_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,
 snapshot_json TEXT NOT NULL,schema_version INTEGER NOT NULL CHECK(schema_version IN (2,3)),selection_hash TEXT NOT NULL,
 PRIMARY KEY(cap_id,snapshot_hash),UNIQUE(cap_id,task_id,binding_id,snapshot_hash),UNIQUE(cap_id,task_id,snapshot_hash),
 FOREIGN KEY(cap_id,task_id,binding_id) REFERENCES m14_cap(cap_id,task_id,binding_id));
CREATE TABLE m14_ref(
 cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,ref_id TEXT NOT NULL REFERENCES capability_resources(resource_id),
 ref_kind TEXT NOT NULL,ref_hash TEXT NOT NULL,relative_path TEXT NOT NULL,task_id TEXT NOT NULL,
 PRIMARY KEY(cap_id,snapshot_hash,ref_id),FOREIGN KEY(cap_id,task_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,snapshot_hash));
CREATE TABLE m14_mcp(
 server_name TEXT PRIMARY KEY,binding_id TEXT NOT NULL,task_id TEXT NOT NULL,kind TEXT NOT NULL,
 UNIQUE(binding_id,kind),FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id));
CREATE TABLE m14_unmapped(task_id TEXT PRIMARY KEY,snapshot_hash TEXT NOT NULL,reason TEXT NOT NULL);
CREATE TABLE m14_migration(version INTEGER PRIMARY KEY,source_schema_hash TEXT NOT NULL);

CREATE TABLE m14_unmapped_version(task_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,snapshot_json TEXT NOT NULL,selection_hash TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(task_id,snapshot_hash));

CREATE TABLE m14_preparation_ref(binding_id TEXT NOT NULL REFERENCES m14_binding(binding_id),token TEXT NOT NULL,ref_id TEXT NOT NULL REFERENCES capability_resources(resource_id),ref_kind TEXT NOT NULL,ref_hash TEXT NOT NULL,relative_path TEXT NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),PRIMARY KEY(binding_id,ref_id));
