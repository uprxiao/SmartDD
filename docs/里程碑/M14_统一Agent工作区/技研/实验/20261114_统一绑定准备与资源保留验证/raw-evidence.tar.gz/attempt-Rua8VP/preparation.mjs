import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import {addRevision,claimMcp,decode} from './migration.mjs';
const transaction=(store,fn)=>actual.withResourceLock(store.root,()=>store.sqlite.transaction(fn).immediate());
function target(db,b){const p=db.prepare('SELECT * FROM ai_profiles WHERE id=?').get(b.profile_id);assert(p&&!p.command_pending&&p.updated_at===b.profile_revision&&p.runner===b.runner,'TARGET_UNAVAILABLE');}
function resource(store,p){const r=store.get(p.ref_id);assert(r.state==='ready'&&r.integrity==='valid'&&r.generation===p.generation&&r.kind===p.ref_kind&&r.contentHash===p.ref_hash&&r.relativePath===p.relative_path,'RESOURCE_CHANGED');return r;}
export async function begin(store,bindingId,row,refs){return transaction(store,()=>{
 const db=store.sqlite,b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(bindingId);assert(b?.phase==='planned','BINDING_NOT_PLANNED');target(db,b);
 const value=decode(row);assert.equal(value.taskId,b.task_id);assert.equal(value.runner,b.runner);assert.equal(value.native.cwd,b.cwd);assert.equal(value.native.sessionId,null);
 const effect=db.prepare('SELECT o.* FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id WHERE t.binding_id=?').get(bindingId);assert(effect?.state==='claimed','NOT_CLAIMED');
 for(const p of refs)resource(store,p);
 const token=randomUUID();db.prepare("UPDATE m14_binding SET phase='preparing',identity_root=? WHERE binding_id=?").run(value.native.stateRoot,bindingId);
 for(const p of refs)db.prepare('INSERT INTO m14_preparation_ref VALUES(?,?,?,?,?,?,?)').run(bindingId,token,p.ref_id,p.ref_kind,p.ref_hash,p.relative_path,p.generation);
 assert(refs.length,'EMPTY_PREPARATION');return{bindingId,token,row,refs};
});}
export async function finish(store,plan,{fault}={}){return transaction(store,()=>{
 const db=store.sqlite,b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(plan.bindingId);assert(b?.phase==='preparing','BINDING_NOT_PREPARING');target(db,b);
 const pins=db.prepare('SELECT * FROM m14_preparation_ref WHERE binding_id=? ORDER BY ref_id').all(b.binding_id);assert(pins.length&&pins.every(p=>p.token===plan.token),'STALE_PREPARATION');
 assert.deepEqual(pins.map(p=>p.ref_id),plan.refs.map(p=>p.ref_id).sort());for(const p of pins)resource(store,p);
 const cap=randomUUID();db.prepare("INSERT INTO m14_cap VALUES(?,?,?,'active',NULL)").run(cap,b.task_id,b.binding_id);
 const value=addRevision(db,b.binding_id,cap,plan.row,pins);if(fault)throw Error('fixture-finish-fault');
 for(const m of value.mcp)claimMcp(db,b.binding_id,b.task_id,m.serverName,m.kind);
 db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(plan.row.snapshot_hash,cap);
 db.prepare("UPDATE m14_binding SET phase='prepared' WHERE binding_id=?").run(b.binding_id);db.prepare('DELETE FROM m14_preparation_ref WHERE binding_id=?').run(b.binding_id);return{bindingId:b.binding_id,capId:cap,snapshotHash:plan.row.snapshot_hash};
});}
export async function cancel(store,plan){return transaction(store,()=>{
 const db=store.sqlite,b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(plan.bindingId);assert(b?.phase==='preparing','BINDING_NOT_PREPARING');
 const pins=db.prepare('SELECT * FROM m14_preparation_ref WHERE binding_id=?').all(b.binding_id);assert(pins.length&&pins.every(p=>p.token===plan.token),'STALE_PREPARATION');
 const effect=db.prepare('SELECT o.* FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id WHERE t.binding_id=?').get(b.binding_id);assert(effect?.state==='claimed','DISPATCH_UNRESOLVED');
 assert(!db.prepare("SELECT 1 FROM capability_runs WHERE binding_id=? AND state NOT IN ('stopped','failed')").get(b.binding_id),'RUN_UNRESOLVED');
 db.prepare('DELETE FROM m14_preparation_ref WHERE binding_id=?').run(b.binding_id);db.prepare("UPDATE m14_binding SET phase='canceled' WHERE binding_id=?").run(b.binding_id);db.prepare("UPDATE m14_outbox SET state='blocked',reason='PREPARATION_CANCELED' WHERE id=?").run(effect.id);
});}
