from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_数据库版本阻挡与迁移恢复验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==7 and result['error']is None;attempt=Path(result['out']);first=root/'attempt-4Q2oUo';assert json.loads((first/'result.json').read_text())['passed']==0
build=json.loads((root/'build.json').read_text())
for s in build['sources']+build['outputs']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
expanded=[]
for p in [repo/'src/main/db/migrations.ts',repo/'src/main/core/capabilities/assets.ts']:
 for pattern in re.findall(r"import\.meta\.glob\('([^']+)'",p.read_text()):
  for f in repo.glob(pattern.replace('@root/','')):
   if f.is_file():expanded.append({'path':str(f),'sha256':sha(f.read_bytes())})
dbs=[]
for p in [first,attempt]:
 for f in sorted(p.rglob('*.db')):
  con=sqlite3.connect(f.as_uri()+'?mode=ro',uri=True);assert con.execute('pragma integrity_check').fetchone()==('ok',);assert con.execute('pragma foreign_key_check').fetchall()==[]
  dbs.append({'path':str(f.relative_to(root)),'integrity':'ok','foreignKeys':[]});con.close()
refs=[repo/'src/main/index.ts']+[repo/'src/main/db'/n for n in ['migrations.ts','managed-client.ts','migration-coordinator.ts','migration-journal.ts','migration-backup.ts','database-access-gate.ts','database-holder-preflight.ts']]+[t3/'apps/server/src'/n for n in ['cloud/servicePreflight.ts','persistence/databaseMigrationHead.ts','persistence/Migrations.ts','persistence/Migrations.test.ts']]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'build':build,'expandedAssets':expanded,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Current SmartDD planner/runner/managed startup/coordinator/gate/backup exercised. Future migration is a synthetic registered suffix; no complete M14 Schema migration claim. T3 preflight versus migrator separation read from exact local source and test; not run in this batch.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
runtime={'checksPassed':7,'actualBaseMigrations':37,'syntheticTargetMigrations':38,'foreignHolderPreflights':result['preflights'],'longRunningChildren':0,'liveDatabaseTouched':False,'modelCalls':0,'smtpOrExternalBusiness':0,'sourceOrPrototypeChanges':0,'sqliteChecks':dbs,'initialAttempt':{'path':first.name,'failure':'Probe bundle forgot to export ResourceStore; failed after creating isolated baseline DB, before maintenance/backup/new migration. Process exited 1; current bundle adds export. Original build, probe and DB retained.'},'faultInjection':'Committed file mirror explicitly reset to backed-up; separate runMigrations recordCommit callback throws. No SIGKILL or packaged app rollback.'}
(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
files=[root/n for n in ['build.mjs','build.json','actual.cjs','probe.mjs','prepare.py','source-review.json','runtime-audit.json']]
for p in [first,attempt]:files+=sorted(f for f in p.rglob('*')if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files],'sqliteIntegrityAndForeignKeys':dbs}
for name,data in [('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtime,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)),('raw-evidence.tar.gz',archive.read_bytes())]:put(exp/name,data)
put(exp/'README.md','''# 数据库版本阻挡与迁移恢复：独立技术验证

当前实际 SmartDD 迁移规划器、执行器、维护锁、外部占用预检、备份、协调器及 macOS openManagedDatabase 的七项检查通过。使用全部 37 个当前迁移和一个合成未来后缀；不是完整 M14 Schema、旧安装包或应用降级验收。未接触日常数据库。

| 检查 | 实际结果 |
| --- | --- |
| V01 迁移协调 | 真实维护门闩＋前后两次实际 lsof 占用预检；协调器产生 0600 备份、核验摘要并提交第 38 个合成迁移 |
| V02 旧读者拒绝 | 当前 37 迁移的规划器／执行器及实际 macOS 受管启动均拒绝第 38 条记录；逻辑数据库指纹未变 |
| V03 已提交恢复 | 显式将文件镜像置回 backed-up，当前协调器按数据库提交记录修复镜像，后续历史／业务行不丢失，没有恢复旧备份 |
| V04 备份边界 | 备份没有之后的业务行／未来表，保留 pending 维护状态；仅复制到独立目录只读检查，未覆盖原库，也未宣称副本可直接启动旧 App |
| V05 无登记研究表 | 当前迁移器看不到未登记的额外表；仅建 M14 实验表不能证明产品版本阻挡生效。不是说所有新增表都不兼容 |
| V06 回执失败 | 实际 runMigrations 的提交回调注入异常，Schema、业务行、迁移账一并回滚 |
| V07 同长度冲突 | 合成相同条数但最后 hash 不同的迁移账被当前规划器／执行器拒绝，数据库未变 |

设计结论：复用原正式迁移链和启动协调，不再建立平行“已迁移”判断。M14 数据结构、提交收据和水位按同事务要求接入，变更旧记录或只写候选 m14_migration 表都不能代替 __drizzle_migrations。UI／后台业务服务只能在启动校验及维护交接完成后启动；非 macOS 的普通入口同样有迁移账检查，但本轮未跑对应平台包装路径。

数据库备份不是整机／业务回滚：原生 transcript、应用数据文件、密钥与工程目录各有来源／引用，不能只覆盖 smartdd.db；备份自身携带的维护状态、store identity、迁移日志也要核验。保留新库与新历史，优先使用兼容版本或只读导出。明确恢复必须使用独立恢复副本及一致的业务资源，保留时间切点之后的数据；当前没有实现自动数据反向迁移。

T3 的层级不同：servicePreflight 会拒绝更高 migration id 或未知／冲突历史；databaseMigrationHead 只读取得记录；Migrations.test 明确包含底层迁移器在更高 V2 id 下返回空变更的用例。故不能把 T3 底层 runMigrations 的返回当作安全降级承诺，参考的是启动／更新预检与迁移执行分层。这里只读核对 T3 源码及测试，没有执行 T3 运行时。

限制：合成未来表用于验证版本机制，不含最终 M14 全表。镜像回退为显式夹具，提交回调为注入，不是本轮进程崩溃。macOS arm64 单机；历史安装包、全部平台、外部旧宿主竞争、库外文件统一恢复及完整交接仍待验。Q50 从待验变为部分，不能声称任何旧版均安全或产品降级已可用。

首轮驱动缺 ResourceStore 导出，在建立隔离基线库后失败，未执行维护迁移。补充导出后七项通过；首轮脚本／构建记录／数据库保留。复跑：在 SmartDD cwd 运行 build.mjs，再运行 probe.mjs；所有数据库、门闩及备份均位于探针 attempt 目录。

[结果](result.json) · [运行审计](runtime-audit.json) · [源码依据](source-review.json) · [摘要](archive-manifest.json) · [脚本、数据库与备份](raw-evidence.tar.gz)。
''')
section='''### 11.3 数据库版本阻挡与备份恢复边界

[七项实际迁移检查](实验/20261114_数据库版本阻挡与迁移恢复验证/README.md)证明当前 SmartDD 已有可复用基础：planMigrations 按记录条数及逐条 hash／时间核验前缀；runMigrations 在同一事务写 Schema、水位和提交收据；macOS openManagedDatabase 经维护／共享门闩及重新核验后开放业务服务。使用当前 37 个迁移与合成第 38 个后缀，实际旧启动拒绝新账且没有改变逻辑数据库；同条数但历史摘要冲突也拒绝。这里的“旧”仅指本批当前基线相对合成新版本，不推广到所有历史安装包。

M14 正式实现接入已有迁移目录、打包清单与协调器。仅创建候选表或记录 m14_migration 不会改变正式版本水位，本轮已验证未登记额外表对旧规划器不可见。最终多绑定／运行外键重建、数据回填和提交收据须在正式迁移事务／受管维护范围中校验；不能把研究中分散的候选 SQL 直接当产品升级入口。备份前后核验宿主占用，业务服务不得在校验失败后继续初始化。macOS 之外已有普通迁移检查，但完整维护锁／备份入口的平台能力仍须分别验证。

当前协调器备份核验权限、内容摘要与备份本身的迁移／应用状态；提交成功而文件镜像滞后时，从数据库提交记录修复镜像，不回写旧备份。本轮在该恢复前插入后续业务及历史行，实际恢复保持它们不变；提交回执注入失败则让整个新迁移回滚。最终 M14 全表、真实进程中断和旧包演练仍待联合，不能由合成后缀替代。

**备份是恢复依据，不是可直接覆盖的降级包。** 本批备份缺少之后的新业务行，并保留 pending 维护状态；SQLite 备份也不包含库外原生历史、应用数据文件或项目代码。正常启动恢复沿提交账完成或拒绝，不自动替换数据库。需要人工恢复时先保留新库／新历史与关联资源，在独立副本核对水位、维护状态、store identity、日志、引用文件及时间切点后的新增数据，再选择兼容程序或导出路径；没有证明反向数据转换时不提供自动降级。不得通过删迁移记录、降水位、去掉维护标记或忽略错误强行启动旧版。大型 SVN 工程无需因此做全量代码快照。

T3 参考落在正确层级：其 servicePreflight 对未知／更高迁移阻挡，而底层迁移器测试允许在更高 V2 水位下返回无新迁移；只读 databaseMigrationHead 用于版本预检。WillYou 采用自己已有的较严格前缀校验，不复制 T3 底层“返回空数组”作为兼容结论。Q50 已取得局部运行证据，完整应用／数据回退、所有平台与旧包边界仍待验证。

'''
def tech(t):
 assert '### 11.3 'not in t;t=t.replace('## 12. 运行资源、配置与版本',section+'## 12. 运行资源、配置与版本');t=t.replace('完整入口回退及 Q50 数据版本回退未验证前，不宣称完整降级可用。','完整入口回退未闭环；Q50 已取得 §11.3 的当前迁移／启动阻挡及恢复证据，仍不宣称完整应用／数据降级可用。');return t
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 assert '### 4.76 'not in t
 t=t.replace('| Q50 | 应用版本回退与数据备份不会静默丢新历史 | E03／11；T35 | 待验；候选 SQLite 原型不代表旧应用能打开新库，必须定义版本阻挡和保留副本流程 |','| Q50 | 应用版本回退与数据备份不会静默丢新历史 | E03／11；T35 | **部分**：§4.76 用当前实际迁移器／受管启动、维护门闩／备份／协调器验证更高水位及同长度摘要冲突拒绝、提交失败回滚和已提交恢复保留后续数据；无登记研究表对版本守卫不可见。合成未来后缀不代表最终 M14 全表，真实旧包／其他平台／库外资源恢复及完整降级仍待验 |')
 return t.replace('## 5. 失败与驱动修正','''### 4.76 数据库版本阻挡、正式迁移协调与恢复

[七项检查](实验/20261114_数据库版本阻挡与迁移恢复验证/README.md)通过：使用全部 37 个当前迁移加合成第 38 个后缀，实际维护门闩、lsof 前后占用检查、备份与协调器完成提交；当前规划器／执行器及 macOS 受管启动拒绝更高水位并保留原逻辑数据，同长度历史摘要冲突也拒绝。提交回调失败使 Schema／业务行／迁移账整体回滚；显式将文件镜像置回 backed-up 后，实际协调器按提交记录恢复且保留升级后的数据。

反例确认：不登记正式迁移的研究表对旧版本守卫不可见；备份缺少之后的数据且包含 pending 维护状态，不是可直接打开的旧版降级包。SQLite 不包含库外原生历史／业务资源。技术方案 §11.3 收口复用正式迁移链、前后占用核验、提交恢复不覆盖新库和独立副本核对。T3 的 servicePreflight 与底层迁移器职责从实际源码／测试区分，未执行 T3 运行时。

首轮驱动缺 ResourceStore 导出而失败，未进入维护迁移；补充导出后七项通过，首轮记录保留。合成新 Schema、镜像夹具与回调故障，不是最终 M14 全表／真实旧包／SIGKILL 验收。Q50 推进为部分；其他平台、完整反向转换、库外一致恢复和候选 M14 正式迁移仍待验。各归档数据库完整性／外键通过，产品与原型未改。

## 5. 失败与驱动修正''')
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：数据库版本／迁移恢复七项检查通过，验证当前实际受管启动拒绝更高迁移水位、提交失败整体回滚、已提交恢复保留后续数据。备份包含维护状态且不覆盖库外历史，不能直接当降级包。见[技术方案 §11.3](技研/技术方案.md)，Q50 推进为部分。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)审视需求与设计剩余缺口，继续验证历史导入、业务与运行接线及明确的协议分支；复用已证明的迁移机制，不另造恢复系统，不把合成后缀当最终 M14 迁移通过。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'stagedFiles':len(entries),'checks':7,'archiveFiles':len(files),'sqliteFiles':len(dbs),'sourceInputs':len(build['sources'])}))
