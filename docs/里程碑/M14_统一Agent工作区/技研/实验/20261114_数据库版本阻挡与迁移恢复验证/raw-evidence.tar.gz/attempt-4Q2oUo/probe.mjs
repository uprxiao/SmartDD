import assert from 'node:assert/strict';
import {createHash,randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,statSync} from 'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2)),sha=b=>createHash('sha256').update(b).digest('hex');
const {bundledMigrations,planMigrations,runMigrations,ResourceStore,coordinateMigrations,acquireDatabaseAccess,assertNoForeignDatabaseHolders,MigrationJournals,openDbClient,openManagedDatabase}=actual;
const base=bundledMigrations(),checks=[],fixtures=[],preflights=[];let problem,lease;
const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
function fixture(name){const dir=out+'/'+name;mkdirSync(dir);const file=dir+'/smartdd.db',client=openDbClient(file);runMigrations(client.sqlite,base);client.sqlite.prepare('INSERT INTO projects(id,name,created_at,updated_at) VALUES(?,?,1,1)').run('before','synthetic before upgrade');const store=new ResourceStore(client.sqlite,dir);const f={dir,file,client,db:client.sqlite,store,closed:false};fixtures.push(f);return f;}
const migrations=future=>[...base,{idx:base.at(-1).idx+1,tag:'research_m14_future',when:base.at(-1).when+1,sql:future,hash:sha(future)}];
const signature=db=>sha(JSON.stringify(db.prepare("SELECT name,sql FROM sqlite_master WHERE type='table' ORDER BY name").all().map(t=>({name:t.name,sql:t.sql,rows:db.prepare('SELECT * FROM "'+t.name.replaceAll('"','""')+'"').all().map(r=>JSON.stringify(r)).sort()}))));
try{
 let f,target,journal,backup;
 await check('V01','actual maintenance coordinator backs up and commits a future migration',async()=>{
  f=fixture('future');target=migrations('CREATE TABLE research_m14_history(id TEXT PRIMARY KEY,body TEXT NOT NULL);');lease=await acquireDatabaseAccess(f.dir,'maintenance');
  const result=await coordinateMigrations({store:f.store,lease,buildId:'isolated-m14-future',migrations:target,assertNoForeignHolders:async()=>{const proof=await assertNoForeignDatabaseHolders(f.file);preflights.push(proof);return proof;}});assert.deepEqual(result,['research_m14_future']);
  journal=new MigrationJournals(f.store,lease).list()[0];assert.equal(journal.state,'complete');backup=f.dir+'/backups/m10/'+journal.backup.operationId+'/smartdd.db';assert.equal(sha(readFileSync(backup)),journal.backup.sha256);assert.equal(statSync(backup).mode&0o777,0o600);
  const copy=new Database(backup,{readonly:true,fileMustExist:true});try{assert.equal(planMigrations(copy,base).pending.length,0);assert(!copy.prepare("SELECT 1 FROM sqlite_master WHERE name='research_m14_history'").get());assert.equal(copy.prepare('SELECT name FROM projects WHERE id=?').get('before').name,'synthetic before upgrade');save('backup-maintenance-state.json',copy.prepare('SELECT * FROM capability_store_state').all());}finally{copy.close();}
  return{oldMigrationCount:base.length,newMigrationCount:target.length,backupHashVerified:true,backupPermission:'0600',actualForeignHolderChecks:preflights.length,coordinatorCommitted:true};
 });
 await check('V02','current old reader and actual managed startup reject the newer journal',async()=>{
  f.db.prepare('INSERT INTO research_m14_history VALUES(?,?)').run('new-history','synthetic after upgrade');f.db.prepare('INSERT INTO projects(id,name,created_at,updated_at) VALUES(?,?,2,2)').run('after','synthetic later business');const before=signature(f.db);
  assert.throws(()=>planMigrations(f.db,base),/请使用更新版本/);assert.throws(()=>runMigrations(f.db,base),/请使用更新版本/);assert.equal(signature(f.db),before);
  f.client.close();f.closed=true;lease.release();lease=null;await assert.rejects(openManagedDatabase(f.file),/请使用更新版本/);const ro=new Database(f.file,{readonly:true,fileMustExist:true});try{assert.equal(signature(ro),before);}finally{ro.close();}
  f.client=openDbClient(f.file);f.db=f.client.sqlite;f.store=new ResourceStore(f.db,f.dir);f.closed=false;lease=await acquireDatabaseAccess(f.dir,'maintenance');return{oldPlannerRejected:true,oldMigratorRejected:true,actualManagedStartupRejected:true,logicalDatabaseUnchanged:true};
 });
 await check('V03','commit recovery repairs journal mirror and preserves post-upgrade business data',async()=>{
  const files=new MigrationJournals(f.store,lease),entry=files.list()[0];assert.equal(entry.state,'complete');
  // Explicitly simulate a lost file-mirror update; no SIGKILL claim.
  const journals=await import('node:fs/promises');const find=async dir=>{for(const e of await journals.readdir(dir,{withFileTypes:true})){const p=dir+'/'+e.name;if(e.isDirectory()){if(e.name!=='backups'){const v=await find(p);if(v)return v;}}else if(e.name===entry.operationId+'.json')return p;}};
  const path=await find(f.dir);assert(path,'journal mirror absent');const prior=JSON.parse(readFileSync(path,'utf8'));assert.equal(prior.state,'complete');writeFileSync(path,JSON.stringify({...prior,state:'backed-up'})+'\n');
  const before=signature(f.db);assert.deepEqual(await coordinateMigrations({store:f.store,lease,buildId:'isolated-m14-future',migrations:target,assertNoForeignHolders:()=>assertNoForeignDatabaseHolders(f.file)}),[]);assert.equal(files.list()[0].state,'complete');assert.equal(signature(f.db),before);assert.equal(f.db.prepare('SELECT body FROM research_m14_history WHERE id=?').get('new-history').body,'synthetic after upgrade');
  return{mirrorStateInjected:true,actualCoordinatorRepair:true,noBackupRestore:true,laterBusinessAndHistoryPreserved:true};
 });
 await check('V04','old backup omits later rows and is not an automatic rollback package',async()=>{
  const receipt=JSON.parse(readFileSync(f.dir+'/backups/m10/'+journal.backup.operationId+'/operation.json','utf8'));assert.equal(receipt.state,'verified');assert.equal(receipt.sha256,sha(readFileSync(backup)));
  const separate=out+'/read-only-recovery-copy';mkdirSync(separate);copyFileSync(backup,separate+'/smartdd.db');const ro=new Database(separate+'/smartdd.db',{readonly:true,fileMustExist:true});try{assert(!ro.prepare("SELECT 1 FROM projects WHERE id='after'").get());assert(!ro.prepare("SELECT 1 FROM sqlite_master WHERE name='research_m14_history'").get());assert.equal(planMigrations(ro,base).pending.length,0);assert.equal(ro.prepare('SELECT maintenance_state FROM capability_store_state').get().maintenance_state,'pending');}finally{ro.close();}
  writeFileSync(f.dir+'/native-history-fixture.txt','synthetic independent native history after upgrade');assert.equal(readFileSync(f.dir+'/native-history-fixture.txt','utf8'),'synthetic independent native history after upgrade');
  return{backupPredatesLaterBusiness:true,backupStillContainsMaintenanceState:true,readOnlyInspectionOnly:true,originalDatabaseNeverOverwritten:true,nativeHistoryNotPartOfSqliteBackup:true,noWorkingCopySnapshot:true};
 });
 lease.release();lease=null;
 await check('V05','unregistered research tables are invisible to version guard',async()=>{
  const u=fixture('unregistered');u.db.exec('CREATE TABLE m14_unregistered_research(id TEXT PRIMARY KEY)');u.db.prepare('INSERT INTO m14_unregistered_research VALUES(?)').run('new-row');const before=signature(u.db);assert.equal(planMigrations(u.db,base).pending.length,0);assert.deepEqual(runMigrations(u.db,base),[]);assert.equal(signature(u.db),before);
  return{currentGuardDoesNotInspectArbitraryExtraTables:true,notProofAdditiveTableIsIncompatible:true,m14ProductionMustRegisterMigration:true};
 });
 await check('V06','failed commit receipt rolls back new schema data and migration watermark together',async()=>{
  const u=fixture('failed-commit'),next=migrations("CREATE TABLE research_failed(id TEXT PRIMARY KEY);--> statement-breakpoint\nINSERT INTO projects(id,name,created_at,updated_at) VALUES('failed','should rollback',1,1);");const before=signature(u.db);assert.throws(()=>runMigrations(u.db,next,{recordCommit:()=>{throw Error('controlled commit receipt failure');}}),/controlled commit receipt failure/);assert.equal(signature(u.db),before);assert.equal(planMigrations(u.db,base).pending.length,0);return{receiptFaultInjected:true,schemaRolledBack:true,businessRowRolledBack:true,journalRolledBack:true};
 });
 await check('V07','same-length conflicting migration history is rejected before mutation',async()=>{
  const u=fixture('conflicting-journal');u.db.prepare('UPDATE __drizzle_migrations SET hash=? WHERE id=(SELECT max(id) FROM __drizzle_migrations)').run('0'.repeat(64));const before=signature(u.db);assert.throws(()=>planMigrations(u.db,base),/迁移记录与当前程序不一致/);assert.throws(()=>runMigrations(u.db,base),/迁移记录与当前程序不一致/);assert.equal(signature(u.db),before);return{countAloneInsufficient:true,conflictingHashRejected:true,databaseUnchanged:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
finally{
 lease?.release();for(const f of fixtures){if(!f.closed){assert.equal(f.db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(f.db.pragma('foreign_key_check'),[]);f.client.close();f.closed=true;}}
}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:problem??null,preflights,scope:'Actual current migration planner/runner, macOS managed startup, persistent maintenance gate, foreign-holder preflight, backup and coordinator. Synthetic future suffix and isolated data; journal-mirror and commit failures injected, no host SIGKILL or packaged application rollback. No live database touched.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
