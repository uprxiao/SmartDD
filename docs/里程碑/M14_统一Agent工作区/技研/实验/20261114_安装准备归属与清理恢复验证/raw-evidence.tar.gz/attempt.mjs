import assert from 'node:assert/strict';
import {mkdirSync,lstatSync,realpathSync,readdirSync,rmSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
const identity=path=>{const s=lstatSync(path,{bigint:true});assert(s.isDirectory()&&!s.isSymbolicLink(),'STAGE_NOT_DIRECTORY');return{dev:String(s.dev),ino:String(s.ino)}};
const same=(a,b)=>assert.deepEqual(a,b,'STAGE_IDENTITY_CHANGED');
const tx=(store,fn)=>actual.withResourceLock(store.root,()=>store.sqlite.transaction(fn).immediate());
function coordinates(store,row){const parent=join(store.root,'native-preparation');assert.equal(row.stage,join(parent,'attempt-'+row.id));assert.equal(realpathSync(parent),parent);same(identity(parent),JSON.parse(row.parent_identity));return parent}
function inspectPartial(store,row,manifest){coordinates(store,row);assert(row.stage_identity,'STAGE_ALLOCATION_UNCERTAIN');same(identity(row.stage),JSON.parse(row.stage_identity));const known=new Map(manifest.files.map(x=>[x.path,x])),directories=new Set();for(const f of manifest.files)for(let p=dirname(f.path);p!=='.';p=dirname(p))directories.add(p);
 const walk=(dir,rel='')=>{for(const name of readdirSync(dir)){const path=join(dir,name),key=rel?rel+'/'+name:name,s=lstatSync(path);assert(!s.isSymbolicLink(),'UNEXPECTED_STAGE_LINK');if(s.isDirectory()){assert(directories.has(key),'UNEXPECTED_STAGE_DIRECTORY');walk(path,key)}else{const file=known.get(key);assert(file&&s.isFile()&&s.nlink===1&&s.uid===process.getuid()&&s.size<=file.size,'UNEXPECTED_STAGE_FILE')}}};walk(row.stage);same(identity(row.stage),JSON.parse(row.stage_identity));}
export async function recoverAttempts(store,reader,jobId,manifest,hash,assertOwner,checkpoint){const rows=store.sqlite.prepare("SELECT * FROM m14_install_attempt WHERE job_id=? AND state IN ('planned','copying','cleanup-deleting') ORDER BY rowid").all(jobId);
 for(const row of rows)await actual.withResourceLock(store.root,()=>{
  assertOwner();const current=store.sqlite.prepare('SELECT * FROM m14_install_attempt WHERE id=?').get(row.id);assert.deepEqual(current,row,'ATTEMPT_CHANGED');assert.equal(row.manifest_hash,hash);assert.equal(reader.state(JSON.parse(row.owner_identity)),'stopped','ATTEMPT_OWNER_LIVE_OR_UNKNOWN');coordinates(store,row);
  if(!existsSync(row.stage)){assert(['planned','cleanup-deleting'].includes(row.state),'MISSING_COPYING_STAGE');store.sqlite.prepare("UPDATE m14_install_attempt SET state='removed' WHERE id=?").run(row.id);return}
  inspectPartial(store,row,manifest);assert(!store.sqlite.prepare("SELECT 1 FROM m14_install_job WHERE prepared_path=? AND phase IN ('prepared','published','activated')").get(row.stage),'STAGE_ALREADY_PREPARED');
  store.sqlite.prepare("UPDATE m14_install_attempt SET state='cleanup-deleting' WHERE id=?").run(row.id);checkpoint('partial-cleanup-intent');inspectPartial(store,row,manifest);rmSync(row.stage,{recursive:true});checkpoint('partial-cleanup-removed');store.sqlite.prepare("UPDATE m14_install_attempt SET state='removed' WHERE id=?").run(row.id);
 });
}
export async function allocate(store,reader,jobId,hash,assertOwner,checkpoint){const parent=join(store.root,'native-preparation');mkdirSync(parent,{recursive:true,mode:0o700});assert.equal(realpathSync(parent),parent);const id=randomUUID(),stage=join(parent,'attempt-'+id),parentIdentity=identity(parent),owner=reader.read(process.pid);assert(owner);
 await tx(store,()=>{assertOwner();store.sqlite.prepare("INSERT INTO m14_install_attempt VALUES(?,?,?,?,NULL,?,'planned',?)").run(id,jobId,stage,JSON.stringify(parentIdentity),JSON.stringify(owner),hash)});checkpoint('attempt-planned');
 same(identity(parent),parentIdentity);mkdirSync(stage,{mode:0o700});checkpoint('attempt-directory-created');const stageIdentity=identity(stage);await tx(store,()=>{assertOwner();same(identity(parent),parentIdentity);same(identity(stage),stageIdentity);store.sqlite.prepare("UPDATE m14_install_attempt SET stage_identity=?,state='copying' WHERE id=? AND state='planned'").run(JSON.stringify(stageIdentity),id)});checkpoint('attempt-copying');
 return{id,stage,assertStage:()=>{same(identity(parent),parentIdentity);same(identity(stage),stageIdentity)}};
}
