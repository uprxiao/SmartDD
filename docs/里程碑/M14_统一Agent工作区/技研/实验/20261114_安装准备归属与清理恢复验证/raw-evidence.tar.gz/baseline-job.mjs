import assert from 'node:assert/strict';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import actual from './actual.cjs';
import {manifestId,prepare,inspect,publish,reopenPrepared,recoverPublished,activateJob} from './artifact.mjs';
export const get=(db,id)=>db.prepare('SELECT * FROM m14_install_job WHERE id=?').get(id);
export async function execute(store,reader,input,checkpoint=()=>{}){
 const db=store.sqlite,{manifest,hash}=manifestId(input.manifest),requestHash=actual.digest(actual.canonicalJson({manifest,source:input.source,expectedRevision:input.expectedRevision})),observed=get(db,input.id),owner=reader.read(process.pid);assert(owner,'OWNER_UNAVAILABLE');let priorState;
 if(observed?.owner_instance&&observed.phase!=='activated')priorState=reader.state({pid:observed.pid,startedAt:observed.birth});
 const claim=await actual.withResourceLock(store.root,()=>db.transaction(()=>{const current=get(db,input.id);assert.equal(actual.canonicalJson(current??null),actual.canonicalJson(observed??null),'CLAIM_CHANGED');if(current){assert.equal(current.request_hash,requestHash,'INSTALL_REQUEST_CONFLICT');if(current.phase==='activated')return{done:JSON.parse(current.result_json)};assert(priorState==='stopped','INSTALL_OWNER_LIVE_OR_UNKNOWN');db.prepare('UPDATE m14_install_job SET owner_instance=?,pid=?,birth=?,recovery_count=recovery_count+1 WHERE id=?').run(store.instanceId,owner.pid,owner.startedAt,input.id);}else db.prepare("INSERT INTO m14_install_job(id,request_hash,manifest_json,source_path,expected_revision,phase,owner_instance,pid,birth) VALUES(?,?,?,?,?,'requested',?,?,?)").run(input.id,requestHash,actual.canonicalJson(manifest),input.source,input.expectedRevision,store.instanceId,owner.pid,owner.startedAt);return{done:null};}).immediate());
 if(claim.done)return{...claim.done,replayed:true};checkpoint('job-created');
 const assertOwner=()=>{const row=get(db,input.id);assert(row.owner_instance===store.instanceId&&row.pid===owner.pid&&row.birth===owner.startedAt,'INSTALL_OWNER_CHANGED');};
 const update=(phase,prepared)=>actual.withResourceLock(store.root,()=>db.transaction(()=>{assertOwner();db.prepare('UPDATE m14_install_job SET phase=?,prepared_path=COALESCE(?,prepared_path) WHERE id=?').run(phase,prepared??null,input.id);}).immediate());
 let resource;try{resource=store.get('agent-native-runtime:'+hash);}catch(e){if(e.code!=='NOT_FOUND')throw e;}
 let handle;
 if(resource){const target=store.directory(resource),staging=join(store.root,'staging',resource.operationId??''),saved=get(db,input.id).prepared_path;const found=[target,staging,saved].find(p=>p&&existsSync(p));if(found)handle=await reopenPrepared(store,manifest,found);else{handle=await prepare(store,manifest,input.source,{onChunk:progress=>{if(progress.file==='payload.bin'&&progress.bytes>=512*1024)checkpoint('copy-in-progress');}});await update('prepared',inspect(handle).stage);}assertOwner();resource=await recoverPublished(handle,resource.operationId);}
 else{const saved=get(db,input.id).prepared_path;handle=saved&&existsSync(saved)?await reopenPrepared(store,manifest,saved):await prepare(store,manifest,input.source,{onChunk:progress=>{if(progress.file==='payload.bin'&&progress.bytes>=512*1024)checkpoint('copy-in-progress');}});await update('prepared',inspect(handle).stage);checkpoint('prepared');resource=await publish(handle);}
 await update('published');checkpoint('published');
 const result=await activateJob(store,handle,input.expectedRevision,assertOwner,r=>{db.prepare("UPDATE m14_install_job SET phase='activated',result_json=? WHERE id=?").run(actual.canonicalJson(r),input.id);if(input.failActivation)throw Error('INJECTED_ACTIVATION_FAILURE');});checkpoint('activated');return{...result,replayed:false};
}
