import {readFileSync,writeSync} from 'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import {execute} from './job.mjs';
const input=JSON.parse(readFileSync(process.argv[2],'utf8')),db=new Database(input.db);db.pragma('foreign_keys=ON');const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),block=new Int32Array(new SharedArrayBuffer(4));
const checkpoint=point=>{if(input.pause===point){writeSync(1,JSON.stringify({type:'checkpoint',point,pid:process.pid,identity:reader.read(process.pid)})+'\n');Atomics.wait(block,0,0);}};
const store=new actual.ResourceStore(db,input.root,p=>checkpoint('resource-'+p),{processes:reader});try{const result=await execute(store,reader,input.job,checkpoint);writeSync(1,JSON.stringify({type:'result',result})+'\n');}catch(e){writeSync(1,JSON.stringify({type:'error',message:e.message,code:e.code,stack:e.stack})+'\n');process.exitCode=1;}finally{db.close();}
