from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_安装准备归属与清理恢复验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==9 and not r['error'];p=Path(r['out']);b=json.loads((root/'build.json').read_text())
for x in b['sources']:assert sha(Path(x['path']).read_bytes())==x['sha256']
assert sha((root/'actual.cjs').read_bytes())==b['output']['sha256']
workers=json.loads((p/'workers.json').read_text());assert len(workers)==21 and sum(x['exit']['signal']=='SIGKILL'for x in workers)==11 and sum(x['exit']['code']==0 for x in workers)==6 and sum(x['exit']['code']==1 for x in workers)==4
refs=[repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/applications/process-identity.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'actualBuild':b,'candidates':[{'path':x.name,'sha256':sha(x.read_bytes())}for x in [root/'attempt.mjs',root/'job.mjs',root/'artifact.mjs',root/'baseline-job.mjs',root/'baseline-artifact.mjs']],'scope':'Current actual ResourceStore and process identity; temporary attempt table/job/artifact changes only. Controlled process death, not power loss, hostile filesystem isolation, actual native package lease/GC or product integration.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[(root/n,n)for n in ['probe.mjs','attempt.mjs','job.mjs','baseline-job.mjs','baseline-artifact.mjs','job.sql','worker.mjs','artifact.mjs','build.mjs','build.json','actual.cjs','prepare.py','source-review.json']]+[(x,str(x.relative_to(root)))for x in sorted(p.iterdir())if x.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x,n in files:tar.add(x,arcname=n,recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':n,'sha256':sha(x.read_bytes())}for x,n in files]}
for n,v in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 安装准备归属与清理恢复验证

日期：2026-11-14。关联 R11／Q56。对前轮复制中断半成品遗留的独立候选修正验证，不是产品功能实现。

## 候选变化

实际 ResourceStore 和进程身份组件保持当前源码。临时安装器新增 attempt 表：安装请求与每次准备分开，复制前记录专用路径、原 owner 内核身份、父目录和 stage 物理身份。状态分为 planned、copying、prepared、cleanup-deleting、removed、consumed。发布／激活继续沿用前轮合同。

登记计划后创建目录；只有物理身份写入 copying 才能开始复制。恢复先确认旧 attempt owner 已停止、路径和身份一致，且部分文件属于清单限定的路径／类型／大小范围，再记录清理意图、清理、记录完成。新准备使用新 attempt，旧行不被覆盖。对已登记 stage 的普通复制失败也保留现场，避免未经归属核对的自动删除。

## 实际检查

| 编号 | 中断／异常 | 结果 |
| --- | --- | --- |
| T01 | planned 已提交、目录尚未创建时退出 | 对账为无剩余材料，记录旧 attempt removed，以新 attempt 完成 |
| T02 | copying 身份已提交、尚未写入首字节时退出 | 清理已确认的空准备目录并重建 |
| T03 | 文件部分写入时退出 | 旧半成品有归属，清理后新准备完整发布；不留下未关联目录 |
| T04 | 目录已创建、物理身份尚未提交时退出 | 保持 planned／不明现场，拒绝自动删除或继续 |
| T05 | cleanup-deleting 已提交、删除前退出 | 沿原 attempt 重新检查并完成清理／新准备 |
| T06 | 目录已删、removed 尚未提交时退出 | 用原清理意图对账缺失，不误认为未登记材料 |
| T07 | 半成品中混入未知文件 | 拒绝自动清理，未知文件及原默认不变 |
| T08 | 原路径换成新目录 | 拒绝清理新目录，原材料和替换目录均保留 |
| T09 | 完整 prepared 的内容损坏 | 继续按完整性失败处理，不能套用半成品清理规则 |

9 项检查通过。21 个受控 worker 均有终态：11 次预定 SIGKILL、6 次成功、4 次预期拒绝。最终 6 个 consumed、5 个 removed；2 个 copying、1 个 planned、1 个 prepared 均是上述拒绝场景保留的记录，不被计作可用安装。

## 边界

本轮改善了 §4.85 的已登记复制中断路径。目录分配后但物理身份尚未落账的窗口仍保守保留，不能宣称所有安装中断均可自动恢复。半成品的完整内容摘要尚不存在，清理依据是私有目录归属及允许的文件集合，不是任意字节来源证明；不适用于用户目录或外部程序目录。

没有证明最后身份检查到删除之间对同用户恶意并发替换的原子隔离。没有断电／内核崩溃耐久性测试；进程退出恢复不能替代文件及目录 fsync 顺序验证。真实包、网络中断、资源租约／GC、在用原生会话和其他平台仍需联合。产品和共享原型未改。

## 复现与证据

执行 `node probe.mjs`，需已记录 Node／SQLite／zod 与 Mac 进程身份工具。实际模块由前轮当前源码构建，本轮先复核 379 个源码摘要与 bundle；归档保留实际 bundle、构建脚本、候选改前／改后文件及所有原始 worker 记录。路径仍含本机依赖绝对路径，不是独立发行包。

[结果](result.json) · [源码与输入](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 old='该缺口尚未修复，不能称安装恢复完整通过。';new='后续[准备归属与清理恢复实验](实验/20261114_安装准备归属与清理恢复验证/README.md)补了临时候选修正，已登记的复制中断不再失去路径归属；未确认目录身份和未知材料仍保留，不能称安装恢复完整通过。';assert old in t;t=t.replace(old,new)
 old='本批没有实现上述准备目录登记／清理，也没有验证断点续传。资源版本切换只针对后续默认选择；';new='准备目录登记／清理目前仅在隔离候选实现并取得九项证据，没有接产品或验证断点续传。资源版本切换只针对后续默认选择；';assert old in t;t=t.replace(old,new)
 anchor='默认指针与安装成功回执必须在同一事务提交；';assert anchor in t
 add='''准备恢复使用原 attempt 的阶段语义：planned 且目录不存在可对账结束；已创建但物理身份未提交，不能按“空目录”猜测归属；copying 且 owner 已停止、父／stage 身份及限定内容可核验，才进入 cleanup-deleting。删除意图先落账，删除后再记 removed，因此“删除后回执前退出”可沿原意图对账。下一准备生成新 attempt，不抹掉旧现场。prepared／published 的损坏继续走完整性失败，不降格为可随意丢弃的半成品。

本轮拒绝了身份未确认、未知文件、同路径目录替换和完整准备损坏；并未实现所有未知现场的自动修复。清理权限仅属于专用私有准备目录，不能扩到用户指定 CLI 或工程目录。进程 SIGKILL 证据不等于断电耐久性，最终文件／目录同步顺序与最后校验至删除的并发边界需按平台继续核验。

'''
 return t.replace(anchor,add+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.86 'not in t
 add='''### 4.86 安装 attempt 归属与部分准备清理

[临时候选修正](实验/20261114_安装准备归属与清理恢复验证/README.md)取得九项检查：复制前持久 attempt／目录身份，计划／copying／部分复制阶段退出后的对账，新 attempt 重新准备，以及清理意图前后真实 worker SIGKILL 恢复。已登记半成品不再丢失归属。目录身份未确认、未知文件、同路径替换、完整 prepared 损坏四种分支均保留并拒绝。

21 个 worker 均有终态，11 次预定 SIGKILL、6 次成功、4 次预期拒绝。实际 ResourceStore／内核身份未改，新增表与行为只在临时候选；完整资源租约／GC、原生会话、网络和断电耐久性未证明。技术方案 §12.1 收口 attempt 阶段、清理意图与不明现场边界；Q56 继续部分，不宣称所有中断自动恢复。

'''
 t=t.replace(anchor,add+anchor).replace('截至 §4.85，56 个宽口径问题项中','截至 §4.86，56 个宽口径问题项中')
 t=t.replace('Q56 本轮按已有安装证据与新增复制中断检查推进为部分，半成品归属／清理缺口未关闭。','Q56 已补临时候选的已登记半成品归属／清理恢复，不明分配与完整资源／会话联合仍未关闭。')
 old='准备目录归属／清理、原生 GC、真实会话升级与跨平台仍待验；不自动继承 T3 结论 |';new='§4.86 补候选 attempt 归属、清理中断恢复及未知现场拒绝；完整资源占用／原生 GC、真实会话升级与跨平台仍待验；不自动继承 T3 结论 |';assert old in t;t=t.replace(old,new)
 t=t.replace('复制归属／恢复清理（§4.85 已复现半成品遗留）','复制归属／完整资源联合（§4.85 复现半成品遗留，§4.86 已补候选 attempt／清理恢复）')
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：临时候选补上复制前 attempt／目录身份，已登记半成品和清理中断可对账；身份不明、未知文件、目录替换或完整准备损坏保持拒绝。见[技术方案 §12.1](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对准备／发布／真实 run 的完整资源关联、在用升级与清理恢复，以及其余业务和执行范围的联合证据。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'checks':9,'archiveFiles':len(files),'partial':49,'pending':4}))
