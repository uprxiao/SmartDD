from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_共享目录串行准入与启动身份验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and not r['error'];p=Path(r['out']);assert all(x['exitCode']==0 for x in r['processes']);assert len(r['launches'])==2
failure=json.loads((root/'attempt-lxbH2l/result.json').read_text());assert failure['checks'][-1]['id']=='A05'and failure['checks'][-1]['status']=='failed'and 'Missing expected exception' in failure['error']
state=json.loads((p/'gate-state.json').read_text());assert all(x['state']=='released'for x in state['leases'])
b=json.loads((p/'input-build.json').read_text())
for x in b['sources']+b['outputs']:assert sha(Path(x['path']).read_bytes())==x['sha256']
refs=[repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/__tests__/run-fixture.ts',repo/'src/main/core/projects/dir-status.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'candidateSources':[{'path':x.name,'sha256':sha(x.read_bytes())}for x in [root/'gate.mjs',root/'probe.mjs',root/'before-fix-gate.mjs',root/'before-fix-probe.mjs']],'actualBoundary':'Unchanged actual run registry, activities, process identity and fixture. Candidate SQLite directory gate in temporary folder, controlled Node writers. No SDK or product launcher. Scope-known=true is valid only for the controlled fixture script, not proof of arbitrary descendants.','failure':'Before-fix descriptor held WC root inode only; same-path child-directory replacement went undetected. Candidate adds cwd device/inode. Original broader fork race remains unproven.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[(root/n,n)for n in ['probe.mjs','gate.mjs','writer.cjs','before-fix-gate.mjs','before-fix-probe.mjs','prepare.py','source-review.json']]
for a in sorted(root.glob('attempt-*')):
 files += [(x,str(x.relative_to(root)))for x in sorted(a.iterdir())if x.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x,n in files:tar.add(x,arcname=n,recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':n,'sha256':sha(x.read_bytes())}for x,n in files]}
for n,v in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 共享目录串行准入与启动身份验证

日期：2026-11-14。关联 R06／R09、Q31–33。独立技术验证，不是产品实现或验收。

## 执行范围

将原候选路径门槛扩为两个实际宿主子进程争抢同一 SQLite 租约；实际 CapabilityRunRegistry 管理合成任务、原生进程身份、withActivity 和资源释放。Agent 替身是本轮捕获 PID 的受控 Node 写者，不使用真实 SDK 或模型。新建本机 SVN 仓库／工作副本和符号链接，无用户数据。

候选首版不开放并行只读；requestedAccess、提示词、nativeSandbox、readOnlyHint 仅作为请求／审计信息，实际都按可能写入者取得租约。没有声称已实现经过认证的并行只读分支。

| 检查 | 结果 |
| --- | --- |
| A01 两个不同项目标签通过 SVN 根下不同子目录／别名申请只读 | 两者排队，未启动后继 Agent；根内兄弟目录同样冲突 |
| A02 原生已退出但实际 withActivity 仍在途 | run 仍 stopping，租约不能释放，两请求继续排队 |
| A03 实际 run 已 stopped，但执行范围证据未知 | 租约仍保留；不能仅凭 stopped 交棒 |
| A04 排空后两个宿主进程同时争抢 | 一方持有、一方排队；仅赢家启动受控写者，退出后才释放 |
| A05 同一路径下 SVN 子目录被替换 | 原候选漏检；补 cwd 物理身份后拒绝，恢复原物理目录后可复核 |
| A06 排队者获准后，输入路径被符号链接改向 | fork 前复核拒绝，未启动 Agent |

最终 6 项通过，四个本轮进程 exit 0，三份租约均释放。只有父与赢家两个受控 Agent 写者实际启动。其余两个进程负责候选调度争抢，不是业务 Agent。

## 保留的失败与修正

初次五项检查记录为 attempt-hC7xOy。随后增加“同路径子目录替换”回归，attempt-lxbH2l 在 A05 确定失败：仅比较 WC 根 dev／ino 与 cwd 字符串不能发现子目录物理替换。before-fix-gate.mjs／before-fix-probe.mjs 保存该失败输入。只在临时 gate 增加 cwdDevice／cwdInode，attempt-wBqnbl 全部六项通过。

初次五项运行未单独冻结那一版完整驱动，记录保留为探索上下文；修正结论依据有源码快照的六项失败／复验，不把初次记录补造为完整可复现基线。产品源码未改。

## 仍未证明

Gate 是候选，并未接产品；租约数据库与实际 owner 数据库分开，不证明二者跨库提交原子性、宿主 SIGKILL 恢复或长期公平性。本批没有跨进程恢复，不覆盖全部等待取消分支。受控脚本没有后台后代；scopeKnown 的真值只用于该脚本，不能作为任意 SDK／shell／MCP 后代已排空的证明。

物理身份复核证明能发现检查时已发生的变化，不消除最后检查与 fork 之间的路径竞争；不能宣称路径被 OS 原子锁定。多平台、完整 launcher、动态来源／权限变更以及真正只读准入仍待验证。六项通过不替代之前原生委派／业务链实验，也不把它们自动合并成端到端通过。

## 复现与证据

在已记录依赖存在的本机运行 `node probe.mjs`。依赖前轮 viewer-lifetime 实际服务 bundle、owner-probe SQLite／进程身份工具及本机 svn；input-build.json 核对执行前源码与产物摘要。原始脚本固定临时依赖绝对路径，不是独立发行包。回归前版本使用 before-fix 两文件，恢复为对应文件名后运行即可观察 A05 失败。

[结果](result.json) · [源码基线](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 old='目录声明至少保存用户入口、规范 cwd、协调范围、物理 dev／ino 与归属运行。';new='目录声明至少保存用户入口、规范 cwd、协调范围与归属运行，分别保存实际 cwd 和协调范围根的物理 dev／ino。两者不能合成一份根身份：同一 SVN 工作副本内，根目录未变而子目录可能已被同路径新目录替换。';assert old in t;t=t.replace(old,new)
 anchor='共享目录委派默认异步。';assert anchor in t
 add='''[串行准入与启动身份实验](实验/20261114_共享目录串行准入与启动身份验证/README.md)将候选 SQLite 门槛接到实际 run／activity／进程身份：两个宿主进程用不同项目标签、SVN 兄弟目录及路径别名申请“只读”，仍排队；原生退出但 activity 未结束、或执行范围未知，均不释放。排空后并发争抢只有一方持有并启动受控写者。请求的只读意图、工具注解和原生 sandbox 名称不直接提升准入权限，初期有效模式明确为“可能写入、需串行”。

该候选原来仅保留协调范围根的物理身份，实际复现同路径子目录替换漏检；增加 cwd dev／ino 后失败回归通过。最终 fork 前复核要同时核对两者。检查到 fork 之间仍有外部路径变化窗口，不能宣称已取得原子目录绑定；启动失败／身份不明保留未完成状态并对账，不靠重新解析同名目录自动继续。候选与实际 owner 目前分库，跨提交恢复、完整原生执行范围及生产 launcher 接线仍待联合验证。

'''
 return t.replace(anchor,add+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.84 'not in t
 add='''### 4.84 串行准入、排空与启动目录身份

[候选门槛联合实验](实验/20261114_共享目录串行准入与启动身份验证/README.md)取得六项证据：不同项目标签／SVN 兄弟目录／别名的只读声明仍排队；实际原生退出而 activity 未结束时不能释放；owner stopped 但范围未知仍保留；两个宿主进程竞争仅一方持有并启动。最终四个进程 exit 0，三份租约释放。

新增回归先复现仅保留 WC 根身份时的子目录同路径替换漏检，补 cwd 独立物理身份后通过；失败与修正源码保留。初次五项探索记录没有该版完整驱动快照，不冒充最终可复现基线。技术方案 §8.1 更新双身份与首版有效串行模式。

使用实际 run／activity／身份，执行器为受控 Node 脚本，不是 SDK；候选租约与 owner 分库，未证跨事务恢复、完整后代或最后检查至 fork 原子性。Q31–33 继续部分，不将前轮分散证据相加为产品端到端通过。

'''
 t=t.replace(anchor,add+anchor).replace('截至 §4.83，56 个宽口径问题项中','截至 §4.84，56 个宽口径问题项中')
 old='完整准入守卫、shell／Skill、插件业务和查询覆盖仍待验，不承诺全项目原子快照 |';new='§4.84 补候选串行准入／实际 activity 与双进程争抢；完整 launcher／scope、shell／Skill、插件业务和查询覆盖仍待验，不承诺全项目原子快照 |';assert old in t;t=t.replace(old,new)
 old='继续验证完整 scope／未知后台、无强制只读时串行准入守卫、查询覆盖、路径／fork 竞争及 Git 准备失败对账。';new='§4.84 补候选串行准入与实际 activity／多进程争抢、cwd 物理替换回归；继续验证完整 scope／未知后台、准入与 owner 提交恢复、查询覆盖、路径／fork 竞争及 Git 准备失败对账。';assert old in t;t=t.replace(old,new)
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：候选串行准入已接实际 run／activity 和双进程争抢；复现并修正临时候选漏检同路径子目录替换的问题，设计明确 cwd 与协调根分别核物理身份。见[技术方案 §8.1](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对准入／owner 提交恢复、启动路径竞争、查询覆盖和动态子树；真实供应商与产品集成条件独立保留。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'finalCases':6,'archiveFiles':len(files),'partial':48,'pending':5}))
