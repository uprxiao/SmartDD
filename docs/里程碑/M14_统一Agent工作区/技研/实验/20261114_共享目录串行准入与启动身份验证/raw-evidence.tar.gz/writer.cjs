require('fs').appendFileSync(process.argv[2],process.argv[3]+'\n');process.send({label:process.argv[3]});process.on('message',m=>{if(m==='stop'){process.disconnect();process.exit(0)}});
