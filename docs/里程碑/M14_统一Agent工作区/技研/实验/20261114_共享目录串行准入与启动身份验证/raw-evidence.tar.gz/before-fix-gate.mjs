import assert from 'node:assert/strict';
import {realpathSync,statSync,existsSync} from 'node:fs';
import {join,dirname,relative,sep} from 'node:path';
import Database from '/private/tmp/willyou-m14-owner-probe/node_modules/better-sqlite3/lib/index.js';
export function descriptor(input){const cwd=realpathSync(input);assert(statSync(cwd).isDirectory());let scope=cwd;for(let d=cwd;;d=dirname(d)){if(existsSync(join(d,'.svn'))){scope=d;break}if(dirname(d)===d)break}const s=statSync(scope,{bigint:true});return{input,cwd,scope,device:String(s.dev),inode:String(s.ino)}}
const contains=(a,b)=>{const r=relative(a,b);return r===''||r!=='..'&&!r.startsWith('..'+sep)&&!r.startsWith(sep)};
export class Gate {
 constructor(path){this.db=new Database(path);this.db.pragma('journal_mode=WAL');this.db.pragma('busy_timeout=5000');this.db.exec("CREATE TABLE IF NOT EXISTS leases(run_id TEXT PRIMARY KEY,descriptor TEXT NOT NULL,state TEXT NOT NULL); CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY,event TEXT NOT NULL,body TEXT NOT NULL)")}
 mark(event,body){this.db.prepare('INSERT INTO audit(event,body) VALUES(?,?)').run(event,JSON.stringify(body))}
 acquire(runId,input,request){return this.db.transaction(()=>{const d=descriptor(input);const policy={requestedAccess:request.requestedAccess,projectId:request.projectId,effectiveAccess:'potential-writer',reason:'parallel-readonly-not-enabled',claims:request.claims??null};for(const row of this.db.prepare("SELECT * FROM leases WHERE state='held'").all()){const held=JSON.parse(row.descriptor);if(row.run_id===runId){assert.deepEqual(d,held);return{state:'held',descriptor:d,policy}}if(contains(d.scope,held.scope)||contains(held.scope,d.scope)){const result={state:'queued',blockedBy:row.run_id,policy};this.mark('queued',{runId,...result});return result}}
 this.db.prepare("INSERT INTO leases VALUES(?,?,'held') ON CONFLICT(run_id) DO UPDATE SET descriptor=excluded.descriptor,state='held'").run(runId,JSON.stringify(d));const result={state:'held',descriptor:d,policy};this.mark('acquired',{runId,...result});return result}).immediate()}
 beforeFork(runId){const row=this.db.prepare("SELECT * FROM leases WHERE run_id=? AND state='held'").get(runId);assert(row,'NO_ACTIVE_LEASE');const d=JSON.parse(row.descriptor);assert.deepEqual(descriptor(d.input),d,'WORKSPACE_IDENTITY_CHANGED');return d}
 release(runId,drained){return this.db.transaction(()=>{assert(drained(),'OWNER_OR_SCOPE_NOT_DRAINED');const r=this.db.prepare("UPDATE leases SET state='released' WHERE run_id=? AND state='held'").run(runId);assert.equal(r.changes,1);this.mark('released',{runId})}).immediate()}
 close(){this.db.close()}
}
if(process.argv[2]==='--worker'){const gate=new Gate(process.argv[3]);process.on('message',m=>{if(m.op==='attempt'){try{process.send({id:m.id,result:gate.acquire(m.runId,m.path,m.request)})}catch(e){process.send({id:m.id,error:e.stack})}}else if(m.op==='stop'){gate.close();process.disconnect()}});process.send({ready:true})}
