from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_浏览器程序化运行授权与排空验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and not r.get('error');a=Path(r['out']);attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());events=json.loads((attempt/'events.json').read_text())if(attempt/'events.json').exists()else[];exits=[x for x in events if x['event']=='owned-exit']
 if(attempt/'final.sqlite').exists():
  assert len(exits)==3 and all(x['code']==(0 if x['id'].startswith('codex')else 143)for x in exits)
  db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
  for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM capability_run_activities WHERE state='active'"]:assert db.execute(query).fetchone()==(0,)
  db.close()
 else:assert not events and result['passed']==0
 attempts.append({'attempt':attempt.name,'passed':result['passed'],'error':result.get('error'),'nativeExits':exits,'finalDbVerified':(attempt/'final.sqlite').exists(),'probeSha256':sha((attempt/'probe.mjs').read_bytes()),'launchSha256':sha((attempt/'launch.mjs').read_bytes())})
assert len(attempts)==3 and sorted(x['passed']for x in attempts)==[0,5,6]
observed=json.loads((a/'observed-scopes.json').read_text());assert len(observed)>=14 and all(x['stable']and x['separate']for x in observed)
held=json.loads((a/'held-business-after-native-exit.json').read_text());assert held['run']['state']=='stopping' and any(x['state']=='active'for x in held['activities'])and any(x['state']!='released'for x in held['leases'])
granted=json.loads((a/'granted.json').read_text());assert len(granted['grants'])==2 and {g['mode']for g in granted['grants']}=={'observe','control'}
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes()
runtime={'attempts':attempts,'finalAttempt':a.name,'scope':r['scope'],'browserScopes':observed,'heldBusinessAfterNativeExit':held,'grants':granted,'initialFailures':['Browser fixture did not install/activate the browser builtin before selecting package; failed before any native launch.','Candidate launch.cancel retired delivery after native exit before actual withActivity settled; RUN_NOT_DRAINED. Added awaited activity completion to temporary launch composition; deterministic held-activity branch verified stopping/lease retention until release.'],'finalExitCount':3,'totalExitCount':6,'modelTurns':0};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/browser'/n for n in ['access.ts','automation.ts','service.ts']]+[repo/'src/main/core/applications'/n for n in ['modules/browser/index.ts','execution-context.ts','run-registry.ts','cli-gateway.ts','tool-service.ts']]+[repo/'scripts/applications/build-bundles.mjs',repo/'resources/applications/definitions.mjs',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'variants':['Programmatic session/run/retention candidates reused.','Electron stub throws on native window/session allocation.','Temporary build-fixture-bundles copies current definitions/assets but rebinds runtime hash to research bridge bundle; not original distributable package identity.','Launch candidate adds awaited per-run actual withActivity promises before retirement; no product modification.'],'transportBoundary':'ToolService entry=cli reaches actual adapter/module/context/browser service. Calls are initiated by trusted research host with owned real native runs, not through native shell, managed CLI binary/kernel gateway, SDK tools or UI.','t3Boundary':'T3 execution-session ownership and run scope remain architectural reference. BrowserAccess lifetime/grants belong to existing WillYou business services.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log','.md']and not(p.parent==root and p.name in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json'])];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 浏览器程序化运行授权与排空

2026-11-14；技术方案 §9.7，验证账 §4.68；R02／03／05／08／10，Q27／28／37。仅技术研究，产品／共享原型未改。

## 实际执行范围

真实 Codex 0.167.1 父运行、Claude SDK 0.3.321／native 2.1.321 子运行，以及同一父 task 切换到新 Claude run，均使用当前候选程序化 owner／ExecutionPlan 初始化。受信实验宿主调用实际 `ApplicationToolService(entry=cli) → ApplicationAdapterRegistry → ApplicationService.data → BrowserModuleData → ApplicationExecutionContexts → BrowserService／BrowserAccess`。没有模型请求，也没有通过原生 shell、willyou-app 二进制或 CLI socket；不能将此结果称为完整 SDK→CLI 端到端通过。

Electron 替身在创建窗口、session 或读取系统路径时直接抛错，本批不创建网页、不读登录态。使用实际浏览器 tab list 空结果、授权服务、暂停状态、审计表和运行生存期。资源包由当前 definitions／assets 生成，但 runtime hash 重绑至研究 bridge；不声称验证正式发布包。Agent adapter 和程序化接线沿用临时研究候选。

## 六项通过

| 检查 | 实际证据 |
| --- | --- |
| B01 真实 run 到现有浏览器处理器 | 两端已初始化原生 run 可访问自己的空标签列表；传入同一个 RunRegistry 长期 signal，单命令 signal 不同；子默认读取父任务被拒 |
| B02 两种跨任务授权 | 父获 control、子获 observe，各绑定申请方 run；后续命令读列表可用，授权不随命令结束消失；observe 不获得 write 权限 |
| B03 单命令取消 | 取消父新一项待授权请求，原 control grant 保留，run 未停止，后续读成功；迟到批准拒绝 |
| B04 父停止 | 父原生退出／run 停止，父申请的 grant 撤销、暂停清除；仍活跃子 run 已获的父 task observe grant 保留，可继续读该逻辑任务 |
| B05 同 task 换 Provider | 新 Claude run 保留父 task，但不能继承旧父 run 对子的授权；子的授权仍属于子，目标仍为同一个逻辑父 task |
| B06 等待真实业务排空 | 停止新父 run 时，用受控 Promise 暂停浏览器请求的业务收尾；原生已经退出，run 仍 stopping、activity 与租约保留，投递不能退役。释放该 Promise 后停止完成，迟到批准拒绝；子再停止后全部 grant 清空 |

最终 {a.name}，3 个原生进程退出（Codex 0、Claude 各 143），调用均由研究宿主发起；{len(observed)} 次实际 BrowserService scope 观测均满足稳定 runSignal／独立 command signal。BrowserService 自身一直保留到实验最后由 ApplicationService.dispose 关闭，单 Agent 停止不销毁宿主服务。

## 发现的候选停止缺口与修正

初次 setup 未安装激活 browser 包，获取 active package 失败，尚未启动原生进程。第二批 attempt-oUppYV 的 B01–B05 通过，B06 出现 RUN_NOT_DRAINED：临时 launch.cancel 等到 native exit 就试图 retire 投递，实际 withActivity 的 finally 尚未结束。原有运行表阻止了过早释放；最终清理仍完成。两份失败保留。

修正临时启动协调：撤销入口与运行 signal、结束原生范围后，等待该 run 已登记的真实 withActivity Promise 结束，再检查 activity／租约并退役。没有删除活动行或强行标成 stopped。最终 B06 添加确定性的业务收尾暂停点，证实 native exit 与业务结束之间资源占用保留；不以 sleep 或多次 stop 侥幸通过。挂起不明业务仍须维持 stopping／恢复状态，不能为了返回成功跳过等待。

## 迁移规则与边界

浏览器运行权限由申请方 run 持有，目标是 task。停止申请方撤销其权限；目标 task 的 Provider 改变不会把仍活跃申请方的 grant 复制给新 Provider，也不等于删除目标页面。实际页面与登录是否保留仍需原生 Electron 验证，本批只有空标签列表。

保留 BrowserModule 的 CLI 入口限制，不在统一任务 UI 改造时直接转成公共 MCP。SDK Driver 后续须接受管业务 CLI 的环境／内核身份路径，并将稳定 runSignal 与一次命令取消分开。审批响应由受信宿主发起，真实 renderer／IPC 还未接线。进程初始化不是模型成功使用浏览器的证据。

未覆盖真实页面／登录、原生 shell→CLI socket、在途网页写入、输入／下载、页面工作区 UI、宿主崩溃或跨平台。本批候选等待修正不等于正式产品已有此 launcher。

[结果](result.json)、[失败／最终运行审计](runtime-audit.json)、[源码及实验替身边界](source-review.json)、[摘要](archive-manifest.json)、[脚本／资源／协议／SQLite](raw-evidence.tar.gz)。{len(files)} 文件，{len(dbs)} 份 SQLite 完整性／外键通过，{len(sources)} 构建输入复核。
''')
section='''### 9.7 浏览器授权与程序化运行生存期

[浏览器程序化运行实验](实验/20261114_浏览器程序化运行授权与排空验证/README.md)把真实 Codex 父、Claude 子及同 task 后继 Claude run，接到现有 CLI ToolService／BrowserModule／业务 context／BrowserService。调用由研究宿主发起；没有实际原生 shell／CLI socket、网页或登录态，不能声称完整浏览器迁移通过。

浏览器仍是受管 CLI 业务入口，不能把统一 UI／SDK 接入直接等同于改成 MCP。Driver 要保留原有业务入口环境与身份校验，模块通过 agentRunSignal 取得稳定运行 signal；命令取消 signal 独立。实证单次请求结束／取消不会撤销原 grant，申请方 run 停止才撤销授权并清除其暂停状态。

**跨任务 grant 属于申请方 run，目标是逻辑 task。** 子没有自动访问父页面的权限；observe 不包含 control。父换 Provider 时，新父 run 不继承旧父申请的 grant；仍活跃子 run 已获的父 task grant 可以继续存在，这不是把权限转交给新父。不要把“结束目标的 Provider”误实现成“销毁目标任务页面或撤销其他仍有效的申请方”。页面／登录保留另做真实 Electron 验证。

当前临时 launcher 曾在 native exit 后、浏览器 withActivity 收尾前退役投递，触发 RUN_NOT_DRAINED。候选修正为等待已登记业务 Promise 的 finally 与租约收口后再退役；受控暂停证实 native 已退出时仍保持 stopping／活动租约，解除业务暂停才完成。正式实现应采用可等待的业务排空通知，保持最终状态守卫；不得轮询凑时序、删除活动行或把取消响应当作排空证明。未知／无法完成的业务保留 stopping／恢复入口。

'''
def tech(t):
 assert '### 9.7 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 t=t.replace('ToolService.call 的取消回执可能先于实际 withActivity 完成；','ToolService.call 的取消回执及原生进程退出都可能先于实际 withActivity 完成（§9.7 已在当前原生 owner／浏览器业务联合中复现）；')
 return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.68 浏览器程序化运行授权与停止排空

[浏览器授权联合实验](实验/20261114_浏览器程序化运行授权与排空验证/README.md)B01–06 通过：当前程序化真实 Codex／Claude owner 接现有 CLI 业务处理器／上下文／BrowserService，稳定 runSignal 跨命令保留；跨任务 control／observe 按申请方 run 隔离，单命令取消不撤销原授权，同 task 换 Provider 不继承旧申请方权限，仍活跃子的目标 task grant 保留。

保留初次包未激活的 setup 失败及第二批 RUN_NOT_DRAINED：临时 launcher 过早在 native exit 后退役，浏览器 activity 尚未结束。候选增加等待实际业务 Promise，最终用受控收尾暂停证明 stopping／租约保留至业务结束。两次运行批各三个 native 最终退出，所有活动和租约收口；产品未改。

这不是模型／原生 CLI socket 或真实页面测试；Electron 分配被禁止、只查空标签与授权状态，资源包 runtime 重绑至研究 bundle。Q37 仍部分；技术方案 §9.7／§9.2 同步申请方 run 与目标 task 的区别及等待业务排空。

'''
def ledger(t):
 assert '### 4.68 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正')
 t=t.replace('SDK run 登记／真实页面联调待验','§4.68 又补当前程序化真实原生 owner／CLI 业务处理器与 BrowserService，申请方 run／目标 task、Provider 切换及实际业务排空；原生 CLI socket／真实页面与登录态联调待验')
 t=t.replace('继续补浏览器／邮件等实际上下文、在途操作、其他更新分支及崩溃','§4.68 又补真实程序化 owner 与浏览器 CLI 处理器／context／授权及停止排空；继续补原生 CLI 传输、真实页面、邮件上下文、在途写与宿主崩溃')
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：浏览器授权接入当前真实原生运行与现有 CLI 业务处理器，6 项隔离检查通过；修正临时 launcher 在业务收尾前过早退役的缺口，证实 native 退出后仍须等待业务 activity。见[技术方案 §9.7](技研/技术方案.md)。未验证真实页面／登录及原生 CLI 传输，产品未改。'
 i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：补浏览器原生 CLI 传输／页面保留与其他业务在途链，继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)列明的回执和宿主恢复；不重复已通过的授权正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
