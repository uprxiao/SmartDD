from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_安装中断与跨进程恢复验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==12 and not r.get('error');a=Path(r['out']);build=json.loads((root/'build.json').read_text())
for n in ['build.mjs','build.json','actual.cjs','artifact.mjs','job.mjs','job.sql','worker.mjs','probe.mjs']:assert(root/n).read_bytes()==(a/n).read_bytes(),n
for s in build['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha((root/'actual.cjs').read_bytes())==build['output']['sha256']
workers=json.loads((a/'workers.json').read_text());native=json.loads((a/'native-exits.json').read_text());assert len(workers)==34 and all(w.get('exit') and not w.get('cleanupKill')for w in workers)
assert sum(w['exit']['signal']=='SIGKILL'for w in workers)==11;assert sum(w['exit']['code']==0 for w in workers)==17;assert sum(w['exit']['code']==1 for w in workers)==6
assert len(native)==1 and native[0]['code']==0 and native[0]['signal']is None and native[0]['stdout'].strip()=='codex-cli 0.167.1'
# Rehash the final installed tree, not only the source package.
fixture=json.loads((a/'fixture.json').read_text());db=sqlite3.connect('file:'+fixture['db']+'?mode=ro',uri=True);resource=r['checks'][-1]['evidence']['recoveredResource'];rel=db.execute('select relative_path from capability_resources where resource_id=?',(resource,)).fetchone()[0];manifest=json.loads((Path('/private/tmp/willyou-m14-package-download-probe')/'fixtures.json').read_text())['native']['manifest'];target=Path(fixture['storeRoot'])/rel
for f in manifest['files']:
 p=target/f['path'];h=hashlib.sha256()
 with p.open('rb')as stream:
  for chunk in iter(lambda:stream.read(262144),b''):h.update(chunk)
 assert p.stat().st_size==f['size'] and h.hexdigest()==f['sha256'] and bool(p.stat().st_mode&0o111)==f['executable'],f['path']
db.close()
initial={'attempt':'attempt-k5kX17','status':'incomplete, not counted as a pass','databaseSnapshot':'attempt-k5kX17/interrupted.sqlite','observedPhase':'requested','recordedOwner':{'pid':78141,'startedAt':'darwin-proc-v1:1794642173:542947'},'currentKernelState':'stopped','processInventory':'Read-only escalated ps found no probe or worker process on revalidation. No process was killed by name.','driverDefect':'spawnWorker always constructed a checkpoint promise whose done branch throws; complete() does not consume that promise, so a normally completed non-paused worker can create an unhandled rejection. Original stderr/exit receipt is absent; exact original termination cause is not proved.','correction':'Only create the checkpoint race for paused workers; persist worker PID/frames/exit incrementally, and clean up only captured live ChildProcess handles in finally.'}
(root/'interrupted-attempt.json').write_text(json.dumps(initial,indent=2))
audit={'attempt':a.name,'workers':len(workers),'workerExits':{'code0':17,'code1':6,'SIGKILL':11},'unexpectedCleanupKills':0,'native':native,'publishedFileHashesVerified':41,'publishedBytes':sum(f['size']for f in manifest['files']),'node':subprocess.check_output(['node','--version'],text=True).strip(),'paidModelCalls':0,'limits':['Temporary job schema, not product implementation','Local prepared files, not download death','Not full App/OS restart','No actual run lease/GC or in-use upgrade']}
(root/'runtime-audit.json').write_text(json.dumps(audit,indent=2))
refs=[repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/applications/resource-lock.ts',repo/'src/main/core/applications/process-identity.ts',t3/'apps/server/src/provider/CodexInstallation.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(build['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Actual ResourceStore, C coordinator and Mac kernel identity reader. Temporary installation owner/phase/activation schema and streaming artifact candidate. T3 source comparison, no T3 installer executed.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and not any(x in p.parts for x in ['node_modules','publication','data','__pycache__']) and p.suffix in ['.mjs','.cjs','.sqlite','.json','.py','.sql','.log'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json','interrupted-attempt.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 安装中断与跨进程恢复：技术研究记录

2026-11-14；R02／08／10／11，Q01／03／48／51／52／53／54；技术方案 §12.1、验证账 §4.52。这里只是独立实验，没有产品代码、共享原型或正式产品验收。

## 验证对象

实际 SmartDD ResourceStore、C 协调锁、MacProcessIdentityReader 与独立 SQLite；临时增加安装请求、进程 owner、阶段和激活回执表。准备／发布候选继承上一批流式资源验证。每个 worker 都是实际 Node 子进程；暂停点通过 stdout 确认 PID 与内核出生身份后，驱动只用捕获的 ChildProcess 发送 SIGKILL，确认停止后由新进程恢复。

请求固定清单、来源路径、预期默认修订和请求摘要。接管前检查原 owner 已停止，锁内再次核对完整原记录；存活／身份未知不能接管。准备目录重新完整校验后获得新进程内句柄，发布恢复保留原 ResourceStore operation ID。默认指针与成功回执在同一 SQLite 事务提交；重试返回原操作收据，不能把收据当作当前默认版本、有效缓存证明或运行授权。

## 结果：{a.name}，I01–I12

| 场景 | 结果及范围 |
| --- | --- |
| I01–I07 | 分别在请求登记、准备完成、资源登记、资源 materialize、资源 rename、资源 ready、激活完成后终止；新 worker 恢复或返回原收据，默认修订只增加一次；已有发布 operation ID 保留、install 租约结束 |
| I01／I02 分支 | 原安装者仍活着、原身份被故障注入成 unknown 时，另一 worker 均拒绝接管；恢复合法身份后才执行预定终止 |
| I08 | 同一已停止安装者的两个恢复进程竞争：一次成功，一次 CLAIM_CHANGED 拒绝；只激活一次，没有将冲突当作另一成功安装 |
| I09 | 发布后由故障注入修改默认修订，恢复拒绝过期激活；新默认修订与已发布资源保留 |
| I10 | 默认指针和回执写入后、提交前注入异常，两者一起回滚；下一 worker 成功激活一次 |
| I11 | 准备目录文件被同大小／权限替换，恢复因内容 hash 变化拒绝；不悄悄重建或激活 |
| I12 | 完整实际 Codex 0.167.1 平台包在 rename 后终止，重启 worker 恢复发布和激活，从恢复路径执行 --version 成功；最终 41 文件／366515155 字节重新核对 |

34 个安装 worker 均有退出记录：17 个 code 0，6 个预期拒绝／故障 code 1，11 个计划内 SIGKILL；没有 finally 兜底终止。另有一个实际 native --version 进程 code 0。其 stderr 提示隔离 CODEX_HOME 尚不存在，版本检查仍成功；这不是初始化、登录或模型调用证明。

## 初次未完成记录与修正

attempt-k5kX17 没有终态结果，保留独立库快照及[复核记录](interrupted-attempt.json)，不计通过。源码复核发现驱动为无需暂停的 worker 也创建了 checkpoint rejection，而 complete() 没有消费该 Promise。该缺陷可导致正常子进程退出后主驱动出现未处理拒绝；原日志缺失，不能断言它就是当次唯一退出原因。

后续确认原记录的内核身份 stopped，且只读进程清单不存在相关实验进程，才重新启动。修正驱动只为暂停场景建立该等待，同时增量记录捕获 PID／事件／退出状态，finally 只清理自己捕获的 ChildProcess。本轮没有修改产品 ResourceStore 来使实验通过。

## 设计结论与未覆盖范围

T3 的版本目录和独立激活指针提供分层参考；WillYou 还需结合现有 ResourceStore 的原操作、归属和持久占用。安装操作与资源发布操作、默认选择与历史收据不能混为一条布尔 installed 状态。重新打开准备目录必须重新验证，不能序列化旧进程的 WeakMap 句柄作为信任凭证。

本批只覆盖已记录阶段之间的 worker 退出。准备文件复制中途、准备完成但目录路径尚未写入时可能留下无关联准备目录，仍需预登记／扫描及保留策略验证；不能由 I01–I07 推导所有指令窗口均恢复。HTTP 下载中途死亡、下载／解包到安装的统一恢复记录、真实 run 租约／GC、在用升级、完整 App／系统重启、原生签名及跨平台尚未完成。恢复时新 owner 的身份和故障结果应可诊断，失败后不自动替换版本、删除未知遗留或接管仍活着的进程。

激活表、安装任务表及驱动都是临时实验 Schema，不代表已决定正式表迁移。当前入口为 worker --version，不是产品 UI／业务调用路径，更不是正式安装验收。

## 证据

[结果](result.json)、[运行审计](runtime-audit.json)、[源码基线](source-review.json)、[原始证据摘要](archive-manifest.json)、[驱动、SQL、结果和数据库归档](raw-evidence.tar.gz)。归档 {len(files)} 文件、{len(dbs)} 份 SQLite，完整性和外键均通过；{len(build['sources'])} 个真实构建输入 hash 复核。大 native 文件不重复入库。

在新的临时目录恢复脚本，配置本机对应依赖和内核身份 helper，核对并重建 build.mjs 后运行 probe.mjs；包含真实 SIGKILL，仅能对本实验捕获的子进程执行，不能指向用户日常资源目录。证据含绝对实验路径，跨机器复跑需替换，不应直接运行归档中的原路径参数。
''')
def tech(t):
 old='现候选准备句柄仅存于进程内、激活表亦是实验 Schema；安装操作持久化、崩溃恢复、遗留准备清理及与正式租约的联合仍须补验。'
 new='准备句柄仍是进程内能力；下面的跨进程实验通过持久清单／原阶段定位目录并重新校验后创建新句柄，不序列化或直接信任旧句柄。激活表和安装表仍为实验 Schema，遗留准备清理及与真实 run 租约的联合尚未完成。'
 assert old in t;t=t.replace(old,new)
 marker='当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、安装阶段持久恢复、跨进程安装、真实磁盘耗尽、运行中升级／GC、历史格式兼容或目标平台安装。'
 replacement='''[安装恢复实验](实验/20261114_安装中断与跨进程恢复验证/README.md)使用独立持久安装记录，完成七个已记录阶段后的实际 worker SIGKILL 与新进程恢复。安装请求固定清单／来源／预期默认修订，owner 使用实例、PID 与内核出生身份；只有原进程已停止且锁内记录仍一致才可接管，存活／未知身份保留原状态。准备目录完整重新校验；实际 ResourceStore 恢复保留原发布 operation ID。完整 Codex 平台包 rename 后退出也已恢复，并从恢复路径执行 --version。

默认指针与安装成功回执必须在同一事务提交；失败一起回滚。重复请求返回原操作回执，不重新激活，也不证明该版本当前仍默认或仍可执行。默认版本修订已变化时拒绝旧安装的激活；并发接管只有一个 owner 能推进，冲突重读原状态，不能隐式创建另一安装或覆盖目标。文件损坏保留诊断，不以重新下载／替换目录掩盖原操作失败。

当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、真实磁盘耗尽、真实 run 租约／在用升级／GC、完整 App／系统重启、历史格式兼容或目标平台安装。'''
 assert marker in t;return t.replace(marker,replacement)
edit(base/'技研/技术方案.md',tech)
section='''### 4.52 安装阶段持久化与跨进程恢复

[安装中断实验](实验/20261114_安装中断与跨进程恢复验证/README.md)I01–I12 结合真实 ResourceStore、C 锁、内核身份与临时安装／激活表，完成七个已记录阶段后的 worker SIGKILL／新进程恢复，以及存活／未知 owner 拒绝、竞争接管、过期默认修订、原子激活回滚、准备内容损坏拒绝。完整 Codex 包 rename 后中断也恢复发布并执行 --version；安装操作与发布操作、历史收据与当前默认值分别处理。

初次 attempt-k5kX17 没有终态，保留快照，不算通过；驱动存在未消费 checkpoint rejection，原日志缺失不能认定唯一退出原因。修正驱动并确认旧身份停止后，attempt-C9boJu 通过全部 12 项；34 安装 worker 和 1 native 均有退出回执。未修改产品或共享原型。

仅证明已记录阶段后的局部恢复，不覆盖复制中途／未登记准备目录、下载中断恢复、真实运行租约／GC、全 App／系统重启或其他平台。T0.1 §12.1 已同步，仍是技术研究，非正式产品验收。

'''
def ledger(t):
 assert '### 4.52 'not in t;t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正')
 lines=t.splitlines()
 for q in ['Q01','Q03','Q48','Q51','Q52','Q53','Q54']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.52 补已记录安装阶段退出／接管与原子激活，复制中途及真实租约仍待证 |'
 t='\n'.join(lines)+'\n';t=t.replace('公网 HTTPS／代理、跨进程恢复、真实 run 租约和遗留准备清理仍待联合。','§4.52 补已记录安装阶段的跨进程恢复／并发接管与激活回滚；公网 HTTPS／代理、复制中途、真实 run 租约和遗留准备清理仍待联合。');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补安装已记录阶段后的实际进程终止／跨进程恢复、并发接管及默认激活回滚，见[技术方案 §12.1](技研/技术方案.md)。完整 Codex 包恢复后版本检查成功；这仍是隔离技术研究，不是产品安装验收。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续补真实运行资源租约／回收、完整协议及跨宿主输入／结果对账；下载／复制中途、遗留准备目录、上游／代理、原业务、平台、性能及界面状态设计仍保留。当前只完善设计并做独立验证，不修改产品或共享原型；产品开发、视觉评审及正式验收属于后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(build['sources'])}))
