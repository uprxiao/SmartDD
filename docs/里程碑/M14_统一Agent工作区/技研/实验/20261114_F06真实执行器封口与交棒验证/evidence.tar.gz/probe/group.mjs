// ../../../../private/tmp/willyou-m14-scope-probe/extracted.ts
import * as NodeChildProcess from "node:child_process";
function signalProcessGroup(pid, signal) {
  if (!Number.isSafeInteger(pid) || pid <= 1) {
    throw Object.assign(new Error(`kill ESRCH: not a spawned process group (${pid})`), {
      code: "ESRCH"
    });
  }
  process.kill(-pid, signal);
}
var CLAUDE_GROUP_WATCH_SCRIPT = [
  "read -r _ <&4 || exit 1",
  "exec 4<&-",
  "{ trap '' TERM; read -r _ <&3; kill -TERM 0; sleep 5; kill -KILL 0; } </dev/null >/dev/null 2>&1 &",
  'exec "$@" 3<&-'
].join("\n");
function spawnClaudeProcessGroup(options, onExit, onStderr = () => {
}, onStderrClose = () => {
}, register) {
  const child = NodeChildProcess.spawn(
    "/bin/sh",
    ["-c", CLAUDE_GROUP_WATCH_SCRIPT, "t3-claude", options.command, ...options.args],
    {
      cwd: options.cwd,
      env: options.env,
      signal: options.signal,
      stdio: ["pipe", "pipe", "pipe", "pipe", "pipe"],
      detached: true
    }
  );
  let forget;
  child.stderr?.setEncoding("utf8").on("data", onStderr).once("close", onStderrClose);
  child.once("exit", () => {
    try {
      signalProcessGroup(child.pid ?? 0, "SIGKILL");
    } catch {
    }
    try {
      forget?.();
    } catch {
    }
    onExit?.();
  });
  const gate = child.stdio[4];
  if (child.pid !== void 0 && gate !== null && gate !== void 0 && "end" in gate) {
    try {
      const registration = register?.(child.pid);
      gate.on("error", () => child.kill("SIGKILL"));
      Promise.resolve(registration).then(value => { forget=value; gate.end("ready\n"); }, error => { child.registrationError=error; child.kill("SIGKILL"); gate.destroy(); });
    } catch (cause) {
      child.kill("SIGKILL");
      gate.destroy();
      throw cause;
    }
  }
  return child;
}
export {
  signalProcessGroup,
  spawnClaudeProcessGroup
};
