function parseClaudeProcessTable(table) {
  return table.split("\n").flatMap((line) => {
    const [pid, ppid, pgid, ...started] = line.trim().split(/\s+/);
    const row = {
      pid: Number(pid),
      ppid: Number(ppid),
      pgid: Number(pgid),
      started: started.join(" ")
    };
    return Number.isSafeInteger(row.pid) && Number.isSafeInteger(row.ppid) && Number.isSafeInteger(row.pgid) && row.started ? [row] : [];
  });
}
function killClaudeDescendant(row) {
  try {
    if (row.pgid === row.pid) signalProcessGroup(row.pid, "SIGKILL");
    else process.kill(row.pid, "SIGKILL");
  } catch {
  }
}
function claudeDescendants(rows, rootPids) {
  const children = Map.groupBy(rows, (row) => row.ppid);
  const found = [];
  const seen = new Set(rootPids);
  const pending = [...rootPids];
  for (let parent = pending.pop(); parent !== void 0; parent = pending.pop()) {
    for (const child of children.get(parent) ?? []) {
      if (seen.has(child.pid)) continue;
      seen.add(child.pid);
      found.push(child);
      pending.push(child.pid);
    }
  }
  return found;
}
export {
  claudeDescendants,
  parseClaudeProcessTable
};
