export const deferred=()=>{let resolve,reject;const promise=new Promise((r,j)=>{resolve=r;reject=j});return{resolve,reject,promise}};
export const bounded=(p,ms=20000)=>{let t;return Promise.race([p,new Promise((_,j)=>t=setTimeout(()=>j(Error('OBSERVATION_DEADLINE')),ms))]).finally(()=>clearTimeout(t))};
export const quote=s=>"'"+s.replaceAll("'","'\\''")+"'";
