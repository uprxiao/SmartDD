import {createServer as netServer} from 'node:net';import {randomUUID} from 'node:crypto';import {deferred,bounded} from './util.mjs';
const out=process.env.F06_OUTPUT;
export async function observer(id) {
  const token = randomUUID(), ready = deferred(), gone = deferred(), replies = new Map();
  const connections = new Set(); let writer, readyInfo;
  const server = netServer(socket => {
    connections.add(socket); let pending = '';
    socket.on('data', bytes => {
      pending += bytes;
      while (pending.includes('\n')) {
        const pos = pending.indexOf('\n'), raw = pending.slice(0, pos); pending = pending.slice(pos + 1);
        const event = JSON.parse(raw);
        if (event.event === 'ready') {
          if (event.token !== token) { socket.destroy(); continue; }
          writer = socket; readyInfo = event; ready.resolve(event);
        } else replies.get(event.id)?.resolve(event);
      }
    });
    socket.on('error', () => {});
    socket.on('close', () => { connections.delete(socket); if (writer === socket) gone.resolve(); });
  });
  await new Promise((yes, no) => { server.once('error', no); server.listen(0, '127.0.0.1', yes); });
  const file = out + '/' + id + '.writes';
  return { token, port: server.address().port, file, ready: ready.promise, gone: gone.promise,
    get live() { return Boolean(writer && !writer.destroyed); },
    async write(label) { const d = deferred(); replies.set(label, d); writer.write(JSON.stringify({ kind: 'write', id: label }) + '\n'); return bounded(d.promise); },
    async stop() { if (writer && !writer.destroyed) { writer.write('{"kind":"stop"}\n'); await bounded(gone.promise); } },
    async close() { await this.stop(); for (const socket of connections) socket.destroy(); await new Promise(resolve => server.close(resolve)); },
    get info() { return readyInfo; },
  };
}

