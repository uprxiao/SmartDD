import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,writeFileSync,copyFileSync,existsSync,lstatSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import candidate from './candidate.cjs';
import {migrate} from './migration.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],helper='/private/tmp/willyou-m14-owner-probe/process-identity';
const save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n');
for(const name of ['build.json','build.mjs','retention.ts','migration.mjs','candidate.sql','resource-gc-plan.ts.variant','resource-graph-maintenance.ts.variant','probe.mjs'])copyFileSync(root+'/'+name,out+'/'+name);
const tables=['m14_binding','m14_cap','m14_revision','m14_ref','m14_mcp'];
const records=db=>Object.fromEntries(tables.map(t=>[t,db.prepare('SELECT * FROM '+t).all()]));
function release(db){db.transaction(()=>{db.prepare('UPDATE m14_cap SET current_hash=NULL').run();for(const t of ['m14_mcp','m14_ref','m14_revision','m14_cap','m14_binding'])db.prepare('DELETE FROM '+t).run();}).immediate();}
function restore(db,saved,{unsafe=false}={}){db.transaction(()=>{
 if(!unsafe)for(const f of saved.m14_ref){const r=db.prepare('SELECT state,integrity,content_hash FROM capability_resources WHERE resource_id=?').get(f.ref_id);assert(r?.state==='ready'&&r.integrity==='valid'&&r.content_hash===f.ref_hash,'RESOURCE_STATE_CHANGED');}
 for(const table of tables)for(const row of saved[table]){const columns=Object.keys(row);db.prepare('INSERT INTO '+table+'('+columns.join(',')+') VALUES('+columns.map(()=>'?').join(',')+')').run(...columns.map(k=>row[k]));}
}).immediate();}
async function setup(){
 const f=await actual.runFixture(undefined,{application:true});
 const runtime=await new actual.RuntimeRegistry(f.store).install({id:'applications',protocolMajor:1,bridgeEntry:'mcp-bridge.cjs',files:{'mcp-bridge.cjs':Buffer.from('module.exports={next:true};')}});
 const source=actual.fixtureBundle('2.0.0');source.manifest.runtime.hash=runtime.contentHash;const next=await f.packageRegistry.install(source);await f.packageRegistry.activate(next.packageHash,1);
 await migrate(f.sqlite);f.sqlite.transaction(()=>{f.sqlite.prepare('UPDATE m14_binding SET legacy_task_id=NULL').run();for(const t of ['capability_session_refs','capability_session_mcp_names','capability_session_identities','capability_snapshot_versions','capability_session_holds','capability_session_snapshots'])f.sqlite.prepare('DELETE FROM '+t).run();}).immediate();
 const saved=records(f.sqlite),reader=new actual.FixtureProcessReader(),oldRuntime='runtime:'+f.applicationSource.manifest.runtime.hash;
 const engine=(modified=true,hook)=>new (modified?candidate:actual).ResourceGraphMaintenance(f.store,reader,input=>actual.restoreOwnedDirectory(helper,input),hook);
 return{...f,saved,reader,oldRuntime,next,engine};
}
const snapshots=[];let error;
async function check(id,label,fn){const f=await setup();try{const evidence=await fn(f);checks.push({id,label,status:'passed',evidence});console.log(JSON.stringify({id,status:'passed'}));}catch(e){checks.push({id,label,status:'failed',error:e.stack});throw e;}finally{
 assert.deepEqual(f.sqlite.pragma('integrity_check'),[{integrity_check:'ok'}]);assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);await f.sqlite.backup(out+'/'+id+'.sqlite');save(out+'/'+id+'-fixture.json',{root:f.root,oldPackage:f.application.resourceId,oldRuntime:f.oldRuntime,newPackage:f.next.resourceId});f.sqlite.close();save(out+'/progress.json',{checks});}}
try{
 await check('G01','baseline deleter overlooks new-only references and physically removes retained package',async f=>{
  const engine=f.engine(false),p=await engine.plan(f.application.resourceId);assert(p.canCollect);assert(f.sqlite.prepare('SELECT 1 FROM m14_ref WHERE ref_id=?').get(f.application.resourceId));const result=await engine.cleanup(f.application.resourceId,p.planHash);
  assert.equal(result.state,'removed');assert(!existsSync(f.store.directory(f.store.get(f.application.resourceId))));assert.equal(f.store.get(f.oldRuntime).state,'removed');assert(existsSync(f.store.directory(f.store.get(f.next.resourceId))));return{baselineRiskReproduced:true,removed:result.resourceIds,newOnlyRefsStillPresent:f.sqlite.prepare('SELECT COUNT(*) n FROM m14_ref').get().n};
 });
 await check('G02','active, tombstone and another binding retain the dependency closure',async f=>{
  const engine=f.engine(),p=await engine.plan(f.application.resourceId);assert(!p.canCollect);assert(p.retained.some(x=>x.resourceId===f.oldRuntime));assert.equal(p.issues.length,0);
  f.sqlite.prepare("UPDATE m14_cap SET retention='tombstone'").run();const tombstone=await engine.plan(f.application.resourceId);assert(!tombstone.canCollect);assert.notEqual(tombstone.planHash,p.planHash);
  const second=structuredClone(f.saved),bindingId=randomUUID(),capId=randomUUID();second.m14_binding[0].binding_id=bindingId;second.m14_cap[0].binding_id=bindingId;second.m14_cap[0].cap_id=capId;for(const r of second.m14_revision){r.binding_id=bindingId;r.cap_id=capId;}for(const r of second.m14_ref)r.cap_id=capId;for(const r of second.m14_mcp){r.binding_id=bindingId;r.server_name='gc_'+randomUUID().replaceAll('-','');}
  restore(f.sqlite,second);const first=f.saved.m14_cap[0].cap_id;f.sqlite.transaction(()=>{f.sqlite.prepare('UPDATE m14_cap SET current_hash=NULL WHERE cap_id=?').run(first);for(const t of ['m14_ref','m14_revision','m14_cap'])f.sqlite.prepare('DELETE FROM '+t+' WHERE cap_id=?').run(first);f.sqlite.prepare('DELETE FROM m14_mcp WHERE binding_id=?').run(f.saved.m14_binding[0].binding_id);f.sqlite.prepare('DELETE FROM m14_binding WHERE binding_id=?').run(f.saved.m14_binding[0].binding_id);}).immediate();assert(!(await engine.plan(f.application.resourceId)).canCollect);return{activeRetains:true,tombstoneRetains:true,secondBindingRetains:true,dependency:f.oldRuntime};
 });
 await check('G03','new reference invalidates a previously collectable plan',async f=>{
  release(f.sqlite);const engine=f.engine(),before=await engine.plan(f.application.resourceId);assert(before.canCollect);restore(f.sqlite,f.saved);await assert.rejects(engine.cleanup(f.application.resourceId,before.planHash),e=>e.code==='RESOURCE_STATE_CHANGED');assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));return{stalePlanRejected:true};
 });
 await check('G04','final write transaction catches a reference admitted after proposal capture',async f=>{
  release(f.sqlite);let inserted=false;const engine=f.engine(true,phase=>{if(phase==='intent'){restore(f.sqlite,f.saved);inserted=true;}}),p=await engine.plan(f.application.resourceId);
  await assert.rejects(engine.cleanup(f.application.resourceId,p.planHash),e=>e.code==='RESOURCE_STATE_CHANGED');assert(inserted);assert.equal(f.sqlite.prepare("SELECT COUNT(*) n FROM capability_resource_operations WHERE kind='cleanup-graph'").get().n,0);assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));return{finalTransactionRejected:true,noCleanupIntentCommitted:true};
 });
 await check('G05','late admission after deleting is rejected with no partial binding',async f=>{
  release(f.sqlite);let rejected=false;const engine=f.engine(true,phase=>{if(phase==='marked'){assert.throws(()=>restore(f.sqlite,f.saved),/RESOURCE_STATE_CHANGED/);rejected=true;throw Error('stop-after-mark');}}),p=await engine.plan(f.application.resourceId);
  await assert.rejects(engine.cleanup(f.application.resourceId,p.planHash),/stop-after-mark/);assert(rejected);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM m14_binding').get().n,0);assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));
  const op=f.sqlite.prepare("SELECT operation_id,plan_json FROM capability_resource_operations WHERE kind='cleanup-graph'").get();const canceled=await engine.cancel(op.operation_id,actual.digest(op.plan_json));assert.equal(canceled.state,'canceled');restore(f.sqlite,f.saved);assert(!(await engine.plan(f.application.resourceId)).canCollect);return{admissionRejected:true,completeCancellationAllowsAdmission:true};
 });
 await check('G06','final deletion and recovery stop if a rogue new reference bypasses admission',async f=>{
  release(f.sqlite);let injected=false;const engine=f.engine(true,phase=>{if(phase==='marked'){restore(f.sqlite,f.saved,{unsafe:true});injected=true;}}),p=await engine.plan(f.application.resourceId);
  await assert.rejects(engine.cleanup(f.application.resourceId,p.planHash),e=>e.code==='RESOURCE_RECOVERY_REQUIRED');assert(injected);assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));assert.equal(f.store.get(f.application.resourceId).state,'deleting');const recovery=await f.engine().recover();assert.equal(recovery.pending.length,1);assert.equal(recovery.recovered.length,0);return{physicalDeletionPrevented:true,recoveryPending:true,rogueFixtureWrite:true};
 });
 await check('G07','corrupt or incomplete new history blocks cleanup instead of being treated as no reference',async f=>{
  f.sqlite.prepare("UPDATE m14_ref SET ref_hash=? WHERE ref_id=?").run('0'.repeat(64),f.application.resourceId);let p=await f.engine().plan(f.application.resourceId);assert(!p.canCollect&&p.issues.some(x=>x.startsWith('m14-reference-integrity:')));
  f.sqlite.prepare('DELETE FROM m14_ref WHERE ref_id=?').run(f.application.resourceId);p=await f.engine().plan(f.application.resourceId);assert(!p.canCollect&&p.issues.some(x=>x.startsWith('m14-revision-unresolved:')));return{badHashRetained:true,missingRequiredReferenceRetained:true};
 });
 await check('G08','last history release still respects a real ResourceStore usage lease before physical deletion',async f=>{
  release(f.sqlite);const engine=f.engine();let enter,leave;const ready=new Promise(r=>enter=r),gate=new Promise(r=>leave=r),usage=f.store.use(f.application.resourceId,'ui','isolated-gc-consumer',async()=>{enter();await gate;});await ready;
  try{const p=await engine.plan(f.application.resourceId);assert(!p.canCollect);assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));}finally{leave();await usage;}
  const p=await engine.plan(f.application.resourceId);assert(p.canCollect);const result=await engine.cleanup(f.application.resourceId,p.planHash);assert.equal(result.state,'removed');assert(!existsSync(f.store.directory(f.store.get(f.application.resourceId))));assert.equal(f.store.get(f.oldRuntime).state,'removed');assert(existsSync(f.store.directory(f.store.get(f.next.resourceId))));return{leaseRespected:true,oldPackageAndRuntimeRemovedAfterRelease:true,newDefaultPreserved:true};
 });
}catch(e){error=e.stack;process.exitCode=1;}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,failed:checks.filter(x=>x.status==='failed').length,error,scope:'Actual graph planner/deleter, ResourceStore, native rename helper, legal v2 snapshots migrated to candidate relations. Candidate build injects new reference reader into planner/final guard. Fixture process identity, no native agent or product edits.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify(result,null,2));
