import {storedCapabilitySessionSnapshotSchema} from '/Users/hx/projects/SmartDD/src/shared/application-session-v3.ts';
import {canonicalJson,digest} from '/Users/hx/projects/SmartDD/src/main/core/applications/manifest.ts';

export function programmaticRetention(store) {
 const db=store.sqlite, names=['m14_binding','m14_cap','m14_revision','m14_ref'];
 const present=names.filter(name=>db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name));
 if(!present.length)return{refs:[],issues:[],basis:null};
 if(present.length!==names.length)return{refs:[],issues:['m14-schema-incomplete'],basis:present};
 const bindings=db.prepare('SELECT * FROM m14_binding ORDER BY binding_id').all(),caps=db.prepare('SELECT * FROM m14_cap ORDER BY cap_id').all(),revisions=db.prepare('SELECT * FROM m14_revision ORDER BY cap_id,snapshot_hash').all(),refs=db.prepare('SELECT * FROM m14_ref ORDER BY cap_id,snapshot_hash,ref_id').all(),issues=[];
 for(const c of caps){
  if(!bindings.some(b=>b.binding_id===c.binding_id&&b.task_id===c.task_id)||!revisions.some(r=>r.cap_id===c.cap_id&&r.snapshot_hash===c.current_hash)||c.retention==='hold')issues.push('m14-history-unresolved:'+c.cap_id);
 }
 for(const r of revisions)try{
  const c=caps.find(c=>c.cap_id===r.cap_id&&c.binding_id===r.binding_id&&c.task_id===r.task_id),b=bindings.find(b=>b.binding_id===r.binding_id&&b.task_id===r.task_id),value=storedCapabilitySessionSnapshotSchema.parse(JSON.parse(r.snapshot_json));
  if(!c||!b||value.taskId!==r.task_id||value.runner!==b.runner||digest(canonicalJson(value))!==r.snapshot_hash)throw Error('identity');
  const expected=new Set(['agent-adapter:'+value.runner+':'+value.adapterBinding.hash,...value.packages.flatMap(p=>['app:'+p.packageHash,'runtime:'+p.runtimeHash]),...value.standardSkills.map(s=>'standard-skill:'+s.skillId+':'+s.hash),...value.mcp.map(m=>(m.kind==='applications'?'runtime:':'legacy-runtime:')+m.runtimeHash)]);
  for(const id of expected)if(!refs.some(f=>f.cap_id===r.cap_id&&f.snapshot_hash===r.snapshot_hash&&f.ref_id===id))throw Error('missing resource');
 }catch{issues.push('m14-revision-unresolved:'+r.cap_id+':'+r.snapshot_hash);}
 for(const f of refs)try{
  const r=store.get(f.ref_id);
  if(!revisions.some(r=>r.cap_id===f.cap_id&&r.snapshot_hash===f.snapshot_hash&&r.task_id===f.task_id)||r.kind!==f.ref_kind||r.contentHash!==f.ref_hash||r.relativePath!==f.relative_path||r.state==='removed')throw Error('resource');
 }catch{issues.push('m14-reference-integrity:'+f.cap_id+':'+f.ref_id);}
 return{refs,issues,basis:{bindings,caps,revisions,refs}};
}
