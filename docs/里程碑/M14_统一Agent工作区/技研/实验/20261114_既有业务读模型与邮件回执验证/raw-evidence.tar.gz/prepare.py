from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_既有业务读模型与邮件回执验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==12 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
paths=['src/main/core/applications/'+x for x in ['activity-service.ts','execution-context.ts','mail-execution-service.ts','mail-send-data-service.ts','mail-unknown-verifications.ts','mail-draft-send-history.ts','mail-user-authorizations.ts','application-service.ts']]+['drizzle/0020_application_activity_subjects.sql']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':x,'sha256':sha((repo/x).read_bytes())} for x in paths],'actualServices':['ApplicationActivityService','ApplicationConnectionService','ApplicationSelectionService','SecretsStore','MailBlobStore','MailDraftService','MailExecutionService','MailUnknownVerifications','readDraftSendHistory'],'controlled':['SecretCipher','connection verifier','MailSendPolicy actors and proof map','manual-verification execution context and sender identity','submit transport'],'findings':['Existing read-only ActivityService merges bridge and Data API by their shared operation identity, includes subject links and browser/send rows; reuse in unified UI.','Its pagination, legacy absent-browser fallback, optional project filtering and deduplication are not a complete integrity/admission proof.','Partial SMTP acceptance persists server-accepted and draft sent with complete false; unified UI must consume receipt.','readDraftSendHistory performs stronger project/revision/content/message identity checks than generic activity.detail.','Manual sent/not-sent observations append mail_draft_mutations; original SMTP unknown is immutable, and not-sent creates a new draft without sending authority.'],'limits':['No real SMTP, native SDK, real UI sender or native user-origin verification','No actual ApplicationExecutionContexts/ToolService dispatch in this experiment; those remain separate integration work','Conflict and missing-table cases are synthetic integrity/compatibility probes, not a claim normal product paths corrupt records','No product completion, new admission service, large-store performance or migration closure']}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','probe.mjs','audit.json','source-review.json','prepare.py']]
for d in sorted(root.glob('attempt-*')):files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts)
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 既有业务读模型与邮件回执验证

日期：2026-11-14。D04，关联 Q09／Q41／Q49。承接 §4.99 的候选汇总，进一步核对现有业务服务可复用内容，防止为统一 UI 另造一套丢失业务语义的记录解释器。当前 SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，最终构建 486 条输入摘要已核对。

## 实际执行与边界

实跑连接、选用、SecretStore、草稿／Blob、MailExecutionService、ApplicationActivityService、readDraftSendHistory 和 MailUnknownVerifications。数据均为隔离 SQLite 与公开合成内容。SecretCipher、连接验证、MailSendPolicy 的 actor／用户证据、人工核实上下文／sender 以及 submit 为受控替身；四次 submit 只是函数调用，不连接 SMTP、不读取真实凭据、不发送真实邮件。没有实际 ApplicationExecutionContexts／ToolService 派发、原生 SDK、真人确认或 Electron 页面。

十二项检查通过；最终 attempt-5DLUmw。第一次 attempt-pBAsPF 十项通过后，新增原草稿跨记录核验与两项人工核实检查，原记录保留。第一次 bundle 后被新增导出构建替换，已从原构建脚本和未变化输入重建，并核对 SHA 与当时记录完全一致；reconstruction.json 明确记录该补归档事实，不将重建说成原时点采样。

| 检查 | 实际结论 |
| --- | --- |
| M01 | 实际冻结准备、同请求同 intent；模型 approved=true、无授权执行和错 run 拒绝；用户证明来源为替身 |
| M02 | 同身份密钥轮换使用当前密钥；发送前 grant 已 used，重复 execute 读同一 execution，只有一次受控 submit |
| M03 | failed 却带 accepted 收件人的矛盾回执归为 unknown；复制草稿保留 priorUnknownExecutionIds，新意图须显式核对该来源 |
| M04 | 部分接受时 intent=server-accepted、draft=sent，但 complete=false；实际历史详情保留拒收名单 |
| M05 | 清除选用后重新选择同一连接，旧授权因 binding revision 变化 stale，未提交 |
| M06 | 替身忽略取消并迟到返回成功，实际服务仍保留 unknown，不重发；以 Promise 事件门闩等待，无轮询 |
| M07 | 实际活动服务按 application_activity_subjects 找到无项目连接管理操作；插件历史 connectionId 可在连接已不存在时保留；混合 id／connectionId 损坏拒绝 |
| M08 | 桥与 Data API 共同 operationId 正常展示一次；注入互相矛盾的底层行后，历史投影仍选桥行，因此不能把展示去重作为准入一致性证明；这不是正常路径产生损坏的证明 |
| M09 | 分页 cursor 与筛选绑定；无归属浏览器记录在项目筛选中不出现，缺 browser 表按旧库兼容返回空；完整准入覆盖必须另验 |
| M10 | 历史查询不创建调用／grant；损坏结果拒绝。泛型详情可解析的错 messageId，被实际 readDraftSendHistory 的关联校验拒绝 |
| M11 | 实际人工核实服务追加 sent 观察，原 intent／execution／grant 字节未变，SMTP 仍 unknown；另一窗口矛盾决定拒绝，无发送权限生成 |
| M12 | not-sent 追加观察并复制新草稿，错 frame 拒绝；准备新意图仍携原 unknown 来源且无自动授权／发送 |

最终只读审计：4 个发送 execution、2 份人工观察；无活动发送意图，实际 run 全 stopped、资源租约 released，数据库完整性与外键通过。原始数据包含 M08 合成冲突和 M09 无归属浏览器记录，作为反例保留，不把它们说成生产缺陷或删除后宣称通过。

## 设计决定

统一任务 UI 复用现有活动读模型和业务详情、人工核实服务，保留桥／Data API 共同身份及明确 subject 关联。运行准入单独取得完整覆盖与业务结果解释，不能只看当前页、project 筛选或合并后的状态。

邮件事实至少分为原始传输结果、草稿修订／来源、可验证人工观察、当前许可四部分。部分接受不能显示全部成功；人工 sent 不把 SMTP unknown 改写成原生成功，人工 not-sent 不授权重发。最终汇总摘要也要覆盖人工核实事实及关联来源，不能仅比较四类主表就认为没有变化。

本轮未验证实际 UI／原生来源授权、邮件身份预检和宿主 actor 生命周期联合，业务对象的最小准入范围、所有写入口协调、源覆盖迁移与大库查询也尚未关闭。下一步使用真实上下文与 MailSendDataService／授权服务联合，保留本次既有业务基线。

复现：固定本机依赖具备后运行 `node build.mjs`、`node probe.mjs`，无需网络或账号。见[结果](result.json)、[来源与边界](source-review.json)、[原始证据](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
t=t.replace('通用调用与数据操作即使 ID 相同，也须有实际映射证据才归并。','当前 MCP／Data API 已有共同 operationId 合同，统一历史沿用现有归并；运行准入仍须核对两层 project／task／run、semantics 与结果一致性，不能因展示为一行就掩盖冲突。',1)
t=t.replace('明确业务对账可以更新状态；时间流逝、切换 Provider 或用户关闭任务都不能代替结果证据。','明确业务对账按模块合同记录；邮件人工核实追加独立事实，保留原 SMTP 结果，不通用覆写 unknown。时间流逝、切换 Provider 或用户关闭任务都不能代替结果证据。',1)
needle='### 9.3 子运行的插件审批与统一请求入口'
add='''### 9.2.2 复用现有活动历史与邮件核实业务

[十二项实际服务实验](实验/20261114_既有业务读模型与邮件回执验证/README.md)确认已有 ApplicationActivityService 是统一 UI 的业务历史基础，不另建替代它的通用日志。它按共同 operationId 合并通用调用与 Data API，保留 application_activity_subjects 的 connection／mail-send／mail-draft 关联、插件历史连接和浏览器记录；这些是业务对象范围的已有依据。UI 沿用原授权入口取得页面和详情，不能把内部读服务直接开放成任意查询接口。目标迁移需保留 subject 表及其来源，不通过名称、时间或当前项目选用猜旧关联。

历史展示与准入是不同消费者：活动服务分页、项目筛选和缺浏览器表的兼容分支不能证明全部未决记录已覆盖；合并后的行也不能代替底层一致性检查。准入使用模块提供的完整覆盖／作用域解释，校验相关主表及关联事实的修订；显示可继续复用既有 read model，不能把当前页“没有 unknown”解释为可启动。

邮件详情按原草稿／执行修订通过 readDraftSendHistory 复核 project、draft、revision、review、contentHash 和 messageId；泛型 activity.detail 的结构解析不足以单独证明这些关联。原 MailExecutionService 负责冻结、授权与最终凭据使用、一次执行及回执规范化；MailSendDataService／真实上下文和用户来源校验仍负责调用者权限，不能由汇总器代办授权。

| 原业务事实 | 统一 UI／交接解释 |
| --- | --- |
| server-accepted 且 complete=false | 展示部分接受及失败范围，不能仅凭 intent 状态或 draft=sent 显示全部成功；不自动重发整个动作 |
| unknown，无有效核实 | 保留未知及对账入口；同 execution 的再次查询不重跑发送 |
| unknown＋有效人工 sent | 同时展示“原始回执未知”和“已人工核实发送”；按业务政策将该对象标为已人工对账，不改写传输结果，不生成新的发送权 |
| unknown＋有效人工 not-sent | 保留原证据，沿用原服务创建新草稿；新 intent 仍核对 priorUnknownExecutionIds 并取得具体新授权，不能直接重放原 execution |
| 核实记录损坏／冲突／与原修订不符 | 保持 unverified；不选择最新记录覆盖矛盾，也不自动改变 SMTP 状态 |

MailUnknownVerifications 已把人工核实追加到 mail_draft_mutations，绑定原项目、草稿／执行、内容与审阅摘要及窗口证明；它是独立业务观察，不是原生用户消息或发送授权。迁移保留原记录与校验路径，汇总的证据修订必须包含核实事实及关联记录，不能只比较主表状态。旧持久核实可用于历史解释，新的确认仍需当前窗口 receipt；重启不能从审计记录复活 live receipt。当前实验的 sender／context／用户证明为替身，实际统一 UI 与原生用户来源联合仍待验证。

'''
assert needle in t;t=t.replace(needle,add+needle,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.100 ' not in t
add='''### 4.100 既有业务读模型、邮件回执与人工核实

[十二项当前实际服务检查](实验/20261114_既有业务读模型与邮件回执验证/README.md)补证现有 ApplicationActivityService、邮件冻结／执行／回执、草稿历史关联和人工核实服务。桥／Data API 本来共享 operationId，现有 subject 可定位无项目连接管理与邮件对象，应复用现有历史而非替换。分页、缺浏览器表兼容及合并投影不构成准入完整性证明；合成底层冲突和无归属浏览器反例已留存。

部分接受表现为 server-accepted／draft sent 但 complete=false；同身份密钥轮换、旧选用撤销／重选、矛盾回执 unknown、取消后迟到结果和一次执行均经实际服务验证。readDraftSendHistory 补足泛型详情的跨记录关联；人工 sent／not-sent 追加事实不改原 SMTP unknown，后者复制新草稿但不授权发送。最终 12 项通过、四次受控 submit、两份人工观察，无 SMTP／模型／真实 UI；actor、来源证明、核实 context／sender 为替身。真实上下文／身份预检／用户来源及准入联合未关闭，T0.1 §9.2.2 和后续 A41 已补保留合同。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| D04 '):
  cols=line.split('|');cols[2]=' §4.99–100 已补候选汇总与当前实际活动／邮件回执／人工核实基线，明确显示去重与完整准入不同。下一步接实际 ApplicationExecutionContexts／MailSendDataService 的预检、身份与最终用户来源授权，验证对象范围和跨运行读取；再与 D01 同库准入及所有写入口共享协调边界，覆盖提交后变更、核实记录修订、恢复与未决索引。插件／浏览器／四类 MCP 已有证据按边界复用，大库查询另验 ';lines[i]='|'.join(cols)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.99，56','截至 §4.100，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('最新进展：'):lines[i]='最新进展：十二项既有业务服务检查通过，补齐现有活动历史复用、邮件部分接受与人工核实记录保留设计；没有产品代码修改。见[实验记录](技研/实验/20261114_既有业务读模型与邮件回执验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if line.startswith('下一步：'):lines[i]='下一步：按[验证账 D04](技研/全局设计验证账.md#71-当前全局收口方式)联合实际业务上下文、邮件身份预检／用户来源授权和对象范围，再接同库运行准入／全入口协调。现有历史与核实服务继续保留，真实 UI／安装验收留在后续产品阶段。'
put(rel,'\n'.join(lines)+'\n')
rel=base/'验收/测试用例.md';t=(repo/rel).read_text();start=t.index('### M14-A41 ');end=t.index('<a id="m14-a42">',start);s=t[start:end]
s=s.replace('重开服务仅保留持久证据。','重开服务仅保留持久证据；模拟部分收件人接受、发送未知及人工 sent／not-sent 核实，核对跨 Provider 后的详情与新草稿；核实后修改来源关联或提交另一窗口的矛盾决定。',1)
s=s.replace('SDK 原生允许不替代宿主批准。','SDK 原生允许不替代宿主批准；部分接受不能显示全部成功；人工核实独立展示且不改原 SMTP 结果，not-sent 只创建新草稿，新发送仍核对原 unknown 并取得明确新授权；历史关联损坏拒绝，不凭当前页或展示合并判定可继续执行。',1)
s=s.replace('真实外部发送需另有明确授权。','补充原传输回执、人工核实追加记录及新草稿／intent 关系；真实外部发送需另有明确授权。',1);t=t[:start]+s+t[end:];put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files)},ensure_ascii=False))
