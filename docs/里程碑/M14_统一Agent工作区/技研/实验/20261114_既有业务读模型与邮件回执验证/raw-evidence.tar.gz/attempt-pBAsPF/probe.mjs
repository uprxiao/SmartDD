import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync,copyFileSync,mkdirSync,cpSync} from 'node:fs';
import a from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
for(const name of ['probe.mjs','build.mjs','build.json'])copyFileSync(root+'/'+name,out+'/'+name);
const checks=[];let f,service,error,submissions=0,submitBehavior,settleProducer;
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});save(id+'.json',evidence);}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
try{
 f=await a.runFixture();const db=f.sqlite,store=f.store,events=new Map(),actor={projectId:'p1',taskId:f.snapshot.taskId,runId:'controlled-mail-run'},hash='a'.repeat(64),stamp=new Date().toISOString();
 const secrets=a.makeSyntheticSecrets(db),connections=new a.ApplicationConnectionService(store,secrets,{verify:async c=>({providerId:c.kind,serviceId:'synthetic-service',accountId:c.username,contractMajor:1})});
 let smtp=await connections.save({expectedRevision:0,name:'Synthetic only',config:{kind:'smtp',host:'smtp-fixture.example.test',port:2525,username:'sender@example.test',fromAddress:'sender@example.test',authMode:'password',mode:'plain'},secret:'public-fixture-secret'});
 const selections=new a.ApplicationSelectionService(store,connections,{requireProject:id=>{assert.equal(id,'p1');},stopProjectRuns:async()=>true,runningInProject:()=>0});
 await selections.setAdded('mail',true,0);await selections.select({projectId:'p1',appId:'mail',enabled:true,expectedRevision:0,connections:{foxmail:null,smtp:smtp.id}});
 const policy={requireDrafts:x=>selections.requireApplicationEnabled(x.projectId,'mail'),requireSend:x=>selections.requireApplicationEnabled(x.projectId,'mail'),authenticate:(_x,c)=>connections.authentication(c.id,c),verifyUserAction:(_x,id)=>{if(!events.has(id))throw Error('No synthetic proof');return events.get(id);},ownerState:()=> 'stopped'};
 const blobs=new a.MailBlobStore(store,f.root+'/mail',policy),drafts=new a.MailDraftService(store,blobs,policy),activity=new a.ApplicationActivityService(store);
 const accepted=(_c,_s,m)=>({state:'server-accepted',complete:true,accepted:[...m.envelope.to],rejected:[],errorCode:null,smtpCode:250,messageId:m.messageId});submitBehavior=accepted;
 service=new a.MailExecutionService(store,drafts,connections,selections,policy,{submit:async(...args)=>{submissions++;return submitBehavior(...args);}});
 const content=()=>({mode:'new',sourceMessageRef:null,senderConnectionId:null,to:['receiver@example.test'],cc:[],bcc:['private@example.test'],subject:'Synthetic research only',text:'Public fixture',html:null,inReplyTo:null,references:[],attachmentIds:[]});
 const prepare=async()=>{const draft=await drafts.create(actor,{operationId:randomUUID(),content:content()}),input={operationId:randomUUID(),draftId:draft.id,expectedRevision:draft.revision,expectedContentHash:draft.contentHash};return{draft,input,intent:await service.prepare(actor,input)};};
 const proof=(intent,over={})=>{const id=randomUUID(),now=Date.now();events.set(id,{id,source:'renderer-confirmation',sourceHash:hash,intentId:intent.id,reviewHash:intent.reviewHash,projectId:actor.projectId,taskId:actor.taskId,runId:actor.runId,createdAt:new Date(now).toISOString(),expiresAt:new Date(now+600000).toISOString(),reviewedUnknownExecutionIds:[],...over});return id;};
 const authorize=intent=>service.authorize(actor,intent.id,proof(intent));
 let first,unknown,partial;
 await check('M01','actual preparation freezes intent and exact proof is required',async()=>{
  first=await prepare();assert.equal(first.intent.state,'awaiting-authorization');assert.equal((await service.prepare(actor,first.input)).id,first.intent.id);
  assert.equal(submissions,0);await assert.rejects(service.authorize(actor,first.intent.id,'approved=true'),{code:'AUTHORIZATION_REQUIRED'});
  await assert.rejects(service.execute(actor,first.intent.id),{code:'AUTHORIZATION_REQUIRED'});
  const bad=proof(first.intent,{runId:'different-run'});await assert.rejects(service.authorize(actor,first.intent.id,bad),{code:'AUTHORIZATION_REQUIRED'});
  await authorize(first.intent);await assert.rejects(service.execute({...actor,runId:'another-run'},first.intent.id),{code:'SCOPE_DENIED'});
  return{frozen:first.intent.id,duplicatePreparationSameIntent:true,modelBooleanRejected:true,otherRunRejected:true,submissions};
 });
 await check('M02','key rotation uses current same-identity secret and duplicate execute returns original receipt',async()=>{
  smtp=await connections.save({id:smtp.id,expectedRevision:smtp.revision,name:smtp.name,config:smtp.config,secret:'rotated-public-fixture-secret'});
  const before=submissions;submitBehavior=(c,s,m)=>{assert.equal(s,'rotated-public-fixture-secret');assert.equal(db.prepare('SELECT state FROM mail_send_grants WHERE intent_id=?').get(first.intent.id).state,'used');return accepted(c,s,m);};
  const sent=await service.execute(actor,first.intent.id);assert.equal(sent.state,'server-accepted');events.clear();assert.deepEqual(await service.execute(actor,first.intent.id),sent);assert.equal(submissions,before+1);
  const detail=activity.detail('send',sent.id);assert.equal(detail.send.result.complete,true);assert.equal(detail.item.send.executionId,sent.executionId);
  return{executionId:sent.executionId,submissions:submissions-before,repeatUsesReceipt:true,activityHasOriginalResult:true};
 });
 await check('M03','invalid receipt is unknown and copied content requires reviewing previous unknown execution',async()=>{
  const x=await prepare();await authorize(x.intent);const before=submissions;
  submitBehavior=(_c,_s,m)=>({...accepted(null,null,m),state:'failed'});
  unknown=await service.execute(actor,x.intent.id);assert.equal(unknown.state,'unknown');assert.equal(unknown.result.errorCode,'INVALID_RECEIPT');assert.equal(activity.detail('send',unknown.id).send.result.state,'unknown');
  await service.execute(actor,unknown.id);assert.equal(submissions,before+1);
  const copy=await drafts.copyAsNew(actor,x.draft.id,1,randomUUID()),intent=await service.prepare(actor,{operationId:randomUUID(),draftId:copy.id,expectedRevision:copy.revision,expectedContentHash:copy.contentHash});
  assert.deepEqual(intent.review.priorUnknownExecutionIds,[unknown.executionId]);await assert.rejects(authorize(intent),{code:'AUTHORIZATION_REQUIRED'});
  await service.authorize(actor,intent.id,proof(intent,{reviewedUnknownExecutionIds:[unknown.executionId]}));await service.cancel(actor,intent.id);
  return{executionId:unknown.executionId,invalidResultRetained:true,copyHasUnknownAncestry:true,noAutomaticResend:true,explicitProofIsControlledFixtureNotHumanApproval:true};
 });
 await check('M04','partial SMTP acceptance stays partial in actual history detail',async()=>{
  const x=await prepare();await authorize(x.intent);submitBehavior=(_c,_s,m)=>({...accepted(null,null,m),accepted:[m.envelope.to[0]],rejected:[m.envelope.to[1]],complete:true});
  partial=await service.execute(actor,x.intent.id);assert.equal(partial.state,'server-accepted');assert.equal(partial.result.complete,false);
  const detail=activity.detail('send',partial.id);assert.equal(detail.send.result.complete,false);assert.equal(detail.send.result.rejected.length,1);
  assert.equal(drafts.get(actor,x.draft.id).state,'sent');
  return{intentState:partial.state,draftState:'sent',resultComplete:false,rejectedCount:1,design:'Unified UI must read result completeness; state alone is insufficient'};
 });
 await check('M05','same connection reselected does not revive an earlier grant',async()=>{
  const x=await prepare();await authorize(x.intent);const before=submissions;
  let b=selections.projectSettings('p1','mail');await selections.select({projectId:'p1',appId:'mail',expectedRevision:b.revision,enabled:true,connections:{foxmail:null,smtp:null}});
  b=selections.projectSettings('p1','mail');await selections.select({projectId:'p1',appId:'mail',expectedRevision:b.revision,enabled:true,connections:{foxmail:null,smtp:smtp.id}});
  await assert.rejects(service.execute(actor,x.intent.id),{code:'INTENT_STALE'});assert.equal(service.get(actor,x.intent.id).state,'stale');assert.equal(submissions,before);
  return{sameConnectionDifferentBindingRevision:true,stale:true,submissions:0};
 });
 await check('M06','late provider completion after cancellation does not replace unknown or resend',async()=>{
  const x=await prepare();await authorize(x.intent);const before=submissions;let entered;const ready=new Promise(r=>entered=r),gate=new Promise(r=>settleProducer=r);let completed;const done=new Promise(r=>completed=r);
  submitBehavior=async(c,s,m)=>{entered();try{await gate;return accepted(c,s,m);}finally{completed();}};
  const pending=service.execute(actor,x.intent.id);await ready;await service.invalidateRun(actor.runId);const cancelled=await pending;assert.equal(cancelled.state,'unknown');
  settleProducer();await done;settleProducer=undefined;assert.equal(service.get(actor,x.intent.id).state,'unknown');await service.execute(actor,x.intent.id);assert.equal(submissions,before+1);
  return{unknownAfterCancel:true,lateAcceptedDoesNotRewrite:true,submissions:submissions-before,transport:'controlled Promise, no SMTP'};
 });
 const insert=(table,row)=>db.prepare(`INSERT INTO ${table}(${Object.keys(row).join(',')}) VALUES(${Object.keys(row).map(()=>'?').join(',')})`).run(...Object.values(row));
 const operation=(over={})=>{const id=randomUUID();insert('application_data_operations',{operation_id:id,caller_kind:'ui',scope_kind:'project',project_id:'p1',app_id:'mail',package_hash:'synthetic',data_api:1,action:'mail.fixture',semantics:'read',scope_hash:hash,targets_json:'[]',state:'succeeded',started_at:stamp,...over});return id;};
 await check('M07','existing read model resolves recorded subjects and plugin targets without current configuration',async()=>{
  const id=operation({scope_kind:'connection-management',project_id:null,action:'connection.save'});insert('application_activity_subjects',{operation_id:id,kind:'connection',subject_id:smtp.id});
  assert(activity.list({connectionId:smtp.id}).items.some(i=>i.id===id));
  const oldConnection=randomUUID(),target={slot:'demo-local',connectionId:oldConnection,identityRevision:1,revision:1,configRevision:1,policyRevision:1,secretRevision:1};
  const plugin=operation({app_id:'demo-tracker',targets_json:JSON.stringify([target])});
  assert.deepEqual(activity.detail('operation',plugin).item.connections,[{id:oldConnection,name:null}]);assert.equal(activity.list({appId:'demo-tracker',connectionId:oldConnection}).items[0].id,plugin);
  db.prepare('UPDATE application_data_operations SET targets_json=? WHERE operation_id=?').run(JSON.stringify([{...target,id:randomUUID()}]),plugin);
  assert.throws(()=>activity.list({connectionId:oldConnection}),{code:'RESOURCE_RECOVERY_REQUIRED'});db.prepare('UPDATE application_data_operations SET targets_json=? WHERE operation_id=?').run(JSON.stringify([target]),plugin);
  return{managementSubjectWithoutProjectVisible:true,historicalPluginConnectionPreserved:true,ambiguousTargetRejected:true,noConnectionRebinding:true};
 });
 await check('M08','read model deduplication must not be reused as integrity or admission proof',async()=>{
  const run=await f.create();await run.prepare();await run.cancelBeforeFork();const id=operation({caller_kind:'agent-run',run_id:run.runId,task_id:f.snapshot.taskId});
  insert('application_invocations',{operation_id:id,run_id:run.runId,request_id:randomUUID(),request_hash:hash,project_id:'p1',task_id:f.snapshot.taskId,app_id:'mail',package_hash:'synthetic',tool_name:'mail.fixture',contract_major:1,semantics:'read',state:'succeeded',effect_state:'read-only',started_at:stamp});
  assert.equal(activity.list({appId:'mail',limit:100}).items.filter(i=>i.id===id).length,1);
  db.prepare("UPDATE application_data_operations SET semantics='write',state='unknown' WHERE operation_id=?").run(id);
  const shown=activity.detail('operation',id);assert.equal(shown.item.state,'succeeded');assert.equal(shown.item.semantics,'read');assert.equal(db.prepare('SELECT state FROM application_data_operations WHERE operation_id=?').get(id).state,'unknown');
  return{legitimateSharedIdentityDeduplicated:true,syntheticConflictMaskedByReadProjection:true,notClaimOfNormalRuntimeCorruption:true,admissionMustValidateBothSources:true};
 });
 await check('M09','pagination and old-schema browser fallback are UI behavior, not source completeness',async()=>{
  const first=activity.list({appId:'mail',limit:1});assert(first.nextCursor);assert.throws(()=>activity.list({appId:'zentao',limit:1,cursor:first.nextCursor}),{code:'INVALID_INPUT'});
  insert('browser_operations',{run_id:'unknown-origin',request_id:randomUUID(),task_id:'missing-task',command:'click',state:'unknown',effect_state:'unknown',created_at:1,updated_at:1});
  const unfiltered=activity.list({appId:'browser'});assert.equal(unfiltered.items.length,1);assert.equal(unfiltered.items[0].projectId,null);assert.equal(activity.list({appId:'browser',projectId:'p1'}).items.length,0);
  db.exec('ALTER TABLE browser_operations RENAME TO research_hidden_browser');try{assert.equal(activity.list({appId:'browser'}).items.length,0);}finally{db.exec('ALTER TABLE research_hidden_browser RENAME TO browser_operations');}
  return{paginationIsNotCompleteSnapshot:true,cursorFilterBound:true,orphanBrowserFilteredOut:true,missingBrowserTableCompatibilityFallback:true,admissionRequiresIndependentCoverage:true};
 });
 await check('M10','history inspection is read-only and malformed terminal mail results are rejected',async()=>{
  const counts=()=>['application_invocations','application_data_operations','mail_send_grants','mail_send_executions'].map(t=>db.prepare('SELECT count(*) n FROM '+t).get().n),before=counts(),n=submissions;
  activity.list({limit:100});activity.detail('send',partial.id);assert.deepEqual(counts(),before);assert.equal(submissions,n);
  const row=db.prepare('SELECT result_json FROM mail_send_executions WHERE id=?').get(partial.executionId);
  db.prepare('UPDATE mail_send_executions SET result_json=? WHERE id=?').run('{bad',partial.executionId);try{assert.throws(()=>activity.detail('send',partial.id),{code:'RESOURCE_RECOVERY_REQUIRED'});}finally{db.prepare('UPDATE mail_send_executions SET result_json=? WHERE id=?').run(row.result_json,partial.executionId);}
  return{inspectionCreatesNoCallsOrGrants:true,corruptResultNotSuccess:true};
 });
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 settleProducer?.();if(service)await service.dispose();if(f){await f.runs.dispose();assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);await f.sqlite.backup(out+'/final.sqlite');mkdirSync(out+'/mail',{recursive:true});cpSync(f.root+'/mail',out+'/mail',{recursive:true});save('fixture.json',{root:f.root});f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:error??null,submissions,scope:'Actual connection/selection/secrets/draft/blob/mail execution/activity services on current isolated SQLite. Synthetic cipher, connection verifier, actors/user-proof policy and submit transport; no SMTP/network/real user approval/SDK/UI/product edit.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,error:result.error,submissions}));
