#include <sys/event.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char **argv){
  int q=kqueue();if(q<0)return 2;
  for(int i=1;i<argc;i++){struct kevent e;EV_SET(&e,(uintptr_t)strtol(argv[i],NULL,10),EVFILT_PROC,EV_ADD|EV_ONESHOT,NOTE_EXIT,0,NULL);if(kevent(q,&e,1,NULL,0,NULL)<0){perror("register");return 3;}}
  puts("READY");fflush(stdout);
  for(int i=1;i<argc;i++){struct kevent e;if(kevent(q,NULL,0,&e,1,NULL)!=1)return 4;printf("EXIT %lu\n",(unsigned long)e.ident);fflush(stdout);}
  close(q);return 0;
}
