import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,appendFileSync,copyFileSync,globSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {library,helper,Database,save,bound,nativeTurn,openActor} from './native.mjs';
const root=import.meta.dirname,readTool='smartdd_zentao_query_v1',writeTool='smartdd_zentao_write_v1';
const hash=x=>createHash('sha256').update(x).digest('hex');
function queue(dir){const db=new Database(dir+'/queue.sqlite');db.pragma('journal_mode=WAL');db.pragma('synchronous=FULL');db.exec(`
CREATE TABLE IF NOT EXISTS result(id TEXT PRIMARY KEY,body TEXT NOT NULL,revision TEXT NOT NULL,notice TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS observation(result_id TEXT NOT NULL,run_id TEXT NOT NULL,token TEXT NOT NULL UNIQUE,state TEXT NOT NULL,ack_count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(result_id,run_id));
CREATE TABLE IF NOT EXISTS lease(id INTEGER PRIMARY KEY CHECK(id=1),run_id TEXT,state TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL,body TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS receipts(phase TEXT PRIMARY KEY,value TEXT NOT NULL);
`);return db;}
const state=db=>Object.fromEntries(['result','observation','lease','events','receipts'].map(t=>[t,db.prepare('SELECT * FROM '+t).all()]));
async function worker(dir,phase){
 const spec=JSON.parse(readFileSync(dir+'/spec.json')),db=queue(dir),actor=spec.actor;
 const tx=fn=>db.transaction(fn).immediate(),mark=(event,body={})=>db.prepare('INSERT INTO events(event,body) VALUES(?,?)').run(event,JSON.stringify({phase,hostPid:process.pid,...body}));
 let oldObservation,runId,token,modelCount=0;
 if(phase==='recovery'){
  const old=await openActor(actor);assert(old.recovered.length===1&&old.recovered[0].state==='stopped');
  const prior=old.sqlite.prepare('SELECT run_id,state FROM capability_runs').all();assert.equal(prior.length,1);assert.equal(prior[0].state,'stopped');
  const invocations=old.sqlite.prepare('SELECT operation_id,state,effect_state FROM application_invocations ORDER BY started_at').all();
  const pending=invocations.filter(x=>x.state==='running');assert.equal(pending.length,1);assert.equal(pending[0].effect_state,'unknown');
  assert.equal(old.sqlite.prepare("SELECT COUNT(*) n FROM capability_resource_leases WHERE owner_kind='run' AND state<>'released'").get().n,0);
  oldObservation=db.prepare('SELECT * FROM observation').get();assert(oldObservation);
  save(dir+'/owner-recovery.json',{recovered:old.recovered,prior,invocations,observation:oldObservation});old.cleanup();
  tx(()=>{
   const lease=db.prepare('SELECT * FROM lease').get();assert.equal(lease.run_id,prior[0].run_id);assert.equal(lease.state,'held');
   if(oldObservation.state==='offered')db.prepare("UPDATE observation SET state='delivery_unknown' WHERE token=?").run(oldObservation.token);
   db.prepare("UPDATE lease SET state='released'").run();mark('reconcile-after-real-owner-stopped',{oldRun:prior[0].run_id,observationState:oldObservation.state});
  });
 }
 const ackCommitted=phase==='recovery'&&spec.cut==='ack',expectedModels=phase==='fault'?3:ackCommitted?2:4,expectedTools=expectedModels-1;
 const input=phase==='fault'?'SERVER_COMPLETION_NOTICE '+spec.resultId+'. Read the result then acknowledge its token.':'EXPLICIT_RECOVERY '+spec.resultId+'. Inspect the durable result state; do not restart the child or repeat external work.';
 const answer=ackCommitted?'DURABLE_OBSERVATION_RECONCILED':'RESULT_CONFIRMED';
 try{
  const result=await nativeTurn(actor,phase,{dir:dir+'/'+phase,delegationId:spec.resultId,input,answer,expectedModels,expectedTools,
   acquire:id=>tx(()=>{assert(db.prepare('SELECT state FROM lease').get()?.state!=='held');runId=id;db.prepare("INSERT INTO lease VALUES(1,?,'held') ON CONFLICT(id) DO UPDATE SET run_id=excluded.run_id,state='held'").run(id);mark('acquire',{runId:id});}),
   assertLease:id=>{const lease=db.prepare('SELECT * FROM lease').get();assert.equal(lease.run_id,id);assert.equal(lease.state,'held');},
   execute:call=>tx(()=>{
    const op=JSON.parse(call.value);assert.equal(call.runId,runId);assert.equal(call.taskId,actor.taskId);assert.equal(op.resultId,spec.resultId);mark('operation',{action:op.action,runId,operationId:call.operationId});
    const result=db.prepare('SELECT * FROM result').get();
    if(op.action==='status'){
     assert.equal(call.toolName,readTool);assert(ackCommitted);const rows=db.prepare('SELECT * FROM observation').all();assert.equal(rows.length,1);assert.equal(rows[0].state,'observed');
     return JSON.stringify({state:'observed',observedByRun:rows[0].run_id,ackCount:rows[0].ack_count,replay:false});
    }
    assert.equal(call.toolName,writeTool);
    if(op.action==='read_result'){
     let row=db.prepare('SELECT * FROM observation WHERE result_id=? AND run_id=?').get(spec.resultId,runId);
     if(!row){row={token:randomUUID()};db.prepare("INSERT INTO observation VALUES(?,?,?,'offered',0)").run(spec.resultId,runId,row.token);}
     token=row.token;mark('result-offered',{token,runId});return JSON.stringify({result:result.body,revision:result.revision,observationToken:token});
    }
    assert.equal(op.action,'ack_result');
    const row=db.prepare('SELECT * FROM observation WHERE result_id=? AND run_id=? AND token=?').get(spec.resultId,runId,op.token);
    if(!row){mark('cross-run-token-rejected');return JSON.stringify({status:'blocked',code:'OBSERVATION_SCOPE_MISMATCH'});}
    assert.equal(op.revision,result.revision);if(row.state!=='observed')db.prepare("UPDATE observation SET state='observed',ack_count=ack_count+1 WHERE token=?").run(row.token);
    mark('ack-committed',{runId,token:row.token});return JSON.stringify({status:'observed',token:row.token});
   }),
   afterExecute:async data=>{
    const op=JSON.parse(data.call.value);if(phase!=='fault'||op.action!==(spec.cut==='read'?'read_result':'ack_result'))return;
    assert.equal(modelCount,spec.cut==='read'?1:2);mark('response-held-before-tool-service-success',{action:op.action});
    save(dir+'/fault-checkpoint.json',{...data,modelCount,queue:state(db)});
    process.send({type:'checkpoint',identities:data.identities});await new Promise(()=>{});
   },
   model:async({body,tools,count,mark:trace})=>{
    modelCount=count;const content=JSON.stringify(body.messages??body.input);
    const call=(action,payload={},read=false)=>{const tool=tools.find(t=>((t.namespace??'')+(t.name??'')).includes(read?readTool:writeTool));assert(tool);return{tool,args:{value:JSON.stringify({action,resultId:spec.resultId,...payload})}};};
    if(count===1){assert(content.includes(input));if(phase==='fault'){assert(!content.includes(spec.body));assert.equal(db.prepare('SELECT COUNT(*) n FROM observation').get().n,0);db.prepare("UPDATE result SET notice='accepted'").run();mark('notice-accepted-no-result');}
     return ackCommitted?call('status',{},true):call('read_result');}
    if(ackCommitted){assert(content.includes('observed'));assert(content.includes(oldObservation.run_id));assert.equal(db.prepare('SELECT COUNT(*) n FROM observation').get().n,1);return{text:answer};}
    assert(content.includes(spec.body));assert(content.includes(token));trace('result-and-token-in-native-model-request',{token});
    if(phase==='fault'&&count===2)return call('ack_result',{token,revision:hash(spec.body)});
    if(phase==='recovery'&&count===2){assert.notEqual(token,oldObservation.token);return call('ack_result',{token:oldObservation.token,revision:hash(spec.body)});}
    if(phase==='recovery'&&count===3){assert(content.includes('OBSERVATION_SCOPE_MISMATCH'));assert.equal(db.prepare('SELECT SUM(ack_count) n FROM observation').get().n,0);return call('ack_result',{token,revision:hash(spec.body)});}
    assert.equal(db.prepare('SELECT SUM(ack_count) n FROM observation').get().n,1);return{text:answer};
   },
   release:receipt=>tx(()=>{db.prepare('INSERT INTO receipts VALUES(?,?)').run(phase,JSON.stringify(receipt));db.prepare("UPDATE lease SET state='released'").run();mark('release',{runId:receipt.runId});})
  });
  assert.equal(phase,'recovery');save(dir+'/recovery-final.json',{result,queue:state(db)});process.send?.({type:'done'});
 }finally{db.close();}
}
async function seed(driver,workspace){
 const {runFixture,MacProcessIdentityReader}=library(driver),f=await runFixture(new MacProcessIdentityReader(helper),{application:true,runtime:readFileSync(root+'/mcp-bridge.cjs'),workspace});
 const extraHashes=Object.fromEntries(f.sqlite.prepare("SELECT resource_id,content_hash FROM capability_resources WHERE kind IN ('fixture-dependency','agent-adapter')").all().map(r=>[r.resource_id,r.content_hash]));
 const actor={driver,root:f.root,home:f.home,taskId:f.snapshot.taskId,workspace,extraHashes,snapshot:f.snapshot};f.sqlite.close();return actor;
}
async function launch(dir,phase,hosts){
 const p=spawn(process.execPath,[import.meta.filename,'--worker',dir,phase],{env:{PATH:'/usr/bin:/bin',HOME:dir},stdio:['ignore','pipe','pipe','ipc']});
 const h={pid:p.pid,phase};hosts.push(h);let watcherPromise;
 const exited=new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',(code,signal)=>{Object.assign(h,{code,signal});resolve();});});
 p.stdout.on('data',b=>appendFileSync(dir+'/'+phase+'.stdout',b));p.stderr.on('data',b=>appendFileSync(dir+'/'+phase+'.stderr',b));
 p.on('message',m=>{
  if(m.type==='done')h.done=true;
  if(m.type==='checkpoint'){
   assert.equal(phase,'fault');assert(!watcherPromise);
   watcherPromise=(async()=>{
    const watcher=spawn(root+'/watch-exit',m.identities.map(x=>String(x.pid)),{stdio:['ignore','pipe','pipe']});h.watcherPid=watcher.pid;let text='';
    const stopped=new Promise((resolve,reject)=>{watcher.once('error',reject);watcher.once('exit',code=>code===0?resolve():reject(Error('watcher exit '+code)));});
    watcher.stdout.on('data',b=>{text+=b;writeFileSync(dir+'/exit-events.txt',text);if(text.includes('READY')&&!h.killIssued){h.killIssued=true;p.kill('SIGKILL');}});watcher.stderr.on('data',b=>appendFileSync(dir+'/watcher.stderr',b));
    await stopped;const {MacProcessIdentityReader}=library('claude'),reader=new MacProcessIdentityReader(helper);for(const id of m.identities)assert.equal(reader.state(id),'stopped');save(dir+'/kernel-exits.json',m.identities);
   })();watcherPromise.catch(()=>{});
  }
 });
 try{await bound(exited,90000,'worker observation');}catch(e){save(dir+'/observation-timeout.json',{message:e.message,pid:p.pid});await exited;}
 if(watcherPromise)await watcherPromise;
 if(phase==='fault'){assert.equal(h.signal,'SIGKILL');assert(h.killIssued);}else{assert.equal(h.code,0);assert(h.done);}
}
async function controller(){
 const out=mkdtempSync(root+'/attempt-'),checks=[],hosts=[];for(const f of ['build.json','build.mjs','native.mjs','probe.mjs','watch-exit.c'])copyFileSync(root+'/'+f,out+'/'+f);let error;
 try{for(const driver of ['claude','codex'])for(const cut of ['read','ack']){
  if(process.argv[2]&&!(`${driver}-${cut}`).startsWith(process.argv[2]))continue;
  const dir=out+'/'+driver+'-'+cut;mkdirSync(dir);const workspace=dir+'/workspace';mkdirSync(workspace);const resultId=randomUUID(),body='SYNTHETIC_TERMINAL_RESULT_'+resultId;
  const spec={driver,cut,resultId,body,actor:await seed(driver,workspace)};save(dir+'/spec.json',spec);let q=queue(dir);q.prepare("INSERT INTO result VALUES(?,?,?,'queued')").run(resultId,body,hash(body));q.close();
  await launch(dir,'fault',hosts);q=queue(dir);save(dir+'/after-kill.json',state(q));assert.equal(q.prepare('SELECT SUM(ack_count) n FROM observation').get().n,cut==='ack'?1:0);assert.equal(q.prepare('SELECT state FROM lease').get().state,'held');q.close();
  const checkpoint=JSON.parse(readFileSync(dir+'/fault-checkpoint.json'));assert.equal(checkpoint.modelCount,cut==='read'?1:2);
  const modelRows=readFileSync(dir+'/fault/model.jsonl','utf8').trim().split('\n').map(JSON.parse);assert.equal(modelRows.length,checkpoint.modelCount);if(cut==='read')assert(!JSON.stringify(modelRows).includes(body));else assert(JSON.stringify(modelRows[1]).includes(body));
  await launch(dir,'recovery',hosts);q=queue(dir);const final=state(q);assert.equal(final.observation.length,cut==='read'?2:1);assert.equal(final.observation.reduce((n,r)=>n+r.ack_count,0),1);assert.equal(final.lease[0].state,'released');assert.equal(final.receipts.length,1);
  if(cut==='read'){assert(final.observation.some(r=>r.state==='delivery_unknown'));assert.equal(final.events.filter(e=>e.event==='cross-run-token-rejected').length,1);}else assert.equal(final.events.filter(e=>e.event==='result-offered').length,1);
  await q.backup(dir+'/queue-final.sqlite');q.close();
  const sql=new Database(spec.actor.root+'/state.sqlite',{readonly:true});const runs=sql.prepare('SELECT run_id,state FROM capability_runs').all();assert.equal(runs.length,2);assert(runs.every(x=>x.state==='stopped'));assert.equal(sql.prepare("SELECT COUNT(*) n FROM capability_resource_leases WHERE owner_kind='run' AND state<>'released'").get().n,0);
  await sql.backup(dir+'/capabilities.sqlite');sql.close();mkdirSync(dir+'/native-history');globSync(spec.actor.snapshot.native.stateRoot+'/**/*.jsonl').forEach((p,i)=>copyFileSync(p,dir+'/native-history/'+i+'.jsonl'));
  const finalNative=JSON.parse(readFileSync(dir+'/recovery/result.json'));const oldBound=readFileSync(dir+'/fault/trace.jsonl','utf8').trim().split('\n').map(JSON.parse).find(x=>x.event==='native-session-bound');assert.equal(finalNative.thread,oldBound.sessionId);
  const check={id:driver+'-'+cut,status:'passed',cut:cut==='read'?'result-offered-response-held':'ack-committed-response-held',nativeRuns:2,modelRequests:modelRows.length+finalNative.modelRequests,ackCount:1,oldInvocationStillRunningEffectUnknown:true,sameNativeThread:true};checks.push(check);save(dir+'/result.json',check);console.log(JSON.stringify(check));
 }}catch(e){error=e.stack;process.exitCode=1;}
 const result={out,checks,hosts,error,scope:'Real native, owner/private MCP and recovery; candidate result observation store, preseeded terminal result, synthetic model. Crash after candidate commit before tool response. No product source changes.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify(result,null,2));
}
if(process.argv[2]==='--worker')worker(process.argv[3],process.argv[4]).then(()=>process.disconnect(),e=>{console.error(e.stack);process.exitCode=1;process.disconnect();});else await controller();
