from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess,re,collections
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_文件查看器MCP生命周期验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==6 and result['error']is None
attempts=[root/n for n in ['attempt-ertv8v','attempt-R5ydlb','attempt-XwPOLZ']];build=json.loads((root/'build.json').read_text());watcher=json.loads((root/'watcher-inputs.json').read_text());native=[x for x in json.loads(Path('/private/tmp/willyou-m14-git-probe/build.json').read_text())['files']if '/native/files/'in x['path']]
for s in build['sources']+build['outputs']+watcher+native:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
dbs=[]
for p in attempts:
 f=p/'final.sqlite';db=sqlite3.connect(f.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()==('ok',);assert db.execute('pragma foreign_key_check').fetchall()==[];assert db.execute("select count(*) from capability_runs where state not in ('stopped','failed')").fetchone()==(0,);assert db.execute("select count(*) from capability_resource_leases where state<>'released'").fetchone()==(0,);db.close();dbs.append({'path':str(f.relative_to(root)),'integrity':'ok','foreignKeys':[]})
expanded=[]
for p in [repo/'src/main/db/migrations.ts',repo/'src/main/core/capabilities/assets.ts']:
 for pattern in re.findall(r"import\.meta\.glob\('([^']+)'",p.read_text()):
  for f in repo.glob(pattern.replace('@root/','')):
   if f.is_file():expanded.append({'path':str(f),'sha256':sha(f.read_bytes())})
refs=[repo/'src/main/index.ts']+[repo/'src/main/core/files'/n for n in ['sources.ts','roots.ts','file-service.ts','controller.ts','mcp/service.ts','mcp/local-provider.ts','mcp/stdio-provider.ts','mcp/ui-view.ts']]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C','/Users/hx/projects/t3code','rev-parse','HEAD'],text=True).strip(),'build':build,'expandedAssets':expanded,'externalWatcher':watcher,'nativeBrokerInputs':native,'nativeBroker':{'path':'/private/tmp/willyou-m14-git-probe/file-broker','sha256':sha(Path('/private/tmp/willyou-m14-git-probe/file-broker').read_bytes())},'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Actual current file services, local MCP client/server and native broker. Electron allocation forbidden by explicit stub; actual parcel watcher loaded externally, not mocked. No native SDK switch, stdio provider or real UI.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
runtime={'finalPassed':6,'attempts':[{'name':p.name,'passed':json.loads((p/'result.json').read_text())['passed'],'error':json.loads((p/'result.json').read_text())['error']}for p in attempts],'finalChildExit':json.loads((attempts[-1]/'child-exit.json').read_text()),'transportCloses':result['closed'],'sqliteChecks':dbs,'initialModuleLoadFailure':'Bundling @parcel/watcher lost optional native module resolution before fixture creation; actual installed module then loaded as explicit external, no watcher stub.','failedSaveDiagnosis':'Nested sandbox-exec denied by execution environment. Isolated retry with reviewed execution permission passed. No fallback to an unconfined broker was added.','modelCalls':0,'productChanges':0};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
files=[root/n for n in ['build.mjs','build.json','actual.cjs','electron-stub.cjs','watcher-inputs.json','probe.mjs','prepare.py','source-review.json','runtime-audit.json']]
for p in attempts:files+=sorted(f for f in p.iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files],'sqliteIntegrityAndForeignKeys':dbs}
for n,d in [('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtime,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('archive-manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2)),('raw-evidence.tar.gz',archive.read_bytes())]:put(exp/n,d)
put(exp/'README.md','''# 文件查看器 MCP 生命周期：独立技术验证

六项检查通过。使用当前 FileSourceResolver（真实 tasks 表／Drizzle）、FileRootsService、FileService、FileViewerService、本地 MCP Client／Server、原生文件 broker，以及当前运行注册器和一个真实自有普通 Node 子进程。所有文件均为隔离合成数据。

| 检查 | 实际证据 |
| --- | --- |
| M01 | 两个窗口 owner 各有自己的文件根／文档／MCP；读取内容一致，跨 owner 与错 generation 拒绝 |
| M02 | 普通 Agent 代用进程 exit 0、实际 run stopped 后，两个原查看器仍可读；直接修改夹具 tasks 的 runner／native_session_id 也不改变已有查看器对象。没有启动真实 Codex／Claude 切换 |
| M03 | Agent run 停止后，查看器通过实际 MCP 工具和 native broker 保存成功；外部写入后再次使用旧 ifMatch 得到 conflict，外部内容保留 |
| M04 | FileService.closeOwner 关闭 A 的 MCP transport，B 仍可读；已等待实际 Client.onclose 回调 |
| M05 | 改变任务 cwd 后旧根校验失败，旧 MCP 关闭，未悄悄读取新目录；重新 openScope／open 后取得新授权，新内容可读，旧请求仍拒绝 |
| M06 | closeDocument 撤销来源并关闭查看器；三份实际 transport 关闭回调收齐，没有用 close 方法返回代替关闭完成 |

设计结论：窗口／文件根／文档拥有查看器生命周期，run 不拥有它。Provider 切换不能调用 FileService.closeOwner 或重新配置全部 viewer adapters；保持 cwd 时保留文件区域，cwd 改变则让实际来源校验失效，并提示重新打开，不能把旧 lease 改指新根。查看器保存继续走原文件比较与保存事务，不授予 Agent 文件写权限。

范围：本地 first-party MCP resources 与条件写回；不是第三方 stdio 进程、MCP App 界面、真实窗口／IPC、SDK 切换或四类 MCP 同时运行。Electron stub 只禁止界面分配；文件服务、MCP 包、进程身份与 native broker 未替换。parcel watcher 使用原安装模块及原生依赖，记录摘要；本轮未订阅文件 watcher。

失败保留：最初 bundle 使 parcel watcher 的原生可选依赖无法定位，导入时失败、未建立夹具；改为加载实际外部模块。第一次实际探针遗漏 userdata 目录，M01 失败，捕获子进程已停止。补齐目录后 M01–02 通过，保存因当前执行环境禁止嵌套 sandbox-exec 而得到 unknown；诊断保留。获准在私有目录运行同一探针后六项通过，未删除产品 sandbox 或增加无沙箱重试。两次旧失败和最终结果各有 SQLite／运行收尾记录，不伪装成首跑全绿。

复跑：SmartDD cwd 下运行 build.mjs、probe.mjs；需原 native broker、macOS sandbox-exec 与 watcher 依赖。保存所需运行权限与本机沙箱有关。源码／native 输入摘要见 source-review，原始 broker 编译命令沿用既有 Git 目录实验。Q39 从静态核对推进为部分，不作整项产品通过。

[结果](result.json) · [运行审计](runtime-audit.json) · [源码](source-review.json) · [摘要](archive-manifest.json) · [原始记录](raw-evidence.tar.gz)。
''')
section='''### 9.8 文件查看器 MCP 与 Agent 运行独立

[六项实际服务检查](实验/20261114_文件查看器MCP生命周期验证/README.md)接通当前 FileSourceResolver／tasks 表、FileRootsService、FileService、真实本地 MCP 和原生文件 broker。实际 run 停止后，原查看器可继续读写；保存沿用 ifMatch 与原事务，外部编辑导致 conflict，原内容保留。两个窗口 owner 相互隔离，关闭一个不关闭另一个；关闭文档撤销来源并关闭 MCP。已等待真实 transport 关闭事件。本轮普通 Node 进程仅用于运行所有权，修改 runner 元数据为夹具，未证明真实 SDK 切换／界面联调。

迁移时保留三类身份：文件来源绑定 logical task／project 及明确 cwd；文档／根 lease 绑定窗口 owner 和 generation；查看器 MCP 绑定文档与该 owner。它们不改绑当前 Agent run，也不继承 Agent 的 MCP 配置作为 viewer 授权。切换 Provider、停止回合／run、子任务结束均不得顺带调用 FileService.closeOwner 或重新 configure 所有查看器；窗口导航／关闭、文档关闭、实际来源撤销及明确配置变更仍沿现有关闭路径处理。

FileSourceResolver 当前只读取 task 的 id／projectId／cwd，不读取 runner 或 nativeSessionId；固定 cwd 的 Provider 切换因此不需要重建文件区域。M14 多 binding／worktree 若改变当前执行目录，须明确区分“正在查看的已授权来源”和“新运行目录”。旧 ref 不可静默指向新 cwd。本轮真实路径变更使旧租约／MCP 失效，重新打开才取得新授权；新 UI 应保留草稿和来源提示，具体交互回归待接线后执行。

查看器资源与条件写工具只服务文件 UI；业务 MCP 沿 run 权限，宿主委派 MCP 沿编排身份，原生／第三方 MCP 沿各自运行定义，不能按名称统一销毁或共用授权。关闭方法发起异步清理，最终退出／重建应有可等待的关闭证明；本轮观察 onclose，不宣称当前所有关闭入口已提供统一 await API。第三方 stdio 进程、真实 MCP App 窗口、四类 MCP 同时运行及 SDK 切换仍待验证，Q39 保持部分。

'''
edit(base/'技研/技术方案.md',lambda t:t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点'))
def ledger(t):
 assert '### 4.77 'not in t
 t=t.replace('| Q39 | 查看器 MCP 与 Agent／业务／委派 MCP 各自拥有生命周期 | E08；R08 | 静态边界已核对；待实际关闭／切换 Agent 后验证查看器连接、窗口与资源保留 |','| Q39 | 查看器 MCP 与 Agent／业务／委派 MCP 各自拥有生命周期 | E08；R08 | **部分**：§4.77 补当前实际文件来源／服务、本地 MCP／native broker 与真实普通进程 run：run 停止后查看器读写保留、保存冲突、跨窗口／generation 拒绝、窗口／文档关闭和 cwd 失效；真实 SDK 切换、stdio 查看器、MCP App 窗口及四类 MCP 联合仍待验 |')
 t=t.replace('## 5. 失败与驱动修正','''### 4.77 文件查看器 MCP 独立生命周期

[六项检查](实验/20261114_文件查看器MCP生命周期验证/README.md)通过：当前 FileSourceResolver／FileRoots／FileService、真实本地 MCP 和原生文件 broker 联合实际 run 注册器，run 停止后查看器读写保留，外部编辑冲突不覆盖；跨 owner／generation 拒绝，关闭一个 owner 不影响另一个，cwd 改变拒绝旧授权，关闭文档结束 MCP。三份 transport 均等待真实关闭回调。

普通 Node 代用进程与 tasks runner 元数据夹具，不是两端 SDK 切换；Electron 分配禁止，没有真实窗口、stdio provider 或四类 MCP 完整联合。首轮漏 userdata、次轮环境拒绝 sandbox-exec 的失败及收尾保留；保留实际文件沙箱后，在已获权限的私有环境最终六项通过。Q39 由静态核对推进为部分，技术方案 §9.8 收口窗口／文档、文件来源和 run 的不同生命周期。产品与原型未改。

## 5. 失败与驱动修正''')
 # Counts describe the existing broad question items, not a research completion percentage.
 groups=collections.Counter()
 for l in t.splitlines():
  if re.match(r'^\| Q\d\d \|',l):
   a=l.split('|');qid=a[1].strip();s=a[4].strip();groups['deferred'if qid in ['Q21','Q22']else'optional'if qid=='Q36'else'partial'if s.startswith(('**部分','**实证限定','**发现问题并验证候选修正'))else'pending']+=1
 assert groups=={'partial':45,'pending':8,'deferred':2,'optional':1}
 t+='''
### 7.4 当前统计口径

截至 §4.77，56 个宽口径问题项中，45 项有部分实验／限定证据，8 项主要内容仍待验证或产品集成，2 项模板产品已按用户确认延后，1 项可选 SVN 自动管理不开放；整项完整关闭为 0。八项为 Q12、Q26、Q29、Q33、Q42、Q51、Q52、Q56。部分条目已有多轮证据但仍包含未覆盖分支；不是只剩八项。

这些问题项横跨研究合同与未来产品集成，因此不能用 45／56 作为研究完成率，也不能将整项未关闭解释为尚无实证。§7.1 已分别列出可独立验证的未知与开发后验收；下一步逐项根据证据核对剩余架构决定、可执行的隔离验证和产品专属条件。研究是否完成按 §7.2 判断，不以累计检查数或尚未开发的 UI 用例替代。此处统计来自 Q 表，不另建第二套需求清单。
'''
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：文件查看器生命周期六项检查通过，实际文件服务／MCP／原生 broker 在 run 停止后保留读写，窗口／文档关闭及 cwd 改变按原授权失效。Q39 推进为部分，见[技术方案 §9.8](技研/技术方案.md)。宽口径统计为 45 项部分证据、8 项待验证／集成、2 项延后及 1 项可选不开放，整项关闭仍为 0。',t)
 return re.sub(r'下一步：[^\n]*','下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的研究／产品条件分离和原生子 Agent 边界验证；保留文件查看器已有证据，真实窗口、stdio 扩展与 SDK 切换的联合另行核验，不重复计作已关闭。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'stagedFiles':len(entries),'checks':6,'archiveFiles':len(files),'sqliteFiles':len(dbs),'sourceInputs':len(build['sources'])}))
