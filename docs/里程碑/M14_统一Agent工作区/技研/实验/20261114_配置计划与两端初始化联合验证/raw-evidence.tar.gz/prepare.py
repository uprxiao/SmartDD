from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_配置计划与两端初始化联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==9 and not result.get('error');attempt=Path(result['out']);baseline=json.loads((root/'baseline.json').read_text());assert baseline['status']=='reproduced'
sources={}
for n in ['build.json','profile-build.json']:
 for s in json.loads((root/n).read_text())['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[s['path']]=s
for e in json.loads((root/'baseline-inputs.json').read_text()):assert sha((root/e['path']).read_bytes())==e['sha256'];assert sha(Path(e['source']).read_bytes())==e['sha256']
processes=[];native=[]
for test in result['checks']:
 id=test['id'];trace=[json.loads(l)for l in (attempt/(id+'-trace.jsonl')).read_text().splitlines()];created=[t for t in trace if t['event']=='wrapper-created'];exits=[t for t in trace if t['event']=='owned-exit'];assert len(created)==len(exits)==test['final']['spawnCount'];assert [t['pid']for t in created]==[t['pid']for t in exits];assert test['final']['runState']=='stopped';processes.extend({'case':id,**e}for e in exits)
 f=json.loads((attempt/(id+'-fixture.json')).read_text());r=f['runtime'];assert sha(Path(r['path']).read_bytes())==r['sha256'];native.append(r)
assert len(processes)==5 and sum(t['final']['payloadReleased']for t in result['checks'])==4
assert sha(Path(result['sdk']['path']).read_bytes())==result['sdk']['sha256'];helper=Path('/private/tmp/willyou-m14-owner-probe/process-identity')
runtimeAudit={'ownProcessExits':processes,'nativePayloadInitializations':4,'wrapperOnly':1,'modelTurns':0,'sdk':result['sdk'],'nativeResources':list({r['path']:r for r in native}.values()),'identityHelper':{'path':str(helper),'sha256':sha(helper.read_bytes())},'scope':'Only captured ChildProcess handles stopped; native initialization only; no model requests or native thread/start.'};(root/'runtime-audit.json').write_text(json.dumps(runtimeAudit,indent=2))
refs=[(repo,'src/main/core/ai/ai-profile-service.ts'),(repo,'src/main/secrets.ts'),(repo,'src/main/core/applications/run-registry.ts'),(repo,'src/main/core/applications/run-plan.ts'),(repo,'src/main/core/tasks/runner-adapters.ts'),(t3,'apps/server/src/orchestration-v2/ProviderSessionManager.ts'),(t3,'apps/server/src/provider/ProviderInstanceRegistry.ts'),(t3,'apps/server/src/provider/ProviderInstallationGate.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,p in refs],'scope':'Actual source with documented isolated variants; T3 source only, no T3 runtime changes.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps({'integration':result,'baseline':baseline},ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtimeAudit,indent=2))]:put(exp/n,data)
put(exp/'README.md',f'''# 配置、宿主计划与两端初始化：联合技术验证

日期：2026-11-14。对应 R02／03／08／11，Q04／06／13／20；设计 §3.2.12，验证账 §4.43。仅隔离技术实验，未改产品或共享原型。

## 本次补齐的关联

前批分别验证的单调执行配置修订、宿主 ExecutionPlan／应用计划／delivery、owned run 和取消门禁，这次置于同一候选链：实际配置服务解析→提交强关联计划和准备引用→运行租约接管→arm→受控 wrapper→内核身份 attach→再次核配置／计划→释放原生程序→初始化→显式取消并观察同一 ChildProcess 退出。

组合过程中移除了旧候选仍使用的 updatedAt 活校验及单独 fixture epoch。基线 `baseline.mjs` 用前批原样候选复现：只改名称会在 live reader 中报 TARGET_CONFIGURATION_CHANGED，尽管旧 fixture epoch 不变。此为研究候选遗漏，不是生产缺陷。新 execution v2／delivery v3 统一以真实配置表触发的单调修订作为运行前置；binding 的旧 profile_revision 字段不再充当执行 freshness，最终绑定兼容身份仍需独立设计。没有实现旧实验格式升级。

## 结果

`{attempt.name}` 的 J01–J09 全部通过，另保存旧候选更名误拒绝的负对照。共捕获五个子进程退出，其中四个真实原生初始化、一个仅 fork wrapper 后阻止 exec。未发送模型任务、未调用原生 thread/start、未调用业务工具。

| 项 | 已证明 |
| --- | --- |
| J01／J02 | Claude／Codex 两端：提交计划后实际服务更名并改 updatedAt，执行修订不变，原计划继续初始化成功；实际内核 PID／出生身份已登记，取消后核为 stopped |
| J03 | arm 后通过实际服务换 Key，旧计划在调用 native factory 前拒绝，未 fork；无需恢复配置即可清理 |
| J04 | Codex wrapper 已 fork、原生尚未 exec 时换 Key，attach 后复核拒绝放行，等 wrapper 实际退出；不冒充“从未 fork” |
| J05 | Claude 初始化后删除配置，旧计划不可再作为执行许可，仍可使用独立 owned 取消句柄结束原生进程 |
| J06 | Codex 初始化后换 Key，旧执行计划再取用拒绝，随后显式结束已启动进程；没有证明运行环境自动更新 |
| J07／J08 | 原生 spawn 回调试图换执行文件或冻结环境被拒绝，零 fork |
| J09 | 复制序列化 ExecutionPlan 句柄不能创建 launcher；配置删掉后的未启动任务仍可取消 |

## 版本、来源与边界

Claude SDK 0.3.321／native 2.1.321；Codex app-server 0.167.1；macOS arm64，程序与 SDK entry hash 在 runtime-audit。真实程序来自前批临时依赖目录，SDK 包资源完整安装／升级生命周期不是本批验证对象。独立 HOME／配置根、受控 PATH、仅指向不可用 loopback 的模型 URL／代理、合成凭据；没有用户登录配置或真实模型调用。

配置通过实际 AiProfileService／SecretsStore，密文加密器为假实现；单调修订为隔离 SQL 触发器。run 仍由旧 registry 的 legacy reserve 创建，随后夹具补 binding／cap／generation/source 关联；保留实际 v3 能力会话、v1 应用计划、真实 run 句柄／进程身份／资源租约。能力适配器及业务包仍为夹具，SDK 尚未接私有业务桥、当前业务权限和原生消息输入。

运行程序与冻结的配置环境由已核验 ExecutionPlan 提供，回调不能任意改换。宿主基础 env 是显式隔离夹具；外部 CLI 文件／系统代理／其他秘密源的完整来源指纹、真实 SDK 选项／用户参数映射和运行中后续 turn 仍未完成。程序文件校验到真正 exec 之间的替换窗口、其他宿主进程在最终检查后改配置、后台后代范围、崩溃恢复、首次真实 native thread ID 和完整 programmatic reserve 仍需验证。

初始化返回只证明握手成功，不是完整对话或单／多 Agent 功能完成。已有进程收到的旧环境不能因 revision 变化而撤回；J06 证明“后续旧许可拒绝＋显式结束”路径，不能宣称所有在途请求即时撤销。

## 证据与复跑

[结果及负对照](result.json)、[运行与版本审计](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[原始驱动／候选／数据库](raw-evidence.tar.gz)。本批 {len(files)} 个归档文件，{len(dbs)} 份 SQLite 通过完整性／外键检查，{len(sources)} 个构建输入复核。

在临时目录恢复匹配依赖、原生程序及 process-identity helper 后，可运行 `node baseline.mjs`、`node probe.mjs`。归档 baseline-inputs 保存实际负对照输入；所有状态、数据库、追踪和程序 hash 均独立记录。不得把这些研究表或变体直接作为产品迁移。
''')
section='''### 3.2.12 配置修订、运行计划与原生启动的联合边界

[联合初始化实验](实验/20261114_配置计划与两端初始化联合验证/README.md)把 §3.2.10 的宿主计划、§3.2.11 的实际配置修订和 §3.3 的 owned 取消接到同一候选链，取得两端真实初始化及关键改配置窗口的限定证据。前批候选仍残留 updatedAt 检查，更名会误拒绝；负对照已复现，现行设计的执行许可统一使用单调执行修订，不能同时用时间戳和另一套 epoch 各作一遍失效规则。绑定兼容身份与“本次执行选择是否仍有效”分开维护。

配置解析完成后，在准备事务中复核所捕获的执行修订，再与宿主计划、应用计划和交付引用一起关联提交。运行资源接管、arm 后／spawn 前和 attach 后／放行原生程序前，均核同一运行、计划及目标修订；不能在等待资源或初始化期间重新选择配置默认项。spawn 回调使用核验后的执行文件和冻结环境，不从回调参数再选账号／程序。密钥正文不写入持久计划，旧来源的历史审计仍保留。

配置失效的效果取决于实际启动位置：未 fork 时关闭回调并取消预留；wrapper 已出现时撤销放行、停止该进程并等待实际退出；原生已初始化时，旧计划不能授权新的执行动作，但既有进程不会被修订号自动停止，按独立生命周期权显式收口。删配置、换 Key 都不能夺走自己进程的取消／释放权。不要把退出前已发出的外部操作视为已撤销。

两端更名后初始化、arm 后换 Key、wrapper 后换 Key、初始化后删除／换 Key，以及回调替换程序／环境和复制句柄拒绝已验证。当前实验只到初始化，没有模型 turn、原生 thread/start 或业务调用；旧 reserve 后的候选关联、宿主基础环境及能力交付仍有夹具。完整 programmatic reserve、业务桥、输入与首次原生 ID、外部来源指纹、最终检查到 exec 的竞争及 SDK 参数映射仍按各项验证，不将本批称为完整 launcher 已验证。

'''
def tech(t):
 assert t.count('### 3.3 真实所有权')==1;return t.replace('### 3.3 真实所有权',section+'### 3.3 真实所有权')
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.43 配置、计划与两端真实初始化联合

[联合实验](实验/20261114_配置计划与两端初始化联合验证/README.md)以同一候选链执行 J01–J09：实际配置修订与 ExecutionPlan／delivery／owned run 联合到真实 Claude SDK／Codex 初始化。四个原生初始化、一个 wrapper-only 均观察同一子进程退出；更名不失效，arm 后或 wrapper 后换 Key 拒绝放行，初始化后删配置／换 Key 仍保留独立取消权，回调替换程序／环境及序列化句柄拒绝。

另用前批原样候选复现仅更名被残留 updatedAt 检查误拒绝，统一改用执行修订后两端通过。候选 execution v2／delivery v3 未做旧实验格式升级；run 仍是 legacy reserve 后夹具关联。模型 turn、业务桥、输入／真实 native ID、外部来源和最终检查到 exec 窗口未覆盖。T0.1 §3.2.12 收录联合约束，Q04／06／13／20 保持部分，不进入产品验收。

'''
def account(t):
 assert t.count('## 5. 失败与驱动修正')==1;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q04','Q06','Q13','Q20']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.43 补执行配置／计划与两端真实初始化、改配置取消窗口的联合证据，完整派发／业务链继续待验 |';t='\n'.join(lines)+'\n'
 old='§4.42 补数据库配置修订与凭据事务；下一步优先收口';new='§4.42 补数据库配置修订与凭据事务；§4.43 补同一运行计划下两端原生初始化与改配置取消；下一步优先收口';assert old in t;return t.replace(old,new)
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：执行配置修订、宿主运行计划与 owned 取消已在同一隔离链连接到 Claude／Codex 真实初始化；更名、换 Key、删配置及错误回调的局部边界已验证，见[技术方案 §3.2.12](技研/技术方案.md)。本批没有发送模型任务；完整程序化准备、业务桥、外部来源与后续回合仍待收口。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources),'ownedExits':len(processes)}))
