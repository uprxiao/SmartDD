import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {setup} from './baseline-inputs/fixture.mjs';
import {prepareExecution,readExecution} from './baseline-inputs/execution.mjs';
import profile from './baseline-inputs/profile.cjs';
const f=await setup();let observed;
try{const h=await prepareExecution(f,f.runtime),orm=profile.drizzle(f.sqlite,{schema:profile.schema}),svc=new profile.AiProfileService(orm,new profile.SecretsStore(orm,{isAvailable:()=>true,encrypt:s=>Buffer.from(s),decrypt:b=>b.toString()}),()=>2),p=svc.get(f.profile);svc.update(f.profile,{name:'cosmetic rename',runner:p.runner,executable:p.executable,env:[],args:p.args,color:p.color,isDefault:p.isDefault});assert.throws(()=>readExecution(f.store,f.run.runId,h.planHash,{live:true}),e=>{observed=e.message;return e.message==='TARGET_CONFIGURATION_CHANGED';});const beforeCleanup={actualProfileUpdatedAt:svc.get(f.profile).updatedAt,fixtureEpoch:f.sqlite.prepare('SELECT epoch FROM m14_fixture_config_epoch').get().epoch,plan:readExecution(f.store,f.run.runId,h.planHash).plan};writeFileSync('baseline.json',JSON.stringify({status:'reproduced',candidateDefect:'old live reader still compares updatedAt after cosmetic rename',error:observed,evidence:beforeCleanup,modelTurns:0},null,2));await f.sqlite.backup('baseline.sqlite');}finally{await f.run.cancelBeforeFork();f.sqlite.close();}
console.log(JSON.stringify({oldCandidateCosmeticRejectionReproduced:true}));
