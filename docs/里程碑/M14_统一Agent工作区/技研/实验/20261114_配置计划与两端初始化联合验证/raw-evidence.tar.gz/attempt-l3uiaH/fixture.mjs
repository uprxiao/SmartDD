import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import actual from './candidate.cjs';
import profileActual from './profile.cjs';
import {migrate as migrateConfiguration} from './revision.mjs';
import {nativeRuntime,cleanProfileEnv} from './native-inputs.mjs';
import {migrate,currentScope} from './migration.mjs';
export async function setup(driver='claude'){
 let f,snapshot,session,authorization,runs;
 const bundle=actual.fixtureBundle();bundle.manifest.tools[0].name='smartdd_zentao_object_get_v1';bundle.manifest.runtime.hash=actual.validateRuntime({id:'applications',protocolMajor:1,bridgeEntry:'mcp-bridge.cjs',files:{'mcp-bridge.cjs':Buffer.from('module.exports = {};\n')}}).hash;
 bundle.files['schemas/input.json']=Buffer.from(JSON.stringify({type:'object',properties:{value:{type:'string'}},required:['value'],additionalProperties:false}));bundle.files['schemas/output.json']=Buffer.from(JSON.stringify({type:'object',properties:Object.fromEntries(['value','packageHash','projectId','taskId','operationId'].map(k=>[k,{type:'string'}])),required:['value','packageHash','projectId','taskId','operationId'],additionalProperties:false}));bundle.manifest.files=Object.entries(bundle.files).map(([path,bytes])=>({path,size:bytes.length,sha256:actual.digest(bytes),executable:false}));
 f=await (driver==='codex'?actual.runCodexFixture:actual.runFixture)(new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),{application:true,applicationBundle:bundle});const db=f.sqlite;
 db.prepare("INSERT INTO application_catalog_state VALUES('zentao',1,1,1,?)").run(new Date().toISOString());
 db.prepare("INSERT INTO application_project_settings(project_id,app_id,enabled,binding_revision,updated_at) VALUES('p1','zentao',0,0,?)").run(new Date().toISOString());
 db.prepare("INSERT INTO application_binding_slot_revisions VALUES('p1','zentao','zentao',0)").run();
 const s=structuredClone(f.snapshot),taskId=randomUUID(),mcp='m14_'+taskId.replaceAll('-',''),oldMcp=s.mcp[0].serverName;s.schema=3;s.taskId=taskId;s.mcp[0].serverName=mcp;
 for(const [key,name]of Object.entries(s.adapterBinding.nativeToolNames))s.adapterBinding.nativeToolNames[key]=name.replace(oldMcp,mcp);
 const caps=actual.builtinApplicationModules.capabilityViews(f.application.manifest);
 for(const p of s.packages){p.entry='mcp';p.capabilityContractMajors=Object.fromEntries(caps.map(c=>[c.id,c.contractMajor]));for(const skill of p.skills)skill.projectionPath=skill.projectionPath.replace(f.snapshot.taskId,taskId);}
 snapshot=actual.capabilitySessionSnapshotV3Schema.parse(s);session=await f.sessions.create(snapshot,f.home);
 authorization=new actual.CurrentApplicationAuthorization(f.store,{packages:f.packageRegistry,retainedMetadata:hash=>f.packageRegistry.get(hash)});
 const createPlan=(recorded,hash,id)=>{const apps=authorization.selectedApps(recorded.projectId),bindings=authorization.bindings(recorded.projectId,apps.map(a=>a.appId)),selected={...recorded,packages:apps.map(a=>authorization.packageSelection(recorded.projectId,a.packageHash,bindings,[])),standardSkills:[]};return actual.createApplicationRunPlan({runId:id,snapshotHash:hash,snapshot:selected,applications:apps.map(a=>{const pack=f.packageRegistry.get(a.packageHash);return{packageHash:a.packageHash,manifest:pack.manifest,capabilities:actual.builtinApplicationModules.capabilityViews(pack.manifest)};}),skills:[],available:{mcp:true,cli:false}});};
 runs=new actual.CapabilityRunRegistry(f.store,f.sessions,{processes:f.reader,assertCurrent:()=>{},revoke:()=>{},createPlan,currentAuthorization:c=>authorization.view(c)});

 let clock=1;const runtime=nativeRuntime(driver);
 const profileService=new profileActual.AiProfileService(profileActual.drizzle(db,{schema:profileActual.schema}),new profileActual.SecretsStore(profileActual.drizzle(db,{schema:profileActual.schema}),{isAvailable:()=>true,encrypt:s=>Buffer.from(s),decrypt:b=>b.toString()}),()=>clock);
 const profile=profileService.create({name:'isolated fixture',runner:driver,executable:runtime.path,env:cleanProfileEnv(driver),args:[],color:null,isDefault:false}).id;
 for(const s of [f.snapshot,snapshot])db.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(s.taskId,s.projectId,s.native.cwd,profile,s.runner,'isolated',1,1);
 await migrate(db);const scope=currentScope(db,snapshot.taskId);
 db.prepare('UPDATE m14_binding SET profile_id=?,profile_revision=1 WHERE binding_id=?').run(profile,scope.bindingId);
 db.exec(readFileSync(new URL('./delivery.sql',import.meta.url),'utf8'));
 db.exec(readFileSync(new URL('./execution.sql',import.meta.url),'utf8'));
 migrateConfiguration(db);
 const run=await runs.reserve({taskId:snapshot.taskId,snapshotHash:session.pointer.snapshotHash,bindings:[]});
 db.prepare('UPDATE capability_runs SET binding_id=?,capability_session_id=?,generation=1,source_snapshot_hash=snapshot_hash WHERE run_id=?').run(scope.bindingId,scope.capabilitySessionId,run.runId);
 await run.prepare();
 return {...f,snapshot,session,runs,run,scope,profile,runtime,authorization,profileService,setClock:v=>{clock=v;}};
}
