from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_保留历史身份占用与异常迁移验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'boundary':r['scope'],'schema0Boundary':'Read-only recognition of existing holdUnknown canonical payload cross-checked with current identity; not a capability-session parser or grant. Duplicate schema0 can have no own identity, which this candidate refuses to migrate.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['probe.mjs','retained.mjs','claims.mjs','migration.mjs','candidate.sql','build.mjs','build.json','actual.cjs','source-review.json','prepare.py']]
attempts=sorted(root.glob('attempt-*'))
for a in attempts:files += [p for p in a.iterdir() if p.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'attempts':[json.loads((a/'result.json').read_text()) for a in attempts],'driverCorrection':'First run expected SESSION_ON_HOLD at reserve; current reserveManaged explicitly emits RESOURCE_STATE_CHANGED for non-active retention. Assertion corrected to actual stable code and strengthened to assert no run inserted; original failure preserved.'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 保留历史身份占用与异常迁移验证

日期：2026-11-14。关联 D01、Q13／Q49。实际 holdUnknown、会话注册器、原生守护注册器及当前 SQLite；新关系表和只保留身份的 owner 记录为临时候选。

## 六项检查

| 检查 | 实际结果 |
| --- | --- |
| K01 前批投影反例 | 有效 v3 历史复制后进入 hold；旧迁移跳过该任务，旧投影没有历史根占用，另一 binding 可认领原根 |
| K02 保留身份 | 修正候选为已知 hold 和合法 schema0 建立只保留身份的 owner／来源，两个任务保留三个根；不创建 capability session，原快照字节与状态不变；当前根／旧根／别名不能重占 |
| K03 既有守护边界 | 实际普通 reserve 拒绝 hold 且未插入 run；实际 schema0 reserveNativeGuard 可准备并取消至 stopped，但 assertActive 和 reserveBridge 均拒绝，不取得业务上下文 |
| K04 未知未来格式 | 合成 schema99 保留记录让整次候选迁移回滚，字节与旧表保持，没有迁移回执 |
| K05 损坏历史来源 | hold 任务的旧根版本损坏时拒绝迁移，损坏记录原样保留，不把该根视为空闲 |
| K06 不明确身份 | 实际 holdUnknown 对已有身份重复登记另一 task 时可不生成独立 identity 行；候选拒绝猜归属，整体回滚并保留原身份与两条历史 |

最终六项通过，各场景终态 SQLite 完整性及外键检查通过。K01 是旧研究候选的缺口，不是产品修复。K03 使用合成资源核验回调，没有真正启动原生 Agent，不证明 CLI 恢复已接完整迁移。

首轮 K03 驱动预期 SESSION_ON_HOLD，但当前 reserveManaged 对非 active 返回 RESOURCE_STATE_CHANGED。读取当前源码确认后修正错误码断言，并增加没有插入 run 的核验；原失败及现场保留，没有改变产品或放宽实际拒绝要求。

## 设计边界

身份占用和能力授权分开。已知 hold 的旧快照与历史仍是占用来源；schema0 只读取既有 holdUnknown 的严格身份形状及摘要，并与独立身份表核对，不升级成业务能力快照。保留 owner 没有 capability session／可执行 revision，不能因出现 binding 行就显示可执行或签发业务权限。

未知格式、损坏来源、别名身份变化或缺失／重复归属，当前候选选择整次拒绝迁移并保留原库；不擅自删除记录、借当前配置补齐或解除占用。用户修复流程、局部迁移策略、全部旧写入口及正式恢复／GC 尚未完成。本轮不承诺自动修复或所有异常历史都能进入新工作区。

## 复现

固定依赖具备时执行 `node build.mjs`、`node probe.mjs`。每个场景独立 runFixture／数据库；候选在迁移事务的 before-drop 钩子内保留 owner 并构建 claim，失败由原事务整体回滚。驱动、两次 attempt、全部数据库与 379 条构建来源摘要均归档。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
tech_rel=base/'技研/技术方案.md';t=(repo/tech_rel).read_text()
old='| 未解析历史 | hold、未知版本、无法对应的 run 保留原记录和明确原因；合法但不同 selection 不套用当前能力。可以先保持 legacy 只读，后续恢复执行必须单独补齐原选择／资源／投影，不在迁移中猜映射 |'
new='| 未解析历史 | hold、未知版本、无法对应的 run 保留原记录和原因，身份占用不能随执行禁用而释放；不同 selection 不套用当前能力。已知 schema0 原生守护与业务授权分别保持；未证明的格式／归属拒绝迁移或执行，不猜映射 |'
assert old in t;t=t.replace(old,new,1)
anchor='迁移先进入已有启动排他／维护协议，核真实 owner 与进程范围；'
add='''[保留历史实验](实验/20261114_保留历史身份占用与异常迁移验证/README.md)复现前批投影遗漏 hold 历史根。现行合同要求保留身份 owner 与可执行 capability session 分离：已知 v2／v3 hold 及当前 holdUnknown 生成的 schema0，验证摘要、形状和独立 identity 后保留当前／历史根及来源，不自动创建可执行能力修订；原记录和 hold 状态不变。若保留 owner 采用 binding 行承载，须以保留来源关联和缺失可执行 capability 明确区分，不能将行存在或 historical phase 视为 prepared。未知新格式、损坏来源、缺失或重复身份及别名变化无法核验时，当前候选整次迁移回滚，原数据保留，不能按空闲放行。正式应用需显示准确失败来源及可继续使用的旧入口范围；自动修复或局部迁移不是本实验已证明能力。

不能将 hold 一律解释为完全禁止原生运行：当前 schema0 history-unknown 有 reserveNativeGuard，允许受管的原生生命周期，但不提供应用业务权限。实验中其准备／取消仍有效，assertActive 与 reserveBridge 均拒绝；普通业务 reserve 对 hold 返回 RESOURCE_STATE_CHANGED，未建立 run。M14 保留这一已有分层，真实 TaskService／CLI 恢复仍需验证，不以业务能力禁用顺带删除原生历史入口。

'''
assert anchor in t;t=t.replace(anchor,add+anchor,1)
t=t.replace('未知／hold／损坏历史、全部写入口与正式 GC／跨进程恢复仍待联合。','保留历史／异常格式的候选分支见下段；全部写入口、正式恢复／GC 与实际 App 迁移仍待联合。',1)
put(tech_rel,t)
ledger_rel=base/'技研/全局设计验证账.md';t=(repo/ledger_rel).read_text();assert '### 4.93 ' not in t
add='''### 4.93 保留历史占用与异常迁移边界

[六项检查](实验/20261114_保留历史身份占用与异常迁移验证/README.md)先复现前批投影跳过 hold、遗漏旧根占用；候选为有效 hold／schema0 保留 owner 与来源，不创建能力会话，当前根／历史根／别名继续冲突。未知未来格式、损坏旧来源、实际 holdUnknown 产生的无独立 identity 重复记录均拒绝整次迁移并保留原库。

实际业务 reserve 拒绝 hold 且无 run 插入；现有 schema0 原生守护可准备／取消，但业务上下文与桥拒绝。初轮驱动误判错误码，核对当前 reserveManaged 后修正并保留失败；最终六项通过。无真实原生进程或产品接线，用户修复／局部迁移、全部写入口与正式资源恢复仍待验证。技术方案 §3.2.2 已明确保留 owner、原生守护和业务能力的区别；Q13／49 继续部分。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1).replace('截至 §4.92，56 个宽口径问题项中','截至 §4.93，56 个宽口径问题项中')
old='剩余为未知／hold 来源、全部写入口／正式资源与恢复联合、复制中途、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
new='§4.93 已补已知 hold／schema0 的保留 owner、现有原生守护边界及未知／损坏／归属不明时整次迁移回滚；剩余为全部写入口／正式资源与恢复联合、异常历史的产品处理、复制中途、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
assert old in t;t=t.replace(old,new,1);put(ledger_rel,t)
index_rel=base/'README.md';t=(repo/index_rel).read_text()
t=re.sub(r'^最新进展：.*$', '最新进展：保留历史的身份占用、schema0 原生守护边界及异常来源拒绝迁移已取得隔离证据，方案已同步。见[保留历史与异常迁移实验](技研/实验/20261114_保留历史身份占用与异常迁移验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)核对全部写入口与正式恢复／资源的共同约束，继续收口委派问题账、完整运行／业务与历史续写；异常历史的实际 App 提示和修复仍留作后续接线验证。',t,flags=re.M);put(index_rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-native-claims-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed']}))
