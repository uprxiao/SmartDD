import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync,copyFileSync,mkdirSync,symlinkSync} from 'node:fs';
import {join,dirname} from 'node:path';
import actual from './actual.cjs';
import {migrate} from './migration.mjs';
import {installClaims,claimNew} from './claims.mjs';
import {installRetainedClaims} from './retained.mjs';

const root=import.meta.dirname,out=mkdtempSync(join(root,'attempt-')),save=(n,v)=>writeFileSync(join(out,n),JSON.stringify(v,null,2));
for(const n of ['probe.mjs','retained.mjs','claims.mjs','migration.mjs','candidate.sql','build.mjs','build.json'])copyFileSync(join(root,n),join(out,n));
const checks=[];let problem;
function snapshot(db){return Object.fromEntries(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(({name})=>[name,db.prepare('SELECT * FROM '+name+' ORDER BY 1').all()]));}
async function fixture(){
 const f=await actual.runFixture(),db=f.sqlite;
 let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});const id=randomUUID();current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:id});
 const from=current.snapshot.native.stateRoot,to=join(f.root,'copied'),cwd=current.snapshot.native.cwd,source=join(from,'projects',actual.encodeClaudeDir(cwd),id+'.jsonl');mkdirSync(dirname(source),{recursive:true});mkdirSync(to);writeFileSync(source,'SYNTHETIC_HELD_HISTORY\n');
 const receipt=actual.copyClaudeSession({from,to,cwd,sessionId:id,nativeTarget:false});current=await f.sessions.adoptLibrary(current.snapshot.taskId,current.pointer.snapshotHash,{...current.snapshot,native:{...current.snapshot.native,stateRoot:to}},{copy:receipt,home:f.home,commit:()=>{assert(db.inTransaction);}});
 await f.sessions.holdUnknown({taskId:current.snapshot.taskId,projectId:'p1',runner:current.snapshot.runner,stateRoot:to,cwd,sessionId:id,reason:'snapshot-corrupt'});
 const unknown={taskId:randomUUID(),projectId:'p1',runner:current.snapshot.runner,stateRoot:join(f.root,'unknown'),cwd,sessionId:randomUUID(),reason:'history-unknown'};mkdirSync(unknown.stateRoot);await f.sessions.holdUnknown(unknown);
 return{...f,current,id,from,to,cwd,unknown};
}
async function run(id,title,fn){const f=await fixture();try{const evidence=await fn(f);checks.push({id,title,status:'passed',evidence});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save(id+'-state.json',snapshot(f.sqlite));assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(join(out,id+'.sqlite'));save(id+'-fixture.json',{root:f.root});f.sqlite.close();}}
const migrateFixed=db=>migrate(db,async point=>{if(point==='before-drop')installRetainedClaims(db);});
try{
 await run('K01','prior projection skips held historical root',async f=>{
  await migrate(f.sqlite,async point=>{if(point==='before-drop')installClaims(f.sqlite);});assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_native_claim').get().n,0);
  const binding=claimNew(f.sqlite,{taskId:randomUUID(),runner:f.current.snapshot.runner,identityRoot:f.from,nativeId:f.id,cwd:f.cwd});assert(binding);return{negative:true,heldOldRootReclaimedByOldCandidate:true,productNotAffected:true};
 });
 await run('K02','known hold and schema0 retain identity without capability session',async f=>{
  const before=f.sqlite.prepare('SELECT * FROM capability_session_snapshots ORDER BY task_id').all();await migrateFixed(f.sqlite);assert.deepEqual(f.sqlite.prepare('SELECT * FROM capability_session_snapshots ORDER BY task_id').all(),before);
  assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_cap').get().n,0);assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_binding').get().n,2);assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_native_claim').get().n,3);assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_retained_identity_source').get().n,2);
  const alias=join(f.root,'alias');symlinkSync(f.from,alias);for(const identityRoot of [f.from,f.to,alias])assert.throws(()=>claimNew(f.sqlite,{taskId:randomUUID(),runner:f.current.snapshot.runner,identityRoot,nativeId:f.id,cwd:f.cwd}),/CONFLICT|already owned/);
  assert.throws(()=>claimNew(f.sqlite,{taskId:randomUUID(),runner:f.unknown.runner,identityRoot:f.unknown.stateRoot,nativeId:f.unknown.sessionId,cwd:f.cwd}),/CONFLICT|already owned/);return{retainedOwners:2,claims:3,capabilitySessions:0,oldRowsUnchanged:true};
 });
 await run('K03','hold denies business run while existing schema0 native guard lifecycle remains separate',async f=>{
  await migrateFixed(f.sqlite);await assert.rejects(f.runs.reserve({taskId:f.current.snapshot.taskId,snapshotHash:f.current.pointer.snapshotHash,bindings:[]}),{code:'SESSION_ON_HOLD'});
  const row=f.sqlite.prepare('SELECT * FROM capability_session_snapshots WHERE task_id=?').get(f.unknown.taskId);const guard=await f.runs.reserveNativeGuard({taskId:f.unknown.taskId,projectId:'p1',runner:f.unknown.runner,snapshotHash:row.snapshot_hash,resourceIds:[f.adapter.resourceId],verify:()=>{}});
  try{await guard.prepare();assert.throws(()=>f.runs.assertActive(guard.runId),{code:'SCOPE_DENIED'});await assert.rejects(guard.reserveBridge(),{code:'SCOPE_DENIED'});}finally{await guard.cancelBeforeFork();}
  assert.equal(f.runs.get(guard.runId).state,'stopped');return{businessRunRejected:true,nativeOnlyGuardPreparedAndStopped:true,businessContextAndBridgeRejected:true,syntheticResourceVerifier:true,noNativeProcessLaunched:true};
 });
 await run('K04','unknown future retention format rolls back migration preserving bytes',async f=>{
  const row=f.sqlite.prepare('SELECT * FROM capability_session_snapshots WHERE task_id=?').get(f.unknown.taskId),v=JSON.parse(row.snapshot_json);v.schema=99;const bytes=actual.canonicalJson(v);f.sqlite.prepare('UPDATE capability_session_snapshots SET schema_version=99,snapshot_json=?,snapshot_hash=? WHERE task_id=?').run(bytes,actual.digest(bytes),f.unknown.taskId);const before=snapshot(f.sqlite);
  await assert.rejects(migrateFixed(f.sqlite),/UNSUPPORTED_RETAINED_SCHEMA/);assert.deepEqual(snapshot(f.sqlite),before);return{unsupportedPreserved:true,noMigrationReceipt:true};
 });
 await run('K05','corrupt held historical source does not silently free its identity',async f=>{
  const row=f.sqlite.prepare("SELECT * FROM capability_snapshot_versions WHERE task_id=? AND json_extract(snapshot_json,'$.native.sessionId')=? AND json_extract(snapshot_json,'$.native.stateRoot')=?").get(f.current.snapshot.taskId,f.id,f.from);assert(row);f.sqlite.prepare('UPDATE capability_snapshot_versions SET snapshot_json=? WHERE snapshot_hash=?').run('{"corrupt":true}',row.snapshot_hash);const before=snapshot(f.sqlite);
  await assert.rejects(migrateFixed(f.sqlite));assert.deepEqual(snapshot(f.sqlite),before);return{corruptBytesPreserved:true,migrationRejectedWithoutClaims:true};
 });
 await run('K06','ambiguous schema0 duplicate with no own identity refuses migration',async f=>{
  const duplicate={...f.unknown,taskId:randomUUID()};await f.sessions.holdUnknown(duplicate);assert(!f.sqlite.prepare('SELECT 1 FROM capability_session_identities WHERE task_id=?').get(duplicate.taskId));const before=snapshot(f.sqlite);
  await assert.rejects(migrateFixed(f.sqlite),/RETAINED_IDENTITY_UNRESOLVED/);assert.deepEqual(snapshot(f.sqlite),before);return{actualDuplicateHoldProduced:true,originalIdentityKept:true,ambiguousRecordPreserved:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,scope:'Actual holdUnknown/session registry/native-only guard over isolated current databases, candidate retention-owner claim projection. Known v2/v3 hold and verified schema0 shape only; unknown/corrupt/ambiguous records reject migration preserving source. No product modification, actual native launch, TaskService integration, recovery/GC wiring or repair UI.'};save('result.json',result);writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
