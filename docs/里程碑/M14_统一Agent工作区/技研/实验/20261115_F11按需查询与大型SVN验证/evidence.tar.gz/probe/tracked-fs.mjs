import * as fs from 'node:fs';
export const calls=[];
export const realpathSync=(...args)=>{calls.push({operation:'realpath',path:args[0]});return fs.realpathSync(...args)};
export const statSync=(...args)=>{calls.push({operation:'stat',path:args[0]});return fs.statSync(...args)};
export const existsSync=(...args)=>{calls.push({operation:'exists',path:args[0]});return fs.existsSync(...args)};
