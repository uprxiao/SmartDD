from pathlib import Path
import hashlib,json
r=Path('/private/tmp/willyou-m14-f11-readset');repo=Path('/Users/hx/projects/SmartDD');p=repo/'native/files/broker.mm';original=p.read_text();s=original
extra=r'''
static NSMutableDictionary *f11Reads, *f11Dirs;
static unsigned long long f11MaxRead=0;
static bool f11Saved=false;
static NSString *f11Path(int fd) { char path[4096]={0}; return fcntl(fd,F_GETPATH,path)==0 ? [NSString stringWithUTF8String:path] : @"<unknown>"; }
static ssize_t f11Pread(int fd,void *buffer,size_t size,off_t offset) { ssize_t n=pread(fd,buffer,size,offset); if(n>0){ if(!f11Reads)f11Reads=[NSMutableDictionary dictionary]; NSString *p=f11Path(fd); f11Reads[p]=@([f11Reads[p] unsignedLongLongValue]+n); f11MaxRead=std::max(f11MaxRead,(unsigned long long)n); } return n; }
static dirent *f11Readdir(DIR *dir) { dirent *e=readdir(dir); if(e){ if(!f11Dirs)f11Dirs=[NSMutableDictionary dictionary]; NSString *p=f11Path(dirfd(dir)); f11Dirs[p]=@([f11Dirs[p] unsignedLongLongValue]+1); } return e; }
static void f11Record(NSDictionary *frame) { if(f11Saved||(!frame[@"result"]&&!frame[@"error"]))return;f11Saved=true; NSDictionary *value=@{@"pid":@(getpid()),@"preadBytes":f11Reads?:@{},@"directoryEntries":f11Dirs?:@{},@"maxPread":@(f11MaxRead)}; NSData *data=[NSJSONSerialization dataWithJSONObject:value options:0 error:nil]; NSString *path=[NSString stringWithFormat:@"/private/tmp/willyou-m14-f11-readset/native-metrics/%d.json",getpid()]; [data writeToFile:path options:NSDataWritingWithoutOverwriting error:nil]; }
static NSDictionary *f11Stamp(const struct stat &s) { return @{@"device":@(s.st_dev),@"inode":@(s.st_ino),@"modifiedNs":[NSString stringWithFormat:@"%lld",s.st_mtimespec.tv_sec*1000000000ll+s.st_mtimespec.tv_nsec],@"changedNs":[NSString stringWithFormat:@"%lld",s.st_ctimespec.tv_sec*1000000000ll+s.st_ctimespec.tv_nsec]}; }
'''
s=s.replace('struct Failure {',extra+'\nstruct Failure {',1)
# Only instrument the original file's actual content reads and directory enumeration.
s=s.replace('ssize_t n = pread(', 'ssize_t n = f11Pread(').replace('dirent *entry = readdir(dir);','dirent *entry = f11Readdir(dir);')
s=s.replace('static void emit(NSDictionary *message) {','static void emit(NSDictionary *message) {\n  f11Record(message);',1)
s=s.replace('bool listing = operation == "list";', 'bool researchQuery=operation=="query-list"; bool listing = operation == "list" || researchQuery;')
s=s.replace('NSMutableArray *entries = [NSMutableArray array];\n    try {','NSMutableArray *entries = [NSMutableArray array];\n    struct stat queryBefore=info(item.fd.value);NSUInteger querySkipped=0;bool queryLimited=false;NSUInteger queryLimit=researchQuery?[request[@"entryLimit"] unsignedIntegerValue]:100000;require(queryLimit>0&&queryLimit<=100000,"INVALID_INPUT","Invalid query limit");\n    try {',1)
s=s.replace('if (fstatat(item.fd.value, name.c_str(), &linkInfo, AT_SYMLINK_NOFOLLOW) < 0) continue;', 'if (fstatat(item.fd.value, name.c_str(), &linkInfo, AT_SYMLINK_NOFOLLOW) < 0) {querySkipped++;continue;}',1)
s=s.replace('if (!entryName) continue; //', 'if (!entryName) {querySkipped++;continue;} //',1)
s=s.replace('value[@"kind"] = @"unavailable"; value[@"reason"] = ns(e.message);','value[@"kind"] = @"unavailable"; value[@"reason"] = ns(e.message);querySkipped++;',1)
s=s.replace('[entries addObject:value];\n        require(entries.count', '[entries addObject:value];\n        if(researchQuery&&entries.count>=queryLimit){queryLimited=true;break;}\n        require(entries.count',1)
a='return @{ @"entries": entries, @"identity": identity(info(item.fd.value)), @"relativePath": ns(item.relative) };';assert a in s
s=s.replace(a,'if(researchQuery)return @{@"entries":entries,@"identity":identity(info(item.fd.value)),@"relativePath":ns(item.relative),@"queryEvidence":@{@"before":f11Stamp(queryBefore),@"after":f11Stamp(info(item.fd.value)),@"skipped":@(querySkipped),@"limited":@(queryLimited)}};\n    '+a,1)
s=s.replace('require(operation == "list" ||', 'require(operation == "query-list" || operation == "list" ||',1)
assert 'f11Record(message);' in s
(r/'broker.mm').write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[{'path':str(x),'sha256':sha(x)} for x in [p,*sorted((repo/'native/files').glob('*.inc.mm'))]]
(r/'native-build.json').write_text(json.dumps({'sources':sources,'originalSha256':sha(p),'variantSha256':sha(r/'broker.mm'),'changes':'Metrics for original pread/readdir plus query-list coverage/stamps/entry budget. Original list/read/search semantics unchanged. No test failpoints or repository edit.','command':'xcrun clang++ -std=c++17 -fobjc-arc -O1 -Wno-deprecated-declarations -framework Foundation -framework AppKit -framework ImageIO -framework CoreGraphics -framework CoreText -I /Users/hx/projects/SmartDD/native/files broker.mm -o file-broker'},indent=2))
