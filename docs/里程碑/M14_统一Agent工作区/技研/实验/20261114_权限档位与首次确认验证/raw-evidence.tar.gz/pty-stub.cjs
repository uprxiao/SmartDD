exports.spawn = () => { throw new Error('PTY spawn is forbidden in this isolated permission preparation probe'); };
