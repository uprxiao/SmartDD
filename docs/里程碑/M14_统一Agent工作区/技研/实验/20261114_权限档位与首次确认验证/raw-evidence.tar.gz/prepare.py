from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_权限档位与首次确认验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
results=[json.loads(p.read_text())for p in sorted(root.glob('latest-*.json'))];assert len(results)==7 and all(r['passed']for r in results)
for r in results:
 assert r['modelRequests']==2 and all(p['exit']['code']==0 for p in r['processes']);assert r['toolResult']
 prompts=r['mode']=='ask'and not r.get('inside',False);assert len(r['approvals'])==(1 if prompts else 0)
 if prompts and r['decision']=='deny':
  assert not r['fileExists'];assert ('Synthetic host denial'if r['driver']=='claude'else'rejected by user')in json.dumps(r['toolResult'])
 else:assert r['fileContent']=='PERMISSION_MARKER'
host=json.loads((root/'host-result.json').read_text());assert host['passed'] and host['drivers']==2;assert "login:'subscription'"in(root/'host-guard.mjs').read_text()
build=json.loads((root/'build.json').read_text())
for f in build['sources']+build['outputs']:assert sha(Path(f['path']).read_bytes())==f['sha256'],f['path']
refs=[repo/p for p in ['src/shared/agent-permissions.ts','src/shared/ai-agents.ts','src/main/core/ai/agent-runtime.ts','src/main/core/ai/agent-launch-plan.ts','src/main/core/ai/legacy-permission-overlay.ts','src/main/core/applications/codex-client-args.ts']]+[t3/'apps/server/src/orchestration-v2/Adapters'/n for n in ['ClaudeAdapterV2.ts','CodexAdapterV2.ts']]+[Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'build':build,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'versions':{'ClaudeSDK':'0.3.321','ClaudeNative':'2.1.321','CodexNative':'0.167.1'},'limitations':'Current permission helper and runtime coordinator executed. Other services/tool/login registries are synthetic; node-pty replaced by throwing guard. Native launch is separate isolated SDK/app-server, not current product launch path or full business bridge.'}
result={'nativeCasesPassed':7,'hostPreparationDriversPassed':2,'nativeResults':results,'hostPreparation':host,'modelRequests':14,'paidModelCalls':0,'productChanges':0,'scope':'Ask allow/deny, full no ordinary native approval, Codex ask workspace write, current new-run full confirmation guard and Claude auto fallback. Not auto classifier, managed policy, restored history, real renderer human decision, or business full-mode joint proof.'}
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[root/n for n in ['build.mjs','build.json','actual.cjs','pty-stub.cjs','probe.mjs','batch.mjs','batch-result.json','host-guard.mjs','host-result.json','model.mjs','native-inputs.mjs','prepare.py','result.json','source-review.json']]
for p in sorted(root.glob('attempt-*')):
 files+=sorted(f for f in p.iterdir()if f.is_file())
 if(p/'workspace/inside-workspace.txt').exists():files.append(p/'workspace/inside-workspace.txt')
for name in ['bootstrap-failure','host-fixture-correction']:files+=sorted(f for f in (root/name).iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files]}
for n,d in [('result.json',result),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 权限档位与首次确认：独立技术验证

依据需求 R0.2 R02／R08／R11 与 Q12。七个原生场景通过，另在两种 runner 夹具上执行实际 AgentRuntimeService 的新运行准备。Claude SDK 0.3.321／native 2.1.321，Codex app-server 0.167.1；所有模型请求仅本机模拟服务，十四次，零付费请求。原生进程七个，均 exit 0。

| 场景 | 实际证据 |
| --- | --- |
| Claude ask allow／deny | 实际 Write 写私有 cwd 外合成文件；default 经 canUseTool 一次批准后写入，拒绝则原生 tool_result is_error 且文件不存在 |
| Claude full | bypassPermissions＋allowDangerouslySkipPermissions；即使安装“拒绝”回调，本次 Write 也不会调用它，文件写入；SDK 给出 CAN_USE_TOOL_SHADOWED 警告 |
| Codex ask allow／deny | workspace-write＋on-request＋user；exec_command 显式请求 require_escalated，精确命令与目标进入原生 requestApproval；accept 写入，decline 返回拒绝且文件不存在 |
| Codex full | danger-full-access＋never；本次普通命令写入不产生审批请求，文件内容正确 |
| Codex ask 目录内写 | 普通 use_default 命令写 cwd 内文件，未请求提权；没有审批回调，写入成功。ask 不是每次询问，也不是只读 |
| 当前宿主准备，两端 | AgentRuntimeService.prepare 在 fullConfirmed=false 且新任务选择 full 时拒绝，尚未读取 profile／生成运行材料；true 后准备成功。auto 在 Claude 有效值为 ask，在 Codex 为 auto；记忆偏好未被改写，显式 ask 可覆盖本次选择 |

宿主部分使用合成 login source／工具注册信息和内存偏好；providers／db 是禁止访问的 guard。没有读真实凭据、验证原生登录或运行 TaskService／renderer。真实权限模块和运行准备模块没有替换；其静态依赖 node-pty 被替换为抛错 guard，保证本探针不会另起 PTY。原生 SDK 进程由独立驱动启动，不能声称旧准备服务已接通新 SDK。

首次 bundle 保留 node-pty 时导入失败，未创建实验夹具／启动 native；失败原 bundle、源码摘要及复现 stderr 已归档。改为禁止 PTY 的显式 guard 后执行。首个宿主夹具误写 login='oauth'，复核实际枚举后改为合法 subscription 并重跑；旧脚本／结果保留，不把旧夹具计作通过。subscription 仍是合成状态，不是实际账号登录证据。

现行产品档位来自 src/shared/agent-permissions.ts：ask／auto／full。Claude auto 回落 ask 是现有策略，SDK 支持 auto 不等于迁移时可自动改变产品行为。Codex auto 展开为 approvals_reviewer=auto_review、approval_policy=on-request、sandbox_mode=workspace-write，本轮只验证这份实际映射／准备，未执行自动审批分类器。

权限决定、原生工具结果和模型回合结果分别记录；拒绝工具后模型回合仍可能正常结束。full 也不意味着绕过显式 deny、受管策略、表单规则或 WillYou 业务审批。本轮没有业务 MCP／插件／邮件，不能从普通 Write／exec 的免审批结果推断它们已获许可。

复跑：node build.mjs；node host-guard.mjs；在具有 localhost 监听权限的环境 node batch.mjs；再 node probe.mjs codex ask deny inside；python3 prepare.py。依赖原固定隔离 SDK／native，摘要见 native-inputs 与 source-review。恢复历史权限、旧高级配置、受管规则、full 真界面回执、auto 分类器和完整业务接线继续待验，Q12 推进为部分。

[结果](result.json) · [源码](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
section='''#### 4.4.3 保留现有权限档位与首次 full 确认

WillYou 当前权威档位为 `src/shared/agent-permissions.ts` 的 ask／auto／full，不能直接改称 T3 的 approval-required／auto-accept-edits／auto／full-access；同名“需要批准”也不保证沙箱范围相同。迁移保存 requestedPermission 与 effectivePermission／降级原因，保留记忆选择和实际应用档位的区别。

| WillYou 选择 | Claude 当前语义／SDK 对应 | Codex 当前语义／app-server 对应 |
| --- | --- | --- |
| ask | default，提供原生许可回调 | workspace-write＋on-request＋user；工作目录内允许的操作不必询问 |
| auto | 当前不开放，按现有 agentPermission 回落 ask；保留记忆 auto，不自动启用 SDK auto | workspace-write＋on-request＋auto_review；来源为现有 --approve-for-me 的展开，分类器运行仍须验证 |
| full | bypassPermissions；SDK 明确 allowDangerouslySkipPermissions | danger-full-access＋never；按受管配置／实际能力核对，不笼统承诺绕过所有政策 |

[权限实跑](实验/20261114_权限档位与首次确认验证/README.md)覆盖两端 ask 的单次批准／拒绝、full 的普通文件写免审批，以及 Codex ask 的目录内普通写。Claude full 下本次 canUseTool 未调用，SDK 还发出 shadowed 警告；不能把它当宿主业务权限总闸。插件、邮件、浏览器等仍由各自实际业务服务审批与授权，full 不给父子任务自动增加业务许可。工具被拒绝后 turn 仍可能 completed，UI 需保留工具拒绝事实。

首次 full 的确认是 WillYou 当前 AgentRuntimeService.prepare 的主进程前置条件，独立于 native onboarding／trust 或 SDK 的危险模式开关。新程序化启动路径必须复用等效检查并保存已确认选择，不能因 SDK 不显示 CLI 提示就跳过；已有历史权限和恢复规则按实际快照处理，不拿当前全局偏好覆盖。原准备服务的两端新任务检查已用合成配置实跑：未确认时拒绝，确认后准备，Claude auto 回落和显式 ask 均保留。真实 renderer 回执、历史恢复／旧高级配置及新 TaskService 接线尚未证明。

T3 当前 approval-required 的 Codex 默认是 readOnly＋untrusted，WillYou 当前 ask 则是 workspaceWrite＋on-request，二者不能等价迁移。T3 Claude 的 acceptEdits／auto 和能力降级机制可参考，但新增产品档位属于独立决策。运行政策需要同时记录文件范围、审批时机、审批主体、交互模式和受管限制，并验证实际生效值；不能只存一个 boolean。原生版本、企业策略或不支持能力导致目标组合不可实现时应明确报告，不能悄悄放宽。

本轮只运行固定版本与隔离文件、合成批准／拒绝。Codex auto 分类器、受管策略限制、Claude 完整设置来源、历史／父子权限继承与所有业务联合继续待验；普通 native 写入实验不提升为 OS 只读沙箱或跨版本保证。

'''
edit(base/'技研/技术方案.md',lambda t:t.replace('### 4.5 长输出、背压与存储失败',section+'### 4.5 长输出、背压与存储失败'))
def ledger(t):
 assert '### 4.80 'not in t
 t=re.sub(r'^\| Q12 \|.*$', '| Q12 | ask／auto／full 等权限与既有首次确认保持等效 | E01／08；G08、T10 | **部分**：§4.80 两端 ask 批准／拒绝、full 普通写免原生审批及 Codex ask 目录内写通过；实际运行准备验证新任务 full 确认与 Claude auto 回落。真实 UI／历史恢复、auto 分类器、受管规则与业务联合仍待验；§4.60–4.61 的回应投递证据继续保留 |',t,flags=re.M)
 t=t.replace('## 5. 失败与驱动修正','''### 4.80 权限档位与首次确认

[七个原生场景与两端实际准备服务检查](实验/20261114_权限档位与首次确认验证/README.md)通过。ask 批准写入、拒绝不写；full 普通 Write／exec 不进入原生审批；Codex ask 允许 cwd 内普通写。实际 AgentRuntimeService 新任务 full 未确认时拒绝，确认后准备；Claude auto 回落 ask 保留记忆偏好。SDK canUseTool 在本次 full Write 下被绕过，不能充当业务总闸。

原生七进程 exit 0，十四次本机受控模型请求，无外部业务。宿主登录／偏好为合成合法夹具，PTY 为禁止启动 guard；初次 node-pty bundle 导入失败和修正前非法 oauth 枚举夹具均保留，合法 subscription 重跑才计证据。不是实际登录、renderer、历史恢复或当前 TaskService→SDK 联合。Q12 待验推进为部分，技术方案 §4.4.3 明确保留 ask／auto／full 语义、首次确认及 T3 默认差异；auto 分类器、受管设置与完整业务继续待验。

## 5. 失败与驱动修正''')
 t=t.replace('截至 §4.79，56 个宽口径问题项中，46 项有部分实验／限定证据，7 项主要内容仍待验证或产品集成','截至 §4.80，56 个宽口径问题项中，47 项有部分实验／限定证据，6 项主要内容仍待验证或产品集成').replace('七项为 Q12、Q26、Q33、Q42、Q51、Q52、Q56','六项为 Q26、Q33、Q42、Q51、Q52、Q56').replace('不是只剩七项','不是只剩六项').replace('用 46／56 作为研究完成率','用 47／56 作为研究完成率')
 groups=collections.Counter()
 for l in t.splitlines():
  if re.match(r'^\| Q\d\d \|',l):
   a=l.split('|');q=a[1].strip();s=a[4].strip();groups['deferred'if q in ['Q21','Q22']else'optional'if q=='Q36'else'partial'if s.startswith(('**部分','**实证限定','**发现问题并验证候选修正'))else'pending']+=1
 assert groups=={'partial':47,'pending':6,'deferred':2,'optional':1}
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：两端 ask／full 原生权限与现有首次 full 准备检查取得实证，Q12 推进为部分；确认 WillYou ask／auto／full 与 T3 默认不能直接等价映射，见[技术方案 §4.4.3](技研/技术方案.md)。全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)中的自动审批／受管政策、动态子树与业务排空；新任务准备与独立原生实验分别计证据，不合并为已完成产品接线。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'nativeCases':7,'hostDrivers':2,'archiveFiles':len(files),'buildSources':len(build['sources'])}))
