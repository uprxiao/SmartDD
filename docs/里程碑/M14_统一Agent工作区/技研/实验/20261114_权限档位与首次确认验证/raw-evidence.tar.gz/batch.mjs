import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const results=[];
for(const driver of ['claude','codex'])for(const [mode,decision] of [['ask','allow'],['ask','deny'],['full','deny']]){
 const r=spawnSync(process.execPath,[import.meta.dirname+'/probe.mjs',driver,mode,decision],{encoding:'utf8',maxBuffer:2*1024*1024});
 results.push({driver,mode,decision,exit:r.status,stdout:r.stdout,stderr:r.stderr});
 process.stdout.write(r.stdout);if(r.stderr)process.stderr.write(r.stderr);
}
writeFileSync(import.meta.dirname+'/batch-result.json',JSON.stringify(results,null,2));
if(results.some(x=>x.exit!==0))process.exitCode=1;
