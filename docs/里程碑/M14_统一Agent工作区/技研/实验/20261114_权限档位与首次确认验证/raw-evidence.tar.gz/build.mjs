import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD';
const result=await build({stdin:{contents:`export {agentPermission,expandCodexPermissionShorthands} from '${repo}/src/shared/agent-permissions.ts'; export {AgentRuntimeService} from '${repo}/src/main/core/ai/agent-runtime.ts';`,resolveDir:repo,loader:'ts'},bundle:true,platform:'node',format:'cjs',target:'node22',metafile:true,tsconfig:repo+'/tsconfig.node.json',nodePaths:['/private/tmp/willyou-m14-owner-probe/node_modules','/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules'],outfile:root+'/actual.cjs',plugins:[{name:'forbid-pty',setup(b){b.onResolve({filter:/^node-pty$/},()=>({path:root+'/pty-stub.cjs'}));}}]});
const hash=path=>({path,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')});
writeFileSync(root+'/build.json',JSON.stringify({sources:Object.keys(result.metafile.inputs).filter(p=>!p.startsWith('<')).map(p=>hash(resolve(p))),outputs:[hash(root+'/actual.cjs')],scope:'Actual shared permission mapping and runtime coordinator; node-pty replaced with a throwing guard, never exercised. Not a PTY runtime test.'},null,2));
console.log(JSON.stringify({inputs:Object.keys(result.metafile.inputs).length}));
