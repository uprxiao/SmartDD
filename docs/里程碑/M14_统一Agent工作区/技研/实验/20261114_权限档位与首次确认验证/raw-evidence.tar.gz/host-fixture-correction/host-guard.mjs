import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readdirSync} from 'node:fs';
import actual from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/host-'),evidence=[];
const forbidden=new Proxy({},{get(_t,key){throw Error('Unexpected dependency access: '+String(key));}});
for(const kind of ['claude','codex']){
 const home=out+'/'+kind,userData=home+'/userdata',cwd=home+'/workspace';for(const p of [home,userData,cwd])mkdirSync(p,{recursive:true});
 const config={id:kind+'-fixture',name:'Isolated login source',source:'login',kind,toolId:kind+'-tool',providerId:null,models:[],defaultModel:null};
 const tool={id:config.toolId,kind,executable:'/synthetic-never-spawned/'+kind,installed:true,version:'fixture-only',login:'oauth'};
 let preference={selected:'full',fullConfirmed:false},profileReads=0;
 const runtime=new actual.AgentRuntimeService({db:forbidden,agents:{configs:()=>[config],tools:()=>[tool],providers:()=>[]},tools:{refresh:async()=>{}},providers:forbidden,profiles:{get:()=>{profileReads++;return{args:[],env:[]};}},userData,baseEnv:()=>({HOME:home}),permissionPreferences:()=>preference});
 const input={profileId:config.id,cwd,signal:new AbortController().signal};
 await assert.rejects(runtime.prepare(input),/首次使用完全访问权限/);assert.equal(profileReads,0);assert.deepEqual(readdirSync(userData),[]);
 preference.fullConfirmed=true;const prepared=await runtime.prepare(input);assert(prepared);prepared.assertCurrent();const full=prepared.snapshot(home+'/.state',1);assert.equal(full.permission.id,'full');assert.deepEqual(full.permission.args,actual.agentPermission(kind,'full').args);
 preference={selected:'auto',fullConfirmed:false};const auto=await runtime.prepare(input);assert(auto);assert.equal(auto.snapshot(home+'/.state',2).permission.id,kind==='claude'?'ask':'auto');assert.equal(preference.selected,'auto');
 const ask=await runtime.prepare({...input,permission:'ask'});assert.equal(ask.snapshot(home+'/.state',3).permission.id,'ask');assert.equal(preference.selected,'auto');
 evidence.push({kind,newFullRejectedBeforeProfileMaterialization:true,confirmedFullPrepared:true,autoEffective:kind==='claude'?'ask':'auto',rememberedAutoUnchanged:true,explicitAskPrepared:true,fullArgs:full.permission.args,autoArgs:auto.profile.args});
}
const result={out,passed:true,drivers:2,evidence,scope:'Actual AgentRuntimeService preparation guard and permission mapping with synthetic login config/tool registry and dependencies. PTY forbidden. No authenticated login, TaskService/renderer confirmation, native runtime, or restored-history gate test.'};writeFileSync(root+'/host-result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
