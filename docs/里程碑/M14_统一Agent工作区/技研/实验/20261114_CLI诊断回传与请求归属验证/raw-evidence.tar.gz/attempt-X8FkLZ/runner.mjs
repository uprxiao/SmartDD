import{createInterface}from'node:readline';import{spawn}from'node:child_process';
for await(const line of createInterface({input:process.stdin})){
 const {id,binary,args,env}=JSON.parse(line);const result=await new Promise((resolve,reject)=>{const c=spawn(binary,args,{env:{...process.env,...env}});let stdout='',stderr='';c.stdout.on('data',x=>stdout+=x);c.stderr.on('data',x=>stderr+=x);c.once('error',reject);c.once('close',code=>resolve({pid:c.pid,code,stdout,stderr}));});process.stdout.write(JSON.stringify({id,...result})+'\n');
}
