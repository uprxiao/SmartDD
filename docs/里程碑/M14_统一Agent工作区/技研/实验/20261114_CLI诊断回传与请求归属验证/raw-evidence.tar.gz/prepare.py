from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_CLI诊断回传与请求归属验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
b=json.loads((root/'build.json').read_text())
for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256']
for o in b['outputs']:assert sha((root/Path(o['file']).name).read_bytes())==o['sha256']
cli=json.loads((root/'cli-build.json').read_text());assert sha(Path(cli['source']).read_bytes())==cli['sourceSha256']
for o in cli['outputs']:assert sha((root/o['file']).read_bytes())==o['sha256']and sha((root/(o['file']+'.mm')).read_bytes())==o['sourceSha256']
r=json.loads((root/'latest.json').read_text());assert r['passed']==5 and not r.get('error');a=Path(r['out']);attempts=[]
for p in sorted(root.glob('attempt-*')):
 result=json.loads((p/'result.json').read_text());events=json.loads((p/'events.json').read_text());assert len(events)==1 and events[0]['type']=='owned-root-exit'and events[0]['code']==0
 db=sqlite3.connect((p/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for q in ["SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM capability_run_activities WHERE state='active'","SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'"]:assert db.execute(q).fetchone()==(0,)
 db.close();proofs=json.loads((p/'proofs.json').read_text());owner=json.loads((p/'owned-roots.json').read_text())[0]
 for proof in [x for x in proofs if x]:assert any(x['pid']==owner['pid']and x['startedAt']==owner['startedAt']for x in proof['ancestors'])
 for output in json.loads((p/'cli-build.json').read_text())['outputs']:assert sha((p/(output['file']+'.mm')).read_bytes())==output['sourceSha256']
 attempts.append({'attempt':p.name,'passed':result['passed'],'error':result.get('error'),'exit':events[0],'kernelProofs':len([x for x in proofs if x]),'unverifiablePeers':len([x for x in proofs if not x]),'allRunResourcesSettled':True})
assert len(attempts)==3
proofs=json.loads((a/'proofs.json').read_text());assert len(proofs)==5 and all(proofs)
wire=json.loads((root/'wire-contract.json').read_text());assert wire['passed']==9 and sha((root/'diagnostic-cli').read_bytes())==wire['binary']['sha256']
repro=json.loads((a/'baseline-stale-attribution.json').read_text());fixed=json.loads((a/'request-local-output.json').read_text());assert repro['receipt']['run_id'] and fixed['unknown']['row']['run_id']is None and fixed['known']['row']['run_id']
rows=json.loads((a/'denials.json').read_text());assert len(rows)==6
runtime={'finalAttempt':a.name,'attempts':attempts,'checks':r['checks'],'wireContract':wire,'cli':cli,'finalDenialRows':len(rows),'expectedWrongBaselineRow':repro['receipt']['audit_id'],'knownAssociation':fixed['known']['row'],'scope':r['scope'],'modelsCalled':0,'nativeAgentTurns':0,'note':'One intentionally wrong baseline row remains as counterexample; not all six rows represent corrected behavior. Five final kernel proofs from genuine sockets; generic owned Node fixture is not an Agent SDK launch.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
prior=repo/base/'技研/实验/20261114_原生浏览器CLI与拒绝审计验证/raw-evidence.tar.gz'
refs=[repo/'src/main/core/applications/cli-gateway.ts',repo/'native/applications/cli.mm',repo/'src/shared/application-cli.ts',repo/'src/shared/application-bridge.ts',repo/'drizzle/0028_capability_broker_denials.sql',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
(root/'source-review.json').write_text(json.dumps({'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(b['sources']),'outputs':b['outputs'],'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'baselineBundle':{'file':'baseline.cjs','sha256':sha((root/'baseline.cjs').read_bytes()),'origin':'Prior 4.69 candidate bundle; current gateway unchanged there.'},'dependencyArchive':{'path':str(prior.relative_to(repo)),'sha256':sha(prior.read_bytes())},'variants':['Gateway auth checks unchanged; remove connection-level authenticatedRun assignment and use receive-local context only after authenticate succeeds.','Native CLI optional auditId/auditUnavailable validation+copy; sequence-cli adds test-only invalid second token and FIFO-synchronized pipelining.','Candidate CLI/MCP denial CHECK Schema reused from 4.69.','Post-auth list failures and storage trigger are explicit injected faults; real kernel reader and ancestor identity are not mocked.','Programmatic registry attaches a captured generic Node process; does not exercise provider launcher or model.','Host diagnostic association verified by real SQLite join only; new UI/IPC diagnostics service not implemented.'],'t3Boundary':'T3 scopes live native requests to exact runtime/session. This experiment complements WillYou business CLI diagnostics; T3 is not claimed to provide this exact denial schema or return contract.'},ensure_ascii=False,indent=2))
(root/'failure-notes.md').write_text('''# 运行记录与反例

attempt-fwpwDy 首批四项通过；随后补同连接并发分支。attempt-X8FkLZ 前四项通过，第五项预期错误：无效请求先返回，CLI 退出早于另一请求完成内核身份读取，实际得到 PEER_UNVERIFIABLE，网关没有放宽认证。该调度不能证明“已认证请求等待”的场景。

最终 attempt-om5rPS 用私有 FIFO：测试 CLI 发送第一条管线请求后等待读取；只有真实身份认证进入 list 处理器才写入 ready，随后 CLI 发无效 token 请求。CLI 收到拒绝并退出后，研究宿主释放第一条已认证请求的失败，确认其审计仍关联原 run，而无效请求只进入宿主级诊断。没有 sleep／轮询或 additionalRoot 放行。

三批通用测试根均退出0，实际 run／进程／活动／资源租约收束。早期 sequence-cli 源码从同一受控变体重建并逐一匹配各批已记录 sourceSha256 后归档，未冒充当时已有源码副本。测试二进制只记录哈希和源码，不加入产品。
''')
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if any(x in ['node_modules','resources','dependencies','publication','__pycache__']for x in rel.parts):continue
 if p.name in ['manifest.json','audit.json','publication-audit.json']:continue
 if p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.md','.mm']:files.append(p)
dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# CLI 诊断回传与请求归属验证

2026-11-14；技术方案 §9.7.1、验证账 §4.72；R01／08／10，Q01／37 的诊断边界。仅隔离研究，产品源码／正式 Schema 未修改。

## 真实链路与结论

当前程序化注册器预留／准备／arm，再登记实验自己启动的通用 Node 根进程的真实 PID／出生身份。该根实际启动当前及候选编译 CLI，经 Unix socket、MacUnixPeerIdentityReader 和真实祖先检查进入网关。这里没有 Codex／Claude 或模型回合，也不声称验证完整 Provider 启动器。Electron 分配被禁止，浏览器只有元数据能力。

最终 {a.name} 五项通过，5 份真实内核 peer 证明：

| 检查 | 证据 |
| --- | --- |
| D01 现状 | 原 Schema 拒绝审计写入，网关返回 auditUnavailable，但原 CLI 丢弃字段；权限仍正确拒绝 |
| D02 回传 | 候选 Schema＋CLI 将 auditId 传出并对应 SQLite 行；注入 INSERT 失败后传 auditUnavailable=true，仍返回 AUTH_REQUIRED／退出2 |
| D03 归属反例 | 同一真实连接先成功 list，再用无效 token call；当前 peer.authenticatedRun 残留使拒绝审计错误关联旧 run |
| D04 每请求身份 | 候选 receive 局部保存本次认证结果。无效 token 只写 run_id=null；本次认证完成后的注入处理器失败保留真实 run，SQLite 可关联正确 task／project |
| D05 并发 | 一个已认证请求等待，另一个无效 token 被拒并退出；后续第一个请求失败仍保留自己的 run，第二个不借用它。候选不能仅在 receive 开头清空共享 peer 字段 |

D05 使用临时 FIFO 等待真实认证完成；不绕过身份验证，不用 sleep。首个并发尝试因 CLI 提前退出而出现 PEER_UNVERIFIABLE，属于实际安全拒绝，但没有覆盖预定交错；修正驱动同步后通过，原始失败保留。首批4项、扩展失败批、最终5项三个通用根均退出0，全部运行资源收束。

最终 SQLite 保留六条拒绝，其中一条故意保留 D03 的错误归属反例，不能把整张表误记为修正后的数据。认证后处理器错误为显式注入，底层工具业务正常结果不是本批重点。

## CLI 返回兼容合同

候选为现有拒绝结果增加可选 auditId／auditUnavailable，保留 error、requestId、operationId 和既有退出码。auditId 需合法 UUID，auditUnavailable 需真正 boolean，两者不能同时表示“已有审计编号且审计不可用”。旧宿主无这些字段仍能解析，但缺字段不证明审计成功。

另以受控本机 socket 响应驱动同一编译 CLI，9 项检查通过：旧响应、合法编号、true／false boolean、unknown effect 仍退出5、坏编号、数值／字符串假 boolean、互相冲突字段。后四类返回 INVALID_RESPONSE／退出4。这组只证明序列化与解析，不冒充真实网关授权或 UI。

宿主 UI 仍从可信记录读取诊断：本次认证成功才按 run→task/project 关联；无 run 的拒绝进入宿主级诊断，不按请求里的 task、token 或上一请求猜测。auditId 是查询关联值，不是授权令牌；查询服务须重新检查当前用户／项目访问范围。新诊断服务、IPC／订阅及 UI 尚未实现，不能以 SQL join 通过代替。Schema 扩充与请求局部归属应一起实施，避免原本被 Schema 拦下的错误归属随迁移开始落库。

## 复跑与限制

先恢复[前批依赖与资源](../20261114_原生浏览器CLI与拒绝审计验证/README.md)，按 source-review 的归档哈希核对。build.mjs 在 SmartDD cwd 构建临时 bundle；build-cli.mjs 仅编译临时二进制；node probe.mjs 运行真实网关链，node wire-contract.mjs 检查受控响应。需要本机固定 Node ABI／依赖、macOS arm64 编译与内核身份 helper；资源目录与依赖不重复归档。

baseline.cjs 保留前批未改 CLI 网关；candidate.cjs 包含仅在内存构建的请求局部身份变体。原始拒绝 Schema 候选来自前批，未分配正式迁移编号。没有日常凭据、外部网络、模型花费、产品改动或 UI 验收。

[结果](result.json) · [运行核验](runtime-audit.json) · [源码依据](source-review.json) · [摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。{len(files)} 文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(b['sources'])} 构建输入核对。
''')
old='当前 CLI 输出会省略网关顶层 auditId／auditUnavailable；统一 UI 需由宿主诊断服务发布拒绝和审计不可用状态，不能假设现有 CLI 输出已包含这些字段。未能认证 run 的拒绝只能进入宿主级诊断，不能按请求参数猜测任务归属；认证成功后才允许关联原 run。若需由 CLI 返回传递则另做明确的版本合同及验证。本批只验证候选数据库约束，未实施正式迁移或返回字段扩展；权限拒绝正确与审计记录完整分别验收。'
new='''当前 CLI 输出会省略网关顶层 auditId／auditUnavailable；[诊断合同实验](实验/20261114_CLI诊断回传与请求归属验证/README.md)已验证临时候选可选字段回传：保留现有 error／requestId／operationId 与退出码，校验 auditId 为合法 UUID、auditUnavailable 为 boolean，并拒绝互相冲突状态。旧宿主缺字段仍兼容，但缺字段不能被解释为审计成功。存储失败不改变原权限拒绝，unknown 操作仍不自动重发。

**诊断归属按本次请求认证结果保存，不能借用连接历史。** 当前 peer.authenticatedRun 会残留前一次 run；真实连接先成功 list 再发送无效 token 已复现错误归属。候选将本次认证结果放在 receive 局部变量，认证失败写入 host-only 诊断；同连接并发时，各请求保留自己的局部身份，不能简单清空共享 peer 字段。顺序反例与一个已认证等待／另一请求失败的并发交错已核验，内核身份检查未放宽。正式 Schema 扩充与此修正应同时落地，不能只放开 CLI 行约束。

统一 UI 仍需由宿主诊断服务发布拒绝和审计不可用状态。本次成功认证后才按 run→task/project 关联；未知 run 只进入宿主级诊断，不按请求参数、token 或前一次连接身份猜测。auditId 只是关联值，不赋予查询权限，服务每次查询仍检查当前项目／用户范围。本批验证了实际 SQLite 关联及 CLI 返回，未实现新诊断服务、IPC／订阅、UI 或正式迁移；权限拒绝正确、审计记录完整与前端可见性分别验收。'''
def tech(t):assert old in t;return t.replace(old,new)
edit(base/'技研/技术方案.md',tech)
record='''### 4.72 CLI 审计回传、每请求归属与并发

[诊断合同实验](实验/20261114_CLI诊断回传与请求归属验证/README.md)最终五项通过：原 CLI 丢失 auditUnavailable 的现状；候选回传 auditId／存储失败状态；真实连接成功认证后无效 token 借用旧 run 的反例；receive 局部身份修正；同连接已认证等待与无效请求并发时各自归属。使用实际编译 CLI、Unix socket、内核 peer、程序化注册器和通用 Node 测试根，没有新增 Agent／模型回合。候选 Schema 与归属修正须一起实施。

另有9项受控响应检查覆盖旧字段缺省、合法字段、类型／冲突拒绝与 unknown 退出码；不是授权证据。初次并发因 CLI 先退出而正确得到 PEER_UNVERIFIABLE，驱动改为 FIFO 等待真实认证后补到目标交错；没有绕过内核检查。三批根进程正常退出，资源收束。原始错误归属行作为反例保留，不声称整张表都是候选正确数据。

T0.1 §9.7.1 已收口可选字段、每请求认证归属与宿主诊断边界。真实诊断 IPC／订阅／UI、当前访问权限查询服务仍待后续接入验证。Q01／37 仅增加诊断局部证据，产品／正式迁移未改。

'''
def ledger(t):
 assert '### 4.72 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');t=t.replace('审计诊断回传合同仍待验证','§4.72 已补 CLI 可选诊断字段、请求局部归属及真实同连接并发；诊断 IPC／UI 和查询访问检查仍待验证');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('最新进展：'):lines[i]='最新进展：CLI 拒绝诊断五项真实链检查＋九项返回合同检查通过。复现并验证候选修正：同连接失败请求不能继承上一请求的 run，审计编号／不可用状态可选回传；见[技术方案 §9.7.1](技研/技术方案.md)。新诊断 UI／IPC 尚未实现，产品未改。'
  if l.startswith('下一步：'):lines[i]='下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的业务在途／宿主恢复、历史迁移与统一状态合同；不重复已通过的 CLI 正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(b['sources'])}))
