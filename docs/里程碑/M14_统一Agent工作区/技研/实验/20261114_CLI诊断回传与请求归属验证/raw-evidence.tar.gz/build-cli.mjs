import{readFileSync,writeFileSync,chmodSync}from'node:fs';import{execFileSync}from'node:child_process';import{createHash}from'node:crypto';
const root=import.meta.dirname,source='/Users/hx/projects/SmartDD/native/applications/cli.mm',original=readFileSync(source,'utf8');writeFileSync(root+'/original-cli.mm',original);chmodSync(root+'/original-cli',0o755);
const anchor='  output(value);fprintf(stderr,"willyou-app: %s\\n",code.UTF8String);';if(!original.includes(anchor))throw Error('anchor missing');
const patch=`  id audit=response[@"auditId"],unavailable=response[@"auditUnavailable"];
  if(audit&&(![audit isKindOfClass:NSString.class]||!matches(audit,@"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$")))return failure(@"INVALID_RESPONSE",@"审计标识无效",4,@"bridge");
  if(unavailable&&CFGetTypeID((__bridge CFTypeRef)unavailable)!=CFBooleanGetTypeID())return failure(@"INVALID_RESPONSE",@"审计状态无效",4,@"bridge");
  if(audit&&[unavailable isEqual:@YES])return failure(@"INVALID_RESPONSE",@"审计状态冲突",4,@"bridge");
  if(audit)value[@"auditId"]=audit;if(unavailable)value[@"auditUnavailable"]=unavailable;
`;
const diagnostic=original.replace(anchor,patch+anchor);writeFileSync(root+'/diagnostic-cli.mm',diagnostic);
const seqAnchor='NSDictionary *call=@{@"schema":@"willyou-cli-v1",@"id":NSUUID.UUID.UUIDString.lowercaseString,@"token":token,';if(!diagnostic.includes(seqAnchor))throw Error('sequence anchor absent');const sequence=diagnostic.replace(seqAnchor,'NSDictionary *call=@{@"schema":@"willyou-cli-v1",@"id":NSUUID.UUID.UUIDString.lowercaseString,@"token":getenv("M14_BAD_SECOND_TOKEN")?@"'+('0'.repeat(64))+'":token,');const pipelined=sequence.replace('  NSDictionary *call=',`  if(getenv("M14_PIPELINE")){
    NSDictionary *first=@{@"schema":@"willyou-cli-v1",@"id":NSUUID.UUID.UUIDString.lowercaseString,@"token":token,@"method":@"capabilities/list"};
    NSData *bytes=[NSJSONSerialization dataWithJSONObject:first options:0 error:nil];std::string text((const char*)bytes.bytes,bytes.length);text+='\\n';size_t offset=0;auto until=milliseconds()+10000;
    while(offset<text.size()){if(!ready(fd,POLLOUT,until))return failure(@"CONNECTION_UNAVAILABLE",@"研究管线未发送",4);ssize_t n=write(fd,text.data()+offset,text.size()-offset);if(n<0&&(errno==EINTR||errno==EAGAIN||errno==EWOULDBLOCK))continue;if(n<=0)return 4;offset+=(size_t)n;}
    const char *gatePath=getenv("M14_PIPELINE_GATE");if(!gatePath)return 4;int gate=open(gatePath,O_RDONLY);char readyByte;if(gate<0||read(gate,&readyByte,1)!=1)return 4;close(gate);
  }
  NSDictionary *call=`);writeFileSync(root+'/sequence-cli.mm',pipelined);
for(const name of ['diagnostic-cli','sequence-cli'])execFileSync('xcrun',['clang++','-std=c++17','-fobjc-arc','-O2','-mmacosx-version-min=12.0','-arch','arm64','-framework','Foundation',root+'/'+name+'.mm','-o',root+'/'+name],{stdio:'inherit'});
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');writeFileSync(root+'/cli-build.json',JSON.stringify({source,sourceSha256:sha(source),outputs:['original-cli','diagnostic-cli','sequence-cli'].map(n=>({file:n,sha256:sha(root+'/'+n),sourceSha256:sha(root+'/'+n+'.mm')}))},null,2));
