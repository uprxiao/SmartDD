import assert from 'node:assert/strict';
import {z} from 'zod';
const scopeSchema=z.object({source:z.literal('plugin-write'),taskId:z.string(),bindingId:z.uuid(),runId:z.uuid(),generation:z.number().int().positive()}).strict();
export function router(f){
 const windows=new WeakMap();
 const window=owner=>{const handle=Object.freeze({});windows.set(handle,owner);return handle;};
 const resolve=(handle,input)=>{assert(windows.has(handle),'TRUSTED_WINDOW_REQUIRED');const scope=scopeSchema.parse(input),context=f.programmaticRuns.assertActive(scope.runId),row=f.sqlite.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(scope.runId);assert(context.run.taskId===scope.taskId&&row.binding_id===scope.bindingId&&row.generation===scope.generation,'REQUEST_SCOPE_CHANGED');return{owner:windows.get(handle),scope,target:{taskId:scope.taskId,ptyId:row.pty_id}};};
 return{window,present:(handle,input)=>{const c=resolve(handle,input);return f.pluginHost.approvals.present(c.owner,c.target).map(({ptyId,...review})=>({...review,scope:c.scope}));},decide:(handle,input,decision)=>{const c=resolve(handle,input);assert.equal(decision.runId,c.scope.runId,'DECISION_RUN_CHANGED');return f.pluginHost.approvals.decide(c.owner,{...c.target,id:decision.id,displayReceiptId:decision.displayReceiptId,reviewHash:decision.reviewHash,allow:decision.allow});}};
}
