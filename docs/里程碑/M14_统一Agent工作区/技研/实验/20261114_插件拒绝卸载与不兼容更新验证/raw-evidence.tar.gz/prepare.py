from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_插件拒绝卸载与不兼容更新验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
results=[json.loads((root/('latest-'+mode+'.json')).read_text())for mode in ['deny','uninstall','incompatible']]
assert all(r['passed']==4 and not r.get('error')for r in results)
attempts=[]
for a in sorted(root.glob('attempt-*')):
 result=json.loads((a/'result.json').read_text());cleanup=json.loads((a/'cleanup.json').read_text());assert len(cleanup['nativeExits'])==2 and all(x['code']==(0 if x['driver']=='codex'else 143)for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped'for x in cleanup['cleanup'])
 for n in ['candidate.cjs','actual.cjs','profile.cjs','mcp-bridge.cjs']:assert sha((a/n).read_bytes())==sha((root/n).read_bytes())
 db=sqlite3.connect((a/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM plugin_runtime_leases WHERE state<>'closed'"]:assert db.execute(query).fetchone()==(0,)
 db.close();attempts.append({'attempt':a.name,'mode':result['mode'],'passed':result['passed'],'error':result.get('error'),'nativeExits':cleanup['nativeExits'],'modelRequests':len(json.loads((a/'models.json').read_text())),'finalAllOwnedResourcesSettled':True,'probeSha256':sha((a/'probe.mjs').read_bytes())})
assert len(attempts)==4 and sum(bool(x['error'])for x in attempts)==1
runtime=[]
for r in results:
 mode=r['mode'];a=Path(r['out']);calls=json.loads((a/'plugin-calls.json').read_text());inv=json.loads((a/'invocations.json').read_text());approvals=json.loads((a/'approvals.json').read_text());models=json.loads((a/'models.json').read_text())
 assert len(models)==6 and len(calls)==(0 if mode=='uninstall'else 2)
 assert len(inv)==len(approvals)==(3 if mode=='deny'else 2)
 assert {x['operation_id']for x in approvals}=={x['operation_id']for x in inv}
 assert {x['scope']['operationId']for x in calls}=={x['operation_id']for x in inv if x['state']=='succeeded'}
 for x in inv:
  assert x['attempt_count']==1
  assert (x['state'],x['effect_state'])in [('succeeded','completed'),('failed','not-started')]
 if mode=='deny':assert sum(x['state']=='denied'for x in approvals)==1 and sum(x['error_code']=='PERMISSION_DENIED'for x in inv)==1
 else:assert all(x['state']=='allowed'for x in approvals)
 if mode=='uninstall':assert all(x['error_code']=='NOT_FOUND'for x in inv)
 requests=[json.loads(x)for x in(a/'codex-requests.jsonl').read_text().splitlines()];turns=[x for x in requests if x['method']=='turn/start'];assert sum(x['method']=='thread/start'for x in requests)==1 and len(turns)==2 and turns[0]['params']['threadId']==turns[1]['params']['threadId']
 observed=[]
 for x in models:
  if x['count']%2:continue
  b=x['body'];items=[v for v in b.get('input',[])if v.get('type')=='function_call_output']if x['driver']=='codex'else[v for m in b['messages']if isinstance(m['content'],list)for v in m['content']if v.get('type')=='tool_result']
  expected=('NOT_FOUND'if mode=='uninstall'else'PERMISSION_DENIED'if mode=='deny'and x['driver']=='codex'else'CHILD_OLD'if x['driver']=='claude'else'PARENT_OLD')if x['count']==2 else('CONFIG_INCOMPATIBLE'if mode=='incompatible'else'NOT_FOUND'if mode=='uninstall'else'VERSION_0.1.1:PARENT_NEW')
  assert expected in json.dumps(items[-1]);observed.append({'driver':x['driver'],'request':x['count'],'expected':expected,'latestToolResult':items[-1]})
 runtime.append({'mode':mode,'attempt':a.name,'invocations':inv,'approvalStates':[x['state']for x in approvals],'writes':len(calls),'modelRequests':len(models),'latestToolResultsVerified':observed,'threadId':turns[0]['params']['threadId']})
(root/'runtime-audit.json').write_text(json.dumps({'attempts':attempts,'finalModes':runtime,'failedAttempt':'Uninstall first attempt expected APP_NOT_ENABLED, actual current service returned NOT_FOUND. Probe assertion produced local model HTTP 500 and final turn failed. Changed only expected error and tightened observation to latest tool result; source unchanged. Prior deny output also checked retrospectively against latest tool result.','scope':'Native Codex/Claude, actual private MCP and existing plugin lifecycle; synthetic models/plugin privateData and candidate launch/UI facade. No product or external business writes.'},ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/plugins'/n for n in ['runtime-supervisor.ts','lifecycle.ts','session-tools.ts','write-approvals.ts','project-policy.ts','host-service.ts']]+[t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'design':'Preserve existing SmartDD preflight checks after approval. T3 response ownership is a reference, not a replacement for SmartDD plugin runtime authority.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
result={'modes':results,'finalChecks':12,'failedAttemptsPreserved':1,'scope':'Isolated research, not product acceptance'}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 插件拒绝、卸载与不兼容更新

2026-11-14；技术方案 §9.6.1、验证账 §4.67；R02／05／06／08／10，Q09／27／28／40／41。沿用 §4.66 的真实 Codex 0.167.1 父运行、Claude SDK 0.3.321／native 2.1.321 子运行、现有私有 MCP／ToolService／PluginHost 与沙箱插件。模型只用本机端点，插件只写临时 privateData；产品与共享原型未改。

## 三个分支，各四项检查通过

每个分支先让父子同时等待插件写审批，再启动生命周期变更；完成子调用并停止子运行，确认父审批及变更等待仍保留；处理父审批后才允许变更收口；同一父原生 thread 再发一轮，核对最新工具结果和实际调用账；最后释放全部自有运行资源。

| 分支 | 原待办与变更 | 同一父会话下一轮 | 实际写入 |
| --- | --- | --- | --- |
| deny | 子允许、父拒绝；父 PERMISSION_DENIED／failed／not-started，兼容更新随后完成 | 新包需要全新审批，允许后成功；原拒绝回执不能重用 | 子旧版一次、父新版一次 |
| uninstall | 选择保留数据卸载；两条审批都允许，但最终执行守卫返回 NOT_FOUND／failed／not-started；零写入后卸载提交 | NOT_FOUND，attemptCount=0；没有新审批或业务调用账 | 0 |
| incompatible | 两条旧审批允许并按旧合同写入，随后新包将 capability semantics 从 write 改为 read | CONFIG_INCOMPATIBLE；既有启动范围拒绝变化，没有新增审批、调用账或写入 | 两次旧版写，新版 0 |

每个最终分支六次本机模型请求，Codex 只创建一个 thread、两个 turn 使用相同 threadId；原生回合终态成功表示错误已作为工具结果进入模型并正常结束，不表示被拒绝的业务执行成功。三条路径均在最终快照核验运行／桥退出、run 租约释放和当前插件租约关闭，无真实秘密读取。

## 关键设计结论

审批决定、业务执行事实、插件生命周期分别记录。特别是卸载期间 allowed 可以对应 failed／not-started；统一 UI 不能仅凭审批允许显示“操作成功”，不能自动重放该操作，也不能迁移旧批准到新包／新 run。现有 PluginSessionTools 在审批后再次调用 authorize／invocation.assertActive，是迁移必须保留的最终守卫。

兼容与不兼容更新不能一刀切。兼容分支可在同一原生会话继续；实际能力 permission／semantics／slots 等发生启动合同不接受的变化时，保留启动来源、拒绝旧运行调用并给出重启会话提示。本批只实测 semantics 变化，其他字段不能据此逐项宣称通过。

## 保留的实验失败

首次 uninstall（attempt-uninstall-Mx1S5V）前两项已通过；后续调用实际返回 NOT_FOUND，实验误期望 APP_NOT_ENABLED，使本机模型端点返回 500、父回合失败。原始请求／失败／最终清理均保留。修正实验错误码预期，改成只检查最新工具结果，复验通过；没有修改产品行为。deny 的旧驱动也离线复核最新工具结果，避免从历史内容误判。

最终批次：{', '.join(Path(r['out']).name for r in results)}。含失败共四批、八个真实原生进程、24 次本机模型请求；各批最终所有记录的自有运行资源均结束。旧版插件 lease 行可能随安装清理删除，不用最终行数倒推历史总进程数。

## 边界与证据

审批为研究私有窗口 facade；候选程序化启动／委派没有接入产品。没有真实 renderer／IPC、外部业务、共享 SVN 写入、更新／卸载中宿主崩溃、审批超时、删除私有数据卸载、其他不兼容字段或跨平台证据。并发的是待审批调用，实际写函数按实验顺序执行。

[结果](result.json)、[逐分支运行审计与最新工具结果](runtime-audit.json)、[源码核对](source-review.json)、[归档摘要](archive-manifest.json)、[脚本／协议／数据库](raw-evidence.tar.gz)。{len(files)} 文件、{len(dbs)} 份 SQLite 完整性与外键通过、{len(sources)} 构建输入核验。运行需要固定依赖与原生版本，仅使用临时 HOME 与本机模型端点。
''')
section='''### 9.6.1 审批拒绝、卸载与不兼容变更

[异常分支实验](实验/20261114_插件拒绝卸载与不兼容更新验证/README.md)补证三种路径：更新中父审批拒绝后调用以 PERMISSION_DENIED／not-started 结束，其他子调用不受牵连，更新继续收口；卸载期间两条旧审批即使允许，最终执行守卫仍返回 NOT_FOUND／not-started，零写入；卸载后同一会话再调用也明确拒绝。能力 semantics 变更则在旧运行下一次调用时返回 CONFIG_INCOMPATIBLE，不建立新审批或业务调用。

**统一 UI 必须分别展示审批决定与执行结果。** allowed 不是 succeeded；本批两条 allowed 对应 failed／not-started。迁移保留审批后、派发前的当前身份／生命周期／策略检查，执行结果由实际调用账驱动。不能仅凭回执显示成功、自动重放被阻止操作，或迁移旧批准到新包／新运行。

同一原生会话是否可继续使用更新后的插件，仍以启动能力合同和当前兼容检查判断。兼容更新允许重新审阅后继续；不兼容变更保持原启动快照，明确要求重新建立会话／能力选择，不偷偷扩大原运行授权。此次只实测 semantics 变化，审批超时、其他兼容字段、删除数据卸载和生命周期中途崩溃仍待验证；真实界面按上述状态区分进行后续验收。

'''
def tech(t):
 assert '### 9.6.1 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 t=t.replace('卸载／不兼容变更及其他竞争分支仍须联合验证。','§9.6.1 补拒绝、保留数据卸载和 semantics 不兼容分支；其他竞争与崩溃仍待验证。')
 t=t.replace('卸载／拒绝／过期／不兼容变更和更新崩溃仍须按具体分支验证，真实 UI、业务连接与 SVN 共享写者另验。','卸载／拒绝／semantics 不兼容分支见 §9.6.1；过期、其他兼容字段与更新崩溃仍须验证，真实 UI、业务连接与 SVN 共享写者另验。')
 return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.67 插件审批拒绝、卸载与不兼容更新

[插件异常实验](实验/20261114_插件拒绝卸载与不兼容更新验证/README.md)三个分支各四项通过：拒绝父审批不取消子调用，更新等待对应预留结束；保留数据卸载期间两条审批允许也不能越过最终派发守卫，调用 NOT_FOUND／not-started、零写入；semantics 变化后旧会话返回 CONFIG_INCOMPATIBLE，无新审批／调用／写入。最新原生工具结果分别进入下一模型请求，父 thread 保持不变。

保留首次卸载实验错误预期 APP_NOT_ENABLED 的失败；实际服务返回 NOT_FOUND，修正实验断言并复验，不改产品。共四批八个 native 最终退出；SQLite、资源释放及来源哈希复核。技术方案 §9.6.1 明确审批状态与执行结果分离。超时、删除数据卸载、其他不兼容字段、更新中宿主崩溃、真实 UI／业务仍未补证。

'''
def ledger(t):
 assert '### 4.67 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正')
 t=t.replace('；真实 UI／卸载／不兼容更新与崩溃仍待验','；§4.67 补拒绝、保留数据卸载与 semantics 不兼容更新，真实 UI／其他字段／崩溃仍待验')
 t=t.replace('继续补浏览器／邮件等实际上下文、在途操作与插件卸载／异常更新','§4.67 又补插件拒绝、保留数据卸载及 semantics 不兼容更新；继续补浏览器／邮件等实际上下文、在途操作、其他更新分支及崩溃')
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：插件拒绝审批、保留数据卸载、semantics 不兼容更新三分支各 4 项隔离检查通过；实证“审批允许”仍可能被最终执行守卫阻止，UI 必须区分审批和执行结果。见[技术方案 §9.6.1](技研/技术方案.md)。保留实验错误预期及复验，产品未改。'
 i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续实际业务上下文、在途操作及回执／宿主恢复的关键未决分支；已通过路径不重复跑，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources),'finalChecks':12}))
