import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const handles=new WeakMap();
export function migrate(db){
 assert(!db.inTransaction,'MIGRATION_REQUIRES_OUTER_COORDINATION');
 return db.transaction(()=>{
  if(db.prepare("SELECT 1 FROM sqlite_master WHERE name='m14_profile_execution_revision'").get())return 'existing';
  assert(!db.prepare('SELECT id FROM ai_profiles WHERE NOT json_valid(env) OR NOT json_valid(args) LIMIT 1').get(),'INVALID_EXISTING_CONFIG');
  db.exec(readFileSync(new URL('./revision.sql',import.meta.url),'utf8'));return 'created';
 }).immediate();
}
export function revision(db,id){const row=db.prepare('SELECT * FROM m14_profile_execution_revision WHERE profile_id=?').get(id);assert(row?.present===1,'CONFIG_ABSENT');return row.revision;}
export function capture(db,profiles,id){
 assert(!db.inTransaction,'FRESH_SNAPSHOT_REQUIRED');const before=revision(db,id),resolved=profiles.resolve(id),after=revision(db,id);assert.equal(before,after,'CONFIG_CHANGED_DURING_RESOLVE');
 const handle=Object.freeze({profileId:id,revision:after});handles.set(handle,{db,resolved});return handle;
}
export function consume(db,handle,fn){
 assert(!db.inTransaction,'FRESH_SNAPSHOT_REQUIRED');const privateValue=handles.get(handle);assert(privateValue?.db===db,'CONFIG_HANDLE_NOT_OWNED');assert.equal(revision(db,handle.profileId),handle.revision,'CONFIG_REVISION_CHANGED');return fn(privateValue.resolved);
}
