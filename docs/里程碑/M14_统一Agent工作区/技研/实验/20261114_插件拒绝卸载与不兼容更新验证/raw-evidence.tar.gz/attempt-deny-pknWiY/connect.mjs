import assert from 'node:assert/strict';
import Database from 'better-sqlite3';
import {readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import actual from './candidate.cjs';
import profileActual from './profile.cjs';
export function connect(spec){
 const sqlite=new Database(join(spec.root,'state.sqlite'));sqlite.pragma('foreign_keys=ON');sqlite.pragma('busy_timeout=5000');const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),store=new actual.ResourceStore(sqlite,spec.root,undefined,{processes:reader});
 const adapters=new Map(spec.adapters.map(([k,id])=>[k,store.get(id)])),sessions=new actual.CapabilitySessionRegistry(store,{assertInitialSelection:s=>assert(s.projectId==='p1'&&adapters.get(s.runner)?.contentHash===s.adapterBinding.hash),verifyExtraResource:r=>{const dir=store.directory(r);assert.equal(actual.digest(readFileSync(join(dir,'entry.cjs'))),r.contentHash);assert.equal(JSON.parse(readFileSync(join(dir,'.smartdd-owned.json'),'utf8')).storeId,store.storeId);assert.deepEqual(readdirSync(dir).sort(),['.smartdd-owned.json','entry.cjs']);}});
 const packageRegistry=new actual.PackageRegistry(store,'controlled-tool-fixture'),authorization=new actual.CurrentApplicationAuthorization(store,{packages:packageRegistry,retainedMetadata:hash=>packageRegistry.get(hash)});
 const createPlan=(recorded,hash,id)=>{const apps=authorization.selectedApps(recorded.projectId),bindings=authorization.bindings(recorded.projectId,apps.map(a=>a.appId)),selected={...recorded,packages:apps.map(a=>authorization.packageSelection(recorded.projectId,a.packageHash,bindings,[])),standardSkills:[]};return actual.createApplicationRunPlan({runId:id,snapshotHash:hash,snapshot:selected,applications:apps.map(a=>{const pack=packageRegistry.get(a.packageHash);return{packageHash:a.packageHash,manifest:pack.manifest,capabilities:actual.builtinApplicationModules.capabilityViews(pack.manifest)};}),skills:[],available:{mcp:true,cli:false}});};
 const runs=new actual.CapabilityRunRegistry(store,sessions,{processes:reader,assertCurrent:s=>assert(sqlite.prepare('SELECT 1 FROM projects WHERE id=? AND archived_at IS NULL').get(s.projectId)),revoke:()=>{},createPlan,currentAuthorization:c=>authorization.view(c)}),db=profileActual.drizzle(sqlite,{schema:profileActual.schema}),profileService=new profileActual.AiProfileService(db,new profileActual.SecretsStore(db,{isAvailable:()=>true,encrypt:s=>Buffer.from(s),decrypt:b=>b.toString()}));
 return{...spec,sqlite,reader,store,adapters,programmaticSessions:sessions,programmaticRuns:runs,packageRegistry,authorization,createPlan,profileService,handles:[],launches:[],consumers:[]};
}
