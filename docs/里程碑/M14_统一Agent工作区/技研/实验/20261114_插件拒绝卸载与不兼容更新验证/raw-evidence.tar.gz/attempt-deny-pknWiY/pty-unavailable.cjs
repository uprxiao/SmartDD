module.exports={spawn(){throw Error('PTY_NOT_IN_PROFILE_PROBE_SCOPE')}};
