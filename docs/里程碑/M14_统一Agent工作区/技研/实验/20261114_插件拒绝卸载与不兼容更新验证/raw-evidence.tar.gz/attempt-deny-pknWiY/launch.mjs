import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import actual from './candidate.cjs';
import {executionForLaunch} from './execution.mjs';
import {inspect} from './contract.mjs';
import {adopt,releasePreparation} from './delivery.mjs';
const owned=new WeakMap();
export function deferred(){let resolve,reject;const promise=new Promise((r,j)=>{resolve=r;reject=j;});promise.catch(()=>{});return{promise,resolve,reject};}
function cell(handle){const c=owned.get(handle);assert(c,'LAUNCH_HANDLE_INVALID');return c;}
function receipt(c){const row=c.store.sqlite.prepare('SELECT * FROM m14_delivery WHERE receipt_id=? AND token=? AND plan_hash=?').get(c.key.receiptId,c.key.token,c.key.planHash);assert(row,'RECEIPT_CHANGED');const value=inspect(c.store.sqlite,row);assert.equal(row.run_id,c.runId);assert.equal(row.owner_instance,c.ownerInstance);return{row,...value};}
function current(c){receipt(c);return executionForLaunch(c.fixture,c.executionHandle);}
export function createLaunch(f,executionHandle,{checkpoint=async()=>{},mark=()=>{}}={}){
 const verified=executionForLaunch(f,executionHandle),key={receiptId:verified.delivery.receiptId,token:verified.delivery.token,planHash:verified.plan.delivery.hash};actual.assertOwnedCapabilityRun(f.runs,f.run);const h=Object.freeze({id:randomUUID()}),c={fixture:f,executionHandle,store:f.store,runs:f.runs,run:f.run,runId:f.run.runId,ownerInstance:f.runs.instanceId,reader:f.reader,key:Object.freeze({...key}),checkpoint,mark,closed:false,started:false,attempted:false,payloadReleased:false,spawnCount:0,child:null,prepare:null,attach:null,dispose:null,cancel:null,attached:deferred(),exit:deferred()};receipt(c);owned.set(h,c);return h;
}
async function retire(c){return actual.withResourceLock(c.store.root,()=>c.store.sqlite.transaction(()=>{
 const {row,run}=receipt(c);assert(['stopped','failed'].includes(run.state)&&run.revocation_state==='revoked','RUN_NOT_DRAINED');
 assert(!c.store.sqlite.prepare("SELECT 1 FROM capability_run_processes WHERE run_id=? AND state NOT IN ('exited','canceled') UNION ALL SELECT 1 FROM capability_run_activities WHERE run_id=? AND state='active' UNION ALL SELECT 1 FROM capability_resource_leases WHERE owner_kind='run' AND owner_id=? AND state<>'released' LIMIT 1").get(c.runId,c.runId,c.runId),'RUN_NOT_DRAINED');
 if(['prepared','adopted'].includes(row.phase))c.store.sqlite.prepare("UPDATE m14_delivery SET phase='abandoned' WHERE receipt_id=?").run(row.receipt_id);
 return c.store.sqlite.prepare('SELECT phase FROM m14_delivery WHERE receipt_id=?').get(row.receipt_id).phase;
}).immediate());}
function spawnOwned(c,command,args,options={}){
 assert(!c.closed,'LAUNCH_CANCELED');assert(c.started&&!c.attempted,'LAUNCH_ALREADY_USED');const prepared=current(c);assert.equal(command,prepared.executable,'REQUESTED_EXECUTABLE_DIFFERS');assert.equal(JSON.stringify(options.env),JSON.stringify(c.environment),'FACTORY_ENV_CHANGED');
 c.attempted=true;c.mark('spawn-attempt');
 const child=spawn('/bin/sh',['-c','read -r _ <&3 || exit 73; exec 3<&-; exec "$@"','m14-gated',command,...args],{...options,stdio:['pipe','pipe','pipe','pipe']});c.child=child;c.spawnCount++;c.mark('wrapper-created',{pid:child.pid});
 child.stdin.on('error',()=>{});child.stdio[3].on('error',()=>{});
 child.once('error',e=>{c.mark('child-error',{code:e.code,pid:child.pid??null});c.exit.reject(e);});
 child.once('exit',(code,signal)=>{c.mark('owned-exit',{pid:child.pid,code,signal});c.run.cli.exited().then(()=>c.exit.resolve({pid:child.pid,code,signal}),e=>c.exit.reject(e));});
 c.attach=(async()=>{await c.checkpoint('after-spawn');if(c.closed)throw Error('LAUNCH_CANCELED');const identity=c.reader.read(child.pid);assert(identity,'IDENTITY_UNKNOWN');await c.run.cli.attach(child.pid,identity.startedAt);if(c.closed)throw Error('LAUNCH_CANCELED');current(c);child.stdio[3].end('ready\n');c.payloadReleased=true;c.mark('payload-released',{pid:child.pid});c.attached.resolve(identity);})().catch(e=>{c.attached.reject(e);child.stdio[3].destroy();if(child.exitCode===null&&child.signalCode===null)child.kill('SIGTERM');});
 return child;
}
export async function start(handle,factory){const c=cell(handle);assert(!c.closed,'LAUNCH_CANCELED');assert(!c.started,'LAUNCH_ALREADY_USED');c.started=true;
 c.prepare=(async()=>{await adopt(c.store,c.runs,c.run,c.key);await c.checkpoint('after-adopt');if(c.closed)throw Error('LAUNCH_CANCELED');await releasePreparation(c.store,c.runs,c.run,c.key);await c.run.cli.arm();await c.checkpoint('after-arm');if(c.closed)throw Error('LAUNCH_CANCELED');current(c);})();
 try{await c.prepare;if(c.closed)throw Error('LAUNCH_CANCELED');const verified=current(c);c.environment=Object.freeze({...c.fixture.baseEnv,...verified.resolved.env});const runtime=factory((cmd,args,opts)=>spawnOwned(c,cmd,args,opts),{executable:verified.executable,env:c.environment});c.dispose=runtime?.close?.bind(runtime);return{runtime,attached:c.attached.promise};}
 catch(e){await cancel(handle);throw e;}
}
export function cancel(handle){const c=cell(handle);c.closed=true;c.mark('gate-closed');if(c.cancel)return c.cancel;
 c.cancel=(async()=>{await c.prepare?.catch(()=>{});try{c.dispose?.();}catch(e){c.mark('dispose-error',{message:e.message});}
  if(!c.attempted){c.mark('unforked-proof');await c.run.cancelBeforeFork();c.attached.reject(Error('LAUNCH_CANCELED'));c.exit.resolve({unforked:true});}
  else{c.mark('stop-attempted');if(c.child){c.child.stdio[3].destroy();if(c.child.exitCode===null&&c.child.signalCode===null)c.child.kill('SIGTERM');}await c.run.stop('isolated-launch-cancel');await c.exit.promise;await c.attach;await c.run.stop('isolated-owned-exit');}
  const phase=await retire(c);c.mark('delivery-retired',{phase});return{phase,...state(handle)};
 })();c.cancel.catch(()=>{});return c.cancel;
}
export function state(handle){const c=cell(handle);return{closed:c.closed,attempted:c.attempted,spawnCount:c.spawnCount,payloadReleased:c.payloadReleased,runState:c.runs.get(c.runId).state};}
