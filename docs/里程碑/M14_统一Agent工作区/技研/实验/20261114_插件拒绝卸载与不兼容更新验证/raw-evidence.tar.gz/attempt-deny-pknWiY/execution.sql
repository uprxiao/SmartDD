CREATE UNIQUE INDEX m14_delivery_execution_key ON m14_delivery(receipt_id,run_id,plan_hash);
CREATE TABLE m14_execution_plan(
 run_id TEXT PRIMARY KEY REFERENCES capability_runs(run_id),
 receipt_id TEXT NOT NULL UNIQUE, receipt_hash TEXT NOT NULL,
 application_plan_hash TEXT NOT NULL, plan_json TEXT NOT NULL, plan_hash TEXT NOT NULL,
 FOREIGN KEY(receipt_id,run_id,receipt_hash) REFERENCES m14_delivery(receipt_id,run_id,plan_hash));
