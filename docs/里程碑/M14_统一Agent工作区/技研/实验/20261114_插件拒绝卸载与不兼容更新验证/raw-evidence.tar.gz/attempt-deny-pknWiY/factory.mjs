import {mkdirSync,appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {deferred} from './launch.mjs';
export function factory(out,f,driver,id,mark,inputDone){
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});
 if(driver==='claude')return(spawn,prepared)=>{
  const q=query({prompt:(async function*(){await inputDone.promise;})(),options:{pathToClaudeCodeExecutable:prepared.executable,cwd:f.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:prepared.env,mcpServers:{},spawnClaudeCodeProcess:o=>{mark('sdk-spawn-callback',{command:o.command});return spawn(o.command,o.args,{cwd:f.snapshot.native.cwd,env:prepared.env});}}});
  const consume=(async()=>{try{for await(const m of q)appendFileSync(out+'/'+id+'-native.jsonl',JSON.stringify(m)+'\n');return{finished:true};}catch(e){mark('sdk-consumer-ended',{message:e.message});return{error:e.message};}})();
  return{close:()=>q.close(),ready:()=>q.initializationResult(),consume};
 };
 return(spawn,prepared)=>{const child=spawn(prepared.executable,['app-server','--disable','plugins','-c','analytics.enabled=false','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url="http://127.0.0.1:1/v1",wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}'],{cwd:f.snapshot.native.cwd,env:prepared.env}),ready=deferred();
 createInterface({input:child.stdout}).on('line',line=>{appendFileSync(out+'/'+id+'-native.jsonl',line+'\n');try{const m=JSON.parse(line);if(m.id===1)m.error?ready.reject(Error(JSON.stringify(m.error))):ready.resolve(m.result);}catch(e){ready.reject(e);}});child.stderr.on('data',b=>appendFileSync(out+'/'+id+'-stderr.log',b));
 return{close:()=>child.stdin.end(),ready:()=>{child.stdin.write(JSON.stringify({id:1,method:'initialize',params:{clientInfo:{name:'m14_config_plan_probe',version:'1'},capabilities:{experimentalApi:true}}})+'\n');return ready.promise;},consume:Promise.resolve({noTurnStarted:true})};};
}