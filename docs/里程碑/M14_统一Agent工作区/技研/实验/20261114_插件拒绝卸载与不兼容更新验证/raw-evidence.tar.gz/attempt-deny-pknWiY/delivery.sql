CREATE UNIQUE INDEX m14_run_exact ON capability_runs(run_id,task_id,binding_id,capability_session_id,source_snapshot_hash,generation);
CREATE TABLE m14_delivery(
 receipt_id TEXT PRIMARY KEY,token TEXT NOT NULL UNIQUE,store_id TEXT NOT NULL,
 task_id TEXT NOT NULL,binding_id TEXT NOT NULL,cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL CHECK(typeof(generation)='integer' AND generation>0),
 plan_json TEXT NOT NULL,plan_hash TEXT NOT NULL,
 owner_pid INTEGER NOT NULL,owner_started_at TEXT NOT NULL,owner_instance TEXT NOT NULL,
 phase TEXT NOT NULL CHECK(phase IN ('prepared','adopted','released','abandoned')),run_lease_id TEXT REFERENCES capability_resource_leases(lease_id),
 CHECK(phase NOT IN ('adopted','released') OR run_lease_id IS NOT NULL),
 UNIQUE(run_id,generation),
 FOREIGN KEY(run_id,task_id,binding_id,cap_id,snapshot_hash,generation) REFERENCES capability_runs(run_id,task_id,binding_id,capability_session_id,source_snapshot_hash,generation),
 FOREIGN KEY(cap_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash));
CREATE TABLE m14_delivery_ref(receipt_id TEXT NOT NULL REFERENCES m14_delivery(receipt_id),resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id),kind TEXT NOT NULL,content_hash TEXT NOT NULL,relative_path TEXT NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),PRIMARY KEY(receipt_id,resource_id));
