export function memberRetention(store){
 const rows=store.sqlite.prepare("SELECT p.*,l.owner_kind,l.owner_id,l.host_instance_id,l.state AS lease_state FROM capability_lease_resources p JOIN capability_resource_leases l ON l.lease_id=p.lease_id WHERE l.state<>'released' ORDER BY p.lease_id,p.resource_id").all(),issues=[];
 for(const row of rows)try{const r=store.get(row.resource_id);if(r.state!=='ready'||r.integrity!=='valid'||r.contentHash!==row.content_hash||r.generation!==row.generation)throw Error('lease member identity');}catch{issues.push('lease-member-unresolved:'+row.lease_id+':'+row.resource_id);}
 return{refs:rows.map(r=>({ref_id:r.resource_id,cap_id:r.lease_id,snapshot_hash:r.content_hash})),issues,basis:rows};
}
