import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import actual from './candidate.cjs';
import {revision} from './revision.mjs';
import {reconcile as reconcileDelivery} from './delivery.mjs';
export const state=(f,id)=>f.sqlite.prepare('SELECT o.*,a.number,a.owner_instance,a.owner_pid,a.owner_started_at,a.state AS attempt_state,b.binding_id,b.task_id,b.runner,b.cwd,b.profile_id,b.profile_revision FROM m14_outbox o JOIN m14_attempt a ON a.id=o.attempt_id JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id JOIN m14_binding b ON b.binding_id=t.binding_id WHERE o.id=?').get(id);
function validTarget(f,row){const p=f.sqlite.prepare('SELECT * FROM ai_profiles WHERE id=?').get(row.target_profile_id);return !!p&&!p.command_pending&&revision(f.sqlite,row.target_profile_id)===row.target_revision;}
export function claimEffect(f,id){return f.sqlite.transaction(()=>{let row=state(f,id);assert(row);if(row.state!=='queued')return row;if(!validTarget(f,row)){f.sqlite.prepare("UPDATE m14_outbox SET state='blocked',reason='TARGET_CONFIGURATION_CHANGED' WHERE id=?").run(id);return state(f,id);}const owner=f.reader.read(process.pid);assert(owner,'OWNER_UNKNOWN');const token=randomUUID();f.sqlite.prepare("UPDATE m14_outbox SET state='claimed',claim=? WHERE id=? AND state='queued'").run(token,id);f.sqlite.prepare("UPDATE m14_attempt SET state='owned',owner_instance=?,owner_pid=?,owner_started_at=? WHERE id=? AND state='pending'").run(f.programmaticRuns.instanceId,owner.pid,owner.startedAt,row.attempt_id);return state(f,id);}).immediate();}
export async function recoverEffect(f,id,expectedAttempt,{reader=f.reader,checkpoint=()=>{}}={}){
 const original=state(f,id);assert(original);if(original.attempt_id!==expectedAttempt)return{status:'advanced',attemptId:original.attempt_id};
 if(['queued','blocked','unknown','stopped'].includes(original.state))return{status:original.state,attemptId:original.attempt_id};
 const owner=original.owner_pid&&original.owner_started_at?reader.state({pid:original.owner_pid,startedAt:original.owner_started_at}):'unknown';if(owner!=='stopped')return{status:'held',reason:'OWNER_'+owner};
 const actualRecovery=await f.programmaticRuns.recover();
 if(original.run_id){const receipt=f.sqlite.prepare('SELECT * FROM m14_delivery WHERE run_id=?').get(original.run_id);if(receipt)await reconcileDelivery(f.store,{receiptId:receipt.receipt_id,token:receipt.token,planHash:receipt.plan_hash},f.reader);}
 return actual.withResourceLock(f.store.root,()=>f.sqlite.transaction(()=>{
  const row=state(f,id);if(row.attempt_id!==expectedAttempt)return{status:'advanced',attemptId:row.attempt_id};if(['queued','blocked','unknown','stopped'].includes(row.state))return{status:row.state,attemptId:row.attempt_id};
  assert(row.claim===original.claim&&row.owner_instance===original.owner_instance&&row.owner_pid===original.owner_pid&&row.owner_started_at===original.owner_started_at,'RECOVERY_SCOPE_CHANGED');assert.equal(reader.state({pid:row.owner_pid,startedAt:row.owner_started_at}),'stopped','OWNER_CHANGED');
  const record=(decision,next)=>f.sqlite.prepare('INSERT INTO m14_attempt_recovery VALUES(?,?,?,?,?,?)').run(row.attempt_id,row.claim,decision,next,row.owner_pid,row.owner_started_at);
  let run;if(row.run_id){run=f.sqlite.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(row.run_id);assert(run.owner_instance_id===row.owner_instance&&run.owner_pid===row.owner_pid&&run.owner_started_at===row.owner_started_at,'RUN_OWNER_DIFFERS');
   const processes=f.sqlite.prepare('SELECT * FROM capability_run_processes WHERE run_id=?').all(row.run_id),activities=f.sqlite.prepare('SELECT 1 FROM capability_run_activities WHERE run_id=? LIMIT 1').get(row.run_id),unreleased=f.sqlite.prepare("SELECT 1 FROM capability_resource_leases WHERE owner_kind='run' AND owner_id=? AND state<>'released' LIMIT 1").get(row.run_id),receipt=f.sqlite.prepare('SELECT phase FROM m14_delivery WHERE run_id=?').get(row.run_id);
   const neverStarted=processes.some(p=>p.kind==='cli')&&processes.every(p=>p.state==='canceled'&&p.pid===null&&p.process_started_at===null)&&!activities;
   if(!['stopped','failed'].includes(run.state)||run.revocation_state!=='revoked'||unreleased||!neverStarted||receipt&&receipt.phase!=='abandoned'){
    record('unknown',null);f.sqlite.prepare("UPDATE m14_attempt SET state='unknown' WHERE id=?").run(row.attempt_id);f.sqlite.prepare("UPDATE m14_outbox SET state='unknown',reason='PRIOR_EXECUTION_NOT_PROVEN_UNSTARTED' WHERE id=?").run(id);return{status:'unknown',runState:run.state,actualRecovery};
   }
  }
  if(!validTarget(f,row)){record('blocked',null);f.sqlite.prepare("UPDATE m14_outbox SET state='blocked',reason='TARGET_CONFIGURATION_CHANGED' WHERE id=?").run(id);return{status:'blocked',actualRecovery};}
  if(!run){record('retry-publication',row.attempt_id);f.sqlite.prepare("UPDATE m14_attempt SET state='pending',owner_instance=NULL,owner_pid=NULL,owner_started_at=NULL WHERE id=?").run(row.attempt_id);f.sqlite.prepare("UPDATE m14_outbox SET state='queued',claim=NULL,reason=NULL WHERE id=?").run(id);return{status:'queued',attemptId:row.attempt_id,number:row.number,actualRecovery};}
  const next=randomUUID();f.sqlite.prepare("INSERT INTO m14_attempt(id,effect_id,number,target_profile_id,target_revision,state) VALUES(?,?,?,?,?,'pending')").run(next,id,row.number+1,row.target_profile_id,row.target_revision);checkpoint('after-next-attempt');
  record('retry-unforked',next);f.sqlite.prepare("UPDATE m14_attempt SET state='closed-unforked' WHERE id=?").run(row.attempt_id);f.sqlite.prepare("UPDATE m14_outbox SET state='queued',claim=NULL,reason=NULL,run_id=NULL,attempt_id=? WHERE id=?").run(next,id);return{status:'queued',attemptId:next,number:row.number+1,oldRunId:run.run_id,actualRecovery};
 }).immediate());
}
