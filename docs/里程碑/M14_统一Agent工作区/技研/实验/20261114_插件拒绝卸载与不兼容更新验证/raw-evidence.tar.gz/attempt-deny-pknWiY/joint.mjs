import {claimEffect} from './recovery.mjs';
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdirSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import actual from './candidate.cjs';
import profileActual from './profile.cjs';
import {migrate,revision} from './revision.mjs';
import {nativeRuntime,cleanProfileEnv,baseEnv} from './native-inputs.mjs';
import {prepareExecution} from './execution.mjs';
import {createLaunch,start,cancel} from './launch.mjs';
export function profiles(f){
 const db=profileActual.drizzle(f.sqlite,{schema:profileActual.schema});let clock=1;
 f.profileService=new profileActual.AiProfileService(db,new profileActual.SecretsStore(db,{isAvailable:()=>true,encrypt:s=>Buffer.from(s),decrypt:b=>b.toString()}),()=>clock++);f.profiles={};
 for(const driver of ['claude','codex']){const runtime=nativeRuntime(driver),p=f.profileService.create({name:'isolated '+driver,runner:driver,executable:runtime.path,env:cleanProfileEnv(driver),args:[],color:null,isDefault:false});f.profiles[driver]=p.id;}
 migrate(f.sqlite);f.sqlite.exec(readFileSync(new URL('./delivery.sql',import.meta.url),'utf8'));f.sqlite.exec(readFileSync(new URL('./execution.sql',import.meta.url),'utf8'));
 for(let i=0;i<2;i++){const driver=i===0?'claude':'codex',id=f.profiles[driver];f.sqlite.prepare('UPDATE m14_binding SET profile_id=?,profile_revision=? WHERE binding_id=?').run(id,revision(f.sqlite,id),f.scopes[i].bindingId);}
}
export function accept(f,parent,input,{checkpoint=()=>{}}={}){
 return f.sqlite.transaction(()=>{
  const context=f.programmaticRuns.assertActive(parent.runId),requestHash=actual.digest(actual.canonicalJson({profileId:input.profileId,revision:input.revision,cwd:input.cwd,prompt:input.prompt}));
  const old=f.sqlite.prepare('SELECT * FROM m14_receipt WHERE parent_task=? AND request_key=?').get(context.run.taskId,input.key);if(old){assert.equal(old.request_hash,requestHash,'REQUEST_CONFLICT');return JSON.parse(old.response);}
  const profile=f.profileService.get(input.profileId);assert(profile&&!f.sqlite.prepare('SELECT command_pending FROM ai_profiles WHERE id=?').get(input.profileId).command_pending&&revision(f.sqlite,input.profileId)===input.revision,'TARGET_CONFIGURATION_CHANGED');const runner=profileActual.builtinRunnerAdapters.get(profile.runner).describe().agentId;
  const childTaskId=randomUUID(),bindingId=randomUUID(),turnId=randomUUID(),delegationId=randomUUID(),effectId=randomUUID(),now=Date.now();
  f.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,runner,title,first_message,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').run(childTaskId,context.run.projectId,input.cwd,profile.id,profile.runner,'isolated child',input.prompt,now,now);
  f.sqlite.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,cwd,entry_mode,phase,profile_id,profile_revision) VALUES(?,?,?,?,'programmatic','planned',?,?)").run(bindingId,childTaskId,runner,input.cwd,profile.id,input.revision);
  f.sqlite.prepare("INSERT INTO m14_turn VALUES(?,?,?,?,'queued')").run(turnId,childTaskId,bindingId,input.prompt);
  f.sqlite.prepare("INSERT INTO m14_delegation VALUES(?,?,?,?,?,'accepted')").run(delegationId,context.run.taskId,parent.runId,childTaskId,turnId);
  f.sqlite.prepare("INSERT INTO m14_outbox(id,delegation_id,state,claim,reason,run_id,target_profile_id,target_revision) VALUES(?,?,'queued',NULL,NULL,NULL,?,?)").run(effectId,delegationId,profile.id,input.revision);
  f.sqlite.prepare("INSERT INTO m14_attempt(id,effect_id,number,target_profile_id,target_revision,state) VALUES(?,?,1,?,?,'pending')").run(effectId,effectId,profile.id,input.revision);f.sqlite.prepare('UPDATE m14_outbox SET attempt_id=? WHERE id=?').run(effectId,effectId);
  const response={childTaskId,bindingId,turnId,delegationId,effectId};f.sqlite.prepare('INSERT INTO m14_receipt VALUES(?,?,?,?,?,?)').run(context.run.taskId,parent.runId,input.key,requestHash,delegationId,actual.canonicalJson(response));checkpoint('before-accept-commit');return response;
 }).immediate();
}
export const effect=(f,id)=>f.sqlite.prepare('SELECT o.*,b.binding_id,b.task_id,b.runner,b.cwd,b.profile_id,b.profile_revision FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id JOIN m14_binding b ON b.binding_id=t.binding_id WHERE o.id=?').get(id);
export const claim=(f,id)=>claimEffect(f,id);
export function childSnapshot(f,row){const s=structuredClone(f.snapshots[row.runner==='codex'?1:0]),old=s.mcp[0].serverName,name='joint_'+row.binding_id.replaceAll('-','');s.taskId=row.task_id;s.native={sessionId:null,cwd:row.cwd,stateRoot:join(f.home,row.task_id,row.runner==='codex'?'.codex':'.claude')};s.mcp[0].serverName=name;for(const[k,v]of Object.entries(s.adapterBinding.nativeToolNames))s.adapterBinding.nativeToolNames[k]=v.replace(old,name);for(const p of s.packages)for(const skill of p.skills)skill.projectionPath=join(f.root,'programmatic',row.binding_id,'skills',skill.nativeName,'SKILL.md');return actual.capabilitySessionSnapshotV3Schema.parse(s);}
export async function prepareChild(f,id,{checkpoint=()=>{}}={}){
 const row=claim(f,id);assert(['claimed','reserved'].includes(row.state),'EFFECT_NOT_PREPARABLE');assert.equal(revision(f.sqlite,row.profile_id),row.target_revision,'TARGET_CONFIGURATION_CHANGED');
 const snapshot=childSnapshot(f,row),scope=await f.programmaticSessions.createProgrammatic(row.binding_id,snapshot,f.home);checkpoint('after-publication');
 const run=await f.programmaticRuns.reserveProgrammaticOnce(row.attempt_id,row.claim,{...scope,bindings:[]});if(!f.handles.includes(run))f.handles.push(run);checkpoint('after-reservation');
 if(f.programmaticRuns.get(run.runId).state==='preparing')await run.prepare();
 const driver=snapshot.runner==='codex'?'codex':'claude',child={...f,snapshot,scope,run,runs:f.programmaticRuns,profile:row.profile_id,adapter:f.adapters.get(snapshot.runner),runtime:nativeRuntime(driver)};child.baseEnv=baseEnv(child);
 const execution=await prepareExecution(child,child.runtime,{checkpoint:point=>checkpoint('execution:'+point)});checkpoint('after-execution');return{child,execution};
}
export function executor(f,factory,mark){const attempts=new Map();return{
 async start(id,prepared,{lostReply=false}={}){
  const row=effect(f,id);if(['initialized','stopped','unknown'].includes(row.state))return{status:row.state,runId:row.run_id};
  const prior=attempts.get(id);if(prior)return prior;
  assert(row.state==='reserved'&&row.run_id===prepared.child.run.runId,'DISPATCH_SCOPE_CHANGED');
  const launch=createLaunch(prepared.child,prepared.execution,{mark:(event,details)=>mark(id,event,details)});f.launches.push({id,launch});
  const changed=f.sqlite.prepare("UPDATE m14_outbox SET state='dispatching' WHERE id=? AND state='reserved' AND run_id=?").run(id,row.run_id);assert.equal(changed.changes,1,'DISPATCH_CONFLICT');
  const p=(async()=>{try{const value=await start(launch,factory(prepared.child,id));f.consumers.push(value.runtime);await value.attached;const info=await value.runtime.ready();f.sqlite.prepare("UPDATE m14_outbox SET state='initialized' WHERE id=? AND state='dispatching'").run(id);mark(id,'initialize-committed',{runId:row.run_id,info});if(lostReply)throw Error('INJECTED_INITIALIZE_ACK_LOSS');return{status:'initialized',runId:row.run_id};}catch(e){f.sqlite.prepare("UPDATE m14_outbox SET state='unknown',reason=? WHERE id=? AND state='dispatching'").run(e.message,id);throw e;}})();attempts.set(id,p);return p;
 },async stop(id){const item=f.launches.find(l=>l.id===id);assert(item);await cancel(item.launch);f.sqlite.prepare("UPDATE m14_outbox SET state='stopped' WHERE id=?").run(id);},lookup:id=>effect(f,id)
};}
