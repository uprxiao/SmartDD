import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD',file=root+'/mcp-bridge.cjs',sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const r=await build({entryPoints:[repo+'/src/main/core/applications/bridge-runtime.ts'],outfile:file,bundle:true,platform:'node',format:'cjs',target:'node22',metafile:true,nodePaths:[root+'/node_modules','/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules'],tsconfig:repo+'/tsconfig.node.json'});
const sources=Object.keys(r.metafile.inputs).filter(p=>!p.startsWith('<')).map(p=>{const path=p.startsWith('/')?p:process.cwd()+'/'+p;return{path,sha256:sha(path)};});writeFileSync(root+'/bridge-build.json',JSON.stringify({sources,outputs:[{file,sha256:sha(file)}]},null,2));console.log(JSON.stringify({bridgeSources:sources.length}));
