import assert from 'node:assert/strict';
import actual from './candidate.cjs';
import {bindNativeLocked,programmaticScopeSchema} from './programmatic.mjs';
export async function bindOwnedNative(f,input,native,options={}){
 const scope=programmaticScopeSchema.parse(input);
 return actual.withResourceLock(f.store.root,()=>f.sqlite.transaction(()=>{
  actual.assertOwnedCapabilityRun(f.runs,f.run);const context=f.runs.assertActive(f.run.runId),row=f.sqlite.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(f.run.runId);
  assert(row.execution_mode==='programmatic'&&row.task_id===scope.taskId&&row.binding_id===scope.bindingId&&row.capability_session_id===scope.capabilitySessionId&&row.source_snapshot_hash===scope.snapshotHash,'NATIVE_CALLBACK_RUN_SCOPE_CHANGED');
  assert(context.snapshot.runner===native.runner&&context.snapshot.native.cwd===native.cwd&&context.snapshot.native.stateRoot===native.stateRoot,'NATIVE_SCOPE_CHANGED');return bindNativeLocked(f.store,scope,native,options);
 }).immediate());
}
