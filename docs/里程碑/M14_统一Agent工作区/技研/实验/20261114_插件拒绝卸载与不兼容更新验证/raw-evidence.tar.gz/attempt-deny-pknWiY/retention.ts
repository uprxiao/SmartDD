import {historyRetention} from './history-retention';
import {memberRetention} from './member-retention';
import {inspect} from './contract.mjs';
export function programmaticRetention(store){
 const history=historyRetention(store),members=memberRetention(store),db=store.sqlite,issues=[...history.issues,...members.issues],refs=[...history.refs,...members.refs];
 const names=['m14_delivery','m14_delivery_ref'],present=names.filter(name=>db.prepare("SELECT 1 FROM sqlite_master WHERE name=? AND type='table'").get(name));
 if(present.length&&present.length!==2)issues.push('delivery-schema-incomplete');
 const deliveries=present.length===2?db.prepare("SELECT * FROM m14_delivery WHERE phase IN ('prepared','adopted') ORDER BY receipt_id").all():[],pins=present.length===2?db.prepare("SELECT p.* FROM m14_delivery_ref p JOIN m14_delivery d USING(receipt_id) WHERE d.phase IN ('prepared','adopted') ORDER BY receipt_id,resource_id").all():[];
 for(const row of deliveries)try{const {plan}=inspect(db,row);for(const p of plan.resources){const r=store.get(p.resourceId);if(r.state!=='ready'||r.integrity!=='valid'||r.contentHash!==p.contentHash||r.generation!==p.generation||r.relativePath!==p.relativePath||r.kind!==p.kind)throw Error('resource');}}catch{issues.push('delivery-unresolved:'+row.receipt_id);}
 for(const p of pins)refs.push({ref_id:p.resource_id,cap_id:p.receipt_id,snapshot_hash:p.content_hash});
 return{refs,issues,basis:{history:history.basis,members:members.basis,deliveries,pins,present}};
}
