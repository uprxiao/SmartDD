CREATE TABLE m14_profile_execution_revision(
 profile_id TEXT PRIMARY KEY,
 revision INTEGER NOT NULL CHECK(typeof(revision)='integer' AND revision>0),
 present INTEGER NOT NULL CHECK(present IN(0,1))
);
INSERT INTO m14_profile_execution_revision SELECT id,1,1 FROM ai_profiles;
CREATE TRIGGER m14_profile_revision_insert AFTER INSERT ON ai_profiles BEGIN
 INSERT INTO m14_profile_execution_revision VALUES(NEW.id,1,1)
 ON CONFLICT(profile_id) DO UPDATE SET revision=revision+1,present=1;
END;
CREATE TRIGGER m14_profile_revision_change AFTER UPDATE ON ai_profiles
WHEN OLD.runner IS NOT NEW.runner OR OLD.executable IS NOT NEW.executable OR OLD.env IS NOT NEW.env OR OLD.args IS NOT NEW.args OR OLD.command_pending IS NOT NEW.command_pending
BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE profile_id=NEW.id; END;
CREATE TRIGGER m14_profile_revision_delete AFTER DELETE ON ai_profiles BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1,present=0 WHERE profile_id=OLD.id;
END;
CREATE TRIGGER m14_secret_revision_insert AFTER INSERT ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND NEW.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name'));
END;
CREATE TRIGGER m14_secret_revision_change AFTER UPDATE ON app_secrets
WHEN OLD.key IS NOT NEW.key OR OLD.secret IS NOT NEW.secret
BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND (NEW.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name') OR OLD.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name')));
END;
CREATE TRIGGER m14_secret_revision_delete AFTER DELETE ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND OLD.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name'));
END;
