CREATE TABLE route(task_id TEXT PRIMARY KEY,binding_id TEXT NOT NULL,revision INTEGER NOT NULL,turn_busy INTEGER NOT NULL DEFAULT 0);
CREATE TABLE child_result(id TEXT PRIMARY KEY,parent_task TEXT NOT NULL,delegation_id TEXT NOT NULL UNIQUE,revision TEXT NOT NULL,body TEXT NOT NULL,observed INTEGER NOT NULL DEFAULT 0,ack_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE notice(result_id TEXT PRIMARY KEY REFERENCES child_result(id),state TEXT NOT NULL,token TEXT,binding_id TEXT,run_id TEXT,generation INTEGER,disposition TEXT);
CREATE TABLE result_observation(token TEXT PRIMARY KEY,result_id TEXT NOT NULL REFERENCES child_result(id),run_id TEXT NOT NULL,binding_id TEXT NOT NULL,generation INTEGER NOT NULL,revision TEXT NOT NULL,state TEXT NOT NULL);
CREATE TABLE route_event(seq INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,payload TEXT NOT NULL);
