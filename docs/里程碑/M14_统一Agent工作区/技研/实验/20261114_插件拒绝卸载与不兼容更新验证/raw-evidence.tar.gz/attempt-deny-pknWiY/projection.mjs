import assert from 'node:assert/strict';
import {addRevision,decode} from './migration.mjs';
import actual from './actual.cjs';
let fault;
export const setProjectionFault=value=>{fault=value;};
export function projectNativeBinding(store,taskId,previousHash,nextHash,next){
 const db=store.sqlite;if(!db.prepare("SELECT 1 FROM sqlite_master WHERE name='m14_binding'").get())return;
 assert(db.inTransaction,'NATIVE_BINDING_REQUIRES_TRANSACTION');
 const b=db.prepare("SELECT * FROM m14_binding WHERE legacy_task_id=? AND task_id=? AND entry_mode='legacy'").get(taskId,taskId);assert(b,'EXACT_LEGACY_BINDING_MISSING');
 const cap=db.prepare('SELECT * FROM m14_cap WHERE binding_id=? AND task_id=? AND current_hash=?').get(b.binding_id,taskId,previousHash);assert(cap,'EXACT_SOURCE_REVISION_MISSING');
 const row=db.prepare('SELECT * FROM m14_revision WHERE cap_id=? AND task_id=? AND binding_id=? AND snapshot_hash=?').get(cap.cap_id,taskId,b.binding_id,previousHash);assert(row,'REVISION_MISSING');const previous=decode(row);
 assert(previous.native.sessionId===null&&next.native.sessionId&&b.native_id===null,'FIRST_NATIVE_BIND_ONLY');
 assert.equal(actual.canonicalJson({...next,native:{...next.native,sessionId:null}}),actual.canonicalJson(previous),'ONLY_NATIVE_ID_MAY_CHANGE');assert.equal(actual.digest(actual.canonicalJson(next)),nextHash,'NEXT_HASH_MISMATCH');assert.equal(actual.selectionHash(next),row.selection_hash,'SELECTION_CHANGED');
 db.prepare('UPDATE m14_binding SET native_id=? WHERE binding_id=? AND native_id IS NULL').run(next.native.sessionId,b.binding_id);
 const refs=db.prepare('SELECT * FROM m14_ref WHERE cap_id=? AND snapshot_hash=?').all(cap.cap_id,previousHash);addRevision(db,b.binding_id,cap.cap_id,{task_id:taskId,snapshot_hash:nextHash,snapshot_json:actual.canonicalJson(next)},refs);
 if(fault==='after-revision')throw Error('injected-native-projection-failure');
 db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(nextHash,cap.cap_id);
}
