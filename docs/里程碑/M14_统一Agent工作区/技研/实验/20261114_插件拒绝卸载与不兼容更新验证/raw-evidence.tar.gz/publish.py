from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');stage=p/'publication';entries=json.loads((p/'manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for e in entries:
 rel=Path(e['path']);assert rel.is_relative_to('docs/里程碑/M14_统一Agent工作区') and '..' not in rel.parts
 f=repo/rel;assert (sha(f.read_bytes()) if f.exists() else None)==e['before'],str(f)
 assert sha((stage/rel).read_bytes())==e['after']
for e in entries:
 f=repo/e['path'];f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((stage/e['path']).read_bytes());assert sha(f.read_bytes())==e['after']
print(json.dumps({'published':len(entries),'productSourceChanges':0}))
