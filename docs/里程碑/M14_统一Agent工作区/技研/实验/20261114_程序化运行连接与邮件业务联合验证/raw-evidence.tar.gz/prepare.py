from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_程序化运行连接与邮件业务联合验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==2 and r['error'] is None
builds=[json.loads((root/n).read_text()) for n in ['actual-build.json','candidate-build.json']]
for b in builds:
 for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
patches=json.loads((root/'patches.json').read_text())
for e in patches:assert sha(Path(e['file']).read_bytes())==e['before'];assert sha(Path(e['variant']).read_bytes())==e['after']
prior=Path('/private/tmp/willyou-m14-default-mail-bridge-probe');resourceReview=json.loads((prior/'source-review.json').read_text())
for e in resourceReview['resources']:assert sha((repo/e['path']).read_bytes())==e['sha256'],e['path']
resourceFiles=[]
for p in sorted((root/'bundles').rglob('*')):
 if p.is_file():
  assert not p.is_symlink();rel=p.relative_to(root);assert sha(p.read_bytes())==sha((prior/rel).read_bytes());resourceFiles.append({'path':str(rel),'sha256':sha(p.read_bytes())})
audit=json.loads((root/'audit.json').read_text())
failures={
'attempt-QRUPTI':'清理阶段查询尚不存在的 generation 字段，覆盖最初错误；原始主因未捕获。零原生进程／提交，不能归因为已确认的 EPERM。',
'attempt-B555VN':'loopback listen EPERM，未启动原生进程。',
'attempt-6CivRj':'研究 reserveProgrammatic 将 bindingMode 误传严格 scope schema，Zod 拒绝；仅修补候选参数传递，产品未改。',
'attempt-eSdlJ8':'研究模型判读未剥离实际 Codex 工具输出的 Wall time／Output 前缀；本机模型服务 500 导致原生通用错误，不是供应商故障。',
'attempt-BPhlWk':'B01 已通过；close 只确认 CLI、未等待已认证桥退出，后继准入正确返回 RESOURCE_BUSY。改为逐 run 使用实际监督器并排空已拥有桥，不放宽准入。',
'attempt-lPKzDK':'已成功恢复同一 native ID；禁用再启用递增连接槽修订，旧发件身份确认不适用，现有服务返回 SENDER_IDENTITY_REQUIRED。研究驱动补齐新的模拟 UI 身份确认后重新验证，未改业务判据。'}
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'builds':builds,'patches':patches,'buildMetadataCorrection':'build.mjs 和历史 manifest 的 scope 文案从默认桥实验沿用，No product source variants 不是候选的准确描述。实际 bundle 为当前源码，candidate bundle 注入三个明确归档的研究变体；不是产品源码变更。以本项、patches 和输出 hash 为准。','resources':resourceFiles,'resourceReuse':'Exact distribution bytes from 4.102; source resource hashes rechecked. Existing original build provenance remains in that experiment.','native':{'version':'Codex 0.167.1','sha256':'ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b'},'actual':['Codex app-server and stdio MCP subprocesses','Kernel process/peer/ancestor checks','Current ApplicationService, contexts, sender identity, UI display receipt and grant services, mail draft/intent/execution','Run-bound preferences, current authorization and real default v2 bridge/result schemas'],'candidate':['Programmatic session/run/plan extensions and shared retained/native claims','Prepared programmatic binding and copied capability references'],'controlled':['Synthetic renderer sender and cipher; direct service review/authorize calls, not real UI clicks','Local synthetic model server; no supplier model or account','SMTP verification loopback fixture; controlled submit return, no actual mail transport DATA'],'limits':['Same provider/native thread only; not cross-provider mail continuation or host delegation','No native user-message authority/PTY-to-programmatic input migration','No full business writer admission, host crash, closing race, migration-copy restore, browser run-bound execution or other providers/versions/platforms','Only successful current candidate bundle outputs are retained at root; earlier attempt variants/scripts/build hashes retained, no claim every earlier compiled output is included'],'failures':failures,'audit':audit}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[p for p in root.iterdir() if p.is_file() and p.name not in ['manifest.json','raw-evidence.tar.gz','archive-manifest.json','publication-audit.json']]
for d in [root/'bundles',*sorted(root.glob('attempt-*'))]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
files=sorted(set(files));archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 程序化运行连接与邮件业务联合验证

日期：2026-11-14。D01／D04，承接 §4.102–105。最终 attempt-2XwvPm 的 B01／B02 两项通过。当前源码的程序化研究扩展与真实 Codex、默认 v2 私有 MCP、现有邮件业务服务已在同库串联；未修改产品代码，不计正式产品验收。

## 范围和基线

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`；实际服务 bundle 681 项输入，候选 684 项输入。候选使用当前 session／run／plan 的三个最小研究变体、共享原生身份 claim；默认分发字节精确复用 §4.102，并重新核对资源源码摘要。构建 manifest 的 scope 沿用旧文案，候选确有三个变体，以 source-review 的勘误和补丁摘要为准。

固定 Codex 0.167.1 启动两个实际 app-server，分别启动私有桥；宿主核验真实 PID／出生身份／祖先关系。使用实际 ApplicationService、当前授权、连接选用、草稿、意图、发件身份、展示回执、发送授权和执行服务。Prepared binding／来源引用为研究夹具；renderer／cipher 为替身，通过服务调用模拟审阅及批准，模型由回环服务生成。SMTP 仅用本机夹具核验连接，发送 submit 为受控返回，没有真实邮件 DATA 或供应商模型调用。

## 两项联合检查

| 检查 | 结果 |
| --- | --- |
| B01 本次绑定与当前选用分离 | 能力历史记录 Z；启动时捕获 A；运行中项目切为 B，原生 MCP 实际发送准备和执行仍使用 A。受控 submit 一次，原 intent 重放返回同一 execution 不重复提交。启动计划字节不变；停用后缓存工具调用返回 APP_NOT_ENABLED 并进入后续模型请求 |
| B02 明确后继运行 | 确认旧 CLI 与桥退出、run stopped 后启动 generation 2，真实 thread/resume 保留同 task／binding／native ID，捕获当前 B，走新草稿／intent／模拟 UI 审阅授权后从 B 受控提交一次。重新启用后的发件身份需要新确认，不能复用旧修订确认 |

最终共十次本机模型请求，协议账两个 initialize、一个 thread/start、一个 thread/resume、两个 turn/start。两 Codex 和两桥均重新核验内核状态 stopped；两 run stopped、39 份租约 released，完整性及外键检查通过。三次回环认证、两次受控 submit、零 DATA。

## 失败及修正

七次尝试全部保留，不能只取最终成功。最早 QRUPTI 被清理查询缺列覆盖了原错误，主因未知；随后 B555VN 明确为监听 EPERM。6CivRj 复现研究入口漏传 bindingMode，修正在临时变体。eSdlJ8 是本机模型判读不认识工具文本前缀；BPhlWk 是漏等桥退出导致准入正确拒绝；lPKzDK 是重新启用后漏做新修订的发件身份确认，实际业务正确拒绝。后两项修正调用时序和前置，没有放宽权限或改预期让旧批准生效。

审计七份库均通过完整性／外键检查，无活动 run 或未释放租约；所有已记录的六个 Codex 和六个桥身份重新核验 stopped。最早无主因的尝试只保留 state.sqlite，其余包含 final.sqlite。旧失败的脚本、变体和构建摘要保留，早期被覆盖的完整 bundle 不宣称已归档。

## 设计结论与未验项

程序化入口必须显式承接原 bindingMode／bindings；宿主捕获本次运行配置，Driver 不自行读取项目最新连接代替。固定连接不会冻结当前开关、连接有效性或业务批准。结束后重新运行可捕获新连接，历史、运行与项目当前选用分别保留。应用停用再启用可能改变连接槽修订，按现有规则重新确认。

原生进程 exit 不等于桥及所有业务活动均结束；本轮只联合验证已认证桥的排空，不能代替完整后代或独立邮件在途活动证明。继续复用既有业务服务，不让 SDK 自行绕过它们。

同 Provider 续聊已串联，但跨 Provider 邮件、委派、原生真人输入来源、完整业务结果准入、迁移复制恢复、异常宿主、浏览器 run-bound 和其他版本／平台仍未覆盖。真实 UI 与正式产品用例仍未执行；研究通过不增加宽口径问题的完整关闭数。

复现：使用固定依赖运行 patch.py、build.mjs、build.mjs --candidate、probe.mjs、audit.mjs；需要归档指定的 Codex 和 macOS 内核 helper，以及 §4.102 同摘要默认分发。仅启用隔离回环服务，不需要真实凭据。见[结果](result.json)、[来源与逐次审计](source-review.json)、[原始证据](raw-evidence.tar.gz)、[摘要清单](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
old='当前源码变体保留 binding_mode 等既有语义，但仅验证默认 current 分支；程序化 run-bound 配置、原生降级和完整业务准入继续待验。'
new='该批当前源码变体只验证默认 current 分支；后续程序化 run-bound 邮件联合证据见 §9.2.2，原生降级及完整业务准入仍待验。';assert old in t;t=t.replace(old,new,1)
needle='**独立业务活动不能从 run 状态推断。**';assert needle in t
add='''**历史配置、运行配置与项目当前选用分别保留。** [程序化运行连接与邮件联合实验](实验/20261114_程序化运行连接与邮件业务联合验证/README.md)已将当前源码研究变体、真实 Codex app-server、默认 v2 私有桥和现有邮件服务接到同一库：能力历史记录 Z，本次 run 捕获 A，项目改选 B 后旧 run 仍从 A 受控提交一次；明确结束并恢复同一 native thread 的新 generation 捕获 B。程序化入口显式传递 bindingMode 与 bindings，不能把它们误并入严格身份 scope，或悄悄回退到 current。宿主捕获配置并生成不可变启动计划，Driver 不用项目当前选用替代本次运行绑定。

固定连接并不冻结授权：当前应用停用仍拒绝已缓存工具；连接有效性、发件身份和每个新 intent 的批准继续由原服务核验。停用再启用递增连接槽修订，旧发件身份确认可能失效，新 run 按现有政策重新确认，不能从历史批准恢复执行权。该批审阅通过真实服务与模拟 renderer 调用，未验证实际 UI 或原生真人输入来源；同 Provider 邮件续聊不能外推跨 Provider／委派。退出时先核对 CLI 及已认证桥都已终止，再允许后继运行；真实 CLI exit 不能单独作为整个执行范围排空的证明。

'''
t=t.replace(needle,add+needle,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.106 ' not in t
add='''### 4.106 程序化运行连接、原生续聊与实际邮件业务联合

[两项联合检查](实验/20261114_程序化运行连接与邮件业务联合验证/README.md)把当前源码程序化变体／共享身份 claim、真实 Codex 0.167.1、默认 v2 私有桥和现有 ApplicationService 邮件链接到同库。历史 Z／run A／项目当前 B 分离；旧 run 仍使用 A，一次提交且重放不重复，停用即时拒绝。确认旧 CLI／桥排空后，generation 2 恢复同一 task／binding／native ID，捕获 B，取得新模拟 UI 批准后受控提交；重新启用须重新确认当前修订的发件身份。

最终两项通过，十次本机合成模型请求、两原生进程和两桥 stopped、两 run stopped、39 租约 released；三次回环认证、两受控 submit、零 DATA。保留六次前置／候选／驱动失败及一次最终成功，包括漏传 bindingMode、漏等桥退出和遗漏重新确认。七份库完整性／外键通过，已记录六 Codex／六桥均 stopped。实际业务服务和内核身份为真实实现，renderer、模型、提交及 prepared 来源仍为夹具。未验跨 Provider 邮件／委派、原生用户来源、完整结果准入、迁移复制／异常 owner、其他版本平台或正式 UI；不改变 Q 完整关闭数。T0.1 §9.2.2 合并保留原业务的配置／授权合同。

''';t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D04 '):
  c=l.split('|');c[2]=' §4.99–102／106 已补实际活动／邮件回执／上下文、真实 Codex＋默认 v2 桥到邮件服务；同任务同 Provider 后继 run 保留原生 ID 并捕获新连接，历史／run／当前选用与动态授权分离。下一步同 D01 联合跨 Provider／委派的业务对象范围、原生输入来源、提交后变化、结果修订与崩溃恢复；研究模拟 UI／提交不代替真人来源或实际界面。run stopped 不代表独立业务租约释放；既有插件／浏览器证据复用，浏览器 run-bound／清理覆盖与大库查询另验 ';lines[i]='|'.join(c)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.105，56','截至 §4.106，56',1);put(rel,t)
rel=base/'README.md';lines=(repo/rel).read_text().splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：程序化运行、真实 Codex、默认 v2 私有桥和现有邮件业务的两项联合检查通过；验证历史／运行／项目连接分离，以及同一原生会话的新运行采用新连接。见[实验记录](技研/实验/20261114_程序化运行连接与邮件业务联合验证/README.md)。模型／提交和 UI 来源仍为夹具，未发真实邮件、未改产品；统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04](技研/全局设计验证账.md#71-当前全局收口方式)联合迁移复制恢复、完整业务结果准入和原生用户来源，补跨 Provider／委派业务范围、closing／异常宿主、降级与资源保留。已取得的同 Provider 邮件证据不能外推其他业务、所有版本或完整迁移。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size,'actualSources':len(builds[0]['sources']),'candidateSources':len(builds[1]['sources'])}))
