import json,sys
from prior_host import Host
h=Host(sys.argv[1]);h.task('A');h.task('B')
for line in sys.stdin:
 try:
  q=json.loads(line);m=q['method'];a=q.get('args',[])
  if m=='burst':
   task,count=a
   for i in range(count):h.commit(task,{'kind':'advisory'},publish=False)
   h.commit(task,{'kind':'item','id':'terminal','rev':1,'state':'done','text':'durable terminal'},publish=False)
   out=h.watermark(task)
  elif m=='inspect':out={'outbox':h.db.execute('select count(*) from outbox').fetchone()[0],'integrity':h.db.execute('pragma integrity_check').fetchone()[0]}
  else:out=getattr(h,m)(*a)
  print(json.dumps({'id':q['id'],'value':out}),flush=True)
 except Exception as e:print(json.dumps({'id':q['id'],'error':str(e)}),flush=True)
h.db.close()
