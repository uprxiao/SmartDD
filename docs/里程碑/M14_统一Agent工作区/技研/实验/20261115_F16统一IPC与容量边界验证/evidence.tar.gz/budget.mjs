export const limits=Object.freeze({eventBytes:32768,pageBytes:262144,replayRows:128,historyRows:100,previewBytes:4096,cacheItems:2000,cacheBytes:8388608,taskCaches:4,noticeBytes:1024,readRangeBytes:131072});
export const size=x=>Buffer.byteLength(JSON.stringify(x));
export class Cache {
 constructor(){this.epoch=1;this.rows=new Map();this.tombstones=new Set();this.bytes=0;this.needsSnapshot=false;this.draft='keep';}
 merge(epoch,rows){if(epoch!==this.epoch||this.needsSnapshot)return false;const next=new Map(this.rows);const deleted=new Set(this.tombstones);for(const x of rows){if(x.deleted){next.delete(x.id);deleted.add(x.id)}else if(!deleted.has(x.id)){const old=next.get(x.id);if(!old||x.rev>old.rev)next.set(x.id,x);else if(x.rev===old.rev&&JSON.stringify(x)!==JSON.stringify(old))throw Error('conflicting revision')}}const bytes=size([...next.values()])+size([...deleted]);if(next.size+deleted.size>limits.cacheItems||bytes>limits.cacheBytes){this.epoch++;this.rows.clear();this.tombstones.clear();this.bytes=0;this.needsSnapshot=true;return false;}this.rows=next;this.tombstones=deleted;this.bytes=bytes;return true;}
 rebase(epoch,rows){if(epoch!==this.epoch)return false;this.needsSnapshot=false;return this.merge(epoch,rows);}
}
