import copy

import hashlib

import itertools

import json

from pathlib import Path

import sqlite3

import tempfile

import traceback

import uuid

class Conflict(Exception):
    pass

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()

class Host:
    def __init__(self, file):
        self.db = sqlite3.connect(file, isolation_level=None)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS meta(id TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, seq INTEGER NOT NULL, pruned INTEGER NOT NULL, projection TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS events(task TEXT, seq INTEGER, body TEXT NOT NULL, PRIMARY KEY(task,seq));
          CREATE TABLE IF NOT EXISTS drafts(task TEXT PRIMARY KEY, rev INTEGER NOT NULL, selection INTEGER NOT NULL, text TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS receipts(task TEXT, op TEXT, digest TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(task,op));
          CREATE TABLE IF NOT EXISTS outbox(task TEXT, op TEXT, text TEXT NOT NULL, selection INTEGER NOT NULL, PRIMARY KEY(task,op));
          CREATE TABLE IF NOT EXISTS creations(op TEXT PRIMARY KEY, digest TEXT NOT NULL, task TEXT NOT NULL);
        ''')
        if not self.db.execute('SELECT id FROM meta').fetchone():
            self.db.execute('INSERT INTO meta VALUES (?)', (str(uuid.uuid4()),))
        self.identity = self.db.execute('SELECT id FROM meta').fetchone()[0]
        self.listeners = []

    def task(self, task):
        self.db.execute('INSERT INTO tasks VALUES (?,0,0,?)', (task, json.dumps({'generation': 1, 'items': {}})))
        self.db.execute('INSERT INTO drafts VALUES (?,0,1,?)', (task, ''))

    def publish(self, task):
        notice = self.watermark(task)
        for callback in self.listeners:
            callback(copy.deepcopy(notice))

    def watermark(self, task):
        return {'database': self.identity, 'task': task, 'seq': self.db.execute('SELECT seq FROM tasks WHERE id=?', (task,)).fetchone()[0]}

    @staticmethod
    def reduce(projection, event):
        p = copy.deepcopy(projection)
        kind = event['kind']
        if kind == 'generation':
            p['generation'] = event['generation']
        elif kind == 'item':
            old = p['items'].get(event['id'])
            if old and (event['rev'] <= old['rev'] or old['state'] in ('done', 'deleted') and event['state'] == 'streaming'):
                raise Conflict('item revision or terminal regression')
            p['items'][event['id']] = {k: event[k] for k in ('rev', 'state', 'text')}
        elif kind != 'advisory':
            raise Conflict('unknown required event')
        return p

    def commit(self, task, event, generation=None, publish=True, fail=False):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            seq, raw = self.db.execute('SELECT seq,projection FROM tasks WHERE id=?', (task,)).fetchone()
            p = json.loads(raw)
            if generation is not None and generation != p['generation']:
                raise Conflict('stale runtime generation')
            p = self.reduce(p, event)
            seq += 1
            self.db.execute('UPDATE tasks SET seq=?,projection=? WHERE id=?', (seq, json.dumps(p), task))
            self.db.execute('INSERT INTO events VALUES (?,?,?)', (task, seq, json.dumps(event)))
            if fail:
                raise Conflict('injected pre-commit failure')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
        if publish:
            self.publish(task)
        return seq

    def snapshot(self, task, interleave=None):
        self.db.execute('BEGIN')
        try:
            seq = self.db.execute('SELECT seq FROM tasks WHERE id=?', (task,)).fetchone()[0]
            if interleave:
                interleave()
            p = self.db.execute('SELECT projection FROM tasks WHERE id=?', (task,)).fetchone()[0]
            self.db.execute('COMMIT')
            return {'database': self.identity, 'task': task, 'seq': seq, 'projection': json.loads(p)}
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def replay(self, task, database, after, through, limit=2):
        self.db.execute('BEGIN')
        try:
            high, pruned = self.db.execute('SELECT seq,pruned FROM tasks WHERE id=?', (task,)).fetchone()
            if database != self.identity or after < pruned or after > high or through > high:
                return {'snapshotRequired': True}
            rows = self.db.execute('SELECT seq,body FROM events WHERE task=? AND seq>? AND seq<=? ORDER BY seq LIMIT ?', (task, after, through, limit)).fetchall()
            return {'database': database, 'task': task, 'through': through, 'events': [{'seq': seq, 'body': json.loads(body)} for seq, body in rows]}
        finally:
            self.db.execute('COMMIT')

    def prune(self, task, through):
        self.db.execute('BEGIN IMMEDIATE')
        self.db.execute('DELETE FROM events WHERE task=? AND seq<=?', (task, through))
        self.db.execute('UPDATE tasks SET pruned=? WHERE id=?', (through, task))
        self.db.execute('COMMIT')

    def draft(self, task):
        rev, selection, text = self.db.execute('SELECT rev,selection,text FROM drafts WHERE task=?', (task,)).fetchone()
        return {'rev': rev, 'selection': selection, 'text': text}

    def command(self, task, op, kind, expected, text='', selection=None, fail=False):
        request = {'kind': kind, 'expected': expected, 'text': text, 'selection': selection}
        fingerprint = digest(request)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            prior = self.db.execute('SELECT digest,body FROM receipts WHERE task=? AND op=?', (task, op)).fetchone()
            if prior:
                if prior[0] != fingerprint:
                    raise Conflict('idempotency key reused with different request')
                self.db.execute('COMMIT')
                return json.loads(prior[1])
            before = self.draft(task)
            if before['rev'] != expected:
                raise Conflict('draft CAS')
            if kind in ('insert', 'send') and selection != before['selection']:
                raise Conflict('selection CAS')
            if kind == 'save':
                after_text = text
            elif kind == 'insert':
                after_text = before['text'] + text
            elif kind == 'send':
                if text != before['text']:
                    raise Conflict('send text is not saved draft')
                self.db.execute('INSERT INTO outbox VALUES (?,?,?,?)', (task, op, text, selection))
                after_text = ''
            else:
                raise Conflict('bad command')
            after = {**before, 'rev': expected + 1, 'text': after_text}
            self.db.execute('UPDATE drafts SET rev=?,text=? WHERE task=?', (after['rev'], after_text, task))
            receipt = {'task': task, 'op': op, **after}
            self.db.execute('INSERT INTO receipts VALUES (?,?,?,?)', (task, op, fingerprint, json.dumps(receipt)))
            if fail:
                raise Conflict('injected transaction failure')
            self.db.execute('COMMIT')
            return receipt
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def create_first(self, op, text):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            old = self.db.execute('SELECT digest,task FROM creations WHERE op=?', (op,)).fetchone()
            if old:
                if old[0] != digest(text):
                    raise Conflict('creation ID reused')
                task = old[1]
            else:
                task = str(uuid.uuid4())
                self.task(task)
                self.db.execute('INSERT INTO creations VALUES (?,?,?)', (op, digest(text), task))
                self.db.execute('INSERT INTO outbox VALUES (?,?,?,1)', (task, op, text))
            self.db.execute('COMMIT')
            return task
        except BaseException:
            self.db.execute('ROLLBACK')
            raise
