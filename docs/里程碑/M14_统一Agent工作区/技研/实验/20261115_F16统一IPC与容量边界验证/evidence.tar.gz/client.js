const api=window.electronAPI;
const bytes=x=>new TextEncoder().encode(JSON.stringify(x)).length;
const check=(v,m)=>{if(!v)throw Error(m)};
class Replica {
 constructor(){this.epoch=1;this.task='A';this.seq=0;this.database=null;this.items={};this.status='loading';this.edit=0;this.text='';this.pending=new Map();this.attempts=0;this.lastCheck=0;this.polling=false;this.historyEpoch=1;this.cache=new Map();this.tombstones=new Set();this.latestNotice=null;this.off=api.eventOn('f16:notice',n=>{this.latestNotice=n});}
 async rpc(method,args=[]){return api.invoke('f16:rpc',{method,args})}
 async snapshot(){const epoch=this.epoch,task=this.task;const s=await this.rpc('snapshot',[task]);if(epoch!==this.epoch)return;check(bytes(s)<=262144,'snapshot budget');this.database=s.database;this.seq=s.seq;this.items=s.projection.items;this.status='ready';this.attempts=0;this.lastError=null;this.historyEpoch++;this.cache.clear();this.tombstones.clear();}
 async sync(){const epoch=this.epoch,task=this.task;this.attempts++;try{const w=await this.rpc('watermark',[task]);if(epoch!==this.epoch)return;if(w.database!==this.database||this.seq>w.seq){await this.snapshot();return;}for(let batch=0;this.seq<w.seq;batch++){if(batch===8){await this.snapshot();return;}const p=await this.rpc('replay',[task,this.database,this.seq,w.seq,128]);if(epoch!==this.epoch)return;if(p.snapshotRequired){await this.snapshot();return;}this.apply(p);}this.status='ready';this.attempts=0;}catch(e){this.lastError=String(e);this.status=this.attempts>=3?'stalled':'recovering';}}
 apply(p){check(p.database===this.database&&p.task===this.task,'identity');check(bytes(p)<=262144&&p.events.length<=128,'page budget');let seq=this.seq;const items=structuredClone(this.items);for(const row of p.events){check(row.seq===seq+1,'sequence');check(bytes(row)<=32768,'event budget');check(['advisory','item'].includes(row.body.kind),'required event');if(row.body.kind==='item')items[row.body.id]=row.body;seq++;}this.items=items;this.seq=seq;}
 async tick(now,force=false){if(this.polling){if(now-this.lastCheck>=15000&&this.status!=='stalled'){this.epoch++;this.status='stalled'}return;}if(this.status==='stalled'||(!force&&now-this.lastCheck<5000))return;this.polling=true;this.lastCheck=now;try{await this.sync()}finally{this.polling=false}}
 resume(){if(this.polling)return false;this.attempts=0;this.status='recovering';return this.tick(0,true)}
 select(task){this.task=task;this.epoch++;this.seq=0;this.database=null;this.text='';this.edit++;}
 editText(t){this.text=t;this.edit++}
 async send(op,rev){const captured={epoch:this.epoch,edit:this.edit,task:this.task,text:this.text};const r=await this.rpc('command',[this.task,op,'send',rev,this.text,1]);this.pending.set(op,r);if(this.epoch===captured.epoch&&this.edit===captured.edit&&this.task===captured.task)this.text='';return r;}
}
window.f16={Replica,check,bytes};
