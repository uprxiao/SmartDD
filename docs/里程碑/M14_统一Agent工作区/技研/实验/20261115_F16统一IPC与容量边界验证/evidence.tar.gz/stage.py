from pathlib import Path
import hashlib,json,tarfile,re,shutil
r=Path(__file__).resolve().parent;b=Path('/Users/hx/projects/SmartDD/docs/里程碑/M14_统一Agent工作区');s=r/'publication';s.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,t):
 q=s/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(t)
e=s/'技研/实验/20261115_F16统一IPC与容量边界验证';e.mkdir(parents=True,exist_ok=True)
last=Path(json.loads((r/'latest.json').read_text())['attempt'])
for src,dest in [(r/'README-evidence.md','README.md'),(last/'result.json','result.json'),(r/'budget-result.json','budget-result.json'),(r/'source-audit.json','source-audit.json')]:shutil.copyfile(src,e/dest)
raw=[]
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if p.is_file() and not p.is_symlink() and 'publication' not in rel.parts and '__pycache__' not in rel.parts and not any(x in rel.parts for x in ['userData','sessionData']) and p.name not in ['evidence.tar.gz','publication-manifest.json']:
  assert not re.search(rb'\bsk-(?:ant-)?[A-Za-z0-9_-]{20,}\b',p.read_bytes()),str(rel)
  raw.append({'path':str(rel),'sha256':sha(p),'bytes':p.stat().st_size})
with tarfile.open(e/'evidence.tar.gz','w:gz') as tar:
 for x in raw:tar.add(r/x['path'],arcname=x['path'],recursive=False)
(e/'archive-manifest.json').write_text(json.dumps(raw,indent=2)+'\n')
p=Path('技研/技术方案.md');t=(b/p).read_text()
t=t.replace('实验已证明显式核对可修复丢尾，尚未验证实际 IPC 的丢失模式、心跳调度和恢复时限，参数需实测后定稿。','原同步实验已证明显式核对可修复丢尾；F16 的真实隔离 IPC 与固定恢复预算见 §4.5.1，墙钟调度及产品联调按 A44 验收。')
t=t.replace('尚未完成真实 IPC、完整 Schema、缓存限额或 DOM 滚动验证。','F16 按 §4.5.1 补证实际 IPC 交界与缓存限额；完整产品 Schema 接线和 DOM 滚动仍待 A44。')
t=t.replace('旧稿 50ms／32KiB 等数值仅为候选预算，须经实际 IPC 与打包 UI 测量后定稿，不能当已有性能证明。','50 ms／32 KiB 的初始合批政策及所有容量／恢复上限见 §4.5.1；协议边界已有隔离证据，不作为打包 UI 的性能测量。')
t=t.replace('预算按职责拆分，具体参数在支持矩阵与实际负载测量后冻结；实验的小预算和 T3 的默认值都不直接成为产品承诺。','预算按职责拆分，初始数值与超限处理固定在 §4.5.1；实际负载测试验证性能并可经明确修订调整，不能用实验小预算或 T3 默认值直接宣称产品性能。')
t=t.replace('Q45 仍为部分，A45 未执行。','F07／F10／F16 组合完成 Q45 研究关闭，A45 仍未执行。')
a=t.index('\n## 5.');t=t[:a]+'\n'+(r/'design-budget.md').read_text()+'\n'+t[a:]
t=t.replace('此实验尚未将草稿事务接入规范事件表，也未验证多窗口真实 IPC、来源权限和 SDK 消费，因此这些仍属于实施后的集成门槛。','该旧实验未接规范事件表；共同提交按 F01，真实隔离 IPC 的迟到回执／窗口销毁按 F16 补证。实际 TaskService、来源权限与 SDK 消费的产品整链仍属实施后集成门槛。')
a=t.index('### 10.3 ');z=t.index('## 11.',a);t=t[:a]+(r/'design-state.md').read_text()+t[z:]
t=t.replace('已经关闭的 F01–F15','已经关闭的 F01–F16').replace('剩余工作严格限定为冻结的 F16（输入与 IPC 同步状态／预算）。下一项 F16。已有最小断言与退出条件，复用当前有效证据；不再要求把所有 SDK、业务和界面先拼成临时产品来结束研究。','F01–F16 均达到冻结研究退出条件。剩余为既定全局关闭审计：逐项核对 R01–R12、Q01–Q56、现行合同、证据边界与 A 用例；审计完成前不宣称整个目标关闭，不新增冻结项，也不要求先拼成临时产品。')
write(p,t)
p=Path('技研/全局设计验证账.md');t=(b/p).read_text();a=t.index('## 5.',t.index('### 4.127'));t=t[:a]+'''### 4.128 F16 统一 IPC、恢复与容量边界（2026-11-15）

[F16 证据](实验/20261115_F16统一IPC与容量边界验证/README.md)包含真实 Electron 42.11.14 两个隐藏窗口、当前 preload 可执行逻辑与既有 SQLite／WAL 候选的九项检查，以及四项独立缓存／字节检查。末条通知被抑制仍可经水位补齐；2001 条增量只占一条在途通知和一个最新槽，有限补拉后快照恢复终态；旧 send 已提交后切任务／销毁旧窗口，迟到 ACK 不清新草稿。三次已结算失败暂停，挂起请求截止后不无限重试，字节裁页连续推进。

首败发现成功快照未清零连续失败计数，导致后续恢复提前暂停；保留失败源码／两批失败状态后修正，原断言通过。T0.1 §4.5.1 固定数值、超限、恢复和权限边界，§10.3 明确输入／审批／切换／恢复状态允许操作。时钟由夹具推进，不是实际延迟／RSS／DOM／产品 UI 证据；新业务整链和真实 IME／焦点按 A43／44／45／52 保留。

当前 preload 和引用 T3 源码核对；旧 SmartDD controller／store／控制服务变化单独列明，不重用旧整链通过。产品源码未变、正式验收仍0／54。按 §7.2 关闭 F16 及 Q43／44／45／52：56项＝研究关闭54＋部分0＋未验证0＋范围外2；冻结16项全部关闭。下一步仅既定全局一致性关闭审计。

'''+t[a:]
t=t.replace('**当前未全量通过，不能宣布设计已可全面开工。**','**冻结研究项已全部关闭，整体关闭审计待完成；不能据此宣布产品已实现或验收通过。**',1)
a=t.index('### 7.6 ');head=t[:a];current=t[a:];current=current.replace('§4.112–127','§4.112–128').replace('研究已关闭 50＋研究部分完成 4','研究已关闭 54＋研究部分完成 0').replace('Q52 的 UI 合同仍为部分','Q52 的 UI 合同研究已关闭').replace('F01–F15 的收口','F01–F16 的收口').replace('F14 新增关闭 Q47／49／50，剩余缺口逐行列明。','F16 新增关闭 Q43／44／45／52；冻结项无剩余，整体一致性关闭审计尚待完成。').replace('总数 16，已关闭 15（F01–F15）、处理中 0、待处理 1','总数 16，已关闭 16（F01–F16）、处理中 0、待处理 0').replace('剩余对应 4 个部分项','剩余部分项 0 个').replace('复核剩余 4 个部分 Q','复核全部 Q 的现行关闭依据')
lines=current.splitlines()
for i,l in enumerate(lines):
 if any(l.startswith('| '+q+' |') for q in ['Q43','Q44','Q45','Q52']):
  c=l.split('|');q=c[1].strip();c[2]=' 研究已关闭 ';c[3]=c[3].rstrip()+'／4.5.1／10.3 ';c[4]=c[4].rstrip()+'／128 ';c[5]={'Q43':' F16：真实IPC迟到ACK／窗口销毁不清新草稿，幂等回执复用；实际输入／来源整链按A43。 ','Q44':' F16：丢尾水位、裁剪快照、有限补拉／失败、挂起占槽与页预算有证；真实调度／UI按A44。 ','Q45':' F16：通知信用／UTF-8编码帧／缓存上限固定并有关键反例，输入与产物按F07／F10；SDK内存／实际负载按A45。 ','Q52':' F16：状态允许操作及组合限制定稿，IPC交界已证；真实原型、视觉、焦点、IME与滚动按A52。 '}[q];lines[i]='|'.join(c)
 if l.startswith('| F16 |'):
  c=l.split('|');c[4]=' §4.128补真实Electron IPC九项和缓存四项，初始数值／恢复及状态表定稿。 ';c[-2]=' 已关闭；§4.128／T0.1 §4.5.1／10.3；真实产品UI仍未验 ';lines[i]='|'.join(c)
current='\n'.join(lines)+'\n';a=current.index('执行依赖：');z=current.index('\n\n',a);current=current[:a]+'执行依赖：F01–F16 已按 §4.112–128 收口；共同关系 C1.9／公共命令 P1.2。冻结验证项全部关闭，不新增冻结项；接下来执行既定全局一致性与关闭审计，最终目标暂保持进行中。'+current[z:];write(p,head+current)
p=Path('README.md');t=(b/p).read_text();a=t.index('最新进展：');z=t.index('\n\n依赖状态',a);t=t[:a]+'''最新进展：[F16 统一 IPC 与容量边界](技研/实验/20261115_F16统一IPC与容量边界验证/README.md)研究关闭。实际 Electron IPC 九项、缓存／字节预算四项通过；已修正候选快照成功后的失败计数未清零问题，交互状态、容量及超限恢复写入 T0.1。产品源码与共享原型未改。

冻结清单总数16：已关闭16、处理中0、待处理0。Q总数56：研究关闭54、部分0、未验证0、延后范围2；产品验收仍0／54。剩余为既定全局一致性关闭审计，完成前整体目标保持进行中；权威统计见[冻结清单§7.6](技研/全局设计验证账.md#76-逐项研究关闭审计与冻结清单2026-11-14)。'''+t[z:];write(p,t)
p=Path('验收/测试用例.md');t=(b/p).read_text();adds={'A43':'按F16验证真实同窗口切任务、同任务发送后继续编辑、双窗口及销毁旧窗口的迟到回执；原operation查询／重试不重复派发，新草稿／焦点保持。','A44':'按T0.1 §4.5.1实际观察5秒核水位、15秒截止、3次已结算失败与8页补拉上限；丢尾、裁剪、隐藏窗口恢复、挂起占槽及成功快照清失败计数；不得以逻辑时钟替代实际成品调度。','A45':'逐层核对§4.5.1的编码帧、队列、通知、页、缓存及产物配额，分别触及条数／字节边界；artifact额度并发预留，超额／存储故障不丢终态或虚报完整；真实SDK、事件循环、RSS／磁盘与多任务公平性按声明平台测量，不将编码字节当物理内存。','A52':'按§10.3每一状态与叠加限制核对可见文案、允许操作及宿主拒绝，实际中文IME组合输入不误发，旧页锚点／尾部跟随和缓存重建可恢复；视觉与语音焦点仍需真实页面／系统证据。'}
for k,v in adds.items():
 a=t.index('### M14-'+k+' ');z=t.find('\n### ',a+1);z=len(t) if z<0 else z;section=t[a:z].replace('- 实际／状态／缺陷：','- 后续补充验证：'+v+'\n- 实际／状态／缺陷：',1);t=t[:a]+section+t[z:]
assert len(re.findall(r'^### M14-A\d+',t,re.M))==54;write(p,t)
manifest=[]
for p in sorted(s.rglob('*')):
 if p.is_file():x=p.relative_to(s);old=b/x;manifest.append({'path':str(x),'before':sha(old) if old.exists() else None,'after':sha(p)})
(r/'publication-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'files':len(manifest),'archiveEntries':len(raw),'archiveBytes':(e/'evidence.tar.gz').stat().st_size}))
