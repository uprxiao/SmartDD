from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;b=Path('/Users/hx/projects/SmartDD/docs/里程碑/M14_统一Agent工作区/技研/实验')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for d in ['20261114_历史分页与实时合并验证','20261114_长输出缓冲与存储故障验证']:
 x=json.loads((b/d/'sources.json').read_text());x=x if isinstance(x,list) else x['sources']
 for group in x:
  for entry in group['files']:
   p=Path(group['root'])/entry['path'];rows.append({'origin':d,'path':str(p),'before':entry['sha256'],'current':sha(p),'same':entry['sha256']==sha(p)})
for x in json.loads((r/'sources.json').read_text()):assert sha(Path(x['path']))==x['sha256']
x=json.loads((r/'latest.json').read_text());last=Path(x['attempt']);result=json.loads((last/'result.json').read_text());assert len(result['results'])==9 and all(v['passed'] for v in result['results']);assert result['workerExit']=={'code':0,'signal':None};assert result['integrity']['integrity']=='ok'
budget=json.loads((r/'budget-result.json').read_text());assert len(budget['results'])==4 and all(v['passed'] for v in budget['results'])
status={}
for name in ['SmartDD','t3code']:
 root=Path('/Users/hx/projects')/name
 status[name]={'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'productChanges':subprocess.check_output(['git','-C',str(root),'status','--short','--','src','native'] if name=='SmartDD' else ['git','-C',str(root),'status','--short'],text=True)}
 assert not status[name]['productChanges']
report={'sourceReview':rows,'currentSourcesVerified':True,'preload':'Current index.ts with imports/types erased only; same invoke/send/eventOn/expose behavior. Candidate main and renderer, not product IPC service.','result':{'ipc':9,'budget':4,'attempt':last.name},'repositories':status,'environment':'Electron 42.11.14 arm64; standalone hidden windows, isolated userData. Sandbox launch exited 134 before test; escalated isolated launch ran. No userData or credentials copied.','reuseBoundary':'Changed old product files do not invalidate independent protocol algorithms; their old product-integration claims are not reused. F09 and current preload supply current entry boundary. T3 sources used for algorithm reference checked individually.'}
(r/'source-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'ipcPassed':9,'budgetPassed':4,'changedReferences':[v['path'] for v in rows if not v['same']],'productChanges':status},ensure_ascii=False))
