const {contextBridge,ipcRenderer}=require('electron');


// Same generic bridge as Yoda: the typed RPC client and event emitter are built on top in the renderer.
const api = {
  invoke: (channel, ...args) => ipcRenderer.invoke(channel, ...args),
  eventSend: (channel, data) => ipcRenderer.send(channel, data),
  eventOn: (channel, cb) => {
    const wrapped = (_, data) => cb(data);
    ipcRenderer.on(channel, wrapped);
    return () => ipcRenderer.removeListener(channel, wrapped);
  },
};

contextBridge.exposeInMainWorld('electronAPI', api);
