from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_父Provider切换与结果路由验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and not r.get('error');a=Path(r['out']);sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s
 for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.ts','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[];exits=[]
for d in sorted(root.glob('attempt-*')):
 q=json.loads((d/'result.json').read_text());c=json.loads((d/'cleanup.json').read_text());assert all('error'not in x and x['state']['runState']=='stopped'for x in c['cleanup']);exits+=c['nativeExits'];attempts.append({'attempt':d.name,'passed':q['passed'],'error':q.get('error'),'nativeExits':c['nativeExits']})
assert len(exits)==7;final=json.loads((a/'cleanup.json').read_text())['nativeExits'];assert len(final)==3 and all(x['signal']is None for x in final);assert {x['id']:x['code']for x in final}=={'parent-A':0,'parent-B':143,'parent-A2':0};models=json.loads((a/'model.json').read_text());assert len(models)==1
f=json.loads((a/'fixture.json').read_text());db=sqlite3.connect('file:'+f['db']+'?mode=ro',uri=True);assert db.execute("select count(*) from capability_runs where state not in ('stopped','failed')").fetchone()[0]==0;assert db.execute("select count(*) from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;assert db.execute('select count(*),sum(ack_count),sum(observed)from child_result').fetchone()==(2,2,2);events=[{'type':t,'payload':json.loads(p)}for t,p in db.execute('select type,payload from route_event order by seq')];db.close()
runtime={'finalAttempt':a.name,'attempts':attempts,'totalNativeExits':len(exits),'finalNativeExits':final,'localModelRequests':1,'supplierModelCalls':0,'resultEvents':events,'scope':'Actual programmatic owner/private run and Codex/Claude initialization/drain. Real Codex busy turn with local response. Seeded child results and candidate host result service; no live result MCP/notice transport, no actual child execution, no user-facing switch.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/current-authorization.ts',t3/'apps/server/src/orchestration-v2/Orchestrator.ts'];review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'variants':'Prior scoped session/run/plan and retention source variants reused; product code unchanged. New result/route tables and service only in tmp.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.variant','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)]and c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 父 Provider 切换与结果路由：联合验证

2026-11-14；R03／04／05／06／12，Q14／19／24–28／54；技术方案 §7.2.2、验证账 §4.57。仅技术研究；产品、原型不变。

## 验证路径

沿用程序化 task／binding／run 候选以及实际 CapabilityRunRegistry 的私有句柄、活跃上下文和排空检查。同一逻辑父 task 先启动 Codex，再排空切 Claude，再排空切回 Codex 的下一 generation；三次都经过真实初始化。结果服务每次从实际私有 run 取得父归属，不信调用者传入的 task／binding；数据库中的 route 记录本次选中的父 binding。

子结果是预置的两个终态夹具，未运行真实子 Agent。notice 派发和显式停止通知是宿主候选命令，未发送真实 MCP／native 通知。父 busy 对照则使用真实 Codex turn/started、本机服务持有响应、turn/completed；投影仍是实验驱动更新，不是产品事件处理器。

## {a.name}：R01–R06

| 检查 | 结果 |
| --- | --- |
| R01 | 真实父 turn 忙时结果保持 pending，领取拒绝；终态后才可领取；父 run 仍 active 时不能切 Provider |
| R02 | 实际 Codex 排空后，未发送 claim 清除旧目标并回 pending，可切 Claude；旧 run／token 再派发被拒绝，两个结果和 delegation 身份不变 |
| R03 | 自动领取与主动完整读取并发进入同一协调事务；仅一个观察 token，旧自动 claim 失效；读取不标 observed，未确认时不再自动领取 |
| R04 | 复制 run 句柄、错误结果摘要拒绝；当前私有 run 用精确 token／revision 确认只记一次，重复返回原确认 |
| R05 | 候选 notice 已 sending，即使 Claude 实际停止，仍阻止切换；恢复为 unknown 也不放行，结果仍未观察 |
| R06 | 用明确的宿主夹具命令停止通知后，结果正文仍未读且保留；切回 Codex generation 2，旧 Claude token 被拒绝；新 run 显式读同一结果并确认 |

最后两个场景验证状态决策，不是 native 通知真实发送／丢失的证明；真实输入确认与崩溃窗口见 §4.56，不能把两个实验相加成完整联合链。停止通知不是接受证据，也不意味着子结果已被父 Agent 理解或任务已完成。

## 进程与补验

首轮 attempt-bnO9J8 六项通过，但 busy 为人工标记；随后增加真实忙碌回合。attempt-rOyZRe 在初始化前因驱动把 JSON 当作 TOML 参数传入 Codex 而退出 code 1，无模型请求；已保留 stderr，不计通过。修正驱动编码后最终六项通过。

三轮共七个捕获原生退出回执；最终 Codex A／A2 code 0、主动取消的 Claude code 143，全部 run stopped、租约 released。仅最终真实忙碌对照发生一次本机合成模型请求，无供应商请求、业务工具或模型费用。最终两个结果各确认一次。

## 设计结论与限制

pending、claimed-but-unsent、sending／unknown 必须分开。切换不改已完成结果的身份；未派发领取可以在原 run 排空并撤销 token 后重路由。已写派发意图不能凭停止推断未发送，必须先对账或由有权限的用户明确停止后续通知，且记录这个决定。

自动通知和主动观察共用结果账，但不能共用“完成”布尔值。读取完整结果只签发当前 run 的 offered token；确认包含 task／binding／run／generation、resultId／revision。UI 查看、自动通知接受、结果读取、观察确认及整个目标结束分别表示。

真实结果响应的序列化／socket 写入、MCP 回包、并发自动派发已越过发送边界、部分分页、子任务执行、模式切换和恢复时继续活着的旧 scope 尚未覆盖。显式确认仍是候选 API，不因为模拟控制流程成功就声明自主协作可靠。完整单任务 A→B→A 的历史上下文交接是另外的验证，本批只核结果路由和所有权。

## 证据

[结果](result.json)、[运行与失败审计](runtime-audit.json)、[源码基线](source-review.json)、[哈希清单](archive-manifest.json)、[驱动／变体／数据库](raw-evidence.tar.gz)。{len(files)} 文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(sources)} 个唯一构建输入复核。

复跑只在隔离 HOME、临时目录与本机模型服务执行，先 build.mjs／profile-build.mjs，再 probe.mjs；不对真实用户结果执行夹具停止通知命令。
''')
section='''#### 7.2.2 未派发结果重路由与观察竞争

[父 Provider 路由实验](实验/20261114_父Provider切换与结果路由验证/README.md)把同一逻辑父 task 的 Codex→Claude→Codex binding 切换接到实际程序化 owner／原生初始化与排空；真实 Codex 忙碌回合期间结果保持待领取，完成后才可继续。子结果和通知派发仍是候选夹具，未声称真实结果 MCP 全链通过。

| 原结果／投递状态 | 切换和观察约束 |
| --- | --- |
| pending | 原父运行排空后可随逻辑父任务新 route 领取，结果与 delegation 身份不变 |
| claimed、尚未进入发送意图 | 排空后撤销旧 claim token，再恢复 pending；旧 worker 必须被当前 run／route 核验拒绝 |
| sending／unknown | 不因原进程 stopped 就自动重路由；先依据原回执对账，或经明确权限入口停止后续通知并保留未观察结果 |
| offered、未确认 | 不当作已观察；阻止重复自动领取，原 token 只属于原 run／结果 revision；跨 run 重读走显式恢复协议 |
| observed | 保留原 observedByRun 和精确结果修订；同命令重试不再次确认，也不宣称新 run 已读 |

主动完整读取与自动领取使用同一协调／事务依据；在自动发送前，主动读可令旧 claim 失效。若自动发送已越过边界，按 unknown／接受证据处理，不能套用未发送撤销。候选已验证领取竞争、复制私有句柄拒绝、结果摘要核验、重复确认一次，以及新 generation 拒绝旧 Provider token；真实 socket 消费窗口和完整父子任务仍须联合验证。

停止通知与观察结果是不同操作。显式停止通知必须经可信用户权限入口，记录原状态、目标和原因，不改 observed；结果仍可由后续 run 明确读取。实验中的 fixture 命令只验证该状态区别，不代表用户已授权真实任务的通知处置，也不决定最终 UI 文案。

'''
def tech(t):
 assert '#### 7.2.2 'not in t;return t.replace('### 7.3 Skill 交付、更新与调用来源',section+'### 7.3 Skill 交付、更新与调用来源')
edit(base/'技研/技术方案.md',tech)
record='''### 4.57 父 Provider 切换、结果重路由与观察领取竞争

[结果路由实验](实验/20261114_父Provider切换与结果路由验证/README.md)R01–R06 将实际程序化私有 owner、同父 task 的 Codex→Claude→Codex 初始化／排空接到候选结果账。真实 Codex 忙碌回合时 pending 不领取，未派发 claim 在排空后撤销并重路由，旧 run token 拒绝；主动读取与自动领取共用观察账，精确 revision／token 确认一次；sending／unknown 不因父停止而放行切换，显式夹具停止通知不标已观察。

最终 attempt-6yqTNU 六项通过；此前人工 busy 基线通过，追加真实回合时一次驱动 TOML 编码错误保留后修正。三轮七个原生退出、一次本机合成模型请求。子结果预置，通知／处置为夹具，没有真实子执行、结果 MCP 或 native 通知消费，不能替代完整父子链。技术方案 §7.2.2 已补状态和迁移约束；产品／原型未改。

'''
def ledger(t):
 assert '### 4.57 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q14','Q19','Q24','Q25','Q26','Q27','Q28','Q54']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.57 补实际父 owner／Provider 切换与候选结果路由，真实通知消费仍待联合 |'
 t='\n'.join(lines)+'\n';t=t.replace('父忙排队／唤醒与主动观察竞争、子问题和取消迟到回应','父忙排队／唤醒与主动观察竞争（§4.57 已补真实忙碌回合及领取阶段，真实通知消费仍缺）、子问题和取消迟到回应');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补同一父 task 的 Codex→Claude→Codex 实际 owner／初始化／排空与候选结果路由，见[技术方案 §7.2.2](技研/技术方案.md)。真实父忙时保持 pending，未发送 claim 可撤销后重路由，sending／unknown 不借切换绕过；完整结果 MCP 尚未覆盖。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：集中收口结果通知／观察的真实传输窗口及输入、业务 run、父子状态的联合，避免重做已通过的初始化；按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续协议、业务 MCP、资源历史／GC、平台、性能与 UI 设计。当前仅研究，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
