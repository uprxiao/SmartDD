import assert from 'node:assert/strict';
import {createInterface} from 'node:readline';
import {appendFileSync,mkdirSync} from 'node:fs';
import {deferred} from './launch.mjs';
export function codex(out,f,id,mark){return(spawn,prepared)=>{
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});
 const child=spawn(prepared.executable,['app-server','--disable','plugins','-c','analytics.enabled=false','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url="http://127.0.0.1:1/v1",wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}'],{cwd:f.snapshot.native.cwd,env:prepared.env}),pending=new Map();let sequence=0;
 const rpc=(method,params)=>{const requestId=++sequence,d=deferred();pending.set(requestId,d);const frame={id:requestId,method,params};mark('native-request',{requestId,method});appendFileSync(out+'/'+id+'-requests.jsonl',JSON.stringify(frame)+'\n');child.stdin.write(JSON.stringify(frame)+'\n');return d.promise.then(result=>({requestId,result}));};
 createInterface({input:child.stdout}).on('line',line=>{appendFileSync(out+'/'+id+'-native.jsonl',line+'\n');try{const frame=JSON.parse(line);if(frame.id!==undefined){const d=pending.get(frame.id);assert(d,'UNMATCHED_NATIVE_REPLY');pending.delete(frame.id);if(frame.error)d.reject(Error(JSON.stringify(frame.error)));else d.resolve(frame.result);}}catch(e){for(const d of pending.values())d.reject(e);}});
 child.stderr.on('data',b=>appendFileSync(out+'/'+id+'-stderr.log',b));child.once('exit',()=>{for(const d of pending.values())d.reject(Error('OWNED_NATIVE_EXIT'));pending.clear();});
 return{close:()=>child.stdin.end(),ready:async()=>{const reply=await rpc('initialize',{clientInfo:{name:'m14_native_binding_probe',version:'1'},capabilities:{experimentalApi:true}});child.stdin.write('{"method":"initialized"}\n');assert(reply.result.userAgent.includes(f.runtime.nativeVersion));return reply.result;},rpc,consume:Promise.resolve({noModelTurn:true})};
};}
