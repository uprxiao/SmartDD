from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生输入ID重试语义验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for chunk in iter(lambda:f.read(262144),b''):h.update(chunk)
 return h.hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
codex=json.loads((root/'latest.json').read_text());claude=json.loads((root/'claude-latest.json').read_text());assert not codex.get('error')and not claude.get('error');ca=Path(codex['out']);cl=Path(claude['out']);c=json.loads((ca/'codex-result.json').read_text());cr=c['records'];assert len(cr)==2 and cr[0]['inputId']==cr[1]['inputId'];assert cr[0]['nativeAccepted']['turnId']!=cr[1]['nativeAccepted']['turnId'];assert cr[0]['nativeAccepted']['item']['id']!=cr[1]['nativeAccepted']['item']['id'];assert codex['checks'][0]['modelRequests']==2
assert claude['checks'][0]['modelRequests']==2 and claude['checks'][0]['duplicateResultCount']==1 and claude['checks'][0]['controlResultCount']==1
clrecords=json.loads((cl/'claude-result.json').read_text())['records'];assert len(clrecords)==3 and clrecords[0]['inputId']==clrecords[1]['inputId']!=clrecords[2]['inputId'];native=[json.loads(l)for l in(cl/'claude-native.jsonl').read_text().splitlines()];users=[x for x in native if x.get('type')=='user'];assert len(users)==2 and {x['uuid']for x in users}=={clrecords[0]['inputId'],clrecords[2]['inputId']}
assert (root/'native.mjs').read_bytes()==(ca/'native.mjs').read_bytes();assert (root/'claude-control.mjs').read_bytes()==(cl/'claude-control.mjs').read_bytes()
attempts=[];requests=0;processes=[]
for d in sorted(root.glob('attempt-*')):
 r=json.loads((d/'result.json').read_text());p=json.loads((d/'cleanup.json').read_text());assert all(x['exitCode']==0 and x['signal']is None for x in p);processes+=p;n=len((d/'model.jsonl').read_text().splitlines())if(d/'model.jsonl').exists()else 0;requests+=n;attempts.append({'attempt':d.name,'error':r.get('error'),'checks':r['checks'],'modelRequests':n,'exits':p})
assert len(processes)==3 and requests==5
runtime={'codex':codex,'claude':claude,'attempts':attempts,'totalLocalModelRequests':requests,'realNativeProcesses':len(processes),'supplierModelCalls':0,'scope':'Native sequential duplicate-ID diagnostic with local synthetic text responses. No business tools, no host crash, no cross-host replay, no proof of vendor exactly-once guarantees.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
pkg=Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules');sourcePaths=[pkg/'@anthropic-ai/claude-agent-sdk/sdk.mjs',pkg/'@anthropic-ai/claude-agent-sdk/package.json',pkg/'@anthropic-ai/claude-agent-sdk-darwin-arm64/claude',pkg/'@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts'];sources=[{'path':str(p),'sha256':filehash(p)}for p in sourcePaths]
assert sources[2]['sha256']=='abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c';assert sources[3]['sha256']=='ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'versions':{'claudeSdk':'0.3.321','claudeNative':'2.1.321','codex':'0.167.1'},'sources':sources,'t3Scope':'Only Claude echoed prompt IDs and command_lifecycle parsing inspected; not a claim that T3 has the same retry policy.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.json','.jsonl','.py','.log','.stderr']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':filehash(p)}for p in sorted(files)],'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生输入 ID 不等于统一幂等合同

2026-11-14；R03／04／05／06／12，Q14–18／24–28／54–55；技术方案 §6.1、验证账 §4.55。仅独立原生协议实验，没有产品修改、业务工具或真实供应商请求。

## 实验与发现

固定 Claude SDK 0.3.321／native 2.1.321、Codex 0.167.1，隔离 HOME 与状态目录。本机 HTTP 服务返回固定文本 SSE，不让模型执行操作。发送完全相同文字与相同 UUID／clientUserMessageId，明确作为故障研究，不采用自动重试策略。

| 执行器 | 结果 |
| --- | --- |
| Codex，{ca.name} | 同一 thread 顺序两次 turn/start，clientUserMessageId 相同；两次原生 turnId、itemId 不同，均完成，模型服务收到两次请求。相同 clientId 不是这一路径的执行去重键 |
| Claude 初轮，attempt-kofNNM | 第一条结果完成后重送相同 UUID；观察到一次模型请求、无第二份 result，观察截止后正常关闭进程。截止不是第二条已失败／永不执行的证明 |
| Claude 对照，{cl.name} | 同一会话依次输入原 UUID、重复 UUID、新 UUID。原输入与新 UUID 各有一个 result；总两次模型请求，原生文件只有两个相应 user UUID，通道仍能处理新输入。本轮重复 UUID 没有形成独立结果 |

不将 Claude 的这次表现提升成所有版本、进程重启、未完成输入或队列合并情况下的 exactly-once 保证。该对照也不证明重复输入会重放旧 ACK。确认丢失时盲目重发可能在 Codex 造成重复执行，在 Claude 无法得到预期的新结果，两者都不能由统一层假定成功。

首次 attempt-l0neDl 在监听 127.0.0.1 时被沙箱 EPERM 拒绝，尚无 native 进程或模型请求；取得隔离监听权限后才运行。三次真正原生实验共三个捕获进程，均 code 0；本机模型请求总五次，HTTP 服务均按 finally 关闭。Claude 初轮超时记录保留，没有改标成通过。

## 对统一任务、切换与协作的约束

宿主 commandId／inputId 的幂等、原生输入关联、原生执行去重是三件事。宿主重复命令应读取同一持久回执；原生 clientId／UUID 只按该 driver 已验证语义使用，不能据此重新发起一次执行。原生关联键必须包含 binding／run generation、session／thread，以及可用的 turn／item，而不能只按 clientId 匹配最后一条。

发送前持久记录固定目标、内容摘要、来源和派发尝试。确认丢失、发送中进程退出或接受落库失败保持 unknown；不自动改派其他 Provider、新建 thread、重新注入历史或重送子任务结果。只有能证明未发送／未消费的分支才按原固定请求安全重试；有真实原生证据时另作对账，不把历史回显重新签发为真人 live 来源。

统一 UI 应区分“宿主已接收”“已派发／待确认”“原生接受”“终态”，unknown 有解释和恢复入口；不能显示可无限点击的“重新发送”并暗示无副作用。用户明确选择再次执行时是新的尝试，并显示可能已有执行的事实。这是设计要求，本轮没有实现页面。

T3 当前 Claude adapter 分别读取 prompt echoed UUID 与 command_lifecycle，并按 prompt／steer 身份路由 result；可参考其关联处理。本批没有核验 T3 的完整重发恢复策略，不能据此宣称它已实现这里的持久对账方案。

尚未覆盖真实宿主崩溃、跨进程 resume 后重复、正在执行时的重复／合并、历史注入确认丢失、子结果自动投递与业务副作用。下一步应将这些原生事实用于现有持久账本的恢复验证，不重复跑正常初始化。

## 证据

[运行及三次原生记录审计](runtime-audit.json)、[版本与源码摘要](source-review.json)、[文件哈希](archive-manifest.json)、[驱动、原生线帧与隔离历史](raw-evidence.tar.gz)。{len(files)} 归档文件。native.mjs 对应 Codex 完成实验，claude-control.mjs 对应三输入对照，初轮脚本在各 attempt 中冻结。较早脚本结果的通用 scope 文案没有描述后加新 UUID 对照，具体覆盖以本说明、sent.jsonl 和实际线帧为准。

仅在新临时目录、隔离 HOME 中复跑，需要本机 loopback 监听权限及对应原生依赖；不要对真实用户输入或业务任务使用重复发送诊断。
''')
def tech(t):
 anchor='| 原生文件关联 | Claude 保留 UUID；'
 assert anchor in t;t=t.replace(anchor,'| 原生文件关联 | Claude 保留 UUID；',1)
 marker='上述是目标合同；候选 RAM 来源账与临时 reader overlay 只验证了局部运行行为，正式类型、Schema、持久化和真实入口尚需实施。'
 addition='''[重复原生输入 ID 实验](实验/20261114_原生输入ID重试语义验证/README.md)明确区分三个合同：宿主 commandId／inputId 去重、原生输入关联、执行器内部执行去重。Codex 0.167.1 同 thread 两次相同 clientUserMessageId／同文的 turn/start 产生不同 turnId、itemId 和两次模型请求；不能将 clientId 当 exactly-once 键。Claude 固定版本对照中，原 UUID 和新 UUID 各完成一次，重复 UUID 没有独立 result；这不保证跨进程恢复、队列或所有版本都同样处理，更不保证重放原 ACK。

宿主相同命令返回原持久回执，不因此再次调用 driver。unknown 不靠同 ID 重发、换 Provider 或新建 thread 探测；原生证据关联要包含原 binding／generation／session／turn／item，缺少唯一依据时保持未核对。明确再次执行需形成独立尝试，保留先前可能已执行的事实；上下文交接、委派 prompt 和回父结果都遵守同一边界。统一 UI 的“已接受／派发中／原生确认／结果未知／终态”分别显示，不能用自动重试掩盖未知。

'''+marker
 assert marker in t;return t.replace(marker,addition)
edit(base/'技研/技术方案.md',tech)
section='''### 4.55 原生输入标识与执行去重差异

[原生重试实验](实验/20261114_原生输入ID重试语义验证/README.md)证明 Codex 0.167.1 相同 thread／clientUserMessageId／同文再次 turn/start 会生成第二个 turn／item 并再次请求模型。Claude 固定版本初轮重复 UUID 未出现第二结果，观察截止后正常退出；新 UUID 对照仍正常完成，重复 UUID 本轮没有独立 result。后者不能宣称为跨进程 exactly-once 或 ACK 重放保证。

因此宿主幂等、原生关联、执行去重分别定义；unknown 保留原目标／尝试，不能借重发或切换 Provider 自动消除。技术方案 §6.1 已同步。三次实际实验共三原生进程 code 0、五次本机合成模型请求；另有一次监听权限预检失败。没有真实业务或供应商请求。跨宿主／队列与结果投递恢复仍需接入这些事实验证。

'''
def ledger(t):
 assert '### 4.55 'not in t;t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q14','Q15','Q16','Q17','Q18','Q24','Q25','Q26','Q27','Q28','Q54','Q55']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.55 补原生同 ID 重发差异，clientId 非统一执行去重保证，跨宿主仍待联合 |'
 return '\n'.join(lines)+'\n'
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补受管 native／业务 run 联合，并验证两端重复输入 ID 的行为差异，见[技术方案 §6.1](技研/技术方案.md)。Codex 相同 clientId 会产生第二个 turn；Claude 本次重复 UUID 没有独立结果，不能统一承诺自动重发安全。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：用这些原生事实核验持久输入账及父子结果的跨宿主恢复，优先收口 Provider 切换与多 Agent 协作的核心异常；按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)保留协议、业务 MCP、资源历史／GC、平台、性能和 UI 状态设计。仅技术研究，不开始产品或原型开发。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'nativeProcesses':len(processes),'localModelRequests':requests}))
