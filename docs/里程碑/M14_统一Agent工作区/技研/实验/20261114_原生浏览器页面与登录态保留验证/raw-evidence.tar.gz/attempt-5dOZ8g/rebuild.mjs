import{rebuild}from'/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules/@electron/rebuild/lib/rebuild.js';
await rebuild({buildPath:import.meta.dirname+'/electron-deps',electronVersion:'42.11.14',arch:'arm64',onlyModules:['better-sqlite3'],force:true,cachePath:import.meta.dirname+'/rebuild-cache'});console.log('isolated Electron SQLite ready');
