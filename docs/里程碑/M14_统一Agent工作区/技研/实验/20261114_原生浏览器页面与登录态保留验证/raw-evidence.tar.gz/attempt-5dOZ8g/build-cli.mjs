import{buildApplicationCli}from'/Users/hx/projects/SmartDD/scripts/applications/build.mjs';
console.log(buildApplicationCli({output:import.meta.dirname+'/willyou-app'}));
