from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent; repo=Path('/Users/hx/projects/SmartDD'); t3=Path('/Users/hx/projects/t3code'); base=Path('docs/里程碑/M14_统一Agent工作区'); stage=root/'publication'; exp=base/'技研/实验/20261114_原生浏览器页面与登录态保留验证'; entries=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
assert not any('electron-stub' in p for p in json.loads((root/'build.json').read_text())['sources'] for p in [p['path']])
preload=json.loads((root/'preload-build.json').read_text());assert sha(Path(preload['source']).read_bytes())==preload['sourceSha256'];assert sha(Path(preload['output']).read_bytes())==preload['sha256']
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and not r.get('error');a=Path(r['out']);attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());events=json.loads((attempt/'events.json').read_text());exits=[x for x in events if x['event']=='owned-exit'];expected=2 if result['passed']==0 else 3;assert len(exits)==expected and all(x['code']==(0 if x['id'].startswith('codex')else 143)for x in exits)
 db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM capability_run_activities WHERE state='active'"]:assert db.execute(query).fetchone()==(0,)
 inv=db.execute('SELECT state,effect_state,error_code,count(*) FROM application_invocations GROUP BY 1,2,3').fetchall();db.close()
 models=json.loads((attempt/'models.json').read_text());proofs=json.loads((attempt/'proofs.json').read_text())
 if result['passed']:
  assert len(models)==15 and len(proofs)==25;assert sorted(inv)==[('failed','read-only','SCOPE_DENIED',3),('succeeded','completed',None,3),('succeeded','read-only',None,6)]
 attempts.append({'attempt':attempt.name,'passed':result['passed'],'error':result.get('error'),'nativeExits':exits,'modelRequests':len(models),'kernelProofs':len(proofs),'allNativeAndBusinessSettled':True})
assert len(attempts)==3
for n in ['initial-pages.json','pages-after-parent-stop.json','pages-after-all-native-stop.json']:
 rows=json.loads((a/n).read_text());assert len(rows)==2 and all(x['live']and x['domPreserved']and x['cookieRoundTrip']for x in rows)
initial=json.loads((a/'initial-pages.json').read_text());assert initial[0]['profileId']==initial[1]['profileId']
for n in ['pages-after-parent-stop.json','pages-after-all-native-stop.json']:assert json.loads((a/n).read_text())==initial
assert json.loads((a/'page-before-new-provider.json').read_text())==initial[0]
assert json.loads((a/'sibling-after-explicit-close.json').read_text())==initial[1]
closed=json.loads((a/'close-return.json').read_text());assert closed=={'destroyedAtReturn':False,'registryRemoved':True}
disposed=json.loads((a/'pages-after-service-dispose.json').read_text());assert len(disposed)==2 and all(x['destroyed']for x in disposed)
web=json.loads((a/'local-web-requests.json').read_text());assert web[0]['logged']==False and all(x['logged']for x in web if x['path'].startswith('/account'))
for x in json.loads((a/'models.json').read_text()):
 if x['count'] not in (2,5):continue
 b=x['body'];latest=([y for y in b.get('input',[])if y.get('type')=='function_call_output']if x['driver']=='codex'else[y for msg in b['messages']if isinstance(msg['content'],list)for y in msg['content']if y.get('type')=='tool_result'])[-1];own=initial[1]if x['id']=='claude-1'else initial[0];other=initial[0]if x['id']=='claude-1'else initial[1];assert (own if x['count']==2 else other)['pageId']in json.dumps(latest)
cli=json.loads((a/'cli-binary.json').read_text());assert sha((root/'willyou-app').read_bytes())==cli['sha256'];assert sha((repo/'native/applications/cli.mm').read_bytes())==cli['sourceSha256'];(root/'cli-source.mm').write_bytes((repo/'native/applications/cli.mm').read_bytes())
runtime={'finalAttempt':a.name,'attempts':attempts,'electron':json.loads((a/'electron-runtime.json').read_text()),'preload':preload,'cli':cli,'pages':initial,'closeReturn':closed,'disposeReturn':json.loads((a/'dispose-return.json').read_text()),'destroyedEventsObserved':disposed,'localHttpRequests':len(web),'accountRequestsWithCookie':sum(x['path'].startswith('/account')and x['logged']for x in web),'scope':r['scope'],'unsupported':['External website/account authentication','App restart persistence','Cross-project login isolation','Actual renderer approval or unified UI','agent-browser helper operations/download/input','Full product migration']}
(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/browser'/n for n in ['page-registry.ts','workspace.ts','profiles.ts','service.ts','javascript-dialogs.ts','__tests__/registry-shutdown.test.ts'] if (repo/'src/main/core/browser'/n).exists()]+[repo/'src/preload/browser-prompt.ts',repo/'src/main/core/applications/modules/browser/index.ts',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'variants':['Programmatic owner/run/session candidates and awaited activity drain reused; no product changes.','Actual Electron external module: no Electron stub in bundle graph. Legacy unused electron-stub.cjs excluded from evidence archive.','Browser definitions/assets rebound to research runtime hash, not original shipped package.','Native protocols use fixed local model output; Codex private danger-full-access and Claude allowedTools Bash do not prove OS sandbox.','Real browser-prompt preload built unchanged; isolated SQLite rebuilt for Electron ABI146.','BrowserPageRegistry.closePage calls WebContents.close then removes entry without awaiting destroyed; existing registry unit fake emits destroyed synchronously.','Research observers await destroyed events outside the unmodified BrowserService, without polling or changing product close semantics.'],'t3Boundary':'T3 runtime/session scoping is a reference. Browser page ownership, partitions and CLI authorization are existing SmartDD business rules retained by the candidate, not T3 features copied into WillYou.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
(root/'startup-notes.md').write_text('''# 实验准备失败记录

初始 Electron 入口顶层 await app.whenReady 未进入实验，执行会话 90702 通过自身 Ctrl-C 结束（130）；原入口保留 main-initial.mjs。一次入口编辑语法错误仍被误启动（89389），Electron 报启动异常，通过自身 Ctrl-C 结束（130）；未创建业务 fixture。随后改为非阻塞 whenReady.then 并先过 node --check。

attempt-5dOZ8g：真实浏览器防护拒绝缺失的 JS 对话框 preload，检查未开始；两端 native 最终退出。随后编译当前真实 browser-prompt.ts，保留默认对话框兼容检查，没有绕过。

attempt-WYI9yF：前五项通过，第六项错误假定 close 返回即 destroyed，断言失败；首次 dispose 即时观测同样有尚未 destroyed 的内容。修正实验为预先订阅真实 destroyed 事件，保持现有 BrowserService 不变。最终 attempt-7LK12j 六项通过，明确记录逻辑关闭返回与原生销毁的时序差异。

依赖：原 Node 26 SQLite ABI147 不能用于 Electron42.11.14 的 Node24 ABI146；仅在本临时目录 electron-deps 安装并重建 better-sqlite3@12.11.1，Node-mode 实测可用。没有修改项目依赖。临时 userData/sessionData、mock keychain、本机页面和模拟 cookie，不使用日常数据或真实账号。
''')
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if any(x in ['node_modules','electron-deps','rebuild-cache','publication','__pycache__']or x.startswith('electron-home-')for x in rel.parts):continue
 if p.name=='electron-stub.cjs':continue
 if p.parent==root and p.name in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']:continue
 if p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log','.md','.mm']:files.append(p)
dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生浏览器页面与登录态保留验证

2026-11-14；技术方案 §9.7.2、验证账 §4.70；R01／02／03／05／08，Q37。仅临时技术研究，产品及共享原型未改。

## 联合链与结果

真实 Electron 42.11.14、当前 BrowserService／WebContentsView／CDP 代理和 browser-prompt preload，接已有程序化 owner 候选。真实 Codex 0.167.1 父、Claude SDK 0.3.321／native 2.1.321 子及同 task 后继 Claude，经原生 shell → 当前受管 CLI → 内核身份网关访问真实页面的标签元数据。模型只使用本机受控回复；批准由受信研究宿主处理。

本机 HTTP 页面设置合成 HttpOnly cookie，页面导航后具有独立 DOM nonce／counter、localStorage。分别在初始、旧父停止、同 task 新 Provider 启动、全部 native 停止后检查：同一个 BrowserPage 对象、pageId、WebContents ID、profileId 和 DOM 状态不变；页面 fetch 实际携带 cookie，服务端返回 LOGIN_OK。不是仅比对标签列表，也不是实际外部账号验证。

最终 {a.name} 六项通过：

| 检查 | 证据 |
| --- | --- |
| N01 错误进程树 | 有效临时 token＋同一真实 CLI，仍被内核祖先验证拒绝 |
| N02 父子访问 | 各自读取真实 pageId，跨 task 未授权拒绝，分别批准后结果进入下一模型请求 |
| N03 旧父停止 | 两页和模拟登录保留，旧 token 经 CLI 拒绝，子自有 grant 保留 |
| N04 同 task 切 Provider | 新 Claude 看到原父页面，重新申请跨任务权限，未继承旧父 grant |
| N05 原生排空 | 三个 native 与 CLI peer／业务活动结束，两页仍活着，grant 已撤销 |
| P06 显式关页 | 只关闭父页；子页 DOM 与模拟登录仍可用，最终服务关闭后两页 destroyed 事件均到达 |

最后一批 15 次本机模型请求、25 份内核 peer 证明、12 条业务调用、2 个真实页面；{runtime['accountRequestsWithCookie']} 次 account HTTP 请求带合成 cookie。三个 attempt 共八个 native 均记录退出且最终业务 run／活动／租约已收束；早期缺 preload 和关闭时序断言失败如实归档，不算通过。

## 必须保留的设计语义

页面属于逻辑 task；运行权限属于申请方 run。替换 Provider、撤销 run 或结束原生进程，不应因此销毁逻辑 task 的网页。父子本次属于同一项目，当前默认 profile／partition 相同，登录共享；页面访问仍需 run grant。不能把 run 权限隔离误写成 Cookie 隔离，也不能把其他业务现有的共享登录改掉。

真实 Electron 的 close／dispose 返回不代表 WebContents 已 destroyed。本次 close-return 为 registryRemoved=true、destroyedAtReturn=false；dispose 返回时子页也尚未 destroyed。现有 BrowserPageRegistry 调用 contents.close 后移除 registry，已有单测 fake 同步发 destroyed，无法呈现这个时差。实验只增加事件观察等待，不修改产品实现。迁移实现需区分页面逻辑关闭、业务活动排空、原生页面销毁三个状态；涉及关闭后的资源回收或重用，应在关闭前订阅 destroyed 并核对同一页面身份，超时保留待对账状态，不得将逻辑删除视为已销毁。beforeunload 阻止、崩溃页／弹窗分支仍待相应用例验证。

## 范围与复跑

独立 Electron userData／sessionData、mock keychain、本机模拟页面，未打开日常登录数据。真实 preload 从当前源码构建并保留其兼容检查。Electron ABI146 与 shell Node ABI147 不兼容，SQLite 仅在临时 electron-deps 重建；没有改项目依赖。构建 external electron，无 stub 进入当前依赖图；历史未使用 stub 排除归档。浏览器能力包仍为当前定义重绑研究 runtime，不冒充正式发布包。

运行 main.mjs（实际 Electron main），而不是用普通 node 执行 probe。model/native 脚本、构建输入摘要、preload 源码哈希、运行协议及 SQLite 已归档；二进制／完整依赖／Chromium缓存不归档。关闭检查通过真实 destroyed 事件等待，没有 sleep／轮询，没有修改现有 BrowserService。初始化失败与错误断言均见 startup-notes 和相应 attempt。

未覆盖真实 renderer 审批、新统一 UI、外部网站账号、应用重启后登录保留、跨项目 Cookie 隔离、agent-browser helper 的网页操作／输入／下载、正式安装包或跨平台。Q37 仍为部分证据，不等于完整产品通过。

[结果](result.json) · [运行核验](runtime-audit.json) · [源码依据](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。共 {len(files)} 文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(sources)} 构建输入哈希核验。
''')
section='''### 9.7.2 逻辑任务页面、运行权限与原生销毁

[真实 Electron 页面实验](实验/20261114_原生浏览器页面与登录态保留验证/README.md)已把 §9.7.1 的空列表扩展为真实 WebContentsView 页面：父 Codex、子 Claude 及同 task 后继 Claude 经原生 CLI 读取 pageId；停止旧父和全部 native 后，原页面对象、DOM、localStorage 与本机合成 HttpOnly Cookie 请求仍保持。新 Provider 重新获得业务权限，不需要重建原页面。仅证明进程内切换和隔离模拟登录，未验证应用重启或外部账号。

迁移保持两条独立身份链：浏览器页面属于逻辑 task／现有 project profile，跨任务访问 grant 属于申请方 run。当前同项目默认共享浏览器登录；不得把 run 权限隔离等同于 Cookie 隔离，或随 Provider 替换销毁页面／重建 partition。用户显式关页和宿主退出才进入相应浏览器生命周期。

**逻辑关闭不等于原生销毁。** 实际 close／dispose 返回时 WebContents 可能尚未触发 destroyed；现有同步 fake 单测不能覆盖这段时序。统一状态需区分停止接单／逻辑移除、业务活动排空、原生销毁。涉及销毁后才允许的资源重用／释放，应预先绑定该 WebContents 的 destroyed 事件，完成后再发布资源完成；事件未到或 beforeunload 阻止时保持待对账状态，不能凭页面列表为空释放占用。实验保持现有 BrowserService 未改，仅等待原生事件证明正常关闭最终可完成；阻止卸载、崩溃页和弹窗仍按分支补证。

'''
def tech(t):
 assert '### 9.7.2 'not in t;return t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
edit(base/'技研/技术方案.md',tech)
record='''### 4.70 真实页面、进程内切换与合成登录保留

[Electron 页面实验](实验/20261114_原生浏览器页面与登录态保留验证/README.md)最终六项通过。真实 Codex 父／Claude 子／同 task 后继 Claude，经实际原生 CLI 与内核网关读取两个真实页面。旧父停止、新 Provider 启动及全部 native 退出后，同页面对象／DOM／localStorage 保留，页面发起本机 HTTP 请求携带合成 HttpOnly Cookie。显式关父页后子页仍正常；最后两个 WebContents 的 destroyed 事件均到达。

发现现有 close／dispose 返回与原生 destroyed 之间有时差：旧检查错误假定同步销毁而失败；修正研究观察器预先订阅事件后通过，产品 BrowserService 未改。原始失败、缺 preload 初始化失败、正常最终批均归档；三个 attempt 八个 native 最终退出。父子同项目默认共享 profile／登录，不把 run 权限隔离误记为 Cookie 隔离。技术方案 §9.7.2 明确页面任务身份、run grant、逻辑关闭／业务排空／原生销毁三层语义。

未验证外部账号、App 重启持久、真实 renderer 批准／统一 UI、agent-browser helper 网页交互和关闭异常分支；Q37 仍部分。Electron ABI 与 SQLite 独立依赖适配仅限本机固定版本，无产品／共享原型修改。

'''
def ledger(t):
 assert '### 4.70 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');t=t.replace('真实页面与登录态、真实 UI 审批仍待验','§4.70 补真实页面对象／DOM 与本机合成登录在 Provider 切换后的保留、显式关闭及 destroyed 时序；外部账号、重启、真实 UI 审批与关闭异常仍待验');t=t.replace('继续补真实页面／登录、邮件上下文、在途写与宿主崩溃，审计诊断回传合同仍待验证','§4.70 又补真实页面／合成登录与关闭事件时序；继续补浏览器异常关闭／重启、邮件上下文、在途写与宿主崩溃，审计诊断回传合同仍待验证');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('最新进展：'):lines[i]='最新进展：真实 Electron 页面已接两端原生 CLI。六项检查通过：Provider 切换保留页面／DOM／本机合成登录，新 run 重新授权；关闭时发现并记录逻辑移除与原生 destroyed 的时差，见[技术方案 §9.7.2](技研/技术方案.md)。真实账号／重启／UI 审批仍待验，产品未改。'
  if l.startswith('下一步：'):lines[i]='下一步：补浏览器关闭异常和拒绝诊断合同，继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的其他业务在途／宿主恢复；不重复已通过的页面保留正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources)}))
