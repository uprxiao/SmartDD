# 实验准备失败记录

初始 Electron 入口顶层 await app.whenReady 未进入实验，执行会话 90702 通过自身 Ctrl-C 结束（130）；原入口保留 main-initial.mjs。一次入口编辑语法错误仍被误启动（89389），Electron 报启动异常，通过自身 Ctrl-C 结束（130）；未创建业务 fixture。随后改为非阻塞 whenReady.then 并先过 node --check。

attempt-5dOZ8g：真实浏览器防护拒绝缺失的 JS 对话框 preload，检查未开始；两端 native 最终退出。随后编译当前真实 browser-prompt.ts，保留默认对话框兼容检查，没有绕过。

attempt-WYI9yF：前五项通过，第六项错误假定 close 返回即 destroyed，断言失败；首次 dispose 即时观测同样有尚未 destroyed 的内容。修正实验为预先订阅真实 destroyed 事件，保持现有 BrowserService 不变。最终 attempt-7LK12j 六项通过，明确记录逻辑关闭返回与原生销毁的时序差异。

依赖：原 Node 26 SQLite ABI147 不能用于 Electron42.11.14 的 Node24 ABI146；仅在本临时目录 electron-deps 安装并重建 better-sqlite3@12.11.1，Node-mode 实测可用。没有修改项目依赖。临时 userData/sessionData、mock keychain、本机页面和模拟 cookie，不使用日常数据或真实账号。
