module.exports = {"kind":"fixture-dependency","version":"1"};
