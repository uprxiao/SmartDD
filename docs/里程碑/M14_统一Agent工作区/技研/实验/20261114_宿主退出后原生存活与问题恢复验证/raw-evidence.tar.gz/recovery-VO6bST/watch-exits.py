import json,select,sys
pids=[int(p) for p in sys.argv[1:]]
q=select.kqueue()
try:
 events=[select.kevent(pid,filter=select.KQ_FILTER_PROC,flags=select.KQ_EV_ADD|select.KQ_EV_ONESHOT,fflags=select.KQ_NOTE_EXIT) for pid in pids]
 q.control(events,0,0)
 print(json.dumps({'type':'ready','pids':pids}),flush=True)
 remaining=set(pids)
 while remaining:
  events=q.control(None,len(remaining),20)
  if not events:raise RuntimeError('EXIT_OBSERVATION_TIMEOUT')
  for event in events:
   if event.ident in remaining:
    remaining.remove(event.ident)
    print(json.dumps({'type':'exit','pid':event.ident,'fflags':event.fflags}),flush=True)

finally:
 q.close()
