module.exports = {"kind":"agent-adapter","version":"1"};
