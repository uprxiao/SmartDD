import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdtempSync,writeFileSync,readFileSync,appendFileSync,copyFileSync} from 'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import * as ledger from './ledger.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/recovery-'),checks=[],reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
const save=(name,x)=>writeFileSync(out+'/'+name,JSON.stringify(x,null,2)+'\n'),defer=()=>{const d=Promise.withResolvers();d.promise.catch(()=>{});return d;};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('WATCHDOG:'+label)),20000))]).finally(()=>clearTimeout(timer));};
for(const n of ['recovery.mjs','watch-exits.py','probe.mjs','ledger.mjs','ledger.sql','fixture.mjs','build.json'])copyFileSync(root+'/'+n,out+'/'+n);
const checkpoint=defer(),host=spawn(process.execPath,[root+'/probe.mjs'],{cwd:root,env:{HOME:out,PATH:'/usr/bin:/bin',TMPDIR:out,WY_LIVE_QUESTION_RECOVERY:'1'},stdio:['ignore','pipe','pipe']});
const processes=[{role:'host',pid:host.pid,exit:null}];
const hostExit=new Promise((resolve,reject)=>{host.once('error',reject);host.once('close',(code,signal)=>{processes[0].exit={code,signal};resolve();});});
host.stderr.on('data',b=>appendFileSync(out+'/host-stderr.log',b));const lines=createInterface({input:host.stdout});lines.on('line',line=>{appendFileSync(out+'/host-stdout.jsonl',line+'\n');try{const x=JSON.parse(line);if(x.type==='checkpoint')checkpoint.resolve(x);else if(x.error)checkpoint.reject(Error(x.error));}catch(e){checkpoint.reject(e);}});
let cp,db,store,watcher,watchExit,watchLines,error;const exitEvents=new Map();
const state=()=>({requests:db.prepare('SELECT * FROM m14_request_reply').all(),runs:db.prepare('SELECT * FROM capability_runs').all(),leases:db.prepare("SELECT * FROM capability_resource_leases WHERE owner_kind='run'").all()});
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save('progress.json',checks);if(db){save(id+'-state.json',state());await db.backup(out+'/'+id+'.sqlite');}}};
function signalOwnedNative(n,signal){assert.equal(reader.state(n.identity),'running','NATIVE_IDENTITY_NOT_LIVE');process.kill(n.identity.pid,signal);}
try{
 cp=await deadline(checkpoint.promise,'pending native');assert.equal(cp.host.pid,host.pid);assert.deepEqual(reader.read(host.pid),cp.host);assert.equal(cp.native.length,2);save('checkpoint.json',cp);
 const ready=defer();watcher=spawn('/usr/bin/python3',[root+'/watch-exits.py',...cp.native.map(n=>String(n.identity.pid))],{stdio:['ignore','pipe','pipe']});const wr={role:'exit-observer',pid:watcher.pid,exit:null};processes.push(wr);watchExit=new Promise((resolve,reject)=>{watcher.once('error',reject);watcher.once('close',(code,signal)=>{wr.exit={code,signal};if(code!==0)ready.reject(Error('EXIT_OBSERVER_FAILED:'+code));resolve();});});watcher.stderr.on('data',b=>appendFileSync(out+'/watch-stderr.log',b));for(const n of cp.native)exitEvents.set(n.identity.pid,defer());watchLines=createInterface({input:watcher.stdout});watchLines.on('line',line=>{appendFileSync(out+'/watch.jsonl',line+'\n');try{const x=JSON.parse(line);if(x.type==='ready')ready.resolve(x);if(x.type==='exit')exitEvents.get(x.pid)?.resolve(x);}catch(e){ready.reject(e);}});await deadline(ready.promise,'watch ready');
 db=new Database(cp.db);db.pragma('foreign_keys=ON');store=new actual.ResourceStore(db,cp.root,undefined,{processes:reader});
 const sessions=new actual.CapabilitySessionRegistry(store,{assertInitialSelection:()=>{throw Error('RECOVERY_MUST_NOT_CREATE_SESSION');},verifyExtraResource:()=>{throw Error('THIS_PROBE_DOES_NOT_PREPARE_NEW_RESOURCE_RUN');}}),runs=new actual.CapabilityRunRegistry(store,sessions,{processes:reader,assertCurrent:()=>{},revoke:()=>{}});
 const reserve=n=>{const r=db.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(n.runId);return runs.reserve({taskId:r.task_id,snapshotHash:r.snapshot_hash,bindings:[]});};
 await check('L01','live old host cannot be taken over while both native forms are pending',async()=>{
  for(const n of cp.native){assert.equal(reader.state(n.identity),'running');await assert.rejects(ledger.recover(store,reader,n.requestId),/OLD_OWNER_LIVE_OR_UNKNOWN/);assert.equal(ledger.inspect(store,n.requestId).view.awaitingUser,true);}
  const rs=await actual.recoverCapabilityRuns(store,reader);assert.equal(rs.length,2);assert(rs.every(x=>x.state==='running'));return{liveOwnerRejected:true,nativeProcesses:2};
 });
 host.kill('SIGKILL');await deadline(hostExit,'host exit');assert.equal(processes[0].exit.signal,'SIGKILL');assert.equal(reader.state(cp.host),'stopped');
 await check('L02','lost host expires questions while actual living natives retain run leases',async()=>{
  for(const n of cp.native){assert.equal(reader.state(n.identity),'running');const v=await ledger.recover(store,reader,n.requestId);assert.equal(v.request.liveness,'expired');assert.equal(v.request.cancel_requested,0);assert.equal(v.decision,null);assert.equal(v.liveGrant,false);assert.equal(v.automaticRetry,false);await assert.rejects(ledger.decide(store,{id:n.requestId},{id:'unused'}),/RESPONSE_OWNER_CHANGED/);}
  const rs=await actual.recoverCapabilityRuns(store,reader);assert(rs.every(x=>x.state==='orphaned'));assert(state().leases.every(x=>x.state==='recovery-required'));for(const n of cp.native)await assert.rejects(reserve(n),e=>e.code==='RESOURCE_BUSY');return{questionsExpiredWithoutConsent:true,nativesStillAlive:true,leasesRetained:true,newRunsBlocked:true};
 });
 await check('L03','unknown native observations do not release resources or recreate callbacks',async()=>{
  const nativePids=new Set(cp.native.map(n=>n.identity.pid)),uncertain={read:pid=>reader.read(pid),state:i=>nativePids.has(i.pid)?'unknown':reader.state(i)};
  const rs=await actual.recoverCapabilityRuns(store,uncertain);assert(rs.every(x=>x.state==='orphaned'));assert(state().leases.every(x=>x.state==='recovery-required'));for(const n of cp.native){const v=await ledger.recover(store,reader,n.requestId);assert.equal(v.request.liveness,'expired');assert.equal(v.liveGrant,false);assert.equal(reader.state(n.identity),'running');}return{controlledUnknownReader:true,actualNativesAlive:true,leasesRetained:true};
 });
 await check('L04','only proved native exits permit actual run recovery and explicit new reservation',async()=>{
  for(const n of cp.native)signalOwnedNative(n,'SIGKILL');await Promise.all(cp.native.map(n=>deadline(exitEvents.get(n.identity.pid).promise,'native exit')));await deadline(watchExit,'watch exit');assert.equal(processes[1].exit.code,0);for(const n of cp.native)assert.equal(reader.state(n.identity),'stopped');
  const rs=await actual.recoverCapabilityRuns(store,reader);assert(rs.every(x=>x.state==='stopped'));assert(state().leases.every(x=>x.state==='released'));
  for(const n of cp.native){const before=ledger.inspect(store,n.requestId),next=await reserve(n);await next.stop('research-no-fork');await next.cancelBeforeFork();assert.equal(runs.get(next.runId).state,'stopped');assert.deepEqual(ledger.inspect(store,n.requestId),before);}
  return{kernelExitEvents:2,nativeBirthsConfirmedStopped:true,oldRunsStopped:true,oldLeasesReleased:true,newReservationsUnforkedAndCancelled:true,noQuestionResend:true};
 });
 assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 if(host.exitCode===null&&host.signalCode===null){host.kill('SIGKILL');await deadline(hostExit,'cleanup host');}
 if(cp)for(const n of cp.native){const observed=reader.state(n.identity);if(observed==='running'){signalOwnedNative(n,'SIGKILL');if(exitEvents.has(n.identity.pid)&&watcher?.exitCode===null&&watcher?.signalCode===null)await deadline(exitEvents.get(n.identity.pid).promise,'cleanup native');}}
 if(watcher&&watcher.exitCode===null&&watcher.signalCode===null){watcher.kill('SIGTERM');await deadline(watchExit,'cleanup observer');}
 if(db){save('final-state.json',state());await db.backup(out+'/final.sqlite');db.close();}lines.close();watchLines?.close();
}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:error??null,processes,native:cp?.native.map(n=>({...n,finalState:reader.state(n.identity)})),scope:'Actual current run recovery and request candidate in one store after real host SIGKILL while two real native processes are deliberately SIGSTOP-frozen. Unknown identity is a controlled reader branch. Synthetic pending forms; no answers sent, business writes, active command side effects, native resumes or product UI.'};save('result.json',result);writeFileSync(root+'/latest-recovery.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
