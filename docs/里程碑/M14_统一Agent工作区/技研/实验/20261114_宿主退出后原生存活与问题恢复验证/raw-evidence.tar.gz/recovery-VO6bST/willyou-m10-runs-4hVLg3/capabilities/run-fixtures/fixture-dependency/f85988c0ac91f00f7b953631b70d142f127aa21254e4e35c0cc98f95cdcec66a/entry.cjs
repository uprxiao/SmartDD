module.exports = {"kind":"fixture-dependency","version":"2"};
