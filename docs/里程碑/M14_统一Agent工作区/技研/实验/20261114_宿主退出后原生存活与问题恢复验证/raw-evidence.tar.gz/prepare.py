from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_宿主退出后原生存活与问题恢复验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest-recovery.json').read_text());assert r['passed']==4 and r['error'] is None and all(n['finalState']=='stopped' for n in r['native'])
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
out=Path(r['out']);cp=json.loads((out/'checkpoint.json').read_text());s=json.loads((out/'final-state.json').read_text());assert len(s['requests'])==2 and all(x['liveness']=='expired' and x['cancel_requested']==0 for x in s['requests']);assert all(x['state']=='stopped' for x in s['runs']);assert all(x['state']=='released' for x in s['leases'])
failure=json.loads((root/'recovery-ch9SRd/failure-audit.json').read_text());assert all(x['state']=='stopped' for x in failure['observations'])
native_dir=Path(cp['out']);model_requests=sum(len((d/'model.jsonl').read_text().splitlines()) for d in native_dir.iterdir() if d.is_dir() and (d/'model.jsonl').exists());assert model_requests==2
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'actualRecovery':'src/main/core/applications/run-recovery.ts: recoverCapabilityRuns plus actual CapabilityRunRegistry reservation gate, ResourceStore and MacProcessIdentityReader','candidate':'Existing isolated request reply ledger unchanged; temporary native checkpoint and observer only','scope':r['scope'],'controlledObservation':'unknown supplied only for the two captured native identities; actual Mac reader continued to observe them alive. SIGSTOP preserves real processes across host death without permitting further actions.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','fixture.mjs','ledger.mjs','ledger.sql','probe.mjs','recovery.mjs','watch-exits.py','mcp.mjs','model.mjs','native-inputs.mjs','migration.mjs','candidate.sql','source-review.json','prepare.py']]
dirs=sorted(p for p in root.iterdir() if p.is_dir() and not p.is_symlink() and (p.name.startswith('attempt-') or p.name.startswith('recovery-')))
for d in dirs:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'finalLocalModelRequests':model_requests,'failedAttemptAudit':failure,'failureRecordedFrom':'Observer stderr, captured host/native checkpoint, exact-identity cleanup record and exec session 68820 terminal error. Failed driver did not produce its normal final result; not counted as passed.'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 宿主退出后原生存活与问题恢复验证

日期：2026-11-14。关联 D02／D06／D08、Q11／26／27／32／56。实际当前 run-recovery、运行预留门禁、ResourceStore 与 Mac 进程身份读取器，联合既有候选问题账。未修改产品代码。

## 四项检查

| 检查 | 实际结果 |
| --- | --- |
| L01 旧宿主尚活 | Claude 与 Codex 两个真实表单同时 pending；问题恢复拒绝接管，实际 run 恢复报告 running |
| L02 宿主死亡、原生仍活 | 精确终止研究宿主后，两个实际 native PID／出生身份仍存活；问题 expired、无取消意图／答案／活句柄；实际 run 为 orphaned、租约 recovery-required，两个新 run 预留均 RESOURCE_BUSY |
| L03 原生身份未知 | 只对已捕获的两原生身份注入 unknown 观测；实际进程仍活，恢复继续保留 orphaned／租约，不重新产生问题回调 |
| L04 原生确认退出 | 精确终止研究原生进程，内核 NOTE_EXIT 事件及 Mac 出生身份均确认停止；实际 run 恢复至 stopped、旧租约 released；显式新预留可建立后按未 fork 路径取消，旧问题不重发、不复活 |

最终四项通过，两个本机合成模型请求产生两个真实 pending 表单，没有发送任何用户答案。研究宿主按计划 SIGKILL，两个原生进程均已停止，退出观察器退出 0；最终库及各状态现场保留，最终 SQLite 完整性／外键检查通过。新预留只验证准入，没有 prepare／fork 或新模型回合。

## 实验方法与证据边界

工作宿主直接捕获 native ChildProcess／出生身份并登记实际 run。两表单 pending 后，对这两个已拥有进程发 SIGSTOP，使它们在宿主死亡后确定仍存在，阻止其继续行动。上层驱动先注册 macOS kqueue NOTE_EXIT，再终止自己创建的宿主；恢复检查后只清理记录中身份仍精确匹配的两个原生 PID。没有按名称或路径搜寻／批量终止进程。

SIGSTOP 是受控故障条件，不是产品处理方案。running 在本实验表示 OS 进程身份仍存在，并不表示进程正在执行指令。L03 的 unknown 是观测替身，不是实际制造内核身份读取失败。两端是 Claude SDK 0.3.321／native 2.1.321 和 Codex app-server 0.167.1，仅本机合成模型与 MCP，隔离 HOME／配置，无付费调用。

本轮证明“问题不能再回答”和“运行仍需保留资源”可以同时成立；不是完整执行范围清理或业务恢复。未覆盖发送中回答、在途邮件／插件写入、独立后台子进程、动态委派后代、自动接管旧原生连接、供应商请求或产品 UI。现有运行恢复结束 run 活动账也不能推导外部副作用失败／未执行；业务结果账仍须单独恢复。

## 首次驱动失败

初轮 Python 观察器用 `with select.kqueue()`，本机对象没有 __enter__，观察器启动失败；恢复断言未执行。清理又等待已经退出观察器的通知，产生 WATCHDOG:cleanup native。修正为显式 try／finally 关闭 kqueue、观察器失败立即拒绝 readiness、清理不等待已死观察器。按已捕获 PID／出生身份补清理并确认旧宿主和两个原生均停止后，才执行最终复验。原 stderr、检查点、补清理及失败审计归档，未伪造初轮正常结果。

## 设计落点

恢复先分清问题宿主与原生执行范围。确认旧问题宿主已死亡后，可以结束失效回答入口而不产生取消／批准；旧原生或身份不明时，实际 run／资源维持待恢复，拒绝新写入运行和资源回收。只有实际执行范围满足原协议的结束条件，才能释放相应租约。UI 同时显示“旧问题已失效”和“运行待恢复”，不要用前者覆盖后者。

## 复现

固定依赖、本机监听及对自建进程发信号权限具备时，执行 `node build.mjs`、`node recovery.mjs`。保留失败与成功两轮、两个 native 检查点、内核事件、实际 SQLite 各阶段及 379 条源码输入摘要。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
old='宿主崩溃后问题句柄失效与旧原生执行范围排空是两个门槛；即使问题已 expired，存活／身份不明的旧进程仍需保留运行与资源占用，该混合联合窗口尚待验证。'
new='''宿主崩溃后问题句柄失效与旧原生执行范围排空是两个门槛。[原生仍存活的宿主退出实验](实验/20261114_宿主退出后原生存活与问题恢复验证/README.md)已将真实 Claude／Codex pending 表单、候选问题恢复与当前实际 run-recovery 接到同库：确认旧宿主死亡后，问题 expired、无取消／答案／新回调；两原生进程仍存在或观测未知时，实际 run 为 orphaned、租约 recovery-required，新 run 预留拒绝。精确进程退出及出生身份确认后，实际运行才结束并释放占用，旧问题仍不复活。

该实验用 SIGSTOP 将已捕获的原生进程保留在故障窗口，unknown 为受控观测分支，不能当作生产停止策略或全部内核故障实测。UI 应同时表达“旧问题失效”和“运行待恢复”；失效按钮不等于可以启动新写者或回收资源。在途回答／业务写入、后台后代和完整执行范围仍按各自账处理，不由问题过期补造未执行／已回滚结论。'''
assert old in t;t=t.replace(old,new,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.97 ' not in t
t=t.replace('真实 UI／业务、原生仍活跃及完整委派链仍待验 |','§4.97 补真实宿主退出后两原生存活／受控未知时的问题过期、实际 run／租约保留及新运行拒绝；真实 UI／业务、在途回应与完整委派链仍待验 |',1)
add='''### 4.97 宿主退出后原生存活与问题恢复

[四项检查](实验/20261114_宿主退出后原生存活与问题恢复验证/README.md)在同库真实 Claude／Codex 表单 pending 时冻结已拥有的原生进程并终止研究宿主。候选问题账将失效入口过期，不生成取消或答案；实际 run-recovery 对存活原生保持 orphaned／recovery-required，实际新预留拒绝。受控 unknown 观测同样保留；精确原生 NOTE_EXIT 和出生身份停止后，实际 run／租约才收尾，旧问题不重发。

首轮观察器不支持 Python context manager，并暴露清理等待已死观察器的驱动缺陷；原错误、身份清理及失败审计保留，全部旧进程确认停止后复验四项通过。最终两次本机合成模型请求，无答案发送，研究宿主及两个原生均停止；没有产品／业务写入。SIGSTOP 是故障夹具，unknown 是替身；发送中回答、独立后台后代及业务结果联合仍未覆盖。Q26／27 等继续部分。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
t=t.replace('仍缺原生仍活跃与完整业务链的联合恢复','§4.97 已补 pending 问题下原生存活／未知与实际 run／租约恢复；仍缺发送中回答、后台执行范围和完整业务链的联合恢复',1)
t=t.replace('截至 §4.96，56 个宽口径问题项中','截至 §4.97，56 个宽口径问题项中',1)
assert len(re.findall(r'^\| Q\d{2} \|',t,re.M))==56;put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();t=re.sub(r'^最新进展：.*$','最新进展：宿主退出而两原生进程仍存活时，旧问题失效与实际运行／租约保留已取得同库证据，新运行被正确拒绝。见[原生存活恢复实验](技研/实验/20261114_宿主退出后原生存活与问题恢复验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$','下一步：回到[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)，核对决定架构的未验证联合与现行设计冲突，区分仍可隔离验证的业务／运行／迁移问题和开发后才能执行的界面验收；不以局部检查数量代替整体收口。',t,flags=re.M);put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-mixed-question-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed'],'localModelRequests':model_requests}))
