# Snapshot file
# Unset all aliases to avoid conflicts with functions
unalias -a 2>/dev/null || true
# Functions

# setopts 2
setopt nohashdirs
setopt login

# aliases 2
alias run-help=man
alias which-command=whence

# exports (native declarations)
export ALL_PROXY=http://127.0.0.1:1
export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1
export CLAUDE_CONFIG_DIR=/private/tmp/willyou-m14-live-question-recovery-probe/attempt-wUkasW/b-state
export CODEX_HOME=/private/tmp/willyou-m14-live-question-recovery-probe/attempt-wUkasW/b-state
export DISABLE_AUTOUPDATER=1
export ENABLE_TOOL_SEARCH=false
export HOME=/private/tmp/willyou-m14-live-question-recovery-probe/recovery-VO6bST/willyou-m10-runs-4hVLg3/home
export HTTPS_PROXY=http://127.0.0.1:1
export HTTP_PROXY=http://127.0.0.1:1
export LANG=C.UTF-8
export LOGNAME=hx
export NO_PROXY=localhost,127.0.0.1
export -T PATH path=( /usr/local/bin /System/Cryptexes/App/usr/bin /usr/bin /bin /usr/sbin /sbin /var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin /var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin /var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin /pkg/env/global/bin /Library/Apple/usr/bin /opt/homebrew/bin /private/tmp/willyou-m14-live-question-recovery-probe/attempt-wUkasW/b-state/tmp/arg0-macos/codex-arg0XtIDnA /private/tmp/willyou-m14-global-f3zh527k/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/codex-path )
export -i10 SHLVL=1
export TMPDIR=/private/tmp/willyou-m14-live-question-recovery-probe/attempt-wUkasW/b-1
export WY_MODEL_KEY=synthetic-only
export __CF_USER_TEXT_ENCODING=0x1F5:0x0:0x64
