import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:http';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,copyFileSync,readFileSync,writeSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {setupMixed} from './fixture.mjs';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import actual from './actual.cjs';
import * as ledger from './ledger.mjs';
import {nativeRuntime,baseEnv} from './native-inputs.mjs';
import {reply} from './model.mjs';
import {createMcp} from './mcp.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,v)=>writeFileSync(out+'/'+n,JSON.stringify(v,null,2)),configs=new Map(),contexts=[],checks=[],processes=[];
for(const n of ['probe.mjs','ledger.mjs','ledger.sql','model.mjs','mcp.mjs','native-inputs.mjs','build.mjs','build.json','fixture.mjs'])copyFileSync(root+'/'+n,out+'/'+n);
const defer=()=>{const d=Promise.withResolvers();d.promise.catch(()=>{});return d;};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('WATCHDOG:'+label)),30000))]).finally(()=>clearTimeout(timer));};
let f,server,base,error,serverError;
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
async function check(id,title,fn){try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}}
async function child(label,driver='claude'){const taskId=randomUUID(),sessionId=driver==='claude'?randomUUID():null,stateRoot=out+'/'+label+'-state';mkdirSync(stateRoot);const stored=await f.sessions.create({...f.snapshot,taskId,runner:driver==='claude'?'claude-code':'codex',adapterBinding:{...f.snapshot.adapterBinding,id:driver==='claude'?'claude-code':'codex',hash:f.adapters.get(driver).contentHash},native:{...f.snapshot.native,stateRoot,sessionId}},f.home);const bindingId=randomUUID();f.sqlite.prepare('INSERT INTO host_child VALUES(?,?,?,?,0)').run(taskId,f.snapshot.taskId,bindingId,null);return{label,driver,stored,taskId,sessionId,bindingId,generation:0};}
async function start(child){
 if(child.driver==='codex')return startCodex(child);
 const run=await f.runs.reserve({taskId:child.taskId,snapshotHash:child.stored.pointer.snapshotHash,bindings:[]});await run.prepare();await run.cli.arm();child.generation++;
 const id=child.label+'-'+child.generation,dir=out+'/'+id;mkdirSync(dir);const mcp=await createMcp(dir),opened=defer(),answer=defer(),attached=defer();
 const c={id,dir,child,run,mcp,opened,answer,attached,scope:{taskId:child.taskId,bindingId:child.bindingId,runId:run.runId,generation:child.generation,connectionId:randomUUID()},modelCount:0,frames:[],sendCount:0,closed:false};contexts.push(c);configs.set(id,c);f.sqlite.prepare('UPDATE host_child SET run_id=?,generation=? WHERE task_id=?').run(run.runId,child.generation,child.taskId);
 const options={pathToClaudeCodeExecutable:nativeRuntime('claude').path,cwd:child.stored.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:{...baseEnv({home:f.home,root:dir,snapshot:child.stored.snapshot}),ANTHROPIC_BASE_URL:base+'/'+id,ANTHROPIC_AUTH_TOKEN:'synthetic-only',ANTHROPIC_API_KEY:'synthetic-only'},strictMcpConfig:true,mcpServers:{wy:{type:'http',url:mcp.url}},tools:[],allowedTools:['mcp__wy__ask'],onElicitation:async(request,o)=>{
  await attached.promise;actual.assertOwnedCapabilityRun(f.runs,run);f.runs.assertActive(run.runId);assert.equal(request.message,'M14_CHILD_QUESTION');
  c.raw={request,requestId:o.requestId};c.handle=await ledger.bindRuntime(f.store,reader,c.scope,{threadId:child.sessionId,requestId:o.requestId},f.runs,run);o.signal.addEventListener('abort',()=>{c.callbackAborted=true;answer.resolve({action:'cancel'});},{once:true});opened.resolve();return answer.promise;
 },spawnClaudeCodeProcess:o=>{
  const p=spawn(o.command,o.args,{cwd:options.cwd,env:options.env,stdio:['pipe','pipe','pipe']}),record={id,pid:p.pid,exit:null};processes.push(record);c.process=p;p.stdin.on('error',()=>{});p.stderr.on('data',b=>appendFileSync(dir+'/stderr.log',b));
  c.exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(code,signal)=>{record.exit={code,signal};resolve(record);});});const identity=reader.read(p.pid);assert(identity);run.cli.attach(p.pid,identity.startedAt).then(()=>attached.resolve(),e=>attached.reject(e));return p;
 }};
 if(child.generation===1)options.sessionId=child.sessionId;else options.resume=child.sessionId;
 c.q=query({prompt:'HOST_CHILD_QUESTION_'+id,options});c.consume=(async()=>{for await(const frame of c.q){c.frames.push(frame);appendFileSync(dir+'/frames.jsonl',JSON.stringify(frame)+'\n');}})();c.consume.catch(()=>{});
 await deadline(opened.promise,id+' form');return c;
}
async function startCodex(child){
 const run=await f.runs.reserve({taskId:child.taskId,snapshotHash:child.stored.pointer.snapshotHash,bindings:[]});await run.prepare();await run.cli.arm();child.generation++;
 const id=child.label+'-'+child.generation,dir=out+'/'+id;mkdirSync(dir);const mcp=await createMcp(dir),opened=defer(),done=defer();
 const c={id,dir,child,run,mcp,opened,scope:{taskId:child.taskId,bindingId:child.bindingId,runId:run.runId,generation:child.generation,connectionId:randomUUID()},modelCount:0,frames:[],sendCount:0,closed:false,queue:Promise.resolve(),consume:done.promise};contexts.push(c);configs.set(id,c);f.sqlite.prepare('UPDATE host_child SET run_id=?,generation=? WHERE task_id=?').run(run.runId,child.generation,child.taskId);
 const env={...baseEnv({home:f.home,root:dir,snapshot:child.stored.snapshot}),WY_MODEL_KEY:'synthetic-only'};
 const args=['app-server','--disable','plugins','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(base+'/'+id+'/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}','-c','mcp_servers.wy={url='+JSON.stringify(mcp.url)+',default_tools_approval_mode="approve"}'];
 const p=spawn(nativeRuntime('codex').path,args,{cwd:child.stored.snapshot.native.cwd,env,stdio:['pipe','pipe','pipe']}),record={id,pid:p.pid,exit:null};processes.push(record);c.process=p;p.stdin.on('error',()=>{});p.stderr.on('data',b=>appendFileSync(dir+'/stderr.log',b));
 c.exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(code,signal)=>{record.exit={code,signal};resolve(record);});});const identity=reader.read(p.pid);assert(identity);await run.cli.attach(p.pid,identity.startedAt);
 const pending=new Map();let seq=0;
 c.rpc=(method,params)=>{const id=++seq,d=defer();pending.set(id,d);p.stdin.write(JSON.stringify({id,method,params})+'\n');return d.promise;};
 const receive=async m=>{
  c.frames.push(m);appendFileSync(dir+'/frames.jsonl',JSON.stringify(m)+'\n');
  if(m.method&&m.id!==undefined){assert.equal(m.method,'mcpServer/elicitation/request');assert.equal(m.params.threadId,c.nativeThread);c.raw={request:m.params,requestId:m.id};c.handle=await ledger.bindRuntime(f.store,reader,c.scope,{threadId:m.params.threadId,requestId:m.id},f.runs,run);
   c.send=value=>new Promise((resolve,reject)=>p.stdin.write(JSON.stringify({id:m.id,result:value})+'\n',e=>e?reject(e):resolve()));opened.resolve();return;
  }
  if(m.id!==undefined){const d=pending.get(m.id);assert(d,'UNMATCHED_REPLY');pending.delete(m.id);m.error?d.reject(Error(JSON.stringify(m.error))):d.resolve(m.result);}
  if(m.method==='serverRequest/resolved'){assert(c.handle,'NO_MATCHING_REQUEST');await ledger.journal(f.store,c.handle,m);await ledger.apply(f.store,c.handle);}
  if(m.method==='turn/completed')done.resolve(m.params.turn);
 };
 c.lines=createInterface({input:p.stdout});c.lines.on('line',line=>{c.queue=c.queue.then(()=>receive(JSON.parse(line))).catch(e=>{opened.reject(e);done.reject(e);c.protocolError??=e;});});
 await deadline(c.rpc('initialize',{clientInfo:{name:'m14_mixed_questions',version:'1'},capabilities:{experimentalApi:true}}),id+' init');p.stdin.write('{"method":"initialized"}\n');
 const params={cwd:child.stored.snapshot.native.cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'on-request',sandbox:'read-only'};
 const thread=await deadline(c.rpc(child.sessionId?'thread/resume':'thread/start',{...params,...(child.sessionId?{threadId:child.sessionId}:{})}),id+' thread');c.nativeThread=thread.thread.id;
 if(child.sessionId)assert.equal(c.nativeThread,child.sessionId);else{child.stored=await f.sessions.bindNativeSession(child.taskId,child.stored.pointer.snapshotHash,{...child.stored.snapshot.native,runner:'codex',sessionId:c.nativeThread});child.sessionId=c.nativeThread;}
 const started=await deadline(c.rpc('turn/start',{threadId:c.nativeThread,input:[{type:'text',text:'HOST_CHILD_QUESTION_'+id,text_elements:[]}]}),id+' turn');c.turnId=started.turn.id;
 await deadline(opened.promise,id+' form');return c;
}
async function stopCodex(c,interrupted){
 if(interrupted){if(c.handle)await ledger.cancel(f.store,c.handle);await c.run.stop();if(c.turnId)await deadline(c.rpc('turn/interrupt',{threadId:c.nativeThread,turnId:c.turnId}),c.id+' interrupt');}
 await deadline(c.consume,c.id+' turn done');await c.queue;if(c.protocolError)throw c.protocolError;
 c.process.stdin.end();await deadline(c.exit,c.id+' exit');c.lines.close();await c.run.cli.exited();await c.run.stop();assert.equal(f.runs.get(c.run.runId).state,'stopped');await ledger.retire(f.store,c.handle);c.closed=true;
}
function command(c,label){return{id:randomUUID(),expected:c.scope,value:{action:'accept',content:{label,count:1,enabled:true}}};}
async function answer(c,cmd){await ledger.decide(f.store,c.handle,cmd);return ledger.dispatch(f.store,c.handle,async()=>{actual.assertOwnedCapabilityRun(f.runs,c.run);f.runs.assertActive(c.run.runId);const current=f.sqlite.prepare('SELECT * FROM host_child WHERE task_id=?').get(c.scope.taskId);assert.equal(current.run_id,c.scope.runId);assert.equal(current.generation,c.scope.generation);c.sendCount++;if(c.send)await c.send(cmd.value);else c.answer.resolve(cmd.value);});}
async function stop(c,interrupted=false){
 if(c.closed)return;if(c.child.driver==='codex')return stopCodex(c,interrupted);if(interrupted&&c.handle)await ledger.cancel(f.store,c.handle);if(interrupted)await c.run.stop();
 if(interrupted)await deadline(c.q.interrupt(),c.id+' interrupt');if(interrupted){c.answer.resolve({action:'cancel'});c.q.close();}
 await deadline(c.consume.catch(e=>{if(!interrupted)throw e;}),c.id+' consume');c.q.close();if(c.exit)await deadline(c.exit,c.id+' exit');await c.run.cli.exited();await c.run.stop();assert.equal(f.runs.get(c.run.runId).state,'stopped');if(!c.deferRetirement)await ledger.retire(f.store,c.handle);c.closed=true;
}
try{
 f=await setupMixed(reader);ledger.initialize(f.store);f.sqlite.exec('CREATE TABLE host_child(task_id TEXT PRIMARY KEY,parent_task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT,generation INTEGER NOT NULL);CREATE TABLE host_parent(task_id TEXT PRIMARY KEY,binding_id TEXT NOT NULL)');f.sqlite.prepare('INSERT INTO host_parent VALUES(?,?)').run(f.snapshot.taskId,randomUUID());
 server=createServer(async(req,res)=>{try{let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),c=configs.get(req.url.split('/')[1]);assert(c);c.modelCount++;assert(c.modelCount<=2);appendFileSync(c.dir+'/model.jsonl',JSON.stringify(body)+'\n');const tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]);const tool=tools.find(t=>t.name==='mcp__wy__ask'||t.name==='ask'&&t.namespace==='mcp__wy');assert(tool);if(c.modelCount===1)reply(res,c.child.driver,body,{tool,args:{}});else{assert(JSON.stringify(body.messages??body.input).includes('FORM_RESULT_'));reply(res,c.child.driver,body,{text:'HOST_CHILD_DONE_'+c.id});}}catch(e){serverError??=e.stack;if(!res.headersSent)res.writeHead(500);res.end('{}');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;save('native-runtime.json',nativeRuntime('claude'));
 const a=await child('a'),b=await child('b','codex'),A=await start(a),B=await start(b);assert.equal(A.raw.request.message,B.raw.request.message);assert.deepEqual(A.raw.request.requestedSchema,B.raw.request.requestedSchema);
 if(process.env.WY_LIVE_QUESTION_RECOVERY==='1'){
  const native=contexts.map(c=>({id:c.id,runId:c.run.runId,requestId:c.handle.id,scope:c.scope,identity:reader.read(c.process.pid)}));assert(native.every(n=>n.identity));
  for(const c of contexts)assert(c.process.kill('SIGSTOP'));
  for(const n of native)assert.equal(reader.state(n.identity),'running');
  const cp={type:'checkpoint',point:'pending-native-live',out,root:f.root,db:f.sqlite.name,host:reader.read(process.pid),native};save('live-checkpoint.json',cp);writeSync(1,JSON.stringify(cp)+'\n');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,30000);throw Error('LIVE_CHECKPOINT_NOT_TERMINATED');
 }
 await check('J01','identical concurrent host-child forms reject wrong child/run and parent scope',async()=>{
  await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'A'),expected:B.scope}),/REQUEST_SCOPE_CHANGED/);await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'A'),expected:{...A.scope,taskId:f.snapshot.taskId}}),/REQUEST_SCOPE_CHANGED/);assert.equal(A.sendCount+B.sendCount,0);await assert.rejects(ledger.retire(f.store,A.handle),/RUN_NOT_STOPPED/);assert.equal(ledger.inspect(f.store,A.handle.id).request.cancel_requested,0);return{sameForm:true,differentHostTasks:true,wrongChildAndParentRejected:true};
 });
 await check('J02','logical parent binding change leaves child question owner unchanged',async()=>{
  const original=ledger.inspect(f.store,B.handle.id).request.scope_json;f.sqlite.prepare('UPDATE host_parent SET binding_id=? WHERE task_id=?').run(randomUUID(),f.snapshot.taskId);assert.equal(ledger.inspect(f.store,B.handle.id).request.scope_json,original);assert.equal(ledger.inspect(f.store,B.handle.id).view.awaitingUser,true);return{candidateParentPointerOnly:true,childRunUnaffected:true,notNativeProviderSwitch:true};
 });
 await check('J03','stopped child refuses old response while sibling completes',async()=>{
  await stop(A,true);await assert.rejects(ledger.decide(f.store,A.handle,command(A,'OLD')),/REQUEST_NOT_OPEN|REQUEST_CANCELLED/);await assert.rejects(answer(A,command(A,'OLD')),/REQUEST_NOT_OPEN|REQUEST_CANCELLED/);assert.equal(A.sendCount,0);
  const cmd=command(B,'B_ONLY');await answer(B,cmd);await ledger.decide(f.store,B.handle,cmd);await deadline(B.consume,'B completed');assert.equal(B.frames.findLast(x=>x.method==='turn/completed').params.turn.status,'completed');assert.deepEqual(B.mcp.records.map(x=>x.result),[cmd.value]);assert.equal(B.sendCount,1);await stop(B);return{oldAnswerNotSent:true,siblingAnswerObservedByActualMcp:true,decisionRepeatNoDuplicateSend:true};
 });
 const A2=await start(a),B2=await start(b);
 await check('J07','Codex cancellation preserves pending Claude sibling and exact cancelled close is not consent',async()=>{
  await stop(B2,true);await assert.rejects(ledger.decide(f.store,B2.handle,command(B2,'OLD_B')),/REQUEST_NOT_OPEN|REQUEST_CANCELLED/);const v=ledger.inspect(f.store,B2.handle.id);assert.equal(v.request.cancel_requested,1);assert.equal(v.decision,null);assert.equal(v.request.liveness,'closed');assert(v.request.close_evidence);assert.equal(ledger.inspect(f.store,A2.handle.id).view.awaitingUser,true);return{codexCancelled:true,claudeStillPending:true,closedDoesNotMeanApproved:true};
 });
 await check('J04','same child native session next run keeps prior response expired',async()=>{
  assert.equal(A2.scope.generation,A.scope.generation+1);assert.notEqual(A2.scope.runId,A.scope.runId);assert.equal(A2.child.sessionId,A.child.sessionId);
  await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'OLD'),expected:A2.scope}),/REQUEST_SCOPE_CHANGED/);assert.equal(A2.sendCount,0);
  const cmd=command(A2,'A_NEXT');await answer(A2,cmd);await deadline(A2.consume,'A2 completed');assert.equal(A2.frames.findLast(x=>x.type==='result').is_error,false);assert.deepEqual(A2.mcp.records.map(x=>x.result),[cmd.value]);A2.deferRetirement=true;await stop(A2);return{actualSdkResumeSameNativeId:true,hostRunAndGenerationChanged:true,oldResponseIsolated:true,newAnswerObserved:true};
 });

 await check('J05','normal retirement differs from explicit cancellation without claiming native acknowledgement',async()=>{
  const av=ledger.inspect(f.store,A.handle.id),bv=ledger.inspect(f.store,B.handle.id);
  assert.equal(av.request.cancel_requested,1);assert.equal(av.decision,null);
  assert.equal(bv.request.cancel_requested,0);assert.equal(bv.request.liveness,'closed');assert.equal(bv.decision.delivery,'submitted');assert(bv.request.close_evidence);assert.equal(bv.view.consumption,'unproven');assert(!bv.view.awaitingUser&&!bv.view.awaitingNative);
  await assert.rejects(ledger.retire(f.store,{...B.handle}),/RESPONSE_OWNER_CHANGED/);assert.deepEqual(await ledger.retire(f.store,B.handle),bv);await assert.rejects(ledger.decide(f.store,B.handle,command(B,'LATE')),/REQUEST_NOT_OPEN/);
  return{normalCancelFlag:0,explicitCancelFlag:1,retirementNotNativeClose:true,noWaitingAfterExit:true,idempotent:true};
 });
 await check('J06','retirement evidence and liveness commit atomically after actual run exits',async()=>{
  const before=ledger.inspect(f.store,A2.handle.id);assert.equal(before.request.liveness,'open');assert.equal(before.request.cancel_requested,0);assert.equal(before.decision.delivery,'submitted');
  f.sqlite.exec("CREATE TRIGGER reject_retirement BEFORE UPDATE OF liveness ON m14_request_reply BEGIN SELECT RAISE(ABORT,'INJECTED_RETIREMENT_FAILURE'); END");
  await assert.rejects(ledger.retire(f.store,A2.handle),/INJECTED_RETIREMENT_FAILURE/);assert.deepEqual(ledger.inspect(f.store,A2.handle.id),before);assert.equal(f.sqlite.prepare('SELECT COUNT(*) AS n FROM m14_request_retirement WHERE request_id=?').get(A2.handle.id).n,0);
  f.sqlite.exec('DROP TRIGGER reject_retirement');
  const cut=process.env.WY_RETIREMENT_CUT,hold=point=>{if(cut===point){writeSync(1,JSON.stringify({type:'checkpoint',point,identity:reader.read(process.pid),db:f.sqlite.name,root:f.root,requestId:A2.handle.id,scope:A2.scope,processes})+'\n');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,30000);throw Error('CHECKPOINT_NOT_TERMINATED');}};
  hold('before-retire');const after=await ledger.retire(f.store,A2.handle,{checkpoint:hold});hold('after-retire');assert.equal(after.request.cancel_requested,0);assert.equal(after.request.liveness,'expired');assert.equal(after.decision.delivery,'submitted');assert.equal(after.request.close_evidence,null);assert(!after.view.awaitingNative&&!after.view.awaitingUser);assert.equal(A2.sendCount,1);
  return{rollbackKeepsOriginalDecision:true,noPartialRetirement:true,retryOnlyRetiresNoResend:true};
 });

 const B3=await start(b);
 await check('J08','Codex same native thread resume rejects prior connection response and accepts current answer',async()=>{
  assert.equal(B3.child.sessionId,B2.nativeThread);assert.notEqual(B3.scope.connectionId,B2.scope.connectionId);assert.notEqual(B3.scope.runId,B2.scope.runId);
  await assert.rejects(ledger.decide(f.store,B2.handle,{...command(B2,'STALE'),expected:B3.scope}),/REQUEST_SCOPE_CHANGED/);
  const cmd=command(B3,'B_NEXT');await answer(B3,cmd);await deadline(B3.consume,'B3 completed');assert.deepEqual(B3.mcp.records.map(x=>x.result),[cmd.value]);await stop(B3);const v=ledger.inspect(f.store,B3.handle.id);assert.equal(v.request.liveness,'closed');assert.equal(v.request.cancel_requested,0);assert.equal(v.decision.delivery,'submitted');return{sameNativeThread:true,newConnection:true,oldResponseRejected:true,currentAnswerObserved:true,numericNativeRequestId:B3.raw.requestId};
 });
 if(serverError)throw Error(serverError);
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 for(const c of contexts)try{await stop(c,true);}catch(e){error??=e.stack;process.exitCode=1;if(c.process&&c.process.exitCode===null&&c.process.signalCode===null){c.process.kill('SIGTERM');await deadline(c.exit,'cleanup');}};
 for(const c of contexts)await c.mcp.close();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}
 if(f){save('host-state.json',{children:f.sqlite.prepare('SELECT * FROM host_child').all(),parent:f.sqlite.prepare('SELECT * FROM host_parent').all(),requests:f.sqlite.prepare('SELECT * FROM m14_request_reply').all(),decisions:f.sqlite.prepare('SELECT * FROM m14_response_decision').all(),retirements:f.sqlite.prepare('SELECT * FROM m14_request_retirement').all(),runs:f.sqlite.prepare('SELECT * FROM capability_runs').all(),leases:f.sqlite.prepare('SELECT * FROM capability_resource_leases').all()});assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(out+'/final.sqlite');f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:error??null,serverError:serverError??null,modelRequests:contexts.reduce((n,c)=>n+c.modelCount,0),processes,scope:'Mixed Claude/Codex same-store child question candidate; real Codex resolved frames journaled exactly. Candidate retirement separates explicit cancellation from actual stopped native run; no native-close or consumption claim. Actual Claude SDK forms/resume, actual child run ownership, candidate parent-child pointers and response ledger in one current store. Synthetic forms/answers/local model. No actual delegation creation/outbox service, real parent provider switch, user UI, business approval, request-ledger crash or full business delegation.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
