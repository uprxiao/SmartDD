import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root='/private/tmp/willyou-m14-global-f3zh527k/node_modules/';
export const sdkPath=root+'@anthropic-ai/claude-agent-sdk/sdk.mjs';
const binaries={claude:{path:root+'@anthropic-ai/claude-agent-sdk-darwin-arm64/claude',sha256:'abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c',sdkVersion:'0.3.321',nativeVersion:'2.1.321',protocol:'claude-sdk-initialization'},codex:{path:root+'@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex',sha256:'ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b',sdkVersion:'not-used',nativeVersion:'0.167.1',protocol:'codex-app-server-initialize'}};
export function nativeRuntime(driver){const r=binaries[driver];assert.equal(createHash('sha256').update(readFileSync(r.path)).digest('hex'),r.sha256);return{kind:'external',...r};}
export const cleanProfileEnv=driver=>driver==='claude'?[{name:'ANTHROPIC_BASE_URL',secret:false,value:'http://127.0.0.1:1'},{name:'ANTHROPIC_AUTH_TOKEN',secret:true,value:'synthetic-only'}]:[{name:'WY_MODEL_KEY',secret:true,value:'synthetic-only'}];
export const baseEnv=f=>({HOME:f.home,PATH:'/usr/bin:/bin',TMPDIR:f.root,HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1',ENABLE_TOOL_SEARCH:'false',CLAUDE_CONFIG_DIR:f.snapshot.native.stateRoot,CODEX_HOME:f.snapshot.native.stateRoot});
