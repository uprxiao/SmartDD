import assert from 'node:assert/strict';
import {mkdirSync,writeFileSync,readFileSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import actual from './actual.cjs';
export async function setupMixed(reader){
 const f=await actual.runFixture(reader),data=Buffer.from('module.exports={isolated:"codex adapter fixture"};'),hash=actual.digest(data);
 const adapter=await f.store.publish({resourceId:'agent-adapter:codex:'+hash,kind:'agent-adapter',contentHash:hash,relativePath:'run-fixtures/codex/'+hash,dependencies:[f.parent.resourceId],materialize:dir=>{mkdirSync(dir);writeFileSync(join(dir,'entry.cjs'),data);writeFileSync(join(dir,'.smartdd-owned.json'),actual.canonicalJson({storeId:f.store.storeId,hash}));},verify:dir=>assert(readFileSync(join(dir,'entry.cjs')).equals(data))});
 const adapters=new Map([['claude',f.adapter],['codex',adapter]]);
 const sessions=new actual.CapabilitySessionRegistry(f.store,{assertInitialSelection:s=>assert(s.projectId==='p1'&&adapters.get(s.runner==='claude-code'?'claude':s.runner)?.contentHash===s.adapterBinding.hash,'HOST_SELECTION_CHANGED'),verifyExtraResource:r=>{const dir=f.store.directory(r);assert.equal(actual.digest(readFileSync(join(dir,'entry.cjs'))),r.contentHash);assert.equal(JSON.parse(readFileSync(join(dir,'.smartdd-owned.json'),'utf8')).storeId,f.store.storeId);assert.deepEqual(readdirSync(dir).sort(),['.smartdd-owned.json','entry.cjs']);}});
 const runs=new actual.CapabilityRunRegistry(f.store,sessions,{processes:reader,assertCurrent:s=>assert(f.sqlite.prepare('SELECT 1 FROM projects WHERE id=? AND archived_at IS NULL').get(s.projectId)),revoke:()=>{}});
 return{...f,sessions,runs,adapters};
}
