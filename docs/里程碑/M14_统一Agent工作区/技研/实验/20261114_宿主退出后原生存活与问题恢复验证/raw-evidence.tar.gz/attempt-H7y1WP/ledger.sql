CREATE TABLE IF NOT EXISTS m14_request_reply (
 id TEXT PRIMARY KEY, scope_json TEXT NOT NULL, scope_hash TEXT NOT NULL,
 native_json TEXT NOT NULL, owner_instance TEXT NOT NULL, owner_pid INTEGER NOT NULL,
 owner_birth TEXT NOT NULL, liveness TEXT NOT NULL, cancel_requested INTEGER NOT NULL DEFAULT 0,
 close_evidence TEXT
);
CREATE TABLE IF NOT EXISTS m14_response_decision (
 command_id TEXT PRIMARY KEY, request_id TEXT NOT NULL UNIQUE REFERENCES m14_request_reply(id),
 digest TEXT NOT NULL, value_json TEXT NOT NULL, delivery TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS m14_request_close_inbox (
 event_id TEXT PRIMARY KEY, request_id TEXT NOT NULL REFERENCES m14_request_reply(id),
 scope_hash TEXT NOT NULL, frame_json TEXT NOT NULL, frame_hash TEXT NOT NULL, processed INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS m14_request_retirement (request_id TEXT PRIMARY KEY REFERENCES m14_request_reply(id),evidence_json TEXT NOT NULL,evidence_hash TEXT NOT NULL);
