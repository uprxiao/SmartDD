import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {z} from 'zod';
import actual from './actual.cjs';
const privateHandles=new WeakMap(),canonical=actual.canonicalJson,hash=x=>actual.digest(canonical(x));
const scopeSchema=z.object({taskId:z.uuid(),bindingId:z.uuid(),runId:z.uuid(),generation:z.number().int().positive(),connectionId:z.uuid()}).strict();
const responseSchema=z.object({action:z.literal('accept'),content:z.object({label:z.string().min(1).max(24),count:z.number().int().min(1).max(3),enabled:z.boolean()}).strict()}).strict();
const row=(store,id)=>store.sqlite.prepare('SELECT * FROM m14_request_reply WHERE id=?').get(id),decision=(store,id)=>store.sqlite.prepare('SELECT * FROM m14_response_decision WHERE request_id=?').get(id);
const tx=(store,fn)=>actual.withResourceLock(store.root,()=>store.sqlite.transaction(fn).immediate());
export const initialize=store=>store.sqlite.exec(readFileSync(new URL('./ledger.sql',import.meta.url),'utf8'));
export function inspect(store,id){const r=row(store,id),d=decision(store,id);assert(r);return{request:r,decision:d??null,view:{awaitingUser:r.liveness==='open'&&!d&&!r.cancel_requested,awaitingNative:r.liveness==='open'&&!!d&&!r.cancel_requested,closed:r.liveness!=='open',decisionRecorded:!!d,delivery:d?.delivery??'none',consumption:'unproven'}};}
export async function bind(store,reader,scope,native,id=randomUUID()){
 scopeSchema.parse(scope);assert(native.threadId&&['string','number'].includes(typeof native.requestId));const identity=reader.read(process.pid);assert(identity&&reader.state(identity)==='running','OWNER_NOT_LIVE');return tx(store,()=>{
  store.sqlite.prepare("INSERT INTO m14_request_reply VALUES(?,?,?,?,?,?,?,'open',0,NULL)").run(id,canonical(scope),hash(scope),canonical(native),store.instanceId,identity.pid,identity.startedAt);const handle=Object.freeze({id});privateHandles.set(handle,{store,reader,identity,scopeHash:hash(scope),closed:false,dispatching:false});return handle;
 });
}
function own(store,handle){const c=privateHandles.get(handle),r=row(store,handle.id);assert(c&&c.store===store&&r&&r.owner_instance===store.instanceId&&r.owner_pid===c.identity.pid&&r.owner_birth===c.identity.startedAt&&r.scope_hash===c.scopeHash&&hash(JSON.parse(r.scope_json))===c.scopeHash,'RESPONSE_OWNER_CHANGED');assert.equal(c.reader.state(c.identity),'running','OWNER_NOT_LIVE');return{c,r};}
export async function decide(store,handle,command){return tx(store,()=>{const {r}=own(store,handle);assert.equal(hash(scopeSchema.parse(command.expected)),r.scope_hash,'REQUEST_SCOPE_CHANGED');const value=responseSchema.parse(command.value),digest=hash({requestId:r.id,expected:command.expected,value});const prior=store.sqlite.prepare('SELECT * FROM m14_response_decision WHERE command_id=?').get(command.id);if(prior){assert.equal(prior.digest,digest,'COMMAND_CONFLICT');return inspect(store,r.id);}assert.equal(r.liveness,'open','REQUEST_NOT_OPEN');assert(!r.cancel_requested,'REQUEST_CANCELLED');assert(!decision(store,r.id),'DECISION_ALREADY_RECORDED');store.sqlite.prepare("INSERT INTO m14_response_decision VALUES(?,?,?,?,'prepared')").run(command.id,r.id,digest,canonical(value));return inspect(store,r.id);});}
async function settle(store,handle,state){return tx(store,()=>{own(store,handle);const d=decision(store,handle.id);assert(d&&['dispatching','unknown','submitted'].includes(d.delivery),'NO_DISPATCH');if(d.delivery!=='submitted')store.sqlite.prepare('UPDATE m14_response_decision SET delivery=? WHERE request_id=?').run(state,handle.id);return inspect(store,handle.id);});}
export async function dispatch(store,handle,send,{checkpoint=async()=>{}}={}){
 const {c}=own(store,handle);assert(!c.dispatching,'DISPATCH_ALREADY_CLAIMED');c.dispatching=true;
 await tx(store,()=>{const {r}=own(store,handle),d=decision(store,r.id);assert(!c.closed&&r.liveness==='open'&&!r.cancel_requested&&d?.delivery==='prepared','REQUEST_NOT_DISPATCHABLE');store.sqlite.prepare("UPDATE m14_response_decision SET delivery='dispatching' WHERE request_id=?").run(r.id);});
 await checkpoint('intent');if(c.closed)return settle(store,handle,'not-sent');
 try{await send();await checkpoint('after-send');return await settle(store,handle,'submitted');}catch(e){await settle(store,handle,'unknown');throw e;}
}
export async function cancel(store,handle){const {c}=own(store,handle);c.closed=true;return tx(store,()=>{own(store,handle);store.sqlite.prepare("UPDATE m14_request_reply SET cancel_requested=1,liveness=CASE WHEN liveness='closed' THEN liveness ELSE 'expired' END WHERE id=?").run(handle.id);store.sqlite.prepare("UPDATE m14_response_decision SET delivery=CASE delivery WHEN 'prepared' THEN 'not-sent' WHEN 'dispatching' THEN 'unknown' ELSE delivery END WHERE request_id=?").run(handle.id);return inspect(store,handle.id);});}
function validateClose(r,frame){const native=JSON.parse(r.native_json);assert.equal(frame.method,'serverRequest/resolved','NOT_CLOSE_EVENT');assert(frame.params?.threadId===native.threadId&&frame.params?.requestId===native.requestId,'NATIVE_SCOPE_CHANGED');}
export async function journal(store,handle,frame){return tx(store,()=>{const {r}=own(store,handle);validateClose(r,frame);const eventId=hash({scope:r.scope_hash,frame}),prior=store.sqlite.prepare('SELECT * FROM m14_request_close_inbox WHERE event_id=?').get(eventId);if(!prior)store.sqlite.prepare('INSERT INTO m14_request_close_inbox VALUES(?,?,?,?,?,0)').run(eventId,r.id,r.scope_hash,canonical(frame),hash(frame));return eventId;});}
function applyLocked(store,id){const r=row(store,id),events=store.sqlite.prepare('SELECT * FROM m14_request_close_inbox WHERE request_id=?').all(id);assert.equal(hash(JSON.parse(r.scope_json)),r.scope_hash,'SCOPE_HASH_CHANGED');for(const e of events){assert.equal(e.scope_hash,r.scope_hash,'INBOX_SCOPE_CHANGED');const frame=JSON.parse(e.frame_json);assert.equal(hash(frame),e.frame_hash,'FRAME_CHANGED');validateClose(r,frame);}if(events.length){store.sqlite.prepare("UPDATE m14_request_reply SET liveness='closed',close_evidence=? WHERE id=?").run(events[0].event_id,id);store.sqlite.prepare("UPDATE m14_response_decision SET delivery=CASE delivery WHEN 'prepared' THEN 'not-sent' WHEN 'dispatching' THEN 'unknown' ELSE delivery END WHERE request_id=?").run(id);store.sqlite.prepare('UPDATE m14_request_close_inbox SET processed=1 WHERE request_id=?').run(id);}return inspect(store,id);}
export async function apply(store,handle){const {c}=own(store,handle);return tx(store,()=>{own(store,handle);const result=applyLocked(store,handle.id);if(result.view.closed)c.closed=true;return result;});}
export async function recover(store,reader,id){const before=row(store,id);assert(before);assert.equal(reader.state({pid:before.owner_pid,startedAt:before.owner_birth}),'stopped','OLD_OWNER_LIVE_OR_UNKNOWN');return tx(store,()=>{assert.equal(canonical(row(store,id)),canonical(before),'OWNER_RECORD_CHANGED');store.sqlite.prepare("UPDATE m14_request_reply SET liveness=CASE WHEN liveness='open' THEN 'expired' ELSE liveness END WHERE id=?").run(id);store.sqlite.prepare("UPDATE m14_response_decision SET delivery=CASE delivery WHEN 'prepared' THEN 'not-sent' WHEN 'dispatching' THEN 'unknown' ELSE delivery END WHERE request_id=?").run(id);return{...applyLocked(store,id),liveGrant:false,automaticRetry:false};});}

export async function bindRuntime(store,reader,scope,native,registry,run){
 assert.equal(registry.store,store,'RUN_STORE_CHANGED');actual.assertOwnedCapabilityRun(registry,run);
 const context=registry.assertActive(run.runId);assert.equal(context.run.taskId,scope.taskId,'RUN_TASK_CHANGED');assert.equal(run.runId,scope.runId,'RUN_ID_CHANGED');
 const handle=await bind(store,reader,scope,native);privateHandles.get(handle).runtime={registry,run,snapshotHash:context.run.snapshotHash};return handle;
}
export async function retire(store,handle,{checkpoint=()=>{}}={}){
 const {c}=own(store,handle);assert(c.runtime,'NO_RUNTIME_PROOF');
 return tx(store,()=>{
  const {r}=own(store,handle),scope=JSON.parse(r.scope_json),{registry,run,snapshotHash}=c.runtime;
  const current=registry.get(run.runId);assert.equal(current.runId,scope.runId,'RUN_ID_CHANGED');assert.equal(current.taskId,scope.taskId,'RUN_TASK_CHANGED');assert.equal(current.snapshotHash,snapshotHash,'RUN_SNAPSHOT_CHANGED');assert.equal(current.state,'stopped','RUN_NOT_STOPPED');
  assert(current.pid&&current.processStartedAt,'NO_NATIVE_IDENTITY');assert.equal(c.reader.state({pid:current.pid,startedAt:current.processStartedAt}),'stopped','NATIVE_NOT_STOPPED');
  const evidence={kind:'runtime-ended',scopeHash:r.scope_hash,runId:current.runId,pid:current.pid,processStartedAt:current.processStartedAt,endedAt:current.endedAt};
  const prior=store.sqlite.prepare('SELECT * FROM m14_request_retirement WHERE request_id=?').get(r.id);
  if(prior){assert.equal(prior.evidence_json,canonical(evidence),'RETIREMENT_CHANGED');}else store.sqlite.prepare('INSERT INTO m14_request_retirement VALUES(?,?,?)').run(r.id,canonical(evidence),hash(evidence));
  checkpoint('retirement-inserted');
  store.sqlite.prepare("UPDATE m14_request_reply SET liveness=CASE WHEN liveness='open' THEN 'expired' ELSE liveness END WHERE id=?").run(r.id);
  store.sqlite.prepare("UPDATE m14_response_decision SET delivery=CASE delivery WHEN 'prepared' THEN 'not-sent' WHEN 'dispatching' THEN 'unknown' ELSE delivery END WHERE request_id=?").run(r.id);
  c.closed=true;return inspect(store,r.id);
 });
}
