from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_通知发送与主动观察竞争验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and not r.get('error');a=Path(r['out']);sources={};outputs=[]
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:
  assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
cleanup=json.loads((a/'cleanup.json').read_text());assert len(cleanup['nativeExits'])==3 and all(x['code']==0 for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped' for x in cleanup['cleanup'])
models=json.loads((a/'model.json').read_text());assert len(models)==3
traces=[json.loads(l)for l in (a/'trace.jsonl').read_text().splitlines()];assert len([x for x in traces if x['event']=='native-request'and x['method']=='turn/start'])==3
for name in ['baseline','preserve-unknown','receipt-after-observation']:
 frames=[json.loads(l)for l in(a/(name+'-native.jsonl')).read_text().splitlines()]
 evidence=json.loads((a/({'baseline':'baseline-overwrite.json','preserve-unknown':'preserved-unknown.json','receipt-after-observation':'accepted-after-observation.json'}[name])).read_text())
 reply=evidence.get('actualNativeAcceptance')or json.loads(evidence['receipt']['frame_json'])
 assert any(f.get('id')==reply['requestId']and f.get('result')==reply['result'] for f in frames)
runtime={'attempt':a.name,'checks':4,'negativeControls':1,'nativeExits':cleanup['nativeExits'],'localMockModelRequests':len(models),'nativeNoticeTurns':3,'observation':'Direct host calls with actual private owner; seeded result bodies, not model-driven MCP in this batch.','receiptWindow':'Actual RPC response received by probe, deliberately withheld from durable host notice ledger.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[t3/'apps/server/src/orchestration-v2/ProviderContinuationService.ts',t3/'apps/server/src/mcp/OrchestratorMcpService.ts',repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/resource-lock.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'candidateOrigin':'Reused §4.57 candidate build with in-memory programmatic ownership/retention variants; product source untouched. Results.ack unchanged as negative control; FixedResults only in temporary directory.','t3Boundary':'T3 queues server continuation with parentRunId/generation and acknowledges task_status before returning. This experiment demonstrates a WillYou research-candidate bug, not a T3 production bug.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 通知实际发送与主动观察竞争

2026-11-14；R03／05／06／10／12，Q24／25／28。技术方案 §7.2.4，验证账 §4.62。研究与隔离候选修正，不是生产功能开发。

## 发现

§4.57 的 Results.ack 在任何通知状态下都写 disposed。之前只验证领取阶段竞争，没有覆盖实际发送之后的主动观察。本批 N01 在真实 Codex app-server turn/start 已接受通知、宿主尚未记录对应回执的窗口执行 read／ack，复现 sending 被覆盖；原 run 排空后 Provider 路由切换错误放行。

这是旧研究候选的缺陷，不是声称 SmartDD 或 T3 已有同一生产问题。负例和修正后的候选保留在同一归档，未修改两边仓库的产品源码。

## {a.name}：4 项检查

| 检查 | 实际证据 |
| --- | --- |
| N01 负对照 | 原候选在真实通知接受后，结果 ack 抹掉 sending；停止原生 run 后 switch 通过。保留前后数据库行及真实 RPC 回执 |
| N02 修正 | 观察写入一次，但 sending 保留；停止实际 run 后仍阻止 switch，对账改 unknown 后仍阻止；仅夹具显式处置通知后才可继续 |
| N03 未发送 | 自动领取后主动读／ack 令旧 claim 失效；旧 markDispatch 拒绝，实际 turn/start 数不增加 |
| N04 回执后到 | 主动 ack 后才记录实际原生接受回执，通知记 delivered；回执同内容重放幂等、冲突及错误 token／复制句柄拒绝；再 ack 不覆盖回执，原 run 停止后允许切换 |

三个原生进程均为固定 Codex 0.167.1，经实际程序化 owner、冻结执行计划及 gated launcher 启动；全部捕获退出码 0，三个 run stopped。三个本机模拟模型请求被保持未完成后随自己的 run 结束；无外部模型、真实子任务或业务写入。结果正文是 seeded 合成数据，read／ack 由驱动经私有 owner 直接调用，不声称本批包含实际模型工具读取。

## 设计收口

结果 observed 和通知传输是两个事实。主动观察只可取消 pending／claimed 的未发送通知；sending／unknown／已接受的投递证据必须保留。迟到接受回执只能补充原通知 attempt 的精确证据，不能转给新 binding／generation，也不能当作业务完成或真人授权。

修正只缩小 ack 的更新条件，没有重建第二套结果正文或自动重新委派。N04 的 nativeAccepted 是研究用可信适配器入口，调用点持有原私有 run 和真实 RPC 回复；它不是可让 renderer／模型自由提交 JSON 的公共 API，最终入口仍须和不可伪造发送句柄／持久 inbox 合并设计。delivered 在此仅代表 turn/start 已被原生接受，不代表模型完成处理或任务树完成。

N02 的显式处置仍使用 fixture-explicit-stop-notification；它不是实际用户授权 UI。实际 socket 部分写入、宿主在回执落库中途退出、旧 owner 停止后迟到回执、父忙排队、Claude 对应竞争及完整私有业务 MCP 链尚未在本批执行。既有局部证据不合并宣称端到端通过。

## T3 对照和证据

本地 ProviderContinuationService 用 queue_after_active，并携带 parentRunId／generation／messageId；OrchestratorMcpService 的终态 task_status 在返回前派发 completion-delivery.acknowledge。WillYou 的独立观察 token 属于候选扩展，本批不把它说成 T3 的接口。

[结果](result.json)、[运行审计](runtime-audit.json)、[源码依据](source-review.json)、[摘要](archive-manifest.json)、[原始驱动／帧／数据库](raw-evidence.tar.gz)。归档 {len(files)} 个文件，{len(dbs)} 份 SQLite 完整性／外键通过，{len(sources)} 个构建输入核对当前源码；二进制按 native-inputs 固定 SHA 校验，未打入归档。

复跑：准备归档中的依赖路径与固定本机二进制后执行 node probe.mjs。只结束脚本自己捕获的子进程，不读取日常 HOME／凭据，不连接公网模型。
''')
section='''#### 7.2.4 已读不能覆盖在途通知

[通知发送竞争实验](实验/20261114_通知发送与主动观察竞争验证/README.md)补到真实 Codex turn/start：原生已接受通知、宿主回执尚未落库时，旧候选的 read／ack 会把 sending 改成 disposed，导致原 run 停止后绕过通知未知检查。该缺陷属于旧研究候选，已在隔离候选修正；不能直接照搬 §7.2.2 早期实验的 ack 实现。

结果观察与通知发送独立更新。ack 只可结束 pending／claimed 的未发送通知；对 sending／unknown 只记结果已观察，保留原 attempt、目标 run／binding／generation、发送状态及阻塞原因。原生接受回执后到时核对原发送所有权及对应原始 RPC，幂等记录已接受事实，后续 ack 不覆盖它。原生接受、模型处理结束、结果已读与任务树完成不能共用一个 done。

未发送的旧 claim 失效后不能再派发；已发送而未知的通知即便结果已读、原进程 stopped，仍须对账或通过可信用户入口明确停止后续通知。不得凭已读自动重发、自动换 Provider 或重复创建子任务。若同一通知已有精确接受回执且原运行排空，则这项通知的未知阻塞解除，其他运行／目录／业务约束继续检查。

本批用三个真实 Codex 通知回合和直接宿主 read／ack 制造交错；不包含模型驱动的结果工具读取、Claude 对应竞争或真实 UI。回执入口还是隔离适配器方法，生产须与私有发送句柄及持久 inbox 联合；部分 socket、回执落库期间宿主退出、旧 owner 停止后的迟到证据和完整业务链继续验证。

'''
def tech(t):
 assert '#### 7.2.4 'not in t;t=t.replace('### 7.3 Skill 交付、更新与调用来源',section+'### 7.3 Skill 交付、更新与调用来源')
 t=t.replace('宿主崩溃、部分回包、真实消费后确认丢失和自动通知的同时发送仍需按相同身份和状态合同核验。','§7.2.4 已补 Codex 通知实际发送与直接宿主观察的交错；宿主崩溃、部分回包、真实消费后确认丢失和完整链仍按相同身份合同核验。');return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.62 通知实际发送与主动观察竞争

[通知竞争实验](实验/20261114_通知发送与主动观察竞争验证/README.md)N01–04 通过，其中 N01 是缺陷负对照。三个真实 Codex turn/start、本机模拟模型和实际私有 owner／执行计划，复现旧候选结果 ack 覆盖 sending 并错误放行切换；隔离修正只允许取消未发送通知，保持已读与投递分开，保留 unknown 的切换阻塞，并核对迟到的真实接受回执及其幂等性。

三个 native 退出码均 0；三次本机模型请求，无真实模型／子任务／业务写入。read／ack 为直接宿主调用，不是本批模型工具行为；真实业务桥、Claude 对应交错、部分 socket／宿主退出及最终可信回执入口仍待验。技术方案 §7.2.4 已收口，不提升为完整委派链或产品完成。

'''
def ledger(t):
 assert '### 4.62 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正')
 lines=t.splitlines()
 for q in ['Q24','Q25','Q28']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.62 补实际 Codex 通知与直接宿主观察交错，修正已读覆盖在途通知反例；完整业务链及 Claude 对应窗口仍待验 |'
 t='\n'.join(lines)+'\n'
 t=t.replace('（§4.57 已补真实忙碌回合及领取阶段，真实通知消费仍缺）','（§4.57 补忙碌回合及领取，§4.62 补真实 Codex 通知与直接观察交错；Claude／完整工具链及回执落库退出仍缺）')
 marker='| native-a1 |';i=t.index(marker);t=t[:i]+'| notice-race N01 | 旧研究候选 ack 无条件结束通知，真实 Codex 发送窗口中覆盖 sending 并误放行切换；限定只结束未发送状态，N02–04 对照通过 | 非 SmartDD／T3 生产缺陷；原生回执入口仍为隔离候选 |\n'+t[i:];return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：真实 Codex 通知与主动观察交错复现旧候选“已读覆盖在途发送”缺陷；隔离修正保留独立投递状态、未知切换阻塞与幂等原生回执，见[技术方案 §7.2.4](技研/技术方案.md)。仅研究验证，产品未改。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：继续现有业务私有桥与程序化 owner 联合；通知／观察复用本轮独立状态合同，补 Claude 与回执恢复关键窗口。其他责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
