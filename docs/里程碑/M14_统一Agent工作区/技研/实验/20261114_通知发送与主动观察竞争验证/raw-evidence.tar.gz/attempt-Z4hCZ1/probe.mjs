import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,readFileSync,writeFileSync,appendFileSync,copyFileSync,readdirSync} from 'node:fs';
import actual from './candidate.cjs';import {setup} from './fixture.mjs';import {profiles} from './joint.mjs';
import {baseEnv,nativeRuntime} from './native-inputs.mjs';import {prepareExecution} from './execution.mjs';
import {createLaunch,start,cancel,deferred,state} from './launch.mjs';import {codex} from './codex.mjs';
import {Results} from './result.mjs';import {FixedResults} from './fixed.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],trace=[],launches=[],models=[],gates=[];
const save=(name,value)=>writeFileSync(out+'/'+name,JSON.stringify(value,null,2)+'\n');
for(const n of readdirSync(root).filter(n=>/\.(mjs|cjs|json|sql|ts|variant)$/.test(n)))copyFileSync(root+'/'+n,out+'/'+n);
const mark=(id,event,data={})=>{const x={id,event,...data};trace.push(x);appendFileSync(out+'/trace.jsonl',JSON.stringify(x)+'\n');};
const deadline=(p,label)=>{let t;return Promise.race([p,new Promise((_,reject)=>t=setTimeout(()=>reject(Error('OBSERVATION_TIMEOUT:'+label)),25000))]).finally(()=>clearTimeout(t));};
let f,server,base,error;
const notice=id=>f.sqlite.prepare('SELECT * FROM notice WHERE result_id=?').get(id);
const result=id=>f.sqlite.prepare('SELECT * FROM child_result WHERE id=?').get(id);
async function parent(id){
 const run=await f.reserve(1);await run.prepare();const p={...f,run,runs:f.programmaticRuns,snapshot:f.snapshots[1],scope:f.scopes[1],profile:f.profiles.codex,adapter:f.adapters.get('codex'),runtime:nativeRuntime('codex')};
 p.baseEnv=baseEnv(p);p.researchBase=base;const plan=await prepareExecution(p,p.runtime),launch=createLaunch(p,plan,{mark:(e,d)=>mark(id,e,d)});launches.push({id,launch});
 const v=await start(launch,codex(out,p,id,(e,d)=>mark(id,e,d)));await deadline(v.attached,id+' attach');const info=await deadline(v.runtime.ready(),id+' init');save(id+'-init.json',info);return{...p,launch,native:v.runtime};
}
async function dispatched(p,store,id){
 const thread=await deadline(p.native.rpc('thread/start',{cwd:p.snapshot.native.cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'never',sandbox:'read-only'}),'thread');
 const claim=await store.claim(p.run,id);assert.equal(claim.status,'claimed');await store.markDispatch(p.run,id,claim.token);
 const gate={entered:deferred(),res:null};gates.push(gate);
 const reply=await deadline(p.native.rpc('turn/start',{threadId:thread.result.thread.id,clientUserMessageId:randomUUID(),input:[{type:'text',text:'ISOLATED_SERVER_NOTICE '+id+'; result available; no tools needed in this transport probe',text_elements:[]}]}),'notice native acceptance');
 await deadline(gate.entered.promise,'local model entered');f.sqlite.prepare('UPDATE route SET turn_busy=1 WHERE task_id=?').run(f.logicalTaskId);
 assert.equal(notice(id).state,'sending');return{claim,reply,gate,threadId:thread.result.thread.id};
}
async function drain(p,g){g?.res?.destroy();await deadline(cancel(p.launch),'owned native drain');assert.equal(state(p.launch).runState,'stopped');}
async function switchAway(store){await store.switch(f.logicalTaskId,f.scopes[0].bindingId);}
async function back(store){await store.switch(f.logicalTaskId,f.scopes[1].bindingId);}
async function check(id,title,fn){try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save('progress.json',{checks});if(f){assert.deepEqual(f.sqlite.pragma('integrity_check'),[{integrity_check:'ok'}]);assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);await f.sqlite.backup(out+'/'+id+'.sqlite');}console.log(JSON.stringify(checks.at(-1)));}}
try{
 server=createServer(async(req,res)=>{let text='';for await(const b of req)text+=b;models.push(JSON.parse(text));const gate=gates.find(g=>!g.res);assert(gate,'UNPLANNED_MODEL_REQUEST');gate.res=res;gate.entered.resolve();});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
 f=await setup(new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'));profiles(f);f.sqlite.exec(readFileSync(root+'/result.sql','utf8'));f.sqlite.exec('CREATE TABLE notice_acceptance(token TEXT PRIMARY KEY,result_id TEXT NOT NULL,run_id TEXT NOT NULL,frame_json TEXT NOT NULL,frame_hash TEXT NOT NULL);');f.sqlite.prepare('INSERT INTO route VALUES(?,?,1,0)').run(f.logicalTaskId,f.scopes[1].bindingId);
 const old=new Results(f),fixed=new FixedResults(f);
 await check('N01','negative control: original candidate observation erases actual in-flight notice',async()=>{
  const p=await parent('baseline'),id=randomUUID();await old.seed(f.logicalTaskId,id,'SYNTHETIC_BASELINE_RESULT');const x=await dispatched(p,old,id),before=notice(id);
  const o=await old.read(p.run,id);await old.ack(p.run,id,o.token,o.revision);assert.equal(notice(id).state,'disposed');assert.equal(result(id).ack_count,1);
  save('baseline-overwrite.json',{before,after:notice(id),actualNativeAcceptance:x.reply,hostAcceptanceNotPersisted:true});
  await drain(p,x.gate);await switchAway(old);await back(old);
  return{defectReproduced:true,nativeTurnActuallyAccepted:true,hostReceiptWithheld:true,observationErasesSending:true,providerSwitchIncorrectlyAllowed:true};
 });
 await check('N02','corrected candidate retains unresolved dispatch after observation and native drain',async()=>{
  const p=await parent('preserve-unknown'),id=randomUUID();await fixed.seed(f.logicalTaskId,id,'SYNTHETIC_UNKNOWN_RESULT');const x=await dispatched(p,fixed,id),o=await fixed.read(p.run,id);
  await assert.rejects(fixed.ack({...p.run},id,o.token,o.revision),e=>e.code==='SCOPE_DENIED');await fixed.ack(p.run,id,o.token,o.revision);assert.equal(notice(id).state,'sending');assert.equal(result(id).ack_count,1);
  await drain(p,x.gate);await assert.rejects(switchAway(fixed),/NOTICE_UNRESOLVED/);await fixed.reconcileNotice(f.logicalTaskId,id);assert.equal(notice(id).state,'unknown');await assert.rejects(switchAway(fixed),/NOTICE_UNRESOLVED/);
  save('preserved-unknown.json',{notice:notice(id),result:result(id),actualNativeAcceptance:x.reply,hostAcceptanceNotPersisted:true});
  await fixed.disposeNotice(f.logicalTaskId,id,'fixture-explicit-stop-notification');assert.equal(result(id).ack_count,1);await switchAway(fixed);await back(fixed);
  return{observationPreserved:true,sendingPreserved:true,stoppedDoesNotProveUnsent:true,unknownBlocksSwitch:true,explicitFixtureDispositionRequired:true};
 });
 const p=await parent('receipt-after-observation');
 await check('N03','read and ack before dispatch invalidate old claim without another native turn',async()=>{
  const id=randomUUID();await fixed.seed(f.logicalTaskId,id,'SYNTHETIC_UNSENT_RESULT');const c=await fixed.claim(p.run,id),before=trace.filter(x=>x.event==='native-request'&&x.method==='turn/start').length,o=await fixed.read(p.run,id);await fixed.ack(p.run,id,o.token,o.revision);
  await assert.rejects(fixed.markDispatch(p.run,id,c.token),/NOTICE_CLAIM_CHANGED/);assert.equal(notice(id).state,'disposed');assert.equal(trace.filter(x=>x.event==='native-request'&&x.method==='turn/start').length,before);return{oldClaimInvalid:true,noAdditionalTurn:true};
 });
 await check('N04','actual delayed acceptance receipt survives prior observation and is idempotent',async()=>{
  const id=randomUUID();await fixed.seed(f.logicalTaskId,id,'SYNTHETIC_ACCEPTED_RESULT');const x=await dispatched(p,fixed,id),o=await fixed.read(p.run,id);await fixed.ack(p.run,id,o.token,o.revision);assert.equal(notice(id).state,'sending');
  await assert.rejects(fixed.nativeAccepted(p.run,id,randomUUID(),x.reply),/NOTICE_SCOPE_CHANGED/);await assert.rejects(fixed.nativeAccepted({...p.run},id,x.claim.token,x.reply),e=>e.code==='SCOPE_DENIED');
  assert.equal((await fixed.nativeAccepted(p.run,id,x.claim.token,x.reply)).replay,false);assert.equal((await fixed.nativeAccepted(p.run,id,x.claim.token,x.reply)).replay,true);
  await assert.rejects(fixed.nativeAccepted(p.run,id,x.claim.token,{...x.reply,requestId:x.reply.requestId+99}),/NATIVE_RECEIPT_CONFLICT/);
  assert.equal(notice(id).state,'delivered');await fixed.ack(p.run,id,o.token,o.revision);assert.equal(notice(id).state,'delivered');assert.equal(result(id).ack_count,1);
  save('accepted-after-observation.json',{notice:notice(id),result:result(id),receipt:f.sqlite.prepare('SELECT * FROM notice_acceptance WHERE token=?').get(x.claim.token)});
  await drain(p,x.gate);await switchAway(fixed);return{nativeAcceptanceSeparateFromObservation:true,oneReceipt:true,receiptReplayIdempotent:true,lateObservationDoesNotEraseReceipt:true,knownDeliveryAndStoppedOwnerPermitSwitch:true};
 });
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 for(const g of gates)g.res?.destroy();const cleanup=[];
 if(f){for(const {id,launch}of [...launches].reverse())try{await deadline(cancel(launch),'cleanup '+id);cleanup.push({id,state:state(launch)});}catch(e){error??=e.stack;process.exitCode=1;cleanup.push({id,error:e.stack});}
 for(const h of f.handles)if(!['stopped','failed'].includes(f.programmaticRuns.get(h.runId).state))await h.stop('cleanup');await f.sqlite.backup(out+'/final.sqlite');save('fixture.json',{root:f.root,db:f.sqlite.name,taskId:f.logicalTaskId,bindings:f.scopes});f.sqlite.close();}
 if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}save('cleanup.json',{cleanup,nativeExits:trace.filter(x=>x.event==='owned-exit')});save('model.json',models);
}
const summary={out,checks,passed:checks.filter(x=>x.status==='passed').length,error,scope:'Actual Codex native turn/start and current private programmatic owner; seeded results, direct host read/ack calls, controlled local model response withheld and host acceptance write delayed. Original candidate defect reproduced and minimal isolated candidate correction verified. No real model, child task, business effect, actual UI or production code.'};save('result.json',summary);writeFileSync(root+'/latest.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({out,passed:summary.passed,error}));
