import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,appendFileSync,existsSync,realpathSync,statSync,globSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {library,helper,Database,save,nativeTurn} from './native.mjs';
const root=import.meta.dirname,hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const readTool='smartdd_zentao_query_v1',writeTool='smartdd_zentao_write_v1';
const skillName='willyou-collaboration-probe',marker='WY_COLLAB_RULESET_1';
const skillText=`---\nname: ${skillName}\ndescription: Reusable isolated collaboration method\n---\n${marker}\nRead the allowed target catalogue through the host before delegating. Select only the configured target and its current revision. Submit the delegate operation once. For a shared workspace, accept waiting_parent_release and end this turn so the host can release the directory. A completion notice is not the result: read the result, then explicitly acknowledge its observation token. Disabled or stale targets must not be silently replaced. These rules grant no business permissions.\n`;
function queue(dir){const db=new Database(dir+'/queue.sqlite');db.pragma('journal_mode=WAL');db.pragma('synchronous=FULL');db.exec(`
 CREATE TABLE IF NOT EXISTS delegation(id TEXT PRIMARY KEY,parent_task TEXT NOT NULL,child_task TEXT NOT NULL,state TEXT NOT NULL,result TEXT,result_hash TEXT);
 CREATE TABLE IF NOT EXISTS notice(id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL UNIQUE,state TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS observation(delegation_id TEXT NOT NULL,run_id TEXT NOT NULL,token TEXT NOT NULL UNIQUE,state TEXT NOT NULL,ack_count INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(delegation_id,run_id));
 CREATE TABLE IF NOT EXISTS receipts(round_id TEXT NOT NULL,phase TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(round_id,phase));
 CREATE TABLE IF NOT EXISTS lease(singleton INTEGER PRIMARY KEY CHECK(singleton=1),run_id TEXT NOT NULL,state TEXT NOT NULL,scope TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL,body TEXT NOT NULL);
 `);return db;}
const scope=wc=>{const real=realpathSync(wc),s=statSync(real);assert(existsSync(real+'/.svn'));return{real,dev:String(s.dev),ino:String(s.ino)};};
const state=db=>Object.fromEntries(['delegation','notice','observation','receipts','lease','events'].map(t=>[t,db.prepare('SELECT * FROM '+t).all()]));
async function worker(dir,index){
 const spec=JSON.parse(readFileSync(dir+'/spec.json')),round=spec.rounds[index],parent=spec.parent,child=spec.children[index],db=queue(dir),roundDir=dir+'/'+round.id;mkdirSync(roundDir);
 const {MacProcessIdentityReader}=library(parent.driver),reader=new MacProcessIdentityReader(helper);let targetEnabled=true,firstParentThread;
 const tx=fn=>db.transaction(fn).immediate(),mark=(event,body={})=>db.prepare('INSERT INTO events(event,body) VALUES(?,?)').run(event,JSON.stringify({round:round.id,hostPid:process.pid,...body}));mark('host-open');
 const assertLease=runId=>{assert.deepEqual(scope(spec.workspace),spec.scope);const row=db.prepare('SELECT * FROM lease WHERE singleton=1').get();assert.equal(row?.run_id,runId);assert.equal(row?.state,'held');};
 const getReceipt=(id,phase)=>JSON.parse(db.prepare('SELECT value FROM receipts WHERE round_id=? AND phase=?').get(id,phase).value);
 const drained=(id,phase,actor)=>{const r=getReceipt(id,phase),sql=new Database(actor.root+'/state.sqlite',{readonly:true});try{assert.equal(sql.prepare('SELECT state FROM capability_runs WHERE run_id=?').get(r.runId).state,'stopped');assert.equal(sql.prepare("SELECT COUNT(*) n FROM capability_resource_leases WHERE owner_id=? AND state<>'released'").get(r.runId).n,0);for(const p of sql.prepare('SELECT pid,process_started_at AS startedAt FROM capability_run_processes WHERE run_id=? AND pid IS NOT NULL').all(r.runId))assert.equal(reader.state(p),'stopped');return r;}finally{sql.close();}};
 async function phase(name){
  const actor=name==='child'?child:parent,selectedSkill=name==='parent'?spec.skill:undefined,duplicated=round.duplicateObservation&&name==='resume';
  const modelCount=name==='parent'?(actor.driver==='claude'?4:3):name==='child'?2:duplicated?5:3,toolCount=name==='parent'?2:name==='child'?1:duplicated?4:2;
  const input=name==='parent'?'Use the selected collaboration Skill for RUN_CASE_'+round.id:name==='child'?'Complete assigned synthetic work for '+round.id:'SERVER_COMPLETION_NOTICE '+round.id+' is terminal. Read its result through the host.';
  const answer=name==='parent'?(round.invalidTarget?'TARGET_BLOCKED':'WAITING_CHILD'):name==='child'?'CHILD_COMPLETE':'RESULT_CONFIRMED';
  if(name==='resume'){const row=db.prepare('SELECT * FROM delegation WHERE id=?').get(round.id);assert.equal(row.state,'result_ready');db.prepare("INSERT INTO notice VALUES(?,?,'sending')").run('notice-'+round.id,round.id);assert(!input.includes(row.result));mark('notice-queued-without-result');}
  let firstBody,previousBody,observedToken,ownedRun;
  const result=await nativeTurn(actor,name,{dir:roundDir+'/'+name,delegationId:round.id,input,answer,skill:selectedSkill,expectedModels:modelCount,expectedTools:toolCount,
   acquire:runId=>tx(()=>{assert(db.prepare('SELECT state FROM lease WHERE singleton=1').get()?.state!=='held');if(name==='child')drained(round.id,'parent',parent);if(name==='resume')drained(round.id,'child',child);ownedRun=runId;assert.equal(hash(spec.skill.path+'/SKILL.md'),spec.skill.sha256);db.prepare("INSERT INTO lease VALUES(1,?,'held',?) ON CONFLICT(singleton) DO UPDATE SET run_id=excluded.run_id,state='held'").run(runId,JSON.stringify(spec.scope));mark('acquire',{name,runId,taskId:actor.taskId});}),assertLease,
   execute:call=>tx(()=>{
    assertLease(call.runId);const op=JSON.parse(call.value);mark('tool-operation',{name,op:op.action,runId:call.runId,operationId:call.operationId});
    if(op.action==='capabilities'){
     assert.equal(name,'parent');assert.equal(call.toolName,readTool);if(round.invalidTarget)targetEnabled=false;
     return JSON.stringify({targetId:spec.targetId,driver:child.driver,revision:1,available:true,rule:marker});
    }
    assert.equal(call.toolName,writeTool);
    if(op.action==='delegate'){
     assert.equal(name,'parent');assert.equal(op.targetId,spec.targetId);assert.equal(op.revision,1);if(!targetEnabled){mark('target-revision-rejected');return JSON.stringify({status:'blocked',code:'TARGET_UNAVAILABLE',fallback:false});}
     db.prepare("INSERT INTO delegation VALUES(?,?,?,'queued',NULL,NULL)").run(round.id,parent.taskId,child.taskId);assert.equal(db.prepare('SELECT state FROM lease WHERE singleton=1').get().state,'held');mark('delegate-persisted-waiting-parent-release');return JSON.stringify({status:'waiting_parent_release',delegationId:round.id});
    }
    if(op.action==='work'){
     assert.equal(name,'child');drained(round.id,'parent',parent);writeFileSync(spec.workspace+'/'+round.id+'.txt','CHILD_DONE_'+round.id+'\n',{flag:'wx'});mark('synthetic-write');return'CHILD_DONE_'+round.id;
    }
    assert.equal(name,'resume');assert.equal(op.delegationId,round.id);assert.equal(call.taskId,parent.taskId);const d=db.prepare('SELECT * FROM delegation WHERE id=?').get(round.id);assert(d&&d.state==='result_ready');
    if(op.action==='read_result'){
     let row=db.prepare('SELECT * FROM observation WHERE delegation_id=? AND run_id=?').get(round.id,call.runId);if(!row){row={token:randomUUID()};db.prepare("INSERT INTO observation VALUES(?,?,?,'offered',0)").run(round.id,call.runId,row.token);}observedToken=row.token;mark('result-offered',{token:row.token});return JSON.stringify({result:d.result,revision:d.result_hash,observationToken:row.token});
    }
    assert.equal(op.action,'ack_result');const row=db.prepare('SELECT * FROM observation WHERE delegation_id=? AND run_id=? AND token=?').get(round.id,call.runId,op.token);assert(row,'observation token cannot move to another run');assert.equal(op.revision,d.result_hash);
    if(row.state!=='observed')db.prepare("UPDATE observation SET state='observed',ack_count=ack_count+1 WHERE token=?").run(row.token);mark('result-acknowledged',{token:row.token,duplicate:row.state==='observed'});return JSON.stringify({status:'observed',token:row.token});
   }),
   model:async({driver,body,tools,count,mark:trace})=>{
    const content=JSON.stringify(body.messages??body.input),call=(action,payload={},read=false)=>({tool:tools.find(t=>((t.namespace??'')+(t.name??'')).includes(read?readTool:writeTool)),args:{value:JSON.stringify({action,...payload})}});
    if(name==='parent'){
     if(count===1){firstBody=body;if(driver==='claude'){const tool=tools.find(t=>t.name==='Skill');assert(tool);return{tool,args:{skill:spec.skill.name}};}}
     const at=driver==='claude'?count-1:count;
     if(at===1){
      let fresh;if(driver==='claude'){const blocks=body.messages.slice(firstBody.messages.length).flatMap(m=>Array.isArray(m.content)?m.content:[]),invoke=blocks.find(b=>b.type==='tool_use'&&b.name==='Skill');assert(invoke);assert(blocks.some(b=>b.type==='tool_result'&&b.tool_use_id===invoke.id&&!b.is_error));fresh=blocks.filter(b=>b.type==='text').map(b=>b.text).join('\n');}
      else{const texts=body.input.flatMap((item,i)=>(item.content??[]).filter(c=>c.type==='input_text').map(c=>({i,text:c.text}))),selected=texts.findLast(t=>t.text.startsWith('<skill>'));assert(selected);const current=texts.findLast(t=>t.text.includes('RUN_CASE_'+round.id));assert(current&&selected.i>=current.i);fresh=selected.text;}
      assert(fresh.includes(marker));trace('fresh-skill-body-verified',{sha256:spec.skill.sha256});return call('capabilities',{},true);
     }
     if(at===2){assert(content.includes(spec.targetId));assert(content.includes(marker));return call('delegate',{targetId:spec.targetId,revision:1});}
     assert(content.includes(round.invalidTarget?'TARGET_UNAVAILABLE':'waiting_parent_release'));return{text:answer};
    }
    if(name==='child'){if(count===1)return call('work');assert(content.includes('CHILD_DONE_'+round.id));return{text:answer};}
    if(count===1){firstBody=body;assert(content.includes(input));assert(!content.includes('CHILD_DONE_'+round.id));assert.equal(db.prepare('SELECT COUNT(*) n FROM observation WHERE delegation_id=?').get(round.id).n,0);db.prepare("UPDATE notice SET state='accepted' WHERE delegation_id=?").run(round.id);mark('notice-accepted-not-result-observed');return call('read_result',{delegationId:round.id});}
    assert(content.includes('CHILD_DONE_'+round.id));assert(content.includes(observedToken));const d=db.prepare('SELECT * FROM delegation WHERE id=?').get(round.id),obs=db.prepare('SELECT * FROM observation WHERE delegation_id=?').get(round.id);
    if(duplicated&&count===2){assert.equal(obs.state,'offered');return call('read_result',{delegationId:round.id});}
    if(count===(duplicated?3:2)){assert.equal(obs.state,'offered');trace('actual-result-return-observed');return call('ack_result',{delegationId:round.id,token:observedToken,revision:d.result_hash});}
    if(duplicated&&count===4){assert.equal(obs.state,'observed');return call('ack_result',{delegationId:round.id,token:observedToken,revision:d.result_hash});}
    assert.equal(obs.ack_count,1);return{text:answer};
   },
   release:receipt=>tx(()=>{assertLease(receipt.runId);db.prepare('INSERT INTO receipts VALUES(?,?,?)').run(round.id,name,JSON.stringify(receipt));db.prepare("UPDATE lease SET state='released' WHERE singleton=1").run();mark('release',{name,runId:receipt.runId});if(name==='child'){const text=readFileSync(spec.workspace+'/'+round.id+'.txt','utf8').trim();db.prepare("UPDATE delegation SET state='result_ready',result=?,result_hash=? WHERE id=?").run(text,createHash('sha256').update(text).digest('hex'),round.id);}if(name==='resume'){assert.equal(db.prepare('SELECT state FROM observation WHERE delegation_id=?').get(round.id).state,'observed');db.prepare("UPDATE delegation SET state='done' WHERE id=?").run(round.id);}})
  });return result;
 }
 try{
  const p=await phase('parent');if(index>0)assert.equal(p.thread,getReceipt(spec.rounds[0].id,'parent').thread);
  if(round.invalidTarget){assert(!db.prepare('SELECT 1 FROM delegation WHERE id=?').get(round.id));assert(!existsSync(spec.workspace+'/'+round.id+'.txt'));mark('invalid-target-no-child-or-fallback');}
  else{await phase('child');const resumed=await phase('resume');assert.equal(p.thread,resumed.thread);assert.notEqual(p.rootPid,resumed.rootPid);const observation=db.prepare('SELECT * FROM observation WHERE delegation_id=?').get(round.id);assert.equal(observation.ack_count,1);}
  assert.equal(hash(spec.skill.path+'/SKILL.md'),spec.skill.sha256);save(roundDir+'/result.json',{status:'passed',parentDriver:parent.driver,childDriver:child.driver,round,...state(db)});process.send?.({done:true});
 }catch(e){save(roundDir+'/failure.json',{error:e.stack,state:state(db)});throw e;}finally{db.close();}
}
function local(command,args,cwd,home){const r=spawnSync(command,args,{cwd,env:{PATH:'/usr/bin:/bin',HOME:home},encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout;}
async function seed(driver,workspace){const {runFixture,MacProcessIdentityReader}=library(driver),f=await runFixture(new MacProcessIdentityReader(helper),{application:true,runtime:readFileSync(root+'/mcp-bridge.cjs'),workspace}),extraHashes=Object.fromEntries(f.sqlite.prepare("SELECT resource_id,content_hash FROM capability_resources WHERE kind IN ('fixture-dependency','agent-adapter')").all().map(r=>[r.resource_id,r.content_hash]));const actor={driver,root:f.root,home:f.home,taskId:f.snapshot.taskId,workspace,extraHashes,snapshot:f.snapshot};f.sqlite.close();return actor;}
if(process.argv[2]==='--worker'){worker(process.argv[3],Number(process.argv[4])).then(()=>process.disconnect(),e=>{console.error(e.stack);process.exitCode=1;process.disconnect();});}
else{
 const out=mkdtempSync(root+'/attempt-'),checks=[],hosts=[];for(const f of ['build.mjs','build.json','native.mjs','probe.mjs'])copyFileSync(root+'/'+f,out+'/'+f);let error;
 try{for(const driver of ['claude','codex']){
  if(process.argv[2]&&process.argv[2]!==driver)continue;const dir=out+'/'+driver;mkdirSync(dir);const workspace=dir+'/wc';local('/opt/homebrew/bin/svnadmin',['create',dir+'/repo'],dir,out);local('/opt/homebrew/bin/svn',['checkout','file://'+dir+'/repo',workspace],dir,out);
  const parent=await seed(driver,workspace),childDriver=driver==='claude'?'codex':'claude',children=[];for(let i=0;i<3;i++)children.push(await seed(childDriver,workspace));const {syncAgentSkillLibrary}=library(driver);
  const sync=syncAgentSkillLibrary({home:parent.home,targets:[{agentId:driver==='claude'?'claude-code':'codex',readsSharedAgentSkills:driver==='codex',...(driver==='claude'?{skillDirectory:'.claude/skills'}:{})}],skills:[{name:skillName,executables:new Set(),files:{'SKILL.md':Buffer.from(skillText)}}]});assert.equal(sync.conflicts.length,0);assert.deepEqual(sync.written,[skillName]);
  const skill={name:skillName,path:parent.home+'/.agents/skills/'+skillName,sha256:hash(parent.home+'/.agents/skills/'+skillName+'/SKILL.md')},rounds=[{id:randomUUID(),duplicateObservation:false,invalidTarget:false},{id:randomUUID(),duplicateObservation:true,invalidTarget:false},{id:randomUUID(),duplicateObservation:false,invalidTarget:true}],spec={workspace,scope:scope(workspace),parent,children,rounds,skill,targetId:'TARGET_'+randomUUID()};save(dir+'/spec.json',spec);save(dir+'/skill-sync.json',sync);writeFileSync(dir+'/SKILL.md',skillText);
  for(let i=0;i<3;i++){
   const p=spawn(process.execPath,[import.meta.filename,'--worker',dir,String(i)],{stdio:['ignore','pipe','pipe','ipc'],env:{PATH:'/usr/bin:/bin',HOME:out}});let done=false,stderr='';p.on('message',m=>{done=m.done===true;});p.stderr.on('data',b=>{stderr+=b;appendFileSync(dir+'/worker.stderr',b);});const ended=await new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',(code,signal)=>resolve({code,signal}));});hosts.push({pid:p.pid,...ended,done});assert.equal(ended.code,0,stderr);assert(done);const r=JSON.parse(readFileSync(dir+'/'+rounds[i].id+'/result.json'));assert.equal(r.status,'passed');const result={id:driver+'-'+(i===0?'initial':i===1?'reopened-repeat-observation':'target-disabled'),status:'passed',roundId:rounds[i].id,skillHash:skill.sha256};checks.push(result);console.log(JSON.stringify(result));
  }
  const db=queue(dir),final=state(db);assert.equal(final.delegation.length,2);assert(final.delegation.every(x=>x.state==='done'));assert.equal(final.observation.length,2);assert(final.observation.every(x=>x.ack_count===1));assert.equal(final.receipts.length,7);assert.equal(final.lease[0].state,'released');save(dir+'/queue-final.json',final);db.close();writeFileSync(dir+'/svn-status.txt',local('/opt/homebrew/bin/svn',['status'],workspace,out));
  for(const [i,actor] of [parent,...children].entries()){const db=new Database(actor.root+'/state.sqlite',{readonly:true});assert.equal(db.prepare("SELECT COUNT(*) n FROM capability_runs WHERE state<>'stopped'").get().n,0);assert.equal(db.prepare("SELECT COUNT(*) n FROM capability_resource_leases WHERE owner_kind='run' AND state<>'released'").get().n,0);await db.backup(dir+'/actor-'+i+'.sqlite');db.close();const dest=dir+'/actor-'+i+'-native';mkdirSync(dest);globSync(actor.snapshot.native.stateRoot+'/**/*.jsonl').forEach((p,j)=>copyFileSync(p,dest+'/'+j+'.jsonl'));}
 }}catch(e){error=e.stack;process.exitCode=1;}
 const result={out,checks,hosts,error,scope:'Actual shared Skill library, native Skill loading, owner/private MCP/ToolService and temporary SVN; candidate target catalogue/queue/result observations. Synthetic models and work, no real model autonomy or business authorization.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify(result,null,2));
}
