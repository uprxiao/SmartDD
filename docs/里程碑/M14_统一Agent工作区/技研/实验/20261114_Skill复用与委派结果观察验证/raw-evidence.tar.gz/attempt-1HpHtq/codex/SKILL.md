---
name: willyou-collaboration-probe
description: Reusable isolated collaboration method
---
WY_COLLAB_RULESET_1
Read the allowed target catalogue through the host before delegating. Select only the configured target and its current revision. Submit the delegate operation once. For a shared workspace, accept waiting_parent_release and end this turn so the host can release the directory. A completion notice is not the result: read the result, then explicitly acknowledge its observation token. Disabled or stale targets must not be silently replaced. These rules grant no business permissions.
