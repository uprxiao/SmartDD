CREATE UNIQUE INDEX ai_run_config_login_unique ON ai_run_configs(tool_id) WHERE source = 'login';

CREATE UNIQUE INDEX ai_run_config_provider_unique ON ai_run_configs(tool_id, provider_id) WHERE source = 'provider';

CREATE INDEX application_activity_subjects_lookup ON application_activity_subjects(kind,subject_id,operation_id);

CREATE UNIQUE INDEX application_connections_identity_key ON application_connections(id,provider_id,app_id);

CREATE INDEX application_connections_provider_idx ON application_connections(provider_id,app_id);

CREATE INDEX application_data_operations_activity_time ON application_data_operations(started_at,operation_id);

CREATE INDEX application_data_operations_project ON application_data_operations(project_id,started_at);

CREATE UNIQUE INDEX application_data_resources_identity ON application_data_resources(project_id,app_id,backing_kind,object_id,object_revision,part,data_contract_major);

CREATE INDEX application_invocations_activity_time ON application_invocations(started_at,operation_id);

CREATE INDEX application_invocations_project_idx ON application_invocations(project_id,started_at);

CREATE UNIQUE INDEX application_zentao_revisions_identity ON application_zentao_revisions(project_id,connection_id,identity_revision,object_kind,native_id,content_revision,representation);

CREATE INDEX browser_operations_created ON browser_operations(created_at);

CREATE INDEX capability_broker_denials_run ON capability_broker_denials(run_id,observed_at);

CREATE INDEX capability_legacy_preparation_state ON capability_legacy_migration_preparations(state,task_id);

CREATE INDEX `capability_resource_leases_resource_idx` ON `capability_resource_leases` (`resource_id`,`state`);

CREATE UNIQUE INDEX capability_resources_discovery_path
  ON capability_resources(scope_identity,scope_relative_path) WHERE path_scope='H' AND state<>'removed';

CREATE INDEX capability_run_evidence_time ON capability_run_preparations(prepared_at,run_id);

CREATE UNIQUE INDEX capability_run_one_cli_idx ON capability_run_processes(run_id) WHERE kind='cli';

CREATE INDEX capability_run_processes_run_idx ON capability_run_processes(run_id);

CREATE INDEX `capability_session_refs_resource_idx` ON `capability_session_refs` (`ref_id`);

CREATE UNIQUE INDEX m14_delivery_execution_key ON m14_delivery(receipt_id,run_id,plan_hash);

CREATE INDEX m14_native_claim_binding ON m14_native_claim(binding_id);

CREATE UNIQUE INDEX m14_native_claim_exact_owner ON m14_native_claim(runner,identity_root,native_id,binding_id,task_id);

CREATE UNIQUE INDEX m14_run_exact ON capability_runs(run_id,task_id,binding_id,capability_session_id,source_snapshot_hash,generation);

CREATE UNIQUE INDEX m14_run_scope_c1 ON capability_runs(run_id,task_id,binding_id,generation);

CREATE INDEX mail_drafts_project_updated ON mail_drafts(project_id,updated_at,id);

CREATE INDEX mail_send_intents_activity_time ON mail_send_intents(created_at,id);

CREATE INDEX mail_send_intents_project_updated ON mail_send_intents(project_id,updated_at,id);

CREATE UNIQUE INDEX plugin_lifecycle_pending ON plugin_lifecycle_changes(app_id)
 WHERE state IN ('preparing','prepared','swapping','recovery-required');

CREATE INDEX `project_databases_project_idx` ON `project_databases` (`project_id`);

CREATE INDEX `project_dirs_project_idx` ON `project_dirs` (`project_id`);

CREATE INDEX `project_servers_project_idx` ON `project_servers` (`project_id`);

CREATE INDEX `tasks_project_idx` ON `tasks` (`project_id`);

CREATE TABLE __drizzle_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      hash TEXT NOT NULL,
      created_at NUMERIC
    );

CREATE TABLE `ai_profiles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`runner` text NOT NULL,
	`executable` text,
	`env` text DEFAULT '[]' NOT NULL,
	`args` text DEFAULT '[]' NOT NULL,
	`color` text,
	`is_default` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
, `check_status` text, `check_category` text, `check_source` text, `check_message` text, `check_ms` integer, `check_at` integer, `command_pending` integer DEFAULT false NOT NULL);

CREATE TABLE ai_providers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  preset TEXT,
  endpoints TEXT NOT NULL,
  auth_type TEXT NOT NULL DEFAULT 'bearer' CHECK (auth_type IN ('bearer', 'api-key')),
  secret_ref TEXT,
  identity_revision INTEGER NOT NULL DEFAULT 1,
  models TEXT NOT NULL DEFAULT '[]',
  recommended TEXT NOT NULL DEFAULT '{}',
  refreshed_at INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
, key_hint TEXT);

CREATE TABLE ai_run_configs (
  profile_id TEXT PRIMARY KEY NOT NULL REFERENCES ai_profiles(id) ON DELETE CASCADE,
  tool_id TEXT NOT NULL REFERENCES ai_tools(id),
  source TEXT NOT NULL CHECK (source IN ('login', 'provider', 'legacy')),
  provider_id TEXT REFERENCES ai_providers(id),
  models TEXT NOT NULL DEFAULT '[]',
  default_model TEXT,
  home_visible INTEGER NOT NULL DEFAULT 1,
  logged_out INTEGER NOT NULL DEFAULT 0,
  name_customized INTEGER NOT NULL DEFAULT 1,
  sort_order INTEGER NOT NULL,
  legacy_reason TEXT,
  migration_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE ai_task_snapshots (
  task_id TEXT PRIMARY KEY NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  snapshot TEXT NOT NULL
);

CREATE TABLE ai_tools (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL,
  executable TEXT NOT NULL,
  custom_path TEXT,
  version TEXT,
  installed INTEGER NOT NULL DEFAULT 0,
  login TEXT NOT NULL DEFAULT 'none' CHECK (login IN ('none', 'subscription', 'api', 'local')),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE `app_secrets` (
	`key` text PRIMARY KEY NOT NULL,
	`secret` text NOT NULL
);

CREATE TABLE `app_settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text NOT NULL,
	`updated_at` integer DEFAULT (unixepoch() * 1000) NOT NULL
);

CREATE TABLE application_activity_subjects (
 operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id) ON DELETE CASCADE,
 kind TEXT NOT NULL CHECK(kind IN ('connection','mail-send','mail-draft')),
 subject_id TEXT NOT NULL,
 PRIMARY KEY(operation_id,kind,subject_id)
);

CREATE TABLE `application_binding_changes` (
  `operation_id` text PRIMARY KEY NOT NULL,
  `project_id` text NOT NULL,
  `app_id` text NOT NULL,
  `from_revision` integer NOT NULL,
  `to_revision` integer,
  `previous_json` text NOT NULL,
  `next_json` text NOT NULL,
  `state` text NOT NULL,
  `error_code` text,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL
);

CREATE TABLE "application_binding_slot_revisions" (
  project_id TEXT NOT NULL,
  app_id TEXT NOT NULL,
  slot TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK(revision >= 0),
  PRIMARY KEY(project_id,app_id,slot),
  FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE,
  FOREIGN KEY(slot,app_id) REFERENCES application_host_providers(provider_id,app_id)
);

CREATE TABLE "application_catalog_state" (
  `app_id` text PRIMARY KEY NOT NULL REFERENCES application_host_applications(app_id),
  `added` integer NOT NULL CHECK (`added` IN (0,1)),
  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),
  `revision` integer NOT NULL,
  `updated_at` text NOT NULL
);

CREATE TABLE "application_connections" (
  `id` text PRIMARY KEY NOT NULL,
  `app_id` text NOT NULL REFERENCES application_host_applications(app_id),
  `provider_id` text NOT NULL,
  `name` text NOT NULL,
  `config_schema_version` integer NOT NULL DEFAULT 1,
  `config_json` text NOT NULL,
  `revision` integer NOT NULL,
  `config_revision` integer NOT NULL,
  `identity_revision` integer NOT NULL,
  `verified_identity_json` text NOT NULL,
  `identity_hash` text NOT NULL,
  `secret_ref` text,
  `secret_revision` integer NOT NULL,
  `policy_revision` integer NOT NULL,
  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),
  `auth_state` text NOT NULL CHECK (`auth_state` IN ('connected','disconnected')),
  `health` text NOT NULL CHECK (`health` IN ('unverified','healthy','unavailable')),
  `health_code` text,
  `health_message` text,
  `tested_at` text,
  `cleanup_pending` integer NOT NULL DEFAULT 0 CHECK (`cleanup_pending` IN (0,1)),
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL, deleted_at TEXT,
  FOREIGN KEY (`provider_id`,`app_id`) REFERENCES application_host_providers(provider_id,app_id)
);

CREATE TABLE application_data_operations (
  operation_id TEXT PRIMARY KEY NOT NULL,
  caller_kind TEXT NOT NULL CHECK(caller_kind IN ('ui','agent-run','index-job')),
  scope_kind TEXT NOT NULL CHECK(scope_kind IN ('project','connection-management','internal-index')),
  project_id TEXT,
  task_id TEXT,
  run_id TEXT,
  job_id TEXT,
  parent_operation_id TEXT,
  app_id TEXT NOT NULL,
  package_hash TEXT NOT NULL,
  data_api INTEGER NOT NULL,
  action TEXT NOT NULL,
  semantics TEXT NOT NULL CHECK(semantics IN ('read','write')),
  scope_hash TEXT NOT NULL,
  targets_json TEXT NOT NULL DEFAULT '[]',
  attempt_count INTEGER NOT NULL DEFAULT 1,
  state TEXT NOT NULL CHECK(state IN ('running','succeeded','failed','unknown','cancelled')),
  error_code TEXT,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  CHECK((caller_kind='agent-run' AND scope_kind='project' AND project_id IS NOT NULL AND task_id IS NOT NULL AND run_id IS NOT NULL AND job_id IS NULL AND parent_operation_id IS NULL)
    OR (caller_kind='ui' AND ((scope_kind='project' AND project_id IS NOT NULL) OR scope_kind='connection-management') AND task_id IS NULL AND run_id IS NULL AND job_id IS NULL AND parent_operation_id IS NULL)
    OR (caller_kind='index-job' AND scope_kind='internal-index' AND semantics='read' AND project_id IS NOT NULL AND task_id IS NULL AND run_id IS NULL AND job_id IS NOT NULL AND parent_operation_id IS NOT NULL))
);

CREATE TABLE application_data_resources (
  resource_id TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  app_id TEXT NOT NULL,
  backing_kind TEXT NOT NULL,
  object_id TEXT NOT NULL,
  object_revision TEXT NOT NULL,
  part TEXT NOT NULL,
  data_contract_major INTEGER NOT NULL,
  permission TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  byte_size INTEGER NOT NULL CHECK(byte_size>=0),
  media_type TEXT NOT NULL,
  minted_package_hash TEXT NOT NULL,
  minted_operation_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE application_host_applications (
 app_id TEXT PRIMARY KEY NOT NULL CHECK(length(app_id) BETWEEN 1 AND 64 AND app_id GLOB '[a-z]*' AND app_id NOT GLOB '*[^a-z0-9-]*')
);

CREATE TABLE application_host_providers (
 provider_id TEXT PRIMARY KEY NOT NULL CHECK(length(provider_id) BETWEEN 1 AND 64 AND provider_id GLOB '[a-z]*' AND provider_id NOT GLOB '*[^a-z0-9-]*'),
 app_id TEXT NOT NULL REFERENCES application_host_applications(app_id) ON DELETE RESTRICT,
 config_api_major INTEGER NOT NULL CHECK(config_api_major=1),
 UNIQUE(provider_id,app_id)
);

CREATE TABLE application_index_waiters (
  index_operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id),
  parent_operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id),
  source_key TEXT NOT NULL,
  joined_at TEXT NOT NULL,
  ended_at TEXT,
  state TEXT NOT NULL CHECK(state IN ('waiting','completed','cancelled','failed')),
  PRIMARY KEY(index_operation_id,parent_operation_id)
);

CREATE TABLE application_invocations (
  operation_id TEXT PRIMARY KEY NOT NULL,
  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,
  request_id TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  project_id TEXT NOT NULL,
  task_id TEXT NOT NULL,
  app_id TEXT NOT NULL,
  package_hash TEXT NOT NULL,
  tool_name TEXT NOT NULL,
  contract_major INTEGER NOT NULL,
  connection_id TEXT,
  semantics TEXT NOT NULL CHECK(semantics IN ('read','write')),
  state TEXT NOT NULL CHECK(state IN ('running','succeeded','failed','unknown')),
  attempt_count INTEGER NOT NULL DEFAULT 0,
  error_code TEXT,
  effect_state TEXT NOT NULL CHECK(effect_state IN ('not-started','read-only','completed','unknown')),
  started_at TEXT NOT NULL,
  ended_at TEXT,
  UNIQUE(run_id,request_id)
);

CREATE TABLE application_mail_operation_sources (
  operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_data_operations(operation_id),
  source_key TEXT NOT NULL,
  source_revision TEXT NOT NULL,
  operation_kind TEXT NOT NULL CHECK(operation_kind IN ('query','read','resource')),
  provenance_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE "application_project_bindings" (
  `project_id` text NOT NULL,
  `app_id` text NOT NULL,
  `slot` text NOT NULL,
  `connection_id` text NOT NULL,
  `identity_revision` integer NOT NULL,
  PRIMARY KEY (`project_id`,`app_id`,`slot`),
  FOREIGN KEY (`connection_id`,`slot`,`app_id`) REFERENCES `application_connections` (`id`,`provider_id`,`app_id`),
  FOREIGN KEY (`project_id`,`app_id`) REFERENCES `application_project_settings` (`project_id`,`app_id`) ON DELETE CASCADE,
  FOREIGN KEY (`slot`,`app_id`) REFERENCES application_host_providers(provider_id,app_id)
);

CREATE TABLE "application_project_settings" (
  `project_id` text NOT NULL REFERENCES `projects` (`id`) ON DELETE CASCADE,
  `app_id` text NOT NULL REFERENCES application_host_applications(app_id),
  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),
  `binding_revision` integer NOT NULL,
  `pending_operation_id` text,
  `updated_at` text NOT NULL,
  `policy_revision` INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (`project_id`,`app_id`)
);

CREATE TABLE application_read_receipt_checks (
  check_operation_id TEXT PRIMARY KEY NOT NULL,
  original_operation_id TEXT NOT NULL,
  checked_at TEXT NOT NULL
);

CREATE TABLE `application_secret_changes` (
  `operation_id` text PRIMARY KEY NOT NULL,
  `connection_id` text NOT NULL,
  `expected_revision` integer NOT NULL,
  `old_secret_ref` text,
  `new_secret_ref` text,
  `candidate_hash` text NOT NULL,
  `candidate_json` text NOT NULL,
  `verified_identity_json` text,
  `compatibility_plan_json` text,
  `expires_at` text NOT NULL,
  `state` text NOT NULL CHECK (`state` IN ('preparing','validated','committed','cleanup-pending','failed','cleaned')),
  `error_code` text,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL
);

CREATE TABLE application_zentao_cursors (
  cursor_id TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  target_json TEXT NOT NULL,
  object_kind TEXT NOT NULL,
  page_size INTEGER NOT NULL,
  page_no INTEGER NOT NULL,
  expected_total INTEGER NOT NULL,
  seen_json TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE application_zentao_files (
  object_key TEXT NOT NULL REFERENCES application_zentao_revisions(object_key),
  file_id TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  bytes BLOB NOT NULL,
  media_type TEXT NOT NULL,
  byte_size INTEGER NOT NULL CHECK(byte_size>=0),
  fetched_at TEXT NOT NULL,
  PRIMARY KEY(object_key,file_id,content_hash)
);

CREATE TABLE application_zentao_operation_objects (
  operation_id TEXT NOT NULL,
  object_key TEXT NOT NULL REFERENCES application_zentao_revisions(object_key),
  PRIMARY KEY(operation_id,object_key)
);

CREATE TABLE application_zentao_operation_resources (
  operation_id TEXT PRIMARY KEY NOT NULL,
  backing_json TEXT NOT NULL
);

CREATE TABLE application_zentao_revisions (
  object_key TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  connection_id TEXT NOT NULL,
  identity_revision INTEGER NOT NULL,
  object_kind TEXT NOT NULL CHECK(object_kind IN ('bug','story')),
  native_id TEXT NOT NULL,
  content_revision TEXT NOT NULL,
  representation TEXT NOT NULL CHECK(representation IN ('summary','detail')),
  payload_json TEXT NOT NULL,
  fetched_at TEXT NOT NULL
);

CREATE TABLE browser_operations (
 run_id TEXT NOT NULL, request_id TEXT NOT NULL, task_id TEXT NOT NULL, page_id TEXT,
 command TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN ('accepted','running','succeeded','failed','unknown')),
 effect_state TEXT NOT NULL, progress TEXT, summary TEXT, error_code TEXT,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
 PRIMARY KEY(run_id, request_id)
);

CREATE TABLE builtin_plugin_defaults (
  app_id TEXT NOT NULL CHECK(app_id IN ('mail','browser')),
  slot TEXT NOT NULL,
  connection_id TEXT REFERENCES application_connections(id),
  revision INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(app_id,slot)
);

CREATE TABLE builtin_plugin_project_preferences (
  project_id TEXT NOT NULL,
  app_id TEXT NOT NULL CHECK(app_id IN ('mail','browser')),
  slot TEXT NOT NULL,
  mode TEXT NOT NULL CHECK(mode IN ('follow','individual')),
  PRIMARY KEY(project_id,app_id,slot),
  FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE
);

CREATE TABLE `capability_active_packages` (
  `app_id` text PRIMARY KEY NOT NULL,
  `package_hash` text NOT NULL REFERENCES `capability_packages` (`package_hash`),
  `activation_generation` integer NOT NULL,
  `activated_at` text NOT NULL
);

CREATE TABLE capability_agent_adapters (
  agent_id TEXT NOT NULL,
  version TEXT NOT NULL,
  adapter_hash TEXT NOT NULL UNIQUE,
  resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id) ON DELETE RESTRICT,
  manifest_json TEXT NOT NULL,
  PRIMARY KEY(agent_id,version)
);

CREATE TABLE capability_bridge_observations (
 run_id TEXT NOT NULL REFERENCES capability_runs(run_id),
 bridge_id TEXT NOT NULL REFERENCES capability_run_processes(process_id),
 evidence_json TEXT NOT NULL,
 evidence_hash TEXT NOT NULL,
 observed_at TEXT NOT NULL,
 PRIMARY KEY(run_id,bridge_id)
);

CREATE TABLE capability_broker_denials (
 audit_id TEXT PRIMARY KEY NOT NULL,
 host_generation TEXT NOT NULL,
 run_id TEXT,
 bridge_id TEXT,
 method TEXT NOT NULL CHECK(method IN ('unknown','exchange','renew','tools/list','tools/call','cancel')),
 error_code TEXT NOT NULL,
 observed_at TEXT NOT NULL,
 CHECK ((run_id IS NULL AND bridge_id IS NULL) OR (run_id IS NOT NULL AND bridge_id IS NOT NULL))
);

CREATE TABLE capability_builtin_package_sources (
  package_hash TEXT NOT NULL REFERENCES capability_packages(package_hash) ON DELETE RESTRICT,
  source_index_hash TEXT NOT NULL,
  source_index_json TEXT NOT NULL,
  approved_at TEXT NOT NULL,
  PRIMARY KEY(package_hash,source_index_hash)
);

CREATE TABLE capability_discovery_roots (
  home_id TEXT PRIMARY KEY NOT NULL,
  canonical_home TEXT NOT NULL UNIQUE
);

CREATE TABLE `capability_install_journal` (
  `install_id` text PRIMARY KEY NOT NULL REFERENCES `capability_resource_operations` (`operation_id`),
  `host_build` text NOT NULL,
  `from_generation` integer,
  `to_generation` integer,
  `state` text NOT NULL,
  `plan_json` text NOT NULL,
  `backup_path` text,
  `error_code` text,
  `updated_at` text NOT NULL
);

CREATE TABLE capability_lease_resources (
  lease_id TEXT NOT NULL REFERENCES capability_resource_leases(lease_id) ON DELETE RESTRICT,
  resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id) ON DELETE RESTRICT,
  content_hash TEXT NOT NULL,
  generation INTEGER NOT NULL,
  PRIMARY KEY(lease_id,resource_id)
);

CREATE TABLE capability_legacy_h_bindings (
 task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_legacy_migration_preparations(task_id),
 binding_json TEXT NOT NULL,
 binding_hash TEXT NOT NULL,
 created_at TEXT NOT NULL
);

CREATE TABLE capability_legacy_migration_preparations (
 task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id),
 source_snapshot_json TEXT NOT NULL,
 source_record_json TEXT NOT NULL,
 source_snapshot_hash TEXT NOT NULL,
 source_identity_json TEXT NOT NULL,
 bound_native_session_id TEXT,
 evidence_json TEXT,
 evidence_hash TEXT,
 manifest_json TEXT,
 manifest_hash TEXT,
 state TEXT NOT NULL CHECK(state IN ('held','prepared','migrated')),
 issue_code TEXT,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL, `h_binding_hash` text,
 CHECK((evidence_json IS NULL AND evidence_hash IS NULL AND manifest_json IS NULL AND manifest_hash IS NULL)
    OR (evidence_json IS NOT NULL AND evidence_hash IS NOT NULL AND manifest_json IS NOT NULL AND manifest_hash IS NOT NULL))
);

CREATE TABLE capability_package_contracts (
  package_hash TEXT NOT NULL REFERENCES capability_packages(package_hash) ON DELETE RESTRICT,
  tool_name TEXT NOT NULL,
  input_source TEXT NOT NULL,
  output_source TEXT NOT NULL,
  PRIMARY KEY(package_hash,tool_name)
);

CREATE TABLE `capability_packages` (
  `package_hash` text PRIMARY KEY NOT NULL,
  `app_id` text NOT NULL,
  `version` text NOT NULL,
  `hash_algorithm` text NOT NULL CHECK (`hash_algorithm` = 'app-manifest-v1'),
  `relative_path` text NOT NULL,
  `manifest_json` text NOT NULL,
  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),
  `installed_at` text NOT NULL,
  UNIQUE (`app_id`,`version`)
);

CREATE TABLE capability_registry (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  runner TEXT NOT NULL,
  source_path TEXT NOT NULL,
  source_scope TEXT NOT NULL,
  project_root TEXT,
  source_label TEXT NOT NULL,
  version TEXT,
  validity TEXT NOT NULL,
  issues TEXT NOT NULL,
  managed INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 1,
  auto_approve INTEGER NOT NULL DEFAULT 0,
  present INTEGER NOT NULL DEFAULT 1,
  discovered_at INTEGER NOT NULL,
  scanned_at INTEGER NOT NULL
);

CREATE TABLE capability_registry_preferences (
  id INTEGER PRIMARY KEY NOT NULL CHECK (id = 1),
  auto_manage INTEGER NOT NULL DEFAULT 0,
  builtin_disabled TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE `capability_resource_dependencies` (
  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),
  `dependency_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),
  PRIMARY KEY (`resource_id`,`dependency_id`),
  CHECK (`resource_id` <> `dependency_id`)
);

CREATE TABLE `capability_resource_leases` (
  `lease_id` text PRIMARY KEY NOT NULL,
  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),
  `owner_kind` text NOT NULL,
  `owner_id` text NOT NULL,
  `host_instance_id` text NOT NULL,
  `pid` integer,
  `process_started_at` text,
  `state` text NOT NULL CHECK (`state` IN ('preparing','active','releasing','released','recovery-required')),
  `created_at` text NOT NULL,
  `ended_at` text
);

CREATE TABLE `capability_resource_operations` (
  `operation_id` text PRIMARY KEY NOT NULL,
  `kind` text NOT NULL,
  `owner_store_id` text NOT NULL,
  `state` text NOT NULL,
  `plan_json` text NOT NULL,
  `error_code` text,
  `created_at` text NOT NULL,
  `updated_at` text NOT NULL
);

CREATE TABLE `capability_resources` (
  `resource_id` text PRIMARY KEY NOT NULL,
  `kind` text NOT NULL,
  `content_hash` text NOT NULL,
  `owner_store_id` text NOT NULL,
  `path_scope` text NOT NULL CHECK (`path_scope` IN ('C','H')),
  `relative_path` text NOT NULL,
  `state` text NOT NULL CHECK (`state` IN ('staged','verified','ready','deleting','removed','recovery-required')),
  `generation` integer NOT NULL DEFAULT 1,
  `integrity` text NOT NULL CHECK (`integrity` IN ('unknown','valid','invalid')),
  `operation_id` text, scope_identity TEXT NOT NULL DEFAULT '', scope_relative_path TEXT,
  UNIQUE (`owner_store_id`,`path_scope`,`relative_path`)
);

CREATE TABLE capability_run_activities (
  activity_id TEXT PRIMARY KEY NOT NULL,
  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,
  state TEXT NOT NULL CHECK(state IN ('active','finished','owner-stopped')),
  started_at TEXT NOT NULL,
  ended_at TEXT
);

CREATE TABLE capability_run_preparations (
 run_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_runs(run_id),
 evidence_json TEXT NOT NULL,
 evidence_hash TEXT NOT NULL,
 prepared_at TEXT NOT NULL
);

CREATE TABLE capability_run_processes (
  process_id TEXT PRIMARY KEY NOT NULL,
  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,
  kind TEXT NOT NULL CHECK(kind IN ('cli','bridge')),
  launch_key TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL CHECK(state IN ('reserved','armed','active','exited','canceled','unknown')),
  pid INTEGER,
  process_started_at TEXT,
  armed_at TEXT,
  attached_at TEXT,
  ended_at TEXT
);

CREATE TABLE capability_run_restrictions (
 run_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_runs(run_id),
 evidence_json TEXT NOT NULL,
 evidence_hash TEXT NOT NULL,
 restricted_at TEXT NOT NULL
);

CREATE TABLE "capability_runs" (
  run_id TEXT PRIMARY KEY NOT NULL,
  task_id TEXT NOT NULL ,
  project_id TEXT NOT NULL,
  runner TEXT NOT NULL,
  pid INTEGER,
  process_started_at TEXT,
  state TEXT NOT NULL,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  error_code TEXT,
  snapshot_hash TEXT,
  owner_instance_id TEXT,
  owner_pid INTEGER,
  owner_started_at TEXT,
  bindings_json TEXT NOT NULL DEFAULT '[]',
  pty_id TEXT
, revocation_state TEXT NOT NULL DEFAULT 'open', binding_mode TEXT NOT NULL DEFAULT 'current' CHECK(binding_mode IN ('current','run')), binding_id TEXT,capability_session_id TEXT,execution_mode TEXT NOT NULL DEFAULT 'legacy' CHECK(execution_mode IN ('legacy','programmatic')),generation INTEGER,source_snapshot_hash TEXT,
   CHECK((binding_id IS NULL)=(capability_session_id IS NULL)),CHECK(execution_mode='legacy' OR (binding_id IS NOT NULL AND snapshot_hash IS NOT NULL AND source_snapshot_hash IS NOT NULL AND generation IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
   FOREIGN KEY(binding_id,task_id,runner) REFERENCES m14_binding(binding_id,task_id,runner),
   FOREIGN KEY(capability_session_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash),
   FOREIGN KEY(capability_session_id,task_id,binding_id,source_snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash));

CREATE TABLE `capability_schema_migrations` (
  `app_id` text NOT NULL,
  `migration_id` text NOT NULL,
  `checksum` text NOT NULL,
  `from_version` integer NOT NULL,
  `to_version` integer NOT NULL,
  `applied_at` text NOT NULL,
  `host_build` text NOT NULL,
  PRIMARY KEY (`app_id`,`migration_id`)
);

CREATE TABLE capability_session_holds (
  task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,
  previous_retention TEXT NOT NULL CHECK(previous_retention IN ('active','tombstone','hold')),
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE capability_session_identities (
  task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,
  runner TEXT NOT NULL,
  identity_root TEXT NOT NULL,
  session_id TEXT,
  cwd TEXT NOT NULL,
  discovery_home TEXT NOT NULL,
  selection_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(runner,identity_root,session_id)
);

CREATE TABLE capability_session_mcp_names (
  server_name TEXT PRIMARY KEY NOT NULL,
  task_id TEXT NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,
  kind TEXT NOT NULL,
  UNIQUE(task_id,kind)
);

CREATE TABLE `capability_session_refs` (
  `task_id` text NOT NULL REFERENCES `capability_session_snapshots` (`task_id`),
  `ref_kind` text NOT NULL,
  `ref_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),
  `ref_hash` text NOT NULL,
  `relative_path` text NOT NULL,
  PRIMARY KEY (`task_id`,`ref_kind`,`ref_id`)
);

CREATE TABLE `capability_session_snapshots` (
  `task_id` text PRIMARY KEY NOT NULL,
  `schema_version` integer NOT NULL,
  `snapshot_json` text NOT NULL,
  `snapshot_hash` text NOT NULL,
  `created_at` text NOT NULL,
  `legacy_status` text NOT NULL,
  `retention_state` text NOT NULL CHECK (`retention_state` IN ('active','tombstone','hold'))
);

CREATE TABLE capability_skill_observations (
 run_id TEXT NOT NULL REFERENCES capability_runs(run_id),
 app_id TEXT NOT NULL,
 skill_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('discovery','read')),
 evidence_json TEXT NOT NULL,
 evidence_hash TEXT NOT NULL,
 observed_at TEXT NOT NULL,
 PRIMARY KEY(run_id,app_id,skill_id,kind)
);

CREATE TABLE capability_skill_placements (
  id TEXT PRIMARY KEY NOT NULL,
  capability_id TEXT NOT NULL REFERENCES capability_registry(id),
  target_root TEXT NOT NULL,
  name TEXT NOT NULL,
  project_root TEXT
);

CREATE TABLE capability_snapshot_versions (
  snapshot_hash TEXT PRIMARY KEY NOT NULL,
  task_id TEXT NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,
  snapshot_json TEXT NOT NULL,
  selection_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE capability_store_state (
  singleton INTEGER PRIMARY KEY NOT NULL CHECK(singleton=1),
  store_id TEXT NOT NULL,
  resource_generation INTEGER NOT NULL DEFAULT 1,
  maintenance_state TEXT NOT NULL CHECK(maintenance_state IN ('ready','pending','recovery-required')),
  maintenance_operation_id TEXT
);

CREATE TABLE `imported_keys` (
  `server_id` text PRIMARY KEY NOT NULL,
  `path` text NOT NULL,
  `created_at` integer NOT NULL
);

CREATE TABLE m14_binding(
 binding_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,runner TEXT NOT NULL,
 identity_root TEXT,native_id TEXT,cwd TEXT NOT NULL,
 legacy_task_id TEXT UNIQUE REFERENCES capability_session_snapshots(task_id),
 entry_mode TEXT NOT NULL CHECK(entry_mode IN ('legacy','programmatic')),
 phase TEXT NOT NULL DEFAULT 'historical' CHECK(phase IN ('historical','planned','preparing','prepared','canceled')),profile_id TEXT,profile_revision INTEGER, discovery_home TEXT, run_generation INTEGER NOT NULL DEFAULT 0 CHECK(run_generation>=0),
 CHECK(phase IN ('planned','canceled') OR identity_root IS NOT NULL),
 CHECK(phase<>'planned' OR native_id IS NULL),
 UNIQUE(binding_id,task_id),UNIQUE(binding_id,task_id,runner),UNIQUE(runner,identity_root,native_id));

CREATE TABLE m14_cap(
 cap_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,
 retention TEXT NOT NULL CHECK(retention IN ('active','hold','tombstone')),current_hash TEXT,
 UNIQUE(cap_id,task_id,binding_id),
 FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(cap_id,current_hash) REFERENCES m14_revision(cap_id,snapshot_hash) DEFERRABLE INITIALLY DEFERRED);

CREATE TABLE m14_completion_delivery(
 delivery_id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL REFERENCES m14_delegation(id),result_revision INTEGER NOT NULL CHECK(typeof(result_revision)='integer' AND result_revision>0),
 parent_task TEXT NOT NULL,target_binding TEXT,target_run TEXT,target_generation INTEGER,input_id TEXT,
 state TEXT NOT NULL CHECK(state IN ('pending','dispatching','accepted','observed','not-sent','unknown')),
 UNIQUE(delegation_id,result_revision),
 CHECK((target_run IS NULL AND target_generation IS NULL AND input_id IS NULL) OR (target_run IS NOT NULL AND target_binding IS NOT NULL AND typeof(target_generation)='integer' AND target_generation>0 AND input_id IS NOT NULL)),
 FOREIGN KEY(target_binding,parent_task) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(input_id,parent_task,target_binding,target_run,target_generation) REFERENCES m14_input(input_id,task_id,binding_id,run_id,generation));

CREATE TABLE m14_contract_baseline(revision TEXT PRIMARY KEY,inputs_hash TEXT NOT NULL,schema_hash TEXT NOT NULL);

CREATE TABLE m14_delegation(
 id TEXT PRIMARY KEY,parent_task TEXT NOT NULL,parent_binding TEXT NOT NULL,parent_run TEXT NOT NULL,parent_generation INTEGER NOT NULL,
 child_task TEXT NOT NULL UNIQUE REFERENCES m14_task_state(task_id),child_binding TEXT NOT NULL,turn_id TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL CHECK(state IN ('queued','preparing','running','waiting','canceling','completed','cancelled','failed','unknown')),
 CHECK(parent_task<>child_task),
 UNIQUE(id,parent_task,parent_binding,parent_run,parent_generation),UNIQUE(id,child_task,child_binding),
 FOREIGN KEY(parent_run,parent_task,parent_binding,parent_generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation),
 FOREIGN KEY(turn_id,child_task,child_binding) REFERENCES m14_turn(id,task_id,binding_id));

CREATE TABLE m14_delivery(
 receipt_id TEXT PRIMARY KEY,token TEXT NOT NULL UNIQUE,store_id TEXT NOT NULL,
 task_id TEXT NOT NULL,binding_id TEXT NOT NULL,cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL CHECK(typeof(generation)='integer' AND generation>0),
 plan_json TEXT NOT NULL,plan_hash TEXT NOT NULL,
 owner_pid INTEGER NOT NULL,owner_started_at TEXT NOT NULL,owner_instance TEXT NOT NULL,
 phase TEXT NOT NULL CHECK(phase IN ('prepared','adopted','released','abandoned')),run_lease_id TEXT REFERENCES capability_resource_leases(lease_id),
 CHECK(phase NOT IN ('adopted','released') OR run_lease_id IS NOT NULL),
 UNIQUE(run_id,generation),
 FOREIGN KEY(run_id,task_id,binding_id,cap_id,snapshot_hash,generation) REFERENCES capability_runs(run_id,task_id,binding_id,capability_session_id,source_snapshot_hash,generation),
 FOREIGN KEY(cap_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash));

CREATE TABLE m14_delivery_ref(receipt_id TEXT NOT NULL REFERENCES m14_delivery(receipt_id),resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id),kind TEXT NOT NULL,content_hash TEXT NOT NULL,relative_path TEXT NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),PRIMARY KEY(receipt_id,resource_id));

CREATE TABLE m14_event(
 task_id TEXT NOT NULL REFERENCES m14_task_state(task_id),task_seq INTEGER NOT NULL CHECK(typeof(task_seq)='integer' AND task_seq>0),
 protocol INTEGER NOT NULL CHECK(protocol=1),type TEXT NOT NULL,binding_id TEXT,run_id TEXT,generation INTEGER,payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
 CHECK((run_id IS NULL AND binding_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND binding_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 PRIMARY KEY(task_id,task_seq),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));

CREATE TABLE m14_execution_plan(
 run_id TEXT PRIMARY KEY REFERENCES capability_runs(run_id),
 receipt_id TEXT NOT NULL UNIQUE, receipt_hash TEXT NOT NULL,
 application_plan_hash TEXT NOT NULL, plan_json TEXT NOT NULL, plan_hash TEXT NOT NULL,
 FOREIGN KEY(receipt_id,run_id,receipt_hash) REFERENCES m14_delivery(receipt_id,run_id,plan_hash));

CREATE TABLE m14_input(
 input_id TEXT PRIMARY KEY,command_id TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 source TEXT NOT NULL CHECK(source IN ('ui-user','history-transfer','agent-delegation','automatic-followup','child-result')),
 text TEXT NOT NULL,turn_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,
 scope_json TEXT NOT NULL CHECK(json_valid(scope_json)),scope_hash TEXT NOT NULL CHECK(length(scope_hash)=64),
 state TEXT NOT NULL CHECK(state IN ('queued','dispatching','unknown','accepted')),
 owner_instance TEXT NOT NULL,owner_pid INTEGER NOT NULL CHECK(typeof(owner_pid)='integer' AND owner_pid>0),owner_birth TEXT NOT NULL,native_json TEXT CHECK(native_json IS NULL OR json_valid(native_json)),
 CHECK(state<>'accepted' OR native_json IS NOT NULL),
 CHECK(json_extract(scope_json,'$.taskId') IS task_id AND json_extract(scope_json,'$.bindingId') IS binding_id AND json_extract(scope_json,'$.runId') IS run_id AND json_extract(scope_json,'$.generation') IS generation),
 UNIQUE(input_id,scope_hash),UNIQUE(input_id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(turn_id,task_id,binding_id,run_id,generation) REFERENCES m14_turn(id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));

CREATE TABLE m14_input_inbox(
 event_id TEXT PRIMARY KEY,input_id TEXT NOT NULL,scope_hash TEXT NOT NULL,frame_json TEXT NOT NULL CHECK(json_valid(frame_json)),frame_hash TEXT NOT NULL CHECK(length(frame_hash)=64),processed INTEGER NOT NULL DEFAULT 0 CHECK(processed IN(0,1)),
 FOREIGN KEY(input_id,scope_hash) REFERENCES m14_input(input_id,scope_hash));

CREATE TABLE m14_mcp(
 server_name TEXT PRIMARY KEY,binding_id TEXT NOT NULL,task_id TEXT NOT NULL,kind TEXT NOT NULL,
 UNIQUE(binding_id,kind),FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id));

CREATE TABLE m14_migration(version INTEGER PRIMARY KEY,source_schema_hash TEXT NOT NULL);

CREATE TABLE m14_native_claim(runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,binding_id TEXT NOT NULL,task_id TEXT NOT NULL,PRIMARY KEY(runner,identity_root,native_id),FOREIGN KEY(binding_id,task_id,runner) REFERENCES m14_binding(binding_id,task_id,runner));

CREATE TABLE m14_native_claim_source(runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL REFERENCES capability_snapshot_versions(snapshot_hash) ON DELETE RESTRICT,PRIMARY KEY(runner,identity_root,native_id,snapshot_hash),FOREIGN KEY(runner,identity_root,native_id) REFERENCES m14_native_claim(runner,identity_root,native_id) ON DELETE RESTRICT);

CREATE TABLE m14_outbox(
 id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL UNIQUE,child_task TEXT NOT NULL,child_binding TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('queued','claimed','reserved','dispatching','initialized','stopped','blocked','unknown')),claim TEXT,reason TEXT,
 run_id TEXT UNIQUE,generation INTEGER,target_profile_id TEXT NOT NULL,target_revision INTEGER NOT NULL CHECK(typeof(target_revision)='integer' AND target_revision>0),
 CHECK((run_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 UNIQUE(id,run_id),
 FOREIGN KEY(delegation_id,child_task,child_binding) REFERENCES m14_delegation(id,child_task,child_binding),
 FOREIGN KEY(run_id,child_task,child_binding,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));

CREATE TABLE m14_preparation(binding_id TEXT PRIMARY KEY REFERENCES m14_binding(binding_id),token TEXT NOT NULL UNIQUE,snapshot_hash TEXT NOT NULL,snapshot_json TEXT NOT NULL,selection_hash TEXT NOT NULL);

CREATE TABLE m14_preparation_ref(binding_id TEXT NOT NULL REFERENCES m14_binding(binding_id),token TEXT NOT NULL,ref_id TEXT NOT NULL REFERENCES capability_resources(resource_id),ref_kind TEXT NOT NULL,ref_hash TEXT NOT NULL,relative_path TEXT NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),PRIMARY KEY(binding_id,ref_id));

CREATE TABLE m14_profile_execution_revision(
 profile_id TEXT PRIMARY KEY,
 revision INTEGER NOT NULL CHECK(typeof(revision)='integer' AND revision>0),
 present INTEGER NOT NULL CHECK(present IN(0,1))
);

CREATE TABLE m14_programmatic_claim_source(
 runner TEXT NOT NULL,identity_root TEXT NOT NULL,native_id TEXT NOT NULL,
 binding_id TEXT NOT NULL,task_id TEXT NOT NULL,cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,
 PRIMARY KEY(runner,identity_root,native_id,cap_id,snapshot_hash),
 FOREIGN KEY(runner,identity_root,native_id,binding_id,task_id) REFERENCES m14_native_claim(runner,identity_root,native_id,binding_id,task_id) ON DELETE RESTRICT,
 FOREIGN KEY(cap_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash) ON DELETE RESTRICT);

CREATE TABLE m14_publication(binding_id TEXT PRIMARY KEY REFERENCES m14_binding(binding_id),request_hash TEXT NOT NULL CHECK(length(request_hash)=64),scope_json TEXT NOT NULL CHECK(json_valid(scope_json)));

CREATE TABLE m14_receipt(
 parent_task TEXT NOT NULL,origin_binding TEXT NOT NULL,origin_run TEXT NOT NULL,origin_generation INTEGER NOT NULL,
 request_key TEXT NOT NULL,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),delegation_id TEXT NOT NULL,response TEXT NOT NULL CHECK(json_valid(response)),
 PRIMARY KEY(parent_task,request_key),
 FOREIGN KEY(delegation_id,parent_task,origin_binding,origin_run,origin_generation) REFERENCES m14_delegation(id,parent_task,parent_binding,parent_run,parent_generation));

CREATE TABLE m14_ref(
 cap_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,ref_id TEXT NOT NULL REFERENCES capability_resources(resource_id),
 ref_kind TEXT NOT NULL,ref_hash TEXT NOT NULL,relative_path TEXT NOT NULL,task_id TEXT NOT NULL,
 PRIMARY KEY(cap_id,snapshot_hash,ref_id),FOREIGN KEY(cap_id,task_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,snapshot_hash));

CREATE TABLE m14_response(
 command_id TEXT PRIMARY KEY,request_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,
 expected_revision INTEGER NOT NULL CHECK(typeof(expected_revision)='integer' AND expected_revision>0),request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 state TEXT NOT NULL CHECK(state IN ('dispatching','applied','not-sent','unknown')),
 FOREIGN KEY(request_id,task_id,binding_id,run_id,generation) REFERENCES m14_runtime_request(request_id,task_id,binding_id,run_id,generation));

CREATE TABLE m14_retained_identity_source(binding_id TEXT PRIMARY KEY REFERENCES m14_binding(binding_id),task_id TEXT NOT NULL UNIQUE REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,snapshot_hash TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('held-known','schema0')));

CREATE TABLE m14_revision(
 cap_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,
 snapshot_json TEXT NOT NULL,schema_version INTEGER NOT NULL CHECK(schema_version IN (2,3)),selection_hash TEXT NOT NULL,
 PRIMARY KEY(cap_id,snapshot_hash),UNIQUE(cap_id,task_id,binding_id,snapshot_hash),UNIQUE(cap_id,task_id,snapshot_hash),
 FOREIGN KEY(cap_id,task_id,binding_id) REFERENCES m14_cap(cap_id,task_id,binding_id));

CREATE TABLE m14_run_request(request_key TEXT PRIMARY KEY,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),run_id TEXT NOT NULL UNIQUE,
 FOREIGN KEY(request_key,run_id) REFERENCES m14_outbox(id,run_id));

CREATE TABLE m14_runtime_request(
 request_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,turn_id TEXT,
 source TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('approval','questions','form','url','unsupported')),native_key TEXT,
 revision INTEGER NOT NULL CHECK(typeof(revision)='integer' AND revision>0),state TEXT NOT NULL CHECK(state IN ('pending','dispatching','resolved','expired','unknown')),
 spec_json TEXT NOT NULL CHECK(json_valid(spec_json)),blocking INTEGER NOT NULL CHECK(blocking IN(0,1)),
 UNIQUE(request_id,task_id,binding_id,run_id,generation),UNIQUE(run_id,generation,source,native_key),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation),
 FOREIGN KEY(turn_id,task_id,binding_id,run_id,generation) REFERENCES m14_turn(id,task_id,binding_id,run_id,generation));

CREATE TABLE m14_task_state(
 task_id TEXT PRIMARY KEY REFERENCES tasks(id) ON DELETE RESTRICT,
 active_binding TEXT,selection_revision INTEGER NOT NULL DEFAULT 1 CHECK(typeof(selection_revision)='integer' AND selection_revision>0),
 draft_revision INTEGER NOT NULL DEFAULT 0 CHECK(typeof(draft_revision)='integer' AND draft_revision>=0),
 task_seq INTEGER NOT NULL DEFAULT 0 CHECK(typeof(task_seq)='integer' AND task_seq>=0),
 FOREIGN KEY(active_binding,task_id) REFERENCES m14_binding(binding_id,task_id));

CREATE TABLE m14_turn(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES m14_task_state(task_id),binding_id TEXT NOT NULL,
 input TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('queued','dispatching','accepted','running','waiting','canceling','completed','cancelled','failed','not-sent','unknown')),
 run_id TEXT,generation INTEGER,
 CHECK((run_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 UNIQUE(id,task_id),UNIQUE(id,task_id,binding_id),UNIQUE(id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));

CREATE TABLE m14_unmapped(task_id TEXT PRIMARY KEY,snapshot_hash TEXT NOT NULL,reason TEXT NOT NULL);

CREATE TABLE m14_unmapped_version(task_id TEXT NOT NULL,snapshot_hash TEXT NOT NULL,snapshot_json TEXT NOT NULL,selection_hash TEXT NOT NULL,reason TEXT NOT NULL,PRIMARY KEY(task_id,snapshot_hash));

CREATE TABLE mail_attachment_objects (
  id TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  content_hash TEXT NOT NULL REFERENCES mail_blob_objects(content_hash) ON DELETE RESTRICT,
  filename TEXT NOT NULL,
  content_type TEXT NOT NULL,
  byte_size INTEGER NOT NULL CHECK(byte_size >= 0),
  created_at TEXT NOT NULL
, kind TEXT NOT NULL DEFAULT 'attachment' CHECK(kind IN ('attachment','message')));

CREATE TABLE mail_blob_objects (
  content_hash TEXT PRIMARY KEY NOT NULL,
  byte_size INTEGER NOT NULL CHECK(byte_size >= 0),
  created_at TEXT NOT NULL
);

CREATE TABLE mail_blob_writes (
  operation_id TEXT PRIMARY KEY NOT NULL,
  attachment_id TEXT NOT NULL,
  project_id TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  metadata_json TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('preparing','staged','published','committed','failed')),
  error_code TEXT,
  cleanup_pending INTEGER NOT NULL DEFAULT 0 CHECK(cleanup_pending IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE mail_draft_mutations (
  project_id TEXT NOT NULL,
  operation_id TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  draft_id TEXT NOT NULL REFERENCES mail_drafts(id) ON DELETE RESTRICT,
  result_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(project_id,operation_id)
);

CREATE TABLE mail_draft_revisions (
  draft_id TEXT NOT NULL REFERENCES mail_drafts(id) ON DELETE RESTRICT,
  revision INTEGER NOT NULL CHECK(revision >= 1),
  content_json TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  actor_task_id TEXT,
  created_at TEXT NOT NULL,
  PRIMARY KEY(draft_id,revision)
);

CREATE TABLE mail_drafts (
  id TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  source_task_id TEXT,
  copied_from_draft_id TEXT REFERENCES mail_drafts(id) ON DELETE RESTRICT,
  subject TEXT NOT NULL,
  attachment_count INTEGER NOT NULL CHECK(attachment_count >= 0),
  current_revision INTEGER NOT NULL CHECK(current_revision >= 1),
  state TEXT NOT NULL CHECK(state IN ('draft','sending','sent','failed','unknown')),
  active_intent_id TEXT,
  last_execution_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE mail_send_executions (
  id TEXT PRIMARY KEY NOT NULL,
  intent_id TEXT NOT NULL UNIQUE REFERENCES mail_send_intents(id) ON DELETE RESTRICT,
  project_id TEXT NOT NULL,
  draft_id TEXT NOT NULL,
  draft_revision INTEGER NOT NULL,
  review_hash TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('executing','server-accepted','failed','unknown')),
  result_json TEXT,
  secret_revision INTEGER NOT NULL,
  owner_instance_id TEXT NOT NULL,
  started_at TEXT NOT NULL,
  ended_at TEXT,
  UNIQUE(draft_id,draft_revision)
);

CREATE TABLE mail_send_grants (
  id TEXT PRIMARY KEY NOT NULL,
  intent_id TEXT NOT NULL REFERENCES mail_send_intents(id) ON DELETE RESTRICT,
  source TEXT NOT NULL CHECK(source IN ('renderer-confirmation','native-user-message')),
  evidence_id TEXT NOT NULL,
  evidence_hash TEXT NOT NULL,
  review_hash TEXT NOT NULL,
  evidence_json TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('active','used','revoked')),
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(source,evidence_id)
);

CREATE TABLE mail_send_intents (
  id TEXT PRIMARY KEY NOT NULL,
  project_id TEXT NOT NULL,
  source_task_id TEXT,
  source_run_id TEXT,
  operation_id TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  draft_id TEXT NOT NULL,
  draft_revision INTEGER NOT NULL,
  draft_content_hash TEXT NOT NULL,
  connection_id TEXT NOT NULL REFERENCES application_connections(id) ON DELETE RESTRICT,
  identity_revision INTEGER NOT NULL,
  config_revision INTEGER NOT NULL,
  policy_revision INTEGER NOT NULL,
  binding_revision INTEGER NOT NULL,
  identity_json TEXT NOT NULL,
  smtp_config_json TEXT NOT NULL,
  raw_write_id TEXT NOT NULL,
  raw_object_id TEXT REFERENCES mail_attachment_objects(id) ON DELETE RESTRICT,
  raw_hash TEXT,
  frozen_hash TEXT,
  envelope_json TEXT,
  message_id TEXT NOT NULL,
  review_json TEXT,
  review_hash TEXT,
  state TEXT NOT NULL CHECK(state IN ('preparing','awaiting-authorization','authorized','executing','server-accepted','failed','unknown','canceled','stale')),
  grant_id TEXT,
  execution_id TEXT,
  cancel_requested_at TEXT,
  owner_instance_id TEXT NOT NULL,
  owner_pid INTEGER NOT NULL,
  owner_started_at TEXT NOT NULL,
  error_code TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL, `sender_identity_hash` text,
  UNIQUE(project_id,operation_id),
  FOREIGN KEY(draft_id,draft_revision) REFERENCES mail_draft_revisions(draft_id,revision) ON DELETE RESTRICT
);

CREATE TABLE mail_sender_confirmation_versions (
  project_id TEXT NOT NULL,
  binding_hash TEXT NOT NULL,
  binding_json TEXT NOT NULL,
  method TEXT NOT NULL,
  receipt_id TEXT NOT NULL UNIQUE,
  sender_id TEXT,
  confirmed_at TEXT NOT NULL,
  record_hash TEXT NOT NULL,
  PRIMARY KEY(project_id,binding_hash,receipt_id)
);

CREATE TABLE `mail_sender_confirmations` (
  `project_id` text PRIMARY KEY NOT NULL,
  `binding_hash` text NOT NULL,
  `binding_json` text NOT NULL,
  `method` text NOT NULL CHECK (`method` IN ('automatic','user')),
  `receipt_id` text NOT NULL UNIQUE,
  `sender_id` text,
  `confirmed_at` text NOT NULL,
  `record_hash` text NOT NULL
);

CREATE TABLE mail_user_action_sources (
  evidence_id TEXT PRIMARY KEY NOT NULL,
  intent_id TEXT NOT NULL REFERENCES mail_send_intents(id),
  source_kind TEXT NOT NULL CHECK(source_kind IN ('renderer-confirmation','native-user-message')),
  source_hash TEXT NOT NULL,
  provenance_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE plugin_builtin_migrations (
 app_id TEXT PRIMARY KEY NOT NULL,
 migration_version INTEGER NOT NULL CHECK(migration_version>0),
 package_hash TEXT NOT NULL,
 source_hash TEXT NOT NULL,
 tables_json TEXT NOT NULL,
 completed_at TEXT NOT NULL
);

CREATE TABLE plugin_connection_defaults (
 app_id TEXT PRIMARY KEY NOT NULL REFERENCES application_host_applications(app_id),
 connection_id TEXT REFERENCES application_connections(id) ON DELETE RESTRICT,
 revision INTEGER NOT NULL CHECK(revision>=0)
);

CREATE TABLE plugin_installations (
 app_id TEXT PRIMARY KEY NOT NULL,
 package_hash TEXT REFERENCES plugin_packages(package_hash) ON DELETE RESTRICT,
 installed INTEGER NOT NULL CHECK(installed IN (0,1)),
 enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
 revision INTEGER NOT NULL CHECK(revision > 0),
 updated_at TEXT NOT NULL,
 CHECK(installed=1 OR (enabled=0 AND package_hash IS NULL))
);

CREATE TABLE plugin_lifecycle_changes (
 change_id TEXT PRIMARY KEY NOT NULL,
 app_id TEXT NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('install','update','uninstall')),
 from_hash TEXT, to_hash TEXT,
 from_revision INTEGER NOT NULL,
 previous_enabled INTEGER NOT NULL CHECK(previous_enabled IN (0,1)),
 state TEXT NOT NULL CHECK(state IN ('preparing','prepared','swapping','committed','rolled-back','recovery-required')),
 payload_json TEXT NOT NULL,
 error_code TEXT,
 host_instance_id TEXT NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE plugin_packages (
 package_hash TEXT PRIMARY KEY NOT NULL,
 bundle_hash TEXT NOT NULL,
 app_id TEXT NOT NULL,
 version TEXT NOT NULL,
 relative_path TEXT NOT NULL UNIQUE,
 manifest_json TEXT NOT NULL,
 created_at TEXT NOT NULL
);

CREATE TABLE plugin_project_preferences (
 project_id TEXT NOT NULL,
 app_id TEXT NOT NULL,
 mode TEXT NOT NULL CHECK(mode IN ('follow','individual')),
 PRIMARY KEY(project_id,app_id),
 FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE
);

CREATE TABLE plugin_runtime_health (
 app_id TEXT PRIMARY KEY NOT NULL,
 failures_json TEXT NOT NULL,
 paused INTEGER NOT NULL CHECK(paused IN (0,1)),
 error_code TEXT,
 updated_at TEXT NOT NULL
);

CREATE TABLE plugin_runtime_leases (
 lease_id TEXT PRIMARY KEY NOT NULL,
 app_id TEXT NOT NULL,
 package_hash TEXT NOT NULL REFERENCES plugin_packages(package_hash) ON DELETE RESTRICT,
 kind TEXT NOT NULL CHECK(kind IN ('invocation','activation')),
 host_instance_id TEXT NOT NULL,
 host_pid INTEGER NOT NULL,
 host_started_at TEXT NOT NULL,
 pid INTEGER,
 process_started_at TEXT,
 state TEXT NOT NULL CHECK(state IN ('reserved','launching','running','closed')),
 created_at TEXT NOT NULL, ended_at TEXT
);

CREATE TABLE plugin_ui_reads (
 operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_data_operations(operation_id) ON DELETE CASCADE,
 host_instance_id TEXT NOT NULL,
 host_pid INTEGER NOT NULL,
 host_started_at TEXT NOT NULL
);

CREATE TABLE plugin_write_approvals (
 operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_invocations(operation_id),
 approval_id TEXT NOT NULL UNIQUE,
 run_id TEXT NOT NULL,
 app_id TEXT NOT NULL,
 package_hash TEXT NOT NULL,
 capability TEXT NOT NULL,
 input_hash TEXT NOT NULL,
 review_hash TEXT NOT NULL,
 policy_hash TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('pending','allowed','denied','cancelled','expired','invalidated')),
 host_instance_id TEXT NOT NULL,
 host_pid INTEGER NOT NULL,
 host_started_at TEXT NOT NULL,
 provenance_json TEXT,
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 decided_at INTEGER
);

CREATE TABLE `project_capabilities` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`capability_id` text NOT NULL,
	`enabled` integer DEFAULT true NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE TABLE `project_databases` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`env` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`aliases` text DEFAULT '[]' NOT NULL,
	`vendor` text NOT NULL,
	`host` text NOT NULL,
	`port` integer NOT NULL,
	`database` text DEFAULT '' NOT NULL,
	`schema` text,
	`username` text DEFAULT '' NOT NULL,
	`access_level` text DEFAULT 'readonly' NOT NULL,
	`is_default` integer DEFAULT false NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`last_test_at` integer,
	`last_test_ok` integer,
	`last_test_category` text,
	`last_test_message` text,
	`last_test_ms` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE TABLE `project_dirs` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`path` text NOT NULL,
	`is_default` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE TABLE `project_import_receipts` (
  `request_id` text PRIMARY KEY NOT NULL,
  `fingerprint` text NOT NULL,
  `result` text NOT NULL,
  `created_at` integer NOT NULL
);

CREATE TABLE `project_servers` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text NOT NULL,
	`env` text NOT NULL,
	`label` text DEFAULT '' NOT NULL,
	`aliases` text DEFAULT '[]' NOT NULL,
	`host` text NOT NULL,
	`port` integer DEFAULT 22 NOT NULL,
	`username` text NOT NULL,
	`auth_type` text NOT NULL,
	`private_key_path` text,
	`default_root` integer DEFAULT false NOT NULL,
	`sudo_policy` text DEFAULT 'none' NOT NULL,
	`app_root` text,
	`logs_path` text,
	`note` text DEFAULT '' NOT NULL,
	`last_test_at` integer,
	`last_test_ok` integer,
	`last_test_category` text,
	`last_test_message` text,
	`last_test_ms` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade
);

CREATE TABLE `projects` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`aliases` text DEFAULT '[]' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`rules_path` text,
	`config_version` integer DEFAULT 1 NOT NULL,
	`archived_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);

CREATE TABLE `sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`runner` text NOT NULL,
	`cwd` text NOT NULL,
	`native_session_id` text,
	`title` text NOT NULL,
	`created_at` integer NOT NULL
);

CREATE TABLE `skill_versions` (
	`id` text PRIMARY KEY NOT NULL,
	`skill_id` text NOT NULL,
	`name` text NOT NULL,
	`version` text NOT NULL,
	`hash` text NOT NULL,
	`installed_at` integer NOT NULL,
	`active` integer DEFAULT false NOT NULL
);

CREATE TABLE sqlite_sequence(name,seq);

CREATE TABLE `tasks` (
	`id` text PRIMARY KEY NOT NULL,
	`project_id` text,
	`dir_id` text,
	`cwd` text NOT NULL,
	`ai_profile_id` text,
	`ai_profile_name` text,
	`runner` text NOT NULL,
	`native_session_id` text,
	`title` text NOT NULL,
	`first_message` text DEFAULT '' NOT NULL,
	`injected_env_names` text DEFAULT '[]' NOT NULL,
	`config_version` integer,
	`state_root` text,
	`archived_at` integer,
	`last_launched_at` integer,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL, `runtime_snapshot` text, `native_history_observed` integer,
	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`dir_id`) REFERENCES `project_dirs`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`ai_profile_id`) REFERENCES `ai_profiles`(`id`) ON UPDATE no action ON DELETE set null
);

CREATE TRIGGER m14_claim_legacy_insert BEFORE INSERT ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_native_claim c JOIN m14_binding b ON b.binding_id=c.binding_id WHERE c.runner=NEW.runner AND c.identity_root=NEW.identity_root AND c.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_CLAIM_CONFLICT');END;

CREATE TRIGGER m14_claim_legacy_update BEFORE UPDATE ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_native_claim c JOIN m14_binding b ON b.binding_id=c.binding_id WHERE c.runner=NEW.runner AND c.identity_root=NEW.identity_root AND c.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_CLAIM_CONFLICT');END;

CREATE TRIGGER m14_completion_target_frozen BEFORE UPDATE OF target_binding,target_run,target_generation,input_id ON m14_completion_delivery
WHEN OLD.state NOT IN ('pending','not-sent') AND (OLD.target_binding IS NOT NEW.target_binding OR OLD.target_run IS NOT NEW.target_run OR OLD.target_generation IS NOT NEW.target_generation OR OLD.input_id IS NOT NEW.input_id)
BEGIN SELECT RAISE(ABORT,'COMPLETION_TARGET_FROZEN');END;

CREATE TRIGGER m14_delegation_cycle_insert BEFORE INSERT ON m14_delegation
WHEN EXISTS(WITH RECURSIVE descendants(id) AS (SELECT child_task FROM m14_delegation WHERE parent_task=NEW.child_task UNION SELECT d.child_task FROM m14_delegation d JOIN descendants x ON d.parent_task=x.id) SELECT 1 FROM descendants WHERE id=NEW.parent_task)
BEGIN SELECT RAISE(ABORT,'DELEGATION_CYCLE');END;

CREATE TRIGGER m14_delegation_origin_immutable BEFORE UPDATE OF parent_task,parent_binding,parent_run,parent_generation,child_task,child_binding,turn_id ON m14_delegation
WHEN OLD.parent_task IS NOT NEW.parent_task OR OLD.parent_binding IS NOT NEW.parent_binding OR OLD.parent_run IS NOT NEW.parent_run OR OLD.parent_generation IS NOT NEW.parent_generation OR OLD.child_task IS NOT NEW.child_task OR OLD.child_binding IS NOT NEW.child_binding OR OLD.turn_id IS NOT NEW.turn_id
BEGIN SELECT RAISE(ABORT,'DELEGATION_ORIGIN_IMMUTABLE');END;

CREATE TRIGGER m14_input_origin_immutable BEFORE UPDATE OF input_id,command_id,request_hash,source,text,turn_id,task_id,binding_id,run_id,generation,scope_json,scope_hash,owner_instance,owner_pid,owner_birth ON m14_input
WHEN OLD.input_id IS NOT NEW.input_id OR OLD.command_id IS NOT NEW.command_id OR OLD.request_hash IS NOT NEW.request_hash OR OLD.source IS NOT NEW.source OR OLD.text IS NOT NEW.text OR OLD.turn_id IS NOT NEW.turn_id OR OLD.task_id IS NOT NEW.task_id OR OLD.binding_id IS NOT NEW.binding_id OR OLD.run_id IS NOT NEW.run_id OR OLD.generation IS NOT NEW.generation OR OLD.scope_json IS NOT NEW.scope_json OR OLD.scope_hash IS NOT NEW.scope_hash OR OLD.owner_instance IS NOT NEW.owner_instance OR OLD.owner_pid IS NOT NEW.owner_pid OR OLD.owner_birth IS NOT NEW.owner_birth
BEGIN SELECT RAISE(ABORT,'INPUT_ORIGIN_IMMUTABLE');END;

CREATE TRIGGER m14_old_identity_guard BEFORE UPDATE ON capability_session_identities WHEN EXISTS(SELECT 1 FROM m14_binding b WHERE b.task_id=NEW.task_id AND b.entry_mode='programmatic') BEGIN SELECT RAISE(ABORT,'M14_LEGACY_IDENTITY_SEALED');END;

CREATE TRIGGER m14_old_mcp_insert_guard BEFORE INSERT ON capability_session_mcp_names WHEN EXISTS(SELECT 1 FROM m14_mcp m JOIN m14_binding b USING(binding_id) WHERE m.server_name=NEW.server_name AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_MCP_NAME_CONFLICT');END;

CREATE TRIGGER m14_old_native_insert_guard BEFORE INSERT ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.runner=NEW.runner AND b.identity_root=NEW.identity_root AND b.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_IDENTITY_CONFLICT');END;

CREATE TRIGGER m14_old_native_update_guard BEFORE UPDATE ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.runner=NEW.runner AND b.identity_root=NEW.identity_root AND b.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_IDENTITY_CONFLICT');END;

CREATE TRIGGER m14_old_run_guard BEFORE INSERT ON capability_runs WHEN NEW.execution_mode='legacy' AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.task_id=NEW.task_id AND b.entry_mode='programmatic') BEGIN SELECT RAISE(ABORT,'M14_LEGACY_WRITER_SEALED');END;

CREATE TRIGGER m14_profile_revision_change AFTER UPDATE ON ai_profiles
WHEN OLD.runner IS NOT NEW.runner OR OLD.executable IS NOT NEW.executable OR OLD.env IS NOT NEW.env OR OLD.args IS NOT NEW.args OR OLD.command_pending IS NOT NEW.command_pending
BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE profile_id=NEW.id; END;

CREATE TRIGGER m14_profile_revision_delete AFTER DELETE ON ai_profiles BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1,present=0 WHERE profile_id=OLD.id;
END;

CREATE TRIGGER m14_profile_revision_insert AFTER INSERT ON ai_profiles BEGIN
 INSERT INTO m14_profile_execution_revision VALUES(NEW.id,1,1)
 ON CONFLICT(profile_id) DO UPDATE SET revision=revision+1,present=1;
END;

CREATE TRIGGER m14_result_parent_insert BEFORE INSERT ON m14_completion_delivery WHEN NOT EXISTS(SELECT 1 FROM m14_delegation WHERE id=NEW.delegation_id AND parent_task=NEW.parent_task) BEGIN SELECT RAISE(ABORT,'RESULT_PARENT_CHANGED');END;

CREATE TRIGGER m14_result_parent_update BEFORE UPDATE OF delegation_id,parent_task ON m14_completion_delivery WHEN NOT EXISTS(SELECT 1 FROM m14_delegation WHERE id=NEW.delegation_id AND parent_task=NEW.parent_task) BEGIN SELECT RAISE(ABORT,'RESULT_PARENT_CHANGED');END;

CREATE TRIGGER m14_secret_revision_change AFTER UPDATE ON app_secrets
WHEN OLD.key IS NOT NEW.key OR OLD.secret IS NOT NEW.secret
BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND (NEW.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name') OR OLD.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name')));
END;

CREATE TRIGGER m14_secret_revision_delete AFTER DELETE ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND OLD.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name'));
END;

CREATE TRIGGER m14_secret_revision_insert AFTER INSERT ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (
 SELECT p.id FROM ai_profiles p,json_each(p.env) e WHERE json_extract(e.value,'$.secret')=1 AND NEW.key='ai:'||p.id||':env:'||json_extract(e.value,'$.name'));
END;