CREATE UNIQUE INDEX m14_run_scope_c1 ON capability_runs(run_id,task_id,binding_id,generation);
CREATE TABLE m14_task_state(
 task_id TEXT PRIMARY KEY REFERENCES tasks(id) ON DELETE RESTRICT,
 active_binding TEXT,selection_revision INTEGER NOT NULL DEFAULT 1 CHECK(typeof(selection_revision)='integer' AND selection_revision>0),
 draft_revision INTEGER NOT NULL DEFAULT 0 CHECK(typeof(draft_revision)='integer' AND draft_revision>=0),
 task_seq INTEGER NOT NULL DEFAULT 0 CHECK(typeof(task_seq)='integer' AND task_seq>=0),
 FOREIGN KEY(active_binding,task_id) REFERENCES m14_binding(binding_id,task_id));
CREATE TABLE m14_turn(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES m14_task_state(task_id),binding_id TEXT NOT NULL,
 input TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('queued','dispatching','accepted','running','waiting','canceling','completed','cancelled','failed','not-sent','unknown')),
 run_id TEXT,generation INTEGER,
 CHECK((run_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 UNIQUE(id,task_id),UNIQUE(id,task_id,binding_id),UNIQUE(id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(binding_id,task_id) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));
CREATE TABLE m14_delegation(
 id TEXT PRIMARY KEY,parent_task TEXT NOT NULL,parent_binding TEXT NOT NULL,parent_run TEXT NOT NULL,parent_generation INTEGER NOT NULL,
 child_task TEXT NOT NULL UNIQUE REFERENCES m14_task_state(task_id),child_binding TEXT NOT NULL,turn_id TEXT NOT NULL UNIQUE,
 state TEXT NOT NULL CHECK(state IN ('queued','preparing','running','waiting','canceling','completed','cancelled','failed','unknown')),
 CHECK(parent_task<>child_task),
 UNIQUE(id,parent_task,parent_binding,parent_run,parent_generation),UNIQUE(id,child_task,child_binding),
 FOREIGN KEY(parent_run,parent_task,parent_binding,parent_generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation),
 FOREIGN KEY(turn_id,child_task,child_binding) REFERENCES m14_turn(id,task_id,binding_id));
CREATE TRIGGER m14_delegation_cycle_insert BEFORE INSERT ON m14_delegation
WHEN EXISTS(WITH RECURSIVE descendants(id) AS (SELECT child_task FROM m14_delegation WHERE parent_task=NEW.child_task UNION SELECT d.child_task FROM m14_delegation d JOIN descendants x ON d.parent_task=x.id) SELECT 1 FROM descendants WHERE id=NEW.parent_task)
BEGIN SELECT RAISE(ABORT,'DELEGATION_CYCLE');END;
CREATE TRIGGER m14_delegation_origin_immutable BEFORE UPDATE OF parent_task,parent_binding,parent_run,parent_generation,child_task,child_binding,turn_id ON m14_delegation
WHEN OLD.parent_task IS NOT NEW.parent_task OR OLD.parent_binding IS NOT NEW.parent_binding OR OLD.parent_run IS NOT NEW.parent_run OR OLD.parent_generation IS NOT NEW.parent_generation OR OLD.child_task IS NOT NEW.child_task OR OLD.child_binding IS NOT NEW.child_binding OR OLD.turn_id IS NOT NEW.turn_id
BEGIN SELECT RAISE(ABORT,'DELEGATION_ORIGIN_IMMUTABLE');END;
CREATE TABLE m14_receipt(
 parent_task TEXT NOT NULL,origin_binding TEXT NOT NULL,origin_run TEXT NOT NULL,origin_generation INTEGER NOT NULL,
 request_key TEXT NOT NULL,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),delegation_id TEXT NOT NULL,response TEXT NOT NULL CHECK(json_valid(response)),
 PRIMARY KEY(parent_task,request_key),
 FOREIGN KEY(delegation_id,parent_task,origin_binding,origin_run,origin_generation) REFERENCES m14_delegation(id,parent_task,parent_binding,parent_run,parent_generation));
CREATE TABLE m14_outbox(
 id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL UNIQUE,child_task TEXT NOT NULL,child_binding TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('queued','claimed','reserved','dispatching','initialized','stopped','blocked','unknown')),claim TEXT,reason TEXT,
 run_id TEXT UNIQUE,generation INTEGER,target_profile_id TEXT NOT NULL,target_revision INTEGER NOT NULL CHECK(typeof(target_revision)='integer' AND target_revision>0),
 CHECK((run_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 UNIQUE(id,run_id),
 FOREIGN KEY(delegation_id,child_task,child_binding) REFERENCES m14_delegation(id,child_task,child_binding),
 FOREIGN KEY(run_id,child_task,child_binding,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));
CREATE TABLE m14_run_request(request_key TEXT PRIMARY KEY,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),run_id TEXT NOT NULL UNIQUE,
 FOREIGN KEY(request_key,run_id) REFERENCES m14_outbox(id,run_id));
CREATE TABLE m14_publication(binding_id TEXT PRIMARY KEY REFERENCES m14_binding(binding_id),request_hash TEXT NOT NULL CHECK(length(request_hash)=64),scope_json TEXT NOT NULL CHECK(json_valid(scope_json)));
CREATE TABLE m14_input(
 input_id TEXT PRIMARY KEY,command_id TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 source TEXT NOT NULL CHECK(source IN ('ui-user','history-transfer','agent-delegation','automatic-followup','child-result')),
 text TEXT NOT NULL,turn_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,
 scope_json TEXT NOT NULL CHECK(json_valid(scope_json)),scope_hash TEXT NOT NULL CHECK(length(scope_hash)=64),
 state TEXT NOT NULL CHECK(state IN ('queued','dispatching','unknown','accepted')),
 owner_instance TEXT NOT NULL,owner_pid INTEGER NOT NULL CHECK(typeof(owner_pid)='integer' AND owner_pid>0),owner_birth TEXT NOT NULL,native_json TEXT CHECK(native_json IS NULL OR json_valid(native_json)),
 CHECK(state<>'accepted' OR native_json IS NOT NULL),
 CHECK(json_extract(scope_json,'$.taskId') IS task_id AND json_extract(scope_json,'$.bindingId') IS binding_id AND json_extract(scope_json,'$.runId') IS run_id AND json_extract(scope_json,'$.generation') IS generation),
 UNIQUE(input_id,scope_hash),UNIQUE(input_id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(turn_id,task_id,binding_id,run_id,generation) REFERENCES m14_turn(id,task_id,binding_id,run_id,generation),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));
CREATE TABLE m14_input_inbox(
 event_id TEXT PRIMARY KEY,input_id TEXT NOT NULL,scope_hash TEXT NOT NULL,frame_json TEXT NOT NULL CHECK(json_valid(frame_json)),frame_hash TEXT NOT NULL CHECK(length(frame_hash)=64),processed INTEGER NOT NULL DEFAULT 0 CHECK(processed IN(0,1)),
 FOREIGN KEY(input_id,scope_hash) REFERENCES m14_input(input_id,scope_hash));
CREATE TABLE m14_runtime_request(
 request_id TEXT PRIMARY KEY,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,turn_id TEXT,
 source TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('approval','questions','form','url','unsupported')),native_key TEXT,
 revision INTEGER NOT NULL CHECK(typeof(revision)='integer' AND revision>0),state TEXT NOT NULL CHECK(state IN ('pending','dispatching','resolved','expired','unknown')),
 spec_json TEXT NOT NULL CHECK(json_valid(spec_json)),blocking INTEGER NOT NULL CHECK(blocking IN(0,1)),
 UNIQUE(request_id,task_id,binding_id,run_id,generation),UNIQUE(run_id,generation,source,native_key),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation),
 FOREIGN KEY(turn_id,task_id,binding_id,run_id,generation) REFERENCES m14_turn(id,task_id,binding_id,run_id,generation));
CREATE TABLE m14_response(
 command_id TEXT PRIMARY KEY,request_id TEXT NOT NULL,task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT NOT NULL,generation INTEGER NOT NULL,
 expected_revision INTEGER NOT NULL CHECK(typeof(expected_revision)='integer' AND expected_revision>0),request_hash TEXT NOT NULL CHECK(length(request_hash)=64),
 state TEXT NOT NULL CHECK(state IN ('dispatching','applied','not-sent','unknown')),
 FOREIGN KEY(request_id,task_id,binding_id,run_id,generation) REFERENCES m14_runtime_request(request_id,task_id,binding_id,run_id,generation));
CREATE TABLE m14_event(
 task_id TEXT NOT NULL REFERENCES m14_task_state(task_id),task_seq INTEGER NOT NULL CHECK(typeof(task_seq)='integer' AND task_seq>0),
 protocol INTEGER NOT NULL CHECK(protocol=1),type TEXT NOT NULL,binding_id TEXT,run_id TEXT,generation INTEGER,payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
 CHECK((run_id IS NULL AND binding_id IS NULL AND generation IS NULL) OR (run_id IS NOT NULL AND binding_id IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
 PRIMARY KEY(task_id,task_seq),
 FOREIGN KEY(run_id,task_id,binding_id,generation) REFERENCES capability_runs(run_id,task_id,binding_id,generation));
CREATE TABLE m14_completion_delivery(
 delivery_id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL REFERENCES m14_delegation(id),result_revision INTEGER NOT NULL CHECK(typeof(result_revision)='integer' AND result_revision>0),
 parent_task TEXT NOT NULL,target_binding TEXT,target_run TEXT,target_generation INTEGER,input_id TEXT,
 state TEXT NOT NULL CHECK(state IN ('pending','dispatching','accepted','observed','not-sent','unknown')),
 UNIQUE(delegation_id,result_revision),
 CHECK((target_run IS NULL AND target_generation IS NULL AND input_id IS NULL) OR (target_run IS NOT NULL AND target_binding IS NOT NULL AND typeof(target_generation)='integer' AND target_generation>0 AND input_id IS NOT NULL)),
 FOREIGN KEY(target_binding,parent_task) REFERENCES m14_binding(binding_id,task_id),
 FOREIGN KEY(input_id,parent_task,target_binding,target_run,target_generation) REFERENCES m14_input(input_id,task_id,binding_id,run_id,generation));
CREATE TRIGGER m14_result_parent_insert BEFORE INSERT ON m14_completion_delivery WHEN NOT EXISTS(SELECT 1 FROM m14_delegation WHERE id=NEW.delegation_id AND parent_task=NEW.parent_task) BEGIN SELECT RAISE(ABORT,'RESULT_PARENT_CHANGED');END;
CREATE TRIGGER m14_result_parent_update BEFORE UPDATE OF delegation_id,parent_task ON m14_completion_delivery WHEN NOT EXISTS(SELECT 1 FROM m14_delegation WHERE id=NEW.delegation_id AND parent_task=NEW.parent_task) BEGIN SELECT RAISE(ABORT,'RESULT_PARENT_CHANGED');END;
CREATE TRIGGER m14_input_origin_immutable BEFORE UPDATE OF input_id,command_id,request_hash,source,text,turn_id,task_id,binding_id,run_id,generation,scope_json,scope_hash,owner_instance,owner_pid,owner_birth ON m14_input
WHEN OLD.input_id IS NOT NEW.input_id OR OLD.command_id IS NOT NEW.command_id OR OLD.request_hash IS NOT NEW.request_hash OR OLD.source IS NOT NEW.source OR OLD.text IS NOT NEW.text OR OLD.turn_id IS NOT NEW.turn_id OR OLD.task_id IS NOT NEW.task_id OR OLD.binding_id IS NOT NEW.binding_id OR OLD.run_id IS NOT NEW.run_id OR OLD.generation IS NOT NEW.generation OR OLD.scope_json IS NOT NEW.scope_json OR OLD.scope_hash IS NOT NEW.scope_hash OR OLD.owner_instance IS NOT NEW.owner_instance OR OLD.owner_pid IS NOT NEW.owner_pid OR OLD.owner_birth IS NOT NEW.owner_birth
BEGIN SELECT RAISE(ABORT,'INPUT_ORIGIN_IMMUTABLE');END;
CREATE TRIGGER m14_completion_target_frozen BEFORE UPDATE OF target_binding,target_run,target_generation,input_id ON m14_completion_delivery
WHEN OLD.state NOT IN ('pending','not-sent') AND (OLD.target_binding IS NOT NEW.target_binding OR OLD.target_run IS NOT NEW.target_run OR OLD.target_generation IS NOT NEW.target_generation OR OLD.input_id IS NOT NEW.input_id)
BEGIN SELECT RAISE(ABORT,'COMPLETION_TARGET_FROZEN');END;
