import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import Database from '/private/tmp/willyou-m14-owner-probe/node_modules/better-sqlite3/lib/index.js';
import a from '/private/tmp/willyou-m14-claude-live-origin-probe/actual.cjs';
const root=import.meta.dirname,prior='/private/tmp/willyou-m14-claude-live-origin-probe';
const sha=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(readFileSync(prior+'/actual-build.json','utf8'));
for(const item of manifest.sources)assert.equal(sha(readFileSync(item.path)),item.sha256,'SOURCE_CHANGED:'+item.path);
const source=prior+'/attempt-5LsY47/final.sqlite';const original=new Database(source,{readonly:true});
assert.equal(original.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(original.pragma('foreign_key_check'),[]);
await original.backup(root+'/seed.sqlite');original.close();
const db=new Database(root+'/seed.sqlite');db.pragma('foreign_keys=ON');
const old=db.prepare('SELECT * FROM capability_runs').get();assert.equal(old.state,'stopped');
const bindings=db.prepare('SELECT * FROM m14_binding').all();
for(const b of bindings){db.prepare("INSERT OR IGNORE INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,1,1)").run(b.task_id,old.project_id,b.cwd,b.runner,'Synthetic relational fixture');}
const originalSnapshot=JSON.parse(db.prepare('SELECT snapshot_json FROM m14_revision WHERE snapshot_hash=?').get(old.source_snapshot_hash).snapshot_json);
const slots=[];
for(const [taskId,suffix] of [[old.task_id,'alternate'],[randomUUID(),'child'],[randomUUID(),'foreign']]){
 db.prepare("INSERT OR IGNORE INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,1,1)").run(taskId,old.project_id,originalSnapshot.native.cwd,originalSnapshot.runner,'Synthetic '+suffix);
 const bindingId=randomUUID(),capId=randomUUID(),runId=randomUUID();
 const snapshot=a.storedCapabilitySessionSnapshotSchema.parse({...originalSnapshot,taskId,native:{...originalSnapshot.native,sessionId:null,stateRoot:root+'/state-'+suffix},mcp:originalSnapshot.mcp.map(m=>({...m,serverName:a.applicationMcpServerName(a.digest(taskId+suffix))}))});
 const json=a.canonicalJson(snapshot),hash=a.digest(json);
 db.transaction(()=>{
 db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,identity_root,cwd,entry_mode,phase,run_generation) VALUES(?,?,?,?,?,'programmatic','prepared',1)").run(bindingId,taskId,snapshot.runner,snapshot.native.stateRoot,snapshot.native.cwd);
 db.prepare("INSERT INTO m14_cap VALUES(?,?,?,'active',NULL)").run(capId,taskId,bindingId);
 db.prepare('INSERT INTO m14_revision VALUES(?,?,?,?,?,?,?)').run(capId,taskId,bindingId,hash,json,snapshot.schema,a.selectionHash(snapshot));
 db.prepare('INSERT INTO m14_ref SELECT ?,?,ref_id,ref_kind,ref_hash,relative_path,? FROM m14_ref WHERE cap_id=? AND snapshot_hash=?').run(capId,hash,taskId,old.capability_session_id,old.source_snapshot_hash);
 db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(hash,capId);
 const row={...old,run_id:runId,task_id:taskId,snapshot_hash:hash,source_snapshot_hash:hash,binding_id:bindingId,capability_session_id:capId,pid:null,process_started_at:null,pty_id:null};
 db.prepare('INSERT INTO capability_runs('+Object.keys(row).join(',')+') VALUES('+Object.keys(row).map(()=>'?').join(',')+')').run(...Object.values(row));
 })();slots.push({taskId,bindingId,capId,runId,generation:1,hash,suffix});
}
assert.deepEqual(db.pragma('foreign_key_check'),[]);db.close();
writeFileSync(root+'/fixture.json',JSON.stringify({source,sourceSHA256:sha(readFileSync(source)),bundle:prior+'/actual.cjs',sourceCount:manifest.sources.length,original:{taskId:old.task_id,bindingId:old.binding_id,capId:old.capability_session_id,runId:old.run_id,generation:old.generation,hash:old.source_snapshot_hash},slots,scope:'Offline copy of synthetic successful experiment database. Added synthetic tasks and stopped rows for relational scope testing only; no run admission, native startup or business action.'},null,2));
copyFileSync('/private/tmp/willyou-m14-delegation-launch-joint-probe/joint.sql',root+'/prior-joint.sql');
for(const f of ['delivery.sql','execution.sql','revision.sql'])copyFileSync('/private/tmp/willyou-m14-delegation-launch-joint-probe/'+f,root+'/'+f);
console.log(JSON.stringify({verifiedSourceInputs:manifest.sources.length,syntheticScopes:4}));
