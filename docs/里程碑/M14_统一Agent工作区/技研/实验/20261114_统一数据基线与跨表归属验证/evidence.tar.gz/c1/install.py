import sqlite3,hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
FILES=['graph.sql','revision.sql','delivery.sql','execution.sql']
def fingerprint(db):
 rows=db.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name").fetchall()
 return hashlib.sha256(json.dumps([tuple(r) for r in rows],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def statements(text):
 statement=''
 for line in text.splitlines(True):
  statement+=line
  if sqlite3.complete_statement(statement):
   yield statement;statement=''
 assert not statement.strip(),'INCOMPLETE_SQL'
def install(db,checkpoint=lambda _:None):
 assert not db.in_transaction;assert db.execute('PRAGMA foreign_keys').fetchone()[0]==1
 inputs=hashlib.sha256(b''.join(n.encode()+b'\0'+(R/n).read_bytes() for n in FILES)).hexdigest()
 exists=db.execute("SELECT 1 FROM sqlite_master WHERE name='m14_contract_baseline'").fetchone()
 if exists:
  row=db.execute('SELECT revision,inputs_hash,schema_hash FROM m14_contract_baseline').fetchone()
  assert row and row[0]=='C1' and row[1]==inputs and row[2]==fingerprint(db),'BASELINE_MISMATCH'
  return 'already-installed'
 db.execute('BEGIN IMMEDIATE')
 try:
  for name in FILES:
   for s in statements((R/name).read_text()):db.execute(s)
   checkpoint(name)
  db.execute('CREATE TABLE m14_contract_baseline(revision TEXT PRIMARY KEY,inputs_hash TEXT NOT NULL,schema_hash TEXT NOT NULL)')
  assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
  db.execute('INSERT INTO m14_contract_baseline VALUES(?,?,?)',('C1',inputs,fingerprint(db)))
  checkpoint('before-commit');db.execute('COMMIT')
  return 'installed'
 except BaseException:
  if db.in_transaction:db.execute('ROLLBACK')
  raise
