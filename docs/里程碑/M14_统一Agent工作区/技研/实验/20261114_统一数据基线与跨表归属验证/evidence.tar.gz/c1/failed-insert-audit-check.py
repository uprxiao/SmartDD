import sqlite3,json,hashlib,uuid,pathlib,traceback
R=pathlib.Path(__file__).resolve().parent;f=json.loads((R/'fixture.json').read_text());A=f['original'];ALT,B,C=f['slots'];H='a'*64
from install import install,fingerprint
checks=[]
def connect(name):
 src=sqlite3.connect('file:'+str(R/'seed.sqlite')+'?mode=ro',uri=True);db=sqlite3.connect(R/name,isolation_level=None);src.backup(db);src.close();db.execute('PRAGMA foreign_keys=ON');db.row_factory=sqlite3.Row;return db
def save(): (R/'result.json').write_text(json.dumps({'checks':checks,'passed':sum(x['status']=='passed' for x in checks),'scope':'Offline SQLite relational constraints only; not runtime/schema/service/end-to-end completion.'},ensure_ascii=False,indent=2))
def check(name,fn):
 try:r=fn();checks.append({'name':name,'status':'passed','evidence':r});save()
 except Exception as e:checks.append({'name':name,'status':'failed','error':traceback.format_exc()});save();raise

def insert(db,table,**row):
 db.execute('INSERT INTO '+table+'('+','.join(row)+') VALUES('+','.join('?' for _ in row)+')',list(row.values()))
def denied(db,sql,args,expected='FOREIGN KEY'):
 db.execute('SAVEPOINT negative')
 try:
  try:db.execute(sql,args)
  except sqlite3.IntegrityError as e:
   assert expected in str(e),(expected,str(e));return str(e)
  raise AssertionError('invalid mutation accepted: '+sql)
 finally: db.execute('ROLLBACK TO negative');db.execute('RELEASE negative')
def scope(x):return {k:x[k] for k in ['taskId','bindingId','runId','generation']}
def turn(db,id,s):insert(db,'m14_turn',id=id,task_id=s['taskId'],binding_id=s['bindingId'],input='synthetic',state='queued',run_id=s['runId'],generation=s['generation'])
def delegation(db,id,parent,child,tid):insert(db,'m14_delegation',id=id,parent_task=parent['taskId'],parent_binding=parent['bindingId'],parent_run=parent['runId'],parent_generation=parent['generation'],child_task=child['taskId'],child_binding=child['bindingId'],turn_id=tid,state='queued')
def inp(db,id,s,tid,source='ui-user'):
 insert(db,'m14_input',input_id=id,command_id=id,request_hash=H,source=source,text='synthetic',turn_id=tid,task_id=s['taskId'],binding_id=s['bindingId'],run_id=s['runId'],generation=s['generation'],scope_json=json.dumps(scope(s)),scope_hash=hashlib.sha256(json.dumps(scope(s)).encode()).hexdigest(),state='queued',owner_instance='offline-fixture',owner_pid=1,owner_birth='not-live')
def original_holes():
 d=connect('negative-original.sqlite');d.executescript((R/'prior-joint.sql').read_text())
 insert(d,'m14_turn',id='wrong-turn',task_id=B['taskId'],binding_id=C['bindingId'],input='wrong',state='queued')
 insert(d,'m14_delegation',id='wrong-delegation',parent_task=A['taskId'],parent_run=C['runId'],child_task=B['taskId'],turn_id='wrong-turn',state='queued')
 insert(d,'m14_outbox',id='wrong-outbox',delegation_id='wrong-delegation',state='reserved',run_id=A['runId'],target_profile_id='fixture',target_revision=1)
 assert d.execute('PRAGMA foreign_key_check').fetchall()==[];d.close();return {'acceptedWrongTurnBinding':True,'acceptedWrongParentRun':True,'acceptedWrongChildRun':True,'existingForeignKeyCheck':'clean despite wrong ownership'}
check('C1-01 original joint schema admits cross-task combinations',original_holes)
d=connect('candidate.sqlite')
install(d)
for s in [A,B,C]:insert(d,'m14_task_state',task_id=s['taskId'],active_binding=s['bindingId'])
for id,s in [('ta',A),('tb',B),('tc',C),('talt',ALT)]:turn(d,id,s)
delegation(d,'dab',A,B,'tb');delegation(d,'dbc',B,C,'tc')
insert(d,'m14_receipt',parent_task=A['taskId'],origin_binding=A['bindingId'],origin_run=A['runId'],origin_generation=1,request_key='create-b',request_hash=H,delegation_id='dab',response='{}')
insert(d,'m14_outbox',id='out-b',delegation_id='dab',child_task=B['taskId'],child_binding=B['bindingId'],state='reserved',run_id=B['runId'],generation=1,target_profile_id='synthetic-profile',target_revision=1)
insert(d,'m14_run_request',request_key='out-b',request_hash=H,run_id=B['runId'])
for id,s,t in [('ia',A,'ta'),('ib',B,'tb'),('ialt',ALT,'talt')]:inp(d,id,s,t,'child-result' if id=='ialt' else 'ui-user')
insert(d,'m14_runtime_request',request_id='req-b',task_id=B['taskId'],binding_id=B['bindingId'],run_id=B['runId'],generation=1,turn_id='tb',source='runtime',kind='questions',native_key='rpc:1',revision=1,state='pending',spec_json='{}',blocking=1)
insert(d,'m14_response',command_id='reply-b',request_id='req-b',task_id=B['taskId'],binding_id=B['bindingId'],run_id=B['runId'],generation=1,expected_revision=1,request_hash=H,state='dispatching')
insert(d,'m14_completion_delivery',delivery_id='result-b',delegation_id='dab',result_revision=1,parent_task=A['taskId'],target_binding=ALT['bindingId'],target_run=ALT['runId'],target_generation=1,input_id='ialt',state='pending')
check('C1-02 compatible task graph and previous resource schemas coexist',lambda:{'tables':d.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0],'deliveryTargetIsNewParentBinding':True})
check('C1-03 turn cannot borrow another task binding',lambda:denied(d,"INSERT INTO m14_turn(id,task_id,binding_id,input,state) VALUES('bad-turn',?,?,'x','queued')",(B['taskId'],C['bindingId'])))
check('C1-04 turn cannot borrow another task run or wrong generation',lambda:[denied(d,"INSERT INTO m14_turn VALUES('bad-run-turn',?,?,'x','queued',?,1)",(B['taskId'],B['bindingId'],C['runId'])),denied(d,"INSERT INTO m14_turn VALUES('bad-gen-turn',?,?,'x','queued',?,2)",(B['taskId'],B['bindingId'],B['runId']))])
def bad_parent_insert():
 d.execute('SAVEPOINT parent-insert')
 try:
  d.execute("DELETE FROM m14_delegation WHERE id='dbc'")
  return denied(d,"INSERT INTO m14_delegation VALUES('bad-dac',?,?,?,?,?,?,?,'queued')",(A['taskId'],A['bindingId'],B['runId'],1,C['taskId'],C['bindingId'],'tc'))
 finally:d.execute('ROLLBACK TO parent-insert');d.execute('RELEASE parent-insert')
check('C1-05 delegation cannot use foreign parent, change origin or create cycle',lambda:[bad_parent_insert(),denied(d,'UPDATE m14_delegation SET parent_run=? WHERE id=?',(C['runId'],'dab'),'DELEGATION_ORIGIN_IMMUTABLE'),denied(d,"INSERT INTO m14_delegation VALUES('dca',?,?,?,?,?,?,?,'queued')",(C['taskId'],C['bindingId'],C['runId'],1,A['taskId'],A['bindingId'],'ta'),'DELEGATION_CYCLE')])
check('C1-06 receipt must match delegation origin',lambda:denied(d,'UPDATE m14_receipt SET origin_run=?',(C['runId'],)))
check('C1-07 outbox and run receipt cannot target another run',lambda:[denied(d,"INSERT INTO m14_outbox(id,delegation_id,child_task,child_binding,state,run_id,generation,target_profile_id,target_revision) VALUES('bad-out-c','dbc',?,?,'reserved',?,1,'fixture',1)",(C['taskId'],C['bindingId'],A['runId'])),denied(d,'UPDATE m14_run_request SET run_id=?',(A['runId'],))])
def bad_input_insert():
 row=dict(d.execute("SELECT * FROM m14_input WHERE input_id='ib'").fetchone());row.update(input_id='bad-scope',command_id='bad-scope',scope_json=json.dumps(scope(C)))
 sql='INSERT INTO m14_input('+','.join(row)+') VALUES('+','.join('?' for _ in row)+')'
 return denied(d,sql,list(row.values()),'CHECK')
check('C1-08 input scope JSON cannot diverge from typed owner',bad_input_insert)
check('C1-09 input inbox cannot attach another source hash',lambda:denied(d,"INSERT INTO m14_input_inbox VALUES('bad-inbox','ib',?,'{}',?,0)",(H,H)))
check('C1-10 runtime request and reply remain in exact run',lambda:[denied(d,'UPDATE m14_runtime_request SET turn_id=? WHERE request_id=?',('ta','req-b')),denied(d,'UPDATE m14_response SET run_id=?',(C['runId'],))])
check('C1-11 session-level request allows absent turn but not foreign run',lambda:(insert(d,'m14_runtime_request',request_id='req-session',task_id=B['taskId'],binding_id=B['bindingId'],run_id=B['runId'],generation=1,turn_id=None,source='runtime',kind='form',native_key='rpc:2',revision=1,state='pending',spec_json='{}',blocking=0),denied(d,'UPDATE m14_runtime_request SET run_id=? WHERE request_id=?',(A['runId'],'req-session')))[1])
check('C1-12 child result may retarget parent binding but never another task',lambda:[denied(d,'UPDATE m14_completion_delivery SET parent_task=?',(B['taskId'],),'RESULT_PARENT_CHANGED'),denied(d,'UPDATE m14_completion_delivery SET input_id=?',('ib',))])
def event_tx():
 d.execute('BEGIN IMMEDIATE')
 try:
  d.execute('UPDATE m14_task_state SET task_seq=task_seq+1 WHERE task_id=?',(A['taskId'],))
  seq=d.execute('SELECT task_seq FROM m14_task_state WHERE task_id=?',(A['taskId'],)).fetchone()[0]
  insert(d,'m14_event',task_id=A['taskId'],task_seq=seq,protocol=1,type='turn.state',binding_id=A['bindingId'],run_id=A['runId'],generation=1,payload_json='{}')
  d.execute("UPDATE m14_turn SET state='accepted' WHERE id='ta'")
  raise RuntimeError('injected-before-commit')
 except RuntimeError:d.execute('ROLLBACK')
 assert d.execute('SELECT task_seq FROM m14_task_state WHERE task_id=?',(A['taskId'],)).fetchone()[0]==0
 assert d.execute('SELECT count(*) FROM m14_event').fetchone()[0]==0
 assert d.execute("SELECT state FROM m14_turn WHERE id='ta'").fetchone()[0]=='queued'
 return {'projectionEventSequenceRolledBackTogether':True,'injectedPythonExceptionNotHostCrash':True}
check('C1-13 transaction rollback preserves projection event and sequence',event_tx)
check('C1-14 referenced run generation cannot mutate under consumers',lambda:denied(d,'UPDATE capability_runs SET generation=2 WHERE run_id=?',(B['runId'],)))
check('C1-15 active selection cannot point to another task binding',lambda:denied(d,'UPDATE m14_task_state SET active_binding=? WHERE task_id=?',(C['bindingId'],A['taskId'])))
check('C1-16 input accepted requires native evidence and known source',lambda:[denied(d,"UPDATE m14_input SET state='accepted' WHERE input_id='ib'",(),'CHECK'),denied(d,"UPDATE m14_input SET source='native-user-role' WHERE input_id='ib'",(),'INPUT_ORIGIN_IMMUTABLE')])
check('C1-17 task event cannot combine task and foreign run',lambda:denied(d,"INSERT INTO m14_event VALUES(?,1,1,'turn.state',?,?,1,'{}')",(A['taskId'],C['bindingId'],C['runId'])))
def final():
 assert d.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert d.execute('PRAGMA foreign_key_check').fetchall()==[]
 schema=[dict(x) for x in d.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name")]
 (R/'combined-schema.json').write_text(json.dumps(schema,indent=2));(R/'combined-schema.sql').write_text('\n\n'.join(x['sql']+';' for x in schema))
 d.close();r=sqlite3.connect('file:'+str(R/'candidate.sqlite')+'?mode=ro',uri=True);assert r.execute('PRAGMA integrity_check').fetchone()[0]=='ok';r.close()
 return {'integrity':'ok','foreignKeys':0,'reopen':'ok','schemaObjects':len(schema),'schemaSHA256':hashlib.sha256((R/'combined-schema.sql').read_bytes()).hexdigest()}
check('C1-18 source cannot become human after capture',lambda:denied(d,"UPDATE m14_input SET source='ui-user' WHERE input_id='ialt'",(),'INPUT_ORIGIN_IMMUTABLE'))
def late_target():
 d.execute("UPDATE m14_completion_delivery SET state='dispatching' WHERE delivery_id='result-b'")
 error=denied(d,"UPDATE m14_completion_delivery SET target_binding=?,target_run=?,target_generation=1,input_id='ia' WHERE delivery_id='result-b'",(A['bindingId'],A['runId']),'COMPLETION_TARGET_FROZEN')
 d.execute("UPDATE m14_completion_delivery SET state='unknown' WHERE delivery_id='result-b'")
 error2=denied(d,"UPDATE m14_completion_delivery SET target_binding=?,target_run=?,target_generation=1,input_id='ia' WHERE delivery_id='result-b'",(A['bindingId'],A['runId']),'COMPLETION_TARGET_FROZEN')
 return [error,error2]
check('C1-19 dispatched or unknown result cannot reroute',late_target)
def install_faults():
 evidence=[]
 for point in ['graph.sql','delivery.sql','before-commit']:
  db=connect('install-fault-'+point.replace('.','-')+'.sqlite');before=fingerprint(db)
  def fail(at):
   if at==point:raise RuntimeError('INJECTED_INSTALL_FAILURE')
  try:install(db,fail);raise AssertionError('fault missing')
  except RuntimeError as e:assert str(e)=='INJECTED_INSTALL_FAILURE'
  assert fingerprint(db)==before;assert not db.in_transaction
  assert install(db)=='installed';assert install(db)=='already-installed'
  assert db.execute('PRAGMA foreign_key_check').fetchall()==[];db.close()
  evidence.append({'point':point,'rollbackToExactSchema':True,'retry':'installed','repeat':'already-installed'})
 return evidence
check('C1-20 unified install failure rollback and repeat',install_faults)
check('C1-21 same schema recognized without reapplying',lambda:install(d))
def tampered():
 target=sqlite3.connect(R/'tampered-copy.sqlite',isolation_level=None);d.backup(target);target.execute('PRAGMA foreign_keys=ON')
 target.execute('DROP TRIGGER m14_input_origin_immutable')
 try:
  try:install(target);raise AssertionError('drift accepted')
  except AssertionError as e:assert str(e)=='BASELINE_MISMATCH'
 finally:target.close()
 return {'schemaDriftRejected':True,'isolatedCommittedCopy':True}
check('C1-22 changed schema does not masquerade as same revision',tampered)
check('C1-23 final schema and reopen integrity',final)
print(json.dumps({'passed':len(checks),'result':str(R/'result.json')}))
