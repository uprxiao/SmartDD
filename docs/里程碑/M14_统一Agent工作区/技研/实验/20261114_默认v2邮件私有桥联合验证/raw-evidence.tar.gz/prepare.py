from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_默认v2邮件私有桥联合验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==3 and r['error'] is None and r['unexpectedData']==0
builds={n:json.loads((root/n).read_text()) for n in ['build.json','bridge-build.json']}
for b in builds.values():
 for e in b['sources']+b['outputs']:
  path=e.get('path',e.get('file'));assert path and sha(Path(path).read_bytes())==e['sha256'],path
a=Path(r['out']);cleanup=json.loads((a/'cleanup.json').read_text());terminal=json.loads((a/'terminal.json').read_text())
assert all(x['kernelState']=='stopped' for x in cleanup)
assert all(x['state']=='stopped' for x in terminal['runs']) and all(x['state']=='released' for x in terminal['leases'])
resources=[repo/'scripts/applications/build-bundles.mjs',repo/'scripts/applications/verify-bundles.cjs']
for name in ['resources/applications','resources/agent-adapters']:resources.extend(p for p in (repo/name).rglob('*') if p.is_file())
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'builds':builds,'resources':[{'path':str(p.relative_to(repo)),'sha256':sha(p.read_bytes())} for p in resources],'distribution':{'mode':'default definitions, NOT retained-v1-test-fixture','index':json.loads((root/'bundles/index.json').read_text()),'adaptation':'Isolated copy of actual build-bundles rewrites imports and pins rebuilt research bridge hash; original definitions retained.'},'actual':['ApplicationService','ApplicationExecutionContexts','MailSendDataService','MailUserAuthorizations','MailSenderIdentity','ApplicationToolService','CapabilitySessionRegistry','CapabilityRunRegistry','CurrentApplicationAuthorization','PrivateApplicationBroker','AgentBridgeProcesses','MacProcessIdentityReader','MacUnixPeerIdentityReader','bridge-runtime'],'controlled':['Node stdio protocol owners instead of native Agent processes','renderer sender and trust predicate','secret cipher','SMTP submit function'],'limits':['Two different tasks in one project, not provider switch within one task','No Claude SDK, Codex app-server, native input receipt, or model requests in this experiment','Schema-3 legacy session/run entry, not candidate programmatic binding schema','No human UI approval, real SMTP delivery, packaged application or product acceptance'],'cleanup':cleanup,'terminal':terminal,'failures':{'attempt-x2r9ze':'Driver expected v1 top-level draft; actual default v2 valid envelope stores data.draft. Failure retained; driver now validates schema/major/status/operation ID then reads data.','attempt-aPXJDn':'Sandbox denied loopback listen before checks. Same isolated probe ran with approved escalation.'}}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','build-bridge.mjs','bridge-build.json','mcp-bridge.cjs','build-fixture-bundles.mjs','probe.mjs','bridge-owner.mjs','client.mjs','source-review.json','CONTINUATION.md','prepare.py']]
for d in [root/'bundles',*sorted(root.glob('attempt-*'))]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts)
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 默认 v2 邮件私有桥联合验证

日期：2026-11-14。D04；关联 Q09／Q12／Q41。承接 §4.101，将默认 mail 1.1.0／contractMajor 2、实际 schema-3 快照／运行计划、当前授权、私有 MCP 桥和现有邮件服务接入同一个隔离数据库。最终 attempt-5A33jQ 三项通过；不是产品实现或验收。

## 基线与边界

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`。业务构建 681 项输入，bridge 构建 205 项输入，归档前逐项核对摘要。原 build-bundles 的临时副本只改导入位置和研究桥摘要，采用默认定义，没有开启 retained-v1-test-fixture。实际包注册器验证、安装分发内容。

两个受控 Node 协议宿主分别在同项目的不同 task 运行；实际 MCP bridge 是各宿主的子进程，实际内核身份读取器验证 PID／出生身份和祖先关系。不是 Claude SDK／Codex app-server，也不是同一 task 的 Provider 切换。renderer 与信任谓词、cipher、最终 submit 为夹具；现有邮件冻结、授权、原运行检查和调用账为实际实现。连接测试只向本次自有回环服务器认证，服务器拒绝 DATA；无真实邮件、模型或外部账号。

## 结果

| 检查 | 实际证据 |
| --- | --- |
| V01 默认分发与真实桥 | mail v2 工具和 contractMajor 2 进入实际 run plan；两次桥认证通过内核祖先检查 |
| V02 权限与一次执行 | 通过真实 MCP 创建草稿和发送意图；未授权拒绝。实际 UI 审阅服务批准后，同项目另一 run 可读意图但不能执行；来源 run 受控提交一次，重复调用返回相同 execution |
| V03 当前授权 | 停用邮件后，旧缓存工具调用返回 APP_NOT_ENABLED，下一次 tools/list 为空；持久启动计划保持不变，没有追加 submit |

最终两宿主 exit 0 且内核报告 stopped，两 run stopped、18 份租约 released；SQLite 完整性与外键通过。一次回环认证、一次受控 submit、零 DATA。

## 失败与修正

attempt-x2r9ze 的 V01 通过，V02 驱动误按 v1 返回值读取 `.draft`，实际 MCP 已返回合法 `willyou-app-result-v2`。只修正隔离驱动：校验 schema、contractMajor、status，以及 envelope.operation.id 与 MCP meta 一致，再读取 data；保留原始失败、原调用输出和清理记录。attempt-aPXJDn 在监听阶段 EPERM，零检查／认证／提交；工具批准后执行同一实验。未改产品实现或降低预期。

## 设计结论及剩余项

统一 UI／Driver 必须按声明版本解析业务结果，保留 source、completeness、resources 和 operation 等元数据。不能把 envelope 当旧 data，也不能让 UI 展示层解包后的业务对象充当授权或完整性证明。MCP 声明和持久 run plan 描述可调用能力；执行仍按当前授权核验。缓存工具可见不保证仍可执行，停用不应改写原启动事实。

本轮补默认 v2 与真实私有桥到实际业务的证据；程序化绑定／原生输入来源、同任务跨 Provider 与同库准入／恢复仍未联合。后续复用本批业务链，按 D01 的统一研究 Schema 接入；不重复用协议宿主代替实际 SDK 来源证明。产品用例状态与 Q 宽口径统计不变。

复现：按归档 build.mjs／build-bridge.mjs 固定依赖构建，在 SmartDD cwd 执行临时 build-fixture-bundles.mjs 生成默认研究分发，然后运行 probe.mjs；需要环境允许回环监听。见[结果](result.json)、[来源清单](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
old='当前证据使用受控进程身份、renderer 事件和禁止执行桥的 retained-v1 测试分发，默认 v2／实际原生来源与新入口联合仍待验。'
new='上述八项证据使用受控进程身份、renderer 事件和禁止执行桥的 retained-v1 测试分发。后续[默认 v2 私有桥实验](实验/20261114_默认v2邮件私有桥联合验证/README.md)已通过真实桥进程、内核祖先校验和实际 schema-3 运行入口接入现有邮件服务，补证同项目跨 run 读取不授予执行权、来源 run 重放不重复提交，以及当前停用拒绝旧缓存调用。该批宿主为 Node 协议夹具，实际 SDK 原生输入来源、程序化 binding 与同任务切换仍待联合。'
assert old in t;t=t.replace(old,new,1)
needle='**独立业务活动不能从 run 状态推断。**'
new='**业务结果版本与当前授权分开。** 默认 mail v2 的结果使用 `willyou-app-result-v2` 信封，业务对象位于 data；统一层按声明版本验证并保留来源、完整性、资源与 operation 元数据，不能套用旧 v1 顶层形状。MCP meta 的 operationId 与业务信封相互核对用于关联，不代替权限凭据。能力列表可缓存、启动计划保持不可变，但执行必须重新核验当前政策；应用停用后旧工具名须明确拒绝，不能因历史声明仍存在继续执行。上述行为已由默认 v2 实际桥实验限定验证。\n\n'
assert needle in t;t=t.replace(needle,new+needle,1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.102 ' not in t
add='''### 4.102 默认 v2 分发、私有桥与邮件业务联合

[三项默认 v2 私有桥检查](实验/20261114_默认v2邮件私有桥联合验证/README.md)接入实际 schema-3 会话／运行计划、CurrentApplicationAuthorization、私有 broker／bridge、内核进程祖先校验与邮件服务。默认 mail 1.1.0／contractMajor 2 广告通过；实际审阅后另一 run 可读但不可执行，来源 run 一次提交且重放返回同执行；停用后旧工具调用拒绝、列表清空、持久启动计划不变。

两宿主和 run 全部 stopped、18 租约 released，完整性／外键通过；一次回环认证、一次受控 submit、零 DATA。保留驱动按 v1 形状误读 v2 data 的失败及监听 EPERM；只修正验证驱动，未改产品。Node 协议宿主替代实际 Agent，renderer／cipher／submit 为夹具，两个 task 共享项目；不覆盖程序化 binding、原生用户输入、同任务 Provider 切换或正式 UI。技术方案 §9.2.2 合并结果信封和动态授权合同，D04 下一步与 D01 同库模型联合；Q 统计不变。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D04 '):
  c=l.split('|');c[2]=' §4.99–102 已补候选汇总、实际活动／邮件回执／核实／上下文，以及默认 v2 私有桥到实际业务；run stopped 不代表独立业务租约释放。下一步按 D01 同一研究 Schema 联合程序化 binding、原生输入来源与现有业务链，验证同任务续聊／委派中的对象范围、提交后变化、业务租约／结果修订和崩溃恢复。§4.102 的 Node 协议宿主不能替代 SDK 输入证明；既有插件／浏览器证据复用，清理覆盖与大库查询另验 ';lines[i]='|'.join(c)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.101，56','截至 §4.102，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：默认 v2 邮件能力经真实私有 MCP 桥和内核身份校验接入现有业务，三项检查通过，补证跨 run 执行隔离和当前停用覆盖缓存工具。见[实验记录](技研/实验/20261114_默认v2邮件私有桥联合验证/README.md)；宿主仍为 Node 协议夹具，不代表 SDK 全链路或产品验收，统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04](技研/全局设计验证账.md#71-当前全局收口方式)固定同一研究 Schema，联合程序化绑定／原生输入、历史身份占用、同库准入与业务结果恢复。默认 v2 私有桥和已有业务服务复用，真实 UI／安装验收留在产品阶段。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size}))
