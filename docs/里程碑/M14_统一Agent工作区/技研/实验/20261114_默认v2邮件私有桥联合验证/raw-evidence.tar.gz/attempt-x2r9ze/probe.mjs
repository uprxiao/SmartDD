import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {createServer} from 'node:net';
import {EventEmitter} from 'node:events';
import {mkdtempSync,mkdirSync,writeFileSync,copyFileSync,cpSync} from 'node:fs';
import Database from 'better-sqlite3';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {appendFileSync} from 'node:fs';
import {client} from './client.mjs';
import a from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2));
for(const n of ['probe.mjs','build.mjs','build.json','build-bridge.mjs','bridge-build.json','bridge-owner.mjs','client.mjs'])copyFileSync(root+'/'+n,out+'/'+n);
const deadline=(p,label)=>{let t;return Promise.race([p,new Promise((_,reject)=>t=setTimeout(()=>reject(Error('OBSERVATION_TIMEOUT:'+label)),30000))]).finally(()=>clearTimeout(t));};
const checks=[],owned=[],sockets=new Set();let broker,supervisor;const proofs=[];let error,db,app,runs,server,reader,submissions=0,authentications=0,unexpectedData=0,submitBehavior,finishPending;
const check=async(id,title,fn)=>{try{const evidence=await fn();checks.push({id,title,status:'passed',evidence});save(id+'.json',evidence);}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
try{
 db=new Database(out+'/state.sqlite');db.pragma('foreign_keys=ON');a.runBundledMigrations(db);const store=new a.ResourceStore(db,out+'/capabilities'),secrets=a.makeSyntheticSecrets(db),projects=new a.ProjectService(a.drizzle(db,{schema:a.schema}),secrets),project=projects.createProject({name:'Isolated mail entry',aliases:[],description:'',rulesPath:null});
 const projectId=project.id,source=new a.CapabilityBundleSource(root+'/bundles');await new a.RuntimeRegistry(store).install(source.runtime());const trusted=new a.BuiltinPackageRegistry(store),pack=await trusted.install(source,source.index.apps.find(p=>p.appId==='mail'));await trusted.packages.activate(pack.packageHash,0);
 reader=new a.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');assert(reader.read(process.pid));const wc=Object.assign(new EventEmitter(),{id:101,mainFrame:{processId:9,routingId:1},isDestroyed:()=>false}),sender={sender:wc,senderFrame:wc.mainFrame};
 const requireSender=s=>{if(s.sender!==wc||s.senderFrame!==wc.mainFrame)throw Error('Untrusted fixture window');};
 submitBehavior=(_c,_s,m)=>({state:'server-accepted',complete:true,accepted:m.envelope.to,rejected:[],errorCode:null,smtpCode:250,messageId:m.messageId});
 app=new a.ApplicationService(store,{secrets,projects,tasks:{stopProject:async()=>true,runningInProject:()=>0},requireSender,mailWorker:out+'/unused-mail-worker',foxmailNative:out+'/unused-foxmail',processes:reader,mailSend:{submit:async(...args)=>{submissions++;return submitBehavior(...args);}}});await app.recover();
 server=createServer(socket=>{sockets.add(socket);socket.on('error',()=>{});socket.on('close',()=>sockets.delete(socket));socket.write('220 isolated verification only\r\n');let buffer='';socket.on('data',bytes=>{buffer+=bytes.toString();while(buffer.includes('\r\n')){const n=buffer.indexOf('\r\n'),line=buffer.slice(0,n);buffer=buffer.slice(n+2);if(line.startsWith('EHLO'))socket.write('250-local\r\n250 AUTH PLAIN\r\n');else if(line.startsWith('AUTH PLAIN ')){authentications++;socket.write('235 ok\r\n');}else if(line==='QUIT')socket.end('221 bye\r\n');else{if(line==='DATA')unexpectedData++;socket.write('500 no messages accepted\r\n');}}});});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const tested=await app.testConnection(sender,{name:'Loopback verification',expectedRevision:0,config:{kind:'smtp',host:'127.0.0.1',port:server.address().port,username:'sender@example.test',fromAddress:'sender@example.test',authMode:'password',mode:'plain'},secret:'public-fixture-secret'}),smtp=await app.saveConnection(sender,'mail',tested.operationId,tested.candidateHash);
 await app.setAdded(sender,'mail',true,app.selections.catalogState('mail').revision);await app.select(sender,{projectId,appId:'mail',enabled:true,expectedRevision:app.selections.projectSettings(projectId,'mail').revision,connections:{foxmail:null,smtp:smtp.id}});
 const content={mode:'new',sourceMessageRef:null,senderConnectionId:null,to:['receiver@example.test'],cc:[],bcc:[],subject:'Synthetic only',text:'Public synthetic body',html:null,inReplyTo:null,references:[],attachmentIds:[]};
 const draft=async()=> (await app.contexts.withUi(sender,{projectId,appId:'mail',action:'ui.mail.draft.create',operations:['mail.draft'],semantics:'write'},context=>app.capabilities.forUi(context,'mail.draft.create',{content}))).draft;
 const prepare=async()=>{const d=await draft();return(await app.prepareSend(sender,projectId,{draftId:d.id,expectedRevision:d.revision,expectedContentHash:d.contentHash})).intent;};
 const confirm=async intent=>{const shown=await app.reviewSend(sender,projectId,intent.id);return app.authorizeSend(sender,projectId,{intentId:intent.id,expectedReviewHash:intent.reviewHash,displayReceiptId:shown.displayReceiptId,reviewedUnknownExecutionIds:[]});};
 const execute=intent=>app.executeSend(sender,projectId,{intentId:intent.id,expectedReviewHash:intent.reviewHash});
 const status=await app.projectPolicy(sender,projectId,'mail');if(status.canConfirm)await app.projectAction(sender,projectId,'mail',{action:'confirm-sender',arguments:{expectedBindingHash:status.bindingHash,confirmed:true}});
 const adapters=new a.AgentAdapterRegistry(store),adapterSource=source.adapters().find(x=>x.metadata.agentId==='claude-code'&&x.metadata.version==='1.2.0'),adapter=await adapters.install(adapterSource.metadata,adapterSource.files),home=out+'/agent-home',cwd=out+'/project';mkdirSync(home);mkdirSync(cwd);
 const sessions=new a.CapabilitySessionRegistry(store,{assertInitialSelection:s=>{assert.equal(s.packages[0].packageHash,pack.packageHash);},verifyExtraResource:(r,s)=>adapters.verifyReference(r,s)}),authorization=new a.CurrentApplicationAuthorization(store,trusted);
 const createPlan=(snapshot,snapshotHash,runId)=>a.createApplicationRunPlan({runId,snapshotHash,snapshot,applications:snapshot.packages.map(p=>{const manifest=trusted.retainedMetadata(p.packageHash).manifest;return{packageHash:p.packageHash,manifest,capabilities:a.builtinApplicationModules.capabilityViews(manifest)};}),skills:[],available:{mcp:true,cli:false}});
 runs=new a.CapabilityRunRegistry(store,sessions,{processes:reader,assertCurrent:s=>{projects.getProject(s.projectId);},revoke:id=>{broker?.revokeRun(id);supervisor?.revokeRun(id);},createPlan,currentAuthorization:c=>authorization.view(c)});app.attachRuns(runs);const tools=new a.ApplicationToolService(store,runs,new a.ApplicationAdapterRegistry(store,app.data),{retryDelays:[0,0]});
 supervisor=new a.AgentBridgeProcesses(runs,{read:async socket=>{const proof=await new a.MacUnixPeerIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity').read(socket);assert(proof);proofs.push(proof);save('peer-proofs.json',proofs);return proof;}},reader,{pollMs:60000});
 broker=new a.PrivateApplicationBroker(runs,tools,{attachPeer:(socket,id,bridge)=>supervisor.attach(socket,id,bridge)});await broker.start();
 const start=async label=>{
  const taskId=randomUUID(),name=a.applicationMcpServerName(a.digest(taskId)),manifest=pack.manifest,decls=a.applicationToolDeclarations(manifest),bindings=authorization.bindings(projectId,['mail']),selected=authorization.packageSelection(projectId,pack.packageHash,bindings,[]);
  const snap={schema:3,taskId,projectId,runner:'claude-code',createdAt:new Date().toISOString(),native:{sessionId:null,stateRoot:home+'/.claude',cwd},adapterBinding:{id:'claude-code',version:adapter.metadata.version,hash:adapter.hash,projectionFormatVersion:1,nativeToolNames:Object.fromEntries(decls.map(t=>[t.name,'mcp__'+name+'__'+t.name]))},agentAtCreation:{version:adapter.metadata.cliVersions[0],adapterRevision:1},catalogGeneration:'research-default-v2',packages:[selected],standardSkills:[],mcp:[{kind:'applications',serverName:name,protocolMajor:1,runtimeHash:manifest.runtime.hash}],provenance:'created'};
  const session=await sessions.create(snap,home),run=await runs.reserve({taskId,snapshotHash:session.pointer.snapshotHash,bindings});await run.prepare();await run.cli.arm();
  const child=spawn(process.execPath,[root+'/bridge-owner.mjs'],{cwd,stdio:['pipe','pipe','pipe'],env:{HOME:home,PATH:'/usr/bin:/bin',TMPDIR:out}}),exited=new Promise(resolve=>child.once('exit',(code,signal)=>resolve({code,signal}))),entry={run,child,exited,label,name,identity:null};owned.push(entry);child.stderr.on('data',b=>appendFileSync(out+'/'+label+'-stderr.log',b));await once(child,'spawn');entry.identity=reader.read(child.pid);assert(entry.identity);await run.cli.attach(child.pid,entry.identity.startedAt);
  const ticket=await broker.prepare(run,name);entry.ticket=ticket;await ticket.bridge.arm();const protocol=client(child,out+'/'+label+'-mcp.jsonl');entry.client=protocol;
  child.stdin.write(JSON.stringify({bridge:store.root+'/runtime/'+manifest.runtime.hash+'/mcp-bridge.cjs',bootstrap:ticket.bootstrapPath,home,tmp:out})+'\n');
  const initialized=await deadline(protocol.rpc('initialize',{protocolVersion:'2025-03-26',capabilities:{},clientInfo:{name:'isolated-native-host',version:'1'}}),label+' initialize');protocol.notify('notifications/initialized');const listed=await deadline(protocol.rpc('tools/list'),label+' tools');assert(broker.hasAuthenticated(run.runId));entry.listed=listed;save(label+'-initial.json',{initialized,listed,run:runs.get(run.runId)});return entry;
 };
 const call=(entry,op,args)=>deadline(entry.client.rpc('tools/call',{name:'smartdd_mail_'+op+'_v2',arguments:args}),'call '+op);
 const ok=r=>{assert(!r.isError,JSON.stringify(r));return r.structuredContent??JSON.parse(r.content[0].text);};
 let one,two,intent;
 await check('V01','default mail v2 is advertised through actual bridge and verified kernel ancestry',async()=>{
  assert.equal(pack.manifest.schema,'smartdd-app-package-v2');assert.equal(pack.version,'1.1.0');one=await start('one');two=await start('two');
  for(const entry of [one,two]){assert(entry.listed.tools.some(t=>t.name==='smartdd_mail_send_prepare_v2'));assert(entry.listed.tools.every(t=>t.name.endsWith('_v2')));const plan=runs.assertActive(entry.run.runId).plan;assert(plan.allowed.some(c=>c.capabilityId==='mail.send.execute'&&c.contractMajor===2));assert(proofs.some(p=>p.ancestors.some(x=>x.pid===entry.identity.pid&&x.startedAt===entry.identity.startedAt)));}
  return{packageSchema:pack.manifest.schema,packageVersion:pack.version,snapshotSchema:3,realBridgeProcesses:2,kernelAncestryVerified:true,owner:'controlled Node protocol host, not Claude SDK'};
 });
 await check('V02','v2 MCP draft and intent enter actual services; project read does not grant execution',async()=>{
  const d=ok(await call(one,'draft_create',{content})).draft;intent=ok(await call(one,'send_prepare',{draftId:d.id,expectedRevision:d.revision,expectedContentHash:d.contentHash})).intent;
  const denied=await call(one,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash});assert(denied.isError);assert.equal(submissions,0);await confirm(intent);
  const otherRead=ok(await call(two,'send_get',{intentId:intent.id}));assert.equal(otherRead.intent.id,intent.id);const otherExecute=await call(two,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash});assert(otherExecute.isError);assert.equal(submissions,0);
  const result=ok(await call(one,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash})).intent;assert.equal(result.state,'server-accepted');const replay=ok(await call(one,'send_execute',{intentId:intent.id,expectedReviewHash:intent.reviewHash})).intent;assert.equal(replay.executionId,result.executionId);assert.equal(submissions,1);
  save('cross-run.json',{denied,otherRead,otherExecute,result,replay});return{executeOnce:true,executionId:result.executionId,sameProjectReadAllowed:true,otherRunExecutionDenied:true,sourceRun:one.run.runId};
 });
 await check('V03','current project policy overrides cached tools without changing launch plan',async()=>{
  const original=db.prepare('SELECT plan_json FROM capability_resource_operations WHERE operation_id=?').get('application-run-plan:'+one.run.runId).plan_json;
  const state=app.selections.catalogState('mail');await app.setEnabled(sender,'mail',false,state.revision);const denied=await call(one,'send_get',{intentId:intent.id});assert(denied.isError);assert(JSON.stringify(denied).includes('APP_NOT_ENABLED'));
  const list=await deadline(one.client.rpc('tools/list'),'disabled tools');assert.equal(list.tools.length,0);assert.equal(db.prepare('SELECT plan_json FROM capability_resource_operations WHERE operation_id=?').get('application-run-plan:'+one.run.runId).plan_json,original);assert.equal(submissions,1);
  save('policy-denial.json',{denied,list});return{cachedToolDenied:true,currentCatalogEmpty:true,storedPlanUnchanged:true,noAdditionalSubmit:true};
 });
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 const cleanup=[];for(const entry of owned){try{entry.client?.close();if(!entry.client)entry.child.stdin.end();let exit;try{exit=await deadline(entry.exited,'owned host exit');}catch(e){entry.child.kill('SIGTERM');exit=await deadline(entry.exited,'owned host termination');throw e;}await entry.run.cli.exited();cleanup.push({label:entry.label,identity:entry.identity,exit,kernelState:reader.state(entry.identity)});}catch(e){error??=e.stack;process.exitCode=1;cleanup.push({label:entry.label,error:e.stack});}}
 await broker?.close();await supervisor?.dispose();if(app)await app.dispose();if(runs)await runs.dispose();for(const socket of sockets)socket.destroy();if(server?.listening)await new Promise(resolve=>server.close(resolve));
 save('cleanup.json',cleanup);if(db){save('terminal.json',{runs:db.prepare('SELECT run_id,state FROM capability_runs').all(),leases:db.prepare("SELECT state,count(*) n FROM capability_resource_leases GROUP BY state").all()});assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);await db.backup(out+'/final.sqlite');db.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:error??null,submissions,authentications,unexpectedData,scope:'Default v2 capability definitions in isolated rebuilt distribution, actual V3 session/run plan, current authorization, private broker and real bridge with kernel ancestry, actual mail/UI approval services. Node protocol host substitutes native Agent; synthetic renderer/cipher/submit. Loopback credential verification only; no models/external mail/product edits.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,error:result.error,submissions,authentications}));
