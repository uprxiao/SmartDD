import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
let child;
const lines=createInterface({input:process.stdin});
lines.on('line',line=>{
 if(!child){const spec=JSON.parse(line);child=spawn(process.execPath,[spec.bridge,'--bootstrap',spec.bootstrap],{stdio:['pipe','pipe','pipe'],env:{HOME:spec.home,PATH:'/usr/bin:/bin',TMPDIR:spec.tmp}});child.stdout.pipe(process.stdout);child.stderr.pipe(process.stderr);child.once('error',e=>{process.stderr.write(e.stack);process.exitCode=1;lines.close();});child.once('exit',(code,signal)=>{process.exitCode=code??(signal?1:0);lines.close();process.stdin.destroy();});}
 else child.stdin.write(line+'\n');
});
lines.on('close',()=>child?.stdin.end());process.on('SIGTERM',()=>{if(child)child.kill('SIGTERM');else process.exit(0);});
