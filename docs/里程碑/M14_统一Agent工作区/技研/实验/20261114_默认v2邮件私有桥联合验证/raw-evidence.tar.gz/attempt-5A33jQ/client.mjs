import {createInterface} from 'node:readline';
import {appendFileSync} from 'node:fs';
export function client(child,log){
 const pending=new Map();let seq=0;const lines=createInterface({input:child.stdout});
 lines.on('line',line=>{appendFileSync(log,line+'\n');try{const m=JSON.parse(line);if(pending.has(m.id)){const d=pending.get(m.id);pending.delete(m.id);m.error?d.reject(Error(JSON.stringify(m.error))):d.resolve(m.result);}}catch(e){for(const d of pending.values())d.reject(e);pending.clear();}});
 child.once('exit',()=>{for(const d of pending.values())d.reject(Error('Owned bridge host exited'));pending.clear();lines.close();});
 return{rpc:(method,params={})=>{const id=++seq;return new Promise((resolve,reject)=>{pending.set(id,{resolve,reject});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');});},notify:(method,params={})=>child.stdin.write(JSON.stringify({jsonrpc:'2.0',method,params})+'\n'),close:()=>child.stdin.end()};
}
