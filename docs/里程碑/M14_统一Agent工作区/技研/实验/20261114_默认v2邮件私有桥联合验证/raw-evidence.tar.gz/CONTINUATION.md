# Default v2 mail private-bridge research

Latest successful attempt: attempt-5A33jQ. Three checks passed. Cleanup confirms both controlled protocol hosts stopped and all run leases released. No SMTP DATA was issued; one synthetic submit was recorded.

V01: default mail 1.1.0 / contract 2, schema-3 snapshot, actual private bridge and kernel ancestry.
V02: actual draft/intent services, UI approval with synthetic renderer, same-project cross-run read but execution denied, original-run execute and replay produce only one controlled submit.
V03: current application disable overrides cached tool access, tools/list empties, immutable persisted launch plan unchanged.

The protocol owners are Node fixtures, not native SDK/model processes. Two tasks share a project; this is not a same-task provider switch test. Renderer trust and secret cipher are fixtures; final SMTP submission is controlled. This verifies existing service composition, not product implementation or UI acceptance.

Retained failures: attempt-x2r9ze (driver incorrectly accessed v2 data as a v1 result; actual response contained the valid willyou-app-result-v2 envelope); attempt-aPXJDn (sandbox blocked loopback bind before checks). Corrected only the isolated driver: validate schema, contractMajor, status, operation ID, then read data.

Pending: incorporate evidence into the M14 verification ledger without changing broad-row completion counts; native SDK/programmatic entry composition and D01 shared admission remain open. No production files were modified by this experiment.
