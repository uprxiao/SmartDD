from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_父子插件并发与更新排空验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and not r.get('error');a=Path(r['out']);sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:
  assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());cleanup=json.loads((attempt/'cleanup.json').read_text());assert len(cleanup['nativeExits'])==2 and all(x['code']==(0 if x['driver']=='codex'else 143)for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped'for x in cleanup['cleanup'])
 db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM plugin_runtime_leases WHERE state<>'closed'"]:assert db.execute(query).fetchone()==(0,)
 db.close();attempts.append({'attempt':attempt.name,'passed':result['passed'],'error':result.get('error'),'nativeExits':cleanup['nativeExits'],'modelRequests':len(json.loads((attempt/'models.json').read_text())),'pluginLeases':json.loads((attempt/'plugin-leases.json').read_text()),'finalAllOwnedResourcesSettled':True})
assert len(attempts)==1
calls=json.loads((a/'plugin-calls.json').read_text());inv=json.loads((a/'invocations.json').read_text());approvals=json.loads((a/'approvals.json').read_text());models=json.loads((a/'models.json').read_text())
assert len(calls)==len(inv)==len(approvals)==3 and len(models)==6
assert all(x['state']=='succeeded' and x['attempt_count']==1 and x['effect_state']=='completed' for x in inv)
assert all(x['state']=='allowed'for x in approvals)
assert {x['scope']['operationId']for x in calls}=={x['operation_id']for x in inv}=={x['operation_id']for x in approvals}
assert len({x['run_id']for x in inv})==len({x['task_id']for x in inv})==2
assert len({x['package_hash']for x in inv})==2
requests=[json.loads(x)for x in(a/'codex-requests.jsonl').read_text().splitlines()]
assert sum(x['method']=='thread/start'for x in requests)==1
turns=[x for x in requests if x['method']=='turn/start'];assert len(turns)==2 and turns[0]['params']['threadId']==turns[1]['params']['threadId']
held=json.loads((a/'child-stopped-update-held.json').read_text());new=json.loads((a/'new-version-call.json').read_text())
assert held['installation']['hash']==new['launchHash']!=new['actualHash']
assert [x['input']['value']for x in calls]==['CHILD_OLD','PARENT_OLD','PARENT_NEW']
assert 'VERSION_0.1.1:PARENT_NEW' in json.dumps(models[-1])
# Update may remove old closed lease rows; retain all observed identities from intermediate snapshots.
plugin_processes={}
for snapshot in a.glob('*.sqlite'):
 db=sqlite3.connect(snapshot.as_uri()+'?mode=ro',uri=True)
 for row in db.execute('SELECT pid,process_started_at,kind,package_hash,state FROM plugin_runtime_leases WHERE pid IS NOT NULL'):
  plugin_processes[(row[0],row[1])]=dict(zip(['pid','startedAt','kind','packageHash','lastSnapshotState'],row))
 db.close()
runtime={'attempts':attempts,'finalAttempt':a.name,'finalChecks':4,'invocations':inv,'observedPluginProcesses':list(plugin_processes.values()),'parentNativeThread':turns[0]['params']['threadId'],'modelRequests':6,'scope':r['scope'],'leaseCaveat':'Lifecycle.finish can remove old-version closed lease rows; final plugin-leases.json is not an enumeration of every process ever spawned. Intermediate SQLite retains old identities.'}
(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/plugins'/n for n in ['runtime-supervisor.ts','lifecycle.ts','session-tools.ts','write-approvals.ts','host-service.ts','process.ts']]+[t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Existing plugin lifecycle/supervisor/approval/bridge is bundled from current source. Delegation, programmatic launch and UI window routing are research candidates. drain wrapper observes entry and completion and calls original method without replacing behavior.','t3Boundary':'T3 RuntimeRequestService validates responseCapability and live providerSessionId. Plugin version drain/review behavior here belongs to existing SmartDD services, not a claim about T3 plugin support.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 父子 Agent 插件并发与更新排空

2026-11-14；技术方案 §9.6，验证账 §4.66；R02／05／06／08／10，Q09／27／28／40／41。仅隔离技术验证，产品与共享原型未改。

Codex 0.167.1 父运行通过候选委派创建 Claude Agent SDK 0.3.321／native 2.1.321 子运行。两端真实 stdio MCP 经现有私有 broker、内核 peer、ToolService、PluginSessionTools、写审批和沙箱 PluginProcess。子任务使用独立目录，不声称验证共享 SVN 写入。模型端点为本机受控响应；插件只写临时 privateData，无真实连接／秘密。

## 实际结果：{a.name}，P01–P04 通过

| 检查 | 观察与断言 |
| --- | --- |
| P01 两项在途审批 | 父子同时通过原生工具发起写调用，两条审批分别绑定 task／binding／run；交换审批会返回 DECISION_RUN_CHANGED，允许之前零写入 |
| P02 更新等待两个调用 | 旧版本两项调用已预留后开始安装 0.1.1；直接观察实际 drain 进入，preparing 已落库，安装版本仍旧。先允许子调用并停止子运行，父审批仍在且更新未完成；再允许父调用，两次旧版本写入完成后更新提交，数据保留 |
| P03 同一父会话用新版本 | 同一个原生 Codex thread 再发一轮，使用当前兼容插件 0.1.1；产生新包哈希审批，旧回执 AUTHORIZATION_REQUIRED。第三次调用账记录新包；启动计划与旧选择快照不被改写；下一模型输入带 VERSION_0.1.1:PARENT_NEW |
| P04 按各自所有权释放 | 两端原生／私有桥退出，run 租约 released；关闭本次 PluginHostService 后剩余插件 lease closed，记录的当前 PID／出生身份确认 stopped；秘密读取计数为零 |

三条实际业务调用均 succeeded／completed／attempt_count=1，与三条 allowed 审批及插件收到的 operationId 一一对应。插件写入顺序 CHILD_OLD、PARENT_OLD、PARENT_NEW；六次本机模型请求。两个真实原生进程受控退出，Codex 0、Claude 143。原生请求日志证实只创建一个父 thread，两个 turn/start 使用相同 threadId。

## 设计结论

现有 PluginLifecycle.withInvocation 的引用覆盖“审批等待至处理结束”，不只覆盖子进程实际执行时段。更新把旧 RuntimeEntry 标记 retired，等待引用归零，再关闭旧进程、迁移数据并激活新版；不能通过结束一个子任务清除其他任务的预留。跨 Agent 并发使用同一插件仍需逐次验证身份与业务审批。

启动快照是来源审计，当前安装与策略决定实际调用。兼容更新可在同一 run／native thread 使用，但新调用账与审批绑定实际新包，不能把旧 packageHash 改成新值来伪造启动来源，也不能沿用旧审批。兼容性仍由既有 capability／permission／semantics／slots 检查决定；本批只验证兼容补丁更新。

T3 的活动 providerSessionId／responseCapability 守卫是运行请求归属参考；本批插件更新排空和包审阅行为来自 SmartDD 现有服务，应保留而不是替换成 T3 不相关的实现。

## 证据边界

审批窗口为研究私有句柄 facade，未走正式 renderer／IPC；规则由受控模型调用触发，不验证模型自主规划。drain 只加入口／返回观测，仍执行原方法；候选委派／启动接线在临时目录。审批是同时等待，两个沙箱写按测试顺序执行，不声称同时执行两个有副作用的插件函数。

未覆盖卸载、拒绝／过期与更新的组合、不兼容更新、更新中宿主崩溃、真正业务连接／后台写、共享 SVN 目录、真实 UI 或跨平台。旧版本安装收尾可能删除其已关闭 lease 行，因此最终 plugin-leases.json 不是全部历史进程清单；保留中间 SQLite，不用最终行数倒推总进程数。当前证据不代替完整产品验收。

[结果](result.json)、[运行审计](runtime-audit.json)、[源码核对](source-review.json)、[摘要](archive-manifest.json)、[原始脚本／协议／SQLite](raw-evidence.tar.gz)。归档 {len(files)} 文件，{len(dbs)} 份 SQLite 完整性／外键通过，{len(sources)} 构建输入哈希复核。

复跑固定当前 SDK/native 与依赖，按 build.mjs／build-bridge.mjs 和 probe.mjs 的临时路径配置；不读取日常配置或连接真实模型／业务。
''')
section='''### 9.6 父子调用与插件更新边界

[父子插件并发实验](实验/20261114_父子插件并发与更新排空验证/README.md)补证 §9.5：真实 Codex 父运行与 Claude 子运行经私有 MCP 同时进入现有插件写审批。两条审批不可交叉批准；先完成并停止子运行后，父审批仍有效，正在等待的插件更新仍未提交。父调用也完成后，现有 drain 才结束并激活新包。

**插件更新等待调用预留，而不仅是当前正在执行的进程请求。** 保留 PluginLifecycle.withInvocation 与 PluginRuntimeSupervisor 引用计数的范围，从审批／Schema／调用账直到处理结束。不能为了统一任务 UI 或子树取消而把整个 appId 的共享预留归给某个 run。更新期间已有旧调用按当前策略完成；新调用按生命周期等待更新结果后重新选择版本。

兼容更新完成后，本批同一个 Codex run／原生 thread 的下一轮实际调用新包，并要求绑定新 packageHash 的新审批；旧回执拒绝。启动 ExecutionPlan 和 externalPlugins 选择快照保持不变，真实 application_invocations 记录当次实际包。实现应分别保存启动来源、当前授权与实际执行版本，不可相互覆盖。现有 permission／semantics／slots 等兼容检查继续有效，不把一次兼容升级推广到任意版本。

本批同时在途的是两项审批，沙箱写按指定顺序执行；测试插件只写私有目录。卸载／拒绝／过期／不兼容变更和更新崩溃仍须按具体分支验证，真实 UI、业务连接与 SVN 共享写者另验。T3 的运行请求会话归属守卫可参考，SmartDD 的插件生命周期继续复用现有服务。

'''
def tech(t):
 assert '### 9.6 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 t=t.replace('更新／卸载与同时多绑定调用仍须联合验证。','§9.6 又补父子同时审批与兼容更新；卸载／不兼容变更及其他竞争分支仍须联合验证。')
 t=t.replace('真实 renderer／IPC、业务插件连接与秘密、更新／卸载竞争、父子树及崩溃恢复仍按剩余账推进，不等同于插件业务全面验收。','§9.6 补父子同时审批与兼容更新；真实 renderer／IPC、业务插件连接与秘密、卸载／异常更新及崩溃恢复仍按剩余账推进，不等同于插件业务全面验收。')
 return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.66 父子插件并发与兼容更新

[父子并发与更新实验](实验/20261114_父子插件并发与更新排空验证/README.md)P01–04 通过：真实 Codex 父与 Claude 子经当前私有桥同时进入实际插件审批，交叉回执拒绝；子完成并停止不取消父审批，更新等待两个旧调用预留结束才提交。父保持同一 run／原生 thread，在下一轮使用兼容新包并重新审批，启动来源保持旧值，调用账记录实际新包。

三次实际沙箱写／三条成功调用／三条批准一一对应，六次本机模型请求；两端原生与桥、当前插件进程和租约最终清理。插件仅写临时私有数据、审批界面为研究 facade；并发审批不等于并发执行写函数。技术方案 §9.6 收口引用范围与三类版本身份；未覆盖卸载、不兼容升级、更新崩溃、真实 UI／业务连接或 SVN 共写。

'''
def ledger(t):
 assert '### 4.66 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正')
 t=t.replace('；§4.65 补两端原生私有 MCP／实际插件审批与沙箱分发、宿主共享池归属；真实 UI／并发／更新卸载仍待验','；§4.65–4.66 补两端原生私有 MCP／实际插件审批与沙箱分发、宿主共享池、父子同时审批及兼容更新；真实 UI／卸载／不兼容更新与崩溃仍待验')
 t=t.replace('继续补浏览器／邮件等实际上下文、在途操作与插件并发更新联合','§4.66 又补父子审批并发／兼容更新和同原生会话新版本调用；继续补浏览器／邮件等实际上下文、在途操作与插件卸载／异常更新')
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：父子两端原生私有 MCP 同时进入实际插件审批，交叉批准被拒；插件更新等待两边旧调用结束，同一父会话下一轮使用兼容新版本并重新审批。4 项隔离检查通过，见[技术方案 §9.6](技研/技术方案.md)。插件只写临时私有目录，产品未改。'
 i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续实际业务上下文、在途操作、更新／卸载异常及回执恢复的未决分支；不重复已通过的正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
