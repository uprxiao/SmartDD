from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_历史恢复并发接管与覆盖防护验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==3 and r['error'] is None and len(r['workers'])==10 and all(w['exit'] for w in r['workers'])
assert sum(w['exit']['signal']=='SIGKILL' for w in r['workers'])==4
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'boundary':r['scope'],'injection':'Two real recovery processes are paused/resumed through captured stdin checkpoint; later history is an explicit synthetic append after competing process commit. Only owned checkpoint processes receive SIGKILL. Candidate acquire uses BEGIN IMMEDIATE, exact pid/birth and generation; copy guard runs under actual resource lock before filesystem copy.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['worker.mjs','baseline-worker.mjs','claim.mjs','probe.mjs','build.mjs','build.json','actual.cjs','source-review.json','prepare.py']]+[p for p in Path(r['out']).iterdir() if p.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 历史恢复并发接管与覆盖防护验证

日期：2026-11-14。关联 D01、Q13／Q49。真实双恢复进程、实际复制函数／会话注册器／资源锁／进程身份，复制账、恢复 claim 与 Task 指针均为临时候选。

## 三项检查

| 检查 | 结果 |
| --- | --- |
| R01 旧候选负例 | 恢复 A 完成旧快照与文件检查后暂停；B 完成恢复提交，驱动向目标追加合成“后续历史”；A 恢复执行，先覆盖副本，之后实际注册器才以 RESOURCE_STATE_CHANGED 拒绝元数据提交。新增内容丢失，说明只在最终提交检查不足 |
| R02 排他恢复 | 候选在 SQLite 同步事务登记精确 pid／出生身份／generation；A 已领取时 B 被拒绝且没有执行复制，A 提交时同时完成 claim；新进程重查 committed，不重放 |
| R03 中断接管 | generation=1 的恢复者领取后被精确 SIGKILL；新进程证明其已退出，取得 generation=2，重新取得真实复制收据并提交 |

三个检查通过，其中 R01 是必须保留的失败行为反例，不表示旧候选安全。10 个 worker 全部终止：4 次预定 SIGKILL、4 次成功 exit 0、2 次预期拒绝 exit 1；三份 SQLite 完整性和外键检查通过。负例文件覆盖只发生在合成夹具，不涉及用户历史或产品代码。

## 候选约束

领取在同一 SQLite 事务复核 copied 状态、原 Task 指针、原 owner 活性和上一恢复 claim；活跃或未知恢复者不允许按时间过期接管。持有者在实际资源锁内、复制前复核 claim 代次／身份、当前快照与文件；提交回调再次核 claim，并与复制账／Task 指针同事务改为 completed。先验文件校验和最终快照 CAS 之间不能留下无归属的文件写入窗口。

这只是参与相同恢复规则的宿主之间的排他。它不提供 OS 全局目录锁，不能宣称阻止任意编辑器或非受管进程写文件。合法后续 Agent 续写、复制过程中退出、最终多 binding／身份占用投影、实际 TaskService、旧根回退及断电耐久性仍待联合。合成追加没有经过真实 Agent 或运行来源账，不作为正常续聊兼容的通过证据。

## 复现

固定依赖具备时执行 `node build.mjs`、`node probe.mjs`。baseline-worker.mjs 保留前批复制恢复候选；本批 worker 的 guarded 开关只用于同场景负对照，产品没有该开关。归档包含当次驱动、进程事件、覆盖前后字节、终态 SQLite 和 379 条构建输入摘要。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
tech_rel=base/'技研/技术方案.md';t=(repo/tech_rel).read_text()
old='原 owner 活着时不接管，未知活性继续保留；恢复进程还需正式的排他 claim，不能只靠“原 owner 已死”允许多个恢复者同时处理。'
new='原 owner 活着时不接管，未知活性继续保留。[双恢复者实跑](实验/20261114_历史恢复并发接管与覆盖防护验证/README.md)复现旧候选的文件覆盖窗口：A 预检后暂停，B 提交并出现合成后续历史，A 再复制覆盖，最终快照 CAS 虽拒绝却来不及保护文件。候选补恢复 operation／generation／精确 pid 与出生身份的持久 claim，在同步事务领取，活跃或未知持有者不按超时接管；原持有者已停止才递增代次。实际资源锁内、文件复制前重验 claim／当前快照／文件，元数据提交再验同 claim，并在该事务完成 claim。双进程争抢和领取后退出接管已验证；正式多 binding／运行准入还须使用相同协调边界，不能让其他入口绕过 claim。'
assert old in t;t=t.replace(old,new,1)
t=t.replace('复制中途、并发恢复、最终多 binding／占用投影、实际 TaskService、提交后镜像窗口及合法续写后的恢复仍待验证。','复制中途、最终多 binding／占用投影、实际 TaskService、提交后镜像窗口及合法续写后的恢复仍待验证；上述排他仅保护遵守同一协议的宿主，不等同 OS 全局目录锁。',1)
put(tech_rel,t)
ledger_rel=base/'技研/全局设计验证账.md';t=(repo/ledger_rel).read_text();assert '### 4.91 ' not in t
add='''### 4.91 历史恢复并发接管与文件覆盖窗口

[三项检查](实验/20261114_历史恢复并发接管与覆盖防护验证/README.md)先复现前批临时候选的双恢复者缺口：A 预检后暂停，B 提交并追加合成后续历史，A 再复制覆盖，最后实际快照检查才拒绝。证明最终数据库 CAS 不能弥补此前的文件覆盖；不是产品代码缺陷报告。

候选补持久恢复 claim、精确出生身份与代次、实际资源锁下的复制前复核及提交时原子完成。活跃竞争者被拒绝；领取后 SIGKILL 的持有者经确认停止，新进程取得下一代并提交。10 个 worker 全终态，4 次预定 SIGKILL、4 次成功、2 次预期拒绝，三份 SQLite 完整性／外键通过。实际 Agent 续写、复制中途、最终多 binding／TaskService 与外部写竞争仍未覆盖。技术方案 §11.2 已收口，Q13／49 保持部分。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1).replace('截至 §4.90，56 个宽口径问题项中','截至 §4.91，56 个宽口径问题项中')
old='下一步是最终占用投影／多 binding 原子提交、复制中途／并发恢复、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
new='§4.91 已补双恢复者覆盖负例与排他 claim／死亡持有者接管；下一步是最终占用投影／多 binding 原子提交、复制中途、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
assert old in t;t=t.replace(old,new,1);put(ledger_rel,t)
index_rel=base/'README.md';t=(repo/index_rel).read_text()
t=re.sub(r'^最新进展：.*$', '最新进展：双恢复者实跑复现了旧候选的历史覆盖窗口；持久接管身份／代次与复制前复核的修正已取得局部证据。见[并发恢复实验](技研/实验/20261114_历史恢复并发接管与覆盖防护验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对身份占用投影与多 binding 原子提交、复制中途及合法历史续写；宿主委派问题账、完整运行／业务和资源清理保持明确未决。',t,flags=re.M);put(index_rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-history-recovery-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed']}))
