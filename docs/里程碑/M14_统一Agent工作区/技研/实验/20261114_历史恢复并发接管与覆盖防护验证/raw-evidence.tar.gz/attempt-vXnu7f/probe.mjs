import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdtempSync,writeFileSync,readFileSync,copyFileSync,appendFileSync} from 'node:fs';
import {join} from 'node:path';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(join(root,'attempt-')),save=(n,v)=>writeFileSync(join(out,n),JSON.stringify(v,null,2));
for(const n of ['probe.mjs','worker.mjs','claim.mjs','baseline-worker.mjs','build.mjs','build.json'])copyFileSync(join(root,n),join(out,n));
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),workers=[],handles=[],checks=[];
function launch(mode,input,label){
 const file=join(out,label+'.input.json');writeFileSync(file,JSON.stringify(input));const child=spawn(process.execPath,[join(root,'worker.mjs'),mode,file],{cwd:root,stdio:['pipe','pipe','pipe']});
 const events=[],checkpoint=Promise.withResolvers(),terminal=Promise.withResolvers();let stderr='';const rec={label,pid:child.pid,mode,events,exit:null};workers.push(rec);
 const rl=createInterface({input:child.stdout});rl.on('line',line=>{const e=JSON.parse(line);events.push(e);if(e.type==='checkpoint')checkpoint.resolve(e);});child.stderr.on('data',d=>{stderr+=d});
 const timer=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');},15000);
 child.on('error',e=>{clearTimeout(timer);checkpoint.reject(e);terminal.reject(e);});
 child.on('exit',(code,signal)=>{clearTimeout(timer);rec.exit={code,signal};rec.stderr=stderr;save(label+'.json',rec);if(!events.some(e=>e.type==='checkpoint'))checkpoint.reject(Error('Exited without checkpoint'));terminal.resolve(rec);});checkpoint.promise.catch(()=>{});
 const h={child,checkpoint:checkpoint.promise,terminal:terminal.promise};handles.push(h);return h;
}
async function kill(h){const gate=await h.checkpoint;assert.equal(gate.pid,h.child.pid);assert.equal(reader.state(gate.owner),'running');h.child.kill('SIGKILL');const end=await h.terminal;assert.equal(end.exit.signal,'SIGKILL');assert.equal(reader.state(gate.owner),'stopped');}
async function fixture(id){const descriptor=join(out,id+'.descriptor.json');await kill(launch('prepare',{pause:'after-copy',descriptor},id+'-original'));return descriptor;}
const event=r=>r.events.find(e=>e.type==='result');
let problem;
try{
 {
  const descriptor=await fixture('R01'),d=JSON.parse(readFileSync(descriptor,'utf8'));
  const stale=launch('recover',{descriptor,pause:'before-recopy',resume:true},'R01-stale');await stale.checkpoint;
  const winner=await launch('recover',{descriptor},'R01-winner').terminal;assert.equal(winner.exit.code,0);
  appendFileSync(d.targetFile,'SYNTHETIC_LATER_HISTORY\n');const before=readFileSync(d.targetFile,'utf8');assert(before.includes('SYNTHETIC_LATER_HISTORY'));
  stale.child.stdin.end('x');const late=await stale.terminal;assert.equal(late.exit.code,1);assert.equal(late.events.find(e=>e.type==='error').code,'RESOURCE_STATE_CHANGED');
  const after=readFileSync(d.targetFile,'utf8');assert(!after.includes('SYNTHETIC_LATER_HISTORY'));
  save('R01-byte-evidence.json',{before,after});checks.push({id:'R01',status:'passed',negative:true,evidence:{staleRecoveryOverwroteSyntheticLaterHistory:true,metadataRejectedTooLate:true,productionNotModified:true}});
 }
 {
  const descriptor=await fixture('R02');const owner=launch('recover',{descriptor,guarded:true,pause:'before-recopy',resume:true},'R02-owner');await owner.checkpoint;
  const other=await launch('recover',{descriptor,guarded:true},'R02-contender').terminal;assert.equal(other.exit.code,1);assert(other.events.find(e=>e.type==='error').message.includes('RECOVERY_OWNER_NOT_STOPPED'));
  owner.child.stdin.end('x');const done=await owner.terminal;assert.equal(done.exit.code,0);const claim=event(done).after.copy_recovery_claim[0];assert.equal(claim.generation,1);assert.equal(claim.state,'completed');
  const again=await launch('recover',{descriptor,guarded:true},'R02-repeat').terminal;assert.equal(again.exit.code,0);assert.equal(event(again).classification,'committed-no-replay');checks.push({id:'R02',status:'passed',evidence:{liveRecoveryContenderRefused:true,oneGeneration:1,committedNoReplay:true}});
 }
 {
  const descriptor=await fixture('R03');const first=launch('recover',{descriptor,guarded:true,pause:'before-recopy'},'R03-first');await kill(first);
  const next=await launch('recover',{descriptor,guarded:true},'R03-next').terminal;assert.equal(next.exit.code,0);const claim=event(next).after.copy_recovery_claim[0];assert.equal(claim.generation,2);assert.equal(claim.state,'completed');checks.push({id:'R03',status:'passed',evidence:{deadClaimReplaced:true,generation:2,newProcessReceipt:true}});
 }
 for(const c of checks){const descriptor=JSON.parse(readFileSync(join(out,c.id+'.descriptor.json'),'utf8'));const db=new Database(descriptor.db,{readonly:true,fileMustExist:true});try{assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);await db.backup(join(out,c.id+'.final.sqlite'));}finally{db.close();}}
}catch(e){problem=e.stack;process.exitCode=1;}
finally{for(const h of handles){if(h.child.exitCode===null&&h.child.signalCode===null)h.child.kill('SIGTERM');await h.terminal;}}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,workers,scope:'Controlled two-process interleaving reproduces stale recovery file overwrite in prior temporary candidate. Fixed candidate SQLite recovery claim uses actual birth identity and actual copy/session registry; synthetic history append is not an Agent run. No full TaskService, final multi-binding schema, OS-wide filesystem lock, crash mid-copy, power-loss or actual post-commit provider continuation.'};save('result.json',result);writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,error:result.error,workers:workers.map(w=>({label:w.label,exit:w.exit}))}));
