import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
import {mkdirSync,readFileSync,writeFileSync,writeSync,readdirSync,lstatSync} from 'node:fs';
import {join,dirname,relative} from 'node:path';
import Database from 'better-sqlite3';
import actual from './actual.cjs';

const [mode,inputPath]=process.argv.slice(2),input=JSON.parse(readFileSync(inputPath,'utf8'));
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
const send=x=>writeSync(1,JSON.stringify(x)+'\n');
const sha=b=>createHash('sha256').update(b).digest('hex');
function state(root){
 const info=lstatSync(root);assert(info.isDirectory()&&!info.isSymbolicLink(),'ROOT_CHANGED');
 const entries=[];const walk=dir=>{for(const name of readdirSync(dir).sort()){const path=join(dir,name),s=lstatSync(path);assert(!s.isSymbolicLink(),'TREE_LINK');if(s.isDirectory()){entries.push({path:relative(root,path),kind:'dir'});walk(path);}else{assert(s.isFile()&&s.nlink===1,'TREE_KIND');entries.push({path:relative(root,path),kind:'file',hash:sha(readFileSync(path))});}}};walk(root);
 return{dev:String(info.dev),ino:String(info.ino),entries};
}
function checkpoint(point,descriptor){
 if(input.pause!==point)return;
 send({type:'checkpoint',point,descriptor,pid:process.pid,owner:reader.read(process.pid)});
 Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,30000);throw Error('CHECKPOINT_NOT_TERMINATED');
}
function readRecord(db){const row=db.prepare('SELECT * FROM copy_handoff').get();return{row,record:JSON.parse(row.payload_json)};}
function snapshot(db){return Object.fromEntries(['copy_handoff','copy_task_pointer','capability_session_snapshots','capability_session_identities','capability_snapshot_versions'].map(t=>[t,db.prepare('SELECT * FROM '+t+' ORDER BY 1').all()]));}
let db;
try{
 if(mode==='prepare'){
  const f=await actual.runFixture(reader);db=f.sqlite;
  let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});
  const id=randomUUID();current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:id});
  const from=current.snapshot.native.stateRoot,to=join(f.root,'copied-history'),cwd=current.snapshot.native.cwd,taskId=current.snapshot.taskId;
  const source=join(from,'projects',actual.encodeClaudeDir(cwd),id+'.jsonl');mkdirSync(dirname(source),{recursive:true});mkdirSync(to);writeFileSync(source,'{"type":"user","message":"SYNTHETIC_RECOVERY_HISTORY"}\n');
  const child=join(dirname(source),id,'subagents','agent.jsonl');mkdirSync(dirname(child),{recursive:true});writeFileSync(child,'SYNTHETIC_CHILD\n');
  const next={...current.snapshot,native:{...current.snapshot.native,stateRoot:to}},record={root:f.root,storeId:f.store.storeId,home:f.home,taskId,id,cwd,from,to,owner:reader.read(process.pid),oldHash:current.pointer.snapshotHash,newHash:actual.digest(actual.canonicalJson(next)),next,sourceState:state(from)};
  assert(record.owner);
  db.exec("CREATE TABLE copy_handoff(id TEXT PRIMARY KEY,state TEXT NOT NULL,payload_json TEXT NOT NULL);CREATE TABLE copy_task_pointer(task_id TEXT PRIMARY KEY,state_root TEXT NOT NULL,snapshot_hash TEXT NOT NULL)");
  db.prepare('INSERT INTO copy_task_pointer VALUES(?,?,?)').run(taskId,from,record.oldHash);
  db.prepare('INSERT INTO copy_handoff VALUES(?,?,?)').run('copy-1','planned',JSON.stringify(record));
  const receipt=actual.copyClaudeSession({from,to,cwd,sessionId:id,nativeTarget:false});record.targetState=state(to);
  db.prepare("UPDATE copy_handoff SET state='copied',payload_json=? WHERE id='copy-1'").run(JSON.stringify(record));
  const descriptor={root:f.root,db:join(f.root,'state.sqlite'),targetFile:join(to,'projects',actual.encodeClaudeDir(cwd),id+'.jsonl')};
  writeFileSync(input.descriptor,JSON.stringify(descriptor));checkpoint('after-copy',descriptor);
  await f.sessions.adoptLibrary(taskId,record.oldHash,next,{copy:receipt,home:f.home,commit:(before,after)=>{
   assert(db.inTransaction);assert.equal(before.pointer.snapshotHash,record.oldHash);assert.equal(after.pointer.snapshotHash,record.newHash);
   db.prepare('UPDATE copy_task_pointer SET state_root=?,snapshot_hash=? WHERE task_id=?').run(to,after.pointer.snapshotHash,taskId);db.prepare("UPDATE copy_handoff SET state='committed' WHERE id='copy-1'").run();checkpoint('in-commit',descriptor);
  }});
  checkpoint('after-commit',descriptor);send({type:'result',state:'committed'});
 }else{
  const descriptor=JSON.parse(readFileSync(input.descriptor,'utf8'));db=new Database(descriptor.db);db.pragma('foreign_keys=ON');const before=snapshot(db);const {row,record:r}=readRecord(db);
  assert.equal(reader.state(r.owner),'stopped','ORIGINAL_OWNER_NOT_STOPPED');
  const store=new actual.ResourceStore(db,descriptor.root,undefined,{processes:reader});assert.equal(store.storeId,r.storeId,'STORE_CHANGED');
  assert.deepEqual(state(r.from),r.sourceState,'SOURCE_CHANGED');assert.deepEqual(state(r.to),r.targetState,'TARGET_CHANGED');
  const ptr=db.prepare('SELECT * FROM copy_task_pointer WHERE task_id=?').get(r.taskId),session=db.prepare('SELECT snapshot_hash FROM capability_session_snapshots WHERE task_id=?').get(r.taskId);
  const sessions=new actual.CapabilitySessionRegistry(store,{assertInitialSelection:s=>{assert.equal(s.taskId,r.taskId);assert.equal(s.adapterBinding.hash,r.next.adapterBinding.hash);assert.equal(s.packages.length,0);},verifyExtraResource:()=>{throw Error('Unexpected verifier call');}});
  if(row.state==='committed'){
   assert.equal(ptr.state_root,r.to);assert.equal(ptr.snapshot_hash,r.newHash);assert.equal(session.snapshot_hash,r.newHash);const current=await sessions.get(r.taskId);assert.equal(current.pointer.snapshotHash,r.newHash);assert.deepEqual(snapshot(db),before);
   send({type:'result',classification:'committed-no-replay',before,after:snapshot(db),receiptRehydrated:false});
  }else{
   assert.equal(row.state,'copied','UNCONFIRMED_COPY');assert.equal(ptr.state_root,r.from);assert.equal(ptr.snapshot_hash,r.oldHash);assert.equal(session.snapshot_hash,r.oldHash);
   sessions.assertHistoryCopyAllowed({taskId:r.taskId,from:r.from,to:r.to,cwd:r.cwd,sessionId:r.id,home:r.home});
   const receipt=actual.copyClaudeSession({from:r.from,to:r.to,cwd:r.cwd,sessionId:r.id,nativeTarget:false});assert(actual.isCopiedClaudeSession(receipt));
   await sessions.adoptLibrary(r.taskId,r.oldHash,r.next,{copy:receipt,home:r.home,commit:(old,next)=>{
    assert(db.inTransaction);assert.equal(old.pointer.snapshotHash,r.oldHash);assert.equal(next.pointer.snapshotHash,r.newHash);
    const updated={...r,targetState:state(r.to)};assert.equal(db.prepare("UPDATE copy_handoff SET state='committed',payload_json=? WHERE id='copy-1' AND state='copied'").run(JSON.stringify(updated)).changes,1);
    assert.equal(db.prepare('UPDATE copy_task_pointer SET state_root=?,snapshot_hash=? WHERE task_id=? AND snapshot_hash=?').run(r.to,r.newHash,r.taskId,r.oldHash).changes,1);
   }});
   send({type:'result',classification:'revalidated-and-recopied',before,after:snapshot(db),receiptRehydrated:false,freshReceipt:true});
  }
  assert.deepEqual(db.pragma('foreign_key_check'),[]);assert.equal(db.pragma('integrity_check',{simple:true}),'ok');
 }
}catch(e){send({type:'error',message:e.message,code:e.code,stack:e.stack,state:db?snapshot(db):null});process.exitCode=1;}
finally{db?.close();}
