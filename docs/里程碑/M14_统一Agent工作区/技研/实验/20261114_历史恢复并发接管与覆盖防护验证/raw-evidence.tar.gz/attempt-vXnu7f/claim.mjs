import assert from 'node:assert/strict';

export function acquire(db,reader,record){
 const owner=reader.read(process.pid);assert(owner,'CURRENT_OWNER_UNKNOWN');
 return db.transaction(()=>{
  assert.equal(reader.state(record.owner),'stopped','ORIGINAL_OWNER_NOT_STOPPED');
  assert.equal(db.prepare("SELECT state FROM copy_handoff WHERE id='copy-1'").get().state,'copied','HANDOFF_CHANGED');
  const pointer=db.prepare('SELECT * FROM copy_task_pointer WHERE task_id=?').get(record.taskId);
  assert.equal(pointer.snapshot_hash,record.oldHash,'POINTER_CHANGED');assert.equal(pointer.state_root,record.from,'POINTER_CHANGED');
  const old=db.prepare("SELECT * FROM copy_recovery_claim WHERE id='copy-1'").get();
  if(old){assert.equal(old.state,'active','CLAIM_NOT_ACTIVE');assert.equal(reader.state({pid:old.pid,startedAt:old.started_at}),'stopped','RECOVERY_OWNER_NOT_STOPPED');}
  const claim={id:'copy-1',generation:(old?.generation??0)+1,...owner};
  db.prepare("INSERT INTO copy_recovery_claim VALUES(?,?,?,?,'active') ON CONFLICT(id) DO UPDATE SET generation=excluded.generation,pid=excluded.pid,started_at=excluded.started_at,state=excluded.state").run(claim.id,claim.generation,claim.pid,claim.startedAt);
  return claim;
 }).immediate();
}
export function assertClaim(db,claim){
 const row=db.prepare('SELECT * FROM copy_recovery_claim WHERE id=?').get(claim.id);
 assert(row&&row.state==='active'&&row.generation===claim.generation&&row.pid===claim.pid&&row.started_at===claim.startedAt,'STALE_RECOVERY_CLAIM');
}
export function finish(db,claim){
 assert(db.inTransaction);assertClaim(db,claim);
 assert.equal(db.prepare("UPDATE copy_recovery_claim SET state='completed' WHERE id=? AND generation=? AND pid=? AND started_at=? AND state='active'").run(claim.id,claim.generation,claim.pid,claim.startedAt).changes,1);
}
