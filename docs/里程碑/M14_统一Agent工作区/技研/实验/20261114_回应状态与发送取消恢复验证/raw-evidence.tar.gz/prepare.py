from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_回应状态与发送取消恢复验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==13 and not r.get('error');a=Path(r['out']);b=json.loads((root/'build.json').read_text());sources=b['sources']
for s in sources:assert sha(Path(s['path']).read_bytes())==s['sha256']
assert sha(Path(b['output']['file']).read_bytes())==b['output']['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
recordings=[]
for x in json.loads((root/'recorded.json').read_text()):
 p=Path(x['source']);copy=root/'recordings'/p.name;assert p.read_bytes()==copy.read_bytes();frames=[json.loads(l)for l in p.read_text().splitlines()];assert x['request']in frames and x['closed']in frames;recordings.append({'path':str(p),'sha256':sha(p.read_bytes()),'archivePath':str(copy.relative_to(root))})
workers=json.loads((a/'workers.json').read_text());assert len(workers)==5 and all(x['signal']=='SIGKILL'and x['code']is None for x in workers)
recoveries=[]
for cut in ['prepared','intent','after-send','submitted','journal']:
 v=json.loads((a/(cut+'-recovery.json')).read_text());assert v['recovered']['liveGrant']is False and v['recovered']['automaticRetry']is False and v['recovered']['view']['consumption']=='unproven';recoveries.append({'cut':cut,**v})
runtime={'attempt':a.name,'passed':13,'workers':workers,'recoveries':recoveries,'newNativeAgentProcesses':0,'modelRequests':0,'transport':'Synthetic append-only file for worker cuts, controlled Promise gates for local interleavings; native close frames replayed from previous live experiment.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/applications/resource-lock.ts',repo/'src/main/core/applications/process-identity.ts',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'recordings':recordings,'build':'Actual SmartDD resource coordination and identity modules, asset glob expansion only; response ledger is temporary research code.','t3Boundary':'Existing live session/request separation referenced; no claim T3 has this exact three-part ledger.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 回应状态、发送与取消竞争及宿主退出恢复

2026-11-14；R02／03／08／10／12，Q01／04／11／12／27／28／43。技术方案 §4.4.2，验证账 §4.61。仅独立技术验证，产品／共享原型未改。

## 目标和方法

§4.60 确认原生请求关闭不能直接当答案接受；其旧 Kernel 又把正常投递统一记 unknown。本批提出最小三部分账：决定、投递事实、请求活性。复用真实 Codex accept／cancel 两条路径的原始 request／serverRequest/resolved 帧，使用实际 ResourceStore、协调锁和 Mac PID／出生身份；候选 SQL 和 responder 仅放在临时目录。

不再重复启动原生 Agent。发送端为受控 Promise 或追加合成 JSON 的文件，以便精确制造返回前／后的时序；五个真实 worker 在检查点由捕获的 ChildProcess 句柄 SIGKILL。该方法验证宿主持久状态与调度，不证明真实 socket 所有字节窗口、OS 断电或 CapabilityRunRegistry 已接入新账。

## {a.name}：13 项检查

| 检查 | 结论 |
| --- | --- |
| S01 | 决定提交后不再等待用户；投递 submitted 且原生请求 closed 后也不等待原生。消费仍 unproven，没有补造批准；重复 commandId 不再发送 |
| S02 | 真实取消路径的关闭帧先到时，之后不能新提交决定；仅请求 closed，不生成用户同意 |
| S03–04 | 发送前取消拒绝派发；即使已持久发送意图，活着的同一闭包尚未调用发送端且门闩关闭，仍能证明 not-sent，发送次数为零 |
| S05 | 发送已在途时取消先记 unknown，迟到的发送完成可补 submitted 事实，但请求仍 expired，不重新等待或复活 |
| S06 | 请求关闭与投递失败交错，得到 closed＋unknown；关闭事实和投递不确定同时保留 |
| S07 | 复制私有句柄、不同 connectionId、数字／字符串原生 ID 混用及损坏 inbox scope 均拒绝；损坏事件不能关闭新请求 |
| S08 | 决定写入失败完整回滚；同命令不同值、同请求第二决定拒绝，不留下可发送的半份收据 |
| C01 | 决定 prepared 后宿主死亡：原 callback 失效，投递 not-sent，不自动恢复 callback 或发送 |
| C02 | 发送意图提交后死亡：unknown，即使本夹具实际上尚未写发送文件；不能凭缺回执证明未发送 |
| C03 | 合成发送已完成、submitted 未记账时死亡：unknown，发送文件保留一次，恢复不重发 |
| C04 | submitted 已提交后死亡：保留 submitted，原 live 请求过期；这仍不代表原生消费 |
| C05 | 精确关闭帧已入 inbox、尚未应用时死亡：恢复原子应用 closed，保留 submitted，重复恢复一致 |

五个 worker 均取得 SIGKILL 终态。每次恢复前分别验证原 owner 存活和 unknown 都拒绝接管，确认出生身份已 stopped 才允许审计恢复；返回 liveGrant=false、automaticRetry=false。新的进程不能由持久 requestId 复造 live callback。

## 已验证的候选合同

决定使用稳定 commandId、原 requestId／作用域和内容摘要，只允许该请求的一个明确决定；事务提交失败不派发。投递记录 prepared／dispatching／submitted／not-sent／unknown，submitted 只说明本次发送函数已正常完成，不承诺原生接受或业务成功。请求活性独立为 open／closed／expired。

正常完成可以投影为“回应已提交，原生请求已结束”，无需一直保留“等待你回答”。关闭事实不消除投递未知，也不解除其他业务操作／目录／运行的约束。取消后迟到的传输事实只更新原记录，永不恢复入口或自动改投下一 Provider。

活着的启动闭包能证明未调用发送端，和宿主退出后只剩发送意图，是不同证据。前者可落 not-sent；后者必须保守 unknown。发送前取消 gate 与状态持久化顺序已经在受控交错中实跑，实际跨进程调用入口仍需接入同一 owner／协调边界。

inbox 保存原连接作用域摘要和原始帧，校验 typed native ID；应用关闭投影与 processed 标记同事务。回放源来自 §4.60，而不是本批重新跑出的原生结果。

## 限制

本批不含真实 Agent、业务写入、实际窗口／IPC，也未联合最终 CapabilityRunRegistry。回放仅覆盖 Codex 的请求关闭帧；Claude 缺唯一 form ID 的 hook 不被本合同猜测匹配。秘密答案没有进入夹具；生产的 secret／敏感字段仍需引用现有受保护存储，不能照搬本批合成 value_json 明文。

新的三部分 ledger 是 WillYou 候选，不宣称 T3 使用相同表。未知传输的人工处置、原生命令／文件审批、同连接并发请求、部分 socket、业务副作用对账及完整产品恢复仍按全局账推进。不是“所有请求恢复已验证完毕”。

## 证据

[结果](result.json)、[worker 与恢复审计](runtime-audit.json)、[源码及回放来源](source-review.json)、[归档摘要](archive-manifest.json)、[驱动／协议／SQLite](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性和外键通过，{len(sources)} 个构建输入复核。

复跑 build.mjs 后运行 probe.mjs；只结束脚本捕获的 worker。所有状态与合成发送文件均在临时目录，不操作日常会话。
''')
section='''#### 4.4.2 回应账的三个状态与恢复次序

[回应状态／退出恢复实验](实验/20261114_回应状态与发送取消恢复验证/README.md)验证了候选 SQL、发送／取消交错及五个真实 worker 退出点；复用 §4.60 的 Codex 关闭帧，未重新启动 Agent。它收口“正常回应不能因缺通用消费 ACK 而一直等待用户”的状态设计，不代替最终原生／业务接线。

| 记录 | 最小事实与变化 | 实现要求 |
| --- | --- | --- |
| 决定 | commandId、requestId、原作用域、决定内容摘要／受保护值引用 | 同命令同内容返回原收据，冲突拒绝；收据提交后才准派发，原决定不随取消被抹除 |
| 投递 | prepared → dispatching → submitted；有明确未发证明为 not-sent；是否发送不明为 unknown | submitted 仅是本地传输完成，不能命名成业务批准；真实消费证据另记其来源及精确对应 |
| 请求活性 | open／closed／expired，另存取消意图和关闭证据 | 不由投递回调重新打开；作用域包括连接代次与 typed native ID；旧回调不复造 |

决定已记录时不再显示“等待用户回答”；submitted＋closed 可显示“回应已提交，原生请求已结束”。closed＋unknown 同时成立，关闭等待入口不消除投递风险，也不放行尚未排空的业务操作或切换。具体文案与视觉留待 UI 评审，状态语义先固定。

取消先关闭同一宿主的发送 gate，再持久化取消状态。prepared 可转 not-sent；dispatching 通常转 unknown，只有仍活着的原闭包证明发送端从未调用才可收为 not-sent。已在途的本地传输后来返回成功，可补 submitted 事实，但请求继续 closed／expired，不复活或自动再发。

恢复必须确认原 owner 的 PID／出生身份已停止，在协调事务内复核原行；存活或未知不接管。原 callback 一律不从数据库复造。prepared → not-sent，dispatching → unknown，submitted 保留；原 live 请求过期。已持久化的精确关闭帧校验原 scope／摘要后，与 inbox processed 一起应用，重复恢复一致。返回审计结果不附带 liveGrant，也不自动重试。

本批的秘密值为空范围、发送端为受控夹具；生产须沿用受保护数据引用。最终请求 Schema 与真实 IPC／CapabilityRunRegistry、其他原生请求类型及业务副作用的联合仍需验证；上述局部证据不关闭整个 Q11／27。

'''
def tech(t):
 assert '#### 4.4.2 'not in t;t=t.replace('### 4.5 长输出、背压与存储失败',section+'### 4.5 长输出、背压与存储失败');t=t.replace('三维 Schema、已发回应与取消的竞争及恢复对账仍需补验；不得用界面结束等待消除未知副作用。','§4.4.2 已补三部分候选账、受控发送／取消交错和宿主退出恢复；最终原生／业务联合仍需补验，不得用界面结束等待消除未知副作用。');return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.61 决定／投递／请求活性分离及发送取消恢复

[回应账实验](实验/20261114_回应状态与发送取消恢复验证/README.md)S01–S08、C01–C05 共 13 项通过。实际协调锁／ResourceStore／Mac 身份加候选 ledger，回放 §4.60 原生关闭帧：正常 submitted＋closed 不再等待，关闭不构成批准，发送前取消可证 not-sent，在途取消及迟到完成不复活请求；私有句柄、typed native ID、inbox scope、事务回滚和重复命令均核验。

五个真实 worker SIGKILL 分别落在决定提交、发送意图、合成传输后、submitted 后、关闭帧入 inbox 后；恢复只在旧 owner stopped 后执行，重复一致，不重发、不恢复 liveGrant。零新 Agent／模型／业务调用。已补技术方案 §4.4.2 的三部分状态和恢复次序；发送端仍是夹具，未声称完整请求 IPC、原生协议及业务联合通过。

'''
def ledger(t):
 assert '### 4.61 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q01','Q04','Q11','Q12','Q27','Q28','Q43']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.61 补决定／投递／活性候选账、发送取消交错与真实 worker 退出，最终原生／业务接线仍待验 |'
 t='\n'.join(lines)+'\n';t=t.replace('继续核验三维回应账、并发与原生命令审批','§4.61 已补三部分回应账／受控交错及退出恢复；继续核验最终联合、同连接并发与原生命令审批');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：回应的决定／投递／请求活性已形成可执行候选，正常提交后结束等待、取消与迟到回包不复活、五个真实 worker 退出点恢复不重发，见[技术方案 §4.4.2](技研/技术方案.md)。仅技术研究，最终原生／业务／UI 联合仍待验。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：继续自动通知与主动读取的实际发送竞争，以及现有业务私有桥联合；请求状态采用本轮三部分合同，复用已通过的原生／恢复证据。其他责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
