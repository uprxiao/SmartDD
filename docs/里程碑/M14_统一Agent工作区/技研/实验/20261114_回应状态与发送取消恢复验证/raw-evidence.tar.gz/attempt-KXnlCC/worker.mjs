import {readFileSync,writeSync,appendFileSync}from'node:fs';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import {bind,decide,dispatch,journal,inspect}from'./ledger.mjs';
const spec=JSON.parse(readFileSync(process.argv[2])),db=new Database(spec.db);db.pragma('foreign_keys=ON');const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),store=new actual.ResourceStore(db,spec.root,undefined,{processes:reader});
const hold=point=>{if(spec.cut===point){writeSync(1,JSON.stringify({type:'checkpoint',point,identity:reader.read(process.pid)})+'\n');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0);}};
try{const handle=await bind(store,reader,spec.scope,spec.native,spec.id);await decide(store,handle,spec.command);hold('prepared');await dispatch(store,handle,async()=>appendFileSync(spec.transport,JSON.stringify(spec.command.value)+'\n'),{checkpoint:async point=>hold(point)});hold('submitted');await journal(store,handle,spec.frame);hold('journal');writeSync(1,JSON.stringify({type:'finished',result:inspect(store,handle.id)})+'\n');}catch(e){writeSync(1,JSON.stringify({type:'error',message:e.message,stack:e.stack})+'\n');process.exitCode=1;}finally{db.close();}
