from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_输入确认与宿主退出恢复验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==8 and not r.get('error');a=Path(r['out']);b=json.loads((root/'build.json').read_text())
for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha(Path(b['output']['file']).read_bytes())==b['output']['sha256']
for n in ['build.mjs','build.json','actual.cjs','input.mjs','input.sql','worker.mjs','watch.py','probe.mjs']:assert(root/n).read_bytes()==(a/n).read_bytes(),n
workers=json.loads((a/'workers.json').read_text());watchers=json.loads((a/'watchers.json').read_text());models=json.loads((a/'model.json').read_text());assert len(workers)==17 and len(watchers)==4 and len(models)==3;assert all(x.get('exit')and not x.get('cleanupKill')for x in workers+watchers);assert sum(x['exit']['signal']=='SIGKILL'for x in workers)==5;assert sum(x['exit']['code']==0 for x in workers)==10;assert sum(x['exit']['code']==1 for x in workers)==2;assert all(x['exit']['code']==0 and any(y.get('exitObserved')for y in x['frames'])for x in watchers)
native=[frame for w in workers for frame in w['frames']if frame['type']=='native-spawn'];assert len(native)==4
for i in range(5):assert r['checks'][i]['evidence']['modelRequests']==(0 if i<2 else 1)
runtime={'attempt':a.name,'workerCounts':{'total':17,'killedAtCheckpoint':5,'recoveryCode0':10,'expectedRejectionCode1':2},'nativeProcesses':native,'watchers':watchers,'nativeExitEvidence':'macOS kqueue NOTE_EXIT plus actual MacProcessIdentityReader stopped; native exit codes unavailable because owning worker was killed','localModelRequests':3,'recoveryNativeSpawns':0,'supplierCalls':0,'scope':'Actual worker exit and live Codex confirmation with temporary input/inbox ledger. Synthetic task/binding/run scope, not actual CapabilityRunRegistry or business grant integration.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/process-identity.ts',repo/'src/main/core/applications/resource-lock.ts',t3/'apps/server/src/orchestration-v2/Orchestrator.ts'];review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(b['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'t3Scope':'Orchestrator command receipt lookup/replay inspected; not evidence of T3 native exactly-once delivery.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and not any(x.startswith('native-home-')for x in p.parts)and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.py','.log','.stderr']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)]and c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 输入确认与宿主退出：持久恢复验证

2026-11-14；R03／04／05／06／12，Q14–18／24–28／46–48／54–55；技术方案 §6.2、验证账 §4.56。技术研究，不修改产品或原型。

## 执行路径

临时输入账保存 commandId、inputId、文本／来源、完整目标 scope 摘要、派发状态与原宿主 PID／出生身份。回调用本进程私有句柄校验原 owner，再把原生 item/completed 用户输入事件写入独立 inbox；事件确认与输入 receipt 应用分开，使已持久事件可以在后续进程对账。scope 字段是实验生成的 task／binding／run／generation，并非本轮真实 CapabilityRunRegistry 记录。

初始 worker 启动真实 Codex 0.167.1 app-server，对本机合成模型服务发送输入。驱动只在已收到明确 checkpoint 后 SIGKILL 自己捕获的 worker；四个有 native 子进程的场景先注册 macOS kqueue NOTE_EXIT，再核对实际进程出生身份已 stopped。不是按名称查 PID 或等待固定时间猜退出。子进程原始退出码因父 worker 被杀而不可用，不能写成 native code 0。

恢复 worker 只读取原输入和 durable inbox，不创建 native 进程、不重发输入，也不建立业务桥或 live 授权。恢复前要求原 owner 已停止，锁内再次比较原行；存活和身份未知拒绝。

## C01–C08：{a.name}

| 场景 | 实际结果 |
| --- | --- |
| C01 只登记 queued 后退出 | 没有 native 或模型请求；新进程判断 not-dispatched。原 owner 仍活或出生身份故障变成 unknown 时均拒绝恢复 |
| C02 dispatching 落库、尚未写 turn/start 时退出 | 已启动 app-server，但无模型请求。恢复仍为 unknown，不凭“实验知道没写”替代产品的持久未发送证明 |
| C03 原生实际完成、确认尚未记入 inbox | 模型服务有一次请求，驱动看到真实接受和终态；输入账没有这些持久证据。恢复 unknown，不重发 |
| C04 inbox 已提交、输入 receipt 尚未应用 | 新进程从固定 scope／frame 摘要和原生 thread／turn／item／clientId 补齐 accepted 审计回执；不会据此补写模型成功终态 |
| C05 receipt 已提交、回包前退出 | 返回原接受身份；重复恢复结果一致，没有第二次 native 调用 |
| C06 相同 commandId 重试／冲突 | 读取原 unknown 回执，不签发新的私有派发句柄；同命令不同文本拒绝 |
| C07 inbox 换 thread 并重算摘要 | 仍因原 scope 不匹配拒绝，原接受回执不改写；hash 正确不能替代归属校验 |
| C08 同 clientId 的两份真实接受 | 回放 §4.55 中实际 Codex 两个不同 turn／item 的接受帧，拒绝 AMBIGUOUS_NATIVE_ACCEPTANCE；不猜配一条回执，processed 标记一起回滚 |

五个切点每个都另起两次恢复 worker 验证回执稳定。共 17 个 worker：5 个计划内 SIGKILL、10 个恢复成功 code 0、2 个活／未知 owner 拒绝 code 1；另有 4 个 kqueue 观察 helper code 0。四个 native 均确认退出；总 3 次本机合成模型请求，恢复阶段零 native spawn／零模型请求。

首次 attempt-CaUUXd 在本机监听遭 EPERM，无 worker／native 执行，保留预检结果；在已批准隔离监听范围重跑，未改实验逻辑。全部最终脚本与真实源码输入 hash 已复核。

## 设计边界

C02 与 C03 的恢复结果同为 unknown，但外部事实分别是未发送和已完成，说明单靠 dispatching 行不可能推断外部执行。任何“失败就重发”的方案都可能重做已完成工作。Provider 切换、同 Provider 新 binding、委派 prompt 和子结果投递都不能绕开该未知状态。

inbox 有完整且唯一的接受证据，才能补原输入的 accepted 审计；原生接受、模型终态、业务副作用、父已观察仍是不同记录。本批仅持久化用户输入接受帧，即使驱动看到了 turn/completed，也没有擅自升级成功状态。

queued 的结果仅证明没有进入派发路径，不证明原空 native thread 可恢复或完整后续发送已验证；真正重试前仍须核原目标、配置、权限和执行资源。恢复回执不是自动恢复真人 live 来源，不能绕过原业务的 proof／claim。

当前 inbox 由临时单 owner 脚本写入；正式实现仍须接到真实 driver 通道、业务 run／generation、规范事件持久化、输入来源和 UI sender，补 Schema／预算及原子事件消费合同。没有覆盖主机断电、消息部分写入、子进程继续活着时的恢复、Claude、真实业务副作用或父子结果完整联合。C08 是真实旧帧回放，不冒充该次 live 回合。

T3 的 Orchestrator 在 command receipt 已存在时走 replay，并防止跨 thread 重用；可参考宿主命令幂等层，但不能把宿主 receipt 与 native 执行完成混为一谈。本批没有验证 T3 的 native 崩溃恢复策略。

## 证据

[结果](result.json)、[进程及恢复审计](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[驱动、线帧与数据库](raw-evidence.tar.gz)。{len(files)} 文件，{len(dbs)} 份 SQLite 完整性和外键通过；{len(b['sources'])} 个真实构建输入核对。完整 native HOME 未重复归档，关键线帧与数据库快照已保留。

复跑限新临时目录，需 macOS kqueue、已构建进程身份 helper、隔离依赖及 loopback 监听；脚本会终止自己捕获的 worker，不能换成用户进程。Python 仅是观察工具，不是产品依赖决策。
''')
section='''### 6.2 持久输入与接受事件的恢复

[宿主退出实验](实验/20261114_输入确认与宿主退出恢复验证/README.md)使用真实 Codex 输入、五个 worker SIGKILL 切点和独立恢复进程，验证“命令已登记、已派发、原生接受、事件已持久化、回执已应用”必须分开。派发记录与外部发送之间无法靠一张数据库事务获得 exactly-once；本批 dispatching 后尚未发送与原生已完成但确认未落库两种场景，恢复都必须保留 unknown。

| 持久事实 | 恢复决策 |
| --- | --- |
| queued，未进入派发 | 保留未发送；重新取得合法执行条件后才能继续，不复用旧进程句柄 |
| dispatching，无唯一持久接受证据 | 标记 unknown，停止自动重发、自动切 Provider 或创建新 thread |
| inbox 已持久、输入回执未应用 | 校验原 owner、完整 scope、事件摘要和原生身份，唯一匹配才补 accepted 审计回执 |
| 原回执已提交 | 同 commandId 返回原回执；内容或目标冲突拒绝，不重新调用 driver |
| 一 inputId 对应多个 native turn／item | 保留冲突与原始证据，不选最新或第一条冒充唯一接受 |

inbox 与输入回执应用都须幂等；消费标记和回执在同一事务更新，失败保留原事件。原 owner 存活／未知不接管，确认已退出后仍在协调锁内复查原行，避免观察期间记录被替换。临时实验已覆盖真实接受事件的持久化前／后窗口、恢复重复、同命令冲突与篡改 scope；实际驱动事件入库、规范事件序列、业务 run／来源授权和 UI 的联合仍须补齐。

accepted 仅表示这一原生输入被接受，不等于模型成功、业务操作完成或父任务已观察；终态／结果／副作用各自持久对账。恢复返回原历史凭据不自动恢复真人 live 授权。未知状态保留原目标和输入来源，不以换 Provider、重建 binding 或重新投递子结果作为绕行路径。

'''
def tech(t):
 assert '### 6.2 'not in t;return t.replace('## 7. 单／多 Agent 与 Skill 复用',section+'## 7. 单／多 Agent 与 Skill 复用')
edit(base/'技研/技术方案.md',tech)
record='''### 4.56 原生输入确认与实际宿主退出恢复

[持久输入实验](实验/20261114_输入确认与宿主退出恢复验证/README.md)C01–C08 用真实 Codex／本机模型、实际 worker SIGKILL 和 kernel exit 观察，覆盖 queued、dispatch 意图、接受未入 journal、journal 已提交、receipt 已提交五个窗口。恢复分别保留未发送／unknown／accepted 审计，不派发 native；同命令冲突、活／未知 owner、inbox 跨 thread 篡改及同 clientId 两个真实 turn 的回放冲突均拒绝。

最终 attempt-GZUUOY 八项通过；17 worker 终态回执、4 native kernel exit 与身份停止证据、4 observer 退出记录、3 本机模型请求。初次监听 EPERM 无 native。技术方案新增 §6.2。临时 scope 未接真实业务 run，未恢复 live grant，也未把输入接受当 turn／副作用成功；Claude、子进程仍活、真实 driver inbox、业务来源及父子结果完整联合仍未关闭。

'''
def ledger(t):
 assert '### 4.56 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q14','Q15','Q16','Q17','Q18','Q24','Q25','Q26','Q27','Q28','Q46','Q47','Q48','Q54','Q55']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.56 补真实 Codex／宿主退出的持久输入恢复，完整业务 run／结果链仍待联合 |'
 t='\n'.join(lines)+'\n';t=t.replace('A→B→A 正常路径已有原生证据，但完整覆盖账和失败窗口未闭环','A→B→A 正常路径已有原生证据；§4.55–4.56 补原生 ID 重发差异与 Codex 接受／宿主退出窗口，完整覆盖账、Claude 和业务 run 联合未闭环');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补真实 Codex 输入确认与五个宿主退出窗口的恢复，见[技术方案 §6.2](技研/技术方案.md)。恢复不重发未知输入；持久原生事件可补原接受回执，同 ID 多个 turn 拒绝猜配。该实验未替代完整业务 run／来源授权联合。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：优先将输入恢复与父子结果投递、实际业务 run／generation 及 Claude 对照联合；按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续收口协议、业务 MCP、资源历史／GC、平台、性能和 UI 状态设计。复用已有证据，只做技术研究与文档，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(b['sources'])}))
