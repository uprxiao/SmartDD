import os,select,sys,json
pid=int(sys.argv[1]);k=select.kqueue()
try:
 k.control([select.kevent(pid,filter=select.KQ_FILTER_PROC,flags=select.KQ_EV_ADD|select.KQ_EV_ENABLE|select.KQ_EV_ONESHOT,fflags=select.KQ_NOTE_EXIT)],0,0)
 print(json.dumps({'ready':True,'pid':pid}),flush=True)
 events=k.control([],1,20)
 print(json.dumps({'pid':pid,'exitObserved':bool(events),'flags':[e.fflags for e in events]}),flush=True)
 if not events:sys.exit(2)
finally:k.close()
