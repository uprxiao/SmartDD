import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync,globSync,existsSync,symlinkSync,copyFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD',sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
if(!existsSync(root+'/node_modules'))symlinkSync('/private/tmp/willyou-m14-owner-probe/node_modules',root+'/node_modules');
for(const name of ['migration.mjs','candidate.sql'])copyFileSync('/private/tmp/willyou-m14-browser-native-cli-probe/'+name,root+'/'+name);
const extra={
 'db/client':['openDbClient'],'db/migrations':['runBundledMigrations'],'secrets':['SecretsStore'],
 'core/projects/project-service':['ProjectService'],'core/projects/transfer-service':['ProjectTransferService'],'core/projects/transfer-format':['decryptProject','encryptProject','decryptTransfer','encryptTransfer','validatePayload'],'core/projects/transfer-fixtures':['transferFixture'],
 'core/ai/ai-profile-service':['AiProfileService'],'core/ai/agent-service':['AgentService'],'core/ai/provider-service':['ProviderService'],'core/ai/agent-transfer':['AgentTransferService']
};
const entry=Object.entries(extra).map(([m,n])=>`export {${n.join(',')}} from '${repo}/src/main/${m}.ts';`).join('\n')+`\nexport {initialTransferDraft} from '${repo}/src/shared/project-transfer.ts';`;
const result=await build({stdin:{contents:entry,resolveDir:repo,loader:'ts'},bundle:true,platform:'node',format:'cjs',target:'node22',metafile:true,tsconfig:repo+'/tsconfig.node.json',external:['better-sqlite3','electron'],nodePaths:[root+'/node_modules','/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules'],outfile:root+'/actual.cjs',plugins:[{name:'expand-vite-globs',setup(b){b.onLoad({filter:/\/(db\/migrations|capabilities\/assets)\.ts$/},({path})=>({loader:'ts',contents:readFileSync(path,'utf8').replace(/import\.meta\.glob\('([^']+)',\s*\{[\s\S]*?\}\)/g,(_,pattern)=>'('+JSON.stringify(Object.fromEntries(globSync(pattern.replace('@root/',repo+'/')).filter(p=>statSync(p).isFile()).map(p=>[p,readFileSync(p,'utf8')])))+')')}));}}]});
const sources=Object.keys(result.metafile.inputs).filter(p=>!p.startsWith('<')).map(p=>p.startsWith('/')?p:process.cwd()+'/'+p).concat(globSync(repo+'/drizzle/*.sql'));
writeFileSync(root+'/build.json',JSON.stringify({sources:[...new Set(sources)].map(path=>({path,sha256:sha(path)})),outputs:[{path:root+'/actual.cjs',sha256:sha(root+'/actual.cjs')}],scope:'Actual current registry and fixture; Vite glob expansion only. No product source variants.'},null,2));
console.log(JSON.stringify({sources:sources.length}));
