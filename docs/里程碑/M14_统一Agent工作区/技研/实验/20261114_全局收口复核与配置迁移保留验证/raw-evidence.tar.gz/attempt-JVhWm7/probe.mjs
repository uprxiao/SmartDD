import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdirSync,mkdtempSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import actual from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],fixtures=[],pass='M14-Research-Only',KEY='PUBLIC_SYNTHETIC_M14_TRANSFER_KEY';
const save=(n,x)=>writeFileSync(out+'/'+n,JSON.stringify(x,null,2)+'\n');for(const n of ['build.mjs','build.json','probe.mjs'])copyFileSync(root+'/'+n,out+'/'+n);
function setup(name){
 const home=out+'/'+name;mkdirSync(home);const client=actual.openDbClient(home+'/state.sqlite');actual.runBundledMigrations(client.sqlite);let decrypts=0;
 const secrets=new actual.SecretsStore(client.db,{isAvailable:()=>true,encrypt:s=>Buffer.from(name+':'+s),decrypt:b=>{decrypts++;assert(b.toString().startsWith(name+':'));return b.toString().slice(name.length+1);}});
 let projectsTransfer;const projects=new actual.ProjectService(client.db,secrets,()=>1000,()=>projectsTransfer.keys.cleanup()),profiles=new actual.AiProfileService(client.db,secrets);
 projectsTransfer=new actual.ProjectTransferService({db:client.db,secrets,projects,profiles,userData:home,appVersion:'0.0.0-research',env:()=>({PATH:'/usr/bin:/bin'}),now:()=>1000});projectsTransfer.recover();
 const agents=new actual.AgentService(client.db,secrets,()=>1000),providers=new actual.ProviderService(client.db,secrets,agents,{fetch:()=>{throw Error('NETWORK_FORBIDDEN');}}),agentTransfer=new actual.AgentTransferService(client.db,secrets,agents,providers,()=>1000);
 const f={name,home,client,secrets,projects,profiles,projectsTransfer,agents,providers,agentTransfer,decrypts:()=>decrypts};fixtures.push(f);return f;
}
function draft(f,preview){const d=actual.initialTransferDraft(preview);d.name='Imported '+randomUUID();for(const row of d.directories){const path=f.home+'/dir-'+randomUUID();mkdirSync(path);f.projectsTransfer.allowDirectory(1,preview.token,path);row.localPath=path;}return d;}
async function importProject(f,path){const chosen=f.projectsTransfer.choose(1,path),preview=await f.projectsTransfer.unlock(1,chosen.fileToken,pass);return f.projectsTransfer.commit(1,preview.token,randomUUID(),draft(f,preview));}
const dbState=f=>JSON.stringify(Object.fromEntries(['ai_providers','ai_profiles','ai_run_configs','ai_tools','app_secrets'].map(n=>[n,f.client.sqlite.prepare('SELECT * FROM '+n+' ORDER BY rowid').all()])));
const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}finally{save('progress.json',checks);}};
let error;
try{
 const sender=setup('sender'),receiver=setup('receiver');
 await check('T01','actual encrypted project transfer preserves configured DB and SSH credentials but creates no task history',async()=>{
  const input=out+'/source.willyou';writeFileSync(input,await actual.encryptProject(actual.transferFixture(),pass));const source=await importProject(sender,input),snapshot=sender.projects.getProject(source.projectId),target=out+'/exported.willyou';
  await sender.projectsTransfer.exportTo(target,source.projectId,[],[],pass);const raw=readFileSync(target),payload=await actual.decryptProject(raw,pass);assert(!raw.includes(Buffer.from('synthetic-db-password')));assert(Object.values(payload.credentials).some(x=>x.password==='synthetic-db-password'));assert(Object.values(payload.credentials).some(x=>x.password==='synthetic-ssh-password'));assert(!('tasks'in payload));assert(!('bindings'in payload));
  const imported=await importProject(receiver,target),copy=receiver.projects.getProject(imported.projectId);assert.notEqual(copy.id,snapshot.id);assert.notEqual(copy.databases[0].id,snapshot.databases[0].id);assert.notEqual(copy.servers[0].id,snapshot.servers[0].id);const exported=receiver.projectsTransfer.snapshot(copy.id,[],[]);assert(Object.values(exported.credentials).some(x=>x.password==='synthetic-db-password'));assert.equal(receiver.client.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,0);assert.deepEqual(sender.projects.getProject(source.projectId),snapshot);
  return{encryptedCredentialsPreserved:true,newProjectAndConnectionIds:true,noTaskHistory:true,sourceUnchanged:true};
 });
 sender.agents.recordTools([{id:'synthetic-codex',kind:'codex',executable:'/synthetic/bin/codex',installed:true,login:'subscription',version:'synthetic'}]);
 const provider=sender.agents.saveProvider({name:'Research Provider',key:KEY,endpoints:{responses:'https://provider.example.invalid/v1'},models:[{id:'research-model',name:'Research model',availability:{codex:'available',claude:'untested'}}],recommended:{codex:'research-model'}});
 const config=sender.agents.saveConfig({name:'Research Agent',toolId:'synthetic-codex',source:'provider',providerId:provider.id,models:['research-model'],defaultModel:'research-model'});
 let plain;
 await check('T02','default Agent export excludes keys and local execution identities without decrypting secrets',async()=>{
  const before=sender.decrypts();plain=await sender.agentTransfer.exportBytes({providerIds:[],agentIds:[config.id]});assert.equal(sender.decrypts(),before);const p=JSON.parse(plain);assert.deepEqual(p.credentials,{});assert.equal(p.providers.length,1);assert.equal(p.agents.length,1);for(const text of [KEY,'/synthetic/','secretRef','nativeSessionId','bindingId'])assert(!plain.toString().includes(text));assert.equal(p.providers[0].models[0].availability.codex,'untested');return{noKeyRead:true,noExecutableOrNativeBinding:true,providerIncludedOnce:true,foreignChecksReset:true};
 });
 await check('T03','explicit encrypted key transfer imports fresh identities without requiring installed CLI or carrying runtime authorization',async()=>{
  await assert.rejects(sender.agentTransfer.exportBytes({providerIds:[],agentIds:[config.id],includeKeys:true,password:pass}),/再次输入/);
  const old=receiver.agents.saveProvider({name:provider.name,key:'PUBLIC_SYNTHETIC_EXISTING',endpoints:provider.endpoints,models:provider.models,recommended:provider.recommended}),oldRow=receiver.client.sqlite.prepare('SELECT * FROM ai_providers WHERE id=?').get(old.id);
  const encrypted=await sender.agentTransfer.exportBytes({providerIds:[],agentIds:[config.id],includeKeys:true,password:pass,confirmation:pass});assert(!encrypted.includes(Buffer.from(KEY)));writeFileSync(out+'/agents-encrypted.willyou',encrypted);
  const chosen=receiver.agentTransfer.inspect(7,encrypted);assert.equal(chosen.encrypted,true);assert.equal(chosen.preview,null);const preview=await receiver.agentTransfer.unlock(7,chosen.token,pass);assert.equal(preview.providers[0].needsKey,false);assert.equal(preview.agents[0].toolInstalled,false);assert(!JSON.stringify(preview).includes(KEY));
  const result=receiver.agentTransfer.commit(7,chosen.token);assert.deepEqual(receiver.agentTransfer.commit(7,chosen.token),result);const imported=receiver.agents.providers().find(p=>p.id===result.providerIds[0]),agent=receiver.agents.configs().find(c=>c.id===result.agentIds[0]);assert(imported.hasKey);assert.notEqual(imported.id,provider.id);assert.notEqual(imported.id,old.id);assert.notEqual(agent.id,config.id);assert.equal(agent.providerId,imported.id);assert.equal(imported.models[0].availability.codex,'untested');assert(receiver.agents.tools().some(t=>t.kind==='codex'&&!t.installed&&t.login==='none'));assert.deepEqual(receiver.client.sqlite.prepare('SELECT * FROM ai_providers WHERE id=?').get(old.id),oldRow);assert.equal(receiver.client.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,0);
  return{confirmedEncryptedKeysPreserved:true,missingCliImportAllowed:true,previewUsesLocalToolInstalledFlag:true,newIdsAndNoMerge:true,noImportedLoginOrTasks:true};
 });
 await check('T04','local-login export rejects; imported login declarations skip; unknown runtime fields fail before mutation',async()=>{
  const login=sender.agents.saveConfig({name:'Local Login',toolId:'synthetic-codex',source:'login'}),before=sender.decrypts();await assert.rejects(sender.agentTransfer.exportBytes({providerIds:[],agentIds:[login.id]}),/不能导出/);assert.equal(sender.decrypts(),before);
  const payload=JSON.parse(plain);payload.agents.push({ref:'foreign-login',name:'Foreign login',source:'login',kind:'codex'});const parsed=receiver.agentTransfer.inspect(8,Buffer.from(JSON.stringify(payload)));assert.equal(parsed.preview.skipped.length,1);assert.equal(parsed.preview.agents.length,1);receiver.agentTransfer.disposeOwner(8);
  const state=dbState(receiver),withRun={...JSON.parse(plain),runtimeBindings:[{runId:randomUUID()}]};assert.throws(()=>receiver.agentTransfer.inspect(9,Buffer.from(JSON.stringify(withRun))));assert.equal(dbState(receiver),state);const future=JSON.parse(plain);future.agents[0].kind='future-driver';assert.throws(()=>receiver.agentTransfer.inspect(10,Buffer.from(JSON.stringify(future))));assert.equal(dbState(receiver),state);
  return{nativeLoginNotPortable:true,unknownRunMetadataRejected:true,unknownDriverRejectedWithoutMutation:true};
 });
 for(const f of fixtures){assert.equal(f.client.sqlite.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(f.client.sqlite.pragma('foreign_key_check'),[]);}
}catch(e){error=e.stack;process.exitCode=1;}
finally{for(const f of fixtures){f.projectsTransfer.disposeAll();for(const owner of [1,7,8,9,10])f.agentTransfer.disposeOwner(owner);f.client.sqlite.close();}}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,error:error??null,scope:'Actual current project/Agent transfer, config, secret-store and SQLite services. Synthetic cipher/credentials/directories and captured existing portable schemas. Actual file password encryption; no OS keychain, network, SSH/DB connection or M14 product migration/managed-runtime UI.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
