from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_全局收口复核与配置迁移保留验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
reviewed=['需求.md','技研/技术方案.md','技研/全局设计验证账.md','技研/兼容验证计划.md','验收/测试用例.md','README.md']
before=root/'reviewed-documents';before.mkdir(exist_ok=True)
for name in reviewed:
 p=before/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/base/name).read_bytes())
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'scope':r['scope'],'reviewedDocuments':[{'path':str(base/name),'sha256':sha((repo/base/name).read_bytes())} for name in reviewed],'findings':['Q42／P0.4／A42 vague no-new-credentials wording conflicts with existing explicit encrypted credential transfer.','A42 assumes project package contains old/new tasks; current project transfer carries configuration, not task/native history.','Agent import preview has toolInstalled based on local CLI; managed runtime availability must be separate in M14.','D01–D08 current backlog mixes past proof and remaining proof; rewrite next decisive evidence without treating UI implementation as prerequisite for research completion.'],'externalNativeDependency':{'path':'/Users/hx/hx/hxWork/SmartDD/node_modules/.pnpm/node-pty@1.1.0/node_modules/node-pty/lib/index.js','sha256':sha(Path('/Users/hx/hx/hxWork/SmartDD/node_modules/.pnpm/node-pty@1.1.0/node_modules/node-pty/lib/index.js').read_bytes()),'used':'Module load only; no terminal spawn.'}}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['build.mjs','build.json','actual.cjs','probe.mjs','source-review.json','prepare.py']]
for d in [before,root/'bootstrap-failure',*sorted(root.glob('attempt-*'))]:files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'bootstrapFailure':json.loads((root/'bootstrap-failure/failure.json').read_text()),'reviewScope':'Requirement/artifact trace and remaining-decision audit; not evidence that every Q or D is closed.'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 全局收口复核与配置迁移保留验证

日期：2026-11-14。关联 R08／R10／R11／R12、Q42，兼及 D01–D08 的剩余决策整理。先核对 R0.2、T0.1、P0.4、全局账及 A42，再使用当前实际配置迁移服务验证发现；没有生产代码变更。

## 发现与修正

1. 原账 Q42、计划与 A42 笼统禁止复制新凭据，可能被实施者理解为删除既有加密迁移功能。实际项目包包含口令加密的 DB／SSH 等配置凭据；Agent 包默认不带 Key，但支持明确选择并确认口令后加密携带。设计应保留它们，禁止的是擅自复制运行票据、登录态、审批回执、业务授权和任务绑定。
2. A42 写“带新旧任务的项目包／导入保留历史”，超出了当前配置迁移格式。现有项目导入创建新项目与连接 ID，不迁移任务／原生历史。旧任务应在原项目保持不变；原生历史导入另按 A46 验证。
3. Agent 导入预览只读本机 toolInstalled。缺少 CLI 可以保存配置，不代表执行可用；M14 应分别显示配置、凭据、受管／外部运行资源及适配兼容性，不得以本机 CLI 缺失否定已就绪受管程序，也不能以导入成功承诺可运行。
4. 当前 D01–D08 表混合历史进展与下一步，若逐句照读，会重复已验证分支。已在原权威账重写每类的下一份决定性证据和产品后验收边界，不另建第二套需求或通过率。

## 四项实际服务检查

| 检查 | 证据 |
| --- | --- |
| T01 项目配置往返 | 实际 ProjectTransferService、ProjectService、SecretsStore 与 SQLite；密码加密文件保留合成 DB／SSH 凭据，接收方项目／连接 ID 重建，原项目不变，未创建任务历史 |
| T02 Agent 默认导出 | 实际 AgentTransferService 默认不读取密钥，配置包不带 Key、本机 executable 或 native binding；选中 Agent 的 Provider 只携带一次，模型检查重置为 untested |
| T03 明确携 Key | 缺确认口令拒绝；确认后实际加密／解密并导入新 Provider／Agent ID，不合并相同 URL 的旧 Provider、不泄露 Key 到预览；无本机 CLI 仍能保存，预览 toolInstalled=false，未继承登录态 |
| T04 不可移植内容 | 本机登录 Agent 拒绝导出；外来 login 声明跳过；包内擅加运行绑定字段或未知 driver 拒绝且数据库未变 |

四项通过，两份实际 SQLite 外键／完整性通过。文件密码加密为实际实现；系统 SecretCipher 使用每个库独立的合成后端，凭据均为公开合成值。没有系统 Keychain、DB／SSH 网络、Provider 认证、SDK 运行或新 UI 验证。此证据证明应保留的现有服务基线，不代表 M14 完整接线已完成；Q42 只从待集成调整为部分。

首次独立构建把 node-pty 一并打包，原生模块按临时 bundle 路径寻找 pty.node 而失败，未进入断言。改为外部加载实际已安装 node-pty 模块，正常加载后四项通过；未调用终端 spawn。原构建、错误摘要及修正来源保留。

## 全局结论

R01–R12 的目标与业务保留前提仍完整，不能据此宣布全量开发就绪。剩余重点转为同一研究 Schema 下的身份／资源／运行联合、业务结果与授权汇总、跨运行输入覆盖、主子完整回收、目录准入和支持／性能矩阵。现有证据足够的分支引用原实验，不重复累计；真实产品界面／安装验收仍留在后续 A 用例。具体待验内容只在验证账 §7.1 维护。

## 复现与证据

固定依赖具备时执行 `node build.mjs`、`node probe.mjs`，不需要网络或真实账号。归档包含当前构建与 243 条输入摘要、驱动、两份合成数据库、实际加密文件、首次构建失败及复核前的文档快照。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text()
t=t.replace('源码基线：SmartDD `40ea344a930aec37e36a803b7c621d3632d2d75a`，T3 `f313d0a6cb843551fb60e57a454a71e71a3a8c04`。','初始源码基线：SmartDD `40ea344a930aec37e36a803b7c621d3632d2d75a`；后续受影响模块已按实验复核至 `5a9e04382441e24624cb94635f9d902c543a03d7`，以各实验来源摘要为准，不表示早期实验全量重跑。T3 参考 `f313d0a6cb843551fb60e57a454a71e71a3a8c04`。',1)
t=t.replace('| 项目、语音、导入导出 | 保留身份、路径、数据及既有入口；语音文本进入相同草稿／提交链 | 项目删除／导入重名、引用有效性、恢复历史、秘密导出规则 |','| 项目、语音、导入导出 | 保留原项目身份及既有配置迁移／加密规则；导入生成新配置身份，任务历史导入另行处理；语音进入同一草稿／提交链 | 重名不覆盖、已选凭据的加密迁移、登录态不迁移、无 CLI 预览、原任务不受影响 |',1)
section='''### 9.9 项目与 Agent 配置迁移的既有边界

[当前服务往返实验](实验/20261114_全局收口复核与配置迁移保留验证/README.md)核对了 ProjectTransferService 与 AgentTransferService；“不新增凭据副本”不能解释为禁用既有的明确加密导出。当前能力分开保留：

| 入口／格式 | 保留的实际行为 | 不随配置包迁移的内容 |
| --- | --- | --- |
| 项目配置，willyou.project | 口令加密所选项目配置、DB／SSH 凭据及所选兼容配置；导入重新选择／核对本地目录，生成新项目与资源 ID，凭据交接给接收方 SecretsStore，不覆盖原项目 | 任务／原生会话历史、M14 binding／run、运行权限和业务审批；这不是整个项目数据库备份 |
| Agent 配置，willyou.agents | 默认不带 Key；用户明确 includeKeys 并确认口令后加密携带所选 Provider／高级配置凭据。导入创建新 Provider／Agent 身份，即使 URL／名称相同也不自动合并；模型检查重新验证 | 本机可执行路径、CLI 登录态、SDK 会话与运行票据、审批回执；导入配置不恢复旧 run 权限 |

当前 Agent 导入预览的 toolInstalled 来自本机 CLI 记录，缺 CLI 不阻止配置保存。M14 把“配置已保存”“凭据是否就绪”“选择的受管／外部运行资源是否可用”“当前适配组合是否支持”分开投影；导入不应偷偷安装／切换执行器，不因导入成功自动绑定既有任务。运行资源路径、摘要及配置修订在用户选择运行目标时由宿主重新解析，不能从导出方复制。受管程序已就绪时不得因全局 CLI 缺失误显示为不可运行；具体预览与启动组合仍需后续集成验证。

现有可移植 Schema 只接收已声明格式和 driver，不能为更多 Agent 静默转写为 Claude／Codex。扩展时明确升级格式／支持矩阵；未知必需字段或运行授权材料继续拒绝，不把“可扩展”当作任意 JSON 已兼容。新导入 ID 不等于原配置身份，既有任务的固定来源／恢复绑定不会按名称或端点自动改投。原生历史导入走 §11 和 A46，保持来源识别与恢复准入，不能混进配置导入事务。

本批是当前服务及实际密码加密的合成数据实验，系统 Keychain、真实连接、受管运行预览、任务切换后配置失效与完整新接口仍待验证。A42 按以上现有行为回归，不再要求配置包携带任务历史，也不取消用户已拥有的加密凭据迁移能力。

'''
t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点',1)
old='2. 共享 SVN 联合实验已覆盖真实双向异步回执、父排空、子执行、父恢复及三个宿主退出窗口；Skill→能力目录→通知／结果观察又取得六项双向局部证据；继续补最终候选 Schema 下创建／outbox／完整交付引用的原子接管、读取／确认丢包、主动观察与通知竞争、父忙／切换、子问题及完整 scope。局部证据不等于完整协作机制或产品通过。'
new='2. 已有共享 SVN 异步交棒、Skill 委派／结果观察、通知竞争、混合子问题与宿主退出恢复证据；下一步按同一研究 Schema 串起创建／outbox、交付引用、原生输入、业务结果和父回收。重点验证尚未覆盖的提交交界与恢复，避免重跑已证明的局部分支；不将分散实验相加为完整协作机制。'
assert old in t;t=t.replace(old,new,1);put(rel,t)
rel=base/'技研/兼容验证计划.md';t=(repo/rel).read_text();old='导入导出不新增密钥副本；当前已交付行为逐项回归';new='保留既有项目／Agent 配置包的明确加密凭据迁移；默认 Agent 导出不带 Key，运行票据／登录态／审批不随包迁移；当前已交付行为逐项回归'
assert old in t;t=t.replace(old,new,1);put(rel,t)
rel=base/'验收/测试用例.md';t=(repo/rel).read_text()
t=t.replace('F04、F07；隔离数据库／SSH；语音入口；带新旧任务的项目包；不含真实秘密。','F04、F07；隔离数据库／SSH、语音入口、已有新旧任务的本地项目；独立项目配置包与 Agent 配置包，合成密码／Key／登录声明，无真实秘密。',1)
t=t.replace('导出后导入重名项目；检查新旧任务引用与配置。','分别导入重名项目、默认无 Key 与确认口令后携 Key 的 Agent 包；检查接收方新 ID、原项目／任务不变、本机登录不迁移；分别在缺全局 CLI／受管程序已就绪时核对预览与运行目标解析。',1)
t=t.replace('导入保留历史／来源关系，不复制新凭据、不误覆盖原项目；未交付旧需求不冒充回归完成。','配置导入按原加密／确认规则保留选定凭据，默认 Agent 导出不读取 Key；生成新配置身份、不覆盖原项目／配置、不复制登录态、binding／run 或审批；原项目任务历史不变，配置包不承担 A46 的原生历史导入。缺全局 CLI 不能使就绪的受管程序被误报不可用，导入成功也不等于执行已就绪；未交付旧需求不冒充回归完成。',1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.98 ' not in t
old='| Q42 | 数据库／SSH、语音、引用插入及导入导出保留 | E08／10；T29／30 | 待集成；逐个沿现有服务用例回归，导入导出不得复制新凭据；不以未修改代码代替接线验证 |'
new='| Q42 | 数据库／SSH、语音、引用插入及导入导出保留 | E08／10；T29／30 | **部分**：§4.98 验证实际项目／Agent 配置加密往返、默认不读 Key、明确携 Key、新 ID／缺 CLI／登录态及未知字段边界，修正禁止加密凭据迁移与配置包携任务历史的错误表述。仍需新目标／受管资源接线及数据库／SSH、语音、引用分项回归；当前服务基线不代表 M14 已集成 |'
assert old in t;t=t.replace(old,new,1)
add='''### 4.98 全局收口复核与配置迁移保留

[四项实际服务检查及设计复核](实验/20261114_全局收口复核与配置迁移保留验证/README.md)发现原 Q42／计划／A42 的凭据与历史表述会误改既有业务。当前 ProjectTransferService 支持口令加密的 DB／SSH 等配置凭据，AgentTransferService 默认不带 Key、明确确认后可加密携 Key；新配置 ID、原项目不变、缺 CLI 可保存、登录态不迁移及未知运行字段拒绝均已用合成数据实跑。配置包不包含任务历史，原生历史另按 A46。

首次构建内联 node-pty 后找不到原生模块，尚未进入检查；改用实际依赖原路径加载后四项通过，没有替换业务实现或启动 PTY。系统加密后端为合成 cipher、无真实网络或 Keychain。T0.1 §9.9、P0.4、A42 已统一，Q42 仅提升为部分。D01–D08 的当前待验表重写为下一份决定性证据，历史记录仍留 §4；不以结构覆盖或本次配置基线证明全量设计就绪。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1)
rows={
'D01':'| D01 身份／迁移，R02／03／08／10；Q13、Q46–50 | §4.29／33–48／73–76／88–93 已覆盖关键局部。下一步固定同一研究 Schema 修订，联合新旧写入口、历史身份占用、运行准入与资源保留读取；验证复制中途、合法历史续写后的恢复、旧根释放／回退和异常来源。要求同一状态库的原子提交／失败／接管证据，不能把不同候选表的通过拼接成完整迁移 | 最终产品迁移器、授权旧库副本、TaskService／PTY 与新旧包回退；既有任务／数据保持，未知来源可诊断 |',
'D02':'| D02 Driver／协议／配置，R02／03／11／12；Q01–07、Q10–12、Q20、Q29、Q54–55 | 固定版本权限、原生子节点、表单及混合问题恢复已有 §4.60–63／78–81／87／94–97 证据。下一步核定方法／事件／请求 Schema 和兼容矩阵，验证受管设置／历史权限继承、fork 前失效、第三适配器经实际 owner／业务边界复用及动态执行范围；不重复用基础表单证明全部协议 | 两端与第三夹具接同一任务服务；真实供应商／登录、声明版本与平台各有对应证据，本机端点不算供应商认证 |',
'D03':'| D03 Skill 协作复用，R06／07／12；Q08、Q23 | §4.30 已有共享 Skill→目录→委派、重开复用及失效目标。下一步联合实际配置／权限服务、规则更新／缺失、冻结脚本／相对资源和真实 owner 保留，明确何时提示变化、何时需新运行；规则不变成授权或强制流程引擎 | 统一任务中的 Skill 选择、同名／更新提示及真实模型最小场景；独立模板产品不列入本期 |',
'D04':'| D04 原业务接入，R01／08／10；Q09、Q37–42 | §4.59／64–77／88 已有插件、浏览器、私有桥、查看器和独立业务恢复证据；§4.98 补当前配置迁移基线。下一步用实际结果账构建交接汇总门禁，联合邮件真实上下文／预检／最终授权、插件审阅与实时版本、浏览器 run 授权及四类 MCP 释放；项目 UI 的无 task 操作、未知效果和重复记录不能漏判。先验证这些会改变身份／授权设计的分支 | 同包逐项回归浏览器、文件、查看器 MCP、插件、邮件、DB／SSH、语音和配置迁移；真实写入遵守已有授权，配置包不迁移运行权限 |',
'D05':'| D05 续聊／来源，R03／04；Q14–18 | A→B→A 与原生输入去重／恢复已有 §4.55–56 等局部证据。下一步在同一最终研究命令／覆盖账上联合真实配置修订、Claude／Codex 接收窗口、附件／预算遗漏与业务真人来源；验证已派发未知时的恢复禁止重发及显式后继 run，不以 client ID 或模型回答认定覆盖完成 | 同任务历史／草稿保留、交接遗漏与 unknown 恢复 UI；实际业务授权来源不被历史交接或子结果替代 |',
'D06':'| D06 委派状态，R05／06；Q19、Q24–28 | 创建／outbox、双向委派、父忙／切换、通知／观察竞争及混合子问题分别已有 §4.28–32／45–48／55–63／94–97 证据。下一步按 D01 同一 Schema 联合创建→准备／资源接管→实际原生输入→业务／结果→父回收，检查提交交界、已发回应未知、动态后代和跨宿主恢复；已证明的 pending 问题恢复不重复跑成新覆盖 | 活动树切主、单／多转换、父子审批／问题与子树取消的同包 UI；父 turn 结束不等于树完成 |',
'D07':'| D07 SVN／目录，R06／09；Q30–36 | §4.28／82–84 已有共享 SVN 异步交棒、只读反例、按需版本与串行准入。下一步联合准入提交、真实 owner／fork／目录路径变化与未知后台范围，补 Git 准备失败对账及查询覆盖；大型项目给出文件数、访问集合和 I/O 数据，稀疏大文件不代表 10GB 公司项目性能 | SVN／普通目录三核心流程、重叠路径、外部改动与成果保留；受限只读未被强制证明前保持串行，不开放自动 SVN 副本管理 |',
'D08':'| D08 UI／同步／分发，R01／10／11；Q43–45、Q51–53、Q56 | §4.9／24–25／49–54／85–86 有同步、输出和安装／资源局部证据。下一步明确默认安装和版本／平台支持表；联合原生／启动／历史引用、在用升级与最终删除守卫，核对下载／代理／离线故障；把 UI 状态、草稿／请求／运行冲突及性能预算写成可测契约，再做可独立验证的 IPC／缓存／流量检查 | 新原型／视觉批准、实际 IME／焦点／滚动、Finder／ASAR／签名／安装与每个声明平台；受管运行可用性不等于本机 CLI installed |'
}
lines=t.splitlines()
for i,line in enumerate(lines):
 for key,newrow in rows.items():
  if line.startswith('| '+key+' '):lines[i]=newrow
t='\n'.join(lines)+'\n'
t=t.replace('截至 §4.97，56 个宽口径问题项中，50 项有部分实验／限定证据，3 项主要内容仍待验证或产品集成','截至 §4.98，56 个宽口径问题项中，51 项有部分实验／限定证据，2 项主要内容仍待验证或产品集成',1).replace('三项为 Q42、Q51、Q52。','两项为 Q51、Q52。Q42 已补当前配置迁移服务基线，新工作区业务接线仍未完成。',1).replace('不是只剩三项。','不是只剩两项。',1).replace('不能用 50／56 作为研究完成率','不能用 51／56 作为研究完成率',1)
assert len(re.findall(r'^\| Q\d{2} \|',t,re.M))==56 and len(re.findall(r'^\| D0[1-8] ',t,re.M))==8;put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();t=re.sub(r'^最新进展：.*$','最新进展：全局复核发现并修正了配置导入导出的凭据／历史边界，实际服务四项检查通过；已按 D01–D08 重整剩余决定性证据。见[全局收口与配置迁移复核](技研/实验/20261114_全局收口复核与配置迁移保留验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$','下一步：优先推进[验证账 D04](技研/全局设计验证账.md#71-当前全局收口方式)的实际业务结果汇总与交接门禁，同时按同一研究 Schema 核对身份／资源／运行的联合约束；已有局部证据按边界复用，产品 UI／安装验收保持后续阶段。',t,flags=re.M);put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-live-question-recovery-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed'],'sourceInputs':len(b['sources'])}))
