from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_运行资源安装复用边界验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==8 and not result.get('error');a=Path(result['out']);build=json.loads((root/'build.json').read_text())
for s in build['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha(Path(build['output']['file']).read_bytes())==build['output']['sha256']
for n in ['build.mjs','actual.cjs','probe.mjs']:assert (root/n).read_bytes()==(a/n).read_bytes()
refs=[repo/'src/main/core/applications/runtime-registry.ts',repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/files/office/engine-resources.ts',repo/'scripts/files/prepare-office.py',repo/'scripts/files/prepare-libreoffice.py',t3/'apps/server/src/provider/CodexInstallation.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(build['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'RuntimeRegistry and ResourceStore actually executed unmodified. Office build preparation and T3 managed installation inspected only. Native programs only statted, no network or native process started.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,indent=2)),('source-review.json',(root/'source-review.json').read_bytes())]:put(exp/n,data)
put(exp/'README.md',f'''# 原生运行资源安装的复用边界

2026-11-14，R02／08／10／11／12，Q01／03／46／48／51／52／53／54；技术方案 §12.1、验证账 §4.49。本批仍是隔离技术研究，没有安装到产品、修改原型或进行正式验收。

## 需要纠正的复用假设

现有 `RuntimeRegistry` 管理应用业务桥，不是通用 Agent 原生程序安装器：入口必须为 .cjs、单文件最多 64 MiB／总量最多 256 MiB、安装文件权限 0600，校验拒绝执行位。本次已安装的 Claude native 大小 323686048 字节，Codex 为 271011440 字节；二者均不能直接用该合同交付。R01 用 64 MiB＋1 的无业务内容缓冲区实际触发预算拒绝，并只读取真实程序的 stat；没有读取或复制数百 MiB 程序进入实验归档。

因此保留旧业务桥合同，Agent 原生程序需要独立资源类型／清单。可复用更底层 ResourceStore 的发布身份、内容路径、准备／校验／就绪状态、归属和恢复原则，但“类型字段能存进去”不表示 GC、租约、执行计划、诊断或安装 UI 已支持该新类型。

## 实际检查

`{a.name}` R01–R08 通过，全部使用当前 SmartDD 模块，仅构建时展开静态资源 glob，没有替换业务源码行为。

| 项 | 结果与边界 |
| --- | --- |
| R01 | 真实文件大小超过桥合同；实际 validateRuntime 拒绝超过单文件预算的合成缓冲区 |
| R02 | 小型合成 bin/codex 入口也因非 .cjs 被拒绝，不只是容量问题 |
| R03 | 正常桥安装为 0600；改为 0700 后实际 verify 拒绝，恢复权限后再次通过 |
| R04 | 通用 ResourceStore 用独立合成类型和专用校验器可发布带执行权限的文件；未执行该文件，也不是完整安装器 |
| R05 | 同宿主两个并发 publish 最终同一 resourceId，一次 materialize、一条资源记录；不等同跨进程竞争已验证 |
| R06 | 新版本 materialize 注入 ENOSPC 后为 recovery-required，旧 ready 内容与字节保持；不是实际耗尽磁盘或在用升级 |
| R07 | rename 后故障注入改字节，最终 verify 拒绝就绪；没有覆盖损坏现场 |
| R08 | 既有 resourceId 不能指向另一内容／路径，原身份保留 |

回调观测表明本路径 materialize／verify 均未在 SQLite 写事务内执行。源码另显示最终 verify 在 C 资源协调锁内同步执行；不能据此声称 SQLite 事务包含整文件散列，也不能忽视几百 MiB 同步校验对宿主事件循环和资源锁的影响。本批没有大文件耗时测量，性能是明确待验项。

失败的 C／D 候选保留 recovery-required 数据与文件作为证据，不强制清空或重标 ready。旧版本仅证明仍可读取，没有实际 run 占用、默认选择指针切换、回退、GC 或死亡安装宿主恢复。

## 对照参考

SmartDD Office／LibreOffice 是构建期准备固定引擎：锁定来源／大小／摘要、离线缓存、随后随包交付；不是应用运行时已有的通用下载服务。不能把构建脚本替换输出目录的做法直接套到在用 Agent 资源。

T3 CodexInstallation 的源码提供另一参考：流式下载并校验大小和 SHA256、独立临时目录、版本目录、程序 --version 检查及独立 active.json 激活。包完整性还检查 codex、codex-code-mode-host 和 rg，表明运行资源不能只记录主程序一个文件。这里是源代码审阅，没有运行 T3 安装器，不推定其与 WillYou 的资源／业务租约合同一致。

## 设计决策与未决项

新增原生资源合同，SDK JS 仍由应用依赖锁固定；清单包括 driver／平台架构／SDK／native／适配器组合、包来源摘要、解包文件清单及模式、入口与必要辅助程序。受管目录按不可变内容区分版本；下载／展开／大文件校验在宿主业务锁和 SQLite 写事务外准备，最终归属及就绪发布继续核验，不能为了性能删除晚变更防护。

新的流式准备和短发布方案尚未实际验证；直接把异步 Promise 塞入当前同步 materialize／verify 合同是错误接入。最终可放到独立安装 worker，但跨进程归属、取消、失联、租约和激活必须接回已有资源状态，不靠 UI 是否仍打开判断安装成败。

完整原生清单 Schema、分发方式、安装／激活事务、在用升级与退回、下载中断／损坏／离线、真实磁盘故障、大文件校验与各平台安装仍有缺口。随包和按需资源应汇合到相同的解析／校验／租用接口，自定义程序单独记录身份，不因路径失效自动改走 PATH 或受管默认项。

## 证据

[结果](result.json)、[当前源码与基线](source-review.json)、[哈希清单](archive-manifest.json)、[完整驱动与 SQLite](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性与外键通过；{len(build['sources'])} 个构建输入校验。没有网络、原生程序执行或真实模型调用。

复跑在新临时目录恢复源码及依赖基线，调整绝对路径后执行 build.mjs、probe.mjs；保留本轮临时数据库用于复核，勿将故障注入应用到用户资源库。小型合成资源不能证明真实几百 MiB 包或平台签名行为。
''')
section='''### 12.1 Agent 原生资源与业务桥运行资源分开管理

[实际资源边界验证](实验/20261114_运行资源安装复用边界验证/README.md)明确：现有 RuntimeRegistry 是 .cjs 业务桥合同，单文件 64 MiB／总量 256 MiB，拒绝可执行权限；本机 Claude／Codex native 均超过单文件限制。不得通过统一提高旧预算或放开执行位将其改造成万能安装器，以免改变现有 Skill／MCP 和业务桥的安全／兼容语义。

新增独立 Agent 原生资源清单，复用 ResourceStore 的归属、不可变身份及发布／恢复原则。新资源种类必须同时进入计划、租约成员、GC／恢复、诊断和卸载路径；仅能 publish 一个新 kind 不算接入完成。SDK JS 包继续随应用依赖锁固定，native 可以来自受管平台包、预置资源或明确的外部路径，来源与凭据配置分离。

清单固定 driver、平台／架构、native／SDK／adapter 兼容组合、来源包摘要、解包文件／权限清单和启动入口；把必要辅助程序及库纳入闭包。T3 Codex 安装源码同时核验主程序、code-mode-host 和 rg，不能只管理 codex 一个文件。完整平台包与签名规则按最终版本验证，不能把某版目录结构当永久合同。

| 生命周期 | 设计约束 |
| --- | --- |
| 准备 | 流式取得并验证固定包；独立临时目录和操作 ID，大小／摘要／平台不符拒绝，半成品不能作为可启动资源；缓存命中仍核验 |
| 发布 | 内容版本使用新目录；发布前后核验原归属及目标，最终只有完整验证资源可 ready；不覆盖已有在用目录 |
| 激活 | 新版本 ready 与“新任务默认选它”是不同事实；默认指针单独原子切换，旧 run 及恢复记录仍关联其原内容版本 |
| 使用／升级 | 运行准备和真实 run 租用确切资源及成员；升级不替换该路径，取消／进程未知不提前释放；已接受任务不能因默认版本变化静默换程序 |
| 回退／删除 | 回退显式选择仍兼容的旧版本；删除核对历史、准备、run、安装等全部占用。外部用户程序不纳入受管删除权 |
| 失败／离线 | 缺资源时明确待安装；离线可用仅限完整兼容缓存。失败保留原可用版本与恢复事实，不自动换 PATH、账号或模型 |

ResourceStore 当前的 materialize／verify 是同步合同，最终 verify 仍持有 C 协调锁；实测回调在 SQLite 事务外，但直接哈希数百 MiB 仍可能阻塞宿主和其他资源操作。大文件下载／展开／校验需异步准备或独立安装 worker，最终短核验与不可变发布仍保留晚变更防护；不可直接返回 Promise 给现有同步回调，也不可仅凭旧 hash 跳过目标核验。此流式接入与性能方案尚待验证。

当前已证实旧桥合同不可直接复用、通用发布可保留独立类型、同宿主并发归并、注入磁盘失败保持旧内容、发布晚变更被拒绝。未证明跨进程安装、真实磁盘耗尽、默认激活、在用升级／回退、下载中断或目标平台安装。SmartDD Office 的构建期锁定缓存与 T3 的运行时受管下载仅提供不同层的参考；正式分发选择应在这些验证后定稿，不以本批小文件结果宣布安装生命周期完成。

'''
def tech(t):
 assert '### 12.1 'not in t;t=t.replace('## 13. 开发顺序与验证门槛',section+'## 13. 开发顺序与验证门槛');return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.49 运行资源安装的实际复用边界

[边界实验](实验/20261114_运行资源安装复用边界验证/README.md)运行未修改的 RuntimeRegistry／ResourceStore，R01–R08 证明业务桥的 .cjs／64 MiB／非可执行合同不适合实际 Claude、Codex native，通用底层可承接独立校验类型；同宿主并发保持一个内容身份，注入 ENOSPC 保持旧版本，rename 后字节变化及身份替换被拒绝。同步回调均不在 SQLite 事务内，最终 verify 持有 C 协调锁，不能忽略大资源性能但本轮没有测量。

T3 流式下载、完整辅助程序校验、版本目录与 active.json，以及 SmartDD 构建期引擎锁／缓存仅做源码对照。T0.1 §12.1 明确桥合同保持、新 native 清单独立及准备／发布／激活／租用职责。没有真实下载、执行 native、在用升级、GC、真实磁盘耗尽或安装包验证；失败候选保留 recovery-required。Q01／03／46／48／51／52／53／54 不因本批通过自动关闭。

'''
def account(t):
 assert '### 4.49 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q01','Q03','Q46','Q48','Q51','Q52','Q53','Q54']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.49 验证现有桥资源合同与原生包边界、实际发布／故障保留，完整安装生命周期仍待证 |';t='\n'.join(lines)+'\n'
 t=t.replace('安装策略与精确资源来源、并发发布、损坏／磁盘不足／离线／在用升级／回退。','安装策略与精确资源来源、跨进程发布、损坏／磁盘不足／离线／在用升级／回退。§4.49 已核验现有桥合同限制及实际小文件发布／故障保留，新的流式原生资源准备与激活仍待联合。')
 return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已验证现有业务桥 RuntimeRegistry 不能直接安装几百 MiB 的 Agent 原生程序；[技术方案 §12.1](技研/技术方案.md)明确独立原生资源合同，并复用底层发布／归属机制。实际小文件发布、同宿主并发及故障保留已有证据，完整安装生命周期尚未通过。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续补原生资源流式准备／激活、完整通用协议和跨宿主输入／结果对账；业务联合、平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(build['sources'])}))
