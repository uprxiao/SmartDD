import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {createServer} from 'node:http';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,copyFileSync} from 'node:fs';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {nativeRuntime} from './native-inputs.mjs';
import {reply} from './model.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),driver=process.argv[2]??'claude',records=[],frames=[],requests=[];
for(const f of ['probe.mjs','model.mjs','native-inputs.mjs'])copyFileSync(root+'/'+f,out+'/'+f);
const save=(n,v)=>writeFileSync(out+'/'+n,JSON.stringify(v,null,2)+'\n');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});promise.catch(()=>{});return{promise,resolve,reject};};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,r)=>timer=setTimeout(()=>r(Error('WATCHDOG:'+label)),45000))]).finally(()=>clearTimeout(timer));};
const home=out+'/home',cwd=out+'/workspace',state=home+(driver==='claude'?'/.claude':'/.codex');for(const p of [home,cwd,state])mkdirSync(p,{recursive:true});
let base,error,serverError,parentRequests=0,childRequests=0,childId,rootThread;
function env(){return{HOME:home,PATH:'/usr/bin:/bin',TMPDIR:out,LANG:'en_US.UTF-8',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1',CLAUDE_CONFIG_DIR:state,CODEX_HOME:state,CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1',ENABLE_TOOL_SEARCH:'false',ANTHROPIC_BASE_URL:base+'/claude',ANTHROPIC_AUTH_TOKEN:'synthetic-only',ANTHROPIC_API_KEY:'synthetic-only',WY_MODEL_KEY:'synthetic-only'};}
function owned(command,args){const child=spawn(command,args,{cwd,env:env(),stdio:['pipe','pipe','pipe']}),r={pid:child.pid,command,args,exit:null};records.push({child,r});child.stdin.on('error',()=>{});child.stdout.on('data',b=>appendFileSync(out+'/stdout.jsonl',b));child.stderr.on('data',b=>appendFileSync(out+'/stderr.log',b));const done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>{r.exit={code,signal};resolve(r);});});return{child,r,done};}
function frame(m){frames.push(m);appendFileSync(out+'/frames.jsonl',JSON.stringify(m)+'\n');}
const childDone=deferred();
const server=createServer(async(req,res)=>{try{let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),messages=driver==='claude'?body.messages:body.input,text=JSON.stringify(messages),isChild=text.includes('NATIVE_CHILD_INPUT')&&!text.includes('NATIVE_PARENT_INPUT');
 requests.push({path:req.url,isChild,body});appendFileSync(out+'/requests.jsonl',JSON.stringify(requests.at(-1))+'\n');assert(requests.length<15,'EXTRA_REQUESTS');
 const tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]);
 if(isChild){childRequests++;reply(res,driver,body,{text:'NATIVE_CHILD_RESULT'});childDone.resolve();return;}
 parentRequests++;
 if(parentRequests===1){const tool=tools.find(t=>t.name===(driver==='claude'?'Agent':'spawn_agent'));save('offered-tools.json',tools);assert(tool,'NATIVE_CHILD_TOOL_MISSING');reply(res,driver,body,{tool,args:driver==='claude'?{description:'Isolated native child',prompt:'NATIVE_CHILD_INPUT',subagent_type:'m14-child'}:{message:'NATIVE_CHILD_INPUT'}});return;}
 if(driver==='codex'&&parentRequests===2){const outputs=(body.input??[]).filter(x=>x.type==='function_call_output');for(const o of outputs){try{const p=JSON.parse(typeof o.output==='string'?o.output:JSON.stringify(o.output));if(p.agent_id)childId=p.agent_id;}catch{}}assert(childId,'CHILD_ID_MISSING');await deadline(childDone.promise,'child response');const tool=tools.find(t=>t.name==='wait_agent');assert(tool,'WAIT_TOOL_MISSING');reply(res,driver,body,{tool,args:{targets:[childId],timeout_ms:10000}});return;}
 if(driver==='claude'&&!text.includes('NATIVE_CHILD_RESULT')){reply(res,driver,body,{text:'NATIVE_PARENT_WAITING'});return;}
 assert(text.includes('NATIVE_CHILD_RESULT'),'PARENT_DID_NOT_RECEIVE_CHILD_RESULT');reply(res,driver,body,{text:'NATIVE_PARENT_RESULT'});
 }catch(e){serverError??=e.stack;res.writeHead(500);res.end('{}');}});
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
 if(driver==='claude'){
  let p;const q=query({prompt:'NATIVE_PARENT_INPUT',options:{pathToClaudeCodeExecutable:nativeRuntime(driver).path,cwd,model:'claude-haiku-4-5',settingSources:[],env:env(),strictMcpConfig:true,mcpServers:{},tools:['Agent'],allowedTools:['Agent'],agents:{'m14-child':{description:'Controlled local research child',prompt:'Return the requested marker.',tools:[],model:'inherit'}},spawnClaudeCodeProcess:o=>{p=owned(o.command,o.args);return p.child;}}});
  try{await deadline((async()=>{for await(const m of q)frame(m);})(),'claude native child');}finally{q.close();if(p)await deadline(p.done,'claude exit');}
  const result=frames.findLast(x=>x.type==='result');assert(result&&!result.is_error,'CLAUDE_RESULT_FAILED');assert(frames.some(x=>x.parent_tool_use_id),'CHILD_CORRELATION_MISSING');assert(frames.some(x=>x.subtype==='task_notification'&&x.status==='completed'&&x.summary.includes('NATIVE_CHILD_RESULT')),'CHILD_NOTIFICATION_MISSING');assert(frames.some(x=>x.type==='assistant'&&!x.parent_tool_use_id&&JSON.stringify(x.message).includes('NATIVE_PARENT_RESULT')),'PARENT_FINAL_MISSING');
 }else{
  const p=owned(nativeRuntime(driver).path,['app-server','--enable','multi_agent','--disable','plugins','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(base+'/codex/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}']),waiting=new Map(),done=deferred();let seq=0;
  const rpc=(method,params)=>{const id=++seq,d=deferred();waiting.set(id,d);p.child.stdin.write(JSON.stringify({id,method,params})+'\n');return deadline(d.promise,method);};
  createInterface({input:p.child.stdout}).on('line',line=>{try{const m=JSON.parse(line);frame(m);if(m.id!==undefined&&!m.method){const d=waiting.get(m.id);waiting.delete(m.id);m.error?d?.reject(Error(JSON.stringify(m.error))):d?.resolve(m.result);}if(m.method==='turn/completed'&&m.params.threadId===rootThread)done.resolve(m.params.turn);if(m.id!==undefined&&m.method)p.child.stdin.write(JSON.stringify({id:m.id,error:{code:-32601,message:'Unexpected request'}})+'\n');}catch(e){done.reject(e);}});
  try{await rpc('initialize',{clientInfo:{name:'m14_native_child',version:'1'},capabilities:{experimentalApi:true}});p.child.stdin.write('{"method":"initialized"}\n');const r=await rpc('thread/start',{cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'never',sandbox:'danger-full-access'});rootThread=r.thread.id;await rpc('turn/start',{threadId:rootThread,input:[{type:'text',text:'NATIVE_PARENT_INPUT',text_elements:[]}]});assert.equal((await deadline(done.promise,'codex child turn')).status,'completed');}finally{p.child.stdin.end();await deadline(p.done,'codex exit');}
  assert(childId&&childId!==rootThread,'DISTINCT_CHILD_THREAD_MISSING');
 }
 if(serverError)throw Error(serverError);assert.equal(childRequests,1);assert(parentRequests>=2);assert(records.every(x=>x.r.exit?.code===0));
}catch(e){error=e.stack;process.exitCode=1;}finally{for(const p of records)if(!p.r.exit){p.child.kill('SIGTERM');await deadline(new Promise(r=>p.child.once('close',r)),'cleanup');}server.closeAllConnections();await new Promise(r=>server.close(r));}
const result={out,driver,passed:!error,error:error??null,serverError:serverError??null,parentRequests,childRequests,rootThread,childId,processes:records.map(x=>x.r),scope:'Fixed-version native child with controlled loopback model. No host delegation, product UI, permission enforcement or crash/stop guarantees.'};save('result.json',result);writeFileSync(root+'/latest-'+driver+'.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
