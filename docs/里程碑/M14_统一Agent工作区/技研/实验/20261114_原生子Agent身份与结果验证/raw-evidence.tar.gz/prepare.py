from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections
root=Path(__file__).resolve().parent; repo=Path('/Users/hx/projects/SmartDD'); t3=Path('/Users/hx/projects/t3code'); base=Path('docs/里程碑/M14_统一Agent工作区'); exp=base/'技研/实验/20261114_原生子Agent身份与结果验证';stage=root/'publication';entries=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
def frames(p):return [json.loads(l)for l in (p/'frames.jsonl').read_text().splitlines()]
c=json.loads((root/'latest-claude.json').read_text());x=json.loads((root/'latest-codex.json').read_text());assert c['passed'] and x['passed']
cf=frames(Path(c['out']));xf=frames(Path(x['out']));started=next(m for m in cf if m.get('subtype')=='task_started');notice=next(m for m in cf if m.get('subtype')=='task_notification');child=next(m for m in cf if m.get('parent_tool_use_id'))
assert started['task_id']==notice['task_id']==child['agent_id'];assert started['run_id']==notice['run_id'];assert started['tool_use_id']==notice['tool_use_id']==child['parent_tool_use_id'];assert started['session_id']==notice['session_id']==child['session_id'];assert notice['status']=='completed';assert [m for m in cf if m.get('subtype')=='background_tasks_changed'][-1]['tasks']==[]
spawn=next(m['params']['item'] for m in xf if m.get('method')=='item/completed' and m['params']['item'].get('tool')=='spawnAgent');wait=next(m['params']['item'] for m in xf if m.get('method')=='item/completed' and m['params']['item'].get('tool')=='wait');assert spawn['senderThreadId']==x['rootThread'];assert spawn['receiverThreadIds']==[x['childId']];assert wait['agentsStates'][x['childId']]['status']=='completed';assert wait['agentsStates'][x['childId']]['message']=='NATIVE_CHILD_RESULT'
done=[m['params']for m in xf if m.get('method')=='turn/completed'];assert {m['threadId']for m in done}=={x['rootThread'],x['childId']};assert all(m['turn']['status']=='completed'for m in done);assert len({m['turn']['rootTurnId']for m in done})==1
for r in [c,x]:
 reqs=[json.loads(l)for l in (Path(r['out'])/'requests.jsonl').read_text().splitlines()];assert len(reqs)==4;assert len({m['body']['model']for m in reqs})==1;assert all(p['exit']['code']==0 for p in r['processes'])
attempts=[]
for p in sorted(root.glob('attempt-*')):
 r=json.loads((p/'result.json').read_text());assert all(v['exit']is not None for v in r['processes']);attempts.append({'attempt':p.name,'driver':r['driver'],'passed':r['passed'],'error':r['error'],'requests':r['parentRequests']+r['childRequests'],'exits':[v['exit']for v in r['processes']]})
refs=[t3/'apps/server/src/orchestration-v2/Adapters'/n for n in ['CodexAdapterV2.ts','ClaudeAdapterV2.ts']]+[Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts'),Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'files':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'t3Evidence':'CodexAdapterV2 provider_native task projection near line 3201; ClaudeAdapterV2 provider_native projection near line 7467. Both have childThreadId. Source review only: this probe does not execute T3 adapters.','runtimeVersions':{'ClaudeSDK':'0.3.321','ClaudeNative':'2.1.321','CodexNative':'0.167.1'},'binaryHashes':'Pinned and checked by native-inputs.mjs before every spawn.'}
result={'checksPassed':2,'claude':c,'codex':x,'attempts':attempts,'paidModelCalls':0,'productChanges':0,'validated':'Native child creation, identity correlation, inherited model on selected localhost endpoint, result delivered to parent, native process exit.','notValidated':'Native cancellation, recursive stop, permission inheritance, child business MCP, crash/restart, full T3/WillYou adapters, UI, other versions/providers.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2));(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
files=[root/n for n in ['probe.mjs','model.mjs','native-inputs.mjs','prepare.py','result.json','source-review.json']]
for p in sorted(root.glob('attempt-*')):files+=sorted(f for f in p.iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files]}
for n,v in [('result.json',result),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 原生子 Agent 身份与结果：独立技术验证

依据需求 R0.2 的 R05／R06／R11／R12、验证账 Q29。固定 macOS arm64 原生版本：Claude SDK 0.3.321／Claude 2.1.321、Codex 0.167.1。两条正常路径通过；模型仅本机受控 SSE 响应，隔离 HOME、工作目录与合成凭据，零付费模型请求。不是实际模型自主规划质量测试。

| 执行器 | 已观察并断言 |
| --- | --- |
| Claude | 真实 Agent 调用自定义 m14-child；实际异步启动。task_started 的 task_id／run_id／tool_use_id 与子 assistant 的 agent_id／parent_tool_use_id、最终 task_notification 关联。父子共享 native session_id；完成通知进入后续父模型请求，父输出最终标记；后台集合最终为空，原生进程 exit 0 |
| Codex | 真实 spawn_agent 创建不同 native child thread；collabAgentToolCall 保留 sender／receiver，wait_agent 收到真实子结果；父子 turn/completed 具有共同 rootTurnId，分别 completed；原生 app-server exit 0 |

成功批每端四次本机模型请求，父三次／子一次；各自父子请求 model 一致。仅验证此处继承路径，不泛化为跨账号、子模型 override 或 DeepSeek 服务兼容。没有建立 WillYou run、调用宿主委派接口或修改业务数据库。

T3 源码确实把两端原生子任务投影为带 childThreadId 的任务节点，origin 明确为 provider_native。不要误写成“原生子任务不能出现在宿主任务树”；也不能因有宿主投影 ID 就授予它独立宿主 run、跨 Provider 迁移或新的业务凭据。这部分是源码核对，未在本轮运行完整 T3。

失败记录完整保留：最初两端本机监听被环境 EPERM 拒绝，未启动原生进程；取得执行权限后，Claude 驱动误认为下一次父请求立即包含子结果，导致模拟服务 500／重试，watchdog 结束探针、捕获进程退出 143；子任务本身曾 completed。修正为接纳先返回等待消息、随后接收通知。Codex 驱动误用旧 wait 工具名，父回合 failed、子已执行、进程 exit 0；按实际 tools Schema 改为 wait_agent(targets)，成功。model 工具名 wait_agent 对应协议 item.tool 为 wait，不能直接混用。

范围限制：未验单 Agent 禁用强度、原生权限继承、子任务业务 MCP、递归停止、宿主退出／恢复、跨 Provider 改绑、最终 UI 或其他平台／版本。普通成功退出也不等于已证明任意子后代均能强制停止。Q29 从待验推进为部分。

复跑：在具有 localhost 监听权限的环境中分别执行 `node probe.mjs claude`、`node probe.mjs codex`；使用 native-inputs 中指定并校验的隔离依赖。`python3 prepare.py` 对原始帧做关联断言并生成归档，不写产品源码。原生运行参数、请求、帧、失败和成功脚本快照见原始证据。

[结果](result.json) · [源码基线](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
section='''### 7.4 原生子 Agent 的展示与执行权限分离

[固定版本两端实跑](实验/20261114_原生子Agent身份与结果验证/README.md)验证了原生子任务创建、身份关联、结果回到父 Agent，以及正常进程退出。Claude 实际异步启动，task_id／run_id／tool_use_id 关联子帧与完成通知，父子共用 session_id；Codex 子任务有不同 native threadId，父子 turn 的 rootTurnId 关联。字段必须保留原生命名空间，不能直接把任一个 ID 当 WillYou 的 taskId 或 runId。

T3 的 ClaudeAdapterV2 与 CodexAdapterV2 均将原生子任务投影为 origin=provider_native 的任务节点，并可分配 childThreadId。WillYou 可借鉴这个统一展示方式：活动树同时容纳原生子任务与宿主委派，明确来源、所属 binding／execution scope、原生身份和已验证控制能力。拥有展示节点／历史投影不等于拥有独立业务 run；本期不因收到 task_started／child thread 通知就另发 WillYou 凭据、占用另一写者或启动第二份执行器。

单 Agent 模式关闭宿主委派入口，原生子任务按独立能力策略展示和控制；如果产品声明“禁止任何子 Agent”，还必须验证各适配器实际禁用能力，不能仅隐藏委派按钮或写提示词。需要跨 Provider／目标配置组合、独立任务授权和工作目录协调时仍由宿主委派建立子任务。原生子任务的继续输入、停止、递归取消和恢复必须按版本声明，未知能力不能从父运行能力推导。

本轮发现模型工具名与协议事件值可能不同：Codex 提供 wait_agent(targets)，事件中的 item.tool 仍是 wait；Claude 完成结果经异步通知进入后续父请求。适配层按真实版本合同转换，UI 不依赖模型工具字符串。正常结果与退出已验证；权限继承、在途业务、强制／递归停止和崩溃恢复继续待证，本节不构成全版本或完整协作闭环声明。

'''
edit(base/'技研/技术方案.md',lambda t:t.replace('## 8. Git／SVN 与工作目录协调',section+'## 8. Git／SVN 与工作目录协调'))
def ledger(t):
 assert '### 4.78 'not in t
 t=re.sub(r'^\| Q29 \|.*$', '| Q29 | 原生子 Agent 与宿主委派的可控范围不会混淆 | E05／07；T3 对照 | **部分**：§4.78 两端真实 Agent／spawn_agent 创建、身份关联、结果返回及正常进程退出通过；T3 明确 provider_native 投影。原生权限、禁用、子业务、递归停止和崩溃恢复仍待验 |',t,flags=re.M)
 t=t.replace('## 5. 失败与驱动修正','''### 4.78 原生子 Agent 身份与结果

[两端正常路径](实验/20261114_原生子Agent身份与结果验证/README.md)通过。Claude 真实 Agent 异步创建子任务，task／run／tool use 关联子帧及通知，父续聊获得子结果；Codex spawn_agent 创建不同原生线程，wait_agent 获取子结果，父子 rootTurnId 对应。成功批每端四次本机模型请求，两个原生进程 exit 0。T3 源码将二者投影为 provider_native，展示子节点不等于独立宿主委派／run 授权。

保留两次监听 EPERM，以及 Claude 误判同步结果导致本机 500／重试、Codex 旧 wait 工具名造成失败的原始记录；修正研究驱动后通过，产品未改。仅受控模型和固定版本，未验原生权限继承、禁用、业务 MCP、递归停止和崩溃恢复；Q29 推进为部分，技术方案 §7.4 收口展示与控制边界。

## 5. 失败与驱动修正''')
 t=t.replace('截至 §4.77，56 个宽口径问题项中，45 项有部分实验／限定证据，8 项主要内容仍待验证或产品集成','截至 §4.78，56 个宽口径问题项中，46 项有部分实验／限定证据，7 项主要内容仍待验证或产品集成').replace('八项为 Q12、Q26、Q29、Q33、Q42、Q51、Q52、Q56','七项为 Q12、Q26、Q33、Q42、Q51、Q52、Q56').replace('不是只剩八项','不是只剩七项').replace('用 45／56 作为研究完成率','用 46／56 作为研究完成率')
 groups=collections.Counter()
 for l in t.splitlines():
  if re.match(r'^\| Q\d\d \|',l):
   a=l.split('|');q=a[1].strip();s=a[4].strip();groups['deferred'if q in ['Q21','Q22']else'optional'if q=='Q36'else'partial'if s.startswith(('**部分','**实证限定','**发现问题并验证候选修正'))else'pending']+=1
 assert groups=={'partial':46,'pending':7,'deferred':2,'optional':1}
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：两端原生子 Agent 身份与结果路径已实跑，Q29 推进为部分；T3 的 provider_native 任务投影已核对，见[技术方案 §7.4](技研/技术方案.md)。全局数量与边界以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准，尚未整项关闭。',t)
 return re.sub(r'下一步：[^\n]*','下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的研究／产品条件分离，优先原生权限与子任务停止边界；不将正常结果路径当作完整协作、权限隔离或产品通过。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'stagedFiles':len(entries),'normalPathsPassed':2,'archiveFiles':len(files),'attempts':len(attempts)}))
