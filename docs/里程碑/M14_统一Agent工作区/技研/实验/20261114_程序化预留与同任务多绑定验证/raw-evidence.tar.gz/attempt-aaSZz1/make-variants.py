from pathlib import Path
r=Path('/Users/hx/projects/SmartDD/src/main/core/applications');d=Path(__file__).resolve().parent
p=r/'session-registry.ts';t=p.read_text();prefix="import {inspectProgrammatic as readProgrammatic,publishProgrammatic,refs as programmaticRefs} from '"+str(d)+"/programmatic.mjs';\nexport interface ProgrammaticScope {taskId:string;bindingId:string;capabilitySessionId:string;snapshotHash:string}\n"
a='  async verifyResources(taskId: string): Promise<void> {';b='  async addProjectionReference';start=t.index(a);end=t.index(b,start);verify=t[start:end]
newverify=verify.replace('async verifyResources(taskId: string)', 'async verifyProgrammaticResources(scope:ProgrammaticScope)').replace('await this.get(taskId)','await this.getProgrammatic(scope)').replace('await this.references(taskId)',"programmaticRefs(this.store,scope).map(r=>({refId:r.ref_id,refKind:r.ref_kind,refHash:r.ref_hash,relativePath:r.relative_path}))")
methods="""
  inspectProgrammatic(scope:ProgrammaticScope):StoredCapabilitySession{return readProgrammatic(this.store,scope,(s:CapabilitySessionSnapshot)=>this.expectedSources(s));}
  async getProgrammatic(scope:ProgrammaticScope):Promise<StoredCapabilitySession>{return withResourceLock(this.store.root,()=>this.inspectProgrammatic(scope));}
  async createProgrammatic(bindingId:string,snapshot:CapabilitySessionSnapshot,home:string):Promise<ProgrammaticScope>{
    const value=capabilitySessionSnapshotSchema.parse(snapshot);this.deps.assertInitialSelection(value);this.validatePackages(value);
    if(canonicalFuturePath(value.native.stateRoot)!==value.native.stateRoot||canonicalFuturePath(value.native.cwd)!==value.native.cwd||canonicalFuturePath(home)!==home)throw new ApplicationError('INVALID_INPUT','程序化来源路径未规范化');
    const resources=this.sourceReferences(value);
    return withResourceLock(this.store.root,()=>this.store.sqlite.transaction(()=>{this.deps.assertInitialSelection(value);const scope=publishProgrammatic(this.store,bindingId,value,home,this.sourceReferences(value));this.inspectProgrammatic(scope);return scope;}).immediate());
  }
"""
t=prefix+t[:start]+methods+newverify+t[start:];(d/'session-registry.ts.variant').write_text(t)
p=r/'run-registry.ts';t=p.read_text();t="import {programmaticScopeSchema,refs as programmaticRefs} from '"+str(d)+"/programmatic.mjs';\nimport type {ProgrammaticScope} from './session-registry';\n"+t
t=t.replace('export interface RunRow {','export interface RunRow { execution_mode?:string;binding_id?:string;capability_session_id?:string;source_snapshot_hash?:string;generation?:number;')
t=t.replace('interface OwnedRun {','interface OwnedRun { programmatic?:ProgrammaticScope & {generation:number};')
t=t.replace('const TERMINAL =',"const scopeOf=(row:RunRow):ProgrammaticScope=>({taskId:row.task_id,bindingId:row.binding_id!,capabilitySessionId:row.capability_session_id!,snapshotHash:row.snapshot_hash});\nconst TERMINAL =")
old='    const session = this.sessions.inspectCoordinated(row.task_id);'
new="    if(owned.programmatic&&(row.execution_mode!=='programmatic'||row.binding_id!==owned.programmatic.bindingId||row.capability_session_id!==owned.programmatic.capabilitySessionId||row.generation!==owned.programmatic.generation||row.source_snapshot_hash!==owned.programmatic.snapshotHash))throw new ApplicationError('SCOPE_DENIED','运行与宿主签发的绑定代次不同');\n    const session = owned.programmatic?this.sessions.inspectProgrammatic(scopeOf(row)):this.sessions.inspectCoordinated(row.task_id);"
assert t.count(old)==1;t=t.replace(old,new)
t=t.replace('private closure(taskId: string,guard?:NativeGuard)', 'private closure(taskId: string,guard?:NativeGuard,scope?:ProgrammaticScope)')
t=t.replace(":this.store.sqlite.prepare('SELECT ref_id,ref_hash,ref_kind,relative_path FROM capability_session_refs", ":scope?programmaticRefs(this.store,scope):this.store.sqlite.prepare('SELECT ref_id,ref_hash,ref_kind,relative_path FROM capability_session_refs")
t=t.replace('this.closure(row.task_id,owned.guard)', 'this.closure(row.task_id,owned.guard,owned.programmatic?scopeOf(row):undefined)')
a='  private async reserveManaged(input: z.infer<typeof reserveSchema>,reservation?: {runId:string;ptyId:string})'
b="""  async reserveProgrammatic(input:ProgrammaticScope & {bindings:RunBindingRevision[]}):Promise<OwnedCapabilityRun>{
    if(!this.deps.createPlan)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化运行必须提供固定应用计划');
    const {bindings,...scope}=input;const parsed=programmaticScopeSchema.parse(scope);return this.reserveManaged({taskId:parsed.taskId,snapshotHash:parsed.snapshotHash,bindings},undefined,parsed);
  }
  private async reserveManaged(input: z.infer<typeof reserveSchema>,reservation?: {runId:string;ptyId:string},programmatic?:ProgrammaticScope)"""
assert a in t;t=t.replace(a,b)
t=t.replace("let selectionHash = '';","let selectionHash = '',generation=0;",1)
t=t.replace('(await this.sessions.get(value.taskId)).snapshot','(programmatic?await this.sessions.getProgrammatic(programmatic):await this.sessions.get(value.taskId)).snapshot',1)
t=t.replace('const session = this.sessions.inspectCoordinated(value.taskId); selectionHash', 'const session = programmatic?this.sessions.inspectProgrammatic(programmatic):this.sessions.inspectCoordinated(value.taskId); selectionHash',1)
t=t.replace('const resources=this.closure(value.taskId);','const resources=this.closure(value.taskId,undefined,programmatic);',1)
a='      this.store.sqlite.prepare("INSERT INTO capability_runs(run_id,task_id,project_id,runner,state,started_at,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id,revocation_state)'
start=t.index(a);end=t.index('\n',start);old=t[start:end]
branch="""      if(programmatic){
        generation=(this.store.sqlite.prepare("UPDATE m14_binding SET run_generation=run_generation+1 WHERE binding_id=? AND task_id=? AND entry_mode='programmatic' AND phase='prepared' RETURNING run_generation").get(programmatic.bindingId,value.taskId) as {run_generation:number}).run_generation;
        this.store.sqlite.prepare("INSERT INTO capability_runs(run_id,task_id,project_id,runner,state,started_at,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id,revocation_state,execution_mode,binding_id,capability_session_id,source_snapshot_hash,generation) VALUES(?,?,?,?,'preparing',?,?,?,?,?,?,?,'open','programmatic',?,?,?,?)").run(runId,value.taskId,session.snapshot.projectId,session.snapshot.runner,timestamp,value.snapshotHash,this.instanceId,this.host.pid,this.host.startedAt,canonicalJson(value.bindings),ptyId,programmatic.bindingId,programmatic.capabilitySessionId,value.snapshotHash,generation);
      }else {
"""+old+'\n      }';t=t[:start]+branch+t[end:]
t=t.replace('const owned: OwnedRun = { ...(plan?', 'const owned: OwnedRun = { ...(programmatic?{programmatic:{...programmatic,generation}}:{}),...(plan?',1)
t=t.replace("if(guard)await guard.verify();else await this.sessions.verifyResources(taskId);","if(guard)await guard.verify();else if(owned.programmatic)await this.sessions.verifyProgrammaticResources(scopeOf(this.row(runId)));else await this.sessions.verifyResources(taskId);")
# Restrict native-only fallback to unchanged legacy path; programmatic support needs a scoped implementation.
a='  async restrictToNative(';idx=t.find(a)
if idx!=-1:
 body=t.index('\n',idx)+1;t=t[:body]+"    if(this.owner(runId).owned.programmatic)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化运行不支持旧原生守护回退');\n"+t[body:]
(d/'run-registry.ts.variant').write_text(t)
p=r/'run-plan.ts';t=p.read_text();old="  const row=store.sqlite.prepare('SELECT snapshot_json FROM capability_snapshot_versions WHERE task_id=? AND snapshot_hash=?').get(snapshot.taskId,plan.snapshotHash) as {snapshot_json:string}|undefined;"
new="""  const run=store.sqlite.prepare('SELECT execution_mode,binding_id,capability_session_id FROM capability_runs WHERE run_id=?').get(plan.runId) as {execution_mode:string;binding_id:string;capability_session_id:string}|undefined;
  const row=(run?.execution_mode==='programmatic'?store.sqlite.prepare('SELECT snapshot_json FROM m14_revision WHERE task_id=? AND binding_id=? AND cap_id=? AND snapshot_hash=?').get(snapshot.taskId,run.binding_id,run.capability_session_id,plan.snapshotHash):store.sqlite.prepare('SELECT snapshot_json FROM capability_snapshot_versions WHERE task_id=? AND snapshot_hash=?').get(snapshot.taskId,plan.snapshotHash)) as {snapshot_json:string}|undefined;"""
assert old in t;t=t.replace(old,new);(d/'run-plan.ts.variant').write_text(t)
