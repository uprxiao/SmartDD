from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_程序化预留与同任务多绑定验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==14 and not result.get('error');attempt=Path(result['out']);assert json.loads((attempt/'result.json').read_text())==result
build=json.loads((root/'build.json').read_text());sources=build['sources']
for s in sources:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
for o in build['outputs']:
 assert sha(Path(o['file']).read_bytes())==o['sha256'];assert sha((attempt/Path(o['file']).name).read_bytes())==o['sha256']
 for p in o['patches']:
  assert sha(Path(p['path']).read_bytes())==p['beforeHash'];assert sha((root/(Path(p['path']).name+'.variant')).read_bytes())==p['afterHash']
for n in ['probe.mjs','fixture.mjs','programmatic.mjs','make-variants.py','build.json']:assert (root/n).read_bytes()==(attempt/n).read_bytes(),n
refs=[(repo,'src/main/core/applications/session-registry.ts'),(repo,'src/main/core/applications/run-registry.ts'),(repo,'src/main/core/applications/run-plan.ts'),(repo,'src/main/core/applications/current-authorization.ts'),(repo,'src/main/core/applications/tool-service.ts'),(t3,'apps/server/src/persistence/Migrations/OrchestrationV2/ProviderSessionBindings.ts'),(t3,'apps/server/src/orchestration-v2/ProjectionStore.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,p in refs],'variants':build['outputs'][1]['patches'],'scope':'Isolated session/run/source variants with actual validators, run transaction, ownership, R17 and tool service. Synthetic adapters, process identities and read handler; no OS Agent, SDK, model turn, full execution plan, IPC or product modification. T3 references prove explicit thread/session association only.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2))]:put(exp/n,data)
put(exp/'README.md',f'''# 程序化预留与同任务多绑定：隔离技术验证

日期：2026-11-14。对应 R02／03／08，Q13／14；技术方案 §3.2.13，验证账 §4.44。仅技术研究，不修改产品或共享原型，也不执行产品验收。

## 问题与结论

前批使用旧 reserve，再由夹具补 run 的 binding／capability／generation 字段，不能据此证明新任务无需旧单会话数据即可启动准备。本批以实际源码的隔离变体新增按精确 scope 创建、读取、校验和预留的入口：新逻辑任务只创建新能力修订／引用，不填旧 snapshot／identity／refs／version 表；run 的关联、代次、固定 v1 应用计划和原有进程／资源租约在同一预留事务插入。

同一逻辑任务保留 Claude／Codex 两绑定；A→B→A 的 run 各有独立 runId，绑定内代次为 1→2。保留既有 task 级未结束运行互斥：竞争预留只有一个成功。多绑定用于串行切换；多 Agent 并行仍通过独立子任务，不放宽同任务运行互斥。

## 实际结果

最终 `{attempt.name}` 的 P01–P14 通过。真实组件包括 SQLite、能力 Schema／包与字节校验、旧注册器预留与 owner 逻辑、v1 计划读写、CurrentApplicationAuthorization 和 ApplicationToolService；新 scope 接线为临时源码变体。

| 项 | 证据范围 |
| --- | --- |
| P01／P02 | 同 task 双 scope、新任务无旧镜像；A→B→A 读取对应执行器资源、固定来源及代次 |
| P03 | 同一进程的两个异步预留竞争，一个成功，另一个 RESOURCE_BUSY；没有多宿主进程竞争实验 |
| P04 | 实际当前应用授权先拒绝停用应用，启用后两绑定依次调用合成只读 handler；停止的旧 run 仍拒绝 |
| P05／P06 | 混用 task／cap／source 或外传 generation 拒绝；预留末端注入失败，run／plan／lease／process／generation 全回滚 |
| P07 | 候选首次 native ID 关联更新当前修订，原 run 来源和 v1 计划不变，后续 run 使用新来源；ID 是夹具，不是原生回调 |
| P08／P09 | 复制 owner 句柄、篡改 generation、损坏 adapter 字节拒绝；未支持的旧 native-only fallback 明确拒绝 |
| P10 | 原旧会话继续 prepare；旧首次 native 绑定同步候选 cap 当前指针，没有被新路径漏掉 |
| P11／P12 | 改资源引用或 MCP 名称拒绝；hold 禁止使用，但仍允许拥有者取消 |
| P13／P14 | 新入口必须有固定应用计划生成器；与旧 MCP 名称冲突时发布事务回滚 |

保留全部失败及修订记录：`attempt-5pG5Gb` 在 preparing 状态误用 cancelBeforeFork，收尾失败且该项数据库未留存，不补造其现场；`attempt-xnwAqh` 使用无效的合成进程出生身份，改成实际解析器接受的格式；`attempt-2AHTCv` 的 P13 复现新入口缺失必需计划检查，候选补拒绝；`attempt-rkVf3j` 虽通过旧版十四项，但未覆盖旧首次 native 投影；扩展 P10 后 `attempt-aaSZz1` 复现组合变体漏旧投影 hook，恢复既有候选 hook 后最终全批通过。后两项是研究候选缺陷，不是已交付产品缺陷，也不能将早一轮绿测替代扩展后的结果。

## T3 对照与明确限制

T3 的 ProviderSessionBindings 迁移、ProjectionStore attached／detached 投影和 thread 查询显式关联 thread 与 provider session，支持将逻辑任务和原生会话分离的设计方向。该源码不能证明 T3 具有 WillYou 的能力快照、资源租约、业务权限或相同运行互斥规则；本批没有运行或修改 T3。

本批没有启动 OS Agent 进程、SDK／app-server、模型 turn、IPC 或 UI。进程身份为内存夹具，适配资源和业务 handler 为合成数据，不能据此证明真实进程归属、原生恢复或全部业务兼容。未把 §4.43 的两端初始化证据自动推广到本批新 reserve。

尚未闭环的设计问题：发布只接受 planned，提交成功但回包丢失后的幂等查询／接管尚未实现；完整 ExecutionPlan／配置修订／delivery／outbox 与新 reserve 未联合；真实 native ID 回调及 scoped native-only 恢复未完成；完整业务上下文服务、跨宿主竞争、应用迁移器与正式版本升级未覆盖。内部 ptyId 暂仍是启动身份字段，实际无 PTY；拟议 launchId 的最终迁移须显式完成。禁止把隔离候选直接当作产品迁移脚本。

## 证据与复跑

[最终结果](result.json)、[源码依据与变体哈希](source-review.json)、[文件清单](archive-manifest.json)、[所有轮次的驱动／候选／数据库](raw-evidence.tar.gz)。归档 {len(files)} 个文件，{len(dbs)} 份 SQLite 已核完整性／外键，{len(sources)} 个构建输入已核当前哈希。

恢复临时依赖与原源码基线后，依次运行 `python3 make-variants.py`、`node build.mjs`、`node probe.mjs`，每步成功再执行下一步。原始每轮输入已随 attempt 保存；复跑只能使用新的临时目录与数据，不连接用户数据库或修改产品配置。
''')
section='''### 3.2.13 程序化预留必须直接绑定来源，保留任务互斥

[新预留实验](实验/20261114_程序化预留与同任务多绑定验证/README.md)补上前批 legacy reserve 后手工关联的缺口。拟议入口显式接收 taskId／bindingId／capabilitySessionId／snapshotHash，读取该绑定的当前合法能力修订、资源引用及 MCP 命名占用。新任务不为兼容旧按 task 查询而伪造一份旧快照；旧入口继续仅服务旧会话。快照 Schema、包校验、文件完整性与既有实时授权继续复用，范围解析集中在适配边界。

预留在资源协调锁及短数据库事务中复核选择，分配绑定内单调 generation，并一次提交带精确来源的 run、固定 v1 应用计划、owner／进程预留和资源租约。generation 由宿主分配，调用方不得指定；后续私有 owner 校验同一 binding／cap／generation／source，首次原生身份变化仍按 §3.2.9 区分固定启动来源与当前修订。新程序化入口必须提供固定应用计划生成器，不能继承旧入口允许缺计划的可选分支。实际 CurrentApplicationAuthorization 按调用时政策判断，不把固定启动计划当作永久业务授权。

一个逻辑任务允许保留多个 Provider 绑定，任一时刻只允许一个未结束运行；A→B→A 在空闲后使用对应绑定，连续分配各自代次。多 Agent 并发建立独立子任务，不以并发激活同任务两个绑定实现。保留旧首次 native 绑定投影与命名冲突域；新旧入口联合变体曾漏掉旧投影，扩展负对照后已修正，后续组合验证必须包含旧任务首次绑定分支。

本批验证新 source／reserve 与实际 owner、v1 计划及 R17 工具服务的局部接线，未启动原生执行器。发布提交后的 ACK 丢失／幂等恢复、完整配置与 ExecutionPlan／delivery／outbox、真正首次 native 回调及业务桥仍需联合验证；不能把前批初始化结果当作本批新链已通过。暂用旧 ptyId 内部字段的候选不是最终 launchId 迁移，未支持的程序化 native-only 回退须明确拒绝，不能落回按 task 查询的旧路径。

'''
def tech(t):
 assert '### 3.2.13 ' not in t;assert t.count('### 3.3 真实所有权')==1;return t.replace('### 3.3 真实所有权',section+'### 3.3 真实所有权')
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.44 程序化预留与同任务多绑定

[隔离实验](实验/20261114_程序化预留与同任务多绑定验证/README.md)最终 P01–P14 补新任务直接创建 scoped 能力会话、从新修订读取并一次预留 run／固定应用计划／代次／租约／进程身份；不再为新任务填旧单会话镜像或事后补 run 关联。A→B→A、同任务异步预留互斥、错误 scope、事务回滚、资源字节损坏、首次身份来源分离及实际 R17／工具服务的当前授权均取得限定证据。

保存两项驱动错误、新入口缺计划检查的红测，以及组合变体漏旧 native 投影的扩展红测；修复候选后最终复验，没有修改产品。T3 thread／provider session 关联只作为职责分离的源码依据。真实 OS 进程／SDK、完整宿主计划与派发、幂等发布恢复、跨进程竞争及旧版本升级不在本批证据内。T0.1 §3.2.13 固化入口与任务互斥；Q13／Q14 仍为部分，不以数据级 A→B→A 代替对话功能完成。

'''
def account(t):
 assert '### 4.44 ' not in t;assert t.count('## 5. 失败与驱动修正')==1;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q13','Q14']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.44 补新任务 scoped 会话／直接预留、A→B→A 代次及任务互斥，完整原生对话与发布恢复未覆盖 |';t='\n'.join(lines)+'\n'
 old='§4.43 补同一运行计划下两端原生初始化与改配置取消；下一步优先收口';new='§4.43 补同一运行计划下两端原生初始化与改配置取消；§4.44 补新任务 scoped source 与直接 run 预留，尚未与完整派发联合；下一步优先收口';assert old in t;return t.replace(old,new)
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：同一逻辑任务的多 Provider 绑定已在隔离源码变体中直接创建能力来源并预留运行，验证 A→B→A 的身份／资源归属、任务互斥及实际业务授权入口，见[技术方案 §3.2.13](技研/技术方案.md)。本批无原生 Agent 或模型调用；完整启动派发、幂等恢复及实际对话仍未贯通。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources)}))
