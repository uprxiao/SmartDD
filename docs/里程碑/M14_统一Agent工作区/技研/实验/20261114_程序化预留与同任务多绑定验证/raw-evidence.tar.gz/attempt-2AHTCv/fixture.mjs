import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {join} from 'node:path';
import actual from './candidate.cjs';
import {migrate} from './migration.mjs';
export async function setup(){
 const bundle=actual.fixtureBundle();bundle.manifest.tools[0].name='smartdd_zentao_object_get_v1';bundle.manifest.runtime.hash=actual.validateRuntime({id:'applications',protocolMajor:1,bridgeEntry:'mcp-bridge.cjs',files:{'mcp-bridge.cjs':Buffer.from('module.exports = {};\n')}}).hash;
 bundle.files['schemas/input.json']=Buffer.from(JSON.stringify({type:'object',properties:{value:{type:'string'}},required:['value'],additionalProperties:false}));bundle.files['schemas/output.json']=Buffer.from(JSON.stringify({type:'object',properties:Object.fromEntries(['value','packageHash','projectId','taskId','operationId'].map(k=>[k,{type:'string'}])),required:['value','packageHash','projectId','taskId','operationId'],additionalProperties:false}));bundle.manifest.files=Object.entries(bundle.files).map(([path,bytes])=>({path,size:bytes.length,sha256:actual.digest(bytes),executable:false}));
 const f=await actual.runFixture(undefined,{application:true,applicationBundle:bundle}),db=f.sqlite;
 db.prepare("INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,'p1',?,'claude','legacy',1,1)").run(f.snapshot.taskId,f.snapshot.native.cwd);
 await migrate(db);db.exec('ALTER TABLE m14_binding ADD COLUMN discovery_home TEXT; ALTER TABLE m14_binding ADD COLUMN run_generation INTEGER NOT NULL DEFAULT 0 CHECK(run_generation>=0);');
 db.prepare("INSERT INTO application_catalog_state VALUES('zentao',1,1,1,?)").run(new Date().toISOString());db.prepare("INSERT INTO application_project_settings(project_id,app_id,enabled,binding_revision,updated_at) VALUES('p1','zentao',0,0,?)").run(new Date().toISOString());db.prepare("INSERT INTO application_binding_slot_revisions VALUES('p1','zentao','zentao',0)").run();
 const data=Buffer.from('module.exports={isolated:"codex adapter fixture"};'),hash=actual.digest(data),adapter=await f.store.publish({resourceId:'agent-adapter:codex:'+hash,kind:'agent-adapter',contentHash:hash,relativePath:'run-fixtures/codex/'+hash,dependencies:[f.parent.resourceId],materialize:dir=>{mkdirSync(dir);writeFileSync(join(dir,'entry.cjs'),data);writeFileSync(join(dir,'.smartdd-owned.json'),actual.canonicalJson({storeId:f.store.storeId,hash}));},verify:dir=>assert(readFileSync(join(dir,'entry.cjs')).equals(data))});
 const allowed=new Map([['claude-code',f.adapter],['codex',adapter]]);
 const sessions=new actual.CapabilitySessionRegistry(f.store,{assertInitialSelection:s=>assert(s.projectId==='p1'&&allowed.get(s.runner)?.contentHash===s.adapterBinding.hash,'HOST_SELECTION_CHANGED'),verifyExtraResource:r=>{const dir=f.store.directory(r),bytes=readFileSync(join(dir,'entry.cjs'));assert.equal(actual.digest(bytes),r.contentHash,'EXTRA_BYTES_CHANGED');assert.equal(JSON.parse(readFileSync(join(dir,'.smartdd-owned.json'),'utf8')).storeId,f.store.storeId);assert.deepEqual(readdirSync(dir).sort(),['.smartdd-owned.json','entry.cjs']);}});
 const taskId=randomUUID();db.prepare("INSERT INTO tasks(id,project_id,cwd,runner,title,created_at,updated_at) VALUES(?,'p1',?,'claude','logical task',1,1)").run(taskId,f.snapshot.native.cwd);
 const scopes=[],snapshots=[];
 for(const runner of ['claude-code','codex']){
  const b=randomUUID(),s=structuredClone(f.snapshot),mcp='programmatic_'+b.replaceAll('-',''),old=s.mcp[0].serverName,a=allowed.get(runner);s.schema=3;s.taskId=taskId;s.runner=runner;s.native.stateRoot=join(f.home,runner==='codex'?'.codex':'.claude');s.adapterBinding={...s.adapterBinding,id:runner,hash:a.contentHash};s.mcp[0].serverName=mcp;
  for(const [key,name]of Object.entries(s.adapterBinding.nativeToolNames))s.adapterBinding.nativeToolNames[key]=name.replace(old,mcp);
  const caps=actual.builtinApplicationModules.capabilityViews(f.application.manifest);for(const p of s.packages){p.entry='mcp';p.capabilityContractMajors=Object.fromEntries(caps.map(c=>[c.id,c.contractMajor]));for(const skill of p.skills)skill.projectionPath=join(f.root,'programmatic',b,'skills',skill.nativeName,'SKILL.md');}
  const snapshot=actual.capabilitySessionSnapshotV3Schema.parse(s);db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,cwd,entry_mode,phase) VALUES(?,?,?,?,'programmatic','planned')").run(b,taskId,runner,s.native.cwd);scopes.push(await sessions.createProgrammatic(b,snapshot,f.home));snapshots.push(snapshot);
 }
 const authorization=new actual.CurrentApplicationAuthorization(f.store,{packages:f.packageRegistry,retainedMetadata:hash=>f.packageRegistry.get(hash)});
 const createPlan=(recorded,hash,id)=>{const apps=authorization.selectedApps(recorded.projectId),bindings=authorization.bindings(recorded.projectId,apps.map(a=>a.appId)),selected={...recorded,packages:apps.map(a=>authorization.packageSelection(recorded.projectId,a.packageHash,bindings,[])),standardSkills:[]};return actual.createApplicationRunPlan({runId:id,snapshotHash:hash,snapshot:selected,applications:apps.map(a=>{const pack=f.packageRegistry.get(a.packageHash);return{packageHash:a.packageHash,manifest:pack.manifest,capabilities:actual.builtinApplicationModules.capabilityViews(pack.manifest)};}),skills:[],available:{mcp:true,cli:false}});};
 const runs=new actual.CapabilityRunRegistry(f.store,sessions,{processes:f.reader,assertCurrent:s=>{assert(db.prepare('SELECT 1 FROM projects WHERE id=? AND archived_at IS NULL').get(s.projectId),'PROJECT_UNAVAILABLE');},revoke:()=>{},createPlan,currentAuthorization:c=>authorization.view(c)}),handles=[];
 const reserve=async(index=0,over={})=>{const h=await runs.reserveProgrammatic({...scopes[index],bindings:[],...over});handles.push(h);return h;};
 return{...f,logicalTaskId:taskId,programmaticSessions:sessions,scopes,snapshots,adapters:allowed,programmaticRuns:runs,reserve,handles,authorization};
}
