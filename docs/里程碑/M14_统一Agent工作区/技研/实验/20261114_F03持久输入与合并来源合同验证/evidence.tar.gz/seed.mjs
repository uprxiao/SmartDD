import {randomUUID} from 'node:crypto';
import {hash} from './durable.mjs';
export function seed(db,ev,identity,instance){
 const original=db.prepare('SELECT * FROM m14_input LIMIT 1').get(),scope={taskId:original.task_id,bindingId:original.binding_id,runId:original.run_id,generation:original.generation,sessionId:ev.init.session_id};
 const insert=(table,x)=>db.prepare('INSERT INTO '+table+'('+Object.keys(x).join(',')+') VALUES('+Object.keys(x).map(()=>'?').join(',')+')').run(...Object.values(x));
 db.transaction(()=>{for(const input of ev.inputs.slice(1)){
  const turn=randomUUID(),command=randomUUID(),request=hash(input);
  insert('m14_turn',{id:turn,task_id:original.task_id,binding_id:original.binding_id,input:input.text,state:'dispatching',run_id:original.run_id,generation:original.generation});
  insert('m14_submission',{input_id:input.id,task_id:original.task_id,binding_id:original.binding_id,turn_id:turn,client_key:input.id,request_hash:request,source:input.source,target_json:'{}',blocks_json:JSON.stringify([{kind:'text',text:input.text}])});
  insert('m14_input',{...original,input_id:input.id,command_id:command,request_hash:request,source:input.source,text:input.text,turn_id:turn,scope_json:JSON.stringify(scope),scope_hash:hash(JSON.stringify(scope)),state:'dispatching',owner_instance:instance,owner_pid:identity.pid,owner_birth:identity.startedAt,native_json:null});
 }}).immediate();return scope;
}
