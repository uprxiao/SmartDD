import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {randomUUID,createHash} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,readFileSync,rmSync} from 'node:fs';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/native-'),home=out+'/home',cwd=out+'/project';mkdirSync(home);mkdirSync(cwd);
const bin='/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk-darwin-arm64/claude';
assert.equal(createHash('sha256').update(readFileSync(bin)).digest('hex'),'abc9feeeca8091d51b623291e044cf0528c2f6b74e0c1d6ef671d52c73f7cd3c');
const defer=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return{promise,resolve,reject};};
const bounded=(promise,label)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('OBSERVATION_TIMEOUT:'+label)),25000))]).finally(()=>clearTimeout(timer));};
const frames=[],requests=[],waiters=[],requestWaiters=[],inputs=[{id:randomUUID(),source:'automatic-followup',text:'FIRST_GATE'},{id:randomUUID(),source:'ui-user',text:'SAME_SYNTHETIC_REQUEST'},{id:randomUUID(),source:'history-transfer',text:'SAME_SYNTHETIC_REQUEST'},{id:randomUUID(),source:'ui-user',text:'LATEST_SYNTHETIC_REQUEST'}];
const nextFrame=fn=>{const old=frames.find(fn);if(old)return Promise.resolve(old);const d=defer();waiters.push({fn,...d});return d.promise;};
const nextRequest=n=>{if(requests[n])return Promise.resolve(requests[n]);const d=defer();requestWaiters.push({n,...d});return d.promise;};
let signal=defer(),queue=[],closed=false,child,exited,q,consumer,server,error;
const push=item=>{queue.push(item);signal.resolve();};
async function* messages(){while(!closed){if(!queue.length)await signal.promise;signal=defer();while(queue.length){const x=queue.shift();yield{type:'user',uuid:x.id,parent_tool_use_id:null,session_id:'',message:{role:'user',content:x.text}};}}}
function reply(g){g.res.writeHead(200,{'content-type':'text/event-stream'});const event=(type,o)=>g.res.write(`event: ${type}\ndata: ${JSON.stringify({type,...o})}\n\n`);event('message_start',{message:{id:'msg_'+randomUUID(),type:'message',role:'assistant',model:g.body.model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});event('content_block_start',{index:0,content_block:{type:'text',text:''}});event('content_block_delta',{index:0,delta:{type:'text_delta',text:'SYNTHETIC_OK'}});event('content_block_stop',{index:0});event('message_delta',{delta:{stop_reason:'end_turn'},usage:{output_tokens:1}});event('message_stop',{});g.res.end();}
try{
 server=createServer(async(req,res)=>{let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),g={body,res,index:requests.length};requests.push(g);appendFileSync(out+'/requests.jsonl',JSON.stringify(body)+'\n');for(const w of [...requestWaiters])if(w.n===g.index){requestWaiters.splice(requestWaiters.indexOf(w),1);w.resolve(g);}});await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 const env={HOME:home,CLAUDE_CONFIG_DIR:home+'/.claude',PATH:'/usr/bin:/bin',TMPDIR:out,ANTHROPIC_BASE_URL:'http://127.0.0.1:'+server.address().port,ANTHROPIC_AUTH_TOKEN:'synthetic-only',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1'};
 q=query({prompt:messages(),options:{pathToClaudeCodeExecutable:bin,cwd,env,model:'claude-haiku-4-5',settingSources:[],tools:[],mcpServers:{},includePartialMessages:true,spawnClaudeCodeProcess:o=>{child=spawn(o.command,o.args,{cwd,env,stdio:['pipe','pipe','pipe']});exited=new Promise(resolve=>child.once('exit',(code,signal)=>resolve({code,signal})));child.stderr.on('data',b=>appendFileSync(out+'/stderr.log',b));return child;}}});
 consumer=(async()=>{try{for await(const frame of q){frames.push(frame);appendFileSync(out+'/frames.jsonl',JSON.stringify(frame)+'\n');for(const w of [...waiters])if(w.fn(frame)){waiters.splice(waiters.indexOf(w),1);w.resolve(frame);}}}catch(e){if(!closed)throw e;}})();consumer.catch(()=>{});
 await bounded(q.initializationResult(),'initialization');push(inputs[0]);const first=await bounded(nextRequest(0),'first model request');
 for(const x of inputs.slice(1))push(x);
 for(const x of inputs.slice(1))await bounded(nextFrame(f=>f.type==='command_lifecycle'&&f.state==='queued'&&f.command_uuid===x.id),'queued '+x.source);
 assert(!frames.some(f=>f.type==='result'),'no model response before queue evidence');reply(first);
 const second=await bounded(nextRequest(1),'batched request');assert(inputs.slice(1).every(x=>JSON.stringify(second.body.messages).includes(x.text)),'all queued texts present');reply(second);
 const merged=await bounded(nextFrame(f=>(f.type==='assistant'||f.type==='stream_event')&&inputs.slice(1).every(x=>f.user_message_uuids?.includes(x.id))),'merged UUID echo');
 const done=await bounded(nextFrame(f=>f.type==='result'&&inputs.slice(1).every(x=>f.user_message_uuids?.includes(x.id))),'merged result');assert.equal(done.is_error,false);assert.equal(merged.parent_tool_use_id,null);assert.equal(merged.user_message_uuid,inputs.at(-1).id);
 writeFileSync(out+'/evidence.json',JSON.stringify({inputs,merged,done,init:frames.find(f=>f.type==='system'&&f.subtype==='init'),queued:frames.filter(f=>f.type==='command_lifecycle'),modelRequests:requests.length},null,2));
}catch(e){error=e.stack;process.exitCode=1;}
finally{closed=true;signal.resolve();try{q?.close();}catch{}if(child&&child.exitCode===null&&child.signalCode===null)child.kill('SIGTERM');if(exited)await bounded(exited,'native exit');await consumer?.catch(e=>{error??=e.stack});for(const g of requests)g.res.destroy();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}rmSync(home,{recursive:true,force:true});rmSync(cwd,{recursive:true,force:true});const result={out,passed:!error,error:error??null,inputs,modelRequests:requests.length,process:child?{pid:child.pid,exitCode:child.exitCode,signal:child.signalCode}:null,homeRemoved:true,scope:'Real Claude SDK/native; local synthetic model; no user data, paid model, business bridge or product changes'};writeFileSync(out+'/result.json',JSON.stringify(result,null,2));writeFileSync(root+'/latest-native.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));}
