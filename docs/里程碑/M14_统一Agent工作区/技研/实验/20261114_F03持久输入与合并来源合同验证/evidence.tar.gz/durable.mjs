import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
export const hash=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
const rank={queued:1,started:2,echo:3};
export function classify(frame,init){
 assert.equal(frame.session_id,init.session_id,'SESSION_CHANGED');
 if(frame.type==='command_lifecycle'){
  assert(init.capabilities?.includes('msg_lifecycle_v1'),'LIFECYCLE_CAPABILITY_REQUIRED');
  assert(['queued','started'].includes(frame.state),'NOT_ACCEPTANCE');
  assert(typeof frame.command_uuid==='string'&&frame.command_uuid,'MISSING_INPUT');
  return{ids:[frame.command_uuid],stage:frame.state,liveEligible:false};
 }
 assert(['assistant','stream_event'].includes(frame.type)&&frame.parent_tool_use_id===null,'ROOT_ECHO_REQUIRED');
 let ids;
 if(frame.user_message_uuids!==undefined){ids=frame.user_message_uuids;assert(Array.isArray(ids)&&ids.length>0&&ids.length<=64&&ids.every(x=>typeof x==='string'&&x.length>0)&&new Set(ids).size===ids.length,'INVALID_UUID_LIST');assert(ids.includes(frame.user_message_uuid),'SINGLE_UUID_NOT_IN_LIST');}
 else{assert(typeof frame.user_message_uuid==='string'&&frame.user_message_uuid,'MISSING_ECHO');ids=[frame.user_message_uuid];}
 return{ids,stage:'echo',liveEligible:frame.resume_reason===undefined};
}
function rowFor(db,id){return db.prepare('SELECT * FROM m14_input WHERE input_id=?').get(id);}
function rowsFor(db,frame,init){
 const shape=classify(frame,init),rows=shape.ids.map(id=>{const r=rowFor(db,id);assert(r,'UNRELATED_INPUT');assert(['dispatching','unknown','accepted'].includes(r.state),'NOT_DISPATCHED');const scope=JSON.parse(r.scope_json);assert.equal(hash(r.scope_json),r.scope_hash,'SCOPE_HASH_CHANGED');assert.equal(scope.sessionId,frame.session_id,'NATIVE_SESSION_CHANGED');for(const [camel,col]of [['taskId','task_id'],['bindingId','binding_id'],['runId','run_id'],['generation','generation']])assert.equal(scope[camel],r[col],'SCOPE_COLUMNS_CHANGED');const logical=db.prepare('SELECT * FROM m14_submission WHERE input_id=?').get(id);assert(logical&&logical.source===r.source&&logical.task_id===r.task_id&&logical.binding_id===r.binding_id&&logical.turn_id===r.turn_id,'SUBMISSION_MISMATCH');assert.equal(JSON.parse(logical.blocks_json)[0].text,r.text,'SUBMISSION_TEXT_CHANGED');return r;});
 assert(rows.every(r=>r.scope_hash===rows[0].scope_hash),'MIXED_RUN_BATCH');return{shape,rows};
}
export function openChannel(db,init,{reader,identity,instance}){
 const channel=Object.freeze({}),owner=Object.freeze({reader,identity,instance});let closed=false;
 return{channel,close(){closed=true;},journal(key,frame,fault=()=>{}){
  assert(key===channel&&!closed,'PRIVATE_LIVE_CHANNEL_REQUIRED');assert.equal(reader.state(identity),'running','OWNER_NOT_RUNNING');
  return db.transaction(()=>{
   const {shape,rows}=rowsFor(db,frame,init);assert(typeof frame.uuid==='string'&&frame.uuid,'FRAME_ID_REQUIRED');const raw=JSON.stringify(frame),digest=hash(raw);
   for(const [index,row]of rows.entries()){
    assert(row.owner_pid===identity.pid&&row.owner_birth===identity.startedAt&&row.owner_instance===instance,'OWNER_CHANGED');
    const eventId=hash([row.run_id,row.generation,frame.uuid,row.input_id]);const old=db.prepare('SELECT * FROM m14_input_inbox WHERE event_id=?').get(eventId);
    if(old)assert.equal(old.frame_hash,digest,'FRAME_CONFLICT');else db.prepare('INSERT INTO m14_input_inbox VALUES(?,?,?,?,?,0)').run(eventId,row.input_id,row.scope_hash,raw,digest);
    fault('journal-member-'+index);
   }
   return{ids:shape.ids,stage:shape.stage,liveGrant:false};
  }).immediate();
 }};
}
export function apply(db,ids,init,fault=()=>{}){
 return db.transaction(()=>{
  const all=new Map();
  for(const id of ids)for(const e of db.prepare('SELECT * FROM m14_input_inbox WHERE input_id=?').all(id))all.set(e.event_id,e);
  for(const e of all.values()){
   assert.equal(hash(e.frame_json),e.frame_hash,'FRAME_HASH_CHANGED');const frame=JSON.parse(e.frame_json),{shape,rows}=rowsFor(db,frame,init);
   assert(shape.ids.every(id=>ids.includes(id)),'PARTIAL_BATCH_APPLY');
   for(const row of rows){const mate=db.prepare('SELECT * FROM m14_input_inbox WHERE event_id=?').get(hash([row.run_id,row.generation,frame.uuid,row.input_id]));assert(mate&&mate.scope_hash===row.scope_hash&&mate.frame_hash===e.frame_hash,'INCOMPLETE_BATCH_JOURNAL');}
   assert.equal(e.scope_hash,rowFor(db,e.input_id).scope_hash,'INBOX_SCOPE_CHANGED');
  }
  for(const [index,id]of ids.entries()){
   const row=rowFor(db,id);assert(row,'INPUT_MISSING');let best=row.native_json?JSON.parse(row.native_json):null;
   for(const e of all.values())if(e.input_id===id){const frame=JSON.parse(e.frame_json),shape=classify(frame,init);if(!best||rank[shape.stage]>rank[best.stage])best={sessionId:frame.session_id,inputId:id,stage:shape.stage,echoGroup:shape.ids,resumeReason:frame.resume_reason??null};}
   if(best)db.prepare("UPDATE m14_input SET state='accepted',native_json=? WHERE input_id=?").run(JSON.stringify(best),id);
   fault('apply-member-'+index);
  }
  for(const e of all.values())db.prepare('UPDATE m14_input_inbox SET processed=1 WHERE event_id=?').run(e.event_id);
  return ids.map(id=>({id,state:rowFor(db,id).state,native:JSON.parse(rowFor(db,id).native_json??'null'),liveGrant:false}));
 }).immediate();
}
export function recover(db,ids,init,{reader,identity}){
 assert.equal(reader.state(identity),'stopped','OWNER_LIVE_OR_UNKNOWN');
 return db.transaction(()=>{
  for(const id of ids){const row=rowFor(db,id);assert(row.owner_pid===identity.pid&&row.owner_birth===identity.startedAt,'RECOVERY_OWNER_CHANGED');if(row.state==='dispatching')db.prepare("UPDATE m14_input SET state='unknown' WHERE input_id=?").run(id);}
  const facts=apply(db,ids,init);return facts.map(f=>({...f,decision:f.state==='queued'?'not-sent':f.state==='accepted'?'accepted-audit-only':'unknown-do-not-resend'}));
 }).immediate();
}
