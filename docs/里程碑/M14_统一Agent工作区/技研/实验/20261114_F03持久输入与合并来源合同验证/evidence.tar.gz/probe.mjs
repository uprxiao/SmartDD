import assert from 'node:assert/strict';
import {fork} from 'node:child_process';
import {once} from 'node:events';
import {randomUUID} from 'node:crypto';
import {readFileSync,writeFileSync,copyFileSync,mkdtempSync} from 'node:fs';
import Database from '/private/tmp/willyou-m14-owner-probe/node_modules/better-sqlite3/lib/index.js';
import actual from '/private/tmp/willyou-m14-writer-map-c1/actual.cjs';
import {ProgrammaticInputs} from '/private/tmp/willyou-m14-claude-live-origin-probe/inputs.mjs';
import {classify,openChannel,apply,recover} from './durable.mjs';
import {seed} from './seed.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/contract-'),evidenceFile=JSON.parse(readFileSync(root+'/latest-native.json')).out+'/evidence.json',ev=JSON.parse(readFileSync(evidenceFile)),ids=ev.inputs.slice(1).map(x=>x.id),checks=[];
const baseline='/private/tmp/willyou-m14-f01-command-contract/attempt-Xn90Z5/native-link.sqlite';
const sourceManifest=JSON.parse(readFileSync('/private/tmp/willyou-m14-writer-map-c1/actual-source-manifest.json'));for(const s of sourceManifest.sources)assert.equal(actual.digest(readFileSync(s.path)),s.sha256,'SOURCE_CHANGED:'+s.path);
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),identity=reader.read(process.pid),instance='f03-probe-'+process.pid;
const bounded=(p,label)=>{let t;return Promise.race([p,new Promise((_,reject)=>t=setTimeout(()=>reject(Error('OBSERVATION_TIMEOUT:'+label)),15000))]).finally(()=>clearTimeout(t));};
const save=()=>writeFileSync(out+'/result.json',JSON.stringify({checks,passed:checks.filter(x=>x.status==='passed').length,sourceInputsVerified:sourceManifest.sources.length,scope:'Real recorded Claude frames, unchanged C1.2 tables, isolated source-gate candidate and actual SQLite writer SIGKILL; relational run fixture is stopped and grants no real business authority'},null,2));
async function check(id,fn){try{checks.push({id,status:'passed',evidence:await fn()});}catch(e){checks.push({id,status:'failed',error:e.stack});save();throw e;}save();}
function open(name){const file=out+'/'+name+'.sqlite';copyFileSync(baseline,file);const db=new Database(file);db.pragma('foreign_keys=ON');return db;}
const verify=db=>{assert.equal(db.pragma('integrity_check',{simple:true}),'ok');assert.deepEqual(db.pragma('foreign_key_check'),[]);};
await check('F03-01 real merged frame requires all IDs, preserves mixed origin and cannot be reduced to last UUID',()=>{assert.equal(ev.merged.user_message_uuid,ids.at(-1));assert.deepEqual(classify(ev.merged,ev.init).ids,ids);assert(![ev.merged.user_message_uuid].includes(ids[0]));assert(ev.inputs[1].text===ev.inputs[2].text&&ev.inputs[1].source!==ev.inputs[2].source);return{nativeMergeObserved:true,ids:ids.length,legacyLastIdDrops:2};});
await check('F03-02 capability and exact identity guards reject malformed, unrelated, subagent and partial groups',()=>{
 const db=open('guards');seed(db,ev,identity,instance);const c=openChannel(db,ev.init,{reader,identity,instance});
 assert.throws(()=>c.journal({},ev.merged),/PRIVATE_LIVE_CHANNEL/);
 for(const frame of [{...ev.merged,session_id:randomUUID()},{...ev.merged,parent_tool_use_id:'child'},{...ev.merged,user_message_uuids:[ids[0],ids[0]]},{...ev.merged,user_message_uuids:[randomUUID()],user_message_uuid:'unknown'},{...ev.merged,user_message_uuids:[],user_message_uuid:ids[0]},{...ev.merged,user_message_uuids:undefined,user_message_uuid:undefined}])assert.throws(()=>c.journal(c.channel,frame));
 const queued=ev.queued.find(x=>x.command_uuid===ids[0]&&x.state==='queued');assert.throws(()=>classify(queued,{...ev.init,capabilities:[]}),/CAPABILITY/);assert.throws(()=>classify({...queued,state:'completed'},ev.init),/NOT_ACCEPTANCE/);
 c.journal(c.channel,ev.merged);assert.throws(()=>apply(db,[ids.at(-1)],ev.init),/PARTIAL_BATCH/);assert.equal(db.prepare('SELECT count(*) n FROM m14_input_inbox WHERE input_id IN(?,?,?)').get(...ids).n,3);
 assert.throws(()=>c.journal(c.channel,{...ev.merged,event:{type:'changed'}}),/FRAME_CONFLICT/);c.close();assert.throws(()=>c.journal(c.channel,ev.merged),/PRIVATE_LIVE_CHANNEL/);verify(db);db.close();return{noPartialAcceptance:true,privateChannelRequired:true,rawFrameConflictRejected:true};
});
await check('F03-03 queued and started establish delivery audit, echo remains distinct and does not complete logical turns',()=>{
 const db=open('stages');seed(db,ev,identity,instance);const c=openChannel(db,ev.init,{reader,identity,instance});
 for(const stage of ['queued','started']){for(const id of ids){const frame=ev.queued.find(x=>x.command_uuid===id&&x.state===stage);assert(frame);c.journal(c.channel,frame);}const facts=apply(db,ids,ev.init);assert(facts.every(x=>x.state==='accepted'&&x.native.stage===stage&&!x.liveGrant));}
 c.journal(c.channel,ev.merged);c.journal(c.channel,ev.merged);const result=apply(db,ids,ev.init);assert(result.every(x=>x.native.stage==='echo'&&!x.liveGrant));assert.equal(db.prepare('SELECT count(*) n FROM m14_input_inbox WHERE input_id IN(?,?,?)').get(...ids).n,9);
 for(const id of ids)assert.equal(db.prepare('SELECT t.state FROM m14_turn t JOIN m14_input i ON i.turn_id=t.id WHERE i.input_id=?').get(id).state,'dispatching');
 assert.deepEqual(apply(db,ids,ev.init),result);verify(db);db.close();return{nativeAcceptanceNotToolAuthorization:true,logicalTurnsNotFalselyCompleted:true,idempotentFanout:true};
});
await check('F03-04 same text and mixed group never transfer live user origin; fresh source gate cannot load grants',()=>{
 const db=open('source');const scope=seed(db,ev,identity,instance),controller=new AbortController();const current={run:{state:'active',runId:scope.runId,taskId:scope.taskId,projectId:'synthetic-project'},bindingId:scope.bindingId,generation:scope.generation,signal:controller.signal,snapshot:{runner:'claude-code',native:{sessionId:scope.sessionId}}};const sender={sender:{id:1},senderFrame:{processId:1,routingId:1}},channel={};const gate=()=>new ProgrammaticInputs({sender,channel,current:()=>current,now:()=>10000});let live=gate();
 for(const x of ev.inputs.slice(1))x.source==='ui-user'?live.captureUser(sender,x.text,x.id):live.captureInternal(x.source,x.text,x.id);
 const c=openChannel(db,ev.init,{reader,identity,instance});for(const id of ids)c.journal(c.channel,ev.queued.find(x=>x.command_uuid===id&&x.state==='queued'));apply(db,ids,ev.init);
 for(const x of ev.inputs.slice(1))assert.equal(live.match(current,x.text,10000,{inputId:x.id}),null);
 c.journal(c.channel,ev.merged);apply(db,ids,ev.init);for(const x of ev.inputs.slice(1))live.acknowledge(channel,x.id,{inputId:x.id,text:x.text,sessionId:scope.sessionId});
 const first=live.match(current,ev.inputs[1].text,10000,{inputId:ids[0]});assert(first);assert(!live.isLatest(first));assert.equal(live.match(current,ev.inputs[2].text,10000,{inputId:ids[1]}),null);const latest=live.match(current,ev.inputs[3].text,10000,{inputId:ids[2]});assert(latest&&live.isLatest(latest));live.claim(latest,current,'same-intent');assert.throws(()=>live.claim(latest,current,'different-intent'));
 assert.equal(classify({...ev.merged,resume_reason:'host_draining'},ev.init).liveEligible,false);live.dispose();assert.equal(live.isRetained(latest),false);const recovered=gate();for(const x of ev.inputs.slice(1)){assert.equal(recovered.match(current,x.text,10000,{inputId:x.id}),null);assert.throws(()=>recovered.acknowledge(channel,x.id,{inputId:x.id,text:x.text,sessionId:scope.sessionId}));}
 assert(db.prepare('SELECT source FROM m14_submission WHERE input_id=?').get(ids[0]).source==='ui-user');controller.abort();recovered.dispose();c.close();verify(db);db.close();return{sourceGateUnchangedFrom108:true,UIAndCurrentRunAreExplicitFixtures:true,journalDoesNotRecreateRAMReceipt:true,originalSourceRetained:true};
});
for(const stage of ['before-journal','journal-member-0','after-journal','apply-member-0','after-apply'])await check('F03-05 '+stage+' writer SIGKILL and audit-only recovery',async()=>{
 const db=open('crash-'+stage);db.close();const child=fork(root+'/worker.mjs',[db.name,evidenceFile,stage],{stdio:['ignore','pipe','pipe','ipc'],env:{...process.env,NODE_PATH:'/private/tmp/willyou-m14-owner-probe/node_modules'}});let stderr='';child.stderr.on('data',b=>stderr+=b);const done=once(child,'exit');let marker;
 try{marker=await bounded(Promise.race([once(child,'message').then(([m])=>m),done.then(([code])=>{throw Error('WORKER_EARLY_EXIT:'+code+':'+stderr);})]),stage);assert.equal(marker.stage,stage);assert.equal(reader.state(marker.identity),'running');child.kill('SIGKILL');const exit=await bounded(done,'worker exit');assert.equal(exit[1],'SIGKILL');assert.equal(reader.state(marker.identity),'stopped');}
 finally{if(child.exitCode===null&&child.signalCode===null){child.kill('SIGKILL');await done;}}
 const reopened=new Database(db.name);reopened.pragma('foreign_keys=ON');const before=reopened.prepare('SELECT input_id,state FROM m14_input WHERE input_id IN(?,?,?) ORDER BY input_id').all(...ids),inbox=reopened.prepare('SELECT count(*) n FROM m14_input_inbox WHERE input_id IN(?,?,?)').get(...ids).n;
 assert.throws(()=>recover(reopened,ids,ev.init,{reader:{state:()=> 'unknown'},identity:marker.identity}),/OWNER_LIVE_OR_UNKNOWN/);
 const facts=recover(reopened,ids,ev.init,{reader,identity:marker.identity});const expected=['before-journal','journal-member-0'].includes(stage)?'unknown':'accepted';assert(facts.every(x=>x.state===expected&&!x.liveGrant));assert.equal(inbox,expected==='unknown'?0:3);assert.deepEqual(recover(reopened,ids,ev.init,{reader,identity:marker.identity}),facts);verify(reopened);reopened.close();return{stage,actualWriterExit:'SIGKILL',recordedNativeFrame:true,nativeNotRunningInThisWorker:true,rowsBeforeRecovery:before,inbox,decision:facts[0].decision,liveGrant:false};
});
save();writeFileSync(root+'/latest-contract.json',JSON.stringify({out,passed:checks.length},null,2));console.log(JSON.stringify({out,passed:checks.length}));
