from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_子任务准备与原生初始化联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 target=stage/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==11 and not result.get('error');attempt=Path(result['out']);assert json.loads((attempt/'result.json').read_text())==result
sources={}
for name in ['build.json','profile-build.json']:
 b=json.loads((root/name).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[s['path']]=s
 for o in b.get('outputs',[]):
  assert sha(Path(o['file']).read_bytes())==o['sha256'];assert sha((attempt/Path(o['file']).name).read_bytes())==o['sha256']
  for p in o.get('patches',[]):assert sha(Path(p['path']).read_bytes())==p['beforeHash'];assert sha((root/(Path(p['path']).name+'.variant')).read_bytes())==p['afterHash']
for n in ['probe.mjs','joint.mjs','fixture.mjs','programmatic.mjs','execution.mjs','joint.sql','candidate.cjs','profile.cjs']:assert (root/n).read_bytes()==(attempt/n).read_bytes(),n
negative=json.loads((root/'baseline-negative.json').read_text());assert negative['status']=='reproduced' and negative['plannedRevision']>negative['acceptedRevision']
runtime=json.loads((root/'runtime-audit.json').read_text());assert len(runtime['attempts'])==4 and sum(len(a['ownExits'])for a in runtime['attempts'])==10
refs=[(repo,'src/main/core/applications/session-registry.ts'),(repo,'src/main/core/applications/run-registry.ts'),(repo,'src/main/core/applications/run-plan.ts'),(repo,'src/main/core/ai/ai-profile-service.ts'),(t3,'apps/server/src/orchestration-v2/EventSink.ts'),(t3,'apps/server/src/orchestration-v2/Orchestrator.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,p in refs],'scope':'Actual source variants and real native initialization; candidate child/outbox/source/reservation/idempotency/ExecutionPlan. T3 commitCommandEffect and replayCommandReceipt inspected only; no T3 runtime or production implementation.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('baseline-negative.json',json.dumps(negative,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('runtime-audit.json',json.dumps(runtime,indent=2))]:put(exp/n,data)
put(exp/'README.md',f'''# 子任务准备、运行预留与两端初始化：联合技术验证

日期：2026-11-14。对应 R02／06／08，Q04／06／13／19／24；技术方案 §3.2.13、§7.1，验证账 §4.45。仅临时目录中的技术实验，没有修改产品或共享原型。

## 补齐的链路

本批将之前分开的子任务原子创建、新能力来源／直接预留、执行配置修订、ExecutionPlan／delivery 和真实原生初始化接到同一数据库／运行注册器。父 Codex 先真实初始化并由实际 owner 判 active；候选宿主服务直接接受子请求，再产生 tasks／planned binding／turn／delegation／receipt／outbox，之后创建新 scoped 能力会话，直接预留实际 run，提交应用计划与宿主计划并初始化子 Claude 或 Codex。

父模型没有发出委派工具调用；这批通过宿主服务直接输入请求。未接 Skill／MCP 委派 transport、业务桥或真实对话。每个子任务使用独立的临时目录，未测试共享 SVN 写入协调。不能把上述初始化联合等同于完整多 Agent 功能。

## 最终结果与负对照

`{attempt.name}` 的 K01–K11 通过。最终批次三个原生初始化：一个父 Codex、一个子 Claude、一个子 Codex；三个均取得实际退出。四个保存轮次共十个自有进程，均已核退出。没有模型 turn、thread/start 或真实业务写入。

| 项 | 实际证明 |
| --- | --- |
| K01／K11 | 子接受使用当前实际 owner；相同逻辑请求返回同一 child，改内容拒绝；接受事务末尾异常整体回滚 |
| K02 | 发布成功后注入回执失败，再次发布返回同 cap／scope；前批原样 publish 在同一重试上报 BINDING_NOT_PLANNED，作为负对照 |
| K03／K04 | 运行请求收据与 run／plan／资源／进程及 outbox reserved 状态同事务；回执异常后复用同一进程内私有句柄和 run；收据插入失败则全部回滚，代次不增加 |
| K05 | 宿主计划准备在 pins 后失败，计划／delivery 回滚；重试使用原 reserved run，只有一份 delivery |
| K06 | 子 Claude 真实初始化提交后注入回执异常；新候选 executor 查询同一 initialized 状态，无第二次 spawn |
| K07 | 同一进程两个重复派发请求共享子 Codex 初始化，只有一次 spawn |
| K08 | 另一个 registry 即使在同一进程读取到持久回执，也不能据此重建私有 owner；要求恢复对账 |
| K09／K10 | 接受后改配置在领取时阻塞；预留后再改配置在宿主计划事务中拒绝，保留原任务／回执，无新计划 |

两个早期全批 `attempt-d1lvDi`／`attempt-JKrpUh` 的 K01–K09 有效；K10 使用固定的轮换值，前一项已写入同值，故第二次未改变配置修订。该失败是无效故障注入，不能证明候选缺陷。修正为唯一合成值并断言修订确实增加后，以旧 execution 候选单跑 `attempt-4oGwlf`：接受修订 1，实际变为 2，旧候选仍生成修订 2 的计划，取得有效负对照。最终将接受时目标修订存入 outbox，并在计划提交事务复核后，全批通过。原始输入／失败／数据库均保留，不用早期绿项替代最终联合结论。

所谓回执丢失均为**同进程提交后抛错模拟**；不是网络断线或宿主 SIGKILL。K07 也不是多进程 worker 竞争。初始化确认只表示原生握手成功，不表示任务已开始执行模型指令或完成工作。

## 收口的设计约束

1. 逻辑请求键、能力发布收据、运行尝试与原生启动分别记账；任何一层的重复请求都不能自动建立另一层的新身份。
2. 新运行预留必须与对应 outbox／运行请求收据同事务。不能先提交 run，再单独写 effect→run 关联，留下恢复时无法判定的窗口。
3. 已接受的目标修订属于本次派发，随 effect 固定，不读取“最新默认项”来替换，也不长期借用 binding 的兼容修订含义。计划准备与启动门禁都核对本次明确选择。
4. 持久回执可以返回事实，不能恢复 WeakMap／私有句柄或授权另一个宿主控制进程。已 initialized 的重复查询不得再次 spawn；dispatching 无明确证明时保留待核实。

T3 EventSink.commitCommandEffect 先在事务中保留 command receipt，再写 events／projection／outbox，提交后通知；Orchestrator.replayCommandReceipt 校验原 thread 并读取原事件。WillYou 借鉴持久提交和作用域核验，不照搬全量事件溯源，也不从 T3 推导跨进程外部操作恰好一次。

## 仍未证明

实际宿主崩溃后新 worker 的接管与新运行尝试、真实 socket 丢包、多个 worker 竞争、提交与 fork 间停止及 native 首次 ID 回调仍需联合验证。本候选每 effect 只有一个 run 收据，未实现重启后可安全创建下一 attempt 的完整协议；不得用丢弃回执或改 claim token 绕过。能力发布的幂等复用覆盖首次 native ID 之前，当前 revision 已变化后的历史发布收据查询／执行分离仍需补。

执行器资源、能力包及密钥均为隔离夹具；配置服务和运行所有权使用实际组件，密文加密器是假实现。没有完整资源安装／版本迁移、SDK 参数映射、后代进程范围、业务来源授权、历史接续或 UI；旧实验格式没有升级迁移。保留所有这些边界，不能称为产品联调或验收。

## 证据与复跑

[最终结果](result.json)、[有效负对照](baseline-negative.json)、[运行审计](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[全部轮次原始证据](raw-evidence.tar.gz)。归档 {len(files)} 个文件、{len(dbs)} 份 SQLite，完整性和外键通过；{len(sources)} 个构建输入已核当前哈希。

在新的临时目录恢复匹配依赖及源码基线，使用归档中已生成的最终 `.variant` 文件，依次成功执行 `node build.mjs`、`node profile-build.mjs`、`node probe.mjs`。`make-variants.py`／`extend.py` 是本次构造记录，不应向已经扩展的最终文件重复套用。原生程序／SDK／进程身份 helper 的版本和 hash 在运行审计中；仅使用独立 HOME、合成凭据及不可用 loopback 模型地址。不连接用户库，不将候选表当作产品迁移。
''')
# Rewrite the current constraint where it belongs instead of adding another implementation chronicle.
def tech(t):
 old='本批验证新 source／reserve 与实际 owner、v1 计划及 R17 工具服务的局部接线，未启动原生执行器。发布提交后的 ACK 丢失／幂等恢复、完整配置与 ExecutionPlan／delivery／outbox、真正首次 native 回调及业务桥仍需联合验证；不能把前批初始化结果当作本批新链已通过。暂用旧 ptyId 内部字段的候选不是最终 launchId 迁移，未支持的程序化 native-only 回退须明确拒绝，不能落回按 task 查询的旧路径。'
 new='本节初次实验仅验证 source／reserve、实际 owner、v1 计划及 R17 局部接线。后续[子任务启动联合实验](实验/20261114_子任务准备与原生初始化联合验证/README.md)已将新任务来源／直接预留与配置修订、ExecutionPlan／delivery／outbox 接到两端真实初始化，并补同进程提交后回执失败的幂等关联（§7.1）。真实宿主崩溃后的接管、下一运行尝试、首次 native 回调及业务桥仍待联合；不能以初始化成功声称完整恢复或对话通过。暂用旧 ptyId 内部字段的候选不是最终 launchId 迁移，未支持的程序化 native-only 回退须明确拒绝，不能落回按 task 查询的旧路径。'
 assert old in t;t=t.replace(old,new)
 old='隔离候选已取得十项证据：真实旧入口对照、双连接并发去重、写任务后／写完 outbox 后／COMMIT 后三处真实宿主 SIGKILL、目标删除、当前权限撤销、领取 token 与跨 run 重试。跨 run 检查先复现重复 child，再修正候选去重作用域。目录／fork 证据和父进程 reader 仍有夹具边界；完整配置身份、子能力准备与实际 outbox worker 联合路径尚未验证，不将计划行当作已经运行。'
 new='''早期隔离创建实验已验证旧入口对照、双连接去重、三个提交窗口的宿主 SIGKILL、目标删除、权限撤销、领取 token 和跨 run 重试；该证据只覆盖当时创建账。后续[子任务启动联合实验](实验/20261114_子任务准备与原生初始化联合验证/README.md)使用同库子任务／outbox、新 scoped 会话、直接 run 预留和真实配置服务，接到 Claude／Codex 原生初始化。提交后抛错、事务回滚及同进程重复派发已验证；没有在新联合链执行宿主崩溃或完整模型回合。

接受时将明确的目标 profileId 与执行修订固定在本次派发记录中，不能只在领取时检查一次。宿主计划的准备事务和 fork 门禁都核对它；变化则保留原子任务和回执、阻止继续，不静默捕获新 Key 或默认配置。有效负对照已复现“接受修订 1 却生成修订 2 的计划”，新增提交核验后拒绝。目标修订属于此次派发，不与长期 binding 兼容身份混用；用户明确更换目标需形成新的受控选择，不能篡改旧接受事实。

能力发布以稳定绑定／请求指纹返回原收据；run 请求收据、run／应用计划／租约／进程预留和 outbox→run 关联同事务写入。同宿主重试复用原私有句柄，计划准备失败可在原 run 上重做尚未提交的计划事务。持久 initialized 记录只供查询原事实，不触发第二次原生启动，也不表示模型任务已执行。

持久收据不签发运行所有权。另一个 registry／宿主不能由 JSON 重建私有 owner；dispatching 或 owner 不明时先对账，不能按领取超时重发。崩溃恢复后若需要新的运行尝试，必须保留原 receipt／run 历史，在证明旧执行范围排空及是否派发后分配独立 attempt／generation，再原子关联队列；本批一 effect 一 run 的候选尚未实现此恢复协议。禁止删除旧收据、换 token 后直接重新启动。首次 native ID 已修订后的发布收据查询、完整业务桥及共享目录仍按各自缺口验证。'''
 assert old in t;return t.replace(old,new)
edit(base/'技研/技术方案.md',tech)
section='''### 4.45 子任务准备、运行预留与原生初始化联合

[联合实验](实验/20261114_子任务准备与原生初始化联合验证/README.md)最终 K01–K11 将同库子任务创建／outbox、新 scoped 能力发布、直接运行预留、实际配置服务和 ExecutionPlan／delivery 接到真实父 Codex 及子 Claude／Codex 初始化。发布和预留回执重试、run 收据与 outbox 原子关联、计划回滚、初始化重复请求及另一个 registry 不得重建 owner 已取得限定证据。最终三个自有进程均退出，无模型 turn 或业务操作。

前两轮 K10 重复使用同值换 Key，未改变修订，属于故障夹具无效；修正后单跑旧候选得到有效负对照：接受修订 1，计划却选修订 2。将本次目标修订持久记录到 outbox 并在计划事务复核后最终通过。全部失败和输入保留。回执故障为同进程抛错，不是 socket 断开或宿主崩溃；真正恢复后的新 attempt、首次 native ID、完整业务／共享 SVN 仍待验。T0.1 §3.2.13／7.1 更新现行规则，Q04／06／13／19／24 保持部分，不进入产品验收。

'''
def ledger(t):
 assert '### 4.45 ' not in t;t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正')
 for q in ['Q04','Q06','Q13','Q19','Q24']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.45 补新子任务／来源／预留／计划到两端初始化联合及同进程回执重试，真实崩溃接管／完整对话未覆盖 |';t='\n'.join(lines)+'\n'
 old='下一项优先验证 D01／D02／D06 的共同接缝：以 §4.44 的新任务精确能力来源与直接预留为起点，接 §4.32 的子创建／outbox 和 §4.43 的配置／计划／原生初始化，验证提交后回包丢失时不会产生重复绑定、重复 run 或错误接管。须先明确幂等键、持久提交点及恢复规则，再在临时候选中验证；这不是接入产品的授权。之后按矩阵补观察竞争／父切换与未知投递、业务权限、运行范围、资源分发和性能等独立缺口。某条联合链通过不替其他 D 项关闭，界面状态的设计也不以尚无产品 UI 为由省略。'
 new='下一项优先验证 D01／D02／D06 的真实宿主恢复接缝：§4.45 已把子创建、新来源／预留、配置／计划及两端初始化联合，并验证同进程提交后抛错重试；仍需在宿主退出后核验持久回执、原 owner／进程范围、实际 run recovery 与下一 attempt 的原子分配，区分未 fork 可恢复和已派发／unknown 不重发。其余观察竞争／父切换、业务权限、运行范围、资源分发、性能及界面状态设计继续按矩阵推进。这是临时技术验证，不是产品接线授权；局部联合通过不替其他 D 项关闭。'
 assert old in t;t=t.replace(old,new)
 t=t.replace('新任务直接预留（§4.44）的局部证据。剩余决定性验证：将新 source／reserve 与同一 ExecutionPlan／delivery／outbox、真实 owner 及首次 native 回调联合；发布提交后回包丢失的幂等接管；','新任务直接预留（§4.44）以及子任务／计划到两端初始化与同进程回执重试（§4.45）的局部证据。剩余决定性验证：新联合链的真实宿主崩溃接管、下一运行尝试及首次 native 回调；发布提交后跨宿主恢复；')
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：子任务持久创建、新能力来源、直接运行预留及宿主计划已在同一隔离链接到 Claude／Codex 真实初始化，补证同进程回执重试和重复派发，见[技术方案 §7.1](技研/技术方案.md)。已修正接受后配置变化被静默采用的候选缺口；尚无模型任务或完整业务接线，真实宿主崩溃后的接管仍待验证。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进全部本期问题。优先验证新联合链的宿主退出、原运行对账及下一运行尝试，区分可恢复的未启动与不可盲目重发的未知派发；继续补业务授权、结果观察竞争、安装／版本／平台和界面状态设计。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型代码；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources)}))
