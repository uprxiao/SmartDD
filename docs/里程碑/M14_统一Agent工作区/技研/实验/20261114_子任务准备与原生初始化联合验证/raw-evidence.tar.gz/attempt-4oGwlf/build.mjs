import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync,globSync,existsSync,symlinkSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD',extra='/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules',sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
if(!existsSync(root+'/node_modules'))symlinkSync('/private/tmp/willyou-m14-owner-probe/node_modules',root+'/node_modules');
const mods={'run-plan':['createApplicationRunPlan','verifyApplicationRunPlan','storeApplicationRunPlan','readApplicationRunPlan','assertRunPlanSnapshotSource'],'run-recovery':['recoverCapabilityRuns'],'process-identity':['MacProcessIdentityReader'],'run-registry':['assertOwnedCapabilityRun','CapabilityRunRegistry'],'current-authorization':['CurrentApplicationAuthorization'],'tool-service':['ApplicationToolService'],'modules/index':['builtinApplicationModules'],'__tests__/fixtures':['fixtureBundle'],'runtime-registry':['RuntimeRegistry','validateRuntime'],'__tests__/run-fixture':['runFixture','FixtureProcessReader'],'resource-store':['ResourceStore'],'resource-gc-plan':['resourceGcPlan'],'resource-graph-maintenance':['ResourceGraphMaintenance'],'restore-owned-directory':['restoreOwnedDirectory'],'manifest':['canonicalJson','digest'],'session-registry':['selectionHash','CapabilitySessionRegistry'],'resource-lock':['withResourceLock']};
const entry=Object.entries(mods).map(([m,n])=>`export {${n.join(',')}} from '${repo}/src/main/core/applications/${m}.ts';`).join('\n')+`\nexport {runFixture as runCodexFixture} from 'm14-codex-fixture';\nexport {storedCapabilitySessionSnapshotSchema,capabilitySessionSnapshotV3Schema} from '${repo}/src/shared/application-session-v3.ts';`;
const outputs=[],sources=new Map();
for(const modified of [false,true]){
 const patches=[];
 const result=await build({stdin:{contents:entry+(modified?`\nexport {setProjectionFault,projectNativeBinding} from '${root}/projection.mjs';`:''),resolveDir:repo,loader:'ts'},define:{'import.meta.url':JSON.stringify('file://'+root+'/fixture-entry.mjs')},bundle:true,platform:'node',format:'cjs',target:'node22',metafile:true,tsconfig:repo+'/tsconfig.node.json',external:['better-sqlite3','./actual.cjs'],nodePaths:[root+'/node_modules',extra],outfile:root+(modified?'/candidate.cjs':'/actual.cjs'),plugins:[{name:'isolated-source-variant',setup(b){
  b.onResolve({filter:/^m14-codex-fixture$/},()=>({path:repo+'/src/main/core/applications/__tests__/run-fixture.ts',namespace:'codex-fixture'}));
  b.onLoad({filter:/.*/,namespace:'codex-fixture'},({path})=>({loader:'ts',resolveDir:repo+'/src/main/core/applications/__tests__',contents:readFileSync(path,'utf8').replaceAll('claude-code','codex').replace("join(home,'.claude')","join(home,'.codex')")}));
  b.onLoad({filter:/\/(db\/migrations|capabilities\/assets)\.ts$/},({path})=>({loader:'ts',contents:readFileSync(path,'utf8').replace(/import\.meta\.glob\('([^']+)',\s*\{[\s\S]*?\}\)/g,(_,pattern)=>'('+JSON.stringify(Object.fromEntries(globSync(pattern.replace('@root/',repo+'/')).flatMap(p=>{try{return[[p,readFileSync(p,'utf8')]]}catch{return[]}})))+')')}));
  if(modified)b.onLoad({filter:/\/(session-registry|run-registry|run-plan)\.ts$/},({path})=>{const name=path.split('/').at(-1),contents=readFileSync(root+'/'+name+'.variant','utf8');patches.push({path,beforeHash:sha(path),afterHash:createHash('sha256').update(contents).digest('hex')});return{loader:'ts',contents};});
  if(modified)b.onLoad({filter:/\/(resource-gc-plan|resource-graph-maintenance)\.ts$/},({path})=>{
   let contents=readFileSync(path,'utf8');const before=contents;
   if(path.endsWith('resource-gc-plan.ts')){
    const anchor=' const baseReasons=reasons,baseIssues=issues;';if(!contents.includes(anchor))throw Error('planner anchor absent');
    contents=contents.replace(anchor," const programmatic=programmaticRetention(store);for(const issue of programmatic.issues)issues.add(issue);for(const ref of programmatic.refs)retain(ref.ref_id,'binding-reference:'+ref.cap_id+':'+ref.snapshot_hash);\n"+anchor);
    contents=contents.replace('storeState,nativeUnknown,holds,runs,issues:','storeState,nativeUnknown,holds,runs,programmatic:programmatic.basis,issues:');
   }else{
    const anchor='  if(db.prepare(`SELECT 1 FROM capability_session_refs';if(!contents.includes(anchor))throw Error('final guard anchor absent');
    contents=contents.replace(anchor,"  const programmatic=programmaticRetention(this.store);if(programmatic.issues.length||programmatic.refs.some(ref=>ids.includes(ref.ref_id)))throw new ApplicationError('RESOURCE_RECOVERY_REQUIRED','新绑定引用或未知历史阻止清理');\n"+anchor);
   }
   contents=`import {programmaticRetention} from '${root}/retention.ts';\n`+contents;patches.push({path,beforeHash:createHash('sha256').update(before).digest('hex'),afterHash:createHash('sha256').update(contents).digest('hex')});writeFileSync(root+'/'+path.split('/').at(-1)+'.variant',contents);return{loader:'ts',contents};
  });
 }}]});
 for(const p of Object.keys(result.metafile.inputs).filter(p=>!p.startsWith('<'))){const path=p.startsWith('codex-fixture:')?p.slice('codex-fixture:'.length):p.startsWith('/')?p:process.cwd()+'/'+p;sources.set(path,{path,sha256:sha(path)});}
 const file=root+(modified?'/candidate.cjs':'/actual.cjs');outputs.push({file,sha256:sha(file),patches});
}
for(const path of globSync(repo+'/drizzle/*.sql'))sources.set(path,{path,sha256:sha(path)});
writeFileSync(root+'/build.json',JSON.stringify({sources:[...sources.values()],outputs,scope:'Actual baseline; candidate build injects retention reader into GC plan and final deletion guard in memory. Product files unchanged.'},null,2));console.log(JSON.stringify({sources:sources.size,outputs:outputs.length}));
