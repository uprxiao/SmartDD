from pathlib import Path
r=Path(__file__).resolve().parent
p=r/'programmatic.mjs';t=p.read_text();a=" assert(store.sqlite.inTransaction,'TRANSACTION_REQUIRED');const db=store.sqlite,b=";b=""" assert(store.sqlite.inTransaction,'TRANSACTION_REQUIRED');const db=store.sqlite;
 const requestHash=actual.digest(actual.canonicalJson({snapshot,home})),prior=db.prepare('SELECT * FROM m14_publication WHERE binding_id=?').get(bindingId);
 if(prior){assert.equal(prior.request_hash,requestHash,'PUBLICATION_CONFLICT');return programmaticScopeSchema.parse(JSON.parse(prior.scope_json));}
 const b=""";assert a in t;t=t.replace(a,b)
a=" db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(snapshotHash,cap);return{taskId:snapshot.taskId,bindingId,capabilitySessionId:cap,snapshotHash};"
b=""" db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(snapshotHash,cap);const scope={taskId:snapshot.taskId,bindingId,capabilitySessionId:cap,snapshotHash};db.prepare('INSERT INTO m14_publication VALUES(?,?,?)').run(bindingId,requestHash,actual.canonicalJson(scope));return scope;""";assert a in t;t=t.replace(a,b);p.write_text(t)
p=r/'run-registry.ts.variant';t=p.read_text();a='  private async reserveManaged(';i=t.index(a)
method="""  private readonly programmaticRequests=new Map<string,{hash:string,promise:Promise<OwnedCapabilityRun>}>();
  async reserveProgrammaticOnce(key:string,claim:string,input:ProgrammaticScope & {bindings:RunBindingRevision[]}):Promise<OwnedCapabilityRun>{
    const {bindings,...scope}=input;programmaticScopeSchema.parse(scope);z.uuid().parse(key);z.uuid().parse(claim);
    if(!this.deps.createPlan)throw new ApplicationError('AGENT_ADAPTER_UNSUPPORTED','程序化运行必须提供固定应用计划');
    const hash=digest(canonicalJson(input)),cached=this.programmaticRequests.get(key);
    if(cached){if(cached.hash!==hash)throw new ApplicationError('SCOPE_DENIED','REQUEST_CONFLICT');return cached.promise;}
    const prior=this.store.sqlite.prepare('SELECT * FROM m14_run_request WHERE request_key=?').get(key) as {request_hash:string;run_id:string}|undefined;
    if(prior){if(prior.request_hash!==hash)throw new ApplicationError('SCOPE_DENIED','REQUEST_CONFLICT');throw new ApplicationError('RESOURCE_RECOVERY_REQUIRED','PERSISTED_RUN_REQUIRES_OWNER');}
    const promise=this.reserveManaged({taskId:scope.taskId,snapshotHash:scope.snapshotHash,bindings},undefined,scope,{key,claim,hash});
    this.programmaticRequests.set(key,{hash,promise});try{return await promise;}catch(e){if(!this.store.sqlite.prepare('SELECT 1 FROM m14_run_request WHERE request_key=?').get(key))this.programmaticRequests.delete(key);throw e;}
  }
"""
t=t[:i]+method+t[i:];a='programmatic?:ProgrammaticScope): Promise<OwnedCapabilityRun>';b='programmatic?:ProgrammaticScope,request?:{key:string;claim:string;hash:string}): Promise<OwnedCapabilityRun>';assert a in t;t=t.replace(a,b,1)
a='      this.store.sqlite.prepare("INSERT OR IGNORE INTO capability_store_state';i=t.index(a,t.index('private async reserveManaged'))
t=t[:i]+"""      if(request){const effect=this.store.sqlite.prepare('SELECT o.*,d.child_task,t.binding_id FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_turn t ON t.id=d.turn_id WHERE o.id=?').get(request.key) as {state:string;claim:string;child_task:string;binding_id:string}|undefined;if(!effect||effect.state!=='claimed'||effect.claim!==request.claim||effect.child_task!==value.taskId||effect.binding_id!==programmatic?.bindingId)throw new ApplicationError('SCOPE_DENIED','STALE_EFFECT_CLAIM');}
"""+t[i:]
a='    }).immediate());\n    const owned: OwnedRun';b="""      if(request){this.store.sqlite.prepare('INSERT INTO m14_run_request VALUES(?,?,?)').run(request.key,request.hash,runId);const changed=this.store.sqlite.prepare("UPDATE m14_outbox SET state='reserved',run_id=? WHERE id=? AND state='claimed' AND claim=?").run(runId,request.key,request.claim);if(changed.changes!==1)throw new ApplicationError('SCOPE_DENIED','EFFECT_RESERVATION_CONFLICT');}
    }).immediate());
    const owned: OwnedRun""";assert a in t;t=t.replace(a,b,1);p.write_text(t)
# Install receipt tables before initial synthetic programmatic fixture sources are published.
p=r/'fixture.mjs';t=p.read_text();a="db.exec('ALTER TABLE m14_binding ADD COLUMN discovery_home TEXT; ALTER TABLE m14_binding ADD COLUMN run_generation INTEGER NOT NULL DEFAULT 0 CHECK(run_generation>=0);');";assert a in t;t=t.replace(a,a+"db.exec(readFileSync(new URL('./joint.sql',import.meta.url),'utf8'));");p.write_text(t)
