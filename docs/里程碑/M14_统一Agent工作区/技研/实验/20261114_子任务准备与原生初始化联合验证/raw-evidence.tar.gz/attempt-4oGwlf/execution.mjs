import assert from 'node:assert/strict';
import {readFileSync,realpathSync} from 'node:fs';
import {join,isAbsolute} from 'node:path';
import {z} from 'zod';
import actual from './candidate.cjs';
import {capture,consume,revision as configurationRevision} from './revision.mjs';
import profileActual from './profile.cjs';
import {prepareLocked,adopt,releasePreparation} from './delivery.mjs';
import {inspect,canonical,digest} from './contract.mjs';
const id=z.string().min(1),hash=z.string().regex(/^[a-f0-9]{64}$/),revision=z.number().int().nonnegative();
const versions={sdkVersion:id,nativeVersion:id,protocol:id};
const external=z.object({kind:z.literal('external'),path:id,sha256:hash,...versions}).strict();
const managed=z.object({kind:z.literal('managed'),resourceId:id,file:id,sha256:hash,...versions}).strict();
export const executionSchema=z.object({schema:z.literal('m14-execution-plan-probe-v2'),storeId:z.uuid(),projectId:id,taskId:id,bindingId:z.uuid(),capabilitySessionId:z.uuid(),sourceSnapshotHash:hash,runId:z.uuid(),generation:z.number().int().positive(),applicationPlanHash:hash,delivery:z.object({receiptId:z.uuid(),hash}).strict(),target:z.object({profileId:z.uuid(),profileRevision:revision,runner:id,profileRunner:id}).strict(),adapter:z.object({id,version:id,hash}).strict(),runtime:z.discriminatedUnion('kind',[external,managed]),createdAt:id}).strict();
const ownedHandles=new WeakMap();
function checkRuntime(store,plan,delivery){
 const r=plan.runtime;let path;
 if(r.kind==='external'){assert(isAbsolute(r.path),'ABSOLUTE_PATH_REQUIRED');assert.equal(realpathSync(r.path),r.path,'EXTERNAL_PATH_IDENTITY');path=r.path;}
 else{assert(!isAbsolute(r.file)&&r.file.split(/[\\/]/).every(x=>x&&x!=='.'&&x!=='..'),'RESOURCE_FILE_ESCAPE');const pin=delivery.resources.find(x=>x.resourceId===r.resourceId);assert(pin,'RUNTIME_NOT_PINNED');const resource=store.get(r.resourceId);assert(resource.state==='ready'&&resource.integrity==='valid'&&resource.contentHash===pin.contentHash&&resource.generation===pin.generation&&resource.relativePath===pin.relativePath,'RUNTIME_RESOURCE_CHANGED');const dir=realpathSync(store.directory(resource));path=join(dir,r.file);assert(realpathSync(path).startsWith(dir+'/'),'RESOURCE_FILE_ESCAPE');}
 assert.equal(digest(readFileSync(path)),r.sha256,'EXECUTABLE_BYTES_CHANGED');return path;
}
export function readExecution(store,runId,expectedHash,{live=false}={}){
 const db=store.sqlite,row=db.prepare('SELECT * FROM m14_execution_plan WHERE run_id=?').get(runId);assert(row,'EXECUTION_NOT_PREPARED');
 const p=executionSchema.parse(JSON.parse(row.plan_json));assert.equal(digest(canonical(p)),row.plan_hash,'EXECUTION_HASH_CHANGED');if(expectedHash!==undefined)assert.equal(row.plan_hash,expectedHash,'EXECUTION_EXPECTED_HASH');
 assert.equal(p.runId,runId,'EXECUTION_RUN_CHANGED');assert.equal(p.storeId,store.storeId,'EXECUTION_STORE_CHANGED');assert.equal(p.applicationPlanHash,row.application_plan_hash,'APPLICATION_HASH_CHANGED');assert.equal(p.delivery.receiptId,row.receipt_id);assert.equal(p.delivery.hash,row.receipt_hash);
 const receipt=db.prepare('SELECT * FROM m14_delivery WHERE receipt_id=?').get(row.receipt_id);assert(receipt,'DELIVERY_ABSENT');assert.equal(receipt.plan_hash,row.receipt_hash);const {plan:d,run}=inspect(db,receipt);
 for(const k of ['taskId','bindingId','capabilitySessionId','runId','generation'])assert.equal(p[k],d[k],'EXECUTION_SCOPE_CHANGED:'+k);
 assert.equal(p.sourceSnapshotHash,d.snapshotHash,'EXECUTION_SOURCE_CHANGED');assert.equal(p.target.profileId,d.profileId);assert.equal(p.target.profileRevision,d.profileRevision);assert.equal(p.target.runner,d.runner);assert.equal(p.target.profileRunner,d.profileRunner);
 const app=actual.readApplicationRunPlan(store,runId,p.applicationPlanHash);assert.equal(app.projectId,p.projectId,'EXECUTION_PROJECT_CHANGED');assert.equal(app.taskId,p.taskId);assert.equal(app.snapshotHash,p.sourceSnapshotHash,'APPLICATION_SOURCE_CHANGED');assert.equal(canonical(app.capabilityAdapter),canonical(p.adapter),'ADAPTER_CHANGED');
 const source=db.prepare('SELECT snapshot_json FROM m14_revision WHERE cap_id=? AND snapshot_hash=?').get(p.capabilitySessionId,run.snapshot_hash);assert(source,'CURRENT_REVISION_ABSENT');const snapshot=actual.storedCapabilitySessionSnapshotSchema.parse(JSON.parse(source.snapshot_json));actual.assertRunPlanSnapshotSource(store,app,snapshot,run.snapshot_hash);
 let executable;
 if(live){const profile=db.prepare('SELECT * FROM ai_profiles WHERE id=?').get(p.target.profileId);assert(profile&&!profile.command_pending&&profile.runner===p.target.profileRunner&&profileActual.builtinRunnerAdapters.get(profile.runner).describe().agentId===p.target.runner&&configurationRevision(db,p.target.profileId)===p.target.profileRevision,'TARGET_CONFIGURATION_CHANGED');assert(['prepared','adopted','released'].includes(receipt.phase),'DELIVERY_ABANDONED');assert(['prepared','active'].includes(run.state)&&run.revocation_state==='open','RUN_NOT_DISPATCHABLE');executable=checkRuntime(store,p,d);}
 return{plan:p,hash:row.plan_hash,applicationPlan:app,delivery:d,executable};
}
export async function prepareExecution(f,runtime,{checkpoint=()=>{}}={}){
 const {store,runs,run}=f;
 const config=capture(store.sqlite,f.profileService,f.profile);
 const result=await actual.withResourceLock(store.root,()=>store.sqlite.transaction(()=>{
  actual.assertOwnedCapabilityRun(runs,run);assert.equal(configurationRevision(store.sqlite,config.profileId),config.revision,'CONFIG_CHANGED_BEFORE_PLAN');
  const db=store.sqlite,existing=db.prepare('SELECT * FROM m14_execution_plan WHERE run_id=?').get(run.runId);
  if(existing){const prior=readExecution(store,run.runId,existing.plan_hash,{live:true});assert.equal(canonical(prior.plan.runtime),canonical(runtime),'EXECUTION_IMMUTABLE');return{hash:prior.hash};}
  const app=actual.verifyApplicationRunPlan(JSON.parse(db.prepare('SELECT plan_json FROM capability_resource_operations WHERE operation_id=?').get('application-run-plan:'+run.runId).plan_json));
  const key=prepareLocked(store,runs,run,f.adapter.resourceId,f.reader);checkpoint('after-pins');
  const receipt=db.prepare('SELECT * FROM m14_delivery WHERE receipt_id=?').get(key.receiptId),{plan:d}=inspect(db,receipt);
  const p=executionSchema.parse({schema:'m14-execution-plan-probe-v2',storeId:store.storeId,projectId:app.projectId,taskId:d.taskId,bindingId:d.bindingId,capabilitySessionId:d.capabilitySessionId,sourceSnapshotHash:d.snapshotHash,runId:d.runId,generation:d.generation,applicationPlanHash:app.planHash,delivery:{receiptId:d.receiptId,hash:key.planHash},target:{profileId:d.profileId,profileRevision:d.profileRevision,runner:d.runner,profileRunner:d.profileRunner},adapter:app.capabilityAdapter,runtime,createdAt:new Date().toISOString()});
  const json=canonical(p),hash=digest(json);db.prepare('INSERT INTO m14_execution_plan VALUES(?,?,?,?,?,?)').run(run.runId,d.receiptId,key.planHash,app.planHash,json,hash);checkpoint('after-plan');readExecution(store,run.runId,hash,{live:true});return{hash};
 }).immediate());
 const handle=Object.freeze({runId:run.runId,planHash:result.hash});ownedHandles.set(handle,{store,runs,run,config});return handle;
}
export async function dispatch(f,handle,consume){
 const owner=ownedHandles.get(handle);assert(owner&&owner.store===f.store&&owner.runs===f.runs&&owner.run===f.run,'EXECUTION_HANDLE_NOT_OWNED');actual.assertOwnedCapabilityRun(f.runs,f.run);
 const value=readExecution(f.store,handle.runId,handle.planHash,{live:true}),key={receiptId:value.delivery.receiptId,token:value.delivery.token,planHash:value.plan.delivery.hash};
 await adopt(f.store,f.runs,f.run,key);await releasePreparation(f.store,f.runs,f.run,key);
 actual.assertOwnedCapabilityRun(f.runs,f.run);const fresh=readExecution(f.store,handle.runId,handle.planHash,{live:true});return consume(fresh);
}

export function executionForLaunch(f,handle){const owned=ownedHandles.get(handle);assert(owned&&owned.store===f.store&&owned.runs===f.runs&&owned.run===f.run,'EXECUTION_HANDLE_NOT_OWNED');actual.assertOwnedCapabilityRun(f.runs,f.run);const verified=readExecution(f.store,handle.runId,handle.planHash,{live:true});assert.equal(owned.config.revision,verified.plan.target.profileRevision);const resolved=consume(f.store.sqlite,owned.config,p=>p);assert.equal(resolved.command,verified.executable,'CONFIG_EXECUTABLE_MISMATCH');return{...verified,resolved};}
