import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {createServer} from 'node:http';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,copyFileSync,existsSync,readFileSync} from 'node:fs';
import {nativeRuntime} from './native-inputs.mjs';
import {reply} from './model.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),frames=[],requests=[],controls=[],records=[],turns=[],reviews=[];
for(const n of ['probe.mjs','model.mjs','native-inputs.mjs'])copyFileSync(root+'/'+n,out+'/'+n);
const save=(n,v)=>writeFileSync(out+'/'+n,JSON.stringify(v,null,2)+'\n');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});promise.catch(()=>{});return{promise,resolve,reject};};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,r)=>timer=setTimeout(()=>r(Error('WATCHDOG:'+label)),25000))]).finally(()=>clearTimeout(timer));};
const reviewHeld=deferred(),reviewClosed=deferred(),firstReviewStarted=deferred(),firstReviewDone=deferred(),firstTurnDone=deferred(),secondReviewDone=deferred(),secondTurnDone=deferred();
const home=out+'/home',cwd=out+'/workspace',state=home+'/.codex',targets=[out+'/first-canceled.txt',out+'/second-allowed.txt'];for(const p of [home,cwd,state])mkdirSync(p,{recursive:true});
let base,error,serverError,thread,phase=0,heldResponse,heldBody,heldClosed=false;const primaryCounts=[0,0],reviewCounts=[0,0];
function control(name,extra={}){controls.push({name,frameCount:frames.length,phase,...extra});save('controls.json',controls);}
function env(){return{HOME:home,PATH:'/usr/bin:/bin',TMPDIR:out,LANG:'en_US.UTF-8',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1',CODEX_HOME:state,WY_MODEL_KEY:'synthetic-only'};}
function owned(command,args){const child=spawn(command,args,{cwd,env:env(),stdio:['pipe','pipe','pipe']}),r={pid:child.pid,command,args,exit:null};records.push({child,r});child.stdin.on('error',()=>{});child.stdout.on('data',b=>appendFileSync(out+'/stdout.jsonl',b));child.stderr.on('data',b=>appendFileSync(out+'/stderr.log',b));const done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>{r.exit={code,signal};resolve(r);});});return{child,r,done};}
function frame(m){
 frames.push(m);appendFileSync(out+'/frames.jsonl',JSON.stringify(m)+'\n');
 if(m.method==='item/autoApprovalReview/started'){
  reviews.push(m.params);if(reviews.length===1)firstReviewStarted.resolve(m.params);
 }
 if(m.method==='item/autoApprovalReview/completed'){
  if(m.params.reviewId===reviews[0]?.reviewId)firstReviewDone.resolve(m.params);else secondReviewDone.resolve(m.params);
 }
 if(m.method==='turn/completed'&&m.params.threadId===thread){
  if(m.params.turn.id===turns[0])firstTurnDone.resolve(m.params.turn);else secondTurnDone.resolve(m.params.turn);
 }
}
const approved=()=>JSON.stringify({risk_level:'low',user_authorization:'high',outcome:'allow',rationale:'Synthetic fixture approval'});
const server=createServer(async(req,res)=>{try{
 let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),isReview=body.text?.format?.schema?.properties?.outcome?.enum?.includes('allow');
 requests.push({phase,path:req.url,isReview:!!isReview,body});appendFileSync(out+'/requests.jsonl',JSON.stringify(requests.at(-1))+'\n');assert(requests.length<=10,'EXTRA_REQUESTS');
 if(isReview){reviewCounts[phase]++;assert.equal(reviewCounts[phase],1);assert(JSON.stringify(body.input).includes(targets[phase]));
  if(phase===0){heldResponse=res;heldBody=body;res.once('close',()=>{heldClosed=true;control('old-review-http-closed');reviewClosed.resolve();});control('first-review-held-before-response');reviewHeld.resolve();return;}
  reply(res,'codex',body,{text:approved()});return;
 }
 primaryCounts[phase]++;
 if(primaryCounts[phase]===1){const tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]),tool=tools.find(t=>t.name==='exec_command');assert(tool);reply(res,'codex',body,{tool,args:{cmd:"printf '%s' 'CANCEL_MARKER_"+phase+"' > '"+targets[phase]+"'",login:false,sandbox_permissions:'require_escalated',justification:'Isolated cancellation test file',yield_time_ms:10000,max_output_tokens:1000}});return;}
 assert.equal(phase,1,'CANCELED_PRIMARY_RESUMED');assert.equal(primaryCounts[phase],2);reply(res,'codex',body,{text:'SECOND_TURN_COMPLETE'});
 }catch(e){serverError??=e.stack;res.writeHead(500);res.end('{}');}});
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
 const p=owned(nativeRuntime('codex').path,['app-server','--disable','plugins','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(base+'/codex/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}']),waiting=new Map();let seq=0;
 const rpc=(method,params)=>{const id=++seq,d=deferred();waiting.set(id,d);p.child.stdin.write(JSON.stringify({id,method,params})+'\n');return deadline(d.promise,method);};
 createInterface({input:p.child.stdout}).on('line',line=>{try{const m=JSON.parse(line);frame(m);if(m.id!==undefined&&!m.method){const d=waiting.get(m.id);waiting.delete(m.id);m.error?d?.reject(Error(JSON.stringify(m.error))):d?.resolve(m.result);}if(m.id!==undefined&&m.method){p.child.stdin.write(JSON.stringify({id:m.id,error:{code:-32601,message:'No human approval surface in this auto test'}})+'\n');throw Error('UNEXPECTED_HUMAN_REQUEST:'+m.method);}}catch(e){serverError??=e.stack;}});
 try{
  await rpc('initialize',{clientInfo:{name:'m14_auto_cancel',version:'1'},capabilities:{experimentalApi:true}});p.child.stdin.write('{"method":"initialized"}\n');
  const r=await rpc('thread/start',{cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'on-request',approvalsReviewer:'auto_review',sandbox:'workspace-write'});thread=r.thread.id;
  const first=await rpc('turn/start',{threadId:thread,input:[{type:'text',text:'FIRST_CANCELLED_ACTION',text_elements:[]}]});turns.push(first.turn.id);
  await deadline(Promise.all([reviewHeld.promise,firstReviewStarted.promise]),'first review in flight');assert(!existsSync(targets[0]));control('interrupt-first-requested',{turnId:turns[0]});
  await rpc('turn/interrupt',{threadId:thread,turnId:turns[0]});control('interrupt-first-acknowledged');
  const [turn,review]=await deadline(Promise.all([firstTurnDone.promise,firstReviewDone.promise,reviewClosed.promise]),'native canceled review and turn');
  assert.equal(turn.status,'interrupted');assert.equal(review.review.status,'aborted');assert(heldClosed);assert(!existsSync(targets[0]));control('first-native-terminal',{turnStatus:turn.status,reviewStatus:review.review.status});
  control('late-response-not-deliverable',{destroyed:heldResponse.destroyed,writableEnded:heldResponse.writableEnded});assert(heldResponse.destroyed);
  phase=1;const second=await rpc('turn/start',{threadId:thread,input:[{type:'text',text:'SECOND_ALLOWED_ACTION',text_elements:[]}]});turns.push(second.turn.id);
  const [nextTurn,nextReview]=await deadline(Promise.all([secondTurnDone.promise,secondReviewDone.promise]),'second turn completed');assert.equal(nextTurn.status,'completed');assert.equal(nextReview.review.status,'approved');assert.equal(reviews.length,2);assert.notEqual(reviews[0].reviewId,reviews[1].reviewId);assert.notEqual(reviews[0].targetItemId,reviews[1].targetItemId);assert.notEqual(turns[0],turns[1]);assert.equal(readFileSync(targets[1],'utf8'),'CANCEL_MARKER_1');assert(!existsSync(targets[0]));control('new-review-and-turn-completed');
 }finally{p.child.stdin.end();await deadline(p.done,'native exit');}
 if(serverError)throw Error(serverError);assert.deepEqual(primaryCounts,[1,2]);assert.deepEqual(reviewCounts,[1,1]);assert(records.every(x=>x.r.exit?.code===0));
}catch(e){error=e.stack;process.exitCode=1;}finally{for(const p of records)if(!p.r.exit){p.child.kill('SIGTERM');await deadline(new Promise(r=>p.child.once('close',r)),'cleanup');}server.closeAllConnections();await new Promise(r=>server.close(r));}
const result={out,passed:!error,error:error??null,serverError:serverError??null,thread,turns,reviews,primaryCounts,reviewCounts,controls,firstFileExists:existsSync(targets[0]),secondFileExists:existsSync(targets[1]),processes:records.map(x=>x.r),scope:'Native Codex 0.167.1 auto-review canceled before any review response, followed by new turn in same live thread. Local controlled model, no business bridge or crash; old socket closed, no successful late response delivery claimed.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
