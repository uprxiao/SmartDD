from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_Codex自动审批与失败语义验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed'];p=Path(r['out']);frames=[json.loads(l)for l in(p/'frames.jsonl').read_text().splitlines()];requests=[json.loads(l)for l in(p/'requests.jsonl').read_text().splitlines()]
assert len(requests)==5 and r['primaryCounts']==[1,2]and r['reviewCounts']==[1,1];assert not r['firstFileExists']and r['secondFileExists'];assert all(x['exit']['code']==0 for x in r['processes'])
ends=[m['params']for m in frames if m.get('method')=='item/autoApprovalReview/completed'];assert len(ends)==2
for i,status in enumerate(['aborted','approved']):
 e=ends[i];s=r['reviews'][i];assert all(e[k]==s[k]for k in ['threadId','turnId','reviewId','targetItemId']);assert e['review']['status']==status
items=[m['params']for m in frames if m.get('method')=='item/completed'and m['params']['item']['type']=='commandExecution'];assert len(items)==2
assert items[0]['item']['status']=='declined'and items[0]['item']['processId']is None;assert items[1]['item']['status']=='completed'and items[1]['item']['exitCode']==0
assert items[0]['item']['id']==ends[0]['targetItemId'] and items[1]['item']['id']==ends[1]['targetItemId'];assert r['turns'][0]!=r['turns'][1]
assert next(x for x in r['controls']if x['name']=='late-response-not-deliverable')['destroyed'];assert not any(m.get('id')is not None and m.get('method') for m in frames)
refs=[t3/'packages/effect-codex-app-server/src/_generated/schema.gen.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'nativeVersion':'0.167.1','nativeHash':'Verified at spawn by native-inputs.mjs','sourceBoundary':'Generated review status includes aborted. T3 source referenced read-only; this probe does not run T3 or WillYou adapters.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[root/n for n in ['probe.mjs','model.mjs','native-inputs.mjs','prepare.py','source-review.json']]+sorted(f for f in p.iterdir()if f.is_file())
archive=root/'cancel-raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x in files:tar.add(x,arcname=str(x.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(x.relative_to(root)),'sha256':sha(x.read_bytes())}for x in files]}
for n,v in [('cancel-result.json',r),('cancel-source-review.json',review),('cancel-archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'cancel-raw-evidence.tar.gz',archive.read_bytes())
addition='''
## 补充：审查在途取消与同线程下一回合

新增一条真实 native 连续路径通过：第一回合自动审查请求到达本机服务但尚未返回任何响应时，宿主 turn/interrupt；同时等待审查 completed(aborted)、回合 interrupted 和原审查 HTTP 关闭。第一文件未创建，对应 commandExecution 为 declined、processId=null。不能把该 declined 显示成“用户拒绝”：本次来源是回合取消。

同一 native thread／同一 app-server 随后开启第二回合；reviewId、targetItemId、turnId 均为新身份。第二审查 approved，第二文件写入、命令 exitCode=0、回合 completed，第一文件仍不存在。五次本机模型请求，原生进程 exit 0，没有人工审批请求。

旧审查连接已经 destroyed，未尝试在断开的连接上伪造一次成功的迟到批准。这里只证明批准前取消及后续身份隔离，不证明批准已返回／命令已启动后的撤销，不涉及宿主崩溃、业务 MCP、资源租约或真实 UI。复跑 `node probe.mjs`，以 cancel 归档内的脚本为准。

[取消结果](cancel-result.json) · [取消源码基线](cancel-source-review.json) · [取消摘要](cancel-archive-manifest.json) · [取消原始记录](cancel-raw-evidence.tar.gz)。
'''
edit(exp/'README.md',lambda t:t+addition)
def tech(t):
 anchor='T3 生成 Schema 标注该通知形状不稳定，targetItemId 可空；'
 assert anchor in t
 paragraph='''同节[在途取消补验](实验/20261114_Codex自动审批与失败语义验证/README.md#补充审查在途取消与同线程下一回合)中，审查模型尚未返回时 interrupt 得到 review aborted、turn interrupted、旧 HTTP 关闭，命令项却是 declined／processId=null；第一文件未写。同线程下一回合使用新的 review／item／turn 身份，批准后仅新文件写入。统一层同时保留审查、命令和回合状态，不能把命令 declined 一律归为用户拒绝；旧审查终态不改写新回合。旧连接关闭并不证明“迟到批准已投递且被拒绝”，批准后／执行中的撤销与崩溃仍需另证。

'''
 assert paragraph not in t
 return t.replace(anchor,paragraph+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t
 addition='''#### 4.81.1 自动审查在途取消

[补充原生路径](实验/20261114_Codex自动审批与失败语义验证/README.md#补充审查在途取消与同线程下一回合)通过：审查响应未返回时中断，review aborted／turn interrupted／旧连接关闭，命令 declined 且无 processId，第一文件未写。同原生线程下一回合使用新 review／item／turn 身份并正常写第二文件，旧动作仍未执行。五次本机请求、原生 exit 0、零人工审批请求。

未向已关闭连接投递迟到批准，不宣称执行后撤销、崩溃恢复或业务排空；原生 declined 也可能来自取消，设计 §4.4.4 补三类状态的保留。Q11／12 继续部分，本次未新增宽口径问题项。

'''
 assert '#### 4.81.1 'not in t
 t=t.replace(anchor,addition+anchor).replace('截至 §4.81，56 个宽口径问题项中','截至 §4.81.1，56 个宽口径问题项中')
 t=t.replace('真实 UI／历史恢复、真实供应商审查、受管规则与业务联合仍待验；§4.60–4.61','§4.81.1 补审查未回应时取消及同线程新回合身份；真实 UI／历史恢复、真实供应商审查、受管规则与业务联合仍待验；§4.60–4.61')
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：自动审查在途取消与同线程下一回合已实跑；审查 aborted／命令 declined／回合 interrupted 各自保留，旧动作未写，新回合独立批准执行。见[技术方案 §4.4.4](技研/技术方案.md)，全局数量仍以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对剩余关键设计与证据，重点实际受管政策／只读边界、动态子树和业务排空；保留真实供应商与产品集成条件。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'continuousNativeScenarios':1,'archiveFiles':len(files),'localRequests':5}))
