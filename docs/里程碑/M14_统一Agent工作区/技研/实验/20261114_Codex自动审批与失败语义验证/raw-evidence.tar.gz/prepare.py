from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_Codex自动审批与失败语义验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
results=[json.loads((root/f'latest-codex-auto-{d}.json').read_text())for d in ['allow','deny','malformed','unavailable']];assert all(r['passed']for r in results)
summaries=[]
for r in results:
 p=Path(r['out']);frames=[json.loads(l)for l in(p/'frames.jsonl').read_text().splitlines()];reqs=[json.loads(l)for l in(p/'requests.jsonl').read_text().splitlines()]
 starts=[m['params']for m in frames if m.get('method')=='item/autoApprovalReview/started'];ends=[m['params']for m in frames if m.get('method')=='item/autoApprovalReview/completed'];assert len(starts)==len(ends)==1
 a,b=starts[0],ends[0];assert all(a[k]==b[k]for k in ['reviewId','threadId','turnId','targetItemId']);assert a['review']['status']=='inProgress';assert b['decisionSource']=='agent';assert b['review']['status']==('approved'if r['decision']=='allow'else'denied');assert not r['approvals'];assert r['turnResult']['status']=='completed';assert all(x['exit']['code']==0 for x in r['processes']);assert r['fileExists']==(r['decision']=='allow');assert len({x['path']for x in reqs})==1 and {x['body']['model']for x in reqs}=={'gpt-5.3-codex'}
 review=[x for x in reqs if x['body'].get('text',{}).get('format',{}).get('schema',{}).get('properties',{}).get('outcome')];assert len(review)==r['reviewRequests'];assert r['modelRequests']-r['reviewRequests']==2
 if r['decision']in ['malformed','unavailable']:
  assert b['review']['riskLevel']is None and b['review']['userAuthorization']is None;assert 'Automatic approval review failed'in b['review']['rationale'];assert 'not executed'in json.dumps(r['toolResult'])
 summaries.append({'decision':r['decision'],'reviewRequests':r['reviewRequests'],'primaryRequests':2,'review':b,'fileWritten':r['fileExists'],'parentTurnStatus':r['turnResult']['status']})
build=json.loads((root/'build.json').read_text());assert sha((root/'actual.cjs').read_bytes())==build['outputs'][0]['sha256']
for f in build['sources']:assert sha(Path(f['path']).read_bytes())==f['sha256']
refs=[repo/'src/shared/agent-permissions.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts',t3/'packages/effect-codex-app-server/src/_generated/schema.gen.ts',t3/'packages/effect-codex-app-server/src/_generated/meta.gen.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'permissionBundle':build,'version':'Codex 0.167.1, pinned native binary verified before spawn by native-inputs.mjs','sourceFindings':'T3 generated schema declares these review events UNSTABLE and targetItemId optional/null; decisionSource is agent. No autoApprovalReview registration/consumer found in current application sources in this read-only review. No T3 runtime/UI test in this batch.','bundleReuse':'Actual permission helper bundle reused from previous permission experiment; only mapping called, not AgentRuntimeService/PTY guard in this batch.'}
attempts=[]
for p in sorted(root.glob('attempt-*')):
 r=json.loads((p/'result.json').read_text());assert all(v['exit']is not None for v in r['processes']);attempts.append({'attempt':p.name,'passed':r['passed'],'decision':r['decision'],'error':r['error'],'serverError':r['serverError'],'requests':r['modelRequests'],'exit':[v['exit']for v in r['processes']]})
result={'checksPassed':4,'results':results,'summaries':summaries,'attempts':attempts,'paidModelCalls':0,'productChanges':0,'scope':'Native auto_review uses structured assessment via selected custom localhost provider. Synthetic allow/deny/invalid JSON/503 only; not live model judgment quality, real provider/model compatibility, managed policy, manual business approval, T3/WillYou UI or recovery.'}
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[root/n for n in ['probe.mjs','batch.mjs','batch-result.json','model.mjs','native-inputs.mjs','actual.cjs','build.json','prepare.py','result.json','source-review.json']]
for p in sorted(root.glob('attempt-*')):files+=sorted(f for f in p.iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files]}
for n,v in [('result.json',result),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# Codex 自动审批：模型路由与失败语义

依据 R0.2 R02／R08／R11、Q11／Q12。Codex 0.167.1 的四个 auto_review 分支通过。使用实际 WillYou agentPermission 的 auto 映射，候选 app-server policy 为 workspace-write／on-request／auto_review；仅自定义 localhost Provider、合成凭据与私有文件。没有真实模型判断、付费调用或产品修改。

| 审查响应 | 模型请求（主＋审查） | 原生事件与文件效果 |
| --- | --- | --- |
| 合法 allow | 2＋1 | started→completed approved；decisionSource=agent；文件写入 |
| 合法 deny | 2＋1 | completed denied，保留合成 riskLevel／userAuthorization／rationale；文件不存在 |
| 非法 JSON | 2＋3 | 审查重试后 denied，风险／授权字段 null，原因明确审查格式失败；文件不存在 |
| 审查端点 503 | 2＋12 | 审查重试后 denied，保留服务失败原因；文件不存在 |

每个完成事件的 reviewId／threadId／turnId／targetItemId 与开始事件一致，且 action 含真实拟执行命令／cwd。本轮所有审查和主模型请求都使用 gpt-5.3-codex 并到达相同 localhost 路由；审批模型请求带 JSON Schema，outcome 必填。没有人工 requestApproval RPC。四个父回合均 completed，四个 native 进程均 exit 0；工具拒绝或审查失败不等于整个对话失败。

失败时未改成 never／full，也未转到人工请求或偷偷放行；不能把 native 内部重试次数写成固定跨版本合同或成本上限。provider 配置 request_max_retries=0 并没有使此次审查链只发一次请求。生产须把审查活动、时间预算和原始失败原因纳入诊断，不能用主回合请求数估算整个运行请求数。

源码对照：T3 生成协议包含 item/autoApprovalReview started／completed，并标注 UNSTABLE；targetItemId 可空且可能多次审查指同一工具项。decisionSource=agent，userAuthorization 是审查模型的评级，不是用户回执。本次应用源码搜索未找到这些方法的适配器注册或 UI 消费；这只是静态范围结论，不是 T3 界面实测。WillYou 不可假定统一 UI 会从 T3 自动得到完整自动审查展示。

原始探索失败保留：初次驱动把额外审查请求当作主模型工具结果请求，返回了本机 500，且请求计数上限再次影响主模型，最终父回合 failed。读取真实 request Schema 后区分两类请求；后续四批各自正常收尾。首次失败是研究驱动错误，不能宣称真实服务繁忙或 auto 不支持自定义 Provider。

待验：真实供应商和模型是否支持相应结构化回复／上下文，审查质量与额外 token 计费，受管约束、审查中断与宿主退出、并发／多次同 target 审查、人工切换入口和完整业务联合。普通自动审批不得代替邮件／插件／浏览器的真人审阅证明。

复跑：node probe.mjs codex auto allow／deny／malformed／unavailable，或 allow 后 node batch.mjs；python3 prepare.py 核对事件、模型路由、结果与归档。需要 localhost 监听权限和 native-inputs 中固定依赖。复用的 permission bundle 来自上一批权限实验，源摘要保留。

[结果](result.json) · [源码](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 t=t.replace('来源为现有 --approve-for-me 的展开，分类器运行仍须验证','来源为现有 --approve-for-me 的展开；结构化审查机制见 §4.4.4，真实供应商／模型仍待验证')
 t=t.replace('Codex auto 分类器、受管策略限制、Claude 完整设置来源、历史／父子权限继承与所有业务联合继续待验','Codex auto 的真实供应商／模型、受管策略限制、Claude 完整设置来源、历史／父子权限继承与所有业务联合继续待验')
 section='''#### 4.4.4 自动审查的来源、失败与请求预算

[Codex auto_review 四分支实跑](实验/20261114_Codex自动审批与失败语义验证/README.md)证明当前固定版本可把额外的结构化审查请求发给选定的自定义 localhost Provider。本轮审查与主模型使用同一 model；这是该配置证据，不是任意账号／模型／供应商均支持 auto 的保证。需要单独核验结构化输出、审查上下文与服务条件，不因普通聊天可用就宣布自动审查可用。

自动审查是 native 产生的可观测活动，不是等待人工回答的 RuntimeRequest。保存 reviewId、binding／run／generation、原 thread／turn、可空 targetItemId、action、decisionSource、原生 review 状态和原因；同一工具可有多次审查，不用 targetItemId 去重，也不按 latest item 补空身份。只有真正的 live 原生 request 才提供人工回应入口。decisionSource=agent 和 userAuthorization 评级不能生成 WillYou 的 human-input／displayReceipt／业务许可。

本轮明确 deny、非法 JSON 和 503 最终都标为 denied；后两者原始原因明确是审查失败，文件均未写入，父 turn 仍 completed。公共模型保留 nativeStatus 与证据；不能仅凭 denied 区分“安全规则拒绝”“服务失败”或“用户拒绝”。没有稳定结构化失败类别时保留未知分类并展示原生原因，不以自由文本解析结果赋予权限或触发自动重试。免执行的终态与审查是否成功分开，完整 UI 不丢弃工具的拒绝／失败。

一次动作可能触发多次审查模型请求，本批非法 JSON 为三次、503 为十二次，虽 provider 的 request_max_retries 配置为零。这些是观测值，不是固定上限；运行预算、取消与诊断须包含内部审查活动，不仅统计主回合。在审查不可用时，不自动改成 full／never，也不当作真人已经批准。用户明确切换权限或另行请求人工审阅属于新的、可追踪的决定；业务原有审阅仍保留。

T3 生成 Schema 标注该通知形状不稳定，targetItemId 可空；本轮应用源码未找到对应适配器注册／UI 消费，不能把生成类型存在算完整功能支持。WillYou 的 native 适配应按精确版本处理通知和未知字段，并保留未支持诊断。真实服务、受管策略、并发审查／中断恢复及最终业务接线仍待验证。

'''
 assert '#### 4.4.4 'not in t
 return t.replace('### 4.5 长输出、背压与存储失败',section+'### 4.5 长输出、背压与存储失败')
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 assert '### 4.81 'not in t
 t=t.replace('真实 UI／历史恢复、auto 分类器、受管规则与业务联合仍待验；§4.60–4.61','§4.81 补 Codex auto_review 经自定义本机 Provider 的允许／拒绝／非法格式／503，失败不写且保留原生原因；真实 UI／历史恢复、真实供应商审查、受管规则与业务联合仍待验；§4.60–4.61')
 t=t.replace('## 5. 失败与驱动修正','''### 4.81 Codex 自动审批与失败语义

[四分支实验](实验/20261114_Codex自动审批与失败语义验证/README.md)通过：实际 auto_review 发起额外结构化审查请求，均走选定本机 Provider；合法 allow 写入，deny／非法 JSON／503 均不执行。开始／完成按 reviewId 和原作用域关联，decisionSource=agent；失败同样可以是 denied，必须保留理由，不能改写成用户拒绝。四个父回合 completed、四个 native exit 0。

审查请求观测为 1／1／3／12，配置主 provider retry=0 不保证内部审查一次；非跨版本预算。首轮驱动未区分审查 Schema 导致本机 500 与计数上限失败，原始记录保留；修正后四批通过，不把该失败归因真实服务。仅合成模型，未验真实供应商质量、受管规则、并发／取消／恢复与业务 UI。技术方案 §4.4.4 更新，Q12 仍部分。

## 5. 失败与驱动修正''')
 t=t.replace('截至 §4.80，56 个宽口径问题项中','截至 §4.81，56 个宽口径问题项中')
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：Codex auto_review 的自定义本机 Provider 路由、允许／拒绝／格式与服务失败已实跑；自动审查失败不可当作用户拒绝，见[技术方案 §4.4.4](技研/技术方案.md)。Q12 保持部分，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的受管政策、动态子树与业务排空；补齐审查事件在统一合同中的身份和能力边界，真实服务与产品集成另行保留。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'checks':4,'attempts':len(attempts),'archiveFiles':len(files),'modelRequestsIncludingInitialFailure':sum(x['requests']for x in attempts)}))
