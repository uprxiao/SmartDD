import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const results=[];
for(const decision of ['deny','malformed','unavailable']){
 const r=spawnSync(process.execPath,[import.meta.dirname+'/probe.mjs','codex','auto',decision],{encoding:'utf8',maxBuffer:2*1024*1024});
 results.push({decision,exit:r.status,stdout:r.stdout,stderr:r.stderr});process.stdout.write(r.stdout);if(r.stderr)process.stderr.write(r.stderr);
}
writeFileSync(import.meta.dirname+'/batch-result.json',JSON.stringify(results,null,2));if(results.some(x=>x.exit!==0))process.exitCode=1;
