#!/bin/sh
unset NODE_OPTIONS
export ELECTRON_RUN_AS_NODE=1
exec '/opt/homebrew/Cellar/node/26.5.0_1/bin/node' '/private/tmp/willyou-m14-f05-mcp-contract/attempt-viOrGy/claude-url/projection/wy-mcp-launch.cjs' --plan '/private/tmp/willyou-m14-f05-mcp-contract/attempt-viOrGy/claude-url/projection/claude.json'
