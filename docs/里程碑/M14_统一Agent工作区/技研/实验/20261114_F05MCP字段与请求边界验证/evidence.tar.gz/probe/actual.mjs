// ../SmartDD/src/main/core/capabilities/mcp-source.ts
var McpSourceError = class extends Error {
  constructor(reason, variable) {
    super(variable ? `\u7F3A\u5C11\u53D8\u91CF ${variable}\uFF1B\u8BF7\u5728\u6765\u6E90 CLI \u7684\u73AF\u5883\u4E2D\u914D\u7F6E\u540E\u91CD\u8BD5` : reason);
    this.reason = reason;
    this.variable = variable;
  }
};
function applyMcpNativePolicy(source, policy) {
  if (!policy) return source;
  if (policy.unverified) throw new McpSourceError("\u6765\u6E90\u6743\u9650\u914D\u7F6E\u5C1A\u4E0D\u80FD\u7B49\u4EF7\u8F6C\u6362\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
  const result = { ...source, disabledTools: [...source.disabledTools], approvedTools: [...source.approvedTools], promptTools: [...source.promptTools] };
  for (const kind of ["allow", "deny", "ask"]) for (const rule of policy[kind]) {
    if (rule === "*" || rule === `mcp__${source.name}` || rule === `mcp__${source.name}__*`) {
      if (kind === "deny") result.enabled = false;
      else if (kind === "allow") result.defaultApproval = "approve";
      else throw new McpSourceError("\u6765\u6E90\u8981\u6C42\u9010\u4E2A\u8BE2\u95EE\u5168\u90E8\u5DE5\u5177\uFF0C\u5C1A\u4E0D\u80FD\u7B49\u4EF7\u8F6C\u6362\uFF1B\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
      continue;
    }
    if (!rule.startsWith("mcp__")) continue;
    const prefix = `mcp__${source.name}__`;
    if (rule.startsWith(prefix)) {
      const tool = rule.slice(prefix.length);
      if (!TOOL.test(tool)) throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u6743\u9650\u5305\u542B\u5C1A\u4E0D\u652F\u6301\u7684\u5339\u914D\u89C4\u5219\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
      result[kind === "allow" ? "approvedTools" : kind === "deny" ? "disabledTools" : "promptTools"].push(tool);
    } else if (rule.includes("*") || rule.includes("?")) throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u6743\u9650\u5305\u542B\u5C1A\u4E0D\u652F\u6301\u7684\u5339\u914D\u89C4\u5219\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
  }
  return result;
}
var NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
var TOOL = /^[A-Za-z0-9_.-]{1,128}$/;
var object = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var invalid = () => {
  throw new McpSourceError("MCP \u58F0\u660E\u683C\u5F0F\u65E0\u6548\uFF1B\u8BF7\u5728\u6765\u6E90 CLI \u4E2D\u4FEE\u590D");
};
function string(v) {
  if (typeof v !== "string" || v.includes("\0") || v.length > 65536) return invalid();
  return v;
}
function strings(v) {
  if (!Array.isArray(v) || v.length > 4096) return invalid();
  return v.map(string);
}
function mcpValue(value, runner) {
  if (runner !== "claude") return { literal: value };
  const parts = [], pattern = /\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}/g;
  let cursor = 0, match;
  while (match = pattern.exec(value)) {
    if (match.index > cursor) parts.push({ text: value.slice(cursor, match.index) });
    parts.push({ ref: match[1], ...match[2] !== void 0 ? { fallback: match[2] } : {} });
    cursor = pattern.lastIndex;
  }
  if (!parts.length) return { literal: value };
  if (cursor < value.length) parts.push({ text: value.slice(cursor) });
  return { parts };
}
function evaluateMcpValue(value, env) {
  if ("literal" in value) return value.literal;
  return value.parts.map((part) => {
    if ("text" in part) return part.text;
    if (Object.hasOwn(env, part.ref) && env[part.ref] !== void 0) return env[part.ref];
    if (part.fallback !== void 0) return part.fallback;
    throw new McpSourceError("missing_variable", part.ref);
  }).join("");
}
function mcpReferenceNames(source, environment) {
  const names = /* @__PURE__ */ new Set();
  const add = (value) => {
    if ("parts" in value) {
      for (const part of value.parts) if ("ref" in part) names.add(part.ref);
    }
  };
  for (const value of [...source.args, ...Object.values(source.env), ...Object.values(source.headers)]) add(value);
  if (source.runner === "claude") for (const value of Object.values(source.headers)) try {
    add(mcpValue(evaluateMcpValue(value, environment), "claude"));
  } catch {
  }
  return [...names].sort();
}
function mcpUrlIssue(value) {
  if (value.includes("${")) return "\u4E0D\u652F\u6301\u8F6C\u6362\uFF1AURL \u542B\u51ED\u636E\uFF08\u53D8\u91CF\u5F15\u7528\uFF09\uFF1B\u6539\u7528\u8BF7\u6C42\u5934\u6216\u73AF\u5883\u53D8\u91CF\u9274\u6743";
  let url;
  try {
    url = new URL(value);
  } catch {
    return "MCP URL \u65E0\u6548";
  }
  if (!["http:", "https:"].includes(url.protocol)) return "MCP URL \u4EC5\u652F\u6301 HTTP \u6216 HTTPS";
  const sensitive = (key) => {
    const normalized = key.toLowerCase().replace(/[-_.\s]/g, "");
    return /token|apikey|accesskey|secret|password|passwd|authorization|signature|credential|bearer|session/.test(normalized) || ["key", "pwd", "auth", "sig", "code", "sid"].includes(normalized);
  };
  if (url.username || url.password || [...url.searchParams.keys()].some(sensitive) || /[?&#=]/.test(url.hash)) return "\u4E0D\u652F\u6301\u8F6C\u6362\uFF1AURL \u542B\u51ED\u636E\uFF1B\u6539\u7528\u8BF7\u6C42\u5934\u6216\u73AF\u5883\u53D8\u91CF\u9274\u6743";
  return null;
}
function parseMcpSource(name, runner, raw) {
  if (!/^[A-Za-z0-9_-]{1,128}$/.test(name) || !object(raw)) return invalid();
  if (runner !== "claude" && runner !== "codex") throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u5C1A\u4E0D\u652F\u6301 MCP \u8F6C\u6362");
  const transport = raw.url !== void 0 ? raw.type === "sse" ? "sse" : "http" : "stdio";
  const source = { name, runner, transport, args: [], env: /* @__PURE__ */ Object.create(null), headers: /* @__PURE__ */ Object.create(null), disabledTools: [], allowedTools: null, approvedTools: [], promptTools: [], defaultApproval: "prompt", enabled: raw.enabled !== false && raw.disabled !== true, oauthRequired: raw.oauth === true || object(raw.auth) && raw.auth.type === "oauth" };
  if (raw.headersHelper !== void 0 || raw.http_headers_helper !== void 0) throw new McpSourceError("\u6765\u6E90\u4F9D\u8D56\u8BA4\u8BC1\u811A\u672C\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E\uFF1B\u626B\u63CF\u4E0D\u4F1A\u6267\u884C\u811A\u672C");
  if (raw.default_tools_approval_mode !== void 0) {
    if (!["prompt", "approve"].includes(String(raw.default_tools_approval_mode))) throw new McpSourceError("\u6765\u6E90 MCP \u7684\u81EA\u52A8\u5206\u7C7B\u5BA1\u6279\u5C1A\u4E0D\u652F\u6301\u8DE8\u5DE5\u5177\u8F6C\u6362");
    source.defaultApproval = raw.default_tools_approval_mode;
  }
  const values = (input, target, names) => {
    if (input === void 0) return;
    if (!object(input)) return invalid();
    for (const [k, v] of Object.entries(input)) {
      if (names === "env" ? !NAME.test(k) : !/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(k)) return invalid();
      target[k] = mcpValue(string(v), runner);
    }
  };
  if (transport === "stdio") {
    source.command = string(raw.command);
    if (!source.command.trim() || source.command.includes("${")) throw new McpSourceError("\u4E0D\u652F\u6301\u8F6C\u6362\uFF1Acommand \u542B\u53D8\u91CF\u5F15\u7528\u6216\u4E3A\u7A7A");
    if (/\.app\/(?:Contents\/)?/i.test(source.command)) throw new McpSourceError("\u547D\u4EE4\u4F4D\u4E8E\u5176\u4ED6\u5E94\u7528\u5305\u5185\uFF0C\u4E0D\u80FD\u8FC1\u79FB");
    source.args = (raw.args === void 0 ? [] : strings(raw.args)).map((v) => mcpValue(v, runner));
    values(raw.env, source.env, "env");
    if (raw.cwd !== void 0) source.cwd = string(raw.cwd);
    if (runner === "codex" && raw.env_vars !== void 0) for (const key of strings(raw.env_vars)) {
      if (!NAME.test(key)) return invalid();
      if (!Object.hasOwn(source.env, key)) source.env[key] = { parts: [{ ref: key }] };
    }
  } else {
    source.url = string(raw.url);
    const issue = mcpUrlIssue(source.url);
    if (issue) throw new McpSourceError(issue);
    values(runner === "codex" ? raw.http_headers : raw.headers, source.headers, "headers");
    if (runner === "codex" && raw.env_http_headers !== void 0) {
      if (!object(raw.env_http_headers)) return invalid();
      for (const [header, key] of Object.entries(raw.env_http_headers)) {
        if (!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(header) || typeof key !== "string" || !NAME.test(key)) return invalid();
        source.headers[header] = { parts: [{ ref: key }] };
      }
    }
    if (runner === "codex" && raw.bearer_token_env_var !== void 0) {
      const key = string(raw.bearer_token_env_var);
      if (!NAME.test(key)) return invalid();
      source.headers.Authorization = { parts: [{ text: "Bearer " }, { ref: key }] };
    }
  }
  const tools = (v) => strings(v).map((name2) => {
    if (!TOOL.test(name2)) throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u540D\u79F0\u65E0\u6CD5\u53EF\u9760\u6620\u5C04\u5BA1\u6279\u89C4\u5219\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
    return name2;
  });
  if (raw.disabled_tools !== void 0) source.disabledTools = tools(raw.disabled_tools);
  if (raw.enabled_tools !== void 0) source.allowedTools = tools(raw.enabled_tools);
  if (raw.tools !== void 0) {
    if (!object(raw.tools)) return invalid();
    for (const [tool, policy] of Object.entries(raw.tools)) {
      if (!TOOL.test(tool)) throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u540D\u79F0\u65E0\u6CD5\u53EF\u9760\u6620\u5C04\u5BA1\u6279\u89C4\u5219\uFF0C\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
      if (!object(policy)) return invalid();
      if (policy.enabled === false || policy.approval_mode === "deny") source.disabledTools.push(tool);
      else if (policy.approval_mode === "approve") source.approvedTools.push(tool);
      else if (policy.approval_mode === "prompt") source.promptTools.push(tool);
    }
  }
  return source;
}
function resolveMcpSource(source, environment, target) {
  if (!source.enabled) throw new McpSourceError("\u6765\u6E90\u5DF2\u505C\u7528\uFF0C\u4E0D\u6CE8\u5165");
  if (source.oauthRequired) throw new McpSourceError(`\u9700\u5728 ${target === "codex" ? "Codex" : "Claude Code"} \u5355\u72EC\u8BA4\u8BC1${target === "codex" ? "\uFF1B\u8BF7\u8FD0\u884C codex mcp login" : ""}`);
  if (source.transport === "sse" && target === "codex") throw new McpSourceError("Codex \u4E0D\u652F\u6301 SSE");
  const env = /* @__PURE__ */ Object.create(null), headers = /* @__PURE__ */ Object.create(null);
  for (const [k, value] of Object.entries(source.env)) env[k] = evaluateMcpValue(value, environment);
  const args = source.args.map((value) => evaluateMcpValue(value, environment));
  for (const [k, value] of Object.entries(source.headers)) {
    const first = evaluateMcpValue(value, environment);
    const resolved = source.runner === "claude" ? evaluateMcpValue(mcpValue(first, "claude"), environment) : first;
    if (/[\r\n]/.test(resolved)) throw new McpSourceError("\u8BF7\u6C42\u5934\u503C\u5305\u542B\u975E\u6CD5\u6362\u884C");
    headers[k] = resolved;
  }
  return { ...source, args, env, headers };
}

// ../SmartDD/src/main/core/capabilities/mcp-conversion.ts
import { join, isAbsolute } from "node:path";
var shell = (text) => "'" + text.replaceAll("'", `'"'"'`) + "'";
function convertMcp(input) {
  if (!/^[A-Za-z0-9_]{1,64}$/.test(input.serverId) || ![input.runRoot, input.cwd, input.executable].every(isAbsolute)) throw new McpSourceError("MCP \u672C\u6B21\u8FD0\u884C\u8DEF\u5F84\u6216\u8EAB\u4EFD\u65E0\u6548");
  const source = resolveMcpSource(input.source, input.sourceEnvironment, input.target);
  if (input.target === "claude" && source.allowedTools !== null) throw new McpSourceError("\u6765\u6E90\u5DE5\u5177\u767D\u540D\u5355\u5C1A\u4E0D\u80FD\u7B49\u4EF7\u8F6C\u6362\u5230 Claude Code\uFF1B\u8BF7\u5728\u76EE\u6807 CLI \u5355\u72EC\u914D\u7F6E");
  if (Object.keys(source.env).some((name) => name.startsWith("WY_MCPV_"))) throw new McpSourceError("MCP \u81EA\u6709\u73AF\u5883\u53D8\u91CF\u4E0D\u80FD\u5360\u7528 WillYou \u79C1\u6709\u69FD\u524D\u7F00");
  const env = /* @__PURE__ */ Object.create(null), files = [], permissionArgs = [];
  let counter = 0;
  const slot = (value) => {
    const key = `WY_MCPV_${input.serverId}_${++counter}`;
    env[key] = value;
    return { slot: key };
  };
  const launcher = join(input.runRoot, "wy-mcp-launch.cjs"), planPath = join(input.runRoot, input.serverId + ".json");
  const result = { env, files, permissionArgs, serverName: source.name, claudeAskTools: [] };
  const tools = /* @__PURE__ */ Object.create(null);
  for (const tool of source.approvedTools) if (!source.disabledTools.includes(tool)) tools[tool] = { approval_mode: "approve" };
  for (const tool of source.promptTools) if (!source.disabledTools.includes(tool)) tools[tool] = { approval_mode: "prompt" };
  const defaultApproval = input.autoApprove ? "approve" : source.defaultApproval;
  if (input.target === "claude") {
    for (const tool of source.disabledTools) permissionArgs.push("--disallowedTools", `mcp__${source.name}__${tool}`);
    for (const tool of source.approvedTools) if (!source.disabledTools.includes(tool)) permissionArgs.push("--allowedTools", `mcp__${source.name}__${tool}`);
    if (defaultApproval === "approve") permissionArgs.push("--allowedTools", `mcp__${source.name}__*`);
    result.claudeAskTools = source.promptTools.filter((tool) => !source.disabledTools.includes(tool)).map((tool) => `mcp__${source.name}__${tool}`);
  }
  if (source.transport === "stdio") {
    const ownEnv = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(source.env)) ownEnv[name] = slot(value);
    const plan = { version: 1, mode: "spawn", serverId: input.serverId, command: source.command, args: source.args.map(slot), cwd: source.cwd ?? input.cwd, ownEnv, stripNames: input.stripNames };
    files.push({ path: launcher, content: input.launcherSource, mode: 384 }, { path: planPath, content: JSON.stringify(plan, null, 2) + "\n", mode: 384 });
    const server = { command: input.executable, args: [launcher, "--plan", planPath], env: { ELECTRON_RUN_AS_NODE: "1", NODE_OPTIONS: "" } };
    if (input.target === "claude") result.claudeServer = { type: "stdio", ...server };
    else result.codexServer = { ...server, env_vars: Object.keys(env), default_tools_approval_mode: defaultApproval, ...source.disabledTools.length ? { disabled_tools: source.disabledTools } : {}, ...source.allowedTools ? { enabled_tools: source.allowedTools } : {}, ...Object.keys(tools).length ? { tools } : {} };
  } else {
    const headers = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(source.headers)) headers[name] = slot(value);
    if (input.target === "codex") {
      const empty = Object.keys(headers).filter((name) => source.headers[name] === "");
      const nonempty = Object.entries(headers).filter(([name]) => source.headers[name] !== "");
      result.codexServer = { url: source.url, default_tools_approval_mode: defaultApproval, ...empty.length ? { http_headers: Object.fromEntries(empty.map((name) => [name, ""])) } : {}, ...nonempty.length ? { env_http_headers: Object.fromEntries(nonempty.map(([name, ref]) => [name, ref.slot])) } : {}, ...source.disabledTools.length ? { disabled_tools: source.disabledTools } : {}, ...source.allowedTools ? { enabled_tools: source.allowedTools } : {}, ...Object.keys(tools).length ? { tools } : {} };
    } else {
      result.claudeServer = { type: source.transport, url: source.url };
      if (counter) {
        files.push({ path: launcher, content: input.launcherSource, mode: 384 }, { path: planPath, content: JSON.stringify({ version: 1, mode: "headers", serverId: input.serverId, headers }, null, 2) + "\n", mode: 384 });
        const helper = join(input.runRoot, input.serverId + "-headers.sh");
        files.push({ path: helper, mode: 448, content: `#!/bin/sh
unset NODE_OPTIONS
export ELECTRON_RUN_AS_NODE=1
exec ${shell(input.executable)} ${shell(launcher)} --plan ${shell(planPath)}
` });
        result.claudeServer.headersHelper = helper;
      }
    }
  }
  return result;
}

// ../SmartDD/src/main/core/capabilities/mcp-projection.ts
import { createHash } from "node:crypto";
import { existsSync, lstatSync, mkdirSync, realpathSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, join as join2, relative, resolve, sep } from "node:path";
var bundled = {};
var launcherSource = Object.entries(bundled).find(([path]) => path.endsWith("/wy-mcp-launch.cjs"))?.[1];
var inside = (base, path) => {
  const rest = relative(base, resolve(path));
  return Boolean(rest) && rest !== ".." && !rest.startsWith(".." + sep);
};
var inline = (value) => {
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return "[" + value.map(inline).join(",") + "]";
  if (value && typeof value === "object") return "{" + Object.entries(value).map(([k, v]) => JSON.stringify(k) + "=" + inline(v)).join(",") + "}";
  throw new Error("MCP \u914D\u7F6E\u503C\u4E0D\u80FD\u53EF\u9760\u8F6C\u6362");
};
function writeControls(userData, runRoot, files) {
  const base = realpathSync(userData), runs = join2(base, "agents", "runs");
  if (!inside(runs, runRoot) || !/^[-a-f0-9]{36}\/mcp$/.test(relative(runs, runRoot).split(sep).join("/"))) throw new Error("MCP \u672C\u6B21\u8FD0\u884C\u76EE\u5F55\u8EAB\u4EFD\u65E0\u6548");
  const unique = /* @__PURE__ */ new Map();
  for (const file of files) {
    if (!inside(runRoot, file.path) || dirname(file.path) !== runRoot) throw new Error("MCP \u914D\u7F6E\u8D85\u51FA\u672C\u6B21\u8FD0\u884C\u76EE\u5F55");
    const old = unique.get(file.path);
    if (old && (old.content !== file.content || old.mode !== file.mode)) throw new Error("MCP \u63A7\u5236\u6587\u4EF6\u540C\u540D\u51B2\u7A81");
    unique.set(file.path, file);
  }
  let current = base;
  for (const part of relative(base, runRoot).split(sep)) {
    current = join2(current, part);
    if (!existsSync(current)) mkdirSync(current, { mode: 448 });
    const st = lstatSync(current);
    if (!st.isDirectory() || st.isSymbolicLink() || process.getuid && st.uid !== process.getuid()) throw new Error("MCP \u7BA1\u7406\u76EE\u5F55\u8EAB\u4EFD\u5F02\u5E38");
  }
  const written = [];
  try {
    for (const file of unique.values()) {
      writeFileSync(file.path, file.content, { flag: "wx", mode: file.mode });
      written.push(file.path);
    }
  } catch (error) {
    for (const path of written) unlinkSync(path);
    throw error;
  }
}
var McpProjectionService = class {
  constructor(registry, options) {
    this.registry = registry;
    this.options = options;
  }
  prepare(input) {
    const result = { args: [], env: /* @__PURE__ */ Object.create(null), secretValues: [], configured: [], issues: [] };
    const files = [], claude = /* @__PURE__ */ Object.create(null), ask = [];
    const runRoot = join2(input.runRoot, "mcp");
    for (const item of this.registry.selected(input.cwd).filter((row) => row.kind === "mcp")) {
      try {
        const resolved = this.registry.resolveMcpSource(item.id);
        if (!resolved) throw new McpSourceError("\u6765\u6E90\u5DF2\u5220\u9664\uFF0C\u8BF7\u91CD\u65B0\u626B\u63CF");
        const references = mcpReferenceNames(resolved.source, resolved.environment);
        const needsSecret = references.some((name) => resolved.secretEnvNames?.includes(name));
        const environment = { ...resolved.environment, ...resolved.configurationId && needsSecret ? this.options.profileEnvironment?.(resolved.configurationId) : {} };
        const source = { ...resolved.source, env: { ...resolved.source.env } };
        if (environment.PATH && !Object.hasOwn(source.env, "PATH")) source.env.PATH = { literal: environment.PATH };
        if (source.cwd) source.cwd = resolve(input.cwd, source.cwd);
        if (source.command?.includes("/") && !source.command.startsWith("/")) source.command = resolve(source.cwd ?? input.cwd, source.command);
        const conversion = convertMcp({
          source,
          target: input.runner,
          serverId: createHash("sha256").update(item.id).digest("hex").slice(0, 32),
          sourceEnvironment: environment,
          runRoot,
          cwd: input.cwd,
          executable: this.options.executable,
          launcherSource: this.options.launcherSource ?? launcherSource ?? "",
          stripNames: [.../* @__PURE__ */ new Set([...input.injectedNames, "NODE_OPTIONS"])],
          autoApprove: item.autoApprove
        });
        if (!conversion.files.every((file) => typeof file.content === "string")) throw new McpSourceError("MCP \u8FD0\u884C\u8D44\u4EA7\u7F3A\u5931\uFF0C\u8BF7\u91CD\u65B0\u5B89\u88C5 WillYou");
        files.push(...conversion.files);
        Object.assign(result.env, conversion.env);
        result.secretValues.push(...Object.values(conversion.env).filter(Boolean));
        if (input.runner === "codex") result.args.push("-c", `mcp_servers.${conversion.serverName}=${inline(conversion.codexServer)}`);
        else {
          claude[conversion.serverName] = conversion.claudeServer;
          result.args.push(...conversion.permissionArgs);
          ask.push(...conversion.claudeAskTools);
        }
        result.configured.push(item.id);
      } catch (error) {
        result.issues.push({ id: item.id, reason: error instanceof McpSourceError ? error.message : "\u6765\u6E90\u914D\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u5728\u6765\u6E90 CLI \u68C0\u67E5\u540E\u91CD\u65B0\u626B\u63CF" });
      }
    }
    if (Object.keys(claude).length) {
      const path = join2(runRoot, "servers.json");
      files.push({ path, content: JSON.stringify({ mcpServers: claude }, null, 2) + "\n", mode: 384 });
      result.args.push("--mcp-config", path);
    }
    if (ask.length) {
      const path = join2(runRoot, "permissions.json");
      files.push({ path, content: JSON.stringify({ permissions: { ask } }, null, 2) + "\n", mode: 384 });
      result.args.push("--settings", path);
    }
    if (files.length) writeControls(this.options.userData, runRoot, files);
    return result;
  }
};
export {
  McpProjectionService,
  McpSourceError,
  applyMcpNativePolicy,
  convertMcp,
  evaluateMcpValue,
  mcpReferenceNames,
  mcpUrlIssue,
  mcpValue,
  parseMcpSource,
  resolveMcpSource
};
