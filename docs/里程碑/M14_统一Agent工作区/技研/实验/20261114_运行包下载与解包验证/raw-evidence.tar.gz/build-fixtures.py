from pathlib import Path
import tarfile,json,hashlib,io
p=Path(__file__).resolve().parent;data=p/'data';data.mkdir(exist_ok=True);source=Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin');prior=Path('/private/tmp/willyou-m14-native-artifact-probe');manifest=json.loads((Path(json.loads((prior/'latest.json').read_text())['out'])/'native-manifest.json').read_text())
archive=data/'codex-local.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=1)as tar:
 for f in manifest['files']:tar.add(source/f['path'],arcname=f['path'],recursive=False)
text=b'#!/bin/sh\nprintf synthetic-package\n';tiny={'schema':1,'driver':'fixture','version':'1','platform':'darwin','arch':'arm64','entry':'bin/runner','files':[{'path':'bin/runner','size':len(text),'sha256':hashlib.sha256(text).hexdigest(),'executable':True}]}
items={}
for name in ['good','traversal','symlink','hardlink','duplicate','wrong-file','extra','oversize']:
 f=data/(name+'.tar.gz')
 with tarfile.open(f,'w:gz')as t:
  x=tarfile.TarInfo('bin/runner');x.mode=0o500;x.size=len(text)+(1 if name=='oversize'else 0);t.addfile(x,io.BytesIO(text+b'x' if name=='oversize'else b'x'*len(text) if name=='wrong-file'else text))
  if name not in ['good','wrong-file','oversize']:
   y=tarfile.TarInfo({'traversal':'../escape','symlink':'bin/alias','hardlink':'bin/alias','duplicate':'bin/runner','extra':'extra','oversize':'oversize'}[name]);y.mode=0o500;y.size=1
   if name in ['symlink','hardlink']:y.type=tarfile.SYMTYPE if name=='symlink'else tarfile.LNKTYPE;y.linkname='../escape';y.size=0;t.addfile(y)
   else:t.addfile(y,io.BytesIO(b'x'))
 items[name]={'archive':str(f),'manifest':tiny}
items['native']={'archive':str(archive),'manifest':manifest}
for v in items.values():
 h=hashlib.sha256()
 with Path(v['archive']).open('rb')as f:
  for b in iter(lambda:f.read(262144),b''):h.update(b)
 v['lock']={'bytes':Path(v['archive']).stat().st_size,'sha256':h.hexdigest()}
(p/'fixtures.json').write_text(json.dumps(items,indent=2));print(json.dumps({k:v['lock']['bytes']for k,v in items.items()}))
