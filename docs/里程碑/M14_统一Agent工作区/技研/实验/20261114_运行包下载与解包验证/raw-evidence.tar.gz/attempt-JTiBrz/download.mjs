import assert from 'node:assert/strict';
import {mkdir,mkdtemp,rm,rename,chmod,stat} from 'node:fs/promises';
import {createWriteStream} from 'node:fs';
import {join} from 'node:path';
import {Readable,Transform} from 'node:stream';
import {pipeline} from 'node:stream/promises';
import {createHash} from 'node:crypto';
import {hashFile} from './artifact.mjs';
export async function download(url,lock,cache,{offline=false,signal,approvedOrigins,onChunk}={}){
 assert(Number.isSafeInteger(lock.bytes)&&lock.bytes>0&&lock.bytes<=512*1024*1024&&/^[a-f0-9]{64}$/.test(lock.sha256),'INVALID_ARCHIVE_LOCK');await mkdir(cache,{recursive:true,mode:0o700});const target=join(cache,lock.sha256+'.tar.gz');
 let exists=false;try{const info=await stat(target);assert(info.isFile(),'CACHE_NOT_FILE');exists=true;}catch(e){if(e.code!=='ENOENT')throw e;}
 if(exists){const bytes=await hashFile(target);if(bytes.size===lock.bytes&&bytes.sha256===lock.sha256)return{path:target,cacheHit:true,bytes:bytes.size};assert(!offline,'OFFLINE_CACHE_CORRUPT');}
 assert(!offline,'OFFLINE_CACHE_MISSING');const work=await mkdtemp(join(cache,'partial-')),part=join(work,'download');let current=new URL(url),response;
 try{for(let redirects=0;;redirects++){assert(approvedOrigins.has(current.origin)&&!current.username&&!current.password,'REDIRECT_NOT_APPROVED');assert(current.protocol==='https:'||(current.protocol==='http:'&&current.hostname==='127.0.0.1'),'SCHEME_NOT_APPROVED');response=await fetch(current,{redirect:'manual',signal});if([301,302,303,307,308].includes(response.status)){assert(redirects<3,'REDIRECT_LIMIT');const location=response.headers.get('location');await response.body?.cancel();assert(location,'REDIRECT_LOCATION_MISSING');current=new URL(location,current);continue;}break;}
 assert.equal(response.status,200,'DOWNLOAD_HTTP_STATUS');const length=response.headers.get('content-length');if(length!==null)assert.equal(Number(length),lock.bytes,'ARCHIVE_LENGTH_MISMATCH');assert(response.body,'ARCHIVE_BODY_MISSING');let bytes=0,maxChunk=0;const digest=createHash('sha256'),meter=new Transform({transform(chunk,_enc,callback){try{bytes+=chunk.length;maxChunk=Math.max(maxChunk,chunk.length);assert(bytes<=lock.bytes,'ARCHIVE_OVERFLOW');digest.update(chunk);onChunk?.({bytes,chunkBytes:chunk.length});callback(null,chunk);}catch(e){callback(e);}}});await pipeline(Readable.fromWeb(response.body),meter,createWriteStream(part,{flags:'wx',mode:0o600}),{signal});assert.equal(bytes,lock.bytes,'ARCHIVE_TRUNCATED');assert.equal(digest.digest('hex'),lock.sha256,'ARCHIVE_HASH_MISMATCH');await chmod(part,0o400);await rename(part,target);return{path:target,cacheHit:false,bytes,maxChunk};
 }finally{if(response?.body&&!response.body.locked)await response.body.cancel().catch(()=>{});await rm(work,{recursive:true,force:true});}
}
