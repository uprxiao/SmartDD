from pathlib import Path
import sys,json,hashlib,tarfile,tempfile,os,shutil
archive,manifest_path,destination,lock_path=map(Path,sys.argv[1:]);manifest=json.loads(manifest_path.read_text());lock=json.loads(lock_path.read_text());files={x['path']:x for x in manifest['files']};assert len(files)==len(manifest['files']);assert len(files)<=4096
parents=set()
for name in files:
 parts=name.split('/');assert all(p and p not in ['.','..'] and not any(c in p for c in ['\\',':','\0'])for p in parts)
 parents.update('/'.join(parts[:i])for i in range(1,len(parts)))
assert not destination.exists();destination.mkdir(mode=0o700);seen=set();total=0;count=0
try:
 with archive.open('rb')as stream:
  before=os.fstat(stream.fileno());digest=hashlib.sha256();compressed=0
  for b in iter(lambda:stream.read(262144),b''):digest.update(b);compressed+=len(b);assert compressed<=lock['bytes'],'COMPRESSED_OVERFLOW'
  assert compressed==lock['bytes'] and digest.hexdigest()==lock['sha256'],'COMPRESSED_INTEGRITY';stream.seek(0)
  with tarfile.open(fileobj=stream,mode='r|gz')as tar:
   for member in tar:
    count+=1;assert count<=8192,'MEMBER_LIMIT';name=member.name.rstrip('/')if member.isdir()else member.name;parts=name.split('/');assert all(p and p not in ['.','..'] and not any(c in p for c in ['\\',':','\0'])for p in parts),'UNSAFE_PATH'
    assert member.isfile()or member.isdir(),'UNSUPPORTED_ENTRY_TYPE';assert not member.sparse,'SPARSE_NOT_ALLOWED'
    if member.isdir():assert name in parents,'EXTRA_DIRECTORY';continue
    assert name in files,'EXTRA_FILE';assert name not in seen,'DUPLICATE_FILE';expected=files[name];assert member.size==expected['size'],'MEMBER_SIZE_MISMATCH';seen.add(name);total+=member.size;assert total<=sum(x['size']for x in files.values()),'EXPANDED_LIMIT'
    target=destination/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);h=hashlib.sha256();written=0
    with tar.extractfile(member)as src,target.open('xb')as output:
     for block in iter(lambda:src.read(262144),b''):written+=len(block);assert written<=expected['size'];h.update(block);output.write(block)
    assert written==expected['size']and h.hexdigest()==expected['sha256'],'MEMBER_HASH_MISMATCH';target.chmod(0o500 if expected['executable']else 0o400)
  after=os.fstat(stream.fileno());assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'ARCHIVE_CHANGED'
 assert seen==set(files),'MISSING_FILE';print(json.dumps({'files':len(seen),'bytes':total,'path':str(destination)}))
except BaseException:
 shutil.rmtree(destination);raise
