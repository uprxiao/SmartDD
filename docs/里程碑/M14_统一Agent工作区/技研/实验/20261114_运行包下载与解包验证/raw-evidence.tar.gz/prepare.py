from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_运行包下载与解包验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==8 and not result.get('error');a=Path(result['out']);build=json.loads((root/'build.json').read_text())
for n in ['artifact.mjs','actual.cjs','build.json','download.mjs','extract.py','probe.mjs','fixtures.json']:assert (root/n).read_bytes()==(a/n).read_bytes(),n
for s in build['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha(Path(build['output']['file']).read_bytes())==build['output']['sha256']
exits=json.loads((a/'process-exits.json').read_text());assert len(exits)==10 and all(not x['timedOut'] and x['signal']is None for x in exits);assert sum(x['code']==0 for x in exits)==3 and sum(x['code']==1 for x in exits)==7
requests=json.loads((a/'http-requests.json').read_text());assert all(x.startswith('/')for x in requests);fixtures=json.loads((root/'fixtures.json').read_text());fixtureInputs=[];(root/'archive-fixtures').mkdir(exist_ok=True)
for name,v in fixtures.items():
 f=Path(v['archive']);h=hashlib.sha256()
 with f.open('rb')as stream:
  for b in iter(lambda:stream.read(262144),b''):h.update(b)
 assert f.stat().st_size==v['lock']['bytes'] and h.hexdigest()==v['lock']['sha256']
 copied=None
 if name!='native':shutil.copyfile(f,root/'archive-fixtures'/f.name);copied='archive-fixtures/'+f.name
 fixtureInputs.append({'name':name,'source':str(f),'sha256':h.hexdigest(),'bytes':f.stat().st_size,'archiveCopy':copied})
(root/'fixture-inputs.json').write_text(json.dumps(fixtureInputs,indent=2))
runtime={'attempt':a.name,'processes':exits,'localHttpRequests':requests,'paidModelCalls':0,'publicUpstreamCalls':0,'python':subprocess.check_output(['/usr/bin/python3','--version'],text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'nativeVersion':'0.167.1','archiveBytes':fixtures['native']['lock']['bytes'],'expandedFileCount':len(fixtures['native']['manifest']['files']),'limits':['Local HTTP, not public HTTPS/proxy','Archive was built from cached native package, not downloaded from upstream','Python is an experiment helper, not a product dependency decision','No install host death, run lease/GC or product integration']}
(root/'runtime-audit.json').write_text(json.dumps(runtime,indent=2));refs=[repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/applications/resource-lock.ts',t3/'apps/server/src/provider/CodexInstallation.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(build['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Actual ResourceStore with isolated stream preparation candidate, Node fetch against loopback HTTP, Python tarfile helper with explicit manifest/type/path/size/hash checks. T3 installer source comparison only.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and not any(x in p.parts for x in ['node_modules','publication','data','__pycache__']) and p.suffix in ['.mjs','.cjs','.sqlite','.json','.py','.gz'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json','raw-evidence.tar.gz']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,indent=2))]+[(n,(root/n).read_bytes())for n in ['fixture-inputs.json','runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 运行包下载、离线缓存与解包边界

2026-11-14；R02／08／10／11，Q01／03／48／51／52／53／54；技术方案 §12.1、验证账 §4.51。技术研究与隔离验证，无产品／共享原型变更。

## 真实执行路径

本机 HTTP 服务提供临时 tar.gz 包，Node fetch 流式下载到独立 partial 目录，校验压缩大小／SHA256 后才发布内容寻址缓存；允许的重定向来源由调用方显式给定。本机离线命中仍校验缓存，缺失或损坏不触发网络兜底。

解包由捕获的 Python 子进程执行实验 helper：同一已打开 archive 文件先校验压缩摘要，再按固定文件清单检查 tar 成员路径、种类、重复、大小及内容摘要；仅生成规定的普通文件／必要目录，不跟随包内软链接、硬链接或稀疏文件。失败删除本次私有解包目录，旧资源不受影响。再次经过上一批流式资源准备／实际 ResourceStore 发布后，才从内容路径执行版本检查。

Python 仅是隔离验证工具，没有决定向产品引入 Python 依赖。正式实现还需选择与各目标平台发行方式匹配的解包器，并验证其边界；这里不把一种 helper 的成功等同所有恶意 tar／压缩炸弹处理已完备。

完整场景的压缩包为 {fixtures['native']['lock']['bytes']} 字节，由此前缓存的实际 Codex 0.167.1 文件临时制作；解包 41 文件／366515155 字节，包含辅助程序和 voice 资源，发布后 --version 成功。不是从公开上游服务器取得的原始发行 archive，不证明公网 TLS、代理、上游布局或来源信任链已验证。

## 结果：attempt-JTiBrz，P01–P08

| 项 | 实际证据 |
| --- | --- |
| P01 | 本地完整 archive 下载→压缩校验→受约束解包→真实 ResourceStore 发布→原生 --version，进程成功退出 |
| P02 | 同源重定向可用；完整缓存离线命中，无额外 HTTP 请求；小包解包成功 |
| P03 | 跳往未批准 origin 时停止，未跟随该重定向 |
| P04 | HTTP 500、错误 Content-Length、坏压缩摘要拒绝，缓存没有半成品 |
| P05 | 客户端收到 149 字节后由服务端中断，失败且 partial 清理；不冒充大文件全程下载中断覆盖 |
| P06 | 客户端收到一块后主动取消，失败且无完成缓存 |
| P07 | 离线缺失／坏缓存明确失败，未请求网络或换资源 |
| P08 | 路径越界、软链接、硬链接、重复成员、内容摘要错误、多余文件、成员大小错误七类包均拒绝；无解包目录或越界文件遗留 |

P08 的包本身拥有匹配的压缩摘要，仍因内部内容不符合固定清单被拒绝；没有用“坏压缩 hash”冒充解包防护。正常／失败 archive 的精确字节及 SHA 可在归档中核对，小型故障包原样保留；大 native archive 仅存清单与摘要，避免将运行程序重复纳入文档库。

十个捕获子进程均有终态回执：两次正常解包加一次 native --version 为 code 0，七次预期解包拒绝为 code 1；没有超时或信号退出。HTTP 服务与连接已关闭，没有模型回合、真实凭据、供应商请求或对日常安装的操作。

## 与 T3 的关系及设计边界

T3 CodexInstallation 先流式校验 archive 的大小／摘要，列出 tar 成员和类型、拒绝不安全路径／非普通文件目录，再解包和检查版本；平台包使用版本目录和独立激活指针。WillYou 沿用“准备后才发布”的原则，并与自己的固定资源清单、ResourceStore 和后续真实租约连接，不直接拷贝安装 UI 或默认更新行为。

本批验证 URL 来源约束、固定包完整性、缓存和常见解包异常；完整安装操作尚无持久 owner／阶段／恢复记录。下载缓存的有效性、解包完成、资源 ready、默认激活及运行使用仍分别核对。超时、取消与崩溃不是同一证据；本批正常清理不能替代进程被终止后的残留恢复。

仍缺公网 HTTPS／企业代理／证书故障、真实上游包来源与清单生成、其他 archive 变体和极端解包预算、下载重试／恢复持久化、并发安装、真实 run 租约／GC、平台安装签名与最终解包器选型。正式协议不得因为本地服务正常就默认接受任意 URL 或从下载内容本身取得可信的版本批准。

## 证据与复跑

[结果](result.json)、[运行与请求审计](runtime-audit.json)、[包输入摘要](fixture-inputs.json)、[源码依据](source-review.json)、[证据哈希](archive-manifest.json)、[全部驱动／数据库／小型坏包](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性与外键通过；{len(build['sources'])} 个实际构建输入复核。

新临时目录恢复源码和依赖，调整绝对路径后执行 build.mjs、build-fixtures.py、probe.mjs；仅监听 127.0.0.1，需足够空间保存缓存、解包和发布副本。临时 native archive 可依据清单从隔离缓存重建，但 gzip 元数据可能令重建 archive 摘要不同；本轮事实以归档 fixture-inputs 的具体摘要为准。故障只作用于本轮私有目录，不对用户安装包或资源库运行。
''')
def tech(t):
 old='当前还未证明网络下载／解包、跨进程安装、真实磁盘耗尽、运行中升级／GC、历史格式兼容或目标平台安装。'
 new='''[下载与解包实验](实验/20261114_运行包下载与解包验证/README.md)又将本机 HTTP 传输接到完整实际 Codex 文件包、受约束解包和 ResourceStore 发布／版本检查。缓存只有完整大小／摘要通过后才可用，离线命中仍验证；来源不在允许范围的重定向拒绝，HTTP 失败、坏长度／摘要、中断和取消不保留完成缓存。解包必须同时检查路径、类型、重复／额外成员、文件集合、成员大小与内容摘要；本批七类异常均拒绝，固定压缩摘要不能代替内部清单约束。

该解包 helper 是隔离 Python 实验工具，不是产品运行依赖决策。正式解包器、真实上游包与可信清单生成、平台路径／权限语义及压缩预算仍须匹配发布方案核验。安装输入的 URL、包摘要、平台和版本批准来自宿主已知配置／发布目录，不从未经信任的包内声明自动获得批准。网络／解包发生在业务协调锁外；下载完成也不自动激活默认值或授予真实运行权限。

当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、安装阶段持久恢复、跨进程安装、真实磁盘耗尽、运行中升级／GC、历史格式兼容或目标平台安装。'''
 assert old in t;t=t.replace(old,new);return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.51 本机包下载、离线缓存与解包

[下载实验](实验/20261114_运行包下载与解包验证/README.md)P01–P08 以本机 HTTP 服务提供由实际 Codex 文件制成的压缩包，完成流式下载、压缩校验、清单约束解包、实际 ResourceStore 发布及 --version。覆盖同源重定向、拒绝未批准来源、HTTP／长度／摘要失败、收到数据后的中断／取消、离线缺失或坏缓存；七种压缩摘要正确但内部不合法的 tar 均拒绝并清理。十个捕获 helper／native 进程都有退出回执，HTTP 服务关闭。

没有公网供应商、HTTPS／代理或真实上游 archive 证明；解包 Python 只是实验工具，未决定产品依赖。正常失败清理不代替崩溃恢复，安装操作持久化、并发、真实租约／GC、极端包预算和平台安装仍未关闭。T0.1 §12.1 已同步，不将当前证据算成产品安装验收。

'''
def account(t):
 assert '### 4.51 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q01','Q03','Q48','Q51','Q52','Q53','Q54']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.51 补本机 HTTP／缓存／解包到实际发布与 native 版本检查，公网、持久恢复和平台仍待证 |';t='\n'.join(lines)+'\n'
 t=t.replace('网络解包、跨进程恢复、真实 run 租约和遗留准备清理仍待联合。','§4.51 补本机 HTTP 下载／缓存／约束解包到实际发布；公网 HTTPS／代理、跨进程恢复、真实 run 租约和遗留准备清理仍待联合。')
 return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补本机 HTTP 包下载、离线缓存、约束解包到实际资源发布与 native 版本检查，见[技术方案 §12.1](技研/技术方案.md)。中断／取消／坏包均有故障证据；公网 HTTPS、安装崩溃及真实运行租约尚未因此通过。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续补安装操作持久恢复与租约联合、完整协议及跨宿主输入／结果对账；上游／代理、业务、平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'processes':len(exits)}))
