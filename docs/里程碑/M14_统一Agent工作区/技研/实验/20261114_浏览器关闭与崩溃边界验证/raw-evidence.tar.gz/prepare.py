from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess
root=Path(__file__).resolve().parent;parent=Path('/private/tmp/willyou-m14-browser-pages-probe');repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_浏览器关闭与崩溃边界验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and not r.get('error');a=Path(r['out']);attempts=[]
for p in sorted(root.glob('attempt-*')):
 result=json.loads((p/'result.json').read_text());cleanup=json.loads((p/'cleanup.json').read_text());assert cleanup['allTrackedDestroyed'];attempts.append({'attempt':p.name,'passed':result['passed'],'error':result.get('error'),'cleanup':cleanup})
assert len(attempts)==2
cdp=json.loads((a/'cdp-after-crash-reload.json').read_text());assert cdp['ok']and cdp['value']['result']['value']==2
crash=json.loads((a/'crash-workspace.json').read_text());assert len(crash['tabs'])==1 and crash['tabs'][0]['failure']is None and crash['notice']is None
checks={x['id']:x['evidence']for x in r['checks']};assert checks['C01']['handler']['activation'] and checks['C01']['blocked']==0 and not checks['C01']['beforeunloadExecuted'];assert checks['C04']['publishedBeforeClose']==[]
runtime={'attempts':attempts,'electron':json.loads((a/'electron-runtime.json').read_text()),'checks':checks,'cdpAfterCrashReload':cdp,'crashUiObservation':{'failure':crash['tabs'][0]['failure'],'notice':crash['notice'],'explicitCrashStateExposed':False},'scope':r['scope'],'nativeAgentTurns':0,'modelCalls':0,'productModified':False};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((parent/n).read_text());
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:assert sha((parent/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
refs=[repo/'src/main/core/browser'/n for n in ['page-registry.ts','workspace.ts','service.ts','cdp-proxy.ts','references.ts','javascript-dialogs.ts','__tests__/registry-shutdown.test.ts']]+[Path('/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules/electron/electron.d.ts'),t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
(root/'sources').mkdir(exist_ok=True)
for p in refs:
 if str(p).startswith(str(repo)):(root/'sources'/p.name).write_bytes(p.read_bytes())
prior=repo/base/'技研/实验/20261114_原生浏览器页面与登录态保留验证/raw-evidence.tar.gz'
reused=[parent/n for n in ['candidate.cjs','fixture.mjs','migration.mjs','joint.sql','browser-prompt.cjs','mcp-bridge.cjs','build.json','profile-build.json','bridge-build.json','preload-build.json']]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputsVerified':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'reused':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in reused],'dependencyArchive':{'path':str(prior.relative_to(repo)),'sha256':sha(prior.read_bytes())},'variants':['Unmodified current BrowserService in prior programmatic candidate bundle; source transformations only prior owner/run/session/retention candidates.','Host calls workspace/pages for isolated tests, no new provider or agent transport claims.','Page crash uses forcefullyCrashRenderer on an explicitly tracked experimental WebContents, not PID/name kill.','C04 calls existing createPopup directly and immediately closes its opener. Actual observed schedule published no popup; not all possible interleavings.'],'t3Boundary':'T3 informs runtime ownership. Existing WillYou browser lifetime and popup/session semantics are retained, not replaced by provider ownership.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
(root/'failure-notes.md').write_text('''# 研究脚本修正

attempt-P1B1ef 在 C01 设置 beforeunload 后把函数作为 executeJavaScript 的返回值，Electron IPC 无法克隆，检查失败；没有测试到业务关闭结论。最终 cleanup 为真，进程 exit1。修正为返回 true，并使用当前 console-message 事件对象读取 message。attempt-IC3bRU 四项通过，Electron exit0。没有修改产品源码，没有调用模型或启动原生 Agent。

最终真实 renderer 崩溃事件 reason=killed、exitCode=2 由实验调用该已持有 WebContents.forcefullyCrashRenderer 引发；不代表研究主进程失败。主进程最终正常退出，全部已跟踪页面销毁。
''')
files=[p for p in root.rglob('*')if p.is_file()and not any(x.startswith('electron-home-')or x in ['publication','node_modules','__pycache__']for x in p.relative_to(root).parts)and p.suffix in ['.mjs','.json','.sqlite','.md','.py','.ts']and p.name not in ['manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes()),'dependencyArchive':review['dependencyArchive']}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 浏览器关闭与崩溃边界验证

2026-11-14；技术方案 §9.7.2，验证账 §4.71；R01／08／10，Q37／44。仅隔离研究，产品与共享原型未改。

## 范围与结果

复用[上一批真实页面实验](../20261114_原生浏览器页面与登录态保留验证/README.md)的当前 BrowserService 构建、原生 Electron 和临时 SQLite。此次由研究宿主直接调用现有工作区接口，专查关闭／崩溃边界，不重复 Agent 正常链，也不增加 Agent／模型通过数。

最终 {a.name}，四项通过：

| 检查 | 实际观察与约束 |
| --- | --- |
| C01 beforeunload | 真页面已注册返回 false 的处理函数，脚本传入 userGesture=true，Chromium userActivation 为 true；当前 workspace.close 不执行处理函数，不发 will-prevent-unload，最终 destroyed。现有默认关闭不等待网页挽留，不能把上一批的异步销毁误读成默认会被 beforeunload 卡住 |
| C02 来源页关闭 | 通过真实 window.open 创建命名弹窗和 _blank 新标签；同一 session。关闭来源页销毁命名弹窗，新标签保留且 DOM／合成 Cookie 请求可用 |
| C03 renderer 崩溃 | 仅主动崩溃已持有的实验 WebContents；收到 killed/exitCode2。BrowserPage／WebContents 身份仍在。显式重新导航后 DOM 临时变量消失，localStorage／合成 Cookie 保留；真实 CDP Runtime.evaluate 返回2 |
| C04 初始化竞争 | 调现有 createPopup 后立即关闭来源页；本次调度尚未发布子页，初始化内容最终 destroyed，无存活孤儿。未穷举全部并发交错 |

C03 的当前 workspace snapshot 仍为 failure=null、notice=null，源码 workspace 未订阅 render-process-gone。这说明当前投影没有表达本次崩溃，而不是自动恢复已经完成。新统一 UI 需明示浏览器页面健康与恢复状态；不能将逻辑标签存在或 Provider 正常运行显示成网页可操作。实验通过的是显式宿主重新导航＋CDP 核验，未证明自动恢复或完整 helper 操作。

## 设计落点

保留已有业务语义：Provider stop 不关页；显式关闭、来源弹窗级联和 _blank 标签独立生命周期仍由浏览器服务负责。现有 beforeunload 默认跳过，不擅自新增保存确认或阻塞流程。如以后明确改成等待网页卸载，要另外定义批准／取消语义及守卫，不能借 M14 迁移悄悄改行为。

逻辑标签、WebContents、renderer 健康是不同状态。renderer 崩溃不等于 task 结束、Agent 失败或网页已销毁；恢复可保留 partition／持久浏览器状态，但不能承诺保留内存 DOM。关闭时继续以 destroyed 事件核对原生资源结束。UI 增量合同应有健康状态／原因／恢复状态，刷新后经过实际导航和受管通道验证才清除异常，禁止用标题或标签存在作为就绪证据。

## 失败、复跑与限制

首批 attempt-P1B1ef 错把函数作为 executeJavaScript 返回值，IPC 克隆失败；修正研究脚本返回 true 后通过，原始失败保存。两批都完成跟踪页面清理。没有真实外部账号／数据、正式 UI、App 重启恢复、下载、agent-browser helper 交互、跨平台或付费模型。Q37／44 仍部分。

使用实际 Electron 运行 main.mjs；probe 的绝对临时依赖来自上一批归档，source-review 记录逐文件与依赖归档摘要。复跑需先恢复上一批脚本和固定依赖，不能只解压本批就声称可独立运行。所有 userData／sessionData 隔离，Chromium 缓存和依赖不重复归档。

[结果](result.json) · [运行核验](runtime-audit.json) · [源码依据](source-review.json) · [摘要](archive-manifest.json) · [脚本／协议／SQLite](raw-evidence.tar.gz)。本批 {len(files)} 文件，{len(dbs)} 份 SQLite 完整性／外键通过；复用构建的 {len(sources)} 输入再次核对。
''')
old='**逻辑关闭不等于原生销毁。** 实际 close／dispose 返回时 WebContents 可能尚未触发 destroyed；现有同步 fake 单测不能覆盖这段时序。统一状态需区分停止接单／逻辑移除、业务活动排空、原生销毁。涉及销毁后才允许的资源重用／释放，应预先绑定该 WebContents 的 destroyed 事件，完成后再发布资源完成；事件未到或 beforeunload 阻止时保持待对账状态，不能凭页面列表为空释放占用。实验保持现有 BrowserService 未改，仅等待原生事件证明正常关闭最终可完成；阻止卸载、崩溃页和弹窗仍按分支补证。'
new='''**逻辑关闭不等于原生销毁。** 实际 close／dispose 返回时 WebContents 可能尚未触发 destroyed；现有同步 fake 单测不能覆盖这段时序。统一状态需区分停止接单／逻辑移除、业务活动排空、原生销毁。涉及销毁后才允许的资源重用／释放，应预先绑定该 WebContents 的 destroyed 事件，完成后再发布资源完成；事件未到保持待对账状态，不能凭页面列表为空释放占用。[关闭与崩溃实验](实验/20261114_浏览器关闭与崩溃边界验证/README.md)进一步确认：现有工作区 close 默认不等待 beforeunload，即使页面注册挽留函数并由脚本获得 Chromium userActivation也会关闭。M14 保留这一业务策略，不能悄悄新增保存确认；若未来改成等待卸载，另行规定用户回应／取消和异常清理。

来源页关闭时，现有命名弹窗级联关闭；_blank 新标签独立保留。实验覆盖真实 window.open、共享 session 与子标签保留，以及一个尚未发布弹窗就关闭来源的初始化竞争。统一 UI／任务切换不能把两类页面混为同一取消树；其生命周期不直接映射 Agent 委派树。

**renderer 健康独立于逻辑任务与网页身份。** 实际 renderer 崩溃后 WebContents 和逻辑 tab 仍存在；显式重新导航恢复了合成 Cookie／localStorage 和 CDP 调用，但内存 DOM 状态已丢失。当前 workspace snapshot 对本次崩溃仍返回 failure=null、notice=null，尚无明确崩溃投影。统一 UI 增量合同应承载页面健康／失败原因／恢复状态，按实际 render-process-gone 更新；不能把 Provider 仍活跃或标签仍存在显示成网页就绪。恢复需实际导航及受管通道确认，不自动重放未知网页写动作，也不据此关闭 Agent run。该新投影及真实界面属于后续接入验证，本批不宣称已有实现或自动恢复。'''
def tech(t):assert old in t;return t.replace(old,new)
edit(base/'技研/技术方案.md',tech)
record='''### 4.71 浏览器关闭策略、弹窗与 renderer 崩溃

[关闭与崩溃实验](实验/20261114_浏览器关闭与崩溃边界验证/README.md)四项通过：当前 close 跳过 beforeunload；命名弹窗随来源页关闭、_blank 新标签保留；实际 renderer 崩溃后显式重新导航保留本机合成 Cookie／localStorage，DOM 重置且 CDP 可用；一个弹窗初始化／来源关闭交错未留下孤儿。复用真实 Electron／BrowserService，宿主直调，没有新增 Agent 或模型回合。

当前崩溃后 workspace 投影 failure／notice 仍为 null，不能把标签存在算网页正常或自动恢复。T0.1 §9.7.2 明确页面健康投影、关闭策略与两类弹窗生命周期；此前 beforeunload 的条件描述收窄为现有默认不等待，未来改策略另验。首批研究脚本返回函数导致 IPC 克隆失败，修正后通过，原始失败与清理保留。Q37／44 仍部分；真实 UI、新健康投影、重启、外部账号和 helper 操作未验。

'''
def ledger(t):
 assert '### 4.71 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');t=t.replace('外部账号、重启、真实 UI 审批与关闭异常仍待验','§4.71 补关闭策略／真实弹窗／renderer 崩溃与显式重新加载；外部账号、重启、真实 UI 审批和新增健康投影仍待验');t=t.replace('继续补浏览器异常关闭／重启、邮件上下文','§4.71 又补默认关闭策略／弹窗／renderer 崩溃；继续补浏览器重启／健康投影、邮件上下文');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('最新进展：'):lines[i]='最新进展：真实浏览器关闭／崩溃四项检查通过，明确现有 beforeunload 策略、命名弹窗与新标签生命周期、显式重新加载后的持久状态与 CDP。发现当前 UI 投影未表达 renderer 崩溃，已补入[技术方案 §9.7.2](技研/技术方案.md)的迁移合同；产品未改。'
  if l.startswith('下一步：'):lines[i]='下一步：推进拒绝诊断合同及[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的业务在途／宿主恢复、统一状态投影；不重复已通过的浏览器正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(sources)}))
