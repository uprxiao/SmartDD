# 研究脚本修正

attempt-P1B1ef 在 C01 设置 beforeunload 后把函数作为 executeJavaScript 的返回值，Electron IPC 无法克隆，检查失败；没有测试到业务关闭结论。最终 cleanup 为真，进程 exit1。修正为返回 true，并使用当前 console-message 事件对象读取 message。attempt-IC3bRU 四项通过，Electron exit0。没有修改产品源码，没有调用模型或启动原生 Agent。

最终真实 renderer 崩溃事件 reason=killed、exitCode=2 由实验调用该已持有 WebContents.forcefullyCrashRenderer 引发；不代表研究主进程失败。主进程最终正常退出，全部已跟踪页面销毁。
