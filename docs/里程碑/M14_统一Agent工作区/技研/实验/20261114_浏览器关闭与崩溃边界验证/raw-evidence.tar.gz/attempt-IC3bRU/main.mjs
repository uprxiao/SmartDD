import{app}from'electron';import{mkdirSync,writeFileSync,mkdtempSync}from'node:fs';
const root=import.meta.dirname,home=mkdtempSync(root+'/electron-home-');mkdirSync(home+'/session');mkdirSync(home+'/downloads');
app.setPath('userData',home);app.setPath('sessionData',home+'/session');app.setPath('downloads',home+'/downloads');app.setName('WillYou M14 isolated research');app.commandLine.appendSwitch('use-mock-keychain');app.commandLine.appendSwitch('disable-background-networking');app.commandLine.appendSwitch('disable-component-update');app.commandLine.appendSwitch('proxy-server','http://127.0.0.1:1');app.commandLine.appendSwitch('proxy-bypass-list','127.0.0.1;localhost');app.on('window-all-closed',()=>{});
writeFileSync(root+'/electron-start.json',JSON.stringify({pid:process.pid,home},null,2));
const startupTimer=setTimeout(()=>{writeFileSync(root+'/electron-startup-timeout.json',JSON.stringify({pid:process.pid,home}));app.exit(1);},30000);
void app.whenReady().then(async()=>{
 clearTimeout(startupTimer);writeFileSync(root+'/electron-runtime.json',JSON.stringify({home,execPath:process.execPath,versions:process.versions,argv:process.argv},null,2));
 try{await import('./probe.mjs');app.exit(process.exitCode??0);}catch(e){writeFileSync(root+'/electron-fatal.json',JSON.stringify({error:e.stack},null,2));console.error(e);app.exit(1);}
}).catch(e=>{console.error(e);app.exit(1);});
