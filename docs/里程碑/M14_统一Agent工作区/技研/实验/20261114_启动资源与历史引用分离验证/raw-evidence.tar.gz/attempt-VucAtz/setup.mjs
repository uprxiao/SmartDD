import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import candidate from './candidate.cjs';
import {migrate} from './migration.mjs';
import {install,accept,claim} from './creation.mjs';
export async function setup(){
 const f=await actual.runFixture(undefined,{application:true}),db=f.sqlite,profile=randomUUID();
 db.prepare('INSERT INTO ai_profiles(id,name,runner,created_at,updated_at) VALUES(?,?,?,?,?)').run(profile,'fixture target','claude-code',1,1);
 db.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(f.snapshot.taskId,'p1',f.snapshot.native.cwd,profile,'claude-code','parent',1,1);
 await migrate(db);install(db);
 const run=await f.create();await run.prepare();await run.cli.arm();f.reader.identities.set(71002,'darwin-proc-v1:71002:1');await run.cli.attach(71002,'darwin-proc-v1:71002:1');
 const scope={taskId:f.snapshot.taskId,runId:run.runId},input={key:randomUUID(),targetId:profile,targetRevision:1,cwd:f.snapshot.native.cwd,prompt:'isolated logical child'},response=await accept(db,scope,input,{authorize:()=>f.runs.assertActive(run.runId)});
 assert.deepEqual(await accept(db,scope,input,{authorize:()=>f.runs.assertActive(run.runId)}),response);
 f.reader.identities.delete(71002);await run.cli.exited();await run.stop('fixture-parent-drained');
 const refs=db.prepare('SELECT * FROM m14_ref').all().map(r=>({...r,generation:f.store.get(r.ref_id).generation}));
 const child=structuredClone(f.snapshot);child.taskId=response.childTaskId;const oldName=child.mcp[0].serverName,newName='m14_'+response.bindingId.replaceAll('-','');child.mcp[0].serverName=newName;for(const [key,name]of Object.entries(child.adapterBinding.nativeToolNames))child.adapterBinding.nativeToolNames[key]=name.replace(oldName,newName);
 for(const p of child.packages)for(const s of p.skills)s.projectionPath=s.projectionPath.replace(f.snapshot.taskId,response.bindingId);
 const row={task_id:child.taskId,snapshot_hash:actual.digest(actual.canonicalJson(child)),snapshot_json:actual.canonicalJson(child)};
 db.transaction(()=>{const b=db.prepare('SELECT binding_id FROM m14_binding WHERE task_id=?').get(f.snapshot.taskId).binding_id;db.prepare('UPDATE m14_binding SET legacy_task_id=NULL WHERE binding_id=?').run(b);db.prepare('UPDATE m14_cap SET current_hash=NULL').run();for(const t of ['m14_mcp','m14_ref','m14_revision','m14_cap'])db.prepare('DELETE FROM '+t).run();db.prepare('DELETE FROM m14_binding WHERE binding_id=?').run(b);for(const t of ['capability_session_refs','capability_session_mcp_names','capability_session_identities','capability_snapshot_versions','capability_session_holds','capability_session_snapshots'])db.prepare('DELETE FROM '+t).run();}).immediate();
 const runtime=await new actual.RuntimeRegistry(f.store).install({id:'applications',protocolMajor:1,bridgeEntry:'mcp-bridge.cjs',files:{'mcp-bridge.cjs':Buffer.from('module.exports={next:true};')}}),source=actual.fixtureBundle('2.0.0');source.manifest.runtime.hash=runtime.contentHash;const next=await f.packageRegistry.install(source);await f.packageRegistry.activate(next.packageHash,1);
 const engine=new candidate.ResourceGraphMaintenance(f.store,f.reader,input=>actual.restoreOwnedDirectory('/private/tmp/willyou-m14-owner-probe/process-identity',input));
 db.prepare('UPDATE m14_workspace SET held=0').run();const claimed=claim(db,response.effectId);assert(claimed.claimed);
 return{...f,profile,scope,input,response,refs,row,engine,next,claimed};
}
