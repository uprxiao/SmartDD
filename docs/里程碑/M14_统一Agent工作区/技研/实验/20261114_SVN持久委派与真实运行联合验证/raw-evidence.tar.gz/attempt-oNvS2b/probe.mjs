import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,appendFileSync,globSync,existsSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {join} from 'node:path';
import {library,helper,save,Database,bound} from './native.mjs';
import {descriptor,openQueue,state} from './coordinator.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],hosts=[];
for(const f of ['build.mjs','native.mjs','coordinator.mjs','probe.mjs','build.json'])copyFileSync(root+'/'+f,out+'/'+f);
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
function local(command,args,cwd){const r=spawnSync(command,args,{cwd,env:{PATH:'/usr/bin:/bin',HOME:out},encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout;}
async function seed(driver,workspace){
 const {runFixture,MacProcessIdentityReader}=library(driver);const f=await runFixture(new MacProcessIdentityReader(helper),{application:true,runtime:readFileSync(root+'/mcp-bridge.cjs'),workspace});
 const extraHashes=Object.fromEntries(f.sqlite.prepare("SELECT resource_id,content_hash FROM capability_resources WHERE kind IN ('fixture-dependency','agent-adapter')").all().map(r=>[r.resource_id,r.content_hash]));
 const actor={driver,root:f.root,home:f.home,taskId:f.snapshot.taskId,workspace,extraHashes,snapshot:f.snapshot};assert.equal(f.snapshot.native.cwd,workspace);f.sqlite.close();return actor;
}
async function worker(dir,killAt){
 const p=spawn(process.execPath,[root+'/coordinator.mjs','--worker',dir],{cwd:root,env:{PATH:'/usr/bin:/bin',HOME:out},stdio:['ignore','pipe','pipe','ipc']});const item={pid:p.pid,killAt,checkpoints:[]};hosts.push(item);p.stdout.on('data',b=>appendFileSync(dir+'/worker.stdout',b));p.stderr.on('data',b=>appendFileSync(dir+'/worker.stderr',b));
 let done=false;const exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',(code,signal)=>{Object.assign(item,{code,signal,done});resolve(item);});});
 p.on('message',m=>{if(m.type==='checkpoint'){item.checkpoints.push(m.name);if(m.name===killAt)p.kill('SIGKILL');else p.send({type:'continue',name:m.name});}if(m.type==='done')done=true;});
 // Observation timeouts are reported; no replacement host is started until this exact handle exits.
 let result;try{result=await bound(exit,180000,'joint worker');}catch(e){save(dir+'/observation-timeout.json',{error:e.message,pid:p.pid});console.log(JSON.stringify({event:'observation-timeout',pid:p.pid,dir}));result=await exit;}
 if(killAt){assert.equal(result.signal,'SIGKILL');assert(result.checkpoints.includes(killAt));assert.equal(done,false);}else{assert.equal(result.code,0,existsSync(dir+'/worker.stderr')?readFileSync(dir+'/worker.stderr','utf8'):'worker failed without stderr');assert(done);}return result;
}
async function scenario(parentDriver,cut){
 const childDriver=parentDriver==='claude'?'codex':'claude',id=parentDriver+'-to-'+childDriver+'-'+cut,dir=out+'/'+id;mkdirSync(dir);const workspace=dir+'/wc';
 local('/opt/homebrew/bin/svnadmin',['create',dir+'/repository'],dir);local('/opt/homebrew/bin/svn',['checkout','file://'+dir+'/repository',workspace],dir);writeFileSync(workspace+'/baseline.txt','isolated SVN fixture\n');local('/opt/homebrew/bin/svn',['add','baseline.txt'],workspace);local('/opt/homebrew/bin/svn',['commit','-m','isolated baseline'],workspace);
 const spec={id,workspace,scope:descriptor(workspace),delegationId:randomUUID(),parent:await seed(parentDriver,workspace),child:await seed(childDriver,workspace)};save(dir+'/spec.json',spec);
 const db=openQueue(dir);db.close();if(cut==='normal')await worker(dir,null);else{await worker(dir,cut);const before=openQueue(dir);save(dir+'/after-host-kill.json',state(before));before.close();await worker(dir,null);}
 const q=openQueue(dir),s=state(q);q.close();assert.equal(s.delegations.length,1);assert.equal(s.delegations[0].state,'delivered');assert.equal(s.delegations[0].delivery_count,1);assert.equal(s.receipts.length,3);assert.equal(s.lease.state,'released');
 const receipts=Object.fromEntries(s.receipts.map(r=>[r.phase,JSON.parse(r.receipt)]));assert.equal(receipts.parent.thread,receipts.resume.thread);assert.notEqual(receipts.parent.rootPid,receipts.resume.rootPid);assert.equal(receipts.parent.taskId,receipts.resume.taskId);assert.notEqual(receipts.parent.taskId,receipts.child.taskId);
 const events=s.journal.map(r=>r.event);assert.equal(events.filter(x=>x==='synthetic-workspace-write').length,1);assert.equal(events.filter(x=>x==='delegation-persisted').length,1);assert.equal(events.filter(x=>x==='parent-result-acknowledged').length,1);assert.equal(events.filter(x=>x==='child-start-denied-while-parent-holds').length,1);
 const order=event=>s.journal.find(x=>x.event===event).seq;assert(order('delegation-persisted')<order('synthetic-workspace-write'));assert(order('child-result-persisted')<order('parent-result-acknowledged'));
 const leaseEvents=s.journal.filter(r=>r.event==='workspace-acquired'||r.event==='workspace-released').map(r=>[r.event,JSON.parse(r.body).phase]);assert.deepEqual(leaseEvents,[['workspace-acquired','parent'],['workspace-released','parent'],['workspace-acquired','child'],['workspace-released','child'],['workspace-acquired','resume'],['workspace-released','resume']]);
 const svn=local('/opt/homebrew/bin/svn',['status'],workspace);assert(svn.includes('result.txt'));assert(!svn.includes('baseline.txt'));writeFileSync(dir+'/svn-status.txt',svn);assert.equal(readFileSync(workspace+'/result.txt','utf8'),'CHILD_DONE '+spec.delegationId+'\n');
 for(const actor of [spec.parent,spec.child]){const sql=new Database(actor.root+'/state.sqlite',{readonly:true});assert.equal(sql.prepare("SELECT COUNT(*) AS n FROM capability_runs WHERE state<>'stopped'").get().n,0);assert.equal(sql.prepare("SELECT COUNT(*) AS n FROM capability_resource_leases WHERE owner_kind='run' AND state<>'released'").get().n,0);sql.close();mkdirSync(dir+'/'+actor.driver+'-native-records');const paths=globSync(actor.snapshot.native.stateRoot+'/**/*.jsonl');save(dir+'/'+actor.driver+'-native-records/index.json',paths);paths.forEach((p,i)=>copyFileSync(p,dir+'/'+actor.driver+'-native-records/'+i+'.jsonl'));}
 const result={id,status:'passed',cut,parentDriver,childDriver,nativeRuns:3,modelRequests:5,workspace:spec.scope,parentThread:receipts.parent.thread,parentRoot:receipts.parent.rootPid,resumedParentRoot:receipts.resume.rootPid,oneDurableRequest:true,oneSyntheticWrite:true,oneResultDelivery:true};save(dir+'/result.json',result);checks.push(result);console.log(JSON.stringify(result));
}
let error;try{for(const driver of ['claude','codex'])for(const cut of ['normal','accepted','result']){if(process.argv[2]&&!(`${driver}-${cut}`).startsWith(process.argv[2]))continue;await scenario(driver,cut);}}catch(e){error=e.stack;process.exitCode=1;}
const result={out,checks,hosts,error,scope:'Actual Claude/Codex native + SmartDD owner/session/resource/private MCP/ToolService, one actual temporary SVN WC per case; candidate SQLite coordinator, fixture target policy and synthetic write, loopback model. Crash windows are after fully drained parent acceptance and fully drained child result, not active-native or delivery-ACK uncertainty.'};save(out+'/result.json',result);save(root+'/latest.json',result);save(out+'/source-hashes.json',Object.fromEntries(['build.mjs','native.mjs','coordinator.mjs','probe.mjs','actual-claude.cjs','actual-codex.cjs','mcp-bridge.cjs'].map(f=>[f,sha(root+'/'+f)])));console.log(JSON.stringify(result,null,2));
