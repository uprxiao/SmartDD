import assert from 'node:assert/strict';
import {readdirSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {Database,library,helper,save} from './native.mjs';
const root=import.meta.dirname,batches=['attempt-0WME4D','attempt-oNvS2b','attempt-23N78k'],output=root+'/evidence';mkdirSync(output,{recursive:true});
const checks=[],audits=[],{MacProcessIdentityReader}=library('claude'),reader=new MacProcessIdentityReader(helper),hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
for(const batch of batches){
 const dir=root+'/'+batch,result=JSON.parse(readFileSync(dir+'/result.json'));const target=output+'/'+batch;mkdirSync(target,{recursive:true});
 for(const name of readdirSync(dir)){
  if(name.endsWith('.json')||name.endsWith('.mjs')||name.endsWith('.c'))copyFileSync(dir+'/'+name,target+'/'+name);
 }
 for(const name of readdirSync(dir).filter(n=>existsSync(dir+'/'+n+'/spec.json'))){
  const source=dir+'/'+name,dest=target+'/'+name;mkdirSync(dest,{recursive:true});const spec=JSON.parse(readFileSync(source+'/spec.json'));
  function records(from,to){mkdirSync(to,{recursive:true});for(const ent of readdirSync(from,{withFileTypes:true})){if(['repository','wc'].includes(ent.name)||ent.name.endsWith('.sqlite')||ent.name.endsWith('.sqlite-wal')||ent.name.endsWith('.sqlite-shm'))continue;const p=join(from,ent.name),d=join(to,ent.name);if(ent.isDirectory())records(p,d);else copyFileSync(p,d);}}
  records(source,dest);mkdirSync(dest+'/workspace');for(const f of ['baseline.txt','result.txt'])if(existsSync(spec.workspace+'/'+f))copyFileSync(spec.workspace+'/'+f,dest+'/workspace/'+f);
  for(const [role,actor] of [['parent',spec.parent],['child',spec.child]]){
   const sqlite=new Database(actor.root+'/state.sqlite',{readonly:true});const integrity=sqlite.pragma('integrity_check'),foreignKeys=sqlite.pragma('foreign_key_check');assert.deepEqual(integrity,[{integrity_check:'ok'}]);assert.equal(foreignKeys.length,0);
   const runs=sqlite.prepare('SELECT run_id,state,error_code,owner_pid,owner_started_at FROM capability_runs').all(),processes=sqlite.prepare('SELECT kind,state,pid,process_started_at AS startedAt FROM capability_run_processes').all(),active=sqlite.prepare("SELECT * FROM capability_resource_leases WHERE owner_kind='run' AND state<>'released'").all();assert(runs.every(r=>r.state==='stopped'));assert.equal(active.length,0);
   for(const p of processes)if(p.pid)assert.equal(reader.state(p),'stopped');await sqlite.backup(dest+'/'+role+'-capabilities.sqlite');sqlite.close();const a={batch,scenario:name,role,integrity,foreignKeys,runs,processes,activeRunLeases:active.length};save(dest+'/'+role+'-audit.json',a);audits.push(a);
  }
  const q=new Database(source+'/delegation.sqlite',{readonly:true});assert.deepEqual(q.pragma('integrity_check'),[{integrity_check:'ok'}]);await q.backup(dest+'/delegation.sqlite');q.close();
 }
 checks.push(...result.checks.map(c=>({...c,batch})));
}
const sourceBuild=JSON.parse(readFileSync(root+'/build.json'));for(const row of sourceBuild.sources)assert.equal(hash(row.path),row.sha256);
const t3='/Users/hx/projects/t3code',referencePaths=['apps/server/src/orchestration-v2/ProviderContinuationService.ts','apps/server/src/orchestration-v2/EffectWorker.ts','apps/server/src/orchestration-v2/DelegatedCompletionDelivery.test.ts'];
save(output+'/t3-reference.json',{head:'f313d0a6cb843551fb60e57a454a71e71a3a8c04',files:referencePaths.map(p=>({path:p,sha256:hash(t3+'/'+p)})),scope:'Read-only source reference; not executed in this experiment.'});
const finalAudits=audits.filter(a=>a.batch!=='attempt-0WME4D');const report={checks,passed:checks.filter(c=>c.status==='passed').length,total:8,finalNativeRuns:finalAudits.reduce((n,a)=>n+a.runs.length,0),allFinalNativeAndRegisteredBridgesStopped:true,actualResourceRunLeasesActive:0,candidateRecoveryWorkspaceLeasesHeld:2,initialDriverFailure:{batch:'attempt-0WME4D',cause:'Controller evaluated missing empty stderr file while formatting a success assertion. Three native phases completed; final scenario assertions did not run. Preserved, not counted.'},audits};assert.equal(report.passed,8);assert.equal(report.finalNativeRuns,24);save(output+'/audit.json',report);save(root+'/combined-result.json',report);
const manifest=[];function walk(dir){for(const e of readdirSync(dir,{withFileTypes:true})){const p=join(dir,e.name);if(e.isDirectory())walk(p);else manifest.push({path:p.slice(output.length+1),sha256:hash(p)});}}walk(output);save(root+'/evidence-manifest.json',manifest);console.log(JSON.stringify({checks:report.passed,nativeRuns:report.finalNativeRuns,files:manifest.length,sourceFilesVerified:sourceBuild.sources.length}));
