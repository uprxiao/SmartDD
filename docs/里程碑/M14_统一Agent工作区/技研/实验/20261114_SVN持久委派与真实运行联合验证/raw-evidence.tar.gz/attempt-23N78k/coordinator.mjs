import assert from 'node:assert/strict';
import {readFileSync,realpathSync,statSync,existsSync,writeFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {Database,library,helper,save,nativeTurn,openActor} from './native.mjs';
export function descriptor(path){let root=realpathSync(path);while(!existsSync(join(root,'.svn'))){const p=dirname(root);assert.notEqual(p,root,'not a SVN working copy');root=p;}const stat=statSync(root);return{root,dev:String(stat.dev),ino:String(stat.ino)};}
export function openQueue(dir){const db=new Database(dir+'/delegation.sqlite');db.pragma('journal_mode=WAL');db.pragma('synchronous=FULL');db.exec(`
 CREATE TABLE IF NOT EXISTS delegation(id TEXT PRIMARY KEY,parent_task TEXT NOT NULL,child_task TEXT NOT NULL,state TEXT NOT NULL,request_operation TEXT NOT NULL,result TEXT,delivery_id TEXT,delivery_count INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS workspace_lease(id INTEGER PRIMARY KEY CHECK(id=1),scope TEXT NOT NULL,run_id TEXT NOT NULL,phase TEXT NOT NULL,state TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS phase_receipts(phase TEXT PRIMARY KEY,receipt TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS journal(seq INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL,body TEXT NOT NULL);
 `);return db;}
export function state(db){return{delegations:db.prepare('SELECT * FROM delegation').all(),lease:db.prepare('SELECT * FROM workspace_lease').get()??null,receipts:db.prepare('SELECT * FROM phase_receipts').all(),journal:db.prepare('SELECT * FROM journal ORDER BY seq').all()};}
export async function runWorker(dir){
 const spec=JSON.parse(readFileSync(dir+'/spec.json')),db=openQueue(dir),{MacProcessIdentityReader}=library('claude'),reader=new MacProcessIdentityReader(helper);
 const host=reader.read(process.pid);assert(host);const mark=(event,body={})=>db.prepare('INSERT INTO journal(event,body) VALUES(?,?)').run(event,JSON.stringify({host,...body}));mark('worker-start');
 const tx=fn=>db.transaction(fn).immediate();
 const assertScope=()=>assert.deepEqual(descriptor(spec.workspace),spec.scope);
 const assertLease=runId=>{assertScope();const row=db.prepare('SELECT * FROM workspace_lease WHERE id=1').get();assert.equal(row?.state,'held');assert.equal(row?.run_id,runId);assert.equal(row.scope,JSON.stringify(spec.scope));};
 function confirmDrained(phase){
  const saved=db.prepare('SELECT receipt FROM phase_receipts WHERE phase=?').get(phase);assert(saved,'missing durable drained receipt');const r=JSON.parse(saved.receipt),actor=phase==='child'?spec.child:spec.parent;
  const a=new Database(actor.root+'/state.sqlite',{readonly:true});try{assert.equal(a.prepare('SELECT state FROM capability_runs WHERE run_id=?').get(r.runId)?.state,'stopped');assert.equal(a.prepare("SELECT COUNT(*) AS n FROM capability_run_processes WHERE run_id=? AND state NOT IN ('exited','canceled')").get(r.runId).n,0);assert.equal(a.prepare("SELECT COUNT(*) AS n FROM capability_run_activities WHERE run_id=? AND state='active'").get(r.runId).n,0);assert.equal(a.prepare("SELECT COUNT(*) AS n FROM capability_resource_leases WHERE owner_id=? AND state<>'released'").get(r.runId).n,0);for(const p of a.prepare('SELECT pid,process_started_at AS startedAt FROM capability_run_processes WHERE run_id=? AND pid IS NOT NULL').all(r.runId))assert.equal(reader.state(p),'stopped');}finally{a.close();}return r;
 }
 function acquire(runId,phase){tx(()=>{assertScope();const current=db.prepare('SELECT * FROM workspace_lease WHERE id=1').get();assert(current?.state!=='held','shared SVN writer still held');if(phase==='child')confirmDrained('parent');if(phase==='resume')confirmDrained('child');db.prepare("INSERT INTO workspace_lease VALUES(1,?,?,?,'held') ON CONFLICT(id) DO UPDATE SET run_id=excluded.run_id,phase=excluded.phase,state='held'").run(JSON.stringify(spec.scope),runId,phase);mark('workspace-acquired',{runId,phase});});}
 async function checkpoint(name,extra={}){mark('checkpoint',{name});save(dir+'/checkpoint-'+name+'.json',state(db));process.send?.({type:'checkpoint',name,pid:process.pid,...extra});await new Promise((resolve,reject)=>{const onMessage=m=>{if(m.type==='continue'&&m.name===name){process.off('message',onMessage);resolve();}};process.on('message',onMessage);process.once('disconnect',()=>reject(Error('controller disconnected while checkpoint held')));});}
 async function executePhase(phase){
  const actor=phase==='child'?spec.child:spec.parent,request=db.prepare('SELECT * FROM delegation WHERE id=?').get(spec.delegationId);
  const input=phase==='parent'?'Delegate the isolated workspace edit; return once the host queues it.':phase==='child'?'Perform the assigned isolated workspace write.':'INTERNAL_CHILD_RESULT '+spec.delegationId+' '+request.result;
  if(phase==='resume')tx(()=>{assert.equal(request.state,'result_ready');db.prepare("UPDATE delegation SET state='delivery_inflight',delivery_id=? WHERE id=?").run('delivery-'+spec.delegationId,spec.delegationId);mark('delivery-inflight');});
  return nativeTurn(actor,phase,{dir:dir+'/'+phase,delegationId:spec.delegationId,input,
   acquire:runId=>acquire(runId,phase),assertLease,onDeliveryObserved:details=>spec.cut==='delivery'?checkpoint('delivery',details):undefined,
   execute:call=>tx(()=>{
    assertLease(call.runId);
    if(phase==='parent'){
     assert.equal(call.taskId,spec.parent.taskId);assert.equal(db.prepare('SELECT COUNT(*) AS n FROM delegation').get().n,0);
     db.prepare("INSERT INTO delegation(id,parent_task,child_task,state,request_operation) VALUES(?,?,?,'queued',?)").run(spec.delegationId,spec.parent.taskId,spec.child.taskId,call.operationId);mark('delegation-persisted',{...call});
     assert.throws(()=>acquire('forbidden-early-child','child'),/shared SVN writer still held/);mark('child-start-denied-while-parent-holds');return'waiting_parent_release '+spec.delegationId;
    }
    assert.equal(phase,'child');assert.equal(call.taskId,spec.child.taskId);assert.equal(db.prepare('SELECT state FROM delegation WHERE id=?').get(spec.delegationId).state,'queued');confirmDrained('parent');
    const payload='CHILD_DONE '+spec.delegationId+'\n';writeFileSync(spec.workspace+'/result.txt',payload,{flag:'wx'});mark('synthetic-workspace-write',{...call,path:spec.workspace+'/result.txt'});return payload.trim();
   }),
   release:receipt=>tx(()=>{
    assertLease(receipt.runId);assert.equal(receipt.final.run.state,'stopped');assert(receipt.final.processes.every(p=>['exited','canceled'].includes(p.state)));db.prepare('INSERT INTO phase_receipts VALUES(?,?)').run(phase,JSON.stringify(receipt));
    db.prepare("UPDATE workspace_lease SET state='released' WHERE id=1 AND run_id=?").run(receipt.runId);mark('workspace-released',{phase,runId:receipt.runId});
    if(phase==='child'){
     const result=readFileSync(spec.workspace+'/result.txt','utf8').trim();assert.equal(result,'CHILD_DONE '+spec.delegationId);db.prepare("UPDATE delegation SET state='result_ready',result=? WHERE id=? AND state='queued'").run(result,spec.delegationId);mark('child-result-persisted',{result});
    }else if(phase==='resume'){
     assert.equal(receipt.thread,confirmDrained('parent').thread);db.prepare("UPDATE delegation SET state='delivered',delivery_count=delivery_count+1 WHERE id=? AND state='delivery_inflight'").run(spec.delegationId);mark('parent-result-acknowledged',{thread:receipt.thread,inputId:receipt.inputId});
    }
   })});
 }
 try{
  let current=db.prepare('SELECT * FROM delegation WHERE id=?').get(spec.delegationId);
  if(current?.state==='delivery_inflight'){const f=await openActor(spec.parent);try{const recovered=f.recovered;assert.equal(recovered.length,1);assert.equal(recovered[0].state,'stopped');mark('interrupted-owner-recovered',{recovered});db.prepare("UPDATE delegation SET state='delivery_unknown' WHERE id=?").run(spec.delegationId);assert.equal(db.prepare('SELECT state FROM workspace_lease WHERE id=1').get().state,'held');mark('unknown-delivery-no-resend');save(dir+'/queue-final.json',state(db));process.send?.({type:'done',pid:process.pid,result:'recovery-required'});return;}finally{f.cleanup();}}
  if(!current){await executePhase('parent');await checkpoint('accepted');current=db.prepare('SELECT * FROM delegation WHERE id=?').get(spec.delegationId);}
  if(current.state==='queued'){confirmDrained('parent');await executePhase('child');await checkpoint('result');current=db.prepare('SELECT * FROM delegation WHERE id=?').get(spec.delegationId);}
  if(current.state==='result_ready'){confirmDrained('child');await executePhase('resume');current=db.prepare('SELECT * FROM delegation WHERE id=?').get(spec.delegationId);}
  assert.equal(current.state,'delivered');assert.equal(current.delivery_count,1);for(const phase of ['parent','child','resume'])confirmDrained(phase);mark('worker-complete');save(dir+'/queue-final.json',state(db));process.send?.({type:'done',pid:process.pid});
 }catch(e){mark('worker-failed',{message:e.message,stack:e.stack});save(dir+'/worker-failure.json',{error:e.stack,state:state(db)});throw e;}
 finally{db.close();}
}
if(process.argv[2]==='--worker')runWorker(process.argv[3]).then(()=>{process.disconnect?.();},e=>{console.error(e.stack);process.exitCode=1;process.disconnect?.();});
