import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdirSync,readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
const root=import.meta.dirname,require=createRequire(import.meta.url);
export const helper='/private/tmp/willyou-m14-owner-probe/process-identity';
export const deferred=()=>{let resolve,reject;const promise=new Promise((r,j)=>{resolve=r;reject=j;});promise.catch(()=>{});return{promise,resolve,reject};};
export const save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n');
export function bound(p,ms=45000,label='operation'){let t;return Promise.race([p,new Promise((_,j)=>t=setTimeout(()=>j(Error('observation deadline '+label)),ms))]).finally(()=>clearTimeout(t));}
export function library(driver){return require('./actual-'+driver+'.cjs');}
const Database=require('better-sqlite3');
export {Database};
export async function openActor(actor){
 const {ResourceStore,CapabilitySessionRegistry,CapabilityRunRegistry,MacProcessIdentityReader,digest,fileNames}=library(actor.driver);
 const reader=new MacProcessIdentityReader(helper),sqlite=new Database(actor.root+'/state.sqlite');sqlite.pragma('foreign_keys=ON');
 const store=new ResourceStore(sqlite,actor.root,undefined,{processes:reader});let revoke;
 const sessions=new CapabilitySessionRegistry(store,{assertInitialSelection:()=>{throw Error('reopen cannot create a new snapshot');},verifyExtraResource:r=>{
  const dir=store.directory(r),bytes=readFileSync(dir+'/entry.cjs');assert.equal(digest(bytes),actor.extraHashes[r.resourceId]);assert.equal(digest(bytes),r.contentHash);assert.equal(fileNames(dir).length,2);assert.equal(JSON.parse(readFileSync(dir+'/.smartdd-owned.json')).storeId,store.storeId);
 }});
 const runs=new CapabilityRunRegistry(store,sessions,{processes:reader,assertCurrent:()=>{},revoke:async()=>{await revoke?.();},revocationTimeoutMs:30});
 const recovered=await runs.recover();const session=await sessions.get(actor.taskId);assert.equal(session.snapshot.native.cwd,actor.workspace);
 return{root:actor.root,home:actor.home,sqlite,store,sessions,runs,reader,snapshot:session.snapshot,session,recovered,setRevoke:f=>{revoke=f;},create:async()=>{const s=await sessions.get(actor.taskId);return runs.reserve({taskId:actor.taskId,snapshotHash:s.pointer.snapshotHash,bindings:[]});},cleanup:()=>sqlite.close()};
}
function reply(res,driver,body,tool,call,args,text){
 res.writeHead(200,{'content-type':'text/event-stream'});const e=(type,obj)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...obj})}\n\n`);
 if(driver==='claude'){
  e('message_start',{message:{id:'m'+randomUUID(),type:'message',role:'assistant',model:body.model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});
  e('content_block_start',{index:0,content_block:call?{type:'tool_use',id:'toolu_'+randomUUID(),name:tool.name,input:{}}:{type:'text',text:''}});
  e('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(args)}:{type:'text_delta',text}});e('content_block_stop',{index:0});e('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});e('message_stop',{});
 }else{
  const rid='r'+randomUUID(),item=call?{id:'fc'+randomUUID(),type:'function_call',call_id:'call'+randomUUID(),name:tool.name,...(tool.namespace?{namespace:tool.namespace}:{}),arguments:JSON.stringify(args),status:'completed'}:{id:'m'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text,annotations:[]}]};
  e('response.created',{response:{id:rid,status:'in_progress',output:[]}});e('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});if(!call)e('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:text});e('response.output_item.done',{output_index:0,item});e('response.completed',{response:{id:rid,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
 }res.end();
}
export async function nativeTurn(actor,phase,io){
 const driver=actor.driver,dir=io.dir;mkdirSync(dir);const trace=[],mark=(event,data={})=>{const entry={event,...data};trace.push(entry);appendFileSync(dir+'/trace.jsonl',JSON.stringify(entry)+'\n');};
 const {MacUnixPeerIdentityReader,PrivateApplicationBroker,AgentBridgeProcesses,ApplicationToolService}=library(driver);
 const f=await openActor(actor),reader=f.reader,peers=new MacUnixPeerIdentityReader(helper),attached=deferred(),closed=deferred(),inputEnd=deferred();
 let run,broker,supervisor,child,queryHandle,consume,server,exitTrack,gateWork,proof,modelError,nativeError,terminal,thread,turn,modelRequests=0,toolCount=0;
 const oldNative=f.snapshot.native.sessionId,answer=phase==='parent'?'WAITING_CHILD':phase==='child'?'CHILD_COMPLETE':'PARENT_SAW_CHILD_DONE',value=phase==='parent'?'DELEGATE_'+io.delegationId:'CHILD_WRITE_'+io.delegationId;
 const rows=()=>({run:f.runs.get(run.runId),processes:f.sqlite.prepare('SELECT kind,state,pid,process_started_at FROM capability_run_processes WHERE run_id=?').all(run.runId),leases:f.sqlite.prepare('SELECT state FROM capability_resource_leases WHERE owner_id=?').all(run.runId),activities:f.sqlite.prepare('SELECT state FROM capability_run_activities WHERE run_id=?').all(run.runId),invocations:f.sqlite.prepare('SELECT state,effect_state,error_code,semantics FROM application_invocations WHERE run_id=?').all(run.runId)});
 const bind=async sessionId=>{const s=await f.sessions.get(actor.taskId);await f.sessions.bindNativeSession(actor.taskId,s.pointer.snapshotHash,{...s.snapshot.native,runner:s.snapshot.runner,sessionId});mark('native-session-bound',{sessionId,wasResume:!!oldNative});};
 function start(cmd,args,env){
  assert(!child);io.assertLease(run.runId);child=spawn('/bin/sh',['-c',"printf 'held\\n' >&5\nexec 5>&-\nread -r _ <&4 || exit 1\nexec 4<&-\n{ trap '' TERM; read -r _ <&3; kill -TERM 0; sleep 5; kill -KILL 0; } </dev/null >/dev/null 2>&1 &\nexec \"$@\" 3<&-",'m14-gated',cmd,...args],{cwd:f.snapshot.native.cwd,env,stdio:['pipe','pipe','pipe','pipe','pipe','pipe'],detached:true});
  const identity=reader.read(child.pid);assert(identity);mark('root-birth',identity);child.stderr.on('data',b=>appendFileSync(dir+'/native.stderr',b));child.once('error',e=>{nativeError=e;closed.reject(e);});
  exitTrack=new Promise((resolve,reject)=>child.once('exit',(code,signal)=>{try{process.kill(-child.pid,'SIGKILL');}catch{}mark('root-exit',{code,signal});run.cli.exited().then(()=>{closed.resolve();resolve();},reject);}));exitTrack.catch(()=>{});
  gateWork=(async()=>{await new Promise(r=>child.stdio[5].once('data',b=>{assert.equal(String(b),'held\n');r();}));await run.cli.attach(child.pid,identity.startedAt);io.assertLease(run.runId);f.runs.assertActive(run.runId);child.stdio[4].end('ready\n');mark('owner-attached-before-exec');attached.resolve();})().catch(e=>{attached.reject(e);child.stdio[4].destroy();child.kill('SIGTERM');});return child;
 }
 try{
  run=await f.create();io.acquire(run.runId);await run.prepare();mark('run-prepared',{runId:run.runId,taskId:actor.taskId,cwd:f.snapshot.native.cwd,recovered:f.recovered});
  const tools=new ApplicationToolService(f.store,f.runs,{resolve:(_hash,name)=>({semantics:name==='smartdd_zentao_write_v1'?'write':'read',retry:'never',authorize:context=>{assert.equal(context.run.runId,run.runId);io.assertLease(run.runId);},execute:async(context,args,operation)=>{
   assert.notEqual(phase,'resume');assert.equal(args.value,value);assert(broker.hasAuthenticated(run.runId));assert.equal(operation.toolName??'smartdd_zentao_write_v1','smartdd_zentao_write_v1');toolCount++;assert.equal(toolCount,1);mark('private-write-entered',{runId:run.runId,operationId:operation.operationId,peer:proof.peer});
   const result=io.execute({runId:run.runId,taskId:actor.taskId,operationId:operation.operationId,value});return{value:result,packageHash:operation.packageHash,projectId:context.run.projectId,taskId:context.run.taskId,operationId:operation.operationId};
  }})});
  supervisor=new AgentBridgeProcesses(f.runs,{read:async socket=>{proof=await peers.read(socket);assert(proof);mark('kernel-peer',proof);return proof;}},reader,{pollMs:60000});
  broker=new PrivateApplicationBroker(f.runs,tools,{attachPeer:(socket,id,b)=>supervisor.attach(socket,id,b),authenticated:async(runId,bridgeId)=>mark('bridge-authenticated',{runId,bridgeId})});await broker.start();const prepared=await broker.prepare(run,f.snapshot.mcp[0].serverName);await prepared.bridge.arm();await run.cli.arm();
  f.setRevoke(()=>{broker.revokeRun(run.runId);supervisor.revokeRun(run.runId);queryHandle?.close();if(child&&child.exitCode===null&&child.signalCode===null)child.kill('SIGTERM');});
  server=createServer(async(req,res)=>{try{
   let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw);modelRequests++;assert(modelRequests<=(phase==='resume'?1:2));f.runs.assertActive(run.runId);io.assertLease(run.runId);assert(broker.hasAuthenticated(run.runId));appendFileSync(dir+'/model.jsonl',JSON.stringify(body)+'\n');
   const list=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]),tool=list.find(t=>((t.namespace??'')+(t.name??'')).includes('smartdd_zentao_write_v1'));assert(tool,'private write tool missing');
   const input=JSON.stringify(body.messages??body.input);if(phase==='resume'){assert(input.includes('WAITING_CHILD'));assert.equal(input.split(io.input).length-1,1);assert(input.includes(io.delegationId));mark('same-native-history-and-result-observed');}else if(modelRequests===2){assert.equal(toolCount,1);assert(input.includes(phase==='parent'?'waiting_parent_release':'CHILD_DONE'));}
   reply(res,driver,body,tool,phase!=='resume'&&modelRequests===1,{value},answer);
  }catch(e){modelError??=e;mark('model-rejected',{message:e.message,stack:e.stack});res.writeHead(500);res.end('{}');}});
  await new Promise((r,j)=>{server.once('error',j);server.listen(0,'127.0.0.1',r);});const base=`http://127.0.0.1:${server.address().port}`,state=f.snapshot.native.stateRoot;mkdirSync(state,{recursive:true});
  const env={HOME:f.home,PATH:'/usr/bin:/bin',TMPDIR:f.root,HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1',CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1',ENABLE_TOOL_SEARCH:'false'};
  const bridgeConfig={command:'/usr/bin/env',args:['-i','HOME='+f.home,'PATH=/usr/bin:/bin','TMPDIR='+f.root,process.execPath,join(f.store.root,'runtime',f.snapshot.packages[0].runtimeHash,'mcp-bridge.cjs'),'--bootstrap',prepared.bootstrapPath]},inputId=randomUUID();
  if(driver==='claude'){
   const sid=oldNative??randomUUID();thread=sid;queryHandle=query({prompt:(async function*(){await attached.promise;await bind(sid);yield{type:'user',uuid:inputId,parent_tool_use_id:null,session_id:'',...(phase==='resume'?{isSynthetic:true,client_composed:true}:{}),message:{role:'user',content:io.input}};await inputEnd.promise;})(),options:{...(oldNative?{resume:sid}:{sessionId:sid}),cwd:f.snapshot.native.cwd,model:'claude-sonnet-4-6',settingSources:[],env:{...env,CLAUDE_CONFIG_DIR:state,ANTHROPIC_BASE_URL:base,ANTHROPIC_AUTH_TOKEN:'synthetic-model'},mcpServers:{[f.snapshot.mcp[0].serverName]:{type:'stdio',...bridgeConfig}},allowedTools:['mcp__'+f.snapshot.mcp[0].serverName+'__smartdd_zentao_write_v1'],spawnClaudeCodeProcess:o=>start(o.command,o.args,{...env,CLAUDE_CONFIG_DIR:state,ANTHROPIC_BASE_URL:base,ANTHROPIC_AUTH_TOKEN:'synthetic-model'})}});
   consume=(async()=>{for await(const m of queryHandle){appendFileSync(dir+'/native.jsonl',JSON.stringify(m)+'\n');if(m.type==='result'&&m.user_message_uuid===inputId){terminal=m;assert.equal(m.session_id,sid);inputEnd.resolve();}}})();
  }else{
   const conf=`mcp_servers.${f.snapshot.mcp[0].serverName}={command=${JSON.stringify(bridgeConfig.command)},args=${JSON.stringify(bridgeConfig.args)},default_tools_approval_mode="approve"}`;
   start('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex',['app-server','--disable','plugins','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c',`model_providers.m14={name="m14",base_url="${base}/v1",wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}`,'-c',conf],{...env,CODEX_HOME:state,WY_MODEL_KEY:'synthetic-model'});
   let n=0;const pending=new Map(),done=deferred();createInterface({input:child.stdout}).on('line',line=>{const m=JSON.parse(line);appendFileSync(dir+'/native.jsonl',line+'\n');if(m.id!==undefined&&!m.method){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}}if(m.method==='turn/completed')done.resolve(m.params.turn);if(m.method&&m.id!==undefined){nativeError=Error('unexpected request '+m.method);child.stdin.write(JSON.stringify({id:m.id,error:{code:-32601,message:'unsupported probe request'}})+'\n');}});
   const rpc=(method,params)=>bound(new Promise((resolve,reject)=>{const id=++n;pending.set(id,{resolve,reject});child.stdin.write(JSON.stringify({id,method,params})+'\n');}),30000,method);
   consume=(async()=>{await attached.promise;await rpc('initialize',{clientInfo:{name:'m14_svn_joint_probe',version:'1'},capabilities:{experimentalApi:true}});child.stdin.write('{"method":"initialized"}\n');const t=await rpc(oldNative?'thread/resume':'thread/start',{...(oldNative?{threadId:oldNative}:{}),cwd:f.snapshot.native.cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'on-request',sandbox:'read-only'});thread=t.thread.id;if(oldNative)assert.equal(thread,oldNative);await bind(thread);const u=await rpc('turn/start',{threadId:thread,input:[{type:'text',text:io.input,text_elements:[]}],clientUserMessageId:inputId});turn=u.turn.id;terminal=await done.promise;assert.equal(terminal.id,turn);})();
  }
  consume.catch(e=>{nativeError=e;});await bound(consume,60000,'native-turn');if(nativeError)throw nativeError;if(modelError)throw modelError;assert.equal(modelRequests,phase==='resume'?1:2);assert.equal(toolCount,phase==='resume'?0:1);
  if(driver==='claude'){assert.equal(terminal.is_error,false);assert.equal(terminal.result,answer);}else assert.equal(terminal.status,'completed');
  queryHandle?.close();if(driver==='codex')child.stdin.end();await bound(closed.promise);await supervisor.poll();await run.stop('probe-finalize');await supervisor.poll();const final=rows();save(dir+'/database-result.json',final);
  assert.equal(final.run.state,'stopped');assert(final.leases.every(x=>x.state==='released'));assert(final.processes.every(x=>['exited','canceled'].includes(x.state)));assert(final.activities.every(x=>x.state!=='active'));assert(proof.ancestors.some(x=>x.pid===child.pid&&x.startedAt===final.run.processStartedAt));assert.equal(reader.state(proof.peer),'stopped');
  if(phase!=='resume'){assert.equal(final.invocations.length,1);assert.equal(final.invocations[0].semantics,'write');assert.equal(final.invocations[0].state,'succeeded');}
  const result={phase,driver,taskId:actor.taskId,runId:run.runId,thread,inputId,turn:turn??null,rootPid:child.pid,peer:proof.peer,modelRequests,toolCount,answer,final};io.release(result);mark('run-drained-and-workspace-released',{runId:run.runId});save(dir+'/result.json',result);return result;
 }catch(e){mark('failure',{message:e.message,stack:e.stack});if(run)save(dir+'/failure-state.json',rows());throw e;}
 finally{
  inputEnd.resolve();queryHandle?.close();if(child&&child.exitCode===null&&child.signalCode===null)child.kill('SIGTERM');if(exitTrack)await bound(exitTrack).catch(e=>mark('cleanup-exit-error',{message:e.message}));if(gateWork)await gateWork;await broker?.close();await supervisor?.dispose();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}if(run)save(dir+'/cleanup-state.json',rows());f.cleanup();
 }
}
