import assert from 'node:assert/strict';import actual from './candidate.cjs';
const owners=new WeakMap();
export async function bind(store,handle,id,token,inputId,sessionId){
 const key=Object.freeze({});await store.tx(()=>{const run=store.authority(handle),n=store.db.prepare('SELECT * FROM notice WHERE result_id=?').get(id);assert(n.state==='sending'&&n.token===token&&n.run_id===run.run_id,'NOTICE_SCOPE_CHANGED');store.db.prepare('INSERT INTO claude_notice_input VALUES(?,?,?,?,?,?,?,NULL)').run(token,id,run.run_id,run.binding_id,run.generation,inputId,sessionId);owners.set(key,{store,handle,id,token,inputId,sessionId,runId:run.run_id});});return key;
}
export async function accept(key,frame){
 const c=owners.get(key);assert(c,'PRIVATE_SEND_HANDLE_REQUIRED');const {store}=c;return store.tx(()=>{
  const run=store.authority(c.handle),r=store.db.prepare('SELECT * FROM claude_notice_input WHERE token=?').get(c.token),n=store.db.prepare('SELECT * FROM notice WHERE result_id=?').get(c.id);
  assert(r&&r.run_id===run.run_id&&r.binding_id===run.binding_id&&r.generation===run.generation&&r.input_id===c.inputId&&r.session_id===c.sessionId&&n.token===c.token,'NOTICE_SCOPE_CHANGED');
  assert(frame.session_id===c.sessionId,'SESSION_CHANGED');
  assert((frame.type==='stream_event'&&frame.event?.type==='message_start'&&frame.parent_tool_use_id===null)||(frame.type==='result'&&frame.is_error===false),'UNSUPPORTED_ACCEPTANCE_EVIDENCE');
  const ids=frame.user_message_uuids??(frame.user_message_uuid?[frame.user_message_uuid]:[]);assert(Array.isArray(ids)&&ids.length<=64&&ids.every(x=>typeof x==='string')&&ids.includes(c.inputId),'INPUT_ECHO_MISMATCH');
  const json=actual.canonicalJson(frame);if(r.frame_json){assert.equal(r.frame_json,json,'ACCEPTANCE_RECEIPT_CONFLICT');return{replay:true};}
  assert.equal(n.state,'sending','NOTICE_NOT_SENDING');store.db.prepare('UPDATE claude_notice_input SET frame_json=? WHERE token=?').run(json,c.token);store.db.prepare("UPDATE notice SET state='delivered' WHERE result_id=?").run(c.id);store.event('notice-claude-echo-accepted',{id:c.id,inputId:c.inputId,sessionId:c.sessionId,run:run.run_id});return{replay:false};
 });
}
export async function acceptLifecycle(key,init,frame){
 const c=owners.get(key);assert(c,'PRIVATE_SEND_HANDLE_REQUIRED');const {store}=c;return store.tx(()=>{
  const run=store.authority(c.handle),r=store.db.prepare('SELECT * FROM claude_notice_input WHERE token=?').get(c.token),n=store.db.prepare('SELECT * FROM notice WHERE result_id=?').get(c.id);
  assert(r&&r.run_id===run.run_id&&r.binding_id===run.binding_id&&r.generation===run.generation&&n.token===c.token,'NOTICE_SCOPE_CHANGED');
  assert(init.type==='system'&&init.subtype==='init'&&init.session_id===c.sessionId&&init.claude_code_version==='2.1.321'&&init.capabilities?.includes('msg_lifecycle_v1'),'LIFECYCLE_CAPABILITY_REQUIRED');
  assert(frame.type==='command_lifecycle'&&['queued','started'].includes(frame.state)&&frame.session_id===c.sessionId&&frame.command_uuid===c.inputId&&typeof frame.uuid==='string','LIFECYCLE_SCOPE_CHANGED');
  const json=actual.canonicalJson(frame),prior=store.db.prepare('SELECT * FROM claude_notice_lifecycle WHERE frame_id=?').get(frame.uuid);
  if(prior){assert(prior.token===c.token&&prior.frame_json===json,'LIFECYCLE_RECEIPT_CONFLICT');return{replay:true};}
  assert(['sending','delivered'].includes(n.state),'NOTICE_NOT_SENDING');
  store.db.prepare('INSERT INTO claude_notice_lifecycle VALUES(?,?,?,?,?)').run(frame.uuid,c.token,frame.state,json,actual.canonicalJson(init));
  store.db.prepare("UPDATE notice SET state='delivered' WHERE result_id=? AND state='sending'").run(c.id);
  store.event('notice-claude-lifecycle',{id:c.id,inputId:c.inputId,state:frame.state,run:run.run_id});return{replay:false};
 });
}
