import assert from 'node:assert/strict';
import actual from './candidate.cjs';
import {Results} from './result.mjs';
export class FixedResults extends Results {
 async ack(handle,id,token,revision){return this.tx(()=>{
  const run=this.authority(handle),r=this.result(id,run),o=this.db.prepare('SELECT * FROM result_observation WHERE token=?').get(token);
  assert(o&&o.result_id===id&&o.run_id===run.run_id&&o.binding_id===run.binding_id&&o.generation===run.generation&&o.revision===revision&&r.revision===revision,'OBSERVATION_SCOPE_CHANGED');
  if(o.state==='observed')return{observed:true,replay:true};
  assert.equal(o.state,'offered','OBSERVATION_NOT_OFFERED');
  this.db.prepare("UPDATE result_observation SET state='observed' WHERE token=?").run(token);
  this.db.prepare('UPDATE child_result SET observed=1,ack_count=ack_count+1 WHERE id=? AND observed=0').run(id);
  this.db.prepare("UPDATE notice SET state='disposed',disposition='observed-before-send' WHERE result_id=? AND state IN('pending','claimed')").run(id);
  this.event('result-observed',{id,run:run.run_id,token});return{observed:true,replay:false};
 });}
 // Research-only adapter receipt entry; the probe supplies the original private owner and actual RPC reply.
 async nativeAccepted(handle,id,token,reply){return this.tx(()=>{
  const run=this.authority(handle);this.result(id,run);
  const n=this.db.prepare('SELECT * FROM notice WHERE result_id=?').get(id);
  assert(n.token===token&&n.run_id===run.run_id&&n.binding_id===run.binding_id&&n.generation===run.generation,'NOTICE_SCOPE_CHANGED');
  assert(Number.isSafeInteger(reply.requestId)&&typeof reply.result?.turn?.id==='string','NATIVE_RECEIPT_INVALID');
  const json=actual.canonicalJson(reply),prior=this.db.prepare('SELECT frame_json FROM notice_acceptance WHERE token=?').get(token);
  if(prior){assert.equal(prior.frame_json,json,'NATIVE_RECEIPT_CONFLICT');return{replay:true};}
  assert.equal(n.state,'sending','NOTICE_NOT_SENDING');
  this.db.prepare('INSERT INTO notice_acceptance VALUES(?,?,?,?,?)').run(token,id,run.run_id,json,actual.digest(json));
  this.db.prepare("UPDATE notice SET state='delivered' WHERE result_id=?").run(id);
  this.event('notice-native-accepted',{id,token,run:run.run_id,requestId:reply.requestId,turnId:reply.result.turn.id});return{replay:false};
 });}
}
