import {mkdirSync,appendFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {deferred} from './launch.mjs';
export function claude(out,f,id){return(spawn,prepared)=>{
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});const input=deferred(),end=deferred(),yielded=deferred(),frames=[],waiters=[],sessionId=randomUUID(),inputId=randomUUID();
 const q=query({prompt:(async function*(){const text=await input.promise;appendFileSync(out+'/'+id+'-input.jsonl',JSON.stringify({sessionId,inputId,text})+'\n');yielded.resolve();yield{type:'user',uuid:inputId,parent_tool_use_id:null,session_id:'',message:{role:'user',content:text}};await end.promise;})(),options:{pathToClaudeCodeExecutable:prepared.executable,sessionId,cwd:f.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],includePartialMessages:true,env:prepared.env,mcpServers:{},spawnClaudeCodeProcess:o=>spawn(o.command,o.args,{cwd:f.snapshot.native.cwd,env:prepared.env})}});
 const consume=(async()=>{try{for await(const m of q){frames.push(m);appendFileSync(out+'/'+id+'-native.jsonl',JSON.stringify(m)+'\n');for(const w of [...waiters])if(w.match(m)){waiters.splice(waiters.indexOf(w),1);w.resolve(m);}}}catch(e){appendFileSync(out+'/'+id+'-consumer.jsonl',JSON.stringify({error:e.message})+'\n');}})();
 return{inputId,sessionId,frames,consume,ready:()=>q.initializationResult(),begin:text=>input.resolve(text),yielded:yielded.promise,next:match=>{const m=frames.find(match);return m?Promise.resolve(m):new Promise(resolve=>waiters.push({match,resolve}));},close:()=>{end.resolve();q.close();}};
};}
