from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_Claude通知生命周期与观察竞争验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and not r.get('error');a=Path(r['out']);sources={};outputs=[]
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:
  assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());assert not result.get('error');cleanup=json.loads((attempt/'cleanup.json').read_text());assert all(x['code']==143 for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped'for x in cleanup['cleanup'])
 attempts.append({'attempt':attempt.name,'checks':result['passed'],'nativeExits':cleanup['nativeExits'],'localModelRequests':len(json.loads((attempt/'model.json').read_text()))})
assert len(attempts)==2 and sum(len(x['nativeExits'])for x in attempts)==5
before=json.loads((a/'before-stream.json').read_text());early=json.loads((a/'accepted-before-terminal.json').read_text());life=json.loads((a/'lifecycle-accepted.json').read_text());terminal=json.loads((a/'terminal.json').read_text())
frames=lambda name:[json.loads(l)for l in(a/(name+'-native.jsonl')).read_text().splitlines()]
assert early['frame']in frames('echo-receipt')and terminal['done']in frames('echo-receipt');assert life['queued']in frames('lifecycle-receipt')and life['started']in frames('lifecycle-receipt')and life['init']in frames('lifecycle-receipt');assert 'msg_lifecycle_v1'in life['init']['capabilities'];assert all(m['type']=='system'for m in before['matched'])
runtime={'attempts':attempts,'finalAttempt':a.name,'finalChecks':4,'observedEarlierThanModelOutput':['command_lifecycle/queued','command_lifecycle/started','system/init user_message_uuids','system/status requesting user_message_uuids'],'C01Boundary':'Frames deliberately not persisted to notice receipt ledger; does not imply CLI lacks earlier acknowledgement. C04 uses actual advertised lifecycle.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
sdk=Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk');refs=[t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',t3/'apps/server/package.json',t3/'pnpm-lock.yaml',sdk/'sdk.d.ts',sdk/'sdk.mjs',sdk/'package.json',repo/'src/main/core/applications/run-registry.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'sdkVersion':json.loads((sdk/'package.json').read_text())['version'],'nativeVersion':life['init']['claude_code_version'],'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'candidateOrigin':'Reused actual services with previous in-memory programmatic ownership/retention variants; standalone private receipt classifier is research code.','t3Boundary':'ClaudeAdapterV2 reads user_message_uuids with legacy single-UUID fallback; prompt-echo gating and command_lifecycle are separate; lifecycle completed without started can be duplicate/no-turn failure. This experiment does not run the T3 adapter.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# Claude 通知生命周期与主动观察竞争

2026-11-14；R02／03／05／06／11／12，Q01／04／24／25／28。技术方案 §7.2.5，验证账 §4.63。仅独立研究，无产品／原型修改。

## 方法与新的观察

使用 Claude Agent SDK 0.3.321、固定 native 2.1.321、实际程序化 owner／配置修订／冻结执行计划和 gated launcher。父 task／binding 是候选表，结果为 seeded 合成正文；观察通过宿主直接调用 read／ack，模型服务仅 localhost。

初次 attempt-KnJgsM 三项通过后，原始帧显示：模型输出之前已出现 command_lifecycle queued／started，以及带 user_message_uuids 的 system/init、requesting 状态。不能据“没有流输出”推断没有可用原生回执。保留初次证据，增加能力声明和生命周期验证；最终 {a.name} 四项通过。

## 检查结果

| 检查 | 结论 |
| --- | --- |
| C01 | SDK 输入迭代已 yield、本机模型已收到请求，但候选故意未持久化任何原生回执。直接 read／ack 不清除 sending；结束原生 run 后仍阻止切换，对账 unknown 后也不自动放行。此为回执未落库窗口，不是“CLI 没发 ACK”的证据 |
| C02 | 实际首个 message_start stream_event 带原输入 UUID 和原 session_id，可在终态前关联接受。私有发送句柄、原会话、输入回声、主线程条件均验证；重复同帧幂等 |
| C03 | 实际匹配的 success result 后到，单独证明该合成回合完成。重复结果观察不覆盖接受记录；原 run 排空后允许切换 |
| C04 | 实际 init 声明 msg_lifecycle_v1，原 command_uuid／session_id 的 queued 和 started 在无任何模型输出时可分别留证。不需要一直等模型输出。能力缺失、错误输入、复制句柄和 completed 冒充启动均拒绝；重复 queued 不增加事件 |

最终三次 native 启动／三次本机模型请求；初次两次均保留，共五个自有 native 退出码 143，所有 run stopped。143 来自实验的受控 SDK close／SIGTERM 收尾，不按业务成功回合解释。最终只有 C03 要求真实 SDK success result；其余路径有意保持模拟响应未完成。

## 可指导实现的边界

输入投递必须有原 task／binding／run／generation、私有发送所有权、原 native session 和 input UUID。SDK yield 是本地交接，不能自身升级为原生接受。采用生命周期时先核验实际能力声明和支持的协议版本；保存 queued／started 各自证据，不能合并叫执行成功。当前孤立候选只白名单验证 2.1.321，不是对所有版本的兼容承诺。

有精确 UUID 的原生流事件也可证明开始响应；同样不是最终结果。多 UUID 字段和旧单 UUID 字段分别解析，不能假设只会回显最后一条。合并批次／steer／原生子 Agent 的实际语义还需专门验证，本批只有一条输入／一个主线程。

生产实现应将原始回执持久化后再推进接受状态，读取／确认不能覆盖其发送事实。真正未取得或尚未落库的证据保持 unknown；已有有效 queued／started 不能被忽略后统一丢进 unknown。初始化／requesting 回声本批只记录观察，不把所有带 UUID 的 system 消息自动算完成。

候选 acceptLifecycle 入口仅由持有原私有句柄的适配器调用，init／frame 是驱动收集的真实原生帧；最终应接原 Query 事件入口和持久 inbox，不能暴露成 renderer 可任意提交 JSON 的授权接口。current owner 已停止后迟到回执、宿主崩溃、丢包、完整业务 MCP 和 UI 仍未在本批验证。

## T3 对照

本地 ClaudeAdapterV2 的 claudeEchoedPromptUuids 先取 user_message_uuids 再回退单值；handleSdkMessage 用输入回声释放暂存帧，同时独立处理 command_lifecycle。它还把 completed 且从未 started 判作无实际回合的失败，说明不能只按事件名字推断执行。此次是源码对照和 SDK 原生实跑，没有运行 T3 适配器测试。

## 证据

[结果](result.json)、[两次实验运行审计](runtime-audit.json)、[版本与源码依据](source-review.json)、[摘要](archive-manifest.json)、[原始驱动／协议／SQLite](raw-evidence.tar.gz)。{len(files)} 个文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(sources)} 个构建输入复核；SDK JS／声明和原生版本来源另附摘要。

复跑需要归档中指向的固定 SDK/native 和临时依赖，执行 node probe.mjs；只使用临时 HOME／localhost 和捕获的自有子进程。无付费模型、真实子任务或外部业务写入。
''')
section='''#### 7.2.5 Claude 的输入生命周期与回执能力

[Claude 通知实验](实验/20261114_Claude通知生命周期与观察竞争验证/README.md)补证 SDK 0.3.321／native 2.1.321 的真实通知和直接宿主观察。不能把 Codex turn/start 的 JSON-RPC 回执形状套给 Claude，也不能一概等模型输出才判接受：当前版本实际声明 msg_lifecycle_v1，并在模型输出前发送原 command_uuid／session_id 的 queued、started；首个流事件还可带原输入 UUID，最后的 result 则独立确认回合终态。

Driver 按实际能力和声明支持的版本解析这些证据，并固定其原 Query／native session／输入 UUID 与宿主 run 归属。queued 代表进入原生队列，started 代表原生命令开始；它们可以记录投递接受，均不代表模型完成、业务成功或子树完成。只有 SDK 输入 yield／本地发送返回而没有持久原生证据时，仍不能记为接受。

对带 user_message_uuids 的版本按列表定位，旧单 UUID 字段单独回退；无明确回声时不得按正文或“最近一个任务”猜测。T3 同样区分 prompt echo 和 command_lifecycle，completed 但没有 started 可能是重复输入没有启动回合，不能当作新执行成功。当前实验仅验证单输入主线程；合批／steer／子 Agent 以及其他版本按能力矩阵补验。

主动观察不覆盖在途通知；精确原生回执可幂等收口该通知的投递未知，之后仍检查原 run／目录／业务排空。若回执存在却未持久化，恢复仍须从可信原连接 inbox 对账；不能因为模型已请求或结果已读便补造接受，也不能忽略已有 queued／started 而强迫所有正常输入进入 unknown。本批回执入口仍在隔离适配器，原 Query 事件与持久 inbox、宿主退出及业务 MCP 联合尚待验。

'''
def tech(t):
 assert '#### 7.2.5 'not in t;t=t.replace('### 7.3 Skill 交付、更新与调用来源',section+'### 7.3 Skill 交付、更新与调用来源')
 t=t.replace('不包含模型驱动的结果工具读取、Claude 对应竞争或真实 UI。','不包含模型驱动的结果工具读取或真实 UI；Claude 对应直接观察及生命周期边界见 §7.2.5。');return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.63 Claude 通知生命周期与观察竞争

[Claude 通知实验](实验/20261114_Claude通知生命周期与观察竞争验证/README.md)最终 C01–04 通过；初次三项及原始协议观察保留。实际 SDK 0.3.321／native 2.1.321 在模型输出前已有能力声明和 queued／started；后续主线程 stream_event 和 result 按原输入 UUID／session 精确定位。观察不覆盖发送，已持久化原生回执允许通知解除未知，不能把 SDK yield 自身当回执。

两次实验共五个 native 受控退出码 143，最终三个 run stopped、三次本机模型请求；只有 C03 要求匹配 success result。此前忽略生命周期的窗口是故意未入账，并非没有原生 ACK。已补技术方案 §7.2.5；实际回执 inbox／宿主退出、合批／steer／子 Agent、真实业务 MCP 和 UI 仍待验，不宣称全版本通用。

'''
def ledger(t):
 assert '### 4.63 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q01','Q04','Q24','Q25','Q28']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.63 补 Claude 能力声明／queued／started、输入回声与直接观察；持久 inbox／宿主退出和完整业务链仍待验 |'
 t='\n'.join(lines)+'\n';t=t.replace('Claude／完整工具链及回执落库退出仍缺','§4.63 又补 Claude 直接观察及生命周期；完整工具链及回执落库退出仍缺');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：Claude 当前 SDK/native 已实证通知 queued／started 在模型输出前出现，原生输入回声、回合终态与结果已读分别处理，见[技术方案 §7.2.5](技研/技术方案.md)。有有效原生证据不能一概归为 unknown，未落库仍需对账；仅研究验证，产品未改。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：继续现有业务私有桥与程序化 owner 联合，以及真实回执 inbox／宿主退出恢复；通知和观察按两端已验证证据分别适配。其他责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
