import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync,globSync,existsSync,symlinkSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=import.meta.dirname,repo='/Users/hx/projects/SmartDD',sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
if(!existsSync(root+'/node_modules'))symlinkSync('/private/tmp/willyou-m14-owner-probe/node_modules',root+'/node_modules');
const exports={'__tests__/run-fixture':['runFixture'],'session-registry':['CapabilitySessionRegistry','canonicalFuturePath','selectionHash'],'run-registry':['CapabilityRunRegistry','assertOwnedCapabilityRun'],'run-plan':['createApplicationRunPlan'],'process-identity':['MacProcessIdentityReader'],'manifest':['canonicalJson','digest'],'resource-lock':['withResourceLock']};
const entry=Object.entries(exports).map(([m,n])=>`export {${n.join(',')}} from '${repo}/src/main/core/applications/${m}.ts';`).join('\n')+`\nexport {runFixture as runCodexFixture} from 'm14-codex-fixture';\nexport {storedCapabilitySessionSnapshotSchema} from '${repo}/src/shared/application-session-v3.ts';`;
const sources=new Map(),outputs=[];
for(const candidate of [false,true]){
const result=await build({stdin:{contents:entry,resolveDir:repo,loader:'ts'},bundle:true,platform:'node',format:'cjs',target:'node22',define:{'import.meta.url':JSON.stringify('file://'+root+'/fixture-entry.mjs')},metafile:true,tsconfig:repo+'/tsconfig.node.json',external:['better-sqlite3','./actual.cjs'],nodePaths:[root+'/node_modules','/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules'],outfile:root+(candidate?'/candidate.cjs':'/actual.cjs'),plugins:[{name:'isolated-research-only',setup(b){
 b.onResolve({filter:/^m14-codex-fixture$/},()=>({path:repo+'/src/main/core/applications/__tests__/run-fixture.ts',namespace:'codex-fixture'}));
 b.onLoad({filter:/.*/,namespace:'codex-fixture'},({path})=>({loader:'ts',resolveDir:repo+'/src/main/core/applications/__tests__',contents:readFileSync(path,'utf8').replaceAll('claude-code','codex').replace("join(home,'.claude')","join(home,'.codex')")}));
 b.onLoad({filter:/\/(db\/migrations|capabilities\/assets)\.ts$/},({path})=>({loader:'ts',contents:readFileSync(path,'utf8').replace(/import\.meta\.glob\('([^']+)',\s*\{[\s\S]*?\}\)/g,(_,pattern)=>'('+JSON.stringify(Object.fromEntries(globSync(pattern.replace('@root/',repo+'/')).filter(p=>statSync(p).isFile()).map(p=>[p,readFileSync(p,'utf8')])))+')')}));
 if(candidate)b.onLoad({filter:/\/(session-registry|run-registry|run-plan)\.ts$/},({path})=>({loader:'ts',contents:readFileSync(root+'/'+path.split('/').at(-1)+'.variant','utf8')}));
}}]});
for(const p of Object.keys(result.metafile.inputs).filter(p=>!p.startsWith('<'))){const path=p.startsWith('codex-fixture:')?p.slice('codex-fixture:'.length):p.startsWith('/')?p:process.cwd()+'/'+p;sources.set(path,{path,sha256:sha(path)});}
const path=root+(candidate?'/candidate.cjs':'/actual.cjs');outputs.push({path,sha256:sha(path)});
}
for(const path of globSync(repo+'/drizzle/*.sql'))sources.set(path,{path,sha256:sha(path)});
writeFileSync(root+'/build.json',JSON.stringify({sources:[...sources.values()],outputs,variants:JSON.parse(readFileSync(root+'/patches.json')),scope:'Current actual source baseline plus generated minimal programmatic entry/read/plan variants; full historical variants not copied. Codex test fixture changes runner/home only. No GC/downgrade support claimed.'},null,2));console.log(JSON.stringify({sources:sources.size,outputs:outputs.length}));
