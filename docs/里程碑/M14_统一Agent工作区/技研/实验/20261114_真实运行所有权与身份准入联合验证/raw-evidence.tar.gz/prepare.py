from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_真实运行所有权与身份准入联合验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==5 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
for e in b['variants']:assert sha(Path(e['file']).read_bytes())==e['before'];assert sha(Path(e['variant']).read_bytes())==e['after']
audit=json.loads((root/'audit.json').read_text());assert all(a['currentKernelState']=='stopped' and a['integrity']=='ok' and not a['foreignKeys'] and a['activeRuns']==0 and a['unreleasedLeases']==0 for a in audit)
t3file=t3/'apps/server/src/orchestration-v2/ProviderSessionManager.ts'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'t3ReadOnlyReference':{'head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'path':str(t3file),'sha256':sha(t3file.read_bytes()),'scope':'releaseEntry source reread only; no T3 runtime tests'},'native':{'kind':'Codex app-server','version':'0.167.1','sha256':'ebabe5f0d79145a9e61274ce9ecf7c02c9021b7b04bfa59b7e61ad4461c32b0b','requests':['initialize','initialized','thread/start'],'noTurnStarted':True},'actual':['MacProcessIdentityReader and actual child PID/birth identity','Current registry owner/WeakMap handles/resource lifecycle with isolated programmatic additions','Current schema-3 parser/plan verification/current legacy code'],'candidate':['Prior retained/programmatic claim SQL and first-native publication','Generated current-source programmatic session/run/read-plan extensions','Claim-source validation during inspect/prepare/arm/active checks','bindOwned wrapper for actual protocol-returned thread ID'],'fixtures':['Codex version of runFixture changes runner/home in test fixture only','Synthetic adapter resources, prepared binding/source/ref rows','Controlled removal/restoration of claim source and run generation change','Two registry instances in one host process, not multi-process takeover'],'failure':'attempt-7JOvUX driver expected CANCELED for old callback, but actual assertOwnedCapabilityRun calls bridgePreparation which returns SCOPE_DENIED on stopped runs. Verified source and changed exact error expectation only. All evidence retained.','limits':['No model turn or provider authentication','No durable native history/resume, business bridge, full delegation or provider switch','No crashed owner takeover, dynamic descendants or unknown PID recovery','Only default binding_mode=current exercised; production programmatic run-bound connection selection remains open','Programmatic fixed-native downgrade deliberately unavailable in this probe; existing legacy branch retained, product fallback design not removed','No final unified production schema/migration/GC/product UI acceptance'],'audit':audit}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['actual.cjs','candidate.cjs','build.mjs','build.json','patch.py','patches.json','session-registry.ts.variant','run-registry.ts.variant','run-plan.ts.variant','probe.mjs','candidate.sql','migration.mjs','claims.mjs','retained.mjs','programmatic-prior.mjs','claims-joint.mjs','claim-read.mjs','source-review.json','audit.json','prepare.py']]
for d in sorted(root.glob('attempt-*')):files.extend(p for p in d.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for n,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/n,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 真实运行所有权与身份准入联合验证

日期：2026-11-14。D01，关联 Q13／Q46–50。承接 §4.103 的共享身份 claim／精确来源，将其接到当前源码生成的程序化注册器变体与真实 Codex app-server。最终 attempt-g1g8xZ 五项通过，未改产品代码。

## 基线和证据层级

SmartDD `5a9e04382441e24624cb94635f9d902c543a03d7`，383 项构建输入、两个 bundle 和三份源码变体的摘要已复核。旧实验整份 variant 落后于当前源码，会丢失历史根保护、adoptLibrary 复制提交和 binding_mode 等变化；本轮从当前文件生成最小补丁，保留现役逻辑。补丁／前后摘要与脚本归档，不把旧实验 bundle 当当前实现。

真实 Codex 0.167.1 固定二进制，仅执行 initialize／thread/start；没有 turn/start、模型或业务请求。HOME／CODEX_HOME 为隔离目录，Provider 为不可用的回环端点与虚构 key。真实子进程 PID／出生身份由现有 MacProcessIdentityReader 读取，先登记启动窗口再关联进程，接收到的原生 ID 直接交给候选宿主绑定入口。

Codex 测试夹具只将原 runFixture 的 runner／home 改为 Codex；适配资源与 prepared binding／源修订为合成。当前注册器的 opaque handle／owner、生命周期、资源租约和 schema 解析为实际源码，程序化来源读取、run 扩展和 claim 校验为研究变体。两个注册器在同一个宿主进程，不能算跨宿主接管。

## 五项检查

| 检查 | 结果 |
| --- | --- |
| O01 运行准入 | 程序化同任务入口启用后，实际旧 reserve 被写守卫拒绝；新 run generation 1，默认 binding_mode=current 保留；第二个同任务 run、另一注册器和复制 handle 均不能取得原运行权限 |
| O02 真实首次身份 | 真实 Codex thread/start 返回的 ID 与真实 owned run 同事务绑定；共享 claim／精确来源写入，run 当前 hash 前进，固定 source hash 和原应用计划字节不变 |
| O03 当前证据 | 同 ID 回调幂等，不同 ID／另一 owner 拒绝；受控移除 claim source、修改 run generation 时，活进程仍在但业务 context 拒绝。恢复夹具数据后原 context 可读 |
| O04 正常接续 | 活进程阻止后继 run；确认本次持有子进程退出后，run stopped／租约 released，但历史 claim 保留。另一注册器可准备 generation 2，以当次 revision 为新 source；旧回调拒绝，不能改后继运行 |
| O05 fork 前复核 | 后继 run 准备后，受控移除其来源，arm 被拒绝且 process record 仍 reserved；恢复来源后以未 fork 证明取消，未启动第二个进程 |

O03／O05 的删除和 generation 修改是故障注入，不是正常业务入口允许用户修改身份。O04 的后继运行只达到 prepared，不表示 Codex 原生历史可恢复；空线程可无持久历史，原生恢复探测仍按已有设计单独判断。

## 失败与清理

attempt-7JOvUX 前三项通过，O04 驱动预期旧回调报 CANCELED，实际 SCOPE_DENIED。源码确认 assertOwnedCapabilityRun 先调用 bridgePreparation，已停止运行在这里拒绝；仅修正精确错误预期，attempt-g1g8xZ 五项通过。失败及成功脚本／协议／数据库保留，没有扩大到任意错误均通过。

两次尝试中的真实 Codex 均 exit 0；再次通过内核读取确认原 PID／出生身份 stopped。保存数据库完整性／外键通过，活动 run 与未释放租约均为 0。最终一次两个 run stopped、五份租约 released；原生身份 claim 仍存在。只关闭本次捕获的 ChildProcess，没有按名称查杀。

## 设计影响和未验项

运行准入、准备、arm、活动业务 context 都需要核验精确 identity claim 的来源，不能只在第一次发布时查询一次。持久 binding／身份占用与当前宿主签发的 run handle 分开；克隆／序列化对象和另一注册器不继承权限。正常退出释放 run 资源，不释放历史身份；后继 run 有自己的 generation 和固定 source，旧回调被拒绝。

此批研究变体只覆盖默认 binding_mode=current；程序化 run-bound 来源、native-only 降级、新旧写入口完整迁移、GC、业务结果／私有桥、模型输入、异常宿主接管和动态后代仍未闭环。variant 显式拒绝未纳入的程序化 fixed-native 降级，不作为取消产品兼容要求的决定。实际跨 Provider／多 Agent 协作及恢复 UI 继续按原需求验证。

T3 `f313d0a6cb843551fb60e57a454a71e71a3a8c04` 的 ProviderSessionManager.releaseEntry 源码本轮只读复核；未运行其适配器或测试，不能由本实验替 T3 作运行结论。

复现：按固定依赖运行 patch.py、build.mjs、probe.mjs，须有归档声明的 Codex 二进制及 macOS 进程身份 helper；无需账号或模型端点。见[结果](result.json)、[来源与限制](source-review.json)、[原始归档](raw-evidence.tar.gz)、[归档摘要](archive-manifest.json)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text();needle='发布收据也必须独立于当前 revision：';idx=t.index(needle)
add='''**持久身份与当前执行权分别复核。** [真实所有权与身份准入实验](实验/20261114_真实运行所有权与身份准入联合验证/README.md)已将共享 claim／精确来源接到当前源码的程序化研究变体和真实 Codex 首次线程响应：run 固定来源／应用计划不变，当前 native revision 前进；准备、arm、活动 context 均复核来源，缺失或 generation 不一致拒绝。另一注册器、复制 handle 和旧回调不继承当前执行权。正常退出后资源租约释放但历史 claim 保留，后继 run 使用自己的 generation 和当次源修订；不得在 run cleanup 中顺带释放原生历史身份。该实验后继 run 只准备未 fork，不能由准入成功推断原生历史可恢复。当前源码变体保留 binding_mode 等既有语义，但仅验证默认 current 分支；程序化 run-bound 配置、原生降级和完整业务准入继续待验。\n\n'''
assert '真实所有权与身份准入实验' not in t;t=t[:idx]+add+t[idx:];put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.104 ' not in t
add='''### 4.104 真实运行所有权、原生身份与后继准入

[五项所有权联合检查](实验/20261114_真实运行所有权与身份准入联合验证/README.md)将共享 claim／精确来源、当前源码生成的程序化注册器变体与真实 Codex 0.167.1 初始化／thread/start 接在同库。实际 opaque owner 拒绝另一注册器和复制 handle；原生 ID 更新当前 revision，固定 source／计划字节不变；缺来源和 generation 错配拒绝活动 context，准备后缺来源也阻止 arm。正常进程退出后租约释放、历史 claim 保留，后继 generation 2 准备成功且旧回调不能修改它。

最终五项通过；保留 O04 驱动误期望 CANCELED、实际 stopped bridgePreparation 返回 SCOPE_DENIED 的失败。两次真实进程 exit 0，内核重新核验 stopped；数据库完整性／外键通过、无活动 run／未释放租约。旧整份源码变体未复用，从当前源码生成最小研究补丁，383 项输入和三个变体摘要复核。没有模型 turn、业务调用、跨 Provider、持久原生恢复或崩溃接管；prepared 来源和适配资源为夹具，两个注册器同宿主。只验默认 binding_mode=current；程序化 run-bound、降级和全入口／业务／资源联合未关闭。T0.1 §3.2.9 已补持久身份与执行权分层。

''';t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1);lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| D01 '):
  c=l.split('|');c[2]=' §4.29／33–48／73–76／88–93／103–104 已补历史／首次绑定共库占用和真实 Codex／owner／后继准入局部联合，当前 source／generation／资源分别复核。下一步固定同一研究 Schema 修订，联合全写入口、合法历史续写／复制恢复、原生可恢复性与业务结果准入；补旧根释放／回退、异常 owner 接管及资源保留读取。§4.104 只准备后继 run，不能当跨宿主或原生恢复通过；要求同库原子提交／失败／接管证据 ';lines[i]='|'.join(c)
t='\n'.join(lines)+'\n';t=t.replace('截至 §4.103，56','截至 §4.104，56',1);put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text();lines=t.splitlines()
for i,l in enumerate(lines):
 if l.startswith('最新进展：'):lines[i]='最新进展：共享身份占用接入当前源码研究变体和真实 Codex 首次线程响应，五项检查通过；确认固定启动来源不被原生 ID 覆盖、旧回调隔离、退出释放运行租约但保留历史身份，以及后继启动前重核。见[实验记录](技研/实验/20261114_真实运行所有权与身份准入联合验证/README.md)；未运行模型或修改产品，统计以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。'
 if l.startswith('下一步：'):lines[i]='下一步：按[验证账 D01／D04](技研/全局设计验证账.md#71-当前全局收口方式)在同一研究模型中联合合法历史续写／恢复、全写入口及业务结果准入，核对程序化 run-bound 配置、降级、异常 owner 与资源保留。后继 run 可准备不等于原生历史可恢复；已有默认 v2 桥及业务证据按边界复用。'
put(rel,'\n'.join(lines)+'\n')
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'staged':len(entries),'archiveMembers':len(files),'archiveBytes':archive.stat().st_size}))
