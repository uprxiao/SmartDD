// apps/server/src/orchestration-v2/LiveStreamBudget.ts
import * as Schema from "effect/Schema";
import * as Arr from "effect/Array";
import * as Deferred from "effect/Deferred";
import * as Effect from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Queue from "effect/Queue";
import * as PubSub from "effect/PubSub";
import * as Scope from "effect/Scope";
import * as Semaphore from "effect/Semaphore";
import * as Stream from "effect/Stream";
var LiveStreamBufferError = class extends Schema.TaggedError()(
  "LiveStreamBufferError",
  { message: Schema.String }
) {
};
var LIVE_STREAM_MAX_ITEMS = 1e3;
var LIVE_STREAM_MAX_SERIALIZED_BYTES = 8 * 1024 * 1024;
var serializedSizes = /* @__PURE__ */ new WeakMap();
function serializedSize(value) {
  const cached = serializedSizes.get(value);
  if (cached !== void 0) {
    return cached;
  }
  const bytes = Buffer.byteLength(JSON.stringify(value));
  serializedSizes.set(value, bytes);
  return bytes;
}
var makeLiveStreamBudget = Effect.fn("makeLiveStreamBudget")(function* (limits) {
  const maxItems = limits?.maxItems ?? LIVE_STREAM_MAX_ITEMS;
  const maxSerializedBytes = limits?.maxSerializedBytes ?? LIVE_STREAM_MAX_SERIALIZED_BYTES;
  const failed = yield* Deferred.make();
  const cleanupComplete = yield* Deferred.make();
  let failure;
  const retained = /* @__PURE__ */ new Set();
  let retainedSerializedBytes = 0;
  const release = (items) => {
    for (const item of items) {
      if (!retained.delete(item)) {
        continue;
      }
      retainedSerializedBytes -= item.serializedBytes;
    }
  };
  yield* Effect.addFinalizer(
    () => Effect.sync(() => release(retained)).pipe(
      Effect.andThen(Deferred.succeed(cleanupComplete, void 0))
    )
  );
  const check = Effect.suspend(() => failure ? Effect.fail(failure) : Effect.void);
  const overflow = Effect.fn("LiveStreamBudget.overflow")(function* (nextItems, nextSerializedBytes) {
    failure ??= new LiveStreamBufferError({
      message: "The live event buffer is full. Resume from the last received sequence."
    });
    yield* Deferred.fail(failed, failure);
    yield* Effect.logWarning("orchestration live event buffer is full", {
      retainedItems: retained.size,
      retainedSerializedBytes,
      nextItems,
      nextSerializedBytes,
      maxItems,
      maxSerializedBytes
    });
    return yield* failure;
  });
  const retain = (value, payload = value) => Effect.suspend(() => {
    if (failure) {
      return Effect.fail(failure);
    }
    const serializedBytes = serializedSize(payload);
    const nextItems = retained.size + 1;
    const nextSerializedBytes = retainedSerializedBytes + serializedBytes;
    if (nextItems > maxItems || nextSerializedBytes > maxSerializedBytes) {
      return overflow(nextItems, nextSerializedBytes);
    }
    const item = { value, serializedBytes };
    retained.add(item);
    retainedSerializedBytes = nextSerializedBytes;
    return Effect.succeed(item);
  });
  const replace = (previous, values, payload = (value) => value) => Effect.suspend(() => {
    if (failure) {
      return Effect.fail(failure);
    }
    const next = values.map((value) => ({
      value,
      serializedBytes: serializedSize(payload(value))
    }));
    let nextItems = retained.size + next.length;
    let nextSerializedBytes = retainedSerializedBytes + next.reduce((sum, item) => sum + item.serializedBytes, 0);
    for (const item of previous) {
      if (retained.has(item)) {
        nextItems -= 1;
        nextSerializedBytes -= item.serializedBytes;
      }
    }
    if (nextItems > maxItems || nextSerializedBytes > maxSerializedBytes) {
      return overflow(nextItems, nextSerializedBytes);
    }
    release(previous);
    for (const item of next) {
      retained.add(item);
    }
    retainedSerializedBytes = nextSerializedBytes;
    return Effect.succeed(next);
  });
  const deliver = (stream) => Stream.fromPull(
    Effect.gen(function* () {
      yield* check;
      const sourceScope = yield* Scope.fork(yield* Effect.scope);
      const source = {
        pull: yield* Stream.toPull(stream).pipe(Scope.provide(sourceScope))
      };
      let inFlight = [];
      yield* Effect.addFinalizer(
        () => Effect.sync(() => {
          release(inFlight);
          inFlight = [];
          source.pull = Effect.interrupt;
        })
      );
      yield* Deferred.await(failed).pipe(
        Effect.catchTags({
          LiveStreamBufferError: (error) => Effect.sync(() => {
            source.pull = Effect.interrupt;
          }).pipe(
            Effect.andThen(Scope.close(sourceScope, Exit.fail(error))),
            Effect.andThen(
              Effect.sync(() => {
                const delivered = new Set(inFlight);
                for (const item of retained) {
                  if (!delivered.has(item)) {
                    release([item]);
                  }
                }
              })
            ),
            Effect.andThen(Deferred.succeed(cleanupComplete, void 0))
          )
        }),
        Effect.forkScoped
      );
      return Effect.gen(function* () {
        release(inFlight);
        inFlight = [];
        yield* check;
        const items = yield* Effect.raceFirst(source.pull, Deferred.await(failed));
        inFlight = items;
        yield* check;
        return Arr.map(items, (item) => item.value);
      });
    })
  ).pipe(Stream.scoped);
  return {
    retain,
    replace,
    release,
    deliver,
    check,
    failed: Deferred.await(failed),
    closed: Deferred.await(cleanupComplete),
    usage: Effect.sync(() => ({ retainedItems: retained.size, retainedSerializedBytes }))
  };
});
var retainLiveStream = Effect.fn("LiveStreamBudget.retainLiveStream")(function* (source, budget) {
  const queue = yield* Queue.unbounded();
  let closed = false;
  const close2 = Effect.fn("LiveStreamBudget.close")(function* (error) {
    if (closed) return;
    closed = true;
    budget.release(yield* Queue.clear(queue).pipe(Effect.orElseSucceed(() => [])));
    if (error) yield* Queue.fail(queue, error);
    yield* Queue.shutdown(queue);
  });
  yield* Effect.addFinalizer(() => close2());
  yield* budget.failed.pipe(Effect.catchTags({ LiveStreamBufferError: close2 }), Effect.forkScoped);
  yield* source.pipe(
    Stream.runForEach(
      (value) => budget.retain(value).pipe(
        Effect.flatMap((item) => Queue.offer(queue, item)),
        Effect.uninterruptible
      )
    ),
    Effect.raceFirst(budget.failed),
    Effect.exit,
    Effect.flatMap(
      (exit2) => Exit.isFailure(exit2) ? Queue.failCause(queue, exit2.cause) : Queue.end(queue)
    ),
    Effect.forkScoped({ startImmediately: true })
  );
  return Stream.fromQueue(queue);
});
var bufferLatestLiveStream = (source, key, limits) => Stream.unwrap(
  Effect.gen(function* () {
    const budget = yield* makeLiveStreamBudget(limits);
    const ready = yield* Queue.bounded(1);
    const mutex = yield* Semaphore.make(1);
    const pending = /* @__PURE__ */ new Map();
    let closed = false;
    const close2 = (error) => mutex.withPermit(
      Effect.gen(function* () {
        if (closed) return;
        closed = true;
        budget.release(pending.values());
        pending.clear();
        if (error) yield* Queue.fail(ready, error);
        yield* Queue.shutdown(ready);
      })
    );
    yield* Effect.addFinalizer(() => close2());
    yield* budget.failed.pipe(
      Effect.catchTags({ LiveStreamBufferError: close2 }),
      Effect.forkScoped
    );
    yield* source.pipe(
      Stream.runForEach(
        (value) => mutex.withPermit(
          Effect.gen(function* () {
            yield* budget.check;
            if (closed) return;
            const identity = key(value);
            const previous = pending.get(identity);
            if (previous && previous.value.sequence >= value.sequence) return;
            const wasEmpty = pending.size === 0;
            const [item] = yield* budget.replace(previous ? [previous] : [], [value]);
            pending.set(identity, item);
            if (wasEmpty) yield* Queue.offer(ready, void 0);
          }).pipe(Effect.uninterruptible)
        )
      ),
      Effect.raceFirst(budget.failed),
      Effect.exit,
      Effect.flatMap(
        (exit2) => Exit.isFailure(exit2) ? Queue.failCause(ready, exit2.cause) : Queue.end(ready)
      ),
      Effect.forkScoped({ startImmediately: true })
    );
    return budget.deliver(
      Stream.fromPull(
        Effect.succeed(
          Queue.take(ready).pipe(
            Effect.andThen(
              mutex.withPermit(
                Effect.sync(() => {
                  const items = Array.from(pending.values()).sort(
                    (left, right) => left.value.sequence - right.value.sequence
                  );
                  pending.clear();
                  return items;
                })
              )
            )
          )
        )
      )
    );
  })
);
var replayAndBufferProjectedLiveEvents = (input, limits) => Stream.unwrap(
  Effect.gen(function* () {
    const budget = yield* makeLiveStreamBudget(limits);
    const subscriptionScope = yield* Scope.fork(yield* Effect.scope);
    const subscription = yield* input.subscribe.pipe(Scope.provide(subscriptionScope));
    let throughSequence = input.afterSequence ?? 0;
    const live = yield* retainLiveStream(
      // Take one event at a time so no uncharged PubSub batch is retained.
      Stream.fromEffectRepeat(PubSub.take(subscription)).pipe(
        Stream.filter(
          (event) => event.sequence > throughSequence && (input.filter?.(event) ?? true)
        ),
        Stream.map(input.project),
        Stream.ensuring(Scope.close(subscriptionScope, Exit.void))
      ),
      budget
    );
    const replay = Stream.unwrap(
      input.latestSequence.pipe(
        Effect.map((highWater) => {
          throughSequence = Math.max(highWater, input.afterSequence ?? 0);
          return input.replay(highWater).pipe(
            // The finite database page is independent of the live tail.
            // Charge only the item being delivered so a fast reader can
            // consume a page larger than the budget without overflowing.
            Stream.filter((event) => input.filter?.(event) ?? true),
            Stream.rechunk(1),
            Stream.mapEffect((event) => budget.retain(input.project(event)))
          );
        })
      )
    );
    return budget.deliver(
      Stream.concat(
        replay,
        live.pipe(
          Stream.filter((item) => {
            if (item.value.sequence > throughSequence) return true;
            budget.release([item]);
            return false;
          })
        )
      )
    );
  })
);
export {
  LIVE_STREAM_MAX_ITEMS,
  LiveStreamBufferError,
  bufferLatestLiveStream,
  makeLiveStreamBudget,
  replayAndBufferProjectedLiveEvents
};
