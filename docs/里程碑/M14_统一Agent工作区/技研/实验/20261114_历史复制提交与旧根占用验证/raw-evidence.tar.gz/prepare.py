from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_历史复制提交与旧根占用验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
result=json.loads((root/'latest.json').read_text());assert result['passed']==7 and result['error'] is None
build=json.loads((root/'build.json').read_text())
for e in build['sources']+build['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':build,'node':subprocess.check_output(['node','-p','JSON.stringify({version:process.version,platform:process.platform,arch:process.arch})'],text=True).strip(),'boundary':result['scope'],'candidateGuard':'Preserved legacy version authority plus canonical path checks inside candidate SQLite transaction; no final indexed multi-binding schema, cross-process copy journal or production wiring.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['probe.mjs','guard.mjs','migration.mjs','candidate.sql','build.mjs','build.json','actual.cjs','prepare.py','source-review.json']]
attempts=sorted(root.glob('attempt-*'))
for p in attempts:files += [x for x in p.iterdir() if x.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':result,'attempts':[json.loads((p/'result.json').read_text()) for p in attempts],'failureClassification':'First driver expected a different Chinese error message; actual NATIVE_IDENTITY_CONFLICT was correct. Corrected assertion to stable code; original failing attempt preserved.'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 历史复制提交与旧根占用验证

日期：2026-11-14。关联 R08／R10、Q13／Q49。当前 SmartDD 的 copyClaudeSession、CapabilitySessionRegistry 和 SQLite 实跑；Task 指针为合成事务回调，M14 迁移及修正守卫为临时候选。

## 七项结果

| 检查 | 实际观察 |
| --- | --- |
| H01 伪造复制收据 | 没有进程内可信身份，实际注册器拒绝，元数据不变 |
| H02 复制后源文件变化 | 真实收据失效，元数据不变；恢复合成源文件后重新复制取得新收据 |
| H03 Task 指针回调抛错 | 同一 SQLite 事务内的快照、身份、历史版本、引用与合成指针全部回滚；磁盘副本保留，未自动激活 |
| H04 有效收据重试 | 实际 adoptLibrary 成功提交；原目录、其符号链接别名及当前目录均拒绝另一任务认领，相同原生 ID 保持 |
| H05 早期 M14 候选负例 | 迁移把不同 selection 的旧根版本保存为 unmapped，却仅检查当前 identity_root；旧 claimBinding 允许另一绑定认领旧根，负例后回滚该插入 |
| H06 候选修正 | 在同步事务中核验保留历史的 Schema／摘要／所属任务／规范根，并关联原绑定后，拒绝旧根、别名及当前根，未插入新绑定 |
| H07 独立身份与别名 | 不同原生 ID 可建立新绑定；同一 ID 经目录别名第二次认领被拒绝 |

最终七项通过，两套数据库完整性与外键检查均通过。没有原生 Agent、模型请求、用户数据、真实 TaskService 或 SVN 项目复制。实际历史复制仅包含该 ID 的合成 JSONL 与同名子树。

首轮 H04 因驱动匹配了不同中文错误消息而失败；实际返回 NATIVE_IDENTITY_CONFLICT 正确。改按稳定错误码断言后重跑，失败和当时驱动完整保留，不把它归为产品缺陷。H05 则是确实成立的旧研究候选缺口，不是现役注册器的缺陷。

## 设计影响与边界

保存旧历史正文不等于保留其身份占用。M14 在迁移不同 selection 的历史版本时，须同时保留规范根／原生 ID／执行器的占用与原 binding 的关联；新旧入口及别名统一检查。禁止把同 task 的另一个 binding 自动视为同一占用者。

本轮候选扫描保留旧版本验证合同，未交付最终索引化身份表。生产设计应采用可核验的持久占用投影与迁移事务，避免每次认领扫描全部历史；来源损坏／歧义不能当作空闲。删除旧版本必须保留所需占用，释放须有单独规则。

进程内收据不可序列化为重启后的权限证明。提交回调异常不是宿主 SIGKILL 或断电实验；磁盘副本保留后，重启对账、跨进程复制、最终 Task 指针／多 binding 同事务、旧根回退与回收仍待验证。原子提交的本次范围是当前注册器和合成回调，不扩张为整个应用恢复通过。

## 复现

固定依赖具备时执行 `node build.mjs`、`node probe.mjs`。build 只读取当前 SmartDD 源码并写临时 bundle，启动前后核对 379 条构建来源与产物；原迁移候选来自归档内 migration.mjs／candidate.sql。全部现场位于独立临时目录，保留终态 SQLite 及文件目录位置。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
tech_rel=base/'技研/技术方案.md';t=(repo/tech_rel).read_text()
old='该分支本轮为源码证据，完整多 binding 映射、提交失败、崩溃与回退继续待验，不由普通同根身份冲突检查替代。'
new='[历史复制提交实验](实验/20261114_历史复制提交与旧根占用验证/README.md)已补实际复制／注册器的伪造收据拒绝、源变化拒绝、提交回调抛错整体回滚及有效收据重试；合成 Task 指针与当前快照在同一事务提交。失败后磁盘副本仍存在，不能凭文件存在启用新入口；进程内可信收据不能持久化后直接当成重启授权。真实 TaskService、多 binding 原子更新、宿主退出对账和回退仍待验证。'
assert old in t;t=t.replace(old,new,1)
anchor='T3 ProviderSessionManager.releaseEntry 将订阅排空、scope 关闭、工具事件补记及释放记录分层处理；'
para='''同一实验复现早期 M14 迁移候选的旧根占用遗漏：不同 selection 的旧版本虽然保存为 unmapped，claimBinding 却只检查当前 identity_root，允许另一 binding 认领旧根。现役注册器正确拒绝；这是拟议迁移缺口。迁移必须从经 Schema／摘要／任务身份核验的历史建立规范根、runner、native ID 到原 binding 的占用映射，保留历史来源与复制关系；当前根、旧根与符号链接别名共用冲突域，同逻辑任务下另一个 binding 也不能重占。未知／损坏历史保留待核查，不当空闲；仅保留历史 JSON 不足以满足占用合同。实验修正依赖保留旧版本、在同步事务中扫描并拒绝，最终实现需建立可核验的持久占用投影并同步新旧写入口，避免每次认领遍历全部历史；历史清理不能顺带释放仍需保留的身份。正式 Schema、跨进程交接和释放规则仍待联合验证。

'''
assert anchor in t;t=t.replace(anchor,para+anchor,1);put(tech_rel,t)
ledger_rel=base/'技研/全局设计验证账.md';t=(repo/ledger_rel).read_text();assert '### 4.89 ' not in t
add='''### 4.89 历史复制提交与旧根身份占用

[七项实验](实验/20261114_历史复制提交与旧根占用验证/README.md)取得当前真实复制／注册器证据：伪造收据与变化来源拒绝；合成 Task 提交回调抛错时全事务回滚、磁盘副本保留；有效收据重试后旧根／别名／当前根仍被原任务占用。原生 ID 与源文件保持。首轮只因中文错误消息断言失败，改为稳定 code 后通过，原记录保留。

另复现早期 M14 claimBinding 只查当前根、遗漏历史根的负例。隔离守卫补合法历史来源与规范路径检查后拒绝冲突，独立新 ID 仍允许、别名重占拒绝。技术方案 §11.2 已收口持久占用投影、历史清理与复制事务边界。本轮没有真实 TaskService、原生 Agent、跨进程或崩溃；不能把回调异常等同 SIGKILL，也不把扫描旧版本的候选作为最终迁移实现。Q13／Q49 继续部分。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1).replace('截至 §4.88，56 个宽口径问题项中','截至 §4.89，56 个宽口径问题项中')
old='当前源码另有受管 Claude 历史根复制，必须核验旧根占用、提交失败与多 binding 的兼容，不能一律要求状态根不变。'
new='§4.89 已补实际 Claude 复制收据、提交回滚、重试及旧根占用，并修正早期候选遗漏旧根的反例；下一步是最终占用投影／多 binding 原子提交、复制后宿主退出对账及旧根回退／释放，不能把进程内收据持久化后继续授权。'
assert old in t;t=t.replace(old,new,1)
put(ledger_rel,t)
index_rel=base/'README.md';t=(repo/index_rel).read_text()
t=re.sub(r'^最新进展：.*$', '最新进展：实际历史复制／注册器的回滚与重试已验证，并复现、修正早期迁移候选遗漏旧根占用的问题。见[历史复制与旧根占用](技研/实验/20261114_历史复制提交与旧根占用验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续验证历史复制后的跨进程对账、身份占用投影与多 binding 原子提交；宿主委派问题账、完整运行／业务和资源清理仍按各自未决分支推进。',t,flags=re.M)
put(index_rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-closure-audit/publish.py',root/'publish.py')
print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':result['passed'],'attempts':len(attempts)}))
