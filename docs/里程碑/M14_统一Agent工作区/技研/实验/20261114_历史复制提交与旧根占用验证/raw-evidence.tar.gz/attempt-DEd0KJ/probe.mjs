import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync,symlinkSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import actual from './actual.cjs';
import {migrate,claimBinding} from './migration.mjs';
import {claimWithHistory} from './guard.mjs';

const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,v)=>writeFileSync(join(out,n),JSON.stringify(v,null,2));
for(const n of ['probe.mjs','guard.mjs','migration.mjs','candidate.sql','build.mjs','build.json'])copyFileSync(join(root,n),join(out,n));
const {runFixture,copyClaudeSession,isCopiedClaudeSession,encodeClaudeDir}=actual;
const checks=[];let f,problem;
const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
const snap=()=>Object.fromEntries(['capability_session_snapshots','capability_session_identities','capability_snapshot_versions','capability_session_refs','copy_task_pointer'].map(t=>[t,f.sqlite.prepare('SELECT * FROM '+t+' ORDER BY 1').all()]));
try{
 f=await runFixture();const id=randomUUID();
 let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});
 current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:id});
 const from=current.snapshot.native.stateRoot,to=join(f.root,'copied-history'),cwd=current.snapshot.native.cwd,taskId=current.snapshot.taskId;
 const source=join(from,'projects',encodeClaudeDir(cwd),id+'.jsonl'),target=join(to,'projects',encodeClaudeDir(cwd),id+'.jsonl');
 mkdirSync(dirname(source),{recursive:true});mkdirSync(to);writeFileSync(source,JSON.stringify({type:'user',sessionId:id,message:{role:'user',content:'SYNTHETIC_HISTORY_ONLY'}})+'\n');
 const tree=join(dirname(source),id,'subagents');mkdirSync(tree,{recursive:true});writeFileSync(join(tree,'agent-1.jsonl'),'SYNTHETIC_CHILD_HISTORY\n');
 f.sqlite.exec('CREATE TABLE copy_task_pointer(task_id TEXT PRIMARY KEY,state_root TEXT NOT NULL,snapshot_hash TEXT NOT NULL)');
 f.sqlite.prepare('INSERT INTO copy_task_pointer VALUES(?,?,?)').run(taskId,from,current.pointer.snapshotHash);
 const next={...current.snapshot,native:{...current.snapshot.native,stateRoot:to}};
 const options=copy=>({copy,home:f.home,commit:(before,after)=>{assert(f.sqlite.inTransaction);assert.equal(before.pointer.snapshotHash,current.pointer.snapshotHash);const r=f.sqlite.prepare('UPDATE copy_task_pointer SET state_root=?,snapshot_hash=? WHERE task_id=? AND snapshot_hash=?').run(to,after.pointer.snapshotHash,taskId,before.pointer.snapshotHash);assert.equal(r.changes,1);}});
 let receipt;
 await check('H01','forged copy receipt rejected before metadata update',async()=>{
  const before=snap(),fake={from,to,sessionId:id,assertCurrent(){}};assert.equal(isCopiedClaudeSession(fake),false);
  await assert.rejects(f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,options(fake)),/库模式快照必须沿用/);assert.deepEqual(snap(),before);return{fakeReceiptRejected:true};
 });
 await check('H02','genuine copied receipt becomes invalid after source changes',async()=>{
  f.sessions.assertHistoryCopyAllowed({taskId,from,to,cwd,sessionId:id,home:f.home});receipt=copyClaudeSession({from,to,cwd,sessionId:id,nativeTarget:false});assert(isCopiedClaudeSession(receipt));
  const before=snap(),original=readFileSync(source);writeFileSync(source,Buffer.concat([original,Buffer.from('{"changed":true}\n')]));
  await assert.rejects(f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,options(receipt)),/失效/);assert.deepEqual(snap(),before);writeFileSync(source,original);
  receipt=copyClaudeSession({from,to,cwd,sessionId:id,nativeTarget:false});receipt.assertCurrent();return{sourceChangeRejected:true,metadataUnchanged:true,newCopyReceipt:true};
 });
 await check('H03','metadata and task pointer roll back together after callback failure; copied files remain',async()=>{
  const before=snap(),opts=options(receipt),commit=opts.commit;opts.commit=(a,b)=>{commit(a,b);throw Error('INJECTED_COMMIT_FAILURE');};
  await assert.rejects(f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,opts),/INJECTED_COMMIT_FAILURE/);assert.deepEqual(snap(),before);assert(existsSync(target));assert.deepEqual(readFileSync(target),readFileSync(source));save('failed-commit-state.json',snap());return{allMetadataRolledBack:true,copiedFileRemains:true,notACrashTest:true};
 });
 await check('H04','retry with still-valid receipt commits pointer and retains old root ownership',async()=>{
  const moved=await f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,options(receipt));assert.equal(moved.snapshot.native.stateRoot,to);assert.equal(moved.snapshot.native.sessionId,id);assert.equal(f.sqlite.prepare('SELECT state_root FROM copy_task_pointer WHERE task_id=?').get(taskId).state_root,to);
  const alias=join(f.root,'old-root-alias');symlinkSync(from,alias);
  for(const stateRoot of [from,alias,to])await assert.rejects(f.sessions.create({...next,taskId:randomUUID(),native:{...next.native,stateRoot}},f.home),/已属于另一任务/);
  save('after-copy-commit.json',snap());return{taskPointerCommitted:true,oldRootAndAliasRejected:true,currentRootRejected:true,oldHistoryBytesPreserved:readFileSync(source).equals(readFileSync(target)),alias};
 });
 await check('H05','old M14 candidate loses old-root exclusion although actual registry retains it',async()=>{
  assert.equal(await migrate(f.sqlite),'migrated');const count=f.sqlite.prepare('SELECT count(*) n FROM m14_binding').get().n;
  f.sqlite.exec('SAVEPOINT negative_claim');let claimed;
  try{claimed=claimBinding(f.sqlite,{taskId:randomUUID(),runner:next.runner,identityRoot:from,nativeId:id,cwd});assert(claimed);save('negative-candidate-bindings.json',f.sqlite.prepare('SELECT * FROM m14_binding').all());}finally{f.sqlite.exec('ROLLBACK TO negative_claim; RELEASE negative_claim');}
  assert.equal(f.sqlite.prepare('SELECT count(*) n FROM m14_binding').get().n,count);return{negativeReproduced:!!claimed,scope:'Old temporary M14 claimBinding; not product bug',unmappedHistoricalVersions:f.sqlite.prepare('SELECT count(*) n FROM m14_unmapped_version').get().n};
 });
 await check('H06','history-aware candidate rejects prior/current roots and alias after migration',async()=>{
  const before=f.sqlite.prepare('SELECT * FROM m14_binding ORDER BY binding_id').all();
  for(const identityRoot of [from,join(f.root,'old-root-alias'),to])assert.throws(()=>claimWithHistory(f.sqlite,{taskId:randomUUID(),runner:next.runner,identityRoot,nativeId:id,cwd}),/HISTORICAL_NATIVE_ALREADY_OWNED/);
  assert.deepEqual(f.sqlite.prepare('SELECT * FROM m14_binding ORDER BY binding_id').all(),before);return{oldRootAliasCurrentRejected:true,noBindingInserted:true,dependsOnRetainedHistoricalVersions:true};
 });
 await check('H07','unrelated native ID accepted once; canonical alias cannot claim it twice',async()=>{
  const other=randomUUID(),args={taskId:randomUUID(),runner:next.runner,identityRoot:from,nativeId:other,cwd};const binding=claimWithHistory(f.sqlite,args);assert(binding);
  assert.throws(()=>claimWithHistory(f.sqlite,{...args,taskId:randomUUID(),identityRoot:join(f.root,'old-root-alias')}),/BINDING_NATIVE_ALREADY_OWNED/);return{unrelatedIdAccepted:true,newBindingAliasRejected:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
finally{if(f){save('final-state.json',snap());assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(join(out,'final.sqlite'));save('fixture.json',{root:f.root});f.sqlite.close();}}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,scope:'Actual copyClaudeSession + actual session registry; synthetic task pointer transaction callback. Temporary old M14 migration negative and isolated retained-history claim guard. No native provider, actual TaskService, crash recovery, production edits or project snapshot.'};save('result.json',result);writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
