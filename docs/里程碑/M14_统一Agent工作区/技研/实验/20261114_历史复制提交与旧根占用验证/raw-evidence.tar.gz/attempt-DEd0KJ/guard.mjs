import assert from 'node:assert/strict';
import actual from './actual.cjs';
import {claimBinding} from './migration.mjs';
const {canonicalFuturePath,canonicalJson,digest,storedCapabilitySessionSnapshotSchema}=actual;

// Isolated research candidate: retained legacy versions remain the authority.
export function claimWithHistory(db,input){
 return db.transaction(()=>{
  const root=canonicalFuturePath(input.identityRoot);
  if(input.nativeId){
   for(const row of db.prepare('SELECT task_id,snapshot_hash,snapshot_json FROM capability_snapshot_versions').all()){
    assert.equal(digest(row.snapshot_json),row.snapshot_hash,'HISTORICAL_SOURCE_CORRUPT');
    const v=storedCapabilitySessionSnapshotSchema.parse(JSON.parse(row.snapshot_json));
    assert.equal(v.taskId,row.task_id,'HISTORICAL_SOURCE_IDENTITY');
    assert.equal(canonicalJson(v),row.snapshot_json,'HISTORICAL_SOURCE_NONCANONICAL');
    if(v.runner===input.runner&&v.native.sessionId===input.nativeId&&canonicalFuturePath(v.native.stateRoot)===root){
     const owner=db.prepare('SELECT binding_id,task_id FROM m14_binding WHERE legacy_task_id=?').get(row.task_id);
     assert(owner&&owner.binding_id===input.bindingId&&owner.task_id===input.taskId,'HISTORICAL_NATIVE_ALREADY_OWNED');
    }
   }
   for(const row of db.prepare('SELECT * FROM m14_binding WHERE runner=? AND native_id=?').all(input.runner,input.nativeId)){
    assert(canonicalFuturePath(row.identity_root)!==root,'BINDING_NATIVE_ALREADY_OWNED');
   }
  }
  return claimBinding(db,{...input,identityRoot:root});
 }).immediate();
}
