from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_宿主子任务提问与旧回应隔离验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and r['error'] is None and r['serverError'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
s=json.loads((Path(r['out'])/'host-state.json').read_text())
assert len(s['requests'])==3 and all(x['liveness']=='expired' and x['cancel_requested']==1 and x['close_evidence'] is None for x in s['requests'])
assert len(s['decisions'])==2 and all(x['delivery']=='submitted' for x in s['decisions'])
assert all(x['state']=='stopped' for x in s['runs']) and all(x['state']=='released' for x in s['leases'])
boundary='正常完成的 B／A2 也被驱动 stop() 调用 ledger.cancel，最终 expired＋cancel_requested=1；证明路由和投递，不证明正常关闭语义。不得将清理动作当作用户取消或原生 resolved 证据。'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'boundary':r['scope'],'terminalStateLimitation':boundary}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
names=['probe.mjs','ledger.mjs','ledger.sql','model.mjs','mcp.mjs','native-inputs.mjs','build.mjs','build.json','actual.cjs','migration.mjs','candidate.sql','source-review.json','prepare.py']
files=[root/n for n in names];attempts=sorted(root.glob('attempt-*'))
for a in attempts:files.extend(p for p in a.rglob('*') if p.is_file() and not p.is_symlink())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
combined={'final':r,'attempts':[json.loads((a/'result.json').read_text()) for a in attempts],'terminalStateLimitation':boundary,'firstAttempt':'沙箱 localhost listen EPERM，零模型请求／原生进程；获准本机隔离执行后四项通过，保留失败。'}
for name,obj in [('result.json',combined),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 宿主子任务提问与旧回应隔离验证

日期：2026-11-14。关联 D06、Q26，兼及 Q11／27／28。真实 Claude SDK 0.3.321／native 2.1.321、HTTP MCP、当前实际会话／运行注册器及同一 SQLite；父子关系、父 binding 指针和回应账为独立候选。

| 检查 | 结果与范围 |
| --- | --- |
| J01 同文并发 | 两个独立子任务同时出现相同 message／schema；跨子任务和父 task 作用域的回答均拒绝，未发送 |
| J02 父指针变化 | 候选父 binding 改变不改变子问题 owner，子问题仍等待回答；没有执行真实父 Provider 切换 |
| J03 取消隔离 | 停止 A 后旧回答拒绝，B 的 B_ONLY 回答由实际 MCP 收到；重复决定没有额外发送 |
| J04 同会话新运行 | A 通过实际 SDK resume 沿用 native session ID，新 run／generation 拒绝旧回答；实际 MCP 收到 A_NEXT |

最终四项通过，五个本机合成模型请求、三个原生进程均退出；主动中断的 A1 退出 1，正常 B1／A2 退出 0。实际运行均 stopped、租约 released，SQLite 外键及完整性检查通过。首轮 localhost 监听被沙箱拒绝，未启动原生进程；授权本机执行后通过，失败记录保留。

归属按 task／binding／run／generation／connection 和实际原生 requestId 绑定私有句柄，发送前复核实际运行所有权及当前子 run。子任务拥有独立原生会话，区别于同一 Provider 内部子 Agent 缺少提问子身份的问题。父只是候选关系记录，本轮没有实际父原生运行，也没有完整 delegate 创建／outbox 服务。

## 发现及后续

驱动 stop() 对正常完成的 B／A2 也调用 ledger.cancel，终态为 expired、cancel_requested=1，close_evidence 为空；两份答案投递记录为 submitted。这不否定回答确实抵达 MCP，但不能证明正常请求关闭、UI 终态或真实取消意图正确。正常运行退役必须与取消分开，原生关闭与消费证据须精确关联；不得补造 Claude resolved 通知，也不按同文表单猜归属。下一步补同一问题账的正常关闭／取消差异及恢复证据。

本轮回答和模型都是合成内容，不是真实用户审批；没有外部供应商付费调用。真实 UI／IPC、业务审批、Codex 混合子任务、父原生 Provider 切换及问题账崩溃联合仍未验证。Q26 只推进为部分证据，不代表多 Agent 产品闭环。

## 复现与证据

固定依赖及本机监听权限具备时，依次执行 `node build.mjs`、`node probe.mjs`。归档包含驱动、实际构建、来源摘要、两次 attempt、原生帧、MCP 结果和数据库；使用隔离 HOME／配置及合成凭据，不读取日常账号配置。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
rel=base/'技研/技术方案.md';t=(repo/rel).read_text();anchor='#### 4.4.2 回应账的三个状态与恢复次序'
addition='''[宿主子任务提问实验](实验/20261114_宿主子任务提问与旧回应隔离验证/README.md)将真实 Claude 表单、当前实际子 run 和候选回应账接在同一数据库：同文并发按子任务隔离，停止 A 不影响 B，同 native session 的下一代 run 不接受旧回答。候选父 binding 指针变化不会重定向子问题；这不等于已完成真实父 Provider 切换。宿主委派已有独立任务／运行身份，不依赖原生内部子 Agent 的展示字段猜提问来源。

实验同时暴露收尾边界：驱动对正常完成也调用 cancel，不能把该 expired／cancel_requested 终态作为产品正常关闭依据。运行退役、用户取消意图、原生请求结束和回应投递分别记录；无精确对应的原生关闭证据时只关闭失效入口并保留投递事实，不补造批准／取消。正常终态、问题账恢复及真实 UI／业务联合仍需验证。

'''
assert anchor in t;t=t.replace(anchor,addition+anchor,1)
t=t.replace('Q26 的宿主子任务提问、人工审批及取消恢复仍需同一运行账和真实接线验证。','宿主子任务的同库实际 run／表单联合见 §4.4.1；人工审批、正常关闭与取消恢复的完整接线仍待验证。',1);put(rel,t)
rel=base/'技研/全局设计验证账.md';t=(repo/rel).read_text();assert '### 4.94 ' not in t
lines=t.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| Q26 |'):
  lines[i]=line.replace('| 待集成；','| **部分**：',1)[:-2]+'；§4.94 已补同库实际子 run／Claude 表单、同文并发、取消兄弟隔离及同原生会话新代次的旧回应拒绝；父指针为候选，正常关闭／真实 UI／业务与崩溃联合仍待验 |'
t='\n'.join(lines)+'\n'
section='''### 4.94 宿主子任务提问与旧回应隔离

[四项检查](实验/20261114_宿主子任务提问与旧回应隔离验证/README.md)将两个独立子任务、真实 Claude 表单／resume、当前运行所有权与候选回应账接到同一数据库。同文问题跨子／父作用域拒绝，停止一子不影响兄弟，重启同原生会话的新 run／generation 不接受旧回应；候选父指针变化不重定向子问题。五个本机合成模型请求，三个原生进程已退出；首轮监听 EPERM 的零执行失败保留。

正常 B／A2 也被驱动 cancel 清理，最终 expired＋cancel_requested=1，投递 submitted；已确认实际 MCP 收到答案，但没有正常关闭证据。这是后续需拆分的生命周期分支，不宣称产品终态正确。父子关系／问题账为候选，无真实父切换、完整委派创建、UI、业务授权或崩溃联合。Q26 从待集成推进为部分，完整条目仍未关闭。

'''
t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正',1)
t=t.replace('仍缺 host_delegated 问题与实际 run 的联合','§4.94 已补 Claude 宿主子问题与实际 run 的同库联合，仍缺正常关闭／取消区别、混合 Provider 与崩溃恢复',1)
t=t.replace('截至 §4.93，56 个宽口径问题项中，49 项有部分实验／限定证据，4 项主要内容仍待验证或产品集成','截至 §4.94，56 个宽口径问题项中，50 项有部分实验／限定证据，3 项主要内容仍待验证或产品集成',1).replace('四项为 Q26、Q42、Q51、Q52。','三项为 Q42、Q51、Q52。Q26 已补同库子问题与实际 run 联合，正常关闭、完整业务及恢复仍未关闭。',1).replace('不是只剩四项。','不是只剩三项。',1).replace('不能用 49／56 作为研究完成率','不能用 50／56 作为研究完成率',1)
assert len(re.findall(r'^\| Q\d{2} \|',t,re.M))==56;put(rel,t)
rel=base/'README.md';t=(repo/rel).read_text()
t=re.sub(r'^最新进展：.*$','最新进展：同库子任务提问、取消隔离及旧运行回应拒绝取得独立证据，同时发现正常结束与取消清理仍需分离。见[宿主子任务提问实验](技研/实验/20261114_宿主子任务提问与旧回应隔离验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$','下一步：优先补问题账正常关闭／取消区别与恢复证据，再按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)收口完整委派／业务、迁移与资源联合；分别通过的组件不视为端到端完成。',t,flags=re.M);put(rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-retained-claims-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed'],'sourceInputs':len(b['sources'])}))
