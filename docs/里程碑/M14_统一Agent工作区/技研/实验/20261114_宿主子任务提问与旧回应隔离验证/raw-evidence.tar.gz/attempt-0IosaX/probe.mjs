import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:http';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,copyFileSync,readFileSync} from 'node:fs';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import actual from './actual.cjs';
import * as ledger from './ledger.mjs';
import {nativeRuntime,baseEnv} from './native-inputs.mjs';
import {reply} from './model.mjs';
import {createMcp} from './mcp.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),save=(n,v)=>writeFileSync(out+'/'+n,JSON.stringify(v,null,2)),configs=new Map(),contexts=[],checks=[],processes=[];
for(const n of ['probe.mjs','ledger.mjs','ledger.sql','model.mjs','mcp.mjs','native-inputs.mjs','build.mjs','build.json'])copyFileSync(root+'/'+n,out+'/'+n);
const defer=()=>{const d=Promise.withResolvers();d.promise.catch(()=>{});return d;};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('WATCHDOG:'+label)),30000))]).finally(()=>clearTimeout(timer));};
let f,server,base,error,serverError;
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
async function check(id,title,fn){try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}}
async function child(label){const taskId=randomUUID(),sessionId=randomUUID(),stateRoot=out+'/'+label+'-state';mkdirSync(stateRoot);const stored=await f.sessions.create({...f.snapshot,taskId,native:{...f.snapshot.native,stateRoot,sessionId}},f.home);const bindingId=randomUUID();f.sqlite.prepare('INSERT INTO host_child VALUES(?,?,?,?,0)').run(taskId,f.snapshot.taskId,bindingId,null);return{label,stored,taskId,sessionId,bindingId,generation:0};}
async function start(child){
 const run=await f.runs.reserve({taskId:child.taskId,snapshotHash:child.stored.pointer.snapshotHash,bindings:[]});await run.prepare();await run.cli.arm();child.generation++;
 const id=child.label+'-'+child.generation,dir=out+'/'+id;mkdirSync(dir);const mcp=await createMcp(dir),opened=defer(),answer=defer(),attached=defer();
 const c={id,dir,child,run,mcp,opened,answer,attached,scope:{taskId:child.taskId,bindingId:child.bindingId,runId:run.runId,generation:child.generation,connectionId:randomUUID()},modelCount:0,frames:[],sendCount:0,closed:false};contexts.push(c);configs.set(id,c);f.sqlite.prepare('UPDATE host_child SET run_id=?,generation=? WHERE task_id=?').run(run.runId,child.generation,child.taskId);
 const options={pathToClaudeCodeExecutable:nativeRuntime('claude').path,cwd:child.stored.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:{...baseEnv({home:f.home,root:dir,snapshot:child.stored.snapshot}),ANTHROPIC_BASE_URL:base+'/'+id,ANTHROPIC_AUTH_TOKEN:'synthetic-only',ANTHROPIC_API_KEY:'synthetic-only'},strictMcpConfig:true,mcpServers:{wy:{type:'http',url:mcp.url}},tools:[],allowedTools:['mcp__wy__ask'],onElicitation:async(request,o)=>{
  await attached.promise;actual.assertOwnedCapabilityRun(f.runs,run);f.runs.assertActive(run.runId);assert.equal(request.message,'M14_CHILD_QUESTION');
  c.raw={request,requestId:o.requestId};c.handle=await ledger.bind(f.store,reader,c.scope,{threadId:child.sessionId,requestId:o.requestId});o.signal.addEventListener('abort',()=>{c.callbackAborted=true;answer.resolve({action:'cancel'});},{once:true});opened.resolve();return answer.promise;
 },spawnClaudeCodeProcess:o=>{
  const p=spawn(o.command,o.args,{cwd:options.cwd,env:options.env,stdio:['pipe','pipe','pipe']}),record={id,pid:p.pid,exit:null};processes.push(record);c.process=p;p.stdin.on('error',()=>{});p.stderr.on('data',b=>appendFileSync(dir+'/stderr.log',b));
  c.exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(code,signal)=>{record.exit={code,signal};resolve(record);});});const identity=reader.read(p.pid);assert(identity);run.cli.attach(p.pid,identity.startedAt).then(()=>attached.resolve(),e=>attached.reject(e));return p;
 }};
 if(child.generation===1)options.sessionId=child.sessionId;else options.resume=child.sessionId;
 c.q=query({prompt:'HOST_CHILD_QUESTION_'+id,options});c.consume=(async()=>{for await(const frame of c.q){c.frames.push(frame);appendFileSync(dir+'/frames.jsonl',JSON.stringify(frame)+'\n');}})();c.consume.catch(()=>{});
 await deadline(opened.promise,id+' form');return c;
}
function command(c,label){return{id:randomUUID(),expected:c.scope,value:{action:'accept',content:{label,count:1,enabled:true}}};}
async function answer(c,cmd){await ledger.decide(f.store,c.handle,cmd);return ledger.dispatch(f.store,c.handle,async()=>{actual.assertOwnedCapabilityRun(f.runs,c.run);f.runs.assertActive(c.run.runId);const current=f.sqlite.prepare('SELECT * FROM host_child WHERE task_id=?').get(c.scope.taskId);assert.equal(current.run_id,c.scope.runId);assert.equal(current.generation,c.scope.generation);c.sendCount++;c.answer.resolve(cmd.value);});}
async function stop(c,interrupted=false){
 if(c.closed)return;c.closed=true;if(c.handle)await ledger.cancel(f.store,c.handle);await c.run.stop();
 if(interrupted)await deadline(c.q.interrupt(),c.id+' interrupt');c.answer.resolve({action:'cancel'});if(interrupted)c.q.close();
 await deadline(c.consume.catch(e=>{if(!interrupted)throw e;}),c.id+' consume');c.q.close();if(c.exit)await deadline(c.exit,c.id+' exit');await c.run.cli.exited();await c.run.stop();assert.equal(f.runs.get(c.run.runId).state,'stopped');
}
try{
 f=await actual.runFixture(reader);ledger.initialize(f.store);f.sqlite.exec('CREATE TABLE host_child(task_id TEXT PRIMARY KEY,parent_task_id TEXT NOT NULL,binding_id TEXT NOT NULL,run_id TEXT,generation INTEGER NOT NULL);CREATE TABLE host_parent(task_id TEXT PRIMARY KEY,binding_id TEXT NOT NULL)');f.sqlite.prepare('INSERT INTO host_parent VALUES(?,?)').run(f.snapshot.taskId,randomUUID());
 server=createServer(async(req,res)=>{try{let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),c=configs.get(req.url.split('/')[1]);assert(c);c.modelCount++;assert(c.modelCount<=2);appendFileSync(c.dir+'/model.jsonl',JSON.stringify(body)+'\n');const tool=(body.tools??[]).find(t=>t.name==='mcp__wy__ask');assert(tool);if(c.modelCount===1)reply(res,'claude',body,{tool,args:{}});else{assert(JSON.stringify(body.messages).includes('FORM_RESULT_'));reply(res,'claude',body,{text:'HOST_CHILD_DONE_'+c.id});}}catch(e){serverError??=e.stack;if(!res.headersSent)res.writeHead(500);res.end('{}');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;save('native-runtime.json',nativeRuntime('claude'));
 const a=await child('a'),b=await child('b'),A=await start(a),B=await start(b);assert.deepEqual(A.raw.request,B.raw.request);
 await check('J01','identical concurrent host-child forms reject wrong child/run and parent scope',async()=>{
  await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'A'),expected:B.scope}),/REQUEST_SCOPE_CHANGED/);await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'A'),expected:{...A.scope,taskId:f.snapshot.taskId}}),/REQUEST_SCOPE_CHANGED/);assert.equal(A.sendCount+B.sendCount,0);return{sameForm:true,differentHostTasks:true,wrongChildAndParentRejected:true};
 });
 await check('J02','logical parent binding change leaves child question owner unchanged',async()=>{
  const original=ledger.inspect(f.store,B.handle.id).request.scope_json;f.sqlite.prepare('UPDATE host_parent SET binding_id=? WHERE task_id=?').run(randomUUID(),f.snapshot.taskId);assert.equal(ledger.inspect(f.store,B.handle.id).request.scope_json,original);assert.equal(ledger.inspect(f.store,B.handle.id).view.awaitingUser,true);return{candidateParentPointerOnly:true,childRunUnaffected:true,notNativeProviderSwitch:true};
 });
 await check('J03','stopped child refuses old response while sibling completes',async()=>{
  await stop(A,true);await assert.rejects(ledger.decide(f.store,A.handle,command(A,'OLD')),/REQUEST_NOT_OPEN|REQUEST_CANCELLED/);await assert.rejects(answer(A,command(A,'OLD')),/REQUEST_NOT_OPEN|REQUEST_CANCELLED/);assert.equal(A.sendCount,0);
  const cmd=command(B,'B_ONLY');await answer(B,cmd);await ledger.decide(f.store,B.handle,cmd);await deadline(B.consume,'B completed');assert.equal(B.frames.findLast(x=>x.type==='result').is_error,false);assert.deepEqual(B.mcp.records.map(x=>x.result),[cmd.value]);assert.equal(B.sendCount,1);await stop(B);return{oldAnswerNotSent:true,siblingAnswerObservedByActualMcp:true,decisionRepeatNoDuplicateSend:true};
 });
 const A2=await start(a);
 await check('J04','same child native session next run keeps prior response expired',async()=>{
  assert.equal(A2.scope.generation,A.scope.generation+1);assert.notEqual(A2.scope.runId,A.scope.runId);assert.equal(A2.child.sessionId,A.child.sessionId);
  await assert.rejects(ledger.decide(f.store,A.handle,{...command(A,'OLD'),expected:A2.scope}),/REQUEST_SCOPE_CHANGED/);assert.equal(A2.sendCount,0);
  const cmd=command(A2,'A_NEXT');await answer(A2,cmd);await deadline(A2.consume,'A2 completed');assert.equal(A2.frames.findLast(x=>x.type==='result').is_error,false);assert.deepEqual(A2.mcp.records.map(x=>x.result),[cmd.value]);await stop(A2);return{actualSdkResumeSameNativeId:true,hostRunAndGenerationChanged:true,oldResponseIsolated:true,newAnswerObserved:true};
 });
 if(serverError)throw Error(serverError);
}catch(e){error=e.stack;process.exitCode=1;}
finally{
 for(const c of contexts)try{await stop(c,true);}catch(e){error??=e.stack;process.exitCode=1;if(c.process&&c.process.exitCode===null&&c.process.signalCode===null){c.process.kill('SIGTERM');await deadline(c.exit,'cleanup');}};
 for(const c of contexts)await c.mcp.close();if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}
 if(f){save('host-state.json',{children:f.sqlite.prepare('SELECT * FROM host_child').all(),parent:f.sqlite.prepare('SELECT * FROM host_parent').all(),requests:f.sqlite.prepare('SELECT * FROM m14_request_reply').all(),decisions:f.sqlite.prepare('SELECT * FROM m14_response_decision').all(),runs:f.sqlite.prepare('SELECT * FROM capability_runs').all(),leases:f.sqlite.prepare('SELECT * FROM capability_resource_leases').all()});assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(out+'/final.sqlite');f.sqlite.close();}
}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:error??null,serverError:serverError??null,modelRequests:contexts.reduce((n,c)=>n+c.modelCount,0),processes,scope:'Actual Claude SDK forms/resume, actual child run ownership, candidate parent-child pointers and response ledger in one current store. Synthetic forms/answers/local model. No actual delegation creation/outbox service, real parent provider switch, user UI, business approval, request-ledger crash or Codex pair.'};save('result.json',result);writeFileSync(root+'/latest.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
