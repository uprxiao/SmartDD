from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_执行配置修订与凭据原子性验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==12 and not result.get('error')
build=json.loads((root/'profile-build.json').read_text())
for s in build['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
references=[(repo,'src/main/core/ai/ai-profile-service.ts'),(repo,'src/main/secrets.ts'),(repo,'src/main/core/projects/transfer-service.ts'),(repo,'src/main/core/ai/controller.ts'),(repo,'src/main/core/ai/profile-health.ts'),(repo,'src/main/core/tasks/task-service.ts'),(t3,'apps/server/src/provider/ProviderInstanceRegistry.ts'),(t3,'apps/server/src/provider/ProviderInstanceRegistry.test.ts')]
review={'scope':'Actual local source; T3 registry behavior statically reviewed, its tests not executed in this batch.','references':[{'path':str(r/p),'sha256':sha((r/p).read_bytes())}for r,p in references],'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'buildInputs':len(build['sources'])};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('result.json',json.dumps(result,ensure_ascii=False,indent=2)),('source-review.json',json.dumps(review,ensure_ascii=False,indent=2)),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes())]:put(exp/n,data)
put(exp/'README.md',f'''# 执行配置修订与凭据原子性：独立技术验证

日期：2026-11-14。对应 R02／03／08／11，Q06／20；设计 §3.2.11、验证账 §4.42。仅在临时目录运行，未改产品、共享原型、用户配置或真实凭据。

## 关键发现

现有 AiProfileService.update 的 Drizzle 事务已涵盖配置行和 SecretsStore 对 app_secrets 的写入。safeStorage 是密文生成／解析接口，数据库内实际保存密文；这里不是“数据库事务必须原子修改系统钥匙串”的跨存储问题。可复用现有事务，不重做凭据服务。

独立候选以每个 profile 的单调 execution revision 跟踪 runner、executable、env、args、commandPending，以及当前引用的密钥记录变化。名称、颜色、默认项和普通健康信息不推进修订。版本与配置／密文在同一事务变动；删除保留失效记录，防止同 ID 再插入恢复旧许可。修订只用于失效判断，不计业务操作次数；一次保存可以递增多次，重写同明文但生成不同密文也可以保守失效。

本批以数据库触发器验证写入覆盖，既覆盖实际服务，也覆盖现有导入中绕过 AiProfileService 的直接表写入顺序。触发器不是完成的正式迁移器；完整 schema 版本／触发器完整性检查、旧宿主写入门槛、升级回退及性能仍须接最终设计。不能只包装设置页 update 方法便声称覆盖所有配置入口。

## 实跑结果

`{Path(result['out']).name}` 的 V01–V12 全部通过，无失败后重跑。构建使用实际配置／密钥服务与现有全部 SQL 迁移；未使用的 node-pty 发现依赖仍为必抛错 stub，假加密器／固定时钟与合成值都有明确边界。

| 项 | 实际证明 |
| --- | --- |
| V01 | 不装候选表时，实际 update 先删除／写入部分密钥，再在下一次加密故障后，配置和全部密文整体恢复 |
| V02 | 候选迁移保留原数据，初始化修订；同一版本的简单重复调用不重置修订 |
| V03 | 改名称／颜色／默认／普通健康信息保留修订；相同 updatedAt 下改启动参数仍使旧句柄失效 |
| V04 | 实际 SecretsStore 直接换 Key，无需改 profile 时间戳即可使旧句柄失效 |
| V05 | 数据库等其他业务密钥、别的 profile 和当前未引用的密钥不影响该 profile |
| V06 | 候选修订与实际配置／密钥在中途加密失败时一起回滚 |
| V07 | 第二 SQLite 连接在实际 resolve 的解密期间旋转密钥，前后修订检查拒绝发出可能混合新旧值的句柄 |
| V08 | 序列化句柄无执行权；密钥缺失／假安全存储不可用拒绝捕获，不回退；公开句柄不含明文 |
| V09 | 删除后保留失效记录；夹具直接重建同 ID，修订不归零，旧句柄不能复活 |
| V10 | commandPending 变动推进修订；禁止在调用者的旧事务快照内作“当前”配置核验 |
| V11 | 按实际导入源码顺序先密钥后 profile 插入，得到有效初始修订；事务失败都回滚，未执行完整 TransferService |
| V12 | 已有无效 JSON 在迁移前明确拒绝，保留原始数据，不留下部分新表 |

## 来源捕获与边界

候选 capture 先读修订，调用实际 resolve，再读修订；不一致即拒绝，无自动重选。明文只留在私有 WeakMap 内，公开句柄仅 profileId／revision；consume 再核当前修订与句柄来源。本批 consume 为同步断言回调，未启动 Agent，也未将该修订接入上一实验的 ExecutionPlan／delivery 或 SDK fork。两连接交错不等于真实多进程崩溃验证；没有 SIGKILL、系统钥匙串或外部配置文件的动态变化实验。

已有 SQLite read transaction 可能维持旧视图，候选直接拒绝在外部事务中捕获／核验；正式事务协调需要与资源协调锁和启动入口统一。数据库修订看不到 CLI 配置文件、继承环境、系统代理、外部凭据提供方或 executable 替换，完整目标来源向量仍需单独处理。已启动进程拿到的旧环境不能靠修订号撤回；运行中改 Key 的后续回合／恢复策略与取消清理仍需联合验证。

T3 本地 Registry.reloadWhere 对成功读取且确实变化的秘密重建实例；普通重读失败会保留已有可用实例及旧值。此为源码事实，不代表 WillYou 的新派发可以绕过缺 Key 检查，也不是 T3 提供了本候选数据库修订机制。实际安全存储、外部秘密源和完整原生生命周期仍按各自条件验证。

## 证据

[结果](result.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[实验与数据库归档](raw-evidence.tar.gz)。{len(files)} 个归档文件，{len(dbs)} 份 SQLite 通过完整性／外键检查，{len(build['sources'])} 个构建输入摘要复核。

在临时目录恢复后，以记录中的 Node／better-sqlite3 依赖运行 `node probe.mjs`；`profile-build.mjs` 可在匹配源码上重建。假加密器保存的是显式 synthetic 数据，不可用于产品；未读取用户 safeStorage、真实 HOME 或真实配置库。
''')
section='''### 3.2.11 执行配置修订与现有凭据事务

[配置原子性实验](实验/20261114_执行配置修订与凭据原子性验证/README.md)确认现有 AiProfileService 的事务已经覆盖配置行与 SecretsStore 的密文行，迁移应保留它。系统安全存储负责加解密，本地密文仍在同一 SQLite；不为解决修订号另建一套账号／密钥存储。加密失败的现有事务回滚和候选修订一起回滚已有实际服务证据。

每个 profile 维护单调执行修订，以下变更在同一写入事务推进：runner／命令／参数／环境的持久内容、commandPending，以及当前引用的凭据新增、替换或删除。名称／颜色／默认选择与不改变命令可用性的健康结果独立维护，不触发执行失效。修订不表示操作数量，可以一笔保存递增多次；相同明文重新加密产生不同密文时允许保守失效，不把密文相等或时间戳当作语义版本。删除保留失效代次，不因重建同 ID 而复活旧运行许可。

修订覆盖必须落到所有写入入口。现有项目导入直接写 ai_profiles，并先写对应 app_secrets；只在 AiProfileService.update 外加计数会漏掉这一入口。候选 SQL 触发器已验证当前服务写入、直接凭据写入及导入顺序的事务一致性；正式落地须纳入统一迁移器、版本／触发器完整性检查和旧宿主写入门槛。未声明的旧结构不能仅见“表存在”就当升级成功；本批简单幂等探针不替代这些迁移规则。

配置捕获采用同一可信来源：读取修订 → 实际 resolve → 再读修订；中途变更拒绝，不自动换账号重试。明文只留在宿主私有执行上下文，计划记录来源身份／修订；消费前再次核验。外层长读事务可能让两次查询看到相同旧快照，不能将其当最新配置；候选禁止在调用者已有事务里执行此检查，最终锁与数据库协调顺序需与原生派发一起验证。两个 SQLite 连接在实际解密期间交错换 Key 的拒绝路径已验证。

此修订覆盖宿主数据库中的配置与凭据，不能覆盖用户 CLI 文件、继承环境、系统代理、外部秘密源或程序文件替换；完整来源向量须由对应解析器给出。对新启动、重新打开或后续回合需要准备的新执行计划，配置缺失／待配置／修订变化均不得借旧缓存继续派发；已经交给原生进程的环境不会被计数器撤回，不宣称改 Key 等于所有在途请求已取消。取消／收尾仍按 owned run 权限执行，不能因配置已删而失去释放路径。

T3 的 ProviderInstanceRegistry 在读取到变化的秘密后重建实例，普通重读失败时保留已有实例。参考其“实例生命周期与来源刷新分离”，但不将“已有实例可继续存在”写成 WillYou“新派发可使用失效配置”。完整运行中的回合边界、原生会话重建与来源刷新仍需联合验证。本批未启动 Agent，也未接上一批 ExecutionPlan 的最终消费链。

'''
def tech(t):
 old='本批实际服务已证实时间戳反例，完整 revision 生成与密钥提交事务仍待验证。';new='实际服务已证实时间戳反例；数据库内执行修订与密钥事务已有 §3.2.11 的局部证据，完整来源向量及原生消费仍待验证。';assert t.count(old)==1;t=t.replace(old,new);assert t.count('### 3.3 真实所有权')==1;return t.replace('### 3.3 真实所有权',section+'### 3.3 真实所有权')
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.42 执行配置修订与凭据原子性

[配置修订实验](实验/20261114_执行配置修订与凭据原子性验证/README.md)通过 V01–V12：实际 AiProfileService／SecretsStore 已有事务回滚；候选单调 revision 与配置／密文同事务变动，支持同毫秒换 Key、直接凭据写入、名称与健康信息不误失效、删除后同 ID 不复活、commandPending、缺 Key 和两 SQLite 连接交错捕获。按真实导入源码顺序的直接写入夹具也有回滚证据，未执行完整 TransferService。

本批没有 Agent、真实钥匙串或模型调用。候选使用 SQL 触发器、假加密器与固定时钟；capture／consume 是独立私有句柄，尚未接完整 ExecutionPlan／SDK 派发。迁移版本／触发器完整性、外部配置来源、在途生命周期和最终 fork 竞争仍待验。T3 的秘密刷新保留／重建规则只作源码对照，不把其既有实例保留视为新派发授权。T0.1 §3.2.11 收录现行约束；Q06／Q20 保持部分。

'''
def account(t):
 assert t.count('## 5. 失败与驱动修正')==1;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q06','Q20']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.42 补实际配置／密钥事务、候选单调修订及两连接交错捕获；完整来源与原生消费待验 |';t='\n'.join(lines)+'\n'
 old='§4.41 补宿主计划关联及实际配置标识／时间戳反例；下一步优先收口';new='§4.41 补宿主计划关联及实际配置标识／时间戳反例；§4.42 补数据库配置修订与凭据事务；下一步优先收口';assert old in t;return t.replace(old,new)
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：宿主计划关联及真实配置标识／时间戳反例已有局部证据；本轮验证现有配置与密钥事务可复用，并补同毫秒换 Key、修订回滚与两连接交错读取。现行设计见[技术方案 §3.2.11](技研/技术方案.md)；完整来源向量、程序化原生启动与所有业务读取方仍待收口。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':len(build['sources'])}))
