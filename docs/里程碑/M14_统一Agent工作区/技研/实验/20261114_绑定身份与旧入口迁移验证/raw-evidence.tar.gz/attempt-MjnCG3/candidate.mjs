import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {z} from 'zod';
import actual from './actual.cjs';
const {storedCapabilitySessionSnapshotSchema:snapshotSchema,canonicalJson,digest,selectionHash}=actual;
const id=z.string().min(1).max(128),hash=z.string().regex(/^[a-f0-9]{64}$/);
export const scopeSchema=z.object({schema:z.literal('m14-binding-scope-probe-v1'),taskId:id,bindingId:z.uuid(),capabilitySessionId:z.uuid(),snapshotHash:hash,runner:z.string().regex(/^[a-z][a-z0-9-]{0,63}$/),generation:z.number().int().positive()}).strict();
export function decode(row){const value=snapshotSchema.parse(JSON.parse(row.snapshot_json));assert.equal(value.taskId,row.task_id);assert.equal(digest(canonicalJson(value)),row.snapshot_hash);return value;}
export function schema(db){db.exec(readFileSync(new URL('./candidate.sql',import.meta.url),'utf8'));}
export function currentScope(db,taskId){return db.prepare('SELECT c.task_id AS taskId,c.binding_id AS bindingId,c.cap_id AS capabilitySessionId,c.current_hash AS snapshotHash,b.runner FROM m14_cap c JOIN m14_binding b USING(binding_id) WHERE c.task_id=?').get(taskId);}
export function load(db,input){const scope=scopeSchema.parse(input);const row=db.prepare('SELECT r.*,b.runner,c.retention FROM m14_revision r JOIN m14_cap c USING(cap_id,task_id,binding_id) JOIN m14_binding b USING(binding_id,task_id) WHERE r.task_id=? AND r.binding_id=? AND r.cap_id=? AND r.snapshot_hash=?').get(scope.taskId,scope.bindingId,scope.capabilitySessionId,scope.snapshotHash);assert(row,'exact binding revision absent');assert.equal(row.runner,scope.runner);const value=decode(row);assert.equal(value.runner,scope.runner);return{scope,value,row};}
export function addRevision(db,bindingId,capId,row,refs){
 const value=decode(row),binding=db.prepare('SELECT * FROM m14_binding WHERE binding_id=? AND task_id=?').get(bindingId,row.task_id);assert(binding,'binding owner absent');assert.equal(value.runner,binding.runner);assert.equal(value.native.cwd,binding.cwd);assert.equal(value.native.stateRoot,binding.identity_root);assert(value.native.sessionId===null||value.native.sessionId===binding.native_id,'native lineage mismatch');
 for(const ref of refs){const r=db.prepare('SELECT * FROM capability_resources WHERE resource_id=?').get(ref.ref_id);assert(r,'resource absent');assert.equal(r.kind,ref.ref_kind);assert.equal(r.content_hash,ref.ref_hash);assert.equal(r.scope_relative_path??r.relative_path,ref.relative_path);}
 const expected=new Set(['agent-adapter:'+value.runner+':'+value.adapterBinding.hash,...value.packages.flatMap(p=>['app:'+p.packageHash,'runtime:'+p.runtimeHash]),...value.standardSkills.map(s=>'standard-skill:'+s.skillId+':'+s.hash),...value.mcp.map(m=>(m.kind==='applications'?'runtime:':'legacy-runtime:')+m.runtimeHash)]);
 assert([...expected].every(id=>refs.some(r=>r.ref_id===id)),'required resource omitted');
 db.prepare('INSERT INTO m14_revision VALUES(?,?,?,?,?,?,?)').run(capId,row.task_id,bindingId,row.snapshot_hash,row.snapshot_json,value.schema,selectionHash(value));
 for(const r of refs)db.prepare('INSERT INTO m14_ref VALUES(?,?,?,?,?,?,?)').run(capId,row.snapshot_hash,r.ref_id,r.ref_kind,r.ref_hash,r.relative_path,row.task_id);
 return value;
}
export function claimBinding(db,{bindingId=randomUUID(),taskId,runner,identityRoot,nativeId,cwd,legacyTaskId=null}){
 const old=nativeId&&db.prepare('SELECT task_id FROM capability_session_identities WHERE runner=? AND identity_root=? AND session_id=?').get(runner,identityRoot,nativeId);
 assert(!old||old.task_id===legacyTaskId,'legacy native identity already owned');
 db.prepare('INSERT INTO m14_binding VALUES(?,?,?,?,?,?,?,?)').run(bindingId,taskId,runner,identityRoot,nativeId,cwd,legacyTaskId,'legacy');return bindingId;
}
export function claimMcp(db,bindingId,taskId,name,kind,legacyTaskId=null){
 const old=db.prepare('SELECT task_id FROM capability_session_mcp_names WHERE server_name=?').get(name);assert(!old||old.task_id===legacyTaskId,'legacy MCP name already owned');
 db.prepare('INSERT INTO m14_mcp VALUES(?,?,?,?)').run(name,bindingId,taskId,kind);
}
export async function migrate(db,checkpoint=async()=>{}){
 if(db.prepare("SELECT 1 FROM sqlite_master WHERE name='m14_migration'").get()&&db.prepare('SELECT 1 FROM m14_migration WHERE version=1').get())return'already-migrated';
 const oldSql=db.prepare("SELECT sql FROM sqlite_master WHERE name='capability_runs'").get().sql,cols=db.pragma('table_info(capability_runs)').map(r=>r.name),indexes=db.prepare("SELECT sql FROM sqlite_master WHERE tbl_name='capability_runs' AND type='index' AND sql IS NOT NULL").all().map(x=>x.sql);
 assert(!db.inTransaction);db.pragma('foreign_keys=OFF');db.exec('BEGIN IMMEDIATE');
 try{
  assert(!db.prepare("SELECT 1 FROM capability_runs WHERE state NOT IN ('stopped','failed') OR revocation_state='revoking'").get(),'run unresolved');assert(!db.prepare("SELECT 1 FROM capability_run_processes WHERE state NOT IN ('exited','canceled')").get(),'process unresolved');assert(!db.prepare("SELECT 1 FROM capability_resource_leases WHERE state<>'released'").get(),'lease unresolved');
  schema(db);const sessions=db.prepare('SELECT * FROM capability_session_snapshots ORDER BY task_id').all();
  for(const row of sessions){
   if(row.retention_state==='hold'||![2,3].includes(row.schema_version)){db.prepare('INSERT INTO m14_unmapped VALUES(?,?,?)').run(row.task_id,row.snapshot_hash,row.retention_state==='hold'?'held':'unknown-schema');continue;}
   const current=decode(row),identity=db.prepare('SELECT * FROM capability_session_identities WHERE task_id=?').get(row.task_id);assert(identity,'native identity missing');assert.equal(identity.runner,current.runner);assert.equal(identity.session_id,current.native.sessionId);assert.equal(identity.cwd,current.native.cwd);assert.equal(identity.identity_root,current.native.stateRoot);assert.equal(identity.selection_hash,selectionHash(current));
   const bindingId=claimBinding(db,{taskId:row.task_id,runner:current.runner,identityRoot:identity.identity_root,nativeId:identity.session_id,cwd:identity.cwd,legacyTaskId:row.task_id}),capId=randomUUID();db.prepare('INSERT INTO m14_cap VALUES(?,?,?,?,?)').run(capId,row.task_id,bindingId,row.retention_state,null);
   const refs=db.prepare('SELECT * FROM capability_session_refs WHERE task_id=?').all(row.task_id),versions=db.prepare('SELECT * FROM capability_snapshot_versions WHERE task_id=? ORDER BY snapshot_hash').all(row.task_id);assert(versions.some(v=>v.snapshot_hash===row.snapshot_hash),'current version missing');
   for(const v of versions){const snapshot=decode(v);if(selectionHash(snapshot)!==selectionHash(current)){db.prepare('INSERT INTO m14_unmapped_version VALUES(?,?,?,?,?)').run(v.task_id,v.snapshot_hash,v.snapshot_json,selectionHash(snapshot),'different-selection-preserved-legacy');continue;}addRevision(db,bindingId,capId,v,refs);}
   db.prepare('UPDATE m14_cap SET current_hash=? WHERE cap_id=?').run(row.snapshot_hash,capId);
   for(const m of current.mcp)claimMcp(db,bindingId,row.task_id,m.serverName,m.kind,row.task_id);
  }
  let sql=oldSql.replace(/^CREATE TABLE\s+["`]?capability_runs["`]?/i,'CREATE TABLE m14_runs_rebuild');assert.notEqual(sql,oldSql);sql=sql.replace(/REFERENCES\s+["`]?capability_session_snapshots["`]?\s*\(["`]?task_id["`]?\)\s*(?:ON DELETE RESTRICT)?/i,'');assert(!sql.includes('REFERENCES capability_session_snapshots'));
  sql=sql.trim().slice(0,-1)+`, binding_id TEXT,capability_session_id TEXT,execution_mode TEXT NOT NULL DEFAULT 'legacy' CHECK(execution_mode IN ('legacy','programmatic')),generation INTEGER,
   CHECK((binding_id IS NULL)=(capability_session_id IS NULL)),CHECK(execution_mode='legacy' OR (binding_id IS NOT NULL AND snapshot_hash IS NOT NULL AND generation IS NOT NULL AND typeof(generation)='integer' AND generation>0)),
   FOREIGN KEY(binding_id,task_id,runner) REFERENCES m14_binding(binding_id,task_id,runner),
   FOREIGN KEY(capability_session_id,task_id,binding_id,snapshot_hash) REFERENCES m14_revision(cap_id,task_id,binding_id,snapshot_hash))`;
  db.exec(sql);const names=cols.map(c=>'"'+c+'"').join(',');db.exec(`INSERT INTO m14_runs_rebuild(${names}) SELECT ${names} FROM capability_runs`);
  db.exec(`UPDATE m14_runs_rebuild SET binding_id=(SELECT r.binding_id FROM m14_revision r WHERE r.task_id=m14_runs_rebuild.task_id AND r.snapshot_hash=m14_runs_rebuild.snapshot_hash),capability_session_id=(SELECT r.cap_id FROM m14_revision r WHERE r.task_id=m14_runs_rebuild.task_id AND r.snapshot_hash=m14_runs_rebuild.snapshot_hash)`);
  await checkpoint('before-drop');db.exec('DROP TABLE capability_runs');await checkpoint('after-drop');db.exec('ALTER TABLE m14_runs_rebuild RENAME TO capability_runs');for(const index of indexes)db.exec(index);
  db.exec(`CREATE TRIGGER m14_old_run_guard BEFORE INSERT ON capability_runs WHEN NEW.execution_mode='legacy' AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.task_id=NEW.task_id AND b.entry_mode='programmatic') BEGIN SELECT RAISE(ABORT,'M14_LEGACY_WRITER_SEALED');END;
   CREATE TRIGGER m14_old_identity_guard BEFORE UPDATE ON capability_session_identities WHEN EXISTS(SELECT 1 FROM m14_binding b WHERE b.task_id=NEW.task_id AND b.entry_mode='programmatic') BEGIN SELECT RAISE(ABORT,'M14_LEGACY_IDENTITY_SEALED');END;
   CREATE TRIGGER m14_old_native_insert_guard BEFORE INSERT ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.runner=NEW.runner AND b.identity_root=NEW.identity_root AND b.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_IDENTITY_CONFLICT');END;
   CREATE TRIGGER m14_old_native_update_guard BEFORE UPDATE ON capability_session_identities WHEN NEW.session_id IS NOT NULL AND EXISTS(SELECT 1 FROM m14_binding b WHERE b.runner=NEW.runner AND b.identity_root=NEW.identity_root AND b.native_id=NEW.session_id AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_NATIVE_IDENTITY_CONFLICT');END;
   CREATE TRIGGER m14_old_mcp_insert_guard BEFORE INSERT ON capability_session_mcp_names WHEN EXISTS(SELECT 1 FROM m14_mcp m JOIN m14_binding b USING(binding_id) WHERE m.server_name=NEW.server_name AND b.legacy_task_id IS NOT NEW.task_id) BEGIN SELECT RAISE(ABORT,'M14_MCP_NAME_CONFLICT');END;`);
  assert.deepEqual(db.pragma('foreign_key_check'),[]);db.prepare('INSERT INTO m14_migration VALUES(1,?)').run(digest(oldSql));db.exec('COMMIT');await checkpoint('after-commit');return'migrated';
 }catch(e){if(db.inTransaction)db.exec('ROLLBACK');throw e;}
 finally{db.pragma('foreign_keys=ON');assert.equal(db.pragma('foreign_keys',{simple:true}),1);}
}
