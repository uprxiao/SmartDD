CREATE TABLE capability_broker_denials (
 audit_id TEXT PRIMARY KEY NOT NULL,
 host_generation TEXT NOT NULL,
 run_id TEXT,
 bridge_id TEXT,
 method TEXT NOT NULL CHECK(method IN ('unknown','exchange','renew','tools/list','tools/call','cancel','cli-parse','cli-list','cli-call','cli-cancel')),
 error_code TEXT NOT NULL,
 observed_at TEXT NOT NULL,
 CHECK ((method IN ('cli-parse','cli-list','cli-call','cli-cancel') AND bridge_id IS NULL) OR (method IN ('unknown','exchange','renew','tools/list','tools/call','cancel') AND ((run_id IS NULL AND bridge_id IS NULL) OR (run_id IS NOT NULL AND bridge_id IS NOT NULL))))
);
