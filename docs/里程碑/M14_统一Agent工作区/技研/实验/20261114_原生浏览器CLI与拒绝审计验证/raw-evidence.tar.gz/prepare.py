from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生浏览器CLI与拒绝审计验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
r=json.loads((root/'latest.json').read_text());assert r['passed']==5 and not r.get('error');a=Path(r['out']);attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());assert result['passed']==5 and not result.get('error');events=json.loads((attempt/'events.json').read_text());exits=[x for x in events if x['event']=='owned-exit'];assert len(exits)==3 and all(x['code']==(0 if x['id'].startswith('codex')else 143)for x in exits)
 db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 for query in ["SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'","SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'","SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')","SELECT COUNT(*) FROM capability_run_activities WHERE state='active'"]:assert db.execute(query).fetchone()==(0,)
 roots=db.execute("SELECT pid,process_started_at FROM capability_run_processes WHERE kind='cli'").fetchall();inv=db.execute('SELECT state,effect_state,error_code,count(*) FROM application_invocations GROUP BY 1,2,3').fetchall();assert sorted(inv)==[('failed','read-only','SCOPE_DENIED',3),('succeeded','completed',None,3),('succeeded','read-only',None,6)];assert db.execute('SELECT count(*) FROM capability_broker_denials').fetchone()==(0,);db.close()
 proofs=json.loads((attempt/'proofs.json').read_text());assert len(proofs)==25;owners={pid:0 for pid,birth in roots};outside=0
 for proof in proofs:
  assert proof['peer']['executable']==str(root/'willyou-app');matched=[pid for pid,birth in roots if any(x['pid']==pid and x['startedAt']==birth for x in proof['ancestors'])];assert len(matched)<=1
  if matched:owners[matched[0]]+=1
  else:outside+=1
 assert outside==1 and set(owners.values())=={8}
 models=json.loads((attempt/'models.json').read_text());assert len(models)==15
 for x in models:
  if x['count']==1:continue
  b=x['body'];latest=([y for y in b.get('input',[])if y.get('type')=='function_call_output']if x['driver']=='codex'else[y for msg in b['messages']if isinstance(msg['content'],list)for y in msg['content']if y.get('type')=='tool_result'])[-1];expected='SCOPE_DENIED'if x['count']==3 else'browser.access.request'if x['count']==4 else'browser.tab.list';assert expected in json.dumps(latest)
 outsideResult=json.loads((attempt/'outside-owner.json').read_text());assert outsideResult['code']!=0 and 'PEER_MISMATCH'in outsideResult['stdout']
 attempts.append({'attempt':attempt.name,'passed':5,'nativeExits':exits,'modelRequests':15,'kernelProofs':25,'proofsPerNativeRoot':owners,'outsideOwnerProofs':outside,'businessCalls':12,'rejectedBeforeGrant':3,'grantedRequests':3,'successfulReads':6,'allNativeAndBusinessSettled':True,'probeSha256':sha((attempt/'probe.mjs').read_bytes())})
assert len(attempts)==2
old=json.loads((a/'revoked-token-cli.json').read_text());assert old['code']!=0 and 'AUTH_REQUIRED'in old['stdout'];assert r['checks'][-1]['evidence']['allCliPeerIdentitiesStopped']
cli=json.loads((a/'cli-binary.json').read_text());assert sha((root/'willyou-app').read_bytes())==cli['sha256'];assert sha((root/'cli-source.mm').read_bytes())==cli['sourceSha256']==sha((repo/'native/applications/cli.mm').read_bytes());schema=json.loads((root/'audit-schema/result.json').read_text());assert schema['originalGatewayFailure']['auditUnavailable']and len(schema['candidateGatewayReceipts'])==8
runtime={'attempts':attempts,'finalAttempt':a.name,'scope':r['scope'],'cli':cli,'revokedTokenCli':old,'schemaReproduction':schema,'auditWarning':'Real rejection output succeeded, but original capability_broker_denials remained empty. CHECK restricts methods to MCP names and requires bridge_id for non-null run_id; actual CLI denial uses cli-* and no bridge_id. Native CLI refused() omits top-level auditId/auditUnavailable.','supportedScope':'macOS arm64 fixed versions and local synthetic model. No Electron pages or real login/network business.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications'/n for n in ['cli-gateway.ts','unix-peer-identity.ts','modules/browser/index.ts','execution-context.ts']]+[repo/'native/applications/cli.mm',repo/'native/applications/process-identity.cc',repo/'scripts/applications/build.mjs',repo/'drizzle/0028_capability_broker_denials.sql',repo/'src/main/core/browser/access.ts',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'kernelHelper':{'path':'/private/tmp/willyou-m14-owner-probe/process-identity','sha256':sha(Path('/private/tmp/willyou-m14-owner-probe/process-identity').read_bytes())},'variants':['Prior programmatic session/run/retention and await-activity launch candidate reused.','Electron allocations forbidden by explicit stub.','Browser bundle uses current definitions/assets with research runtime rebinding; not original distributable identity.','Controlled local model directs only fixed CLI browser read/access commands. Codex thread uses danger-full-access in private fixture; Claude allowedTools Bash. This verifies business gateway authority, not native sandbox strength.','Copied SQLite CHECK migration is candidate only; actual Gateway.denial method unchanged.'],'t3Boundary':'T3 provider/runtime scope is reference. Existing WillYou browser CLI gateway, process ancestry and browser grants remain authoritative business path; no new public MCP authorization bypass.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log','.md','.mm']and not(p.parent==root and p.name in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json'])];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生浏览器 CLI 与拒绝审计兼容

2026-11-14；技术方案 §9.7.1，验证账 §4.69；R02／03／05／08／10，Q09／27／28／37。仅隔离研究，产品／共享原型未改。

## 真实链路与五项检查

`Codex exec_command／Claude Bash → 当前源码编译的 willyou-app → ApplicationCliGateway → MacUnixPeerIdentityReader → ApplicationToolService(entry=cli) → 原 BrowserModule／context／BrowserService`

本批不再由研究宿主直接替 Agent 调用业务工具。模型端点为本机受控响应，按固定步骤要求每个真实原生运行：读取自己的空标签列表 → 未授权读取其他 task（SCOPE_DENIED）→ 申请跨任务授权 → 宿主允许后再次读取。每一步最新工具输出进入下一模型请求，三个 run 各五次请求。原生运行固定 Codex 0.167.1、Claude SDK 0.3.321／native 2.1.321。

| 检查 | 结果 |
| --- | --- |
| N01 真实二进制＋错误进程树 | 研究宿主直接启动同一 willyou-app，并给它有效临时 token；内核对端可核验但不属于 Agent 祖先链，返回 PEER_MISMATCH |
| N02 父子分别授权 | Codex 父、Claude 子的原生 shell 各完成实际 CLI 流程；等待的授权分别绑定父／子 run；批准 control／observe 后读成功，未批准之前被拒 |
| N03 停旧父 | 原父停止、旧 token 再经真实 CLI 返回 AUTH_REQUIRED；旧 owner 业务入口拒绝，仍活跃子的 grant 保留 |
| N04 同 task 新 Provider | 新 Claude run 保留父 task，但重新经过 CLI 未授权拒绝与独立申请，不能继承旧父 grant |
| N05 排空 | 三个原生 run 及业务活动结束、授权清空；所有记录的 CLI peer PID／出生身份核验 stopped；宿主 BrowserService 在运行停止后才由实验最终关闭 |

最终 {a.name}，五项通过。25 份真实内核 peer 证明：三个原生根各八份（四条 CLI 命令各发现＋调用），另一个属于错误祖先反例；旧 token 拒绝在读取 peer 前发生。12 条业务调用＝6 条成功读取、3 条获批授权、3 条未授权读取拒绝。三次授权返回 completed 不代表修改网页。首批 attempt-iJQGuD 已通过相同五组，随后补旧 token 实际请求与 peer 退出断言复验；两批六个 native 最终退出，共 30 次本机模拟模型请求。

## 现有审计缺口与候选迁移

真实 CLI 拒绝正确，但 capability_broker_denials 无记录。当前 0028 表约束只允许 MCP 方法，且已知 run 要求同时有 bridge_id；CLI 网关实际写 cli-parse／cli-list／cli-call／cli-cancel，且没有 MCP bridge_id。原 Gateway.denial 捕获 SQLite 失败后返回 auditUnavailable，CLI refused 又只输出 error／requestId，调用端看不到顶层审计状态。

复制 final.sqlite 的最小复现直接调用未修改 Gateway.denial，确认 auditUnavailable。候选表重建扩展四个 CLI 方法及独立 CLI 行形状：CLI bridge_id 必须空，run_id 可为空；MCP 原来的成对约束保留。原方法无需改造即可对 4 方法 × 已知／未知 run 写出 8 个 auditId。旧行保留、事务中途失败回滚、无桥已知 MCP run 拒绝、伪 CLI bridge 拒绝、未知 method 拒绝均已检查。不是正式迁移编号，也未修改用户数据库。

迁移方案必须明确该补齐：不能伪造 bridge_id 绕过检查；审批／鉴权拒绝仍按失败返回，审计写失败另展示可恢复诊断。统一 UI 不应依赖当前 CLI 输出恢复完整审计状态，需从宿主投影读取，或明确扩充并版本化 CLI 返回字段。CLI 输出传播 auditId／auditUnavailable 尚未实施或验证。

## 范围和复跑

Electron 原生窗口／session 分配被禁止，只有空 tab 列表；没有真实网页、登录态、网页写、输入／下载、真实 renderer 批准、远程供应商或平台沙箱能力验证。Codex 使用实验私有 danger-full-access thread、Claude 允许固定 Bash，业务授权依旧由真实 CLI 网关核验；不据此声称原生只读隔离。资源定义来自当前源码，但 bundle runtime hash 重绑至研究桥；不是正式发布资源证据。

编译：在 SmartDD 根目录执行归档 build-cli.mjs，输出临时 willyou-app；归档 cli-source.mm 和 cli-binary.json 保留源码／二进制哈希。运行 probe.mjs，再运行 audit-schema.mjs（只写复制 SQLite）。baseline.sqlite 为原快照，working／after 为候选结果，initial-working-copy 为首次同一 Schema 实验的工作副本。SDK/native 与依赖固定，全部 HOME、数据、模型端点临时隔离。

[结果](result.json)、[运行／Schema 审计](runtime-audit.json)、[源码依据](source-review.json)、[摘要](archive-manifest.json)、[原始脚本／模型协议／SQLite](raw-evidence.tar.gz)。{len(files)} 文件，{len(dbs)} 份 SQLite 完整性与外键通过，{len(sources)} 构建输入核对。
''')
section='''### 9.7.1 原生 shell、受管 CLI 与审计兼容

[原生浏览器 CLI 实验](实验/20261114_原生浏览器CLI与拒绝审计验证/README.md)补齐 §9.7 的传输缺口：Codex exec_command／Claude Bash 实际启动当前源码编译的 willyou-app，经现有 Unix 网关、真实内核 peer 与祖先出生身份检查到达浏览器业务。两端原生工具输出进入下一模型请求，同 task 换 Provider 后新 run 重新申请授权；有效 token 在错误进程树仍被拒，旧 run 结束后的 token 也经真实 CLI 被拒。该结果不包含真实 Electron 页面／登录态。

程序化 Driver 要在受管原生启动环境中提供该 run 的业务 CLI 入口与临时凭据，保留网关对固定二进制、有效 run、真实祖先、能力计划和业务 context 的复核；不用宿主代为执行 shell 或放宽 additionalRoot 来伪造链路通过。此通道与私有应用 MCP 分别按能力声明选择。授权回应仍由受信宿主入口处理，模型／父 Agent 不能自行准许。

**拒绝审计表要同时支持 CLI 与 MCP。** 当前 0028 Schema 的方法枚举与 run／bridge 成对约束仅覆盖 MCP，现有 CLI 网关的 cli-* 拒绝会遇到 CHECK 失败。复制库实验已证明：扩充四个 CLI 方法并约束 CLI bridge_id 为空、保留 MCP 原有身份组合后，未改网关即可写出拒绝收据，旧行及事务失败回滚保留。正式迁移采用版本门槛／事务重建，不能为 CLI 伪造 MCP bridge_id 或削弱 MCP 约束。

当前 CLI 输出会省略网关顶层 auditId／auditUnavailable；统一 UI 需由宿主诊断服务发布拒绝和审计不可用状态，不能假设现有 CLI 输出已包含这些字段。未能认证 run 的拒绝只能进入宿主级诊断，不能按请求参数猜测任务归属；认证成功后才允许关联原 run。若需由 CLI 返回传递则另做明确的版本合同及验证。本批只验证候选数据库约束，未实施正式迁移或返回字段扩展；权限拒绝正确与审计记录完整分别验收。

'''
def tech(t):
 assert '### 9.7.1 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 t=t.replace('没有实际原生 shell／CLI socket、网页或登录态，不能声称完整浏览器迁移通过。','本批没有实际原生 shell／CLI socket、网页或登录态；原生传输的后续证据见 §9.7.1，仍不能声称完整浏览器迁移通过。')
 return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.69 原生浏览器 CLI、进程归属与拒绝审计

[原生 CLI 实验](实验/20261114_原生浏览器CLI与拒绝审计验证/README.md)N01–05 通过：两端真实 shell 启动当前受管 CLI，经内核 peer／祖先到浏览器业务；未授权拒绝、批准后结果均回到模型，同父 task 切换新 Claude 后重新授权。错误进程树持有有效 token 仍拒绝；旧 token 在真实 CLI 上拒绝；全部原生与记录的 CLI peer 退出。最终 15 次本机模型请求、25 份 peer 证明、12 条业务调用；首批正常通过后补断言复验，原始两批保留。

发现现有 CLI 拒绝审计未落库：0028 CHECK 不接受 cli-*，有 run 时又要求 MCP bridge。复制 SQLite＋未改 Gateway.denial 复现；候选兼容 Schema 的 8 个已知／未知 run 拒绝收据写入，旧行、事务回滚及无效身份组合守卫通过。真实鉴权拒绝正确，不等于审计完备；技术方案 §9.7.1 加入迁移与 UI 诊断合同。CLI 顶层审计字段输出尚待验证。

不含原生页面／登录、真实 renderer 审批、网页写或跨平台；Electron 分配禁止，模型仅本机受控响应，业务包为当前定义重绑研究 runtime。产品与正式 Schema 未改，Q37 继续部分。

'''
def ledger(t):
 assert '### 4.69 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正')
 t=t.replace('原生 CLI socket／真实页面与登录态联调待验','§4.69 补两端真实 shell／受管 CLI／内核网关及换 Provider 后重新授权；真实页面与登录态、真实 UI 审批仍待验')
 t=t.replace('继续补原生 CLI 传输、真实页面、邮件上下文、在途写与宿主崩溃','§4.69 又补两端原生 CLI 传输与拒绝审计 Schema 候选；继续补真实页面／登录、邮件上下文、在途写与宿主崩溃，审计诊断回传合同仍待验证')
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：两端原生 shell→受管 CLI→内核身份网关→浏览器业务链已补证，5 项检查通过。另发现现有拒绝审计表仅兼容 MCP，已复现并验证候选 Schema 兼容迁移，见[技术方案 §9.7.1](技研/技术方案.md)。真实网页／登录与 UI 审批未验，产品未改。'
 i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：补真实浏览器页面／登录保留和拒绝诊断合同，继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的其他业务在途／宿主恢复；不重复已通过的 CLI 正常链，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources),'nativeChecks':5,'candidateDenialReceipts':8}))
