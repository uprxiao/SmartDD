---
name: test-query
description: Isolated fixture
---
Use the owned test tool.
