"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// <stdin>
var stdin_exports = {};
__export(stdin_exports, {
  claudeSessionFile: () => claudeSessionFile,
  codexRolloutFile: () => codexRolloutFile,
  recentCodexRollouts: () => recentCodexRollouts
});
module.exports = __toCommonJS(stdin_exports);

// src/main/core/tasks/native-sessions.ts
var import_node_fs = require("node:fs");
var import_promises = require("node:fs/promises");
var import_node_path = require("node:path");
var import_better_sqlite3 = __toESM(require("better-sqlite3"));

// src/shared/codex-session.ts
function parseCodexSessionMeta(firstLine) {
  try {
    const d = JSON.parse(firstLine);
    if (d?.type !== "session_meta" || !d.payload?.id || !d.payload?.cwd) return null;
    const ts = Date.parse(d.payload.timestamp);
    return {
      id: String(d.payload.id),
      cwd: String(d.payload.cwd),
      timestampMs: Number.isNaN(ts) ? 0 : ts,
      originator: String(d.payload.originator ?? "")
    };
  } catch {
    return null;
  }
}

// src/main/core/tasks/native-sessions.ts
var encodeClaudeDir = (cwd) => cwd.replace(/[^a-zA-Z0-9]/g, "-");
function claudeSessionFile(root, cwd, sessionId, scan = true) {
  const projects = (0, import_node_path.join)(root, "projects");
  const candidates = /* @__PURE__ */ new Set([cwd]);
  try {
    candidates.add((0, import_node_fs.realpathSync)(cwd));
  } catch {
  }
  for (const c of candidates) {
    const f = (0, import_node_path.join)(projects, encodeClaudeDir(c), `${sessionId}.jsonl`);
    if ((0, import_node_fs.existsSync)(f)) return f;
  }
  if (!scan || !(0, import_node_fs.existsSync)(projects)) return null;
  for (const d of (0, import_node_fs.readdirSync)(projects)) {
    const f = (0, import_node_path.join)(projects, d, `${sessionId}.jsonl`);
    if ((0, import_node_fs.existsSync)(f)) return f;
  }
  return null;
}
function codexRolloutFile(root, sessionId, sinceMs, scan) {
  const sessions = (0, import_node_path.join)(root, "sessions");
  const suffix = `-${sessionId}.jsonl`;
  const inDir = (dir) => {
    if (!(0, import_node_fs.existsSync)(dir)) return null;
    const name = (0, import_node_fs.readdirSync)(dir).find((n) => n.startsWith("rollout-") && n.endsWith(suffix));
    return name ? (0, import_node_path.join)(dir, name) : null;
  };
  for (const dir of codexDayDirs(sessions, sinceMs)) {
    const f = inDir(dir);
    if (f) return f;
  }
  if (!scan || !(0, import_node_fs.existsSync)(sessions)) return null;
  const sub = (dir) => (0, import_node_fs.readdirSync)(dir).filter((n) => /^\d+$/.test(n)).sort().reverse();
  for (const y of sub(sessions)) {
    for (const m of sub((0, import_node_path.join)(sessions, y))) {
      for (const d of sub((0, import_node_path.join)(sessions, y, m))) {
        const f = inDir((0, import_node_path.join)(sessions, y, m, d));
        if (f) return f;
      }
    }
  }
  return null;
}
async function recentCodexRollouts(root, sinceMs) {
  const byId = /* @__PURE__ */ new Map();
  for (const m of await rolloutMetas(root, sinceMs)) byId.set(m.id, m);
  for (const m of codexThreads(root, sinceMs) ?? []) byId.set(m.id, m);
  const latest = Date.now() + 6e4;
  return [...byId.values()].filter((m) => m.timestampMs <= latest);
}
function codexStateDb(root) {
  if (!(0, import_node_fs.existsSync)(root)) return null;
  const n = (f) => Number(/^state_(\d+)\.sqlite$/.exec(f)?.[1] ?? -1);
  const best = (0, import_node_fs.readdirSync)(root).filter((f) => n(f) >= 0).sort((a, b) => n(b) - n(a))[0];
  return best ? (0, import_node_path.join)(root, best) : null;
}
function codexThreads(root, sinceMs) {
  const file = codexStateDb(root);
  if (!file) return null;
  let db = null;
  try {
    db = new import_better_sqlite3.default(file, { readonly: true, fileMustExist: true });
    db.pragma("query_only = ON");
    const rows = db.prepare(
      `SELECT id, cwd, COALESCE(created_at_ms, created_at * 1000) AS ms, first_user_message AS msg, COALESCE(originator, source) AS origin
         FROM threads WHERE archived = 0 AND first_user_message <> '' AND COALESCE(created_at_ms, created_at * 1000) >= ?`
    ).all(sinceMs - 2e3);
    return rows.map((r) => ({ id: r.id, cwd: r.cwd, timestampMs: r.ms, originator: r.origin ?? "", firstUserMessage: r.msg }));
  } catch {
    return null;
  } finally {
    db?.close();
  }
}
async function rolloutMetas(root, sinceMs) {
  const out = [];
  for (const dayDir of codexDayDirs((0, import_node_path.join)(root, "sessions"), sinceMs)) {
    if (!(0, import_node_fs.existsSync)(dayDir)) continue;
    for (const name of (0, import_node_fs.readdirSync)(dayDir)) {
      if (!name.startsWith("rollout-") || !name.endsWith(".jsonl")) continue;
      const file = (0, import_node_path.join)(dayDir, name);
      if ((0, import_node_fs.statSync)(file).mtimeMs < sinceMs - 2e3) continue;
      const meta = parseCodexSessionMeta(await readFirstLine(file));
      if (meta) out.push(meta);
    }
  }
  return out;
}
function codexDayDirs(sessionsRoot, sinceMs) {
  const days = /* @__PURE__ */ new Set();
  for (const t of [sinceMs, Date.now()]) {
    const d = new Date(t);
    const p = (n) => String(n).padStart(2, "0");
    days.add((0, import_node_path.join)(sessionsRoot, String(d.getFullYear()), p(d.getMonth() + 1), p(d.getDate())));
  }
  return [...days];
}
async function readFirstLine(file) {
  const fh = await (0, import_promises.open)(file, "r");
  try {
    const buf = Buffer.alloc(64 * 1024);
    const { bytesRead } = await fh.read(buf, 0, buf.length, 0);
    const text = buf.subarray(0, bytesRead).toString("utf8");
    const nl = text.indexOf("\n");
    return nl === -1 ? text : text.slice(0, nl);
  } finally {
    await fh.close();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  claudeSessionFile,
  codexRolloutFile,
  recentCodexRollouts
});
