# 失败与范围记录

首批 attempt-UopqC9：Claude SDK→CLI→SDK 三轮通过。Codex 首次 app-server 成功，随后 exec resume 未显式传 model，实际请求使用 gpt-6.1-sol，并无 tools；模型测试端因无预期工具返回500，CLI exit1。stderr 的临时目录 PATH alias 警告不是退出原因。历史仍包含之前记录，没有证明模型自动沿用。只在 CLI 参数补 --model gpt-5.3-codex 后，单独重跑 Codex（attempt-RvCagg）三轮通过，已通过的 Claude 没有重复执行。

缺失历史实验首次导入整个 runner-adapters bundle，触发未使用的 node-pty 原生模块加载失败，在操作历史文件前退出。改为只加载当前 native-sessions 只读模块，没有替换历史定位逻辑或提供 PTY stub。原构建和输入摘要保留 reader-initial。后续两端 CLI 缺历史均 exit1、零模型请求，原实验 transcript 恢复并核对哈希。

所有模型响应只来自本机；十个 native（八个往返相关，两个缺失反例）均已终态。不是应用／PTY 迁移、业务权限或并发排他验证。
