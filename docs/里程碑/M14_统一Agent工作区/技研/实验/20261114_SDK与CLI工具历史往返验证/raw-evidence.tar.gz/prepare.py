from pathlib import Path
import json,hashlib,sqlite3,tarfile,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_SDK与CLI工具历史往返验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
first=root/'attempt-UopqC9';second=root/'attempt-RvCagg';a=json.loads((first/'result.json').read_text());b=json.loads((second/'result.json').read_text());assert a['checks'][0]['status']=='passed'and a['checks'][1]['status']=='failed';assert b['passed']==1 and not b.get('error');missing=json.loads((root/'missing-history/result.json').read_text());assert missing['passed']==2 and not missing.get('error')and not missing['requests']
checks=[a['checks'][0],b['checks'][0]]+[{'id':'H0'+str(i+3),'title':x['driver']+' actual locator and CLI missing-history rejection','status':'passed','evidence':x}for i,x in enumerate(missing['results'])]
attempts=[]
for p in [first,second]:
 process=json.loads((p/'processes.json').read_text());assert all(x['exit']and x['exit']['signal']is None for x in process);assert all(x['exit']['code']==(1 if p==first and x['label']=='codex-2-cli'else 0)for x in process)
 req=[json.loads(l)for l in (p/'model-requests.jsonl').read_text().splitlines()];attempts.append({'attempt':p.name,'modelRequests':len(req),'processes':[{'label':x['label'],'pid':x['pid'],'exit':x['exit']}for x in process]})
 for native in p.glob('codex-home/.codex/state_5.sqlite'):
  target=p/'codex-state-index.sqlite';db=sqlite3.connect(native.as_uri()+'?mode=ro',uri=True);dest=sqlite3.connect(target);db.backup(dest);dest.close();db.close()
for driver,p in [('claude',first),('codex',second)]:
 req=[json.loads(l)for l in (p/'model-requests.jsonl').read_text().splitlines()if json.loads(l)['phase'].startswith(driver+'-')];assert len(req)==6
 for x in req:
  index=int(x['phase'].rsplit('-',1)[1]);body=x['body'];serialized=json.dumps(body.get('messages',body.get('input')))
  for i in range(1,index):
   for prefix in ['USER_','FILE_','ANSWER_']:assert prefix+driver+'_'+str(i)in serialized
  if index==3 and x['count']==1:
   toolouts=[z for message in body['messages']if isinstance(message.get('content'),list)for z in message['content']if z.get('type')=='tool_result']if driver=='claude'else[z for z in body['input']if z.get('type')=='function_call_output'];assert len(toolouts)>=2
   for i in [1,2]:assert 'FILE_'+driver+'_'+str(i)in json.dumps(toolouts)
 for stageName in (['sdk1','cli2','sdk3']if driver=='claude'else['server1','cli2','server3']):assert (p/(driver+'-'+stageName+'-history.jsonl')).stat().st_size>0
for x in missing['results']:
 process=json.loads((root/('missing-history/'+x['driver']+'-process.json')).read_text());assert process['code']==1 and process['signal']is None
 sessions=json.loads(((first if x['driver']=='claude'else second)/'sessions.json').read_text());state=sessions[x['driver']];files=list(Path(state['state']).rglob('*'+state['id']+'*.jsonl'));assert len(files)==1 and sha(files[0].read_bytes())==x['originalRestoredSha256']
reader=json.loads((root/'reader-build.json').read_text())
for s in reader['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256']
assert sha(Path(reader['output']['file']).read_bytes())==reader['output']['sha256']
origReq=[json.loads(x)for x in (first/'model-requests.jsonl').read_text().splitlines()];default=next(x for x in origReq if x['phase']=='codex-2')['body'];assert default['model']=='gpt-6.1-sol'and not default.get('tools')
result={'checks':checks,'passed':4,'selectedEvidence':{'claude':first.name,'codex':second.name,'missing':'missing-history/result.json'},'totalLocalModelRequests':sum(x['modelRequests']for x in attempts),'paidModelCalls':0,'originalFailedCodexAttemptPreserved':True,'scope':'Fixed-version native history compatibility, three turns with real file-read tools each; CLI missing-history refusal and existing SmartDD native locator. Not interactive PTY, TaskService migration, concurrent writer guard, product UI, cross-version downgrade or external provider authentication.'};(root/'combined-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
runtime={'attempts':attempts,'missing':missing,'defaultModelCounterexample':{'originalModel':'gpt-5.3-codex','cliDefaultObserved':default['model'],'toolsDeclared':bool(default.get('tools')),'failedModelRequest':True},'allNativeProcessesTerminal':True,'roundtripNativeProcesses':8,'missingHistoryProcesses':2,'typedToolResultHistoryVerified':True,'reader':reader};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/tasks'/n for n in ['task-service.ts','runner-adapters.ts','native-sessions.ts']]+[repo/'src/shared/runner-args.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts']
nativeBase=Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules');binaries=[nativeBase/'@anthropic-ai/claude-agent-sdk-darwin-arm64/claude',nativeBase/'@openai/codex-darwin-arm64/vendor/aarch64-apple-darwin/bin/codex'];sdk=nativeBase/'@anthropic-ai/claude-agent-sdk/sdk.mjs'
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'runtimes':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in [*binaries,sdk]],'versions':{'claudeSdk':'0.3.321','claudeNative':'2.1.321','codex':'0.167.1','platform':'darwin-arm64'},'localReaderSourceInputs':len(reader['sources']),'t3Reference':'Claude uses resume nativeThreadId or sessionId depending lifecycle, compiles selection settings separately. Codex thread/resume receives explicit params and handles archived/unloading states. T3 does not prove interactive CLI rollback compatibility for WillYou.','limits':['Direct child processes, no WillYou owner/lease handoff in this batch.','CLI uses noninteractive --print/exec, not actual terminal PTY.','Controlled file-read tools; unknown business writes and pending requests are not replay-tested.','Same native binary and state root across modes; no historical or future version compatibility claim.']};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
(root/'failure-notes.md').write_text('''# 失败与范围记录

首批 attempt-UopqC9：Claude SDK→CLI→SDK 三轮通过。Codex 首次 app-server 成功，随后 exec resume 未显式传 model，实际请求使用 gpt-6.1-sol，并无 tools；模型测试端因无预期工具返回500，CLI exit1。stderr 的临时目录 PATH alias 警告不是退出原因。历史仍包含之前记录，没有证明模型自动沿用。只在 CLI 参数补 --model gpt-5.3-codex 后，单独重跑 Codex（attempt-RvCagg）三轮通过，已通过的 Claude 没有重复执行。

缺失历史实验首次导入整个 runner-adapters bundle，触发未使用的 node-pty 原生模块加载失败，在操作历史文件前退出。改为只加载当前 native-sessions 只读模块，没有替换历史定位逻辑或提供 PTY stub。原构建和输入摘要保留 reader-initial。后续两端 CLI 缺历史均 exit1、零模型请求，原实验 transcript 恢复并核对哈希。

所有模型响应只来自本机；十个 native（八个往返相关，两个缺失反例）均已终态。不是应用／PTY 迁移、业务权限或并发排他验证。
''')
files=[]
for p in root.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(root)
 if any(x in ['node_modules','publication','help-home','claude-home','codex-home','claude-workspace','codex-workspace','__pycache__']for x in rel.parts):continue
 if p.name in ['manifest.json','audit.json','publication-audit.json']:continue
 if p.suffix in ['.mjs','.cjs','.json','.jsonl','.log','.txt','.sqlite','.py','.md']:files.append(p)
dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# SDK／app-server 与 CLI 工具历史往返

2026-11-14；T0.1 §11.1，验证账 §4.73；R02／03／10／11，Q49。仅隔离研究，产品／共享原型未改。

## 已验证的四项

| 检查 | 结果与证据边界 |
| --- | --- |
| H01 Claude | SDK 0.3.321／native 2.1.321：SDK→同二进制 CLI --print --resume→SDK，三轮沿用同 sessionId、cwd、CLAUDE_CONFIG_DIR |
| H02 Codex | native 0.167.1：app-server→同二进制 exec resume→新 app-server，三轮沿用同 threadId、cwd、CODEX_HOME |
| H03 Claude 缺历史 | 当前 SmartDD claudeSessionFile 能找到 SDK／CLI 共写的 transcript；暂移后返回 null，CLI 明确失败且零模型请求，没有新建原路径；恢复后哈希一致 |
| H04 Codex 缺历史 | 当前 codexRolloutFile／recentCodexRollouts 可定位真实 rollout／索引；暂移后找不到，CLI 明确失败且零模型请求；原文件恢复且哈希一致 |

两端每轮实际执行一次合成文件读取，再生成文本回答。模型端受控响应只发命令，不把文件内容塞进提示；工具真实输出 FILE_* 进入下一模型请求。第三轮的结构化 tool_result／function_call_output 同时含前两轮结果，同时核对用户输入和回答标记。不是让模型口头声明“记得”，也不是只看文件存在。每轮结束并观察进程终态后才启动下一种入口，没有并行写同一历史。

Claude 通过证据在 attempt-UopqC9，Codex 通过在 attempt-RvCagg；原首批 Codex 失败保留。有效往返合计12次本机模型请求，连同首次 Codex 尝试共15次；两次缺历史反例零请求。八个往返相关 native 及两个缺失反例 native 均退出，未调用付费／远程模型。

## 发现的配置边界

首批 Codex exec resume 没有显式传 model，实际从 gpt-5.3-codex 变为当前默认 gpt-6.1-sol；该请求未声明 tools，受控模型端按预期拒绝。stderr 的临时目录 PATH alias 警告不是失败主因。显式传同一模型后工具往返通过。**恢复原 thread 并不证明有效配置原样继承**；入口切换仍要重新解析并固定 model、provider/base URL、凭据来源和权限参数，按已有执行计划约束执行。

已有 TaskService.recoveryOf 区分从未落盘的 fresh 与已观察历史后来缺失的 unrecoverable。迁移保留 nativeHistoryObserved 和身份来源，不能把缺失 transcript 当新空会话。实际当前定位函数可识别本批历史，但没有把新任务映射或入口切换接入 TaskService。

## T3 参考和实现要求

T3 Claude Adapter 按生命周期选择 resume 或 sessionId，并单独编译选择配置；Codex Adapter 将明确参数传给 thread/resume，另处理归档／卸载状态。WillYou 参考其身份与选择分离，不能从 T3 的原生恢复推出任意旧 CLI 版本都可回退。

SDK／CLI 切换前仍要求旧 run、后台工具、业务活动和未决写入已收束，原生身份排他占用交接成功。CLI 能读历史不等于业务权限、审批、来源证明和规范事件自动迁移。未知工具／记录保留为原始历史，未知写不重发。不同 native／SDK 版本、交互式 PTY、正式配置继承、旧任务入口和应用数据版本回退仍分别验证。

## 复跑与限制

固定 native／SDK 版本和哈希见 source-review。node probe.mjs 跑两端，node probe.mjs codex 只跑 Codex。本轮只补 Codex 默认模型参数后复验，没有为凑同批结果重跑 Claude。build-reader.mjs 在 SmartDD cwd 编译原只读定位模块；missing-history.mjs 针对已记录的实验会话暂移并恢复，复跑需替换其中的实验路径，禁止用于日常会话。

仅非交互 CLI --print／exec，未验证真实 PTY、TaskService 切换、并发写者拒绝、原生子任务／后台工具全格式、未知业务写或跨版本降级。Q49 从待验推进为部分，不能声称产品回退已可用。

[结果](result.json) · [运行审计](runtime-audit.json) · [源码／版本](source-review.json) · [摘要](archive-manifest.json) · [原生协议／历史／脚本](raw-evidence.tar.gz)。{len(files)} 文件，{len(dbs)} 份原生索引 SQLite 完整性／外键通过；当前只读模块 {len(reader['sources'])} 构建输入核对。
''')
section='''### 11.1 原生格式往返与入口回退门槛

[SDK／CLI 工具历史实验](实验/20261114_SDK与CLI工具历史往返验证/README.md)取得固定版本局部证据：Claude SDK 0.3.321／native 2.1.321 的 SDK→CLI --print→SDK，以及 Codex 0.167.1 的 app-server→exec CLI→app-server，均能在相同原生 ID、状态根和 cwd 下继续含工具记录的会话。后续真实模型请求包含旧用户输入、回答和结构化工具结果；当前 SmartDD 原生定位函数也可识别这些历史。仅非交互 CLI，未证明旧 PTY／TaskService 已接通或跨版本兼容。

**恢复身份和恢复配置分开校验。** Codex exec resume 未显式传模型时，本次实验实际使用了新的默认模型，而不是历史模型；显式固定后才完成工具链。模式切换应由统一执行配置解析器提供 model、provider／端点、凭据来源、权限与资源版本，不能仅传 resume ID 后依赖 CLI 默认值。T3 的 Adapter 同样将 nativeThreadId 与选择参数分别处理；其恢复机制不是 WillYou 的任意版本回退保证。

相同格式可读只是回退前提之一。交接必须先证明旧 owner、后台／子进程、业务活动和未决操作收束，再移交同一原生身份的排他占用；期间未知写不自动重放。维持业务上下文、审批归属、来源证明和规范历史的独立映射，不因为原生 transcript 可读就授予旧权限。完整入口切换、未知写和真实 PTY 继续验证。

两端 CLI 在原历史文件缺失时均明确失败且零模型请求，实验恢复了原文件并核对摘要。迁移保留“曾观察到历史”的状态；已写历史后来丢失不可降为 fresh、新建空会话或换一个 ID 静默继续。应用／数据库版本回退、全部原生工具格式和版本矩阵仍与本节格式兼容结果分开收口。

'''
def tech(t):
 assert '### 11.1 'not in t;t=t.replace('## 12. 运行资源、配置与版本',section+'## 12. 运行资源、配置与版本');t=t.replace('Q49–50 未验证前不宣称完整降级可用。','Q49 仅取得下节固定版本原生格式往返证据；完整入口回退及 Q50 数据版本回退未验证前，不宣称完整降级可用。');return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.73 固定版本 SDK／CLI 工具历史往返

[往返实验](实验/20261114_SDK与CLI工具历史往返验证/README.md)补 Q49：Claude SDK→CLI --print→SDK、Codex app-server→exec CLI→app-server 均沿用原生 ID，并在真实请求中携带前轮结构化工具结果。当前 SmartDD 只读定位函数可识别本批 transcript／rollout；两端 CLI 在暂移历史后均明确失败、零模型请求，原实验文件恢复且哈希一致。

Codex 首次 CLI 未显式传模型时改用当前默认模型、没有预期工具声明，受控模型端拒绝；补明确模型参数后只重跑 Codex 通过。Claude 已通过的首批结果保留，没有假装首次整批成功。共有15次本机模型请求，十个 native 终态；未调用付费模型。原读取模块构建误带 node-pty 的启动失败也保留，之后只加载实际原生定位模块。

T0.1 §11.1 明确原生身份与配置分别固定、历史曾存在的状态保留及回退排他门槛。仅固定版本／非交互入口；真实 PTY、TaskService、新旧 owner 交接、未知业务写和跨版本／数据回退仍待验，Q49 保持部分。

'''
def ledger(t):
 assert '### 4.73 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');old='| Q49 | SDK↔CLI 切回、旧任务只读与未知提交不自动重发 | E03／11；G05、T27 | 待验；共用原生文件不自动等于双向恢复兼容；需带工具历史与占用排他正负例 |';new='| Q49 | SDK↔CLI 切回、旧任务只读与未知提交不自动重发 | E03／11；G05、T27 | **部分**：§4.73 补两端固定版本 SDK／app-server→非交互 CLI→原入口的真实工具历史往返、现有只读定位器和缺失历史 CLI 拒绝；发现 Codex CLI 恢复仍须显式固定模型。真实 PTY／TaskService、原生身份排他交接、未知业务写、旧任务只读与跨版本回退仍待验 |';assert old in t;t=t.replace(old,new);t=t.replace('最终 Schema 下的新旧读者、资源种类、启动排他及旧格式拒绝／回退边界。','最终 Schema 下的新旧读者、资源种类、启动排他及旧格式拒绝／回退边界。§4.73 已补固定版本原生工具历史在程序化／非交互 CLI 间往返与缺失拒绝，未替代上述产品入口与排他交接。');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('最新进展：'):lines[i]='最新进展：两端 SDK／app-server 与非交互 CLI 的真实工具历史往返已通过，现有历史定位器及缺失历史拒绝也取得证据。发现 Codex CLI 恢复仍须显式固定模型，见[技术方案 §11.1](技研/技术方案.md)。Q49 推进为部分，真实 PTY／产品回退未实现。'
  if l.startswith('下一步：'):lines[i]='下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)的新旧入口排他交接、业务在途／宿主恢复和历史迁移合同；不重复已通过的固定版本格式往返，不修改产品或原型。'
 return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'readerSources':len(reader['sources'])}))
