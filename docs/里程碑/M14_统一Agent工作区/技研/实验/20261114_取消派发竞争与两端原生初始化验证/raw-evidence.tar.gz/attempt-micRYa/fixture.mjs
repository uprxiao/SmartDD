import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import candidate from './candidate.cjs';
import {migrate,currentScope} from './migration.mjs';
export const helper='/private/tmp/willyou-m14-owner-probe/process-identity';
export const reader=()=>new actual.MacProcessIdentityReader(helper);
export const engine=store=>new candidate.ResourceGraphMaintenance(store,reader(),input=>actual.restoreOwnedDirectory(helper,input));
export async function setup(driver='claude'){
 const processes=reader(),f=await (driver==='codex'?actual.runCodexFixture:actual.runFixture)(processes,{application:true}),db=f.sqlite,profile=randomUUID();
 db.prepare('INSERT INTO ai_profiles(id,name,runner,created_at,updated_at) VALUES(?,?,?,?,?)').run(profile,'isolated profile',f.snapshot.runner,1,1);
 db.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run(f.snapshot.taskId,'p1',f.snapshot.native.cwd,profile,f.snapshot.runner,'isolated owner',1,1);
 await migrate(db);const scope=currentScope(db,f.snapshot.taskId);db.prepare('UPDATE m14_binding SET profile_id=?,profile_revision=1 WHERE binding_id=?').run(profile,scope.bindingId);
 db.exec(readFileSync(new URL('./delivery.sql',import.meta.url),'utf8'));
 const install=async(version)=>{const runtime=await new actual.RuntimeRegistry(f.store).install({id:'applications',protocolMajor:1,bridgeEntry:'mcp-bridge.cjs',files:{'mcp-bridge.cjs':Buffer.from('module.exports='+JSON.stringify({version})+';')}}),source={manifest:structuredClone(f.applicationSource.manifest),files:{...f.applicationSource.files}};source.manifest.version=version;source.manifest.runtime.hash=runtime.contentHash;const pack=await f.packageRegistry.install(source);await f.packageRegistry.activate(pack.packageHash,f.packageRegistry.active(pack.appId).generation);return{pack,runtime};};
 const delivery=await install('2.0.0'),next=await install('3.0.0'),run=await f.create();
 db.prepare('UPDATE capability_runs SET binding_id=?,capability_session_id=?,generation=1 WHERE run_id=?').run(scope.bindingId,scope.capabilitySessionId,run.runId);
 await run.prepare();const gc=engine(f.store);assert((await gc.plan(delivery.pack.resourceId)).canCollect);
 return{...f,scope,profile,delivery,next,run,engine:gc};
}
