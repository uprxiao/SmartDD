from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_历史复制跨进程提交恢复验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==5 and r['error'] is None
assert len(r['workers'])==14 and all(w['exit'] for w in r['workers'])
assert sum(w['exit']['signal']=='SIGKILL' for w in r['workers'])==5
build=json.loads((root/'build.json').read_text())
for e in build['sources']+build['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
helper=Path('/private/tmp/willyou-m14-owner-probe/process-identity')
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':build,'helper':{'path':str(helper),'sha256':sha(helper.read_bytes())},'node':subprocess.check_output(['node','-p','JSON.stringify({version:process.version,platform:process.platform,arch:process.arch})'],text=True).strip(),'boundary':r['scope'],'faultInjection':'Only captured child processes terminated after synchronous checkpoint. in-commit blocks inside actual adoptLibrary commit callback before SQLite transaction return. after-commit is after adoptLibrary returns, including mirrors. No power failure or partial-copy injection.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['worker.mjs','probe.mjs','build.mjs','build.json','actual.cjs','prepare.py','source-review.json','runtime-audit.json']]+[p for p in Path(r['out']).iterdir() if p.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 历史复制跨进程提交恢复验证

日期：2026-11-14。关联 Q13／Q49、D01。使用当前实际 copyClaudeSession、CapabilitySessionRegistry、ResourceStore、SQLite 与 macOS 进程身份助手；复制账和 Task 指针为临时候选，源／目标均为合成历史。

## 故障与结果

| 检查 | 注入及恢复观察 |
| --- | --- |
| C01 复制完成、元数据未提交 | 原宿主尚活时，另一恢复进程拒绝接管；精确 SIGKILL 后，新进程核验 copied 账、原快照、指针、目录身份及内容，重新复制取得新的进程内收据，再执行实际 adoptLibrary |
| C02 元数据事务内部 | 在实际 adoptLibrary 的同步 commit 回调中完成指针和复制账更新、事务尚未返回时 SIGKILL；新进程读到旧快照／旧指针及 copied 账，重新核验并复制、成功提交 |
| C03 提交完成后 | adoptLibrary 返回后 SIGKILL；新进程读到 committed 账与一致的新快照／新指针，不再复制、不重放提交 |
| C04 提交前副本变化 | 原宿主退出后改动合成目标文件；恢复拒绝，外部改动与 copied 状态保留，旧指针未前移 |
| C05 提交后副本变化 | 原宿主退出后改动合成目标文件；恢复拒绝，保留外部改动及已经提交的新指针，不自动回滚旧入口 |

五项通过。C01–C03 各增加一次新进程重复恢复，均识别 committed，不重放。14 个 worker 全部终止：5 次预定 SIGKILL、6 次成功 exit 0、3 次预期拒绝 exit 1。五份终态 SQLite 的完整性／外键检查通过，原 owner 均已证明停止。

恢复没有把 JSON 重新包装成可信 ClaudeRestoreReceipt。提交前恢复先验证实际旧会话与保留记录，再调用真实复制函数取得当前进程的新收据；副本或源身份／内容不匹配则保留现场。真实注册器处理元数据事务，宿主初始选择政策仅为固定空应用夹具；这不证明产品授权服务已完整接线。

## 设计影响与未覆盖

复制完成、原子提交完成与运行准入是三个事实。复制账和 Task／binding 指针必须进入同一元数据事务，恢复按数据库状态及实际文件身份分支，不能凭副本存在或旧进程内收据继续。提交后损坏不自动降级为“复制未完成”并重放旧输入。

本轮只覆盖复制已经完成后的三个提交窗口。未覆盖文件复制中途、两个恢复者同时接管、最终多 binding／身份占用投影、真实 TaskService、Agent 已经续写历史后的恢复、提交后镜像尚未完成的窗口、系统断电或目标文件系统的耐久性。after-commit 已包含实际 adoptLibrary 的镜像处理，不标成“事务提交但镜像尚未写”。

本批没有启动后续 Agent，文件变化为明确注入。不能将原复制摘要永久作为所有后续启动的硬门槛：合法续聊会写入新历史，后续须依据已提交 binding、运行与历史修订对账。此处拒绝只说明没有合法后续写入证据时保留现场，不证明所有历史追加都应拒绝。

## 复现

固定依赖与本机进程助手可用时执行 `node build.mjs`、`node probe.mjs`。驱动只终止自己启动并已核对出生身份的 ChildProcess；超时也只处理该句柄。所有源码、构建输入、各进程日志和终态 SQLite 均归档。当前 379 条构建输入及产物已再次核对。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
tech_rel=base/'技研/技术方案.md';t=(repo/tech_rel).read_text();anchor='T3 ProviderSessionManager.releaseEntry 将订阅排空、scope 关闭、工具事件补记及释放记录分层处理；'
add='''[跨进程复制恢复实验](实验/20261114_历史复制跨进程提交恢复验证/README.md)进一步验证实际注册器配合候选复制账的三个窗口：复制完成未提交、事务回调内真实 SIGKILL 后均读到旧指针／旧快照并重新核验，重新复制取得新进程收据后才能提交；adoptLibrary 已返回后的退出恢复读取 committed，不重复复制或提交。复制账与 Task／binding 指针及身份占用更新应进入同一元数据事务，不能先将外部日志标成功再提交。原 owner 活着时不接管，未知活性继续保留；恢复进程还需正式的排他 claim，不能只靠“原 owner 已死”允许多个恢复者同时处理。

复制前／提交后文件变化分别保留旧／新已提交指针并拒绝自动继续；已提交记录不能因副本异常就重放旧交接。此实验没有后续 Agent 续写，原复制摘要只适用于该交接窗口，不永久冻结会话历史；合法续写后的恢复须核对当前 binding、运行和历史修订。复制中途、并发恢复、最终多 binding／占用投影、实际 TaskService、提交后镜像窗口及合法续写后的恢复仍待验证。进程 SIGKILL 不代表断电耐久性已经通过。

'''
assert anchor in t;t=t.replace(anchor,add+anchor,1);put(tech_rel,t)
ledger_rel=base/'技研/全局设计验证账.md';t=(repo/ledger_rel).read_text();assert '### 4.90 ' not in t
add='''### 4.90 历史复制跨进程提交与恢复

[五项隔离实验](实验/20261114_历史复制跨进程提交恢复验证/README.md)验证真实复制／注册器配合候选账：复制完成、事务内部和 adoptLibrary 返回后三个位置终止原宿主，新进程分别核验旧态并取得新复制收据，或识别已提交而不重放；原 owner 存活时拒绝。提交前／后副本变化均保留改动及各自已提交指针，不自动覆盖或回退。

14 个 worker 均终止，5 次预定 SIGKILL、6 次成功、3 次预期拒绝；三条正常恢复各重复一次均不重放，五份 SQLite 完整性及外键通过。没有原生 Agent 或实际 TaskService。复制中途、并发恢复者、最终多 binding／占用投影、提交后镜像窗口、合法历史续写和断电耐久性未覆盖，不能将原复制摘要永久冻结为启动条件。技术方案 §11.2 已收口；Q13／Q49 仍为部分。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1).replace('截至 §4.89，56 个宽口径问题项中','截至 §4.90，56 个宽口径问题项中')
old='下一步是最终占用投影／多 binding 原子提交、复制后宿主退出对账及旧根回退／释放，不能把进程内收据持久化后继续授权。'
new='§4.90 已补实际注册器配合候选复制账的三个 SIGKILL／新进程恢复窗口及副本变化拒绝；下一步是最终占用投影／多 binding 原子提交、复制中途／并发恢复、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
assert old in t;t=t.replace(old,new,1);put(ledger_rel,t)
index_rel=base/'README.md';t=(repo/index_rel).read_text()
t=re.sub(r'^最新进展：.*$', '最新进展：历史复制完成后的提交前／事务内／提交后三个宿主退出窗口已补跨进程恢复证据，副本异常保留现场。见[历史复制恢复实验](技研/实验/20261114_历史复制跨进程提交恢复验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)核对身份占用投影与多 binding 原子提交、复制／恢复并发及合法历史续写的兼容；宿主委派问题账、完整运行／业务和资源清理仍按具体分支推进。',t,flags=re.M);put(index_rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-history-copy-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed']}))
