import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {mkdtempSync,writeFileSync,readFileSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import actual from './actual.cjs';
const root=import.meta.dirname,out=mkdtempSync(join(root,'attempt-')),save=(n,v)=>writeFileSync(join(out,n),JSON.stringify(v,null,2));
for(const n of ['probe.mjs','worker.mjs','build.mjs','build.json'])copyFileSync(join(root,n),join(out,n));
const reader=new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'),workers=[],checks=[];
function launch(mode,input,label){
 const file=join(out,label+'.input.json');writeFileSync(file,JSON.stringify(input));const child=spawn(process.execPath,[join(root,'worker.mjs'),mode,file],{cwd:root,stdio:['ignore','pipe','pipe']});
 const events=[],checkpoint=Promise.withResolvers(),terminal=Promise.withResolvers();let stderr='';const rec={label,pid:child.pid,mode,events,exit:null};workers.push(rec);
 const rl=createInterface({input:child.stdout});rl.on('line',line=>{const e=JSON.parse(line);events.push(e);if(e.type==='checkpoint')checkpoint.resolve(e);});child.stderr.on('data',d=>{stderr+=d});
 const timer=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');},15000);
 child.on('error',e=>{clearTimeout(timer);checkpoint.reject(e);terminal.reject(e);});
 child.on('exit',(code,signal)=>{clearTimeout(timer);rec.exit={code,signal};rec.stderr=stderr;save(label+'.json',rec);if(!events.some(e=>e.type==='checkpoint'))checkpoint.reject(Error('Exited without checkpoint'));terminal.resolve(rec);});checkpoint.promise.catch(()=>{});
 return{child,checkpoint:checkpoint.promise,terminal:terminal.promise};
}
let problem;
try{
 const cases=[{id:'C01',pause:'after-copy'},{id:'C02',pause:'in-commit'},{id:'C03',pause:'after-commit'},{id:'C04',pause:'after-copy',tamper:true},{id:'C05',pause:'after-commit',tamper:true}];
 for(const c of cases){
  const descriptor=join(out,c.id+'.descriptor.json'),running=launch('prepare',{pause:c.pause,descriptor},c.id+'-owner');const gate=await running.checkpoint;assert.equal(gate.pid,running.child.pid);assert.equal(reader.state(gate.owner),'running');
  if(c.id==='C01'){
   const live=await launch('recover',{descriptor},c.id+'-live-refusal').terminal;assert.equal(live.exit.code,1);assert(live.events.some(e=>e.type==='error'&&e.message.includes('ORIGINAL_OWNER_NOT_STOPPED')));
  }
  running.child.kill('SIGKILL');const killed=await running.terminal;assert.equal(killed.exit.signal,'SIGKILL');assert.equal(reader.state(gate.owner),'stopped');
  const d=JSON.parse(readFileSync(descriptor,'utf8'));if(c.tamper)writeFileSync(d.targetFile,'SYNTHETIC_EXTERNAL_CHANGE\n');
  const recovery=await launch('recover',{descriptor},c.id+'-recovery').terminal;
  if(c.tamper){
   assert.equal(recovery.exit.code,1);const e=recovery.events.find(e=>e.type==='error');assert(e.message.includes('TARGET_CHANGED'));assert.equal(readFileSync(d.targetFile,'utf8'),'SYNTHETIC_EXTERNAL_CHANGE\n');const ptr=e.state.copy_task_pointer[0];assert.equal(ptr.state_root,c.pause==='after-commit'?JSON.parse(e.state.copy_handoff[0].payload_json).to:JSON.parse(e.state.copy_handoff[0].payload_json).from);checks.push({...c,status:'passed',evidence:{tamperRefused:true,externalBytesPreserved:true,committedMetadataNotRolledBack:c.pause==='after-commit'}});
  }else{
   assert.equal(recovery.exit.code,0);const e=recovery.events.find(e=>e.type==='result');assert.equal(e.classification,c.pause==='after-commit'?'committed-no-replay':'revalidated-and-recopied');
   const repeat=await launch('recover',{descriptor},c.id+'-repeat').terminal;assert.equal(repeat.exit.code,0);assert.equal(repeat.events.find(e=>e.type==='result').classification,'committed-no-replay');checks.push({...c,status:'passed',evidence:{classification:e.classification,newReceipt:e.freshReceipt??false,repeatNoReplay:true,liveOwnerRefusal:c.id==='C01'}});
  }
 }
}catch(e){problem=e.stack;process.exitCode=1;}
finally{for(const w of workers)assert(w.exit,'all spawned workers must terminate');}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,workers,scope:'Actual copy/session registry across owned process SIGKILL with candidate SQLite handoff ledger and synthetic task pointer. No actual TaskService, final multi-binding claims, simultaneous recovery contenders, partial-file-copy checkpoint, native Provider, product edit or power-loss durability.'};save('result.json',result);writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({out,passed:result.passed,error:result.error,workers:workers.map(w=>({label:w.label,exit:w.exit}))}));
