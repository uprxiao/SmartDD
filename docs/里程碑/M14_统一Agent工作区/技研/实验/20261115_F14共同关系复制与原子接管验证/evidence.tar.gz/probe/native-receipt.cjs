module.exports = require('./actual.cjs');
