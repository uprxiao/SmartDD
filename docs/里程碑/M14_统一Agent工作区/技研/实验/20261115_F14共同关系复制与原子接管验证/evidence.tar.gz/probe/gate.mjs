import assert from 'node:assert/strict';import{readFileSync}from'node:fs';import a from './actual.cjs';import{schemaHash,hash}from'./final-schema.mjs';
const contexts=new WeakMap(),active=new WeakMap();
export function register(db){db.function('m14_copy_projection_allowed',(task,from,to,oldId,newId,oldCwd,newCwd)=>{const x=active.get(db);return x&&db.inTransaction&&x.taskId===task&&x.from===from&&x.to===to&&x.nativeId===oldId&&oldId===newId&&x.cwd===oldCwd&&oldCwd===newCwd?1:0;});}
export function install(db){register(db);const old=db.prepare('select * from m14_contract_baseline').get();assert.equal(old.revision,'C1.8');assert.equal(old.schema_hash,schemaHash(db));const sql=readFileSync(new URL('./copy.sql',import.meta.url),'utf8');db.transaction(()=>{db.exec(sql);db.prepare('update m14_contract_baseline set revision=?,inputs_hash=?,schema_hash=?').run('C1.9',hash(sql),schemaHash(db));})()}
export function checkClaim(db,ctx){const r=db.prepare('select * from m14_history_copy where id=?').get(ctx.id);assert(r&&r.generation===ctx.generation&&r.owner_pid===ctx.pid&&r.owner_birth===ctx.startedAt,'STALE_COPY_CLAIM');assert(['planned','copying','copied'].includes(r.phase),'COPY_ALREADY_TERMINAL');return r;}
export async function withCopyContext(db,ctx,action){assert(!contexts.has(db),'COPY_CONTEXT_ALREADY_ACTIVE');contexts.set(db,ctx);try{return await action();}finally{contexts.delete(db);assert(!active.has(db),'PROJECTION_WINDOW_LEAK');}}
export function withCopyIdentityProjection(db,taskId,action){
 const ctx=contexts.get(db);if(!ctx)return action();assert(db.inTransaction,'COPY_PROJECTION_OUTSIDE_TRANSACTION');const r=checkClaim(db,ctx),d=JSON.parse(r.descriptor_json);assert.equal(r.phase,'copied');assert.equal(r.task_id,taskId);assert.equal(r.owner_pid,process.pid);
 const state=db.prepare('select * from m14_task_state where task_id=?').get(taskId);assert(state?.record_state==='active'&&state.selection_revision===r.expected_selection&&state.active_binding===r.binding_id,'TASK_SELECTION_CHANGED');
 assert.equal(db.prepare('select current_hash from m14_cap where cap_id=?').get(r.cap_id).current_hash,r.source_snapshot_hash,'CAP_SOURCE_CHANGED');
 assert.equal(db.prepare('select snapshot_hash from capability_session_snapshots where task_id=?').get(taskId).snapshot_hash,d.nextHash,'LEGACY_PROJECTION_NOT_EXPECTED');
 active.set(db,{taskId,from:d.from,to:d.to,nativeId:d.nativeId,cwd:d.cwd});try{return action();}finally{active.delete(db);}
}
