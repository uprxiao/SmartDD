import assert from 'node:assert/strict';import{randomUUID}from'node:crypto';import{mkdirSync,writeFileSync}from'node:fs';import{join,dirname}from'node:path';import a from './actual.cjs';import{installFinal}from'./final-schema.mjs';import{addRevision}from'./migration.mjs';import{retainVersionClaim}from'./claims.mjs';
export async function fixture(){
 const reader=new a.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');const f=await a.runFixture(reader);const db=f.sqlite;
 let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});const nativeId=randomUUID();current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:nativeId});
 installFinal(db);const taskId=current.snapshot.taskId,bindingId=randomUUID(),capId=randomUUID(),from=current.snapshot.native.stateRoot,to=join(f.root,'copied-history'),cwd=current.snapshot.native.cwd;
 db.transaction(()=>{
  db.prepare('INSERT INTO tasks(id,project_id,cwd,runner,native_session_id,state_root,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?,1,1)').run(taskId,'p1',cwd,'claude-code',nativeId,from,'SYNTHETIC_MIGRATION');
  db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,identity_root,native_id,cwd,legacy_task_id,entry_mode,phase) VALUES(?,?,?,?,?,?,?,'legacy','historical')").run(bindingId,taskId,'claude-code',from,nativeId,cwd,taskId);
  db.prepare("INSERT INTO m14_cap VALUES(?,?,?,'active',NULL)").run(capId,taskId,bindingId);
  const refs=db.prepare('select * from capability_session_refs where task_id=?').all(taskId);
  for(const row of db.prepare('select * from capability_snapshot_versions where task_id=?').all(taskId)){addRevision(db,bindingId,capId,row,refs);retainVersionClaim(db,bindingId,row);}
  db.prepare('update m14_cap set current_hash=? where cap_id=?').run(current.pointer.snapshotHash,capId);
  db.prepare("insert into m14_task_state values(?,?,1,0,0,'active')").run(taskId,bindingId);
 })();
 const source=join(from,'projects',a.encodeClaudeDir(cwd),nativeId+'.jsonl');mkdirSync(dirname(source),{recursive:true});writeFileSync(source,JSON.stringify({type:'user',sessionId:nativeId,message:{role:'user',content:'SYNTHETIC_MIGRATION_HISTORY'}})+'\n');const child=join(dirname(source),nativeId,'subagents','agent.jsonl');mkdirSync(dirname(child),{recursive:true});writeFileSync(child,'SYNTHETIC_CHILD_HISTORY\n');mkdirSync(to);
 const second=randomUUID();db.prepare("INSERT INTO m14_binding(binding_id,task_id,runner,cwd,entry_mode,phase) VALUES(?,?,?,?,'programmatic','planned')").run(second,taskId,'codex',cwd);
 assert.deepEqual(db.pragma('foreign_key_check'),[]);
 return{...f,reader,current,taskId,bindingId,capId,from,to,cwd,nativeId,source,child,second,next:{...current.snapshot,native:{...current.snapshot.native,stateRoot:to}}};
}
export function snapshot(db){return Object.fromEntries(['tasks','m14_task_state','m14_binding','m14_cap','m14_revision','m14_ref','m14_native_claim','m14_native_claim_source','capability_session_snapshots','capability_session_identities','capability_snapshot_versions','capability_session_refs'].map(t=>[t,db.prepare('select * from '+t+' order by 1').all()]));}
