import assert from 'node:assert/strict';import fs from 'node:fs';import{join,relative}from'node:path';import{randomUUID}from'node:crypto';import Database from'better-sqlite3';import a from'./actual.cjs';import candidate from'./candidate.cjs';import{fixture,snapshot}from'./fixture.mjs';import{install,register,withCopyContext,checkClaim}from'./gate.mjs';import{updateCopiedBinding}from'./claims.mjs';
const[mode,inputFile]=process.argv.slice(2),input=JSON.parse(fs.readFileSync(inputFile,'utf8')),reader=new a.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity');
const json=x=>JSON.stringify(x),sha=b=>a.digest(b);function tree(root){const stat=fs.lstatSync(root);assert(stat.isDirectory()&&!stat.isSymbolicLink());const entries=[];const walk=d=>{for(const name of fs.readdirSync(d).sort()){const p=join(d,name),s=fs.lstatSync(p);assert(!s.isSymbolicLink(),'LINKED_HISTORY');entries.push({path:relative(root,p),kind:s.isDirectory()?'directory':'file',hash:s.isDirectory()?null:sha(fs.readFileSync(p))});if(s.isDirectory())walk(p);}};walk(root);return{dev:String(stat.dev),ino:String(stat.ino),entries};}
function sentinel(db,d){
 db.transaction(()=>{
 const id='retained-worktree-'+d.taskId;db.prepare("insert into m14_worktree_intent values(?,?,?,?,?,?,?,?,?,?,'retained',NULL,19,'SYNTHETIC_PRIOR_OUTCOME')").run(id,d.taskId,d.second,1,d.cwd,'prior-common-identity','prior-parent-identity','prior-base','prior-branch',d.cwd+'/retained-worktree');
 const source='imported-history-'+d.taskId,raw=Buffer.from(json({type:'user',sessionId:d.nativeId,message:{role:'user',content:'SYNTHETIC_IMPORTED_PRIOR_HISTORY'}})+'\n'),hash=sha(raw),key='offset:0';
 db.prepare("insert into m14_history_source values(?,?,?,?,?,?,?,?,'readable',NULL)").run(source,d.taskId,d.bindingId,'claude',d.nativeId,'main','claude-transcript-2.1.321',json({fromRoot:d.from}));
 db.prepare('insert into m14_history_record values(?,?,?,?,?)').run(source,key,hash,raw,json({origin:'imported-history',actionable:false}));db.prepare('insert into m14_history_revision values(?,?,?,?,?)').run(source,hash,raw.length,json([{offset:0,size:raw.length,key,rawHash:hash}]),json({state:'readable'}));db.prepare('update m14_history_source set current_revision=? where source_id=?').run(hash,source);
 })();
}
function retained(db){return Object.fromEntries(['m14_worktree_intent','m14_worktree_binding','m14_history_source','m14_history_revision','m14_history_record'].map(t=>[t,db.prepare('select * from '+t+' order by 1').all()]));}
let db,result;let fileCopies=0;
try{
 let d,store;
 if(mode==='prepare'){
  const f=await fixture();db=f.sqlite;store=f.store;install(db);const owner=reader.read(process.pid);assert(owner);d={id:randomUUID(),root:f.root,db:join(f.root,'state.sqlite'),home:f.home,taskId:f.taskId,bindingId:f.bindingId,capId:f.capId,second:f.second,from:f.from,to:f.to,cwd:f.cwd,nativeId:f.nativeId,oldHash:f.current.pointer.snapshotHash,nextHash:sha(a.canonicalJson(f.next)),next:f.next,source:f.source,target:join(f.to,'projects',a.encodeClaudeDir(f.cwd),f.nativeId+'.jsonl'),sourceState:tree(f.from),originalTargetState:tree(f.to)};sentinel(db,d);d.retainedHash=sha(json(retained(db)));d.baseline=snapshot(db);
  db.prepare("insert into m14_history_copy values(?,?,?,?,?,1,'planned',1,?,?,?,NULL)").run(d.id,d.taskId,d.bindingId,d.capId,d.oldHash,owner.pid,owner.startedAt,json(d));fs.writeFileSync(input.descriptor,json(d));db.prepare("update m14_history_copy set phase='copying' where id=?").run(d.id);
  const copy=fs.copyFileSync;fs.copyFileSync=(from,to,...rest)=>{const value=copy(from,to,...rest);if(String(to).includes('.willyou-copy-')){fileCopies++;if(fileCopies===1){db.prepare('update m14_history_copy set progress_json=? where id=?').run(json({targetState:tree(d.to),point:'after-first-staged-file',copiedFile:String(to)}),d.id);fs.writeFileSync(input.checkpoint,json({point:'after-first-staged-file',pid:process.pid,owner,fileCopies}));process.exit(73);}}return value;};
  a.copyClaudeSession({from:d.from,to:d.to,cwd:d.cwd,sessionId:d.nativeId,nativeTarget:false});throw Error('CHECKPOINT_NOT_REACHED');
 }else{
  d=JSON.parse(fs.readFileSync(input.descriptor,'utf8'));db=new Database(d.db);db.pragma('foreign_keys=ON');register(db);store=new a.ResourceStore(db,d.root,undefined,{processes:reader});const r=db.prepare('select * from m14_history_copy where id=?').get(d.id);
  assert.equal(sha(json(retained(db))),d.retainedHash,'RETAINED_RELATIONS_CHANGED');
  if(r.phase==='committed'){
   assert.equal(db.prepare('select current_hash from m14_cap where cap_id=?').get(d.capId).current_hash,d.nextHash);assert.equal(db.prepare('select state_root from tasks where id=?').get(d.taskId).state_root,d.to);assert.equal(db.prepare('select identity_root from m14_binding where binding_id=?').get(d.bindingId).identity_root,d.to);result={classification:'committed-no-replay',fileCopies,retainedRelationsUnchanged:true};
  }else{
   const owner=reader.read(process.pid);assert(owner);const ctx=db.transaction(()=>{const current=db.prepare('select * from m14_history_copy where id=?').get(d.id);assert(['copying','copied'].includes(current.phase));assert.equal(reader.state({pid:current.owner_pid,startedAt:current.owner_birth}),'stopped','OLD_OWNER_NOT_STOPPED');const generation=current.generation+1;db.prepare('update m14_history_copy set generation=?,owner_pid=?,owner_birth=? where id=?').run(generation,owner.pid,owner.startedAt,d.id);return{id:d.id,generation,...owner};}).immediate();
   assert.deepEqual(tree(d.from),d.sourceState,'SOURCE_CHANGED');assert.deepEqual(tree(d.to),JSON.parse(r.progress_json).targetState,'TARGET_CHANGED');assert.equal(db.prepare('select snapshot_hash from capability_session_snapshots where task_id=?').get(d.taskId).snapshot_hash,d.oldHash);assert.equal(db.prepare('select state_root from tasks where id=?').get(d.taskId).state_root,d.from);
   const registry=new candidate.CapabilitySessionRegistry(store,{assertInitialSelection:s=>{assert.equal(s.taskId,d.taskId);assert.equal(s.adapterBinding.hash,d.next.adapterBinding.hash);assert.equal(s.packages.length,0);},verifyExtraResource:()=>{throw Error('Unexpected verifier');}});
   registry.assertHistoryCopyAllowed({taskId:d.taskId,from:d.from,to:d.to,cwd:d.cwd,sessionId:d.nativeId,home:d.home});
   const receipt=await a.withResourceLock(store.root,()=>{checkClaim(db,ctx);assert.deepEqual(tree(d.from),d.sourceState);assert.deepEqual(tree(d.to),JSON.parse(r.progress_json).targetState);fileCopies++;return a.copyClaudeSession({from:d.from,to:d.to,cwd:d.cwd,sessionId:d.nativeId,nativeTarget:false});});
   db.prepare("update m14_history_copy set phase='copied',progress_json=? where id=?").run(json({targetState:tree(d.to),point:'full-copy-verified'}),d.id);
   await withCopyContext(db,ctx,()=>registry.adoptLibrary(d.taskId,d.oldHash,d.next,{copy:receipt,home:d.home,commit:(before,after)=>{
    assert(db.inTransaction);checkClaim(db,ctx);assert.equal(before.pointer.snapshotHash,d.oldHash);assert.equal(after.pointer.snapshotHash,d.nextHash);updateCopiedBinding(db,d.bindingId,after);db.prepare('update tasks set state_root=? where id=?').run(d.to,d.taskId);db.prepare('update m14_task_state set selection_revision=selection_revision+1 where task_id=?').run(d.taskId);db.prepare("update m14_history_copy set phase='committed' where id=?").run(d.id);assert.equal(sha(json(retained(db))),d.retainedHash);if(input.failCommit)throw Error('F14_COMMIT_FAILURE');
   }}));
   assert.deepEqual(tree(d.from),d.sourceState);result={classification:'fresh-receipt-committed',fileCopies,retainedRelationsUnchanged:true,sourceUnchanged:true,oldAndNewClaims:db.prepare('select identity_root from m14_native_claim where binding_id=?').all(d.bindingId)};
  }
  assert.deepEqual(db.pragma('foreign_key_check'),[]);assert.equal(db.pragma('integrity_check',{simple:true}),'ok');
 }
 console.log(json({type:'result',...result}));
}catch(e){console.log(json({type:'error',message:e.message,stack:e.stack,fileCopies}));process.exitCode=1;}finally{db?.close();}
