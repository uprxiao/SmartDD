import assert from 'node:assert/strict';import{mkdtempSync,writeFileSync,readFileSync}from'node:fs';import{join}from'node:path';import a from './actual.cjs';import{fixture,snapshot}from'./fixture.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/negative-');let f,error,result;
try{
 f=await fixture();const before=snapshot(f.sqlite),source=readFileSync(f.source);
 f.sessions.assertHistoryCopyAllowed({taskId:f.taskId,from:f.from,to:f.to,cwd:f.cwd,sessionId:f.nativeId,home:f.home});
 const receipt=a.copyClaudeSession({from:f.from,to:f.to,cwd:f.cwd,sessionId:f.nativeId,nativeTarget:false});let caught;
 try{await f.sessions.adoptLibrary(f.taskId,f.current.pointer.snapshotHash,f.next,{copy:receipt,home:f.home,commit(){throw Error('SHOULD_NOT_REACH_COMMIT');}});}catch(e){caught=e;}
 assert(caught?.message.includes('M14_LEGACY_IDENTITY_SEALED'),caught?.stack);assert.deepEqual(snapshot(f.sqlite),before);assert.deepEqual(readFileSync(f.source),source);
 result={passed:true,negative:true,errorCode:caught.code,message:caught.message,multiBindingOriginalAdoptionRefused:true,allMetadataRolledBack:true,sourceUnchanged:true,fixtureRoot:f.root,db:join(f.root,'state.sqlite'),scope:'Current unmodified registry plus exact C1.8 schema, actual copy receipt, second programmatic planned binding. Exposes research integration gap; not a production bug or approved guard removal.'};await f.sqlite.backup(join(out,'state.sqlite'));
}catch(e){error=e.stack;process.exitCode=1;}finally{f?.sqlite.close();}
const value={out,result,error:error??null};writeFileSync(join(out,'result.json'),JSON.stringify(value,null,2));writeFileSync(join(root,'negative-latest.json'),JSON.stringify(value,null,2));console.log(JSON.stringify(value));
