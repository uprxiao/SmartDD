import assert from 'node:assert/strict';import{readFileSync}from'node:fs';import{createHash}from'node:crypto';
export const image=JSON.parse(readFileSync(new URL('./schema-inspect.json',import.meta.url),'utf8')).next;
export const hash=x=>createHash('sha256').update(x).digest('hex');
export const schemaHash=db=>hash(JSON.stringify(db.prepare('SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name').all()));
export function installFinal(db){
 assert.equal(db.prepare('select count(*) n from capability_runs').get().n,0,'FRESH_FIXTURE_REQUIRED');
 const existing=db.prepare("select type,name,sql from sqlite_master where sql is not null").all();
 for(const row of existing){const target=image.find(x=>x.name===row.name&&x.type===row.type);assert(target,'SOURCE_OBJECT_MISSING');if(row.name!=='capability_runs')assert.equal(target.sql,row.sql,'UNEXPECTED_SOURCE_SCHEMA_CHANGE:'+row.name);}
 db.pragma('foreign_keys=OFF');db.exec('BEGIN IMMEDIATE');
 try{
  for(const row of image.filter(x=>x.type==='table'&&x.name!=='capability_runs'))if(!db.prepare('select 1 from sqlite_master where name=?').get(row.name))db.exec(row.sql);
  db.exec('DROP TABLE capability_runs');db.exec(image.find(x=>x.name==='capability_runs').sql);
  for(const row of image.filter(x=>x.type!=='table'))if(!db.prepare('select 1 from sqlite_master where name=? and type=?').get(row.name,row.type))db.exec(row.sql);
  db.prepare('insert into m14_business_epoch values(1,0)').run();
  db.exec("INSERT INTO m14_resource_publication SELECT 'resource:'||resource_id,1 FROM capability_resources; INSERT INTO m14_resource_publication SELECT 'plugin:'||package_hash,1 FROM plugin_packages;");
  db.prepare('insert into m14_contract_baseline values(?,?,?)').run('C1.8',hash('C1.8 final schema from F13 audit'),schemaHash(db));
  assert.deepEqual(db.pragma('foreign_key_check'),[]);db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e;}finally{db.pragma('foreign_keys=ON');}
}
