from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_原生子Agent定向与后代停止验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
names=['latest-claude.json','latest-codex.json','latest-nested-claude.json','latest-nested-codex.json','latest-subtree-codex.json'];results=[json.loads((root/n).read_text())for n in names]
assert all(r['passed']for r in results)
def fs(r):return[json.loads(l)for l in (Path(r['out'])/'frames.jsonl').read_text().splitlines()]
for r in results:
 f=fs(r);steps={s['name']:s for s in r['controls']};assert steps['parent-completed-with-two-pending-children']['frameCount']<=steps['stop-A-requested']['frameCount'];assert steps['stop-A-native-terminal']['frameCount']<=steps['sibling-B-response-released']['frameCount'];assert all(p['exit']['code']==0 for p in r['processes'])
 if r['driver']=='claude':
  a=next(m for m in f if m.get('subtype')=='task_started' and m['task_id']==r['childA']);b=next(m for m in f if m.get('subtype')=='task_started' and m['task_id']==r['childB']);assert a['session_id']==b['session_id'];assert any(m.get('subtype')=='task_notification'and m['task_id']==r['childA']and m['status']=='stopped'for m in f);assert any(m.get('subtype')=='task_notification'and m['task_id']==r['childB']and m['status']=='completed'for m in f)
  if r.get('childC'):
   c=next(m for m in f if m.get('subtype')=='task_started' and m['task_id']==r['childC']);assert c['parent_task_id']==a['task_id'] and c['spawn_depth']==2;assert steps['grandchild-C-terminal']['status']=='stopped'
 else:
  assert any(m.get('method')=='turn/completed'and m['params']['threadId']==r['childA']and m['params']['turn']['status']=='interrupted'for m in f);assert any(m.get('method')=='turn/completed'and m['params']['threadId']==r['childB']and m['params']['turn']['status']=='completed'for m in f)
  if r.get('childC'):
   c=next(m['params']['item']for m in f if m.get('method')=='item/completed'and m['params']['item'].get('tool')=='spawnAgent'and m['params']['item'].get('prompt')=='STOP_GRANDCHILD_C');assert c['senderThreadId']==r['childA'] and c['receiverThreadIds']==[r['childC']]
assert next(s for s in results[3]['controls']if s['name']=='grandchild-C-terminal')['status']=='completed'
assert next(s for s in results[4]['controls']if s['name']=='grandchild-C-terminal')['status']=='interrupted'
attempts=[]
for p in sorted(root.glob('attempt-*')):
 r=json.loads((p/'result.json').read_text());assert all(x['exit']is not None for x in r['processes']);attempts.append({'attempt':p.name,'passed':r['passed'],'driver':r['driver'],'error':r['error'],'requests':r['modelRequests'],'exits':[x['exit']for x in r['processes']]})
refs=[t3/'apps/server/src/orchestration-v2/Adapters'/n for n in ['ClaudeAdapterV2.ts','CodexAdapterV2.ts']]+[Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts'),Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'versions':{'ClaudeSDK':'0.3.321','ClaudeNative':'2.1.321','CodexNative':'0.167.1'},'sourceOnlyReferences':['ClaudeAdapterV2 stopSubagent awaits confirmed native outcome after stopTask, checks live owning query and task generation.','CodexAdapterV2 interrupt path enumerates active lineage and late descendants, sends per-thread/turn interrupts, and separately handles tracked terminal processes.'],'limits':'No T3 adapter execution in this batch. Probe owns native processes directly, not WillYou run registration or business activity leases.'}
result={'checksPassed':5,'results':results,'attempts':attempts,'conclusion':'Parent turn completion does not drain native children. Directed stop can preserve sibling. In tested nested paths Claude stopTask stopped foreground grandchild; Codex interrupt(A) left C running/completed. Explicit interrupt(C) then interrupt(A) stopped both, sibling B completed.','scope':'Local synthetic models; fixed native versions on macOS arm64. No shell or business work inside children; no runtime-native subtree freeze, late-spawn race, deeper recursion, crash recovery, permission or UI proof.','paidModelCalls':0,'productChanges':0}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2));(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
files=[root/n for n in ['probe.mjs','nested.mjs','subtree.mjs','model.mjs','native-inputs.mjs','prepare.py','source-review.json','result.json']]
for p in sorted(root.glob('attempt-*')):files+=sorted(f for f in p.iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in files]}
for n,d in [('result.json',result),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 原生子 Agent 定向停止与后代范围

依据 R0.2 的 R05／R06／R11／R12 与 Q29。固定 Claude SDK 0.3.321／native 2.1.321、Codex 0.167.1。五项边界检查通过，其中一项专门复现 Codex 单节点 interrupt 不递归的反例。全部模型响应来自本机模拟服务；没有付费模型、外部业务、产品或原型修改。

| 检查 | 已验证结果 |
| --- | --- |
| S01 Claude 定向停止 | 父 result 已成功返回，A／B 两个子模型 HTTP 请求仍等待；stopTask(A) 后收到 A stopped 且其请求关闭；B 未结束，放行其模型响应后 B completed |
| S02 Codex 定向停止 | 父 turn/completed 时 A／B 仍在途；按 A 的真实 threadId＋turnId interrupt，等待 A interrupted 与 HTTP 关闭；B 随后正常 completed |
| S03 Claude 一层后代 | A 创建前台孙任务 C，真实 parent_task_id 指 A、spawn_depth=2；此时 A 在等工具、C 在等模型。stopTask(A) 后 A／C 均报告 stopped，B 未被停止且正常完成 |
| S04 Codex 非递归反例 | agents.max_depth=2，A 创建 C，分别有真实 native thread／turn。只 interrupt(A)，A 已 interrupted，随后才放行 C 的模型响应，C 仍 completed。不能把 A 的终态当整棵子树终态 |
| S05 Codex 显式后代候选 | 对已知 C 发 interrupt 并等原生终态，再 interrupt A；C／A 均 interrupted，B 继续 completed。仅证明这个已知、静止拓扑，不等于解决停止期间新增后代 |

控制日志记录请求、ACK、原生终态和响应放行时的帧序号；等待使用事件／Deferred，不以 sleep 或 ACK 当完成。五份成功实验原生进程均 exit 0。所有 child HTTP 只返回标记文本，无 Shell、文件写、MCP 或业务操作；因此不能证明这些在途活动也已排空。

T3 源码参考：Claude stopSubagent 检查当前 query／原生身份并等待 confirmedOutcome；Codex interrupt 路径枚举 lineage、补处理迟到后代，并另管终端进程。这里只读核对源码，没有运行 T3 适配器，不把源码或本探针升格为 WillYou 已实现的停止服务。

失败记录：初次 Claude 嵌套探针错误等待 A 的第二个模型请求；实际 A 正前台等待 C 工具，所以门闩超时，捕获进程关闭退出 143。改为等待真实 task_started、父完成及 C／B 请求，再按实际工具等待阶段停止，验证通过。未靠增加超时时长或强制改成后台规避差异。

迁移结论：turn_done、节点 terminal、子树 terminal、execution scope drained 是四个不同判断。原生来源节点与宿主委派节点保持不同控制器。停止子树需记录目标／代次和后代关系，逐个取得终态，并处理停止期间新出现后代；未证实排空时保留 stopping／unknown 和写者／业务租约。单节点控制只描述当前节点；不把兄弟一起误停。

仍待验证：更深后代、后台工具、递归期间新建节点、重复停止／迟到旧代事件、宿主退出／恢复、当前业务活动排空、权限及单 Agent 禁用、最终任务树 UI。Q29 保持部分。

复跑依次执行 `node probe.mjs claude`、`node probe.mjs codex`、`node nested.mjs claude`、`node nested.mjs codex`、`node subtree.mjs codex`；需要原固定隔离依赖与 localhost 监听权限。`python3 prepare.py` 核验原始帧的父子关系／终态并生成归档。子请求只在研究门闩中暂停，没有修改执行器内部。

[结果](result.json) · [源码基线](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 old='正常结果与退出已验证；权限继承、在途业务、强制／递归停止和崩溃恢复继续待证，本节不构成全版本或完整协作闭环声明。'
 assert old in t
 t=t.replace(old,'正常结果与退出已验证；定向与一层后代停止的范围见下节，权限继承、在途业务和崩溃恢复继续待证。本节不构成全版本或完整协作闭环声明。')
 section='''#### 7.4.1 节点停止、子树停止与执行范围排空

[五项隔离检查](实验/20261114_原生子Agent定向与后代停止验证/README.md)证明两端父回合成功返回时，两个原生子 Agent 仍可处于在途模型请求；父 turn_done 不关闭子树。Claude stopTask(A) 与 Codex 对 A 的精确 threadId／turnId interrupt 均可停止 A，同时 B 继续并完成。控制请求返回只是已接受；适配器仍等待关联原生终态，不能先把 UI 或资源投影改成全部停止。

后代范围并不等价：本次 Claude 的 A 前台等待孙任务 C，stopTask(A) 得到 A／C stopped；Codex 中 A interrupted 后 C 仍能继续 completed。Codex 对已知 C、A 分别 interrupt 并等待各自终态的候选路径通过，兄弟 B 未受影响。这个固定两层拓扑不证明停止期间新增后代、深层递归、后台 Shell 或业务操作已排空，Claude 的这一次递归结果也不成为跨版本通用保证。

停止合同区分 requestStopNode 与 requestStopSubtree 的意图及目标集合。保存 origin、当前 binding／run／generation、原生节点与父子关系、控制请求和终态证据。原生节点由所属适配器控制，宿主委派由任务服务递归收口，不因一个 provider_native 子节点终态就释放整个宿主 run。子树停止进入 stopping 后停止接纳新的宿主委派；原生执行器能否禁止新建后代需能力声明，做不到时持续纳入迟到后代并停止、等待其终态，超时保留 unknown，不能宣称已冻结原生树。

排空还需结合后台工具／进程和现有业务 withActivity／租约；节点已停止不代表外部写入已撤销。未知或在途时继续保留共享目录写者，避免后继 Provider 与旧后代并发写入。T3 的 Claude 停止等待 confirmedOutcome、Codex lineage 与迟到后代处理可作为实现参考，本轮没有执行完整适配器。重复停止、旧代事件、子树变动和业务联合仍须独立验证及实施后回归。

'''
 return t.replace('## 8. Git／SVN 与工作目录协调',section+'## 8. Git／SVN 与工作目录协调')
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 assert '### 4.79 'not in t
 t=t.replace('原生权限、禁用、子业务、递归停止和崩溃恢复仍待验 |','§4.79 补两端定向停止／兄弟保留与一层后代，Codex 非递归反例及显式后代停止候选；原生权限、禁用、子业务、动态递归和崩溃恢复仍待验 |')
 t=t.replace('## 5. 失败与驱动修正','''### 4.79 原生子 Agent 定向与后代停止

[五项边界检查](实验/20261114_原生子Agent定向与后代停止验证/README.md)通过：两端父完成时子任务仍在途；定向停止 A 均有原生终态和请求关闭，兄弟 B 正常继续。Claude A 前台等待 C 时 stopTask(A) 得到 A／C stopped；Codex 只 interrupt(A) 后 C 仍 completed，是非递归反例。显式按 C、A 精确身份逐一 interrupt／等待后，两者 interrupted，B 保留。

本机受控模型、固定原生版本；没有子 Shell／业务写、动态后代或完整适配器。五份成功进程 exit 0。保留 Claude 首次驱动把前台工具等待误当第二轮模型等待的超时及退出 143；修正事件门闩后通过。技术方案 §7.4.1 明确节点、子树与执行范围排空的不同证据；Q29 仍部分，原生权限、禁用、动态递归、业务排空及崩溃恢复待验。

## 5. 失败与驱动修正''')
 t=t.replace('截至 §4.78，56 个宽口径问题项中','截至 §4.79，56 个宽口径问题项中')
 groups=collections.Counter()
 for l in t.splitlines():
  if re.match(r'^\| Q\d\d \|',l):
   a=l.split('|');q=a[1].strip();s=a[4].strip();groups['deferred'if q in ['Q21','Q22']else'optional'if q=='Q36'else'partial'if s.startswith(('**部分','**实证限定','**发现问题并验证候选修正'))else'pending']+=1
 assert groups=={'partial':46,'pending':7,'deferred':2,'optional':1}
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：原生子 Agent 定向停止与后代范围已补实证；发现 Codex 单节点 interrupt 不递归，并验证显式停止已知后代的候选。设计见[技术方案 §7.4.1](技研/技术方案.md)，数量与范围仍以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：继续[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)中的权限档位／禁用和动态子树边界，区分可独立验证的研究疑点与开发后产品回归；不将原生终态等同业务活动排空。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'checks':5,'attempts':len(attempts),'archiveFiles':len(files),'localRequestsIncludingFailed':sum(x['requests']for x in attempts)}))
