import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {createServer} from 'node:http';
import {mkdtempSync,mkdirSync,writeFileSync,appendFileSync,copyFileSync} from 'node:fs';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {nativeRuntime} from './native-inputs.mjs';
import {reply} from './model.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),driver=process.argv[2]??'claude',records=[],frames=[],requests=[],controls=[];
for(const f of ['nested.mjs','model.mjs','native-inputs.mjs'])copyFileSync(root+'/'+f,out+'/'+f);
const save=(n,v)=>writeFileSync(out+'/'+n,JSON.stringify(v,null,2)+'\n');
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});promise.catch(()=>{});return{promise,resolve,reject};};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,r)=>timer=setTimeout(()=>r(Error('WATCHDOG:'+label)),25000))]).finally(()=>clearTimeout(timer));};
const home=out+'/home',cwd=out+'/workspace',state=home+(driver==='claude'?'/.claude':'/.codex');for(const p of [home,cwd,state])mkdirSync(p,{recursive:true});
let base,error,serverError,parentRequests=0,rootThread,childA,childB,childC,childACalls=0;
const aRequested=deferred(),bRequested=deferred(),parentDone=deferred(),aStopped=deferred(),bCompleted=deferred(),inputEnd=deferred();
const cRequested=deferred(),cTerminal=deferred();
const pending={};const turns=new Map();
function env(){return{HOME:home,PATH:'/usr/bin:/bin',TMPDIR:out,LANG:'en_US.UTF-8',HTTP_PROXY:'http://127.0.0.1:1',HTTPS_PROXY:'http://127.0.0.1:1',ALL_PROXY:'http://127.0.0.1:1',NO_PROXY:'localhost,127.0.0.1',CLAUDE_CONFIG_DIR:state,CODEX_HOME:state,CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC:'1',DISABLE_AUTOUPDATER:'1',ENABLE_TOOL_SEARCH:'false',ANTHROPIC_BASE_URL:base+'/claude',ANTHROPIC_AUTH_TOKEN:'synthetic-only',ANTHROPIC_API_KEY:'synthetic-only',WY_MODEL_KEY:'synthetic-only'};}
function owned(command,args){const child=spawn(command,args,{cwd,env:env(),stdio:['pipe','pipe','pipe']}),r={pid:child.pid,command,args,exit:null};records.push({child,r});child.stdin.on('error',()=>{});child.stdout.on('data',b=>appendFileSync(out+'/stdout.jsonl',b));child.stderr.on('data',b=>appendFileSync(out+'/stderr.log',b));const done=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>{r.exit={code,signal};resolve(r);});});return{child,r,done};}
function control(name,details={}){controls.push({name,frameCount:frames.length,...details});save('controls.json',controls);}
function frame(m){
 frames.push(m);appendFileSync(out+'/frames.jsonl',JSON.stringify(m)+'\n');
 if(driver==='claude'){
  if(m.subtype==='task_started'){if(m.prompt==='STOP_CHILD_A')childA=m.task_id;if(m.prompt==='STOP_CHILD_B')childB=m.task_id;if(m.prompt==='STOP_GRANDCHILD_C')childC=m.task_id;}
  if(m.type==='result'&&!m.is_error)parentDone.resolve(m);
  if(m.subtype==='task_notification'&&m.task_id===childA)aStopped.resolve(m);
  if(m.subtype==='task_notification'&&m.task_id===childB)bCompleted.resolve(m);if(m.subtype==='task_notification'&&m.task_id===childC)cTerminal.resolve(m);
 }else{
  if(m.method==='turn/started')turns.set(m.params.threadId,m.params.turn.id);
  if(m.method==='item/completed'&&m.params.item.tool==='spawnAgent'){const item=m.params.item;if(item.prompt==='STOP_CHILD_A')childA=item.receiverThreadIds[0];if(item.prompt==='STOP_CHILD_B')childB=item.receiverThreadIds[0];if(item.prompt==='STOP_GRANDCHILD_C')childC=item.receiverThreadIds[0];}
  if(m.method==='turn/completed'){if(m.params.threadId===rootThread)parentDone.resolve(m.params.turn);if(m.params.threadId===childA)aStopped.resolve(m.params.turn);if(m.params.threadId===childB)bCompleted.resolve(m.params.turn);if(m.params.threadId===childC)cTerminal.resolve(m.params.turn);}
 }
}
const server=createServer(async(req,res)=>{try{
 let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),text=JSON.stringify(driver==='claude'?body.messages:body.input),which=text.includes('STOP_PARENT')?'parent':text.includes('STOP_CHILD_A')?'A':text.includes('STOP_CHILD_B')?'B':text.includes('STOP_GRANDCHILD_C')?'C':'unknown';
 requests.push({path:req.url,which,body});appendFileSync(out+'/requests.jsonl',JSON.stringify(requests.at(-1))+'\n');assert(requests.length<=12,'EXCESS_REQUESTS');
 if(which==='A'&&++childACalls===1){const tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]),tool=tools.find(t=>t.name===(driver==='claude'?'Agent':'spawn_agent'));save('child-A-offered-tools.json',tools);assert(tool,'NESTED_SPAWN_TOOL_MISSING');reply(res,driver,body,{tool,args:driver==='claude'?{description:'Grandchild',prompt:'STOP_GRANDCHILD_C',subagent_type:'m14-grandchild'}:{message:'STOP_GRANDCHILD_C'}});if(driver==='claude')aRequested.resolve();return;}
 if(which==='A'||which==='B'||which==='C'){assert(!pending[which],'CHILD_RETRIED');const closed=deferred();pending[which]={res,body,closed,closedSeen:false};res.once('close',()=>{pending[which].closedSeen=true;closed.resolve();control('child-http-closed',{which});});(which==='A'?aRequested:which==='B'?bRequested:cRequested).resolve();return;}
 assert.equal(which,'parent');parentRequests++;
 if(parentRequests<=2){const tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]),tool=tools.find(t=>t.name===(driver==='claude'?'Agent':'spawn_agent'));assert(tool,'SPAWN_MISSING');const marker=parentRequests===1?'STOP_CHILD_A':'STOP_CHILD_B';reply(res,driver,body,{tool,args:driver==='claude'?{description:marker,prompt:marker,subagent_type:'m14-child'}:{message:marker}});return;}
 reply(res,driver,body,{text:'STOP_PARENT_RETURNED'});
 }catch(e){serverError??=e.stack;res.writeHead(500);res.end('{}');}});
async function verifyAndStop(stop){
 await deadline(Promise.all([aRequested.promise,bRequested.promise,cRequested.promise,parentDone.promise]),'two children and parent completion');
 assert(childA&&childB&&childC&&new Set([childA,childB,childC]).size===3);assert((!pending.A||!pending.A.closedSeen)&&!pending.B.closedSeen&&!pending.C.closedSeen);assert(!records[0].r.exit);
 control('parent-completed-with-two-pending-children',{childA,childB,childC,childAWaiting:pending.A?'model-http':'grandchild-tool'});
 control('stop-A-requested');await deadline(stop(),'stop-A acknowledgement');control('stop-A-acknowledged');
 const terminal=await deadline(aStopped.promise,'native-A-terminal');assert.equal(terminal.status,driver==='claude'?'stopped':'interrupted');control('stop-A-native-terminal',{status:terminal.status});
 if(pending.A)await deadline(pending.A.closed.promise,'child A HTTP canceled');assert(!pending.B.closedSeen,'SIBLING_WAS_CANCELED');
 assert(!frames.some(m=>driver==='claude'?m.subtype==='task_notification'&&m.task_id===childB:m.method==='turn/completed'&&m.params.threadId===childB),'SIBLING_PREMATURE_TERMINAL');control('sibling-B-still-pending');
 if(!pending.C.closedSeen){reply(pending.C.res,driver,pending.C.body,{text:'GRANDCHILD_RESULT_AFTER_PARENT_STOP'});control('grandchild-C-response-released-after-A-terminal');}
 const grandchild=await deadline(cTerminal.promise,'grandchild C terminal');control('grandchild-C-terminal',{status:grandchild.status});assert(['completed','stopped','interrupted'].includes(grandchild.status));
 reply(pending.B.res,driver,pending.B.body,{text:'STOP_CHILD_B_RESULT'});control('sibling-B-response-released');
 const completed=await deadline(bCompleted.promise,'sibling B completed');assert.equal(completed.status,'completed');control('sibling-B-native-completed');
}
try{
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
 if(driver==='claude'){
  let p;async function* input(){yield{type:'user',message:{role:'user',content:'STOP_PARENT'},parent_tool_use_id:null,session_id:''};await inputEnd.promise;}
  const q=query({prompt:input(),options:{pathToClaudeCodeExecutable:nativeRuntime(driver).path,cwd,model:'claude-haiku-4-5',settingSources:[],env:env(),strictMcpConfig:true,mcpServers:{},tools:['Agent'],allowedTools:['Agent'],agents:{'m14-child':{description:'Isolated child stop test',prompt:'Return requested marker.',tools:['Agent'],model:'inherit'},'m14-grandchild':{description:'Isolated leaf',prompt:'Return marker.',tools:[],model:'inherit'}},spawnClaudeCodeProcess:o=>{p=owned(o.command,o.args);return p.child;}}});
  const drain=(async()=>{for await(const m of q)frame(m);})();drain.catch(()=>{});
  try{await verifyAndStop(()=>q.stopTask(childA));inputEnd.resolve();await deadline(drain,'claude stream normal end');}finally{inputEnd.resolve();q.close();if(p)await deadline(p.done,'claude process exit');}
 }else{
  const p=owned(nativeRuntime(driver).path,['app-server','--enable','multi_agent','--disable','plugins','-c','agents.max_depth=2','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(base+'/codex/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}']);let seq=0;const waiting=new Map();
  const rpc=(method,params)=>{const id=++seq,d=deferred();waiting.set(id,d);p.child.stdin.write(JSON.stringify({id,method,params})+'\n');return deadline(d.promise,method);};
  createInterface({input:p.child.stdout}).on('line',line=>{try{const m=JSON.parse(line);frame(m);if(m.id!==undefined&&!m.method){const d=waiting.get(m.id);waiting.delete(m.id);m.error?d?.reject(Error(JSON.stringify(m.error))):d?.resolve(m.result);}if(m.id!==undefined&&m.method)p.child.stdin.write(JSON.stringify({id:m.id,error:{code:-32601,message:'Unexpected request'}})+'\n');}catch(e){serverError??=e.stack;}});
  try{await rpc('initialize',{clientInfo:{name:'m14_native_child_stop',version:'1'},capabilities:{experimentalApi:true}});p.child.stdin.write('{"method":"initialized"}\n');const r=await rpc('thread/start',{cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'never',sandbox:'danger-full-access'});rootThread=r.thread.id;await rpc('turn/start',{threadId:rootThread,input:[{type:'text',text:'STOP_PARENT',text_elements:[]}]});await verifyAndStop(()=>{assert(turns.has(childA),'CHILD_TURN_ID_MISSING');return rpc('turn/interrupt',{threadId:childA,turnId:turns.get(childA)});});}finally{p.child.stdin.end();await deadline(p.done,'codex process exit');}
 }
 if(serverError)throw Error(serverError);assert(records.every(x=>x.r.exit?.code===0),'PROCESS_EXIT_NOT_ZERO');
}catch(e){error=e.stack;process.exitCode=1;}finally{inputEnd.resolve();for(const p of records)if(!p.r.exit){p.child.kill('SIGTERM');await deadline(new Promise(r=>p.child.once('close',r)),'cleanup');}server.closeAllConnections();await new Promise(r=>server.close(r));}
const result={out,driver,passed:!error,error:error??null,serverError:serverError??null,modelRequests:requests.length,parentRequests,rootThread,childA,childB,childC,controls,processes:records.map(x=>x.r),scope:'Fixed native versions with A owning one native grandchild C and sibling B. Pause leaf model HTTP (Claude A waits for foreground C tool, Codex A waits for model HTTP); stop A after parent completion, record C outcome and sibling continuation. No shell, business writes, deeper descendants, stop races, crash recovery, OS containment or full product adapters.'};save('result.json',result);writeFileSync(root+'/latest-nested-'+driver+'.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
