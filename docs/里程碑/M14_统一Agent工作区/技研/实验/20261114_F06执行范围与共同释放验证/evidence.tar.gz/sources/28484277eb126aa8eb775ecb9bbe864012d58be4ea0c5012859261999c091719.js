/* eslint no-console: 0 */
import * as urllib from './url.js';
import util from 'node:util';
import fs from 'node:fs';
import nmfetch from '../fetch/index.js';
import * as errors from '../errors.js';
import { isProtoKey, copyOwnKeys } from './objects.js';
import dns from 'node:dns';
import net from 'node:net';
import os from 'node:os';
import { finished } from 'node:stream';
// re-exported for the callers that already depend on this module, see ./objects
export { isProtoKey, copyOwnKeys };
const DNS_TTL = 5 * 60 * 1000;
const CACHE_CLEANUP_INTERVAL = 30 * 1000; // Minimum 30 seconds between cleanups
const MAX_CACHE_SIZE = 1000; // Maximum number of entries in cache
let lastCacheCleanup = 0;
/** @internal */
export const _lastCacheCleanup = () => lastCacheCleanup;
/** @internal */
export const _resetCacheCleanup = () => {
    lastCacheCleanup = 0;
};
export let networkInterfaces;
let networkInterfacesRead = false;
// Read on first use rather than at load, so that importing the module does not ask for
// the interface table (Deno prompts for --allow-sys on it)
/** @internal */
export const _readNetworkInterfaces = () => {
    if (!networkInterfacesRead) {
        networkInterfacesRead = true;
        try {
            networkInterfaces = os.networkInterfaces();
        }
        catch (_err) {
            // fails on some systems
        }
    }
    return networkInterfaces;
};
const isFamilySupported = (family, allowInternal) => {
    const addresses = Object.values(_readNetworkInterfaces() || {}).flat();
    if (!addresses.length) {
        // hope for the best. Runtimes without an interface table (Cloudflare
        // Workers) report an empty object rather than throwing
        return true;
    }
    return addresses.filter(i => !i.internal || allowInternal).some(i => i.family === 'IPv' + family || i.family === family);
};
const resolve = (family, hostname, options, callback) => {
    options = options || {};
    if (!isFamilySupported(family, options.allowInternalNetworkInterfaces)) {
        callback(null, []);
        return null;
    }
    const dnsResolver = dns.Resolver ? new dns.Resolver(options) : dns;
    dnsResolver['resolve' + family](hostname, (err, addresses) => {
        if (err) {
            switch (err.code) {
                case dns.NODATA:
                case dns.NOTFOUND:
                case dns.NOTIMP:
                case dns.SERVFAIL:
                case dns.CONNREFUSED:
                case dns.REFUSED:
                case 'EAI_AGAIN':
                    return callback(null, []);
            }
            return callback(err);
        }
        return callback(null, Array.isArray(addresses) ? addresses : [].concat(addresses || []));
    });
    return dns.Resolver ? dnsResolver : null;
};
export const dnsCache = new Map();
const formatDNSValue = (value, extra) => {
    if (!value) {
        return Object.assign({}, extra || {});
    }
    const addresses = value.addresses || [];
    // Select a random address from available addresses, or null if none
    const host = addresses.length > 0 ? addresses[Math.floor(Math.random() * addresses.length)] : null;
    return Object.assign({
        host,
        // Include all addresses for connection fallback support
        _addresses: addresses
    }, extra || {});
};
export const resolveHostname = (options, callback) => {
    options = options || {};
    if (!options.host && options.servername) {
        options.host = options.servername;
    }
    if (!options.host || net.isIP(options.host)) {
        // nothing to do here
        const value = {
            addresses: [options.host]
        };
        return callback(null, formatDNSValue(value, {
            servername: options.servername || false,
            cached: false
        }));
    }
    const host = options.host;
    // The TLS server name belongs to the connection asking, not to the host it resolves. The
    // cache is shared by every transport of the process and keyed by host alone, so a server
    // name stored in it would be the one of whichever transport resolved the host first, and a
    // later transport with its own tls.servername would present and verify that name instead
    const servername = options.servername || host;
    let cached;
    if (dnsCache.has(options.host)) {
        cached = dnsCache.get(options.host);
        // Lazy cleanup with time throttling
        const now = Date.now();
        if (now - lastCacheCleanup > CACHE_CLEANUP_INTERVAL) {
            lastCacheCleanup = now;
            // Clean up expired entries
            for (const [host, entry] of dnsCache.entries()) {
                if (entry.expires && entry.expires < now) {
                    dnsCache.delete(host);
                }
            }
            // If cache is still too large, remove oldest entries
            if (dnsCache.size > MAX_CACHE_SIZE) {
                const toDelete = Math.floor(MAX_CACHE_SIZE * 0.1); // Remove 10% of entries
                const keys = Array.from(dnsCache.keys()).slice(0, toDelete);
                keys.forEach(key => dnsCache.delete(key));
            }
        }
        if (!cached.expires || cached.expires >= now) {
            return callback(null, formatDNSValue(cached.value, {
                servername,
                cached: true
            }));
        }
    }
    // The timeout limits the lookup as a whole. It is also handed to the resolver, but there
    // it applies to every query attempt on its own, and the resolver retries a few times
    let responded = false;
    let deadline;
    const respond = (err, result) => {
        if (responded) {
            return;
        }
        responded = true;
        clearTimeout(deadline);
        callback(err, result);
    };
    // a stale cached value is still better than no value at all
    const respondCached = (error) => {
        if (!cached) {
            return false;
        }
        dnsCache.set(host, {
            value: cached.value,
            expires: Date.now() + (options.dnsTtl || DNS_TTL)
        });
        respond(null, formatDNSValue(cached.value, {
            servername,
            cached: true,
            error
        }));
        return true;
    };
    const resolvers = [];
    const timeout = Number(options.timeout) || 0;
    if (timeout > 0) {
        deadline = setTimeout(() => {
            for (const resolver of resolvers) {
                if (typeof resolver.cancel === 'function') {
                    resolver.cancel();
                }
            }
            const err = new Error('DNS lookup for ' + host + ' timed out');
            err.code = dns.TIMEOUT;
            if (!respondCached(err)) {
                respond(err);
            }
        }, timeout);
    }
    // Resolve both IPv4 and IPv6 addresses for fallback support, at the same time
    let ipv4Addresses = [];
    let ipv6Addresses = [];
    let ipv4Error = null;
    let ipv6Error = null;
    let pending = 2;
    const onResolved = () => {
        if (--pending || responded) {
            return;
        }
        // Combine addresses: IPv4 first, then IPv6
        const allAddresses = ipv4Addresses.concat(ipv6Addresses);
        if (allAddresses.length) {
            const value = {
                addresses: allAddresses
            };
            dnsCache.set(host, {
                value,
                expires: Date.now() + (options.dnsTtl || DNS_TTL)
            });
            return respond(null, formatDNSValue(value, {
                servername,
                cached: false
            }));
        }
        // No addresses from resolve4/resolve6, try dns.lookup as fallback
        if (ipv4Error && ipv6Error && respondCached(ipv4Error)) {
            // Both resolvers had errors
            return;
        }
        try {
            dns.lookup(host, { all: true }, (err, addresses) => {
                if (err) {
                    if (respondCached(err)) {
                        return;
                    }
                    return respond(err);
                }
                // Get all supported addresses from dns.lookup
                const supportedAddresses = addresses
                    ? addresses.filter(addr => isFamilySupported(addr.family)).map(addr => addr.address)
                    : [];
                if (addresses && addresses.length && !supportedAddresses.length) {
                    // there are addresses but none can be used
                    console.warn(`Failed to resolve IPv${addresses[0].family} addresses with current network`);
                }
                if (!supportedAddresses.length && cached) {
                    // nothing was found, fallback to cached value
                    return respond(null, formatDNSValue(cached.value, {
                        servername,
                        cached: true
                    }));
                }
                const value = {
                    addresses: supportedAddresses.length ? supportedAddresses : [host]
                };
                dnsCache.set(host, {
                    value,
                    expires: Date.now() + (options.dnsTtl || DNS_TTL)
                });
                return respond(null, formatDNSValue(value, {
                    servername,
                    cached: false
                }));
            });
        }
        catch (lookupErr) {
            if (respondCached(lookupErr)) {
                return;
            }
            return respond(ipv4Error || ipv6Error || lookupErr);
        }
    };
    for (const family of [4, 6]) {
        const resolver = resolve(family, host, options, (err, addresses) => {
            if (family === 4) {
                ipv4Error = err;
                ipv4Addresses = addresses || [];
            }
            else {
                ipv6Error = err;
                ipv6Addresses = addresses || [];
            }
            onResolved();
        });
        if (resolver) {
            resolvers.push(resolver);
        }
    }
};
/**
 * Parses connection url to a structured configuration object
 *
 * @param str Connection url
 * @return Configuration object
 */
export const parseConnectionUrl = (str) => {
    str = str || '';
    const options = {};
    const url = urllib.parse(str, true);
    switch (url.protocol) {
        case 'smtp:':
            options.secure = false;
            break;
        case 'smtps:':
            options.secure = true;
            break;
        case 'direct:':
            options.direct = true;
            break;
    }
    if (!isNaN(url.port) && Number(url.port)) {
        options.port = Number(url.port);
    }
    if (url.hostname) {
        options.host = url.hostname;
    }
    if (url.username || url.password) {
        options.auth = {
            user: url.username || '',
            pass: url.password || ''
        };
    }
    Object.keys(url.query || {}).forEach(key => {
        let obj = options;
        let lKey = key;
        let value = url.query[key];
        if (!isNaN(value)) {
            value = Number(value);
        }
        switch (value) {
            case 'true':
                value = true;
                break;
            case 'false':
                value = false;
                break;
        }
        // tls is nested object
        if (key.indexOf('tls.') === 0) {
            lKey = key.substr(4);
            if (!options.tls) {
                options.tls = {};
            }
            obj = options.tls;
        }
        else if (key.indexOf('.') >= 0) {
            // ignore nested properties besides tls
            return;
        }
        // `in` already keeps "__proto__" out, but only as a side effect of it being an
        // Object.prototype member. Say it, so the protection survives a change to the check
        if (!isProtoKey(lKey) && !(lKey in obj)) {
            obj[lKey] = value;
        }
    });
    return options;
};
/** @internal */
export const _logFunc = (logger, level, defaults, data, message, ...args) => {
    const entry = Object.assign({}, defaults || {}, data || {});
    delete entry.level;
    let logLevel = level;
    if (typeof logger[logLevel] !== 'function') {
        // Provided logger does not implement this level. Fall back to a
        // lower-severity handler instead of throwing.
        logLevel = ['info', 'debug', 'log', 'trace', 'warn', 'error'].find(name => typeof logger[name] === 'function');
    }
    if (logLevel) {
        logger[logLevel](entry, message, ...args);
    }
};
/**
 * Returns a bunyan-compatible logger interface. Uses either provided logger or
 * creates a default console logger
 *
 * @param [options] Options object that might include 'logger' value
 * @param [defaults] Fields merged into every log entry, overridden by the fields of the entry itself
 * @return bunyan compatible logger
 */
export const getLogger = (options, defaults) => {
    options = options || {};
    const response = {};
    const levels = ['trace', 'debug', 'info', 'warn', 'error', 'fatal'];
    if (!options.logger) {
        // use vanity logger
        levels.forEach(level => {
            response[level] = () => false;
        });
        return response;
    }
    const logger = options.logger === true ? createDefaultLogger(levels) : options.logger;
    levels.forEach(level => {
        response[level] = (...args) => {
            // the bunyan forms: a data object first, or the message alone
            const data = typeof args[0] === 'string' ? undefined : args.shift();
            _logFunc(logger, level, defaults, data, ...args);
        };
    });
    return response;
};
/**
 * Wrapper for creating a callback that either resolves or rejects a promise
 * based on input
 *
 * @param resolve Function to run if callback is called
 * @param reject Function to run if callback ends with an error
 */
export const callbackPromise = (resolve, reject) => function (...args) {
    const err = args.shift();
    if (err) {
        reject(err);
    }
    else {
        resolve(...args);
    }
};
export const parseDataURI = (uri) => {
    if (typeof uri !== 'string') {
        return null;
    }
    // Early return for non-data URIs to avoid unnecessary processing
    if (!uri.startsWith('data:')) {
        return null;
    }
    // Find the first comma safely - this prevents ReDoS
    const commaPos = uri.indexOf(',');
    if (commaPos === -1) {
        return null;
    }
    const data = uri.substring(commaPos + 1);
    const metaStr = uri.substring('data:'.length, commaPos);
    let encoding;
    const metaEntries = metaStr.split(';');
    if (metaEntries.length > 0) {
        const lastEntry = metaEntries[metaEntries.length - 1].toLowerCase().trim();
        // Only recognize valid encoding types to prevent manipulation
        if (['base64', 'utf8', 'utf-8'].includes(lastEntry) && lastEntry.indexOf('=') === -1) {
            encoding = lastEntry;
            metaEntries.pop();
        }
    }
    const contentType = metaEntries.length > 0 ? metaEntries.shift() : 'application/octet-stream';
    const params = {};
    for (let i = 0; i < metaEntries.length; i++) {
        const entry = metaEntries[i];
        const sepPos = entry.indexOf('=');
        if (sepPos > 0) {
            // Ensure there's a key before the '='
            const key = entry.substring(0, sepPos).trim();
            const value = entry.substring(sepPos + 1).trim();
            if (key && !isProtoKey(key)) {
                params[key] = value;
            }
        }
    }
    // Decode data based on encoding with proper error handling
    let bufferData;
    try {
        if (encoding === 'base64') {
            bufferData = Buffer.from(data, 'base64');
        }
        else {
            try {
                bufferData = Buffer.from(decodeURIComponent(data));
            }
            catch (_decodeError) {
                bufferData = Buffer.from(data);
            }
        }
    }
    catch (_bufferError) {
        bufferData = Buffer.alloc(0);
    }
    return {
        data: bufferData,
        encoding: encoding || null,
        contentType: contentType || 'application/octet-stream',
        params
    };
};
export function resolveContent(data, key, options, callback) {
    // options is optional; support the legacy resolveContent(data, key, callback) signature
    if (!callback && typeof options === 'function') {
        callback = options;
        options = false;
    }
    options = options || {};
    let promise;
    if (!callback) {
        promise = new Promise((resolve, reject) => {
            callback = callbackPromise(resolve, reject);
        });
    }
    resolveContentValue(data, key, options, callback);
    return promise;
}
function resolveContentValue(data, key, options, callback) {
    let content = (data && data[key] && data[key].content) || data[key];
    const encoding = ((typeof data[key] === 'object' && data[key].encoding) || 'utf8')
        .toString()
        .toLowerCase()
        .replace(/[-_\s]/g, '');
    if (!content) {
        return callback(null, content);
    }
    if (typeof content === 'object') {
        if (typeof content.pipe === 'function') {
            return resolveStream(content, (err, value) => {
                if (err) {
                    return callback(err);
                }
                // we can't stream twice the same content, so we need
                // to replace the stream object with the streaming result
                if (data[key].content) {
                    data[key].content = value;
                }
                else {
                    data[key] = value;
                }
                callback(null, value);
            });
        }
        else if (/^data:/i.test(content.path || content.href)) {
            const parsedDataUri = parseDataURI(content.path || content.href);
            return callback(null, parsedDataUri && parsedDataUri.data ? parsedDataUri.data : Buffer.alloc(0));
        }
        else if (content.href || /^https?:\/\//i.test(content.path)) {
            // An href is always a URL, and so is a path that looks like one. Let nmfetch
            // decide whether it is fetchable, it validates the parsed URL. Testing the raw
            // string here instead would let a file: href fall through to the "return as is"
            // default below and travel on inside the resolved message.
            const url = content.href || content.path;
            if (options.disableUrlAccess) {
                setImmediate(() => {
                    const err = new Error('Url access rejected for ' + url);
                    err.code = errors.EURLACCESS;
                    callback(err);
                });
                return;
            }
            return resolveStream(nmfetch(url, { headers: content.httpHeaders, tls: content.tls }), callback);
        }
        else if (content.path) {
            if (options.disableFileAccess) {
                setImmediate(() => {
                    const err = new Error('File access rejected for ' + content.path);
                    err.code = errors.EFILEACCESS;
                    callback(err);
                });
                return;
            }
            return resolveStream(fs.createReadStream(content.path), callback);
        }
    }
    if (typeof data[key].content === 'string' && !['utf8', 'usascii', 'ascii'].includes(encoding)) {
        content = Buffer.from(data[key].content, encoding);
    }
    // default action, return as is
    setImmediate(() => callback(null, content));
}
/**
 * Copies properties from source objects to target objects
 */
export const assign = function (...args) {
    const target = args.shift() || {};
    args.forEach(source => {
        Object.keys(source || {}).forEach(key => {
            if (isProtoKey(key)) {
                return;
            }
            if (['tls', 'auth'].includes(key) &&
                source[key] &&
                typeof source[key] === 'object') {
                // tls and auth are special keys that need to be enumerated separately
                // other objects are passed as is. Enumerating is a copy of user supplied
                // keys just like the loop above, so it gets the same treatment
                target[key] = copyOwnKeys(target[key] || {}, source[key]);
            }
            else {
                target[key] = source[key];
            }
        });
    });
    return target;
};
export const encodeXText = (str) => {
    // ! 0x21
    // + 0x2B
    // = 0x3D
    // ~ 0x7E
    if (!/[^\x21-\x2A\x2C-\x3C\x3E-\x7E]/.test(str)) {
        return str;
    }
    const buf = Buffer.from(str);
    let result = '';
    for (let i = 0, len = buf.length; i < len; i++) {
        const c = buf[i];
        if (c < 0x21 || c > 0x7e || c === 0x2b || c === 0x3d) {
            result += '+' + (c < 0x10 ? '0' : '') + c.toString(16).toUpperCase();
        }
        else {
            result += String.fromCharCode(c);
        }
    }
    return result;
};
// The first error a stream emitted, see recordStreamErrors
const streamErrors = new WeakMap();
/**
 * Keeps the first error a content stream emits before it is read, so the error is reported
 * when the stream is read instead of being thrown as unhandled. The listener stays attached
 * for good, a stream that emits 'error' more than once never throws the later ones either
 *
 * @param stream Readable stream
 */
export function recordStreamErrors(stream) {
    stream.on('error', err => {
        if (!streamErrors.has(stream)) {
            streamErrors.set(stream, err);
        }
    });
}
/**
 * Destroys a value if it is a readable stream that was not destroyed yet
 *
 * @param value Any content value
 */
export function destroyStream(value) {
    const stream = value;
    if (stream && typeof stream.pipe === 'function' && typeof stream.destroy === 'function' && !stream.destroyed) {
        stream.destroy();
    }
}
/**
 * Tells why a stream can not be read from start to end anymore. A stream that ended or was
 * destroyed before anyone read it would never emit 'end' to a new reader, or, when piped, would
 * end the destination right away and turn into an empty value without any error
 *
 * @param stream Readable stream
 * @returns The error the stream failed with, an ESTREAM error, or null when it can be read
 */
export function unreadableStreamError(stream) {
    const err = streamErrors.get(stream) || stream.errored;
    if (err) {
        return err;
    }
    if (stream.readableEnded || stream.destroyed) {
        const unreadable = new Error('Content stream was already read or destroyed');
        unreadable.code = errors.ESTREAM;
        return unreadable;
    }
    return null;
}
/**
 * Streams a stream value into a Buffer
 *
 * @param stream Readable stream
 * @param callback Callback function with (err, value)
 */
export function resolveStream(stream, callback) {
    let responded = false;
    const respond = (err, value) => {
        if (responded) {
            return;
        }
        responded = true;
        callback(err, value);
    };
    const unreadable = unreadableStreamError(stream);
    if (unreadable) {
        // absorbs a later 'error' from the stream, there is nobody left to report it to
        stream.on('error', () => false);
        setImmediate(() => respond(unreadable));
        return;
    }
    const chunks = [];
    let chunklen = 0;
    stream.on('data', (chunk) => {
        if (typeof chunk === 'string') {
            chunk = Buffer.from(chunk);
        }
        chunks.push(chunk);
        chunklen += chunk.length;
    });
    // finished() also reports a stream that is destroyed before 'end', which would otherwise
    // leave the callback waiting forever
    finished(stream, { writable: false }, err => {
        if (err) {
            return respond(err);
        }
        let value;
        try {
            value = Buffer.concat(chunks, chunklen);
        }
        catch (E) {
            return respond(E);
        }
        respond(null, value);
    });
}
/**
 * Generates a bunyan-like logger that prints to console
 *
 * @returns Bunyan logger instance
 */
function createDefaultLogger(levels) {
    const levelMaxLen = levels.reduce((max, level) => Math.max(max, level.length), 0);
    const levelNames = new Map();
    levels.forEach(level => {
        let levelName = level.toUpperCase();
        if (levelName.length < levelMaxLen) {
            levelName += ' '.repeat(levelMaxLen - levelName.length);
        }
        levelNames.set(level, levelName);
    });
    const print = (level, entry, message, ...args) => {
        let prefix = '';
        if (entry) {
            if (entry.tnx === 'server') {
                prefix = 'S: ';
            }
            else if (entry.tnx === 'client') {
                prefix = 'C: ';
            }
            if (entry.sid) {
                prefix = '[' + entry.sid + '] ' + prefix;
            }
            if (entry.cid) {
                prefix = '[#' + entry.cid + '] ' + prefix;
            }
        }
        message = util.format(message, ...args);
        message.split(/\r?\n/).forEach((line) => {
            console.log('[%s] %s %s', new Date().toISOString().substr(0, 19).replace(/T/, ' '), levelNames.get(level), prefix + line);
        });
    };
    const logger = {};
    levels.forEach(level => {
        logger[level] = print.bind(null, level);
    });
    return logger;
}
