import { VoiceButton } from './voice-controls';
import { voiceStore, textareaVoiceTarget } from '@renderer/core/voice-store';
// Composer layout follows Yoda (Apache-2.0) src/renderer/features/tasks/home-composer.
import { ArrowUp, CircleAlert, ClipboardCheck, Compass, Folder, FolderTree, Hammer, Info, Loader2, Monitor, Plus, Settings, Square, Wrench } from 'lucide-react';
import { observer } from 'mobx-react-lite';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { rpcErrorMessage } from '@shared/ipc/rpc';
import { navigation } from '@renderer/core/navigation';
import { tasksStore } from '@renderer/core/tasks-store';
import { useAgents } from '@renderer/lib/hooks/useAgents';
import { homeAgents, homeAgentId, HomeAgentPicker, HomePermissionPicker } from '@renderer/features/agents/home-agent-controls';
import { agentPermission } from '@shared/agent-permissions';
import { useAppSettingsKey } from '@renderer/lib/hooks/useAppSettingsKey';
import { useProject, useProjectList } from '@renderer/lib/hooks/useProjects';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@renderer/lib/ui/select';
import { Button } from '@renderer/lib/ui/button';
import { Dialog, DialogContent, DialogContentArea, DialogFooter, DialogHeader, DialogTitle } from '@renderer/lib/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@renderer/lib/ui/menu';
import { Field } from './projects/form-parts';
import { ProjectDialog } from './projects/project-dialogs';
import { cn } from '@renderer/utils/utils';
import { CapabilityLaunchPreview } from './capabilities';
import appIcon from '../../assets/branding/app-icon.png';

const CHIP = 'm6-composer-select';

export const HomeView = observer(function HomeView() {
  const { t } = useTranslation();
  const { data: projects } = useProjectList(false);
  const { data: agents } = useAgents();
  const profiles = agents ? homeAgents(agents.configs) : undefined;
  const permissions = useAppSettingsKey('agentPermissions');
  const draft = useAppSettingsKey('homeDraft');
  const [launchSettings, setLaunchSettings] = useState(false);
  const [creatingProject, setCreatingProject] = useState(false);
  const [projectId, setProjectId] = useState<string | null>(null);
  const message = navigation.homeInput(projectId);
  const setMessage = (value: string) => navigation.setHomeInput(projectId, value);
  const [dirId, setDirId] = useState<string | null>(null);
  const [profileId, setProfileId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [launching, setLaunching] = useState(false);
  const [canceling, setCanceling] = useState(false);
  const launchToken = useRef<string | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const { data: project } = useProject(projectId);
  useLayoutEffect(()=>{
    const el=inputRef.current;if(!el)return;
    el.style.height='0px';const full=el.scrollHeight;
    el.style.height=Math.max(42,Math.min(full,220))+'px';el.style.overflowY=full>220?'auto':'hidden';
  },[message]);


  // Project defaults to the last choice if it still exists (PRD F05).
  const initialized = useRef(false);
  useEffect(() => {
    if (initialized.current || !projects || !profiles || !draft.value) return;
    initialized.current = true;
    const d = draft.value;
    const initialProjectId=navigation.homePreset&&projects.some(p=>p.id===navigation.homePreset?.projectId)?navigation.homePreset.projectId:d.projectId&&projects.some(p=>p.id===d.projectId)?d.projectId:projects.length===1?projects[0].id:null;
    const request=navigation.pluginPromptRequest;
    if(request){const prompt=navigation.consumePluginPrompt(request.seq);if(prompt){const existing=navigation.homeInput(initialProjectId);navigation.setHomeInput(initialProjectId,existing?existing+'\n'+prompt:prompt);}}
    if (navigation.homePreset && projects.some((p) => p.id === navigation.homePreset?.projectId)) {
      setProjectId(navigation.homePreset.projectId);
    } else if (d.projectId && projects.some((p) => p.id === d.projectId)) {
      setProjectId(d.projectId);
      setDirId(d.dirId);
    } else if (projects.length === 1) setProjectId(projects[0].id);
  }, [projects, profiles, draft.value]);

  const pluginPrompt=navigation.pluginPromptRequest;
  useEffect(()=>{if(!initialized.current||!pluginPrompt)return;const prompt=navigation.consumePluginPrompt(pluginPrompt.seq);if(prompt){const existing=navigation.homeInput(projectId);navigation.setHomeInput(projectId,existing?existing+'\n'+prompt:prompt);inputRef.current?.focus();}},[pluginPrompt?.seq,projectId,projects,profiles,draft.value]);

  // The list is the same service-ordered projection as Settings. Hidden/logout/missing tools cannot stay selected.
  const profileChosen = useRef(false);
  useEffect(() => {
    if (!agents || !draft.value) return;
    const visible = homeAgents(agents.configs);
    if (profileChosen.current && visible.some(p => p.id === profileId)) return;
    setProfileId(homeAgentId(visible, draft.value.aiProfileId));
  }, [agents, draft.value, profileId]);

  // "New task" under a project selects it.
  const preset = navigation.homePreset;
  const appliedPreset = useRef<number | null>(null);
  useEffect(() => {
    if (!preset || appliedPreset.current === preset.seq || !projects?.some((p) => p.id === preset.projectId)) return;
    appliedPreset.current = preset.seq;
    const applicationPrompt=navigation.consumeApplicationPrompt(preset.seq);
    if(applicationPrompt){const existing=navigation.homeInput(preset.projectId);navigation.setHomeInput(preset.projectId,existing?existing+'\n'+applicationPrompt:applicationPrompt);}
    setProjectId(preset.projectId);
    setDirId(null);
    inputRef.current?.focus();
  }, [preset?.seq, projects]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (navigation.currentViewId === 'home') inputRef.current?.focus();
  }, [navigation.currentViewId]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (initialized.current) navigation.selectHomeProject(projectId);
  }, [projectId]);

  // A stale or missing directory falls back to the project's default one.
  const dirs = project?.id === projectId ? (project?.dirs ?? []) : [];
  const dir = dirs.find((d) => d.id === dirId) ?? dirs.find((d) => d.isDefault) ?? dirs[0] ?? null;
  const profile = profiles?.find((p) => p.id === profileId) ?? null;
  const selectedProvider=agents?.providers.find(p=>p.id===profile?.providerId);
  const missingProviderKey=profile?.source==='provider'&&selectedProvider&&!selectedProvider.hasKey;
  const dirProblem = project && project.id === projectId && (!dir ? t('home.noDir') : !dir.status.available ? t('home.dirUnavailable', { path: dir.path }) : '');
  const ready = Boolean(projectId && profile && dir && dir.status.available && permissions.value) && !launching;

  const launch = async () => {
    if (!ready || !projectId || !profile || !dir) return;
    setError('');
    const token=crypto.randomUUID();launchToken.current=token;
    setLaunching(true);
    try {
      await tasksStore.create({ projectId, dirId: dir.id, aiProfileId: profile.id, firstMessage: message, launchToken:token, permission:agentPermission(profile.kind==='codex'?'codex':'claude',permissions.value?.selected??'ask').id });
      draft.update({ projectId, dirId: dir.id, aiProfileId: profile.id });
      setMessage('');
    } catch (e) {
      setError(rpcErrorMessage(e));
    } finally {
      launchToken.current=null;setCanceling(false);setLaunching(false);
    }
  };

  const cancelPreparation = async () => {
    const token=launchToken.current;if(!token||canceling)return;
    setCanceling(true);
    try { await tasksStore.cancelCreate(token); }
    catch(e) { setError(rpcErrorMessage(e));setCanceling(false); }
  };

  const suggestions = [
    { Icon: Compass, key: 'explore' },
    { Icon: Hammer, key: 'build' },
    { Icon: ClipboardCheck, key: 'review' },
    { Icon: Wrench, key: 'fix' },
  ] as const;

  const projectPicker = <Select value={projectId} onValueChange={(v) => { if(!projectId&&v&&message){const existing=navigation.homeInput(String(v));navigation.setHomeInput(String(v),existing?existing+'\n'+message:message);navigation.setHomeInput(null,'');}setProjectId(v as string | null); setDirId(null); if (v) navigation.newTask(String(v)); }}>
    <SelectTrigger className={CHIP} data-testid="home-project" aria-label={t('home.pickProject')}><Folder size={15} /><SelectValue placeholder={t('home.pickProject')} /></SelectTrigger>
    <SelectContent>{(projects ?? []).map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
  </Select>;
  const profilePicker = <HomeAgentPicker configs={profiles??[]} providers={agents?.providers??[]} value={profileId} onChange={id=>{profileChosen.current=true;setProfileId(id);}} />;
  const directoryPicker = <Select value={dir?.id ?? null} onValueChange={(v) => setDirId(v as string | null)}>
    <SelectTrigger className={CHIP} data-testid="home-dir" aria-label={t('m6.directory')} title={dir?.path}><FolderTree size={15} /><SelectValue placeholder={t('home.noDir')} /></SelectTrigger>
    <SelectContent>{dirs.map((d) => <SelectItem key={d.id} value={d.id}>{d.label || d.path}</SelectItem>)}</SelectContent>
  </Select>;

  return <section className="reference-home m13-shell" aria-label={t('nav.newTask')}>
    <div className="reference-welcome"><img src={appIcon} alt="WillYou" draggable={false} /><h1>{t('m6.welcomePrefix')} <button onClick={() => setLaunchSettings(true)}>{project?.name || 'WillYou'}</button> {t('m6.welcomeSuffix')}</h1></div>
    <div className="reference-composer-wrap">
      {(dirProblem || error || !projectId || !profile) && <div className="launch-hint" role="status"><span>{error || dirProblem || (!projectId ? t(projects?.length ? 'home.pickProject' : 'home.noProjects') : t(profiles?.length ? 'home.pickProfile' : 'home.noProfiles'))}</span>{error&&missingProviderKey?<button onClick={()=>navigation.openAgentProvider(selectedProvider.id)}>去填写 Key</button>:<button onClick={() => setLaunchSettings(true)}>{t('m6.taskSettings')}</button>}</div>}
      {error && <span data-testid="home-error" className="sr-only">{error}</span>}
      <div className="reference-composer-context"><div className="reference-home-picker">{projectPicker}</div>
        <button className="local-environment" data-testid="home-cwd" title={dir?.path} onClick={() => setLaunchSettings(true)}><Monitor size={16} /><span>{dirs.length > 1 ? dir?.label || t('m6.directory') : t('m6.thisComputer')}</span></button>
        <button data-testid="home-task-settings" className="composer-settings" title={t('m6.taskSettings')} aria-label={t('m6.taskSettings')} onClick={() => setLaunchSettings(true)}><Settings size={16} /></button>
      </div>
      <form className="reference-composer" onSubmit={(e) => { e.preventDefault(); void launch(); }}>
        <textarea ref={inputRef} data-testid="home-input" aria-label={t('m6.taskDescription')} value={message} placeholder={t('m6.promptPlaceholder')} onChange={(e) => setMessage(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) { e.preventDefault(); void launch(); } }} />
        <div className="reference-composer-toolbar">
          <DropdownMenu><DropdownMenuTrigger className="row-action" aria-label={t('m6.addContext')}><Plus size={20} /></DropdownMenuTrigger><DropdownMenuContent side="top" align="start">
            <DropdownMenuItem onClick={() => setCreatingProject(true)}><Plus />{t('projects.new')}</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLaunchSettings(true)}><Folder />{t('home.pickProject')}</DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigation.openSettings('aiProfiles')}><Settings />{t('settings.sections.aiProfiles')}</DropdownMenuItem><DropdownMenuSeparator />
            {suggestions.map(({ Icon, key }) => <DropdownMenuItem key={key} data-testid="home-suggestion" onClick={() => { setMessage(t(`home.suggestions.${key}.prompt`)); inputRef.current?.focus(); }}><Icon />{t(`home.suggestions.${key}.title`)}</DropdownMenuItem>)}
          </DropdownMenuContent></DropdownMenu>
          <HomePermissionPicker kind={profile?.kind??'claude'} disabled={!profile||launching} />
          <div className="reference-home-picker composer-profile">{profilePicker}</div>
          <VoiceButton compact disabled={launching} onClick={() => void voiceStore.trigger(textareaVoiceTarget(inputRef.current), 'home')} />
          <button type={launching ? "button" : "submit"} data-testid="home-launch" className="reference-send" disabled={launching ? canceling : !ready} onClick={launching ? () => void cancelPreparation() : undefined} aria-label={t(launching ? "home.cancelPreparation" : "home.launchHint")} title={t(launching ? "home.cancelPreparation" : "home.launchHint")}>{canceling ? <Loader2 size={19} className="animate-spin" /> : launching ? <Square size={17} fill="currentColor" /> : <ArrowUp size={19} />}</button>
        </div>
      </form>
    </div>
    <Dialog open={launchSettings} onOpenChange={setLaunchSettings}><DialogContent className="m6-launch-dialog"><DialogHeader><DialogTitle>{t('m6.taskSettings')}</DialogTitle></DialogHeader><DialogContentArea>
      <Field label={t('home.pickProject')}><div className="flex items-center justify-between gap-3">{projectPicker}<Button variant="outline" size="sm" onClick={() => { setLaunchSettings(false); setCreatingProject(true); }}>{t('projects.new')}</Button></div></Field>
      <Field label={t('m6.directory')}>{directoryPicker}<span className="font-mono text-xs break-all text-foreground-muted">{dir?.path}</span></Field>
      <Field label={t('home.pickProfile')}>{profilePicker}</Field>
      {projectId && profileId && dir && <CapabilityLaunchPreview projectId={projectId} aiProfileId={profileId} cwd={dir.path} />}
      {dirProblem && <Hint tone="error" text={dirProblem} />}
      <div className="flex flex-wrap gap-2"><Button variant="outline" size="sm" disabled={!projectId} onClick={() => projectId && navigation.openProject(projectId)}>{t('m6.projectResources')}</Button><Button variant="outline" size="sm" onClick={() => navigation.openSettings('aiProfiles')}>{t('settings.sections.aiProfiles')}</Button></div>
    </DialogContentArea><DialogFooter><Button data-testid="home-settings-done" onClick={() => setLaunchSettings(false)}>{t('m6.done')}</Button></DialogFooter></DialogContent></Dialog>
    {creatingProject && <ProjectDialog open onOpenChange={setCreatingProject} />}
  </section>;
});

function Hint({
  text,
  action,
  onClick,
  tone = 'info',
  testId,
}: {
  text: string;
  action?: string;
  onClick?: () => void;
  tone?: 'info' | 'error';
  testId?: string;
}) {
  const Icon = tone === 'error' ? CircleAlert : Info;
  return (
    <div
      data-testid={testId}
      className={cn(
        'flex items-start gap-2 rounded-lg border px-3 py-2 text-sm',
        tone === 'error'
          ? 'border-foreground-destructive/30 bg-foreground-destructive/5 text-foreground-destructive'
          : 'border-border bg-background-1 text-foreground-muted'
      )}
    >
      <Icon className="mt-0.5 size-4 shrink-0" />
      <p className="min-w-0 flex-1 whitespace-pre-wrap select-text">{text}</p>
      {action && (
        <button type="button" onClick={onClick} className="shrink-0 font-medium text-foreground underline underline-offset-2">
          {action}
        </button>
      )}
    </div>
  );
}
