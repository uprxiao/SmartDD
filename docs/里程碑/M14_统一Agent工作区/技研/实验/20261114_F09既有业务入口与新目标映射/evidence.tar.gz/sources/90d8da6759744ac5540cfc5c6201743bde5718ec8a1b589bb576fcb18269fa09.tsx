import { AgentTaskInfo } from '@renderer/features/agents/task-agent';
import { runnerDescription } from '@shared/ai-profiles';
import {SessionApplicationsPanel} from '@renderer/features/applications/session-applications';
import {openNewBrowserTab} from '@renderer/features/browser/store';
// Task details and runtime bar adapted from Yoda (Apache-2.0).
// The single window title follows the approved Codex reference; the sidebar switches sessions.
import { Ellipsis, Folder, FolderOpen, Moon, Play, SlidersHorizontal, Square, SquarePlus, Sun, TriangleAlert, X } from 'lucide-react';
import { observer } from 'mobx-react-lite';
import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { observeTaskHeaderLayout, type TaskHeaderLayout } from '@shared/task-header-layout.mjs';
import { useTranslation } from 'react-i18next';
import { toast } from 'sonner';
import { rpcErrorMessage } from '@shared/ipc/rpc';
import type { TaskView as Task } from '@shared/tasks';
import type { Runner } from '@shared/types';
import claudeLogo from '@renderer/assets/runners/claude.png';
// Keep a file URL: the packaged renderer CSP intentionally excludes data: images.
import openaiLogo from '@renderer/assets/runners/openai.svg?no-inline';
import { navigation } from '@renderer/core/navigation';
import { tasksStore } from '@renderer/core/tasks-store';
import { useAiProfiles } from '@renderer/lib/hooks/useAiProfiles';
import { useProject } from '@renderer/lib/hooks/useProjects';
import { HealthDot, ProfileHealthMark } from '@renderer/lib/profile-health';
import { rpc } from '@renderer/lib/ipc';
import { Button } from '@renderer/lib/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@renderer/lib/ui/popover';
import { cn } from '@renderer/utils/utils';
import { useTheme } from '@renderer/lib/theme';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@renderer/lib/ui/menu';
import { RuntimeCapabilities } from './capabilities';
import { useTaskClose } from './task-close';

const RUNNER_LOGOS: Record<Runner, string> = { claude: claudeLogo, codex: openaiLogo };

/** The CLI exited but its terminal is still on screen: resume or switch from here. */
const canRestartInPlace = (task: Task) => task.archivedAt === null && !task.ptyId && tasksStore.terminals.has(task.id) && task.recovery !== 'unrecoverable';

/** Window-level title: changing the selected sidebar task never unmounts its terminal. */
export const TaskHeader = observer(function TaskHeader({ task }: { task: Task }) {
  const { t } = useTranslation();
  const { effectiveTheme, setTheme } = useTheme();
  const [busy, setBusy] = useState(false);
  const [sessionApps,setSessionApps]=useState(false);
  const headerRef = useRef<HTMLElement>(null);
  const [headerLayout, setHeaderLayout] = useState<TaskHeaderLayout>('default');
  useLayoutEffect(() => observeTaskHeaderLayout(headerRef.current, setHeaderLayout), [task.id]);
  const { requestClose, closeDialog, busy: closing } = useTaskClose(task);
  const dark = effectiveTheme === 'ydark';
  const running = Boolean(task.ptyId);
  const restart = canRestartInPlace(task) && Boolean(task.aiProfileId);
  const changeSession = async () => {
    setBusy(true);
    try {
      if (running) await rpc.tasks.kill(task.id);
      else await tasksStore.resume({ taskId: task.id });
    } catch (e) { toast.error(rpcErrorMessage(e)); }
    finally { setBusy(false); }
  };
  return <><header ref={headerRef} className="task-window-header app-drag" data-header-layout={headerLayout} data-testid="task-header">
    <div className="task-window-title" title={`${task.projectName ?? t('task.noProject')} / ${task.title}`}>
      <Folder size={17} aria-hidden="true" /><span>{task.title}</span>
    </div>
    <div className="task-window-actions app-no-drag">
      {task.projectId&&<button type="button" className="m9-file-entry" data-testid="task-new-browser" title="新建标签页（⇧⌘B）" onClick={()=>openNewBrowserTab(task.id)}><SquarePlus size={16}/><span className="task-entry-label">新建标签页</span></button>}
      <button type="button" className="m9-file-entry" data-testid="task-applications" aria-label="会话插件" onClick={()=>setSessionApps(true)}><SlidersHorizontal size={16}/><span className="task-entry-label">插件</span></button>
      <button type="button" className="m9-file-entry" data-testid="task-files" aria-pressed={navigation.filePanelOpen} onClick={() => navigation.toggleFilePanel()}><FolderOpen size={16} /><span className="task-entry-label">文件</span></button>
      <DropdownMenu>
        <DropdownMenuTrigger className="icon-button" data-testid="task-actions" aria-label={t('m6.more')} title={t('m6.more')}><Ellipsis size={18} /></DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {(running || restart) && <>
            <DropdownMenuItem data-testid={running ? 'task-kill' : 'task-header-resume'} disabled={busy || closing || tasksStore.resuming.has(task.id) || tasksStore.closing.has(task.id)} onClick={() => void changeSession()}>
              {running ? <Square /> : <Play />}{running ? t('task.kill') : task.recovery === 'resumable' ? t('task.resume') : t('task.start')}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
          </>}
          <DropdownMenuItem data-testid="task-close-session" disabled={busy || closing || tasksStore.closing.has(task.id)} onClick={requestClose}>
            <X />{t('tasks.closeSession')}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setTheme(dark ? 'ylight' : 'ydark')}>
            {dark ? <Sun /> : <Moon />}{t('settings.theme')}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      {task.agentSnapshot ? <AgentTaskInfo task={task} /> : <TaskInfo task={task} />}
      <span className="task-window-divider" />
      <button type="button" className="icon-button" title={t('nav.newTask')} aria-label={t('nav.newTask')} onClick={() => navigation.newTask(task.projectId ?? undefined)}><SquarePlus size={17} /></button>
    </div>
  </header>{closeDialog}{sessionApps&&<SessionApplicationsPanel key={task.id} taskId={task.id} projectName={task.projectName} runIdentity={(task.ptyId??'stopped')+':'+(task.runtimeSnapshot?.runId??'unrecorded')} onClose={()=>setSessionApps(false)}/>}</>;
});

function InfoRow({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex min-w-0 gap-3">
      <span className="w-16 shrink-0 text-foreground-passive">{label}</span>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}

const TaskInfo = observer(function TaskInfo({ task }: { task: Task }) {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);
  const { data: profiles = [] } = useAiProfiles();
  const { data: project } = useProject(task.projectId);
  const profile = profiles.find((p) => p.id === task.aiProfileId);
  // A present-day profile is not evidence of a pre-M13 task's historical model.
  const model = task.agentSnapshot?.model ?? null;
  const running = Boolean(task.ptyId);
  // Project writes refresh this query independently of the task-list cache.
  // Config revisions only increase; an older query cache must not suppress a
  // change already observed in the task metadata while its refetch completes.
  const projectVersion = project?.configVersion === undefined ? task.projectConfigVersion
    : task.projectConfigVersion === null ? project.configVersion : Math.max(project.configVersion, task.projectConfigVersion);
  const changed = task.configVersion !== null && projectVersion !== null && task.configVersion !== projectVersion;
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        data-testid="task-info"
        title={t('task.info')}
        aria-label={t('task.info')}
        className="icon-button data-popup-open:bg-background-2"
      >
        <SlidersHorizontal size={18} />
      </PopoverTrigger>
      <PopoverContent align="end" data-testid="task-info-popup" className="max-h-[75vh] w-96 gap-2.5 overflow-y-auto text-xs">
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate text-sm font-medium" title={task.title}>
            {task.title}
          </span>
          <span className={cn('ml-auto shrink-0 rounded px-1.5 py-0.5', running ? 'bg-green-500/15 text-foreground' : 'bg-background-2 text-foreground-muted')}>
            {running ? t('task.running') : t(`task.recovery.${task.recovery}`)}
          </span>
        </div>
        <InfoRow label={t('task.fields.project')}>{task.projectName ?? t('task.noProject')}</InfoRow>
        <InfoRow label={t('task.fields.profile')}>
          <span className="flex items-center gap-1.5">
            <span className="inline-block size-2 shrink-0 rounded-full" style={{ background: task.aiProfileColor ?? 'var(--color-foreground-passive)' }} />
            <span className="truncate">{task.agentSnapshot?.name ?? task.aiProfileName ?? '—'}</span>
            {profile && <ProfileHealthMark profile={profile} withLabel />}
            {task.aiProfileId === null && task.aiProfileName && <span className="text-foreground-passive">（{t('task.profileDeleted')}）</span>}
          </span>
        </InfoRow>
        <InfoRow label={t('task.fields.model')}>
          <span className="font-mono">{model ?? t('task.modelDefault')}</span>
        </InfoRow>
        <InfoRow label={t('task.fields.cwd')}>
          <span className="block font-mono break-all select-text">{task.cwd}</span>
        </InfoRow>
        {task.runtimeSnapshot && <InfoRow label={t('capabilities.label')}><RuntimeCapabilities snapshot={task.runtimeSnapshot} /></InfoRow>}
        {changed && (
          <div className="flex items-start gap-1 text-foreground-muted">
            <TriangleAlert className="mt-0.5 size-3.5 shrink-0" />
            {t('task.configChanged', { from: task.configVersion, to: projectVersion })}
          </div>
        )}
        {canRestartInPlace(task) && (
          <Button
            variant="outline"
            size="sm"
            className="self-start"
            data-testid="task-header-switch"
            onClick={() => {
              setOpen(false);
              tasksStore.dropTerminal(task.id);
            }}
          >
            {t('task.switchProfile')}
          </Button>
        )}
      </PopoverContent>
    </Popover>
  );
});

/** Bottom strip of the task page: runner · profile · model, and how many tasks are running. */
export const RuntimeBar = observer(function RuntimeBar({ task }: { task: Task }) {
  const { t } = useTranslation();
  const { data: profiles = [] } = useAiProfiles();
  const profile = profiles.find((p) => p.id === task.aiProfileId);
  const model = task.agentSnapshot?.model ?? null;
  const runningCount = tasksStore.tasks.filter((x) => x.ptyId).length;
  return (
    <div
      data-testid="runtime-bar"
      className="@container flex h-8 min-w-0 shrink-0 items-center gap-1.5 overflow-hidden border-t border-border bg-background-secondary px-2.5 text-[11px] whitespace-nowrap text-foreground-muted"
    >
      <img src={RUNNER_LOGOS[task.runner]} alt="" className="size-4 shrink-0 object-contain" />
      <span className="truncate font-medium text-foreground @max-[720px]:hidden">{runnerDescription(task.runner).label}</span>
      <span className="text-foreground-passive @max-[720px]:hidden">·</span>
      <span data-testid="runtime-profile" className="flex min-w-0 items-center gap-1">
        <span className="inline-block size-2 shrink-0 rounded-full" style={{ background: task.aiProfileColor ?? 'var(--color-foreground-passive)' }} />
        <span className="truncate">{task.agentSnapshot?.name ?? task.aiProfileName ?? '—'}</span>
        {profile && <HealthDot profile={profile} className="size-1.5" />}
      </span>
      {model && (
        <>
          <span className="text-foreground-passive">·</span>
          <span data-testid="runtime-model" className="max-w-52 truncate font-mono text-[10px] text-foreground">
            {model}
          </span>
        </>
      )}
      <span data-testid="runtime-running" className="ml-auto flex shrink-0 items-center gap-1.5">
        <span className={cn('size-2 rounded-full border', runningCount > 0 ? 'border-green-500 bg-green-200' : 'border-foreground-passive bg-background-secondary')} />
        {t('runtime.running', { count: runningCount })}
      </span>
    </div>
  );
});
