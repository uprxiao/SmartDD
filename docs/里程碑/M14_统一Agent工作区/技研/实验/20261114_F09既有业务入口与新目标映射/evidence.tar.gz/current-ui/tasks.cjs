var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/mobx.cjs.production.min.js
var require_mobx_cjs_production_min = __commonJS({
  "../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/mobx.cjs.production.min.js"(exports2) {
    function t(t2) {
      for (var n2 = arguments.length, i2 = new Array(n2 > 1 ? n2 - 1 : 0), r2 = 1; r2 < n2; r2++) i2[r2 - 1] = arguments[r2];
      throw new Error("number" == typeof t2 ? "[MobX] minified error nr: " + t2 + (i2.length ? " " + i2.map(String).join(",") : "") + ". Find the full error at: https://github.com/mobxjs/mobx/blob/main/packages/mobx/src/errors.ts" : "[MobX] " + t2);
    }
    function n() {
      return "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : In;
    }
    function i() {
      qn || t("Proxy not available");
    }
    function r(t2) {
      var n2 = false;
      return function() {
        if (!n2) return n2 = true, t2.apply(this, arguments);
      };
    }
    function e(t2) {
      return "function" == typeof t2;
    }
    function u(t2) {
      switch (typeof t2) {
        case "string":
        case "symbol":
        case "number":
          return true;
      }
      return false;
    }
    function o(t2) {
      return null !== t2 && "object" == typeof t2;
    }
    function s(t2) {
      if (!o(t2)) return false;
      var n2 = Object.getPrototypeOf(t2);
      if (null == n2) return true;
      var i2 = Object.hasOwnProperty.call(n2, "constructor") && n2.constructor;
      return "function" == typeof i2 && i2.toString() === Gn;
    }
    function f(t2) {
      var n2 = null == t2 ? void 0 : t2.constructor;
      return !!n2 && ("GeneratorFunction" === n2.name || "GeneratorFunction" === n2.displayName);
    }
    function c(t2, n2, i2) {
      Kn(t2, n2, { enumerable: false, writable: true, configurable: true, value: i2 });
    }
    function a(t2, n2, i2) {
      Kn(t2, n2, { enumerable: false, writable: false, configurable: true, value: i2 });
    }
    function h(t2, n2) {
      var i2 = "isMobX" + t2;
      return n2.prototype[i2] = true, function(t3) {
        return o(t3) && true === t3[i2];
      };
    }
    function l(t2) {
      return null != t2 && "[object Map]" === Object.prototype.toString.call(t2);
    }
    function v(t2) {
      return null != t2 && "[object Set]" === Object.prototype.toString.call(t2);
    }
    function d(t2) {
      return null === t2 ? null : "object" == typeof t2 ? "" + t2 : t2;
    }
    function b(t2, n2) {
      return Bn.hasOwnProperty.call(t2, n2);
    }
    function p(t2, n2) {
      return !!(t2 & n2);
    }
    function y(t2, n2, i2) {
      return i2 ? t2 |= n2 : t2 &= ~n2, t2;
    }
    function m(t2, n2) {
      (null == n2 || n2 > t2.length) && (n2 = t2.length);
      for (var i2 = 0, r2 = Array(n2); i2 < n2; i2++) r2[i2] = t2[i2];
      return r2;
    }
    function w(t2, n2, i2) {
      if (A()) return Reflect.construct.apply(null, arguments);
      var r2 = [null];
      r2.push.apply(r2, n2);
      var e2 = new (t2.bind.apply(t2, r2))();
      return i2 && M(e2, i2.prototype), e2;
    }
    function j(t2, n2) {
      for (var i2 = 0; i2 < n2.length; i2++) {
        var r2 = n2[i2];
        r2.enumerable = r2.enumerable || false, r2.configurable = true, "value" in r2 && (r2.writable = true), Object.defineProperty(t2, k(r2.key), r2);
      }
    }
    function O(t2, n2, i2) {
      return n2 && j(t2.prototype, n2), i2 && j(t2, i2), Object.defineProperty(t2, "prototype", { writable: false }), t2;
    }
    function x(t2, n2) {
      var i2 = "undefined" != typeof Symbol && t2[Symbol.iterator] || t2["@@iterator"];
      if (i2) return (i2 = i2.call(t2)).next.bind(i2);
      if (Array.isArray(t2) || (i2 = (function(t3, n3) {
        if (t3) {
          if ("string" == typeof t3) return m(t3, n3);
          var i3 = {}.toString.call(t3).slice(8, -1);
          return "Object" === i3 && t3.constructor && (i3 = t3.constructor.name), "Map" === i3 || "Set" === i3 ? Array.from(t3) : "Arguments" === i3 || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i3) ? m(t3, n3) : void 0;
        }
      })(t2)) || n2 && t2 && "number" == typeof t2.length) {
        i2 && (t2 = i2);
        var r2 = 0;
        return function() {
          return r2 >= t2.length ? { done: true } : { done: false, value: t2[r2++] };
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function g() {
      return (g = Object.assign ? Object.assign.bind() : function(t2) {
        for (var n2 = 1; n2 < arguments.length; n2++) {
          var i2 = arguments[n2];
          for (var r2 in i2) ({}).hasOwnProperty.call(i2, r2) && (t2[r2] = i2[r2]);
        }
        return t2;
      }).apply(null, arguments);
    }
    function S(t2) {
      return (S = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t3) {
        return t3.__proto__ || Object.getPrototypeOf(t3);
      })(t2);
    }
    function _(t2, n2) {
      t2.prototype = Object.create(n2.prototype), t2.prototype.constructor = t2, M(t2, n2);
    }
    function A() {
      try {
        var t2 = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {
        })));
      } catch (t3) {
      }
      return (A = function() {
        return !!t2;
      })();
    }
    function M(t2, n2) {
      return (M = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t3, n3) {
        return t3.__proto__ = n3, t3;
      })(t2, n2);
    }
    function k(t2) {
      var n2 = (function(t3) {
        if ("object" != typeof t3 || !t3) return t3;
        var n3 = t3[Symbol.toPrimitive];
        if (void 0 !== n3) {
          var i2 = n3.call(t3, "string");
          if ("object" != typeof i2) return i2;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return String(t3);
      })(t2);
      return "symbol" == typeof n2 ? n2 : n2 + "";
    }
    function E(t2) {
      var n2 = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
      return (E = function(t3) {
        function i2() {
          return w(t3, arguments, S(this).constructor);
        }
        if (null === t3 || !(function(t4) {
          try {
            return -1 !== Function.toString.call(t4).indexOf("[native code]");
          } catch (n3) {
            return "function" == typeof t4;
          }
        })(t3)) return t3;
        if ("function" != typeof t3) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== n2) {
          if (n2.has(t3)) return n2.get(t3);
          n2.set(t3, i2);
        }
        return i2.prototype = Object.create(t3.prototype, { constructor: { value: i2, enumerable: false, writable: true, configurable: true } }), M(i2, t3);
      })(t2);
    }
    function V(t2) {
      return Object.assign((function(n2, i2) {
        if (N(i2)) return t2.t(n2, i2);
        R(n2, i2, t2);
      }), t2);
    }
    function R(t2, n2, i2) {
      b(t2, zn) || c(t2, zn, g({}, t2[zn])), (function(t3) {
        return "override" === t3.i;
      })(i2) || (t2[zn][n2] = i2);
    }
    function N(t2) {
      return "object" == typeof t2 && "string" == typeof t2.kind;
    }
    function T(t2, n2, i2) {
      void 0 === n2 && (n2 = Hn), void 0 === i2 && (i2 = Hn);
      var r2 = new Jn(t2);
      return n2 !== Hn && Bt(r2, n2), i2 !== Hn && Dt(r2, i2), r2;
    }
    function C(t2, n2, i2) {
      return $t(t2) ? t2 : Array.isArray(t2) ? ci.array(t2, { name: i2 }) : s(t2) ? ci.object(t2, void 0, { name: i2 }) : l(t2) ? ci.map(t2, { name: i2 }) : v(t2) ? ci.set(t2, { name: i2 }) : "function" != typeof t2 || Lt(t2) || Ft(t2) ? t2 : f(t2) ? Gi(t2) : Pi(i2, t2);
    }
    function I(t2) {
      return t2;
    }
    function L(t2, n2) {
      return { i: t2, u: n2, o: P, s: K, t: B };
    }
    function P(t2, n2, i2, r2) {
      var e2;
      if (null != (e2 = this.u) && e2.bound) return null === this.s(t2, n2, i2, false) ? 0 : 1;
      if (r2 === t2.h) return null === this.s(t2, n2, i2, false) ? 0 : 2;
      if (Lt(i2.value)) return 1;
      var u2 = D(t2, this, n2, i2, false);
      return Kn(r2, n2, u2), 2;
    }
    function K(t2, n2, i2, r2) {
      var e2 = D(t2, this, n2, i2);
      return t2.l(n2, e2, r2);
    }
    function B(n2, i2) {
      var r2, e2 = i2.kind, u2 = i2.name, o2 = i2.addInitializer, s2 = this, f2 = function(t2) {
        var n3, i3, r3, e3;
        return st(null != (n3 = null == (i3 = s2.u) ? void 0 : i3.name) ? n3 : u2.toString(), t2, null != (r3 = null == (e3 = s2.u) ? void 0 : e3.autoAction) && r3);
      };
      return "field" == e2 ? function(t2) {
        var n3, i3 = t2;
        return Lt(i3) || (i3 = f2(i3)), null != (n3 = s2.u) && n3.bound && ((i3 = i3.bind(this)).isMobxAction = true), i3;
      } : "method" == e2 ? (Lt(n2) || (n2 = f2(n2)), null != (r2 = this.u) && r2.bound && o2((function() {
        var t2 = this[u2].bind(this);
        t2.isMobxAction = true, this[u2] = t2;
      })), n2) : void t("Cannot apply '" + s2.i + "' to '" + String(u2) + "' (kind: " + e2 + "):\n'" + s2.i + "' can only be used on properties with a function value.");
    }
    function D(t2, n2, i2, r2, e2) {
      var u2, o2, s2, f2, c2, a2, h2;
      void 0 === e2 && (e2 = ki.safeDescriptors);
      var l2, v2 = r2.value;
      return null != (u2 = n2.u) && u2.bound && (v2 = v2.bind(null != (l2 = t2.v) ? l2 : t2.h)), { value: st(null != (o2 = null == (s2 = n2.u) ? void 0 : s2.name) ? o2 : i2.toString(), v2, null != (f2 = null == (c2 = n2.u) ? void 0 : c2.autoAction) && f2, null != (a2 = n2.u) && a2.bound ? null != (h2 = t2.v) ? h2 : t2.h : void 0), configurable: !e2 || t2.p, enumerable: false, writable: !e2 };
    }
    function W(t2, n2) {
      return { i: t2, u: n2, o: q, s: G, t: H };
    }
    function q(t2, n2, i2, r2) {
      var e2;
      if (r2 === t2.h) return null === this.s(t2, n2, i2, false) ? 0 : 2;
      if (null != (e2 = this.u) && e2.bound && (!b(t2.h, n2) || !Ft(t2.h[n2])) && null === this.s(t2, n2, i2, false)) return 0;
      if (Ft(i2.value)) return 1;
      var u2 = U(t2, 0, 0, i2, false, false);
      return Kn(r2, n2, u2), 2;
    }
    function G(t2, n2, i2, r2) {
      var e2, u2 = U(t2, 0, 0, i2, null == (e2 = this.u) ? void 0 : e2.bound);
      return t2.l(n2, u2, r2);
    }
    function H(t2, n2) {
      var i2, r2 = n2.name, e2 = n2.addInitializer;
      return Ft(t2) || (t2 = Gi(t2)), null != (i2 = this.u) && i2.bound && e2((function() {
        var t3 = this[r2].bind(this);
        t3.isMobXFlow = true, this[r2] = t3;
      })), t2;
    }
    function U(t2, n2, i2, r2, e2, u2) {
      void 0 === u2 && (u2 = ki.safeDescriptors);
      var o2, s2 = r2.value;
      return Ft(s2) || (s2 = Gi(s2)), e2 && ((s2 = s2.bind(null != (o2 = t2.v) ? o2 : t2.h)).isMobXFlow = true), { value: s2, configurable: !u2 || t2.p, enumerable: false, writable: !u2 };
    }
    function F(t2, n2) {
      return { i: t2, u: n2, o: X, s: z, t: $ };
    }
    function X(t2, n2, i2) {
      return null === this.s(t2, n2, i2, false) ? 0 : 1;
    }
    function z(t2, n2, i2, r2) {
      return t2.m(n2, g({}, this.u, { get: i2.get, set: i2.set }), r2);
    }
    function $(t2, n2) {
      function i2(n3) {
        var i3 = g({}, e2.u, { get: t2, context: n3 });
        return i3.name || (i3.name = "ObservableObject." + u2.toString()), new wi(i3);
      }
      var r2, e2 = this, u2 = n2.name;
      return (0, n2.addInitializer)((function() {
        var n3, r3 = wn(this)[$n], e3 = this, o2 = r3.j.get(u2);
        o2 instanceof wi && o2.derivation !== t2 && r3.j.delete(u2), (null != (n3 = r3.O) ? n3 : r3.O = /* @__PURE__ */ new Map()).set(u2, (function() {
          return i2(e3);
        }));
      })), function() {
        var n3 = this[$n], e3 = n3.j.get(u2);
        if (e3 instanceof wi && e3.derivation !== t2) {
          var o2, s2, f2 = null == (o2 = r2) ? void 0 : o2.get(this);
          return f2 || (f2 = i2(this), (null != (s2 = r2) ? s2 : r2 = /* @__PURE__ */ new WeakMap()).set(this, f2)), f2.get();
        }
        return n3.g(u2);
      };
    }
    function J(t2, n2) {
      return { i: t2, u: n2, o: Y, s: Q, t: Z };
    }
    function Y(t2, n2, i2) {
      return null === this.s(t2, n2, i2, false) ? 0 : 1;
    }
    function Q(t2, n2, i2, r2) {
      var e2, u2;
      return t2.S(n2, i2.value, null != (e2 = null == (u2 = this.u) ? void 0 : u2.enhancer) ? e2 : C, r2);
    }
    function Z(t2, n2) {
      function i2(t3, n3) {
        var i3, u2 = wn(t3)[$n];
        return (null != (i3 = u2._) ? i3 : u2._ = /* @__PURE__ */ new Map()).set(e2, (function() {
          var t4, i4;
          return new yi(n3, null != (t4 = null == (i4 = r2.u) ? void 0 : i4.enhancer) ? t4 : C, "ObservableObject." + e2.toString(), false);
        })), u2;
      }
      var r2 = this, e2 = n2.name;
      if ("accessor" === n2.kind) return { get: function() {
        var n3;
        return (null != (n3 = this[$n]) ? n3 : i2(this, t2.get.call(this))).g(e2);
      }, set: function(t3) {
        var n3;
        return (null != (n3 = this[$n]) ? n3 : i2(this, t3)).A(e2, t3);
      }, init: function(t3) {
        return i2(this, t3), t3;
      } };
    }
    function tt(t2) {
      return { i: "true", u: t2, o: nt, s: it, t: rt };
    }
    function nt(t2, n2, i2, r2) {
      var e2, u2, o2, s2;
      if (i2.get) return li.o(t2, n2, i2, r2);
      if (i2.set) {
        var c2 = Lt(i2.set) ? i2.set : st(n2.toString(), i2.set);
        return r2 === t2.h ? null === t2.l(n2, { configurable: !ki.safeDescriptors || t2.p, set: c2 }) ? 0 : 2 : (Kn(r2, n2, { configurable: true, set: c2 }), 2);
      }
      if (r2 !== t2.h && "function" == typeof i2.value) return f(i2.value) ? (null != (s2 = this.u) && s2.autoBind ? Gi.bound : Gi).o(t2, n2, i2, r2) : (null != (o2 = this.u) && o2.autoBind ? Pi.bound : Pi).o(t2, n2, i2, r2);
      var a2, h2 = false === (null == (e2 = this.u) ? void 0 : e2.deep) ? ci.ref : ci;
      return "function" == typeof i2.value && null != (u2 = this.u) && u2.autoBind && (i2.value = i2.value.bind(null != (a2 = t2.v) ? a2 : t2.h)), h2.o(t2, n2, i2, r2);
    }
    function it(t2, n2, i2, r2) {
      var e2, u2, o2;
      return i2.get ? li.s(t2, n2, i2, r2) : i2.set ? t2.l(n2, { configurable: !ki.safeDescriptors || t2.p, set: st(n2.toString(), i2.set) }, r2) : ("function" == typeof i2.value && null != (e2 = this.u) && e2.autoBind && (i2.value = i2.value.bind(null != (o2 = t2.v) ? o2 : t2.h)), (false === (null == (u2 = this.u) ? void 0 : u2.deep) ? ci.ref : ci).s(t2, n2, i2, r2));
    }
    function rt() {
      t("'" + this.i + "' cannot be used as a decorator");
    }
    function et(t2) {
      return t2 || ni;
    }
    function ut(t2) {
      return true === t2.deep ? C : false === t2.deep ? I : (n2 = t2.defaultDecorator) && null != (i2 = null == (r2 = n2.u) ? void 0 : r2.enhancer) ? i2 : C;
      var n2, i2, r2;
    }
    function ot(t2, n2, i2) {
      return N(n2) ? ii.t(t2, n2) : u(n2) ? void R(t2, n2, ii) : $t(t2) ? t2 : s(t2) ? ci.object(t2, n2, i2) : Array.isArray(t2) ? ci.array(t2, n2) : l(t2) ? ci.map(t2, n2) : v(t2) ? ci.set(t2, n2) : "object" == typeof t2 && null !== t2 ? t2 : ci.box(t2, n2);
    }
    function st(t2, n2, i2, r2) {
      function e2() {
        return ft(0, i2, n2, r2 || this, arguments);
      }
      return void 0 === i2 && (i2 = false), e2.isMobxAction = true, e2.toString = function() {
        return n2.toString();
      }, bi && (pi.value = t2, Kn(e2, "name", pi)), e2;
    }
    function ft(t2, n2, i2, r2, e2) {
      var u2 = ct(0, n2);
      try {
        return i2.apply(r2, e2);
      } catch (t3) {
        throw u2.M = t3, t3;
      } finally {
        at(u2);
      }
    }
    function ct(t2, n2) {
      var i2 = ki.trackingDerivation, r2 = !n2 || !i2;
      Mt();
      var e2 = ki.allowStateChanges;
      r2 && (wt(), e2 = lt(true));
      var u2 = { k: r2, V: i2, R: e2, N: Ot(true), T: false, C: 0, I: di++, L: vi };
      return vi = u2.I, u2;
    }
    function at(n2) {
      vi !== n2.I && t(30), vi = n2.L, void 0 !== n2.M && (ki.suppressReactionErrors = true), vt(n2.R), xt(n2.N), kt(), n2.k && jt(n2.V), ki.suppressReactionErrors = false;
    }
    function ht(t2, n2) {
      var i2 = lt(t2);
      try {
        return n2();
      } finally {
        vt(i2);
      }
    }
    function lt(t2) {
      var n2 = ki.allowStateChanges;
      return ki.allowStateChanges = t2, n2;
    }
    function vt(t2) {
      ki.allowStateChanges = t2;
    }
    function dt(t2) {
      return t2 instanceof gi;
    }
    function bt(t2) {
      switch (t2.P) {
        case ji.K:
          return false;
        case ji.B:
        case ji.D:
          return true;
        case ji.W:
          for (var n2 = Ot(true), i2 = wt(), r2 = t2.q, e2 = r2.length, u2 = 0; u2 < e2; u2++) {
            var o2 = r2[u2];
            if (xi(o2)) {
              if (ki.disableErrorBoundaries) o2.get();
              else try {
                o2.get();
              } catch (t3) {
                return jt(i2), xt(n2), true;
              }
              if (t2.P === ji.D) return jt(i2), xt(n2), true;
            }
          }
          return gt(t2), jt(i2), xt(n2), false;
      }
    }
    function pt(t2, n2, i2) {
      var r2 = Ot(true);
      gt(t2), t2.G = new Array(0 === t2.H ? 100 : t2.q.length), t2.U = 0, t2.H = ++ki.runId;
      var e2, u2 = ki.trackingDerivation;
      if (ki.trackingDerivation = t2, ki.inBatch++, true === ki.disableErrorBoundaries) e2 = n2.call(i2);
      else try {
        e2 = n2.call(i2);
      } catch (t3) {
        e2 = new gi(t3);
      }
      return ki.inBatch--, ki.trackingDerivation = u2, (function(t3) {
        for (var n3 = t3.q, i3 = t3.q = t3.G, r3 = ji.K, e3 = 0, u3 = t3.U, o2 = 0; o2 < u3; o2++) {
          var s2 = i3[o2];
          0 === s2.diffValue && (s2.diffValue = 1, e3 !== o2 && (i3[e3] = s2), e3++), s2.P > r3 && (r3 = s2.P);
        }
        for (i3.length = e3, t3.G = null, u3 = n3.length; u3--; ) {
          var f2 = n3[u3];
          0 === f2.diffValue && _t(f2, t3), f2.diffValue = 0;
        }
        for (; e3--; ) {
          var c2 = i3[e3];
          1 === c2.diffValue && (c2.diffValue = 0, St(c2, t3));
        }
        r3 !== ji.K && (t3.P = r3, t3.F());
      })(t2), xt(r2), e2;
    }
    function yt(t2) {
      var n2 = t2.q;
      t2.q = [];
      for (var i2 = n2.length; i2--; ) _t(n2[i2], t2);
      t2.P = ji.B;
    }
    function mt(t2) {
      var n2 = wt();
      try {
        return t2();
      } finally {
        jt(n2);
      }
    }
    function wt() {
      var t2 = ki.trackingDerivation;
      return ki.trackingDerivation = null, t2;
    }
    function jt(t2) {
      ki.trackingDerivation = t2;
    }
    function Ot(t2) {
      var n2 = ki.allowStateReads;
      return ki.allowStateReads = t2, n2;
    }
    function xt(t2) {
      ki.allowStateReads = t2;
    }
    function gt(t2) {
      if (t2.P !== ji.K) {
        t2.P = ji.K;
        for (var n2 = t2.q, i2 = n2.length; i2--; ) n2[i2].X = ji.K;
      }
    }
    function St(t2, n2) {
      t2.$.add(n2), t2.X > n2.P && (t2.X = n2.P);
    }
    function _t(t2, n2) {
      t2.$.delete(n2), 0 === t2.$.size && At(t2);
    }
    function At(t2) {
      false === t2.isPendingUnobservation && (t2.isPendingUnobservation = true, ki.pendingUnobservations.push(t2));
    }
    function Mt() {
      ki.inBatch++;
    }
    function kt() {
      if (0 == --ki.inBatch) {
        Rt();
        for (var t2 = ki.pendingUnobservations, n2 = 0; n2 < t2.length; n2++) {
          var i2 = t2[n2];
          i2.isPendingUnobservation = false, 0 === i2.$.size && (i2.isBeingObserved && (i2.isBeingObserved = false, i2.onBUO()), i2 instanceof wi && i2.J());
        }
        ki.pendingUnobservations = [];
      }
    }
    function Et(t2) {
      var n2 = ki.trackingDerivation;
      return null !== n2 ? (n2.H !== t2.Y && (t2.Y = n2.H, n2.G[n2.U++] = t2, !t2.isBeingObserved && ki.trackingContext && (t2.isBeingObserved = true, t2.onBO())), t2.isBeingObserved) : (0 === t2.$.size && ki.inBatch > 0 && At(t2), false);
    }
    function Vt(t2) {
      t2.X !== ji.D && (t2.X = ji.D, t2.$.forEach((function(t3) {
        t3.P === ji.K && t3.F(), t3.P = ji.D;
      })));
    }
    function Rt() {
      ki.inBatch > 0 || ki.isRunningReactions || Vi(Nt);
    }
    function Nt() {
      ki.isRunningReactions = true;
      for (var t2 = ki.pendingReactions, n2 = 0; t2.length > 0; ) {
        100 == ++n2 && (console.error("[mobx] cycle in reaction: " + t2[0]), t2.splice(0));
        for (var i2 = t2.splice(0), r2 = 0, e2 = i2.length; r2 < e2; r2++) i2[r2].Z();
      }
      ki.isRunningReactions = false;
    }
    function Tt() {
      return console.warn("[mobx.spy] Is a no-op in production builds"), function() {
      };
    }
    function Ct(t2) {
      return function(n2, i2) {
        return e(n2) ? st(n2.name || "<unnamed action>", n2, t2) : e(i2) ? st(n2, i2, t2) : N(i2) ? (t2 ? Ci : Ni).t(n2, i2) : u(i2) ? R(n2, i2, t2 ? Ci : Ni) : u(n2) ? V(L(t2 ? "autoAction" : "action", { name: n2, autoAction: t2 })) : void 0;
      };
    }
    function It(t2) {
      return ft(0, false, t2, this, void 0);
    }
    function Lt(t2) {
      return e(t2) && true === t2.isMobxAction;
    }
    function Pt(t2, n2) {
      function i2() {
        t2(s2);
      }
      var r2, e2, u2, o2;
      void 0 === n2 && (n2 = Wn);
      var s2, f2 = null != (r2 = null == (e2 = n2) ? void 0 : e2.name) ? r2 : "Autorun";
      if (n2.scheduler || n2.delay) {
        var c2 = Kt(n2), a2 = false;
        s2 = new Ei(f2, (function() {
          a2 || (a2 = true, c2((function() {
            a2 = false, s2.isDisposed || s2.track(i2);
          })));
        }), n2.onError, n2.requiresObservable);
      } else s2 = new Ei(f2, (function() {
        this.track(i2);
      }), n2.onError, n2.requiresObservable);
      return null != (u2 = n2) && null != (u2 = u2.signal) && u2.aborted || s2.tt(), s2.nt(null == (o2 = n2) ? void 0 : o2.signal);
    }
    function Kt(t2) {
      return t2.scheduler ? t2.scheduler : t2.delay ? function(n2) {
        return setTimeout(n2, t2.delay);
      } : Ki;
    }
    function Bt(t2, n2, i2) {
      return Wt("onBO", t2, n2, i2);
    }
    function Dt(t2, n2, i2) {
      return Wt("onBUO", t2, n2, i2);
    }
    function Wt(t2, n2, i2, r2) {
      var u2 = "function" == typeof r2 ? Mn(n2, i2) : Mn(n2), o2 = e(r2) ? r2 : i2, s2 = t2 + "L";
      return u2[s2] ? u2[s2].add(o2) : u2[s2] = /* @__PURE__ */ new Set([o2]), function() {
        var t3 = u2[s2];
        t3 && (t3.delete(o2), 0 === t3.size && delete u2[s2]);
      };
    }
    function qt(t2, n2, i2, r2) {
      var e2 = Xn(n2);
      return Vn((function() {
        var n3 = wn(t2, r2)[$n];
        Fn(e2).forEach((function(t3) {
          n3.s(t3, e2[t3], !i2 || !(t3 in i2) || i2[t3]);
        }));
      })), t2;
    }
    function Gt(t2) {
      var n2, i2 = { name: t2.it };
      return t2.q && t2.q.length > 0 && (i2.dependencies = (n2 = t2.q, Array.from(new Set(n2))).map(Gt)), i2;
    }
    function Ht(t2) {
      var n2 = { name: t2.it };
      return (function(t3) {
        return t3.$ && t3.$.size > 0;
      })(t2) && (n2.observers = Array.from((function(t3) {
        return t3.$;
      })(t2)).map(Ht)), n2;
    }
    function Ut(t2) {
      e(t2.cancel) && t2.cancel();
    }
    function Ft(t2) {
      return true === (null == t2 ? void 0 : t2.isMobXFlow);
    }
    function Xt(t2, n2) {
      var i2;
      if (void 0 === n2) return xi(t2);
      if (false === On(t2)) return false;
      var r2 = t2[$n];
      if (null != (i2 = r2.O) && i2.has(n2)) return true;
      if (!r2.j.has(n2)) return false;
      var e2 = Mn(t2, n2);
      return xi(e2);
    }
    function zt(t2, n2) {
      if (!t2) return false;
      if (void 0 !== n2) {
        if (On(t2)) {
          var i2, r2, e2 = t2[$n];
          return e2.j.has(n2) || !(null == (i2 = e2.O) || !i2.has(n2)) || !(null == (r2 = e2._) || !r2.has(n2));
        }
        return false;
      }
      return On(t2) || !!t2[$n] || Yn(t2) || Ri(t2) || xi(t2);
    }
    function $t(t2) {
      return zt(t2);
    }
    function Jt(n2) {
      return On(n2) ? n2[$n].rt() : ir(n2) || ur(n2) ? Array.from(n2.keys()) : pn(n2) ? n2.map((function(t2, n3) {
        return n3;
      })) : void t(5);
    }
    function Yt(n2, i2) {
      return On(n2) ? n2[$n].et(i2) : ir(n2) || ur(n2) ? n2.has(i2) : pn(n2) ? i2 >= 0 && i2 < n2.length : void t(10);
    }
    function Qt(n2) {
      if (On(n2)) return n2[$n].ut();
      t(38);
    }
    function Zt(t2, n2, i2) {
      return t2.set(n2, i2), i2;
    }
    function tn(t2, n2) {
      void 0 === n2 && (n2 = void 0), Mt();
      try {
        return t2.apply(n2);
      } finally {
        kt();
      }
    }
    function nn(t2, n2, i2) {
      var r2;
      if ("number" == typeof i2.timeout) {
        var e2 = new Error("WHEN_TIMEOUT");
        r2 = setTimeout((function() {
          if (!o2[$n].isDisposed) {
            if (o2(), !i2.onError) throw e2;
            i2.onError(e2);
          }
        }), i2.timeout);
      }
      i2.name = "When";
      var u2 = st("When-effect", n2), o2 = Pt((function(n3) {
        ht(false, t2) && (n3.dispose(), r2 && clearTimeout(r2), u2());
      }), i2);
      return o2;
    }
    function rn(t2, n2) {
      var i2, r2, e2;
      if (null != n2 && null != (i2 = n2.signal) && i2.aborted) return Object.assign(Promise.reject(new Error("WHEN_ABORTED")), { cancel: function() {
        return null;
      } });
      var u2 = new Promise((function(i3, u3) {
        var o2, s2 = nn(t2, i3, g({}, n2, { onError: u3 }));
        r2 = function() {
          s2(), u3(new Error("WHEN_CANCELLED"));
        }, e2 = function() {
          s2(), u3(new Error("WHEN_ABORTED"));
        }, null == n2 || null == (o2 = n2.signal) || null == o2.addEventListener || o2.addEventListener("abort", e2);
      })).finally((function() {
        var t3;
        return null == n2 || null == (t3 = n2.signal) || null == t3.removeEventListener ? void 0 : t3.removeEventListener("abort", e2);
      }));
      return u2.cancel = r2, u2;
    }
    function en(t2) {
      return t2[$n];
    }
    function un(t2) {
      return void 0 !== t2.ot && t2.ot.length > 0;
    }
    function on(t2, n2) {
      var i2 = t2.ot || (t2.ot = []);
      return i2.push(n2), r((function() {
        var t3 = i2.indexOf(n2);
        -1 !== t3 && i2.splice(t3, 1);
      }));
    }
    function sn(n2, i2) {
      var r2 = wt();
      try {
        for (var e2 = [].concat(n2.ot || []), u2 = 0, o2 = e2.length; u2 < o2 && ((i2 = e2[u2](i2)) && !i2.type && t(14), i2); u2++) ;
        return i2;
      } finally {
        jt(r2);
      }
    }
    function fn(t2) {
      return void 0 !== t2.st && t2.st.length > 0;
    }
    function cn(t2, n2) {
      var i2 = t2.st || (t2.st = []);
      return i2.push(n2), r((function() {
        var t3 = i2.indexOf(n2);
        -1 !== t3 && i2.splice(t3, 1);
      }));
    }
    function an(t2, n2) {
      var i2 = wt(), r2 = t2.st;
      if (r2) {
        for (var e2 = 0, u2 = (r2 = r2.slice()).length; e2 < u2; e2++) r2[e2](n2);
        jt(i2);
      }
    }
    function hn(t2, n2, r2, e2) {
      return void 0 === r2 && (r2 = "ObservableArray"), void 0 === e2 && (e2 = false), i(), Vn((function() {
        var i2 = new zi(r2, n2, e2, false);
        a(i2.j, $n, i2);
        var u2 = new Proxy(i2.j, Xi);
        return i2.v = u2, t2 && t2.length && i2.ft(0, 0, t2), u2;
      }));
    }
    function ln(t2, n2) {
      "function" == typeof Array.prototype[t2] && ($i[t2] = n2(t2));
    }
    function vn(t2) {
      return function() {
        var n2 = this[$n];
        n2.ct.reportObserved();
        var i2 = n2.ht(n2.j);
        return i2[t2].apply(i2, arguments);
      };
    }
    function dn(t2) {
      return function(n2, i2) {
        var r2 = this, e2 = this[$n];
        return e2.ct.reportObserved(), e2.ht(e2.j)[t2]((function(t3, e3) {
          return n2.call(i2, t3, e3, r2);
        }));
      };
    }
    function bn(t2) {
      return function() {
        var n2 = this, i2 = this[$n];
        i2.ct.reportObserved();
        var r2 = i2.ht(i2.j), e2 = arguments[0];
        return arguments[0] = function(t3, i3, r3) {
          return e2(t3, i3, r3, n2);
        }, r2[t2].apply(r2, arguments);
      };
    }
    function pn(t2) {
      return o(t2) && Qi(t2[$n]);
    }
    function yn(t2) {
      return t2[Symbol.toStringTag] = "MapIterator", Tn(t2);
    }
    function mn(t2) {
      return t2[Symbol.toStringTag] = "SetIterator", Tn(t2);
    }
    function wn(t2, n2) {
      var i2;
      if (b(t2, $n)) return t2;
      var r2 = null != (i2 = null == n2 ? void 0 : n2.name) ? i2 : "ObservableObject", e2 = new sr(t2, /* @__PURE__ */ new Map(), String(r2), (function(t3) {
        var n3;
        return t3 ? null != (n3 = t3.defaultDecorator) ? n3 : tt(t3) : void 0;
      })(n2));
      return c(t2, $n, e2), t2;
    }
    function jn(t2) {
      return or[t2] || (or[t2] = { get: function() {
        return this[$n].g(t2);
      }, set: function(n2) {
        return this[$n].A(t2, n2);
      } });
    }
    function On(t2) {
      return !!o(t2) && fr(t2[$n]);
    }
    function xn(t2, n2, i2) {
      var r2;
      null == (r2 = t2.h[zn]) || delete r2[i2];
    }
    function gn(t2) {
      return { enumerable: false, configurable: true, get: function() {
        return this[$n].lt(t2);
      }, set: function(n2) {
        this[$n].vt(t2, n2);
      } };
    }
    function Sn(t2) {
      Kn(vr.prototype, "" + t2, gn(t2));
    }
    function _n(t2) {
      if (t2 > hr) {
        for (var n2 = hr; n2 < t2 + 100; n2++) Sn(n2);
        hr = t2;
      }
    }
    function An(t2, n2, i2) {
      return new vr(t2, n2, i2);
    }
    function Mn(n2, i2) {
      if ("object" == typeof n2 && null !== n2) {
        if (pn(n2)) return void 0 !== i2 && t(23), n2[$n].ct;
        if (ur(n2)) return n2.ct;
        if (ir(n2)) {
          if (void 0 === i2) return n2.dt;
          var r2 = n2.bt.get(i2) || n2.pt.get(i2);
          return r2 || t(25, i2, En(n2)), r2;
        }
        if (On(n2)) {
          var u2, o2;
          if (!i2) return t(26);
          var s2 = n2[$n], f2 = null != (u2 = null != (o2 = s2.j.get(i2)) ? o2 : s2.yt(i2)) ? u2 : s2.wt(i2);
          return f2 || t(27, i2, En(n2)), f2;
        }
        if (Yn(n2) || xi(n2) || Ri(n2)) return n2;
      } else if (e(n2) && Ri(n2[$n])) return n2[$n];
      t(28);
    }
    function kn(n2, i2) {
      return n2 || t(29), void 0 !== i2 ? kn(Mn(n2, i2)) : Yn(n2) || xi(n2) || Ri(n2) || ir(n2) || ur(n2) ? n2 : n2[$n] ? n2[$n] : void t(24, n2);
    }
    function En(t2, n2) {
      var i2;
      if (void 0 !== n2) i2 = Mn(t2, n2);
      else {
        if (Lt(t2)) return t2.name;
        i2 = On(t2) || ir(t2) || ur(t2) ? kn(t2) : Mn(t2);
      }
      return i2.it;
    }
    function Vn(t2) {
      var n2 = wt(), i2 = lt(true);
      Mt();
      try {
        return t2();
      } finally {
        kt(), vt(i2), jt(n2);
      }
    }
    function Rn(t2, n2, i2) {
      return void 0 === i2 && (i2 = -1), (function t3(n3, i3, r2, u2, o2) {
        if (n3 === i3) return 0 !== n3 || 1 / n3 == 1 / i3;
        if (null == n3 || null == i3) return false;
        if (n3 != n3) return i3 != i3;
        var s2 = typeof n3;
        if ("function" !== s2 && "object" !== s2 && "object" != typeof i3) return false;
        var f2 = br.call(n3);
        if (f2 !== br.call(i3)) return false;
        switch (f2) {
          case "[object RegExp]":
          case "[object String]":
            return "" + n3 == "" + i3;
          case "[object Number]":
            return +n3 != +n3 ? +i3 != +i3 : 0 == +n3 ? 1 / +n3 == 1 / i3 : +n3 == +i3;
          case "[object Date]":
          case "[object Boolean]":
            return +n3 == +i3;
          case "[object Symbol]":
            return "undefined" != typeof Symbol && Symbol.valueOf.call(n3) === Symbol.valueOf.call(i3);
          case "[object Map]":
          case "[object Set]":
            r2 >= 0 && r2++;
        }
        n3 = Nn(n3), i3 = Nn(i3);
        var c2 = "[object Array]" === f2;
        if (!c2) {
          if ("object" != typeof n3 || "object" != typeof i3) return false;
          var a2 = n3.constructor, h2 = i3.constructor;
          if (a2 !== h2 && !(e(a2) && a2 instanceof a2 && e(h2) && h2 instanceof h2) && "constructor" in n3 && "constructor" in i3) return false;
        }
        if (0 === r2) return false;
        r2 < 0 && (r2 = -1), o2 = o2 || [];
        for (var l2 = (u2 = u2 || []).length; l2--; ) if (u2[l2] === n3) return o2[l2] === i3;
        if (u2.push(n3), o2.push(i3), c2) {
          if ((l2 = n3.length) !== i3.length) return false;
          for (; l2--; ) if (!t3(n3[l2], i3[l2], r2 - 1, u2, o2)) return false;
        } else {
          var v2 = Object.keys(n3), d2 = v2.length;
          if (Object.keys(i3).length !== d2) return false;
          for (var p2 = 0; p2 < d2; p2++) {
            var y2 = v2[p2];
            if (!b(i3, y2) || !t3(n3[y2], i3[y2], r2 - 1, u2, o2)) return false;
          }
        }
        return u2.pop(), o2.pop(), true;
      })(t2, n2, i2);
    }
    function Nn(t2) {
      return pn(t2) ? t2.slice() : l(t2) || ir(t2) || v(t2) || ur(t2) ? Array.from(t2.entries()) : t2;
    }
    function Tn(t2) {
      return t2[Symbol.iterator] = Cn, Object.assign(Object.create(pr), t2);
    }
    function Cn() {
      return this;
    }
    Object.defineProperty(exports2, "__esModule", { value: true });
    var In = {};
    var Ln = Object.assign;
    var Pn = Object.getOwnPropertyDescriptor;
    var Kn = Object.defineProperty;
    var Bn = Object.prototype;
    var Dn = [];
    Object.freeze(Dn);
    var Wn = {};
    Object.freeze(Wn);
    var qn = "undefined" != typeof Proxy;
    var Gn = Object.toString();
    var Hn = function() {
    };
    var Un = void 0 !== Object.getOwnPropertySymbols;
    var Fn = "undefined" != typeof Reflect && Reflect.ownKeys ? Reflect.ownKeys : Un ? function(t2) {
      return Object.getOwnPropertyNames(t2).concat(Object.getOwnPropertySymbols(t2));
    } : Object.getOwnPropertyNames;
    var Xn = Object.getOwnPropertyDescriptors || function(t2) {
      var n2 = {};
      return Fn(t2).forEach((function(i2) {
        n2[i2] = Pn(t2, i2);
      })), n2;
    };
    var zn = Symbol("mobx-stored-annotations");
    var $n = Symbol("mobx administration");
    var Jn = (function() {
      function t2(t3) {
        void 0 === t3 && (t3 = "Atom"), this.it = void 0, this.jt = 0, this.$ = /* @__PURE__ */ new Set(), this.Y = 0, this.X = ji.B, this.onBOL = void 0, this.onBUOL = void 0, this.it = t3;
      }
      var n2 = t2.prototype;
      return n2.onBO = function() {
        this.onBOL && this.onBOL.forEach((function(t3) {
          return t3();
        }));
      }, n2.onBUO = function() {
        this.onBUOL && this.onBUOL.forEach((function(t3) {
          return t3();
        }));
      }, n2.reportObserved = function() {
        return Et(this);
      }, n2.reportChanged = function() {
        Mt(), Vt(this), kt();
      }, n2.toString = function() {
        return this.it;
      }, O(t2, [{ key: "isBeingObserved", get: function() {
        return p(this.jt, t2.Ot);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.Ot, n3);
      } }, { key: "isPendingUnobservation", get: function() {
        return p(this.jt, t2.xt);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.xt, n3);
      } }, { key: "diffValue", get: function() {
        return p(this.jt, t2.gt) ? 1 : 0;
      }, set: function(n3) {
        this.jt = y(this.jt, t2.gt, 1 === n3);
      } }]);
    })();
    Jn.Ot = 1, Jn.xt = 2, Jn.gt = 4;
    var Yn = h("Atom", Jn);
    var Qn = { identity: function(t2, n2) {
      return t2 === n2;
    }, structural: function(t2, n2) {
      return Rn(t2, n2);
    }, default: function(t2, n2) {
      return Object.is ? Object.is(t2, n2) : t2 === n2 ? 0 !== t2 || 1 / t2 == 1 / n2 : t2 != t2 && n2 != n2;
    }, shallow: function(t2, n2) {
      return Rn(t2, n2, 1);
    } };
    var Zn = V({ i: "override", o: function() {
      return 0;
    }, s: function() {
      t("'" + this.i + "' can only be used with 'makeObservable'");
    }, t: function() {
      console.warn("'" + this.i + "' cannot be used with decorators - this is a no-op");
    } });
    var ti = tt();
    var ni = { deep: true, name: void 0, defaultDecorator: void 0, proxy: true };
    Object.freeze(ni);
    var ii = J("observable");
    var ri = J("observable.ref", { enhancer: I });
    var ei = J("observable.shallow", { enhancer: function(t2, n2, i2) {
      return null == t2 || On(t2) || pn(t2) || ir(t2) || ur(t2) ? t2 : Array.isArray(t2) ? ci.array(t2, { name: i2, deep: false }) : s(t2) ? ci.object(t2, void 0, { name: i2, deep: false }) : l(t2) ? ci.map(t2, { name: i2, deep: false }) : v(t2) ? ci.set(t2, { name: i2, deep: false }) : void 0;
    } });
    var ui = J("observable.struct", { enhancer: function(t2, n2) {
      return Rn(t2, n2) ? n2 : t2;
    } });
    var oi = V(ii);
    Ln(ot, oi);
    var si;
    var fi;
    var ci = Ln(ot, { box: function(t2, n2) {
      var i2 = et(n2);
      return new yi(t2, ut(i2), i2.name, true, i2.equals);
    }, array: function(t2, n2) {
      var i2 = et(n2);
      return (false === ki.useProxies || false === i2.proxy ? An : hn)(t2, ut(i2), i2.name);
    }, map: function(t2, n2) {
      var i2 = et(n2);
      return new nr(t2, ut(i2), i2.name);
    }, set: function(t2, n2) {
      var i2 = et(n2);
      return new er(t2, ut(i2), i2.name);
    }, object: function(t2, n2, r2) {
      return Vn((function() {
        return qt(false === ki.useProxies || false === (null == r2 ? void 0 : r2.proxy) ? wn({}, r2) : (function(t3, n3) {
          var r3, e2;
          return i(), null != (e2 = (r3 = (t3 = wn(t3, n3))[$n]).v) ? e2 : r3.v = new Proxy(t3, Hi);
        })({}, r2), t2, n2);
      }));
    }, ref: V(ri), shallow: V(ei), deep: oi, struct: V(ui) });
    var ai = F("computed");
    var hi = F("computed.struct", { equals: Qn.structural });
    var li = function(t2, n2) {
      if (N(n2)) return ai.t(t2, n2);
      if (u(n2)) return R(t2, n2, ai);
      if (s(t2)) return V(F("computed", t2));
      var i2 = s(n2) ? n2 : {};
      return i2.get = t2, i2.name || (i2.name = t2.name || ""), new wi(i2);
    };
    Object.assign(li, ai), li.struct = V(hi);
    var vi = 0;
    var di = 1;
    var bi = null != (si = null == (fi = Pn((function() {
    }), "name")) ? void 0 : fi.configurable) && si;
    var pi = { value: "action", configurable: true, writable: false, enumerable: false };
    var yi = (function(t2) {
      function n2(n3, i3, r2, e2, u2) {
        var o2;
        return void 0 === r2 && (r2 = "ObservableValue"), void 0 === u2 && (u2 = Qn.default), (o2 = t2.call(this, r2) || this).enhancer = void 0, o2.it = void 0, o2.equals = void 0, o2.St = false, o2.ot = void 0, o2.st = void 0, o2._t = void 0, o2.dehancer = void 0, o2.enhancer = i3, o2.it = r2, o2.equals = u2, o2._t = i3(n3, void 0, r2), o2;
      }
      _(n2, t2);
      var i2 = n2.prototype;
      return i2.dehanceValue = function(t3) {
        return void 0 !== this.dehancer ? this.dehancer(t3) : t3;
      }, i2.set = function(t3) {
        (t3 = this.At(t3)) !== ki.UNCHANGED && this.Mt(t3);
      }, i2.At = function(t3) {
        if (un(this)) {
          var n3 = sn(this, { object: this, type: Fi, newValue: t3 });
          if (!n3) return ki.UNCHANGED;
          t3 = n3.newValue;
        }
        return t3 = this.enhancer(t3, this._t, this.it), this.equals(this._t, t3) ? ki.UNCHANGED : t3;
      }, i2.Mt = function(t3) {
        var n3 = this._t;
        this._t = t3, this.reportChanged(), fn(this) && an(this, { type: Fi, object: this, newValue: t3, oldValue: n3 });
      }, i2.get = function() {
        return this.reportObserved(), this.dehanceValue(this._t);
      }, i2.kt = function(t3) {
        return on(this, t3);
      }, i2.Et = function(t3, n3) {
        return n3 && t3({ observableKind: "value", debugObjectName: this.it, object: this, type: Fi, newValue: this._t, oldValue: void 0 }), cn(this, t3);
      }, i2.raw = function() {
        return this._t;
      }, i2.toJSON = function() {
        return this.get();
      }, i2.toString = function() {
        return this.it + "[" + this._t + "]";
      }, i2.valueOf = function() {
        return d(this.get());
      }, i2[Symbol.toPrimitive] = function() {
        return this.valueOf();
      }, n2;
    })(Jn);
    var mi = h("ObservableValue", yi);
    var wi = (function() {
      function n2(n3) {
        this.P = ji.B, this.q = [], this.G = null, this.$ = /* @__PURE__ */ new Set(), this.H = 0, this.Y = 0, this.X = ji.K, this.U = 0, this._t = new gi(null), this.it = void 0, this.Vt = void 0, this.jt = 0, this.derivation = void 0, this.Rt = void 0, this.Nt = Oi.NONE, this.Tt = void 0, this.Ct = void 0, this.It = void 0, this.Lt = void 0, this.onBOL = void 0, this.onBUOL = void 0, n3.get || t(31), this.derivation = n3.get, this.it = n3.name || "ComputedValue", n3.set && (this.Rt = st("ComputedValue-setter", n3.set)), this.Ct = n3.equals || (n3.compareStructural || n3.struct ? Qn.structural : Qn.default), this.Tt = n3.context, this.It = n3.requiresReaction, this.Lt = !!n3.keepAlive;
      }
      var i2 = n2.prototype;
      return i2.F = function() {
        !(function(t2) {
          t2.X === ji.K && (t2.X = ji.W, t2.$.forEach((function(t3) {
            t3.P === ji.K && (t3.P = ji.W, t3.F());
          })));
        })(this);
      }, i2.onBO = function() {
        this.onBOL && this.onBOL.forEach((function(t2) {
          return t2();
        }));
      }, i2.onBUO = function() {
        this.onBUOL && this.onBUOL.forEach((function(t2) {
          return t2();
        }));
      }, i2.get = function() {
        if (this.isComputing && t(32, this.it, this.derivation), 0 !== ki.inBatch || 0 !== this.$.size || this.Lt) {
          if (Et(this), bt(this)) {
            var n3 = ki.trackingContext;
            this.Lt && !n3 && (ki.trackingContext = this), this.trackAndCompute() && (function(t2) {
              t2.X !== ji.D && (t2.X = ji.D, t2.$.forEach((function(n4) {
                n4.P === ji.W ? n4.P = ji.D : n4.P === ji.K && (t2.X = ji.K);
              })));
            })(this), ki.trackingContext = n3;
          }
        } else bt(this) && (this.Pt(), Mt(), this._t = this.Kt(false), kt());
        var i3 = this._t;
        if (dt(i3)) throw i3.cause;
        return i3;
      }, i2.set = function(n3) {
        if (this.Rt) {
          this.isRunningSetter && t(33, this.it), this.isRunningSetter = true;
          try {
            this.Rt.call(this.Tt, n3);
          } finally {
            this.isRunningSetter = false;
          }
        } else t(34, this.it);
      }, i2.trackAndCompute = function() {
        var t2 = this._t, n3 = this.P === ji.B, i3 = this.Kt(true), r2 = n3 || dt(t2) || dt(i3) || !this.Ct(t2, i3);
        return r2 && (this._t = i3), r2;
      }, i2.Kt = function(t2) {
        this.isComputing = true;
        var n3, i3 = lt(false);
        if (t2) n3 = pt(this, this.derivation, this.Tt);
        else if (true === ki.disableErrorBoundaries) n3 = this.derivation.call(this.Tt);
        else try {
          n3 = this.derivation.call(this.Tt);
        } catch (t3) {
          n3 = new gi(t3);
        }
        return vt(i3), this.isComputing = false, n3;
      }, i2.J = function() {
        this.Lt || (yt(this), this._t = void 0);
      }, i2.Et = function(t2, n3) {
        var i3 = this, r2 = true, e2 = void 0;
        return Pt((function() {
          var u2 = i3.get();
          if (!r2 || n3) {
            var o2 = wt();
            t2({ observableKind: "computed", debugObjectName: i3.it, type: Fi, object: i3, newValue: u2, oldValue: e2 }), jt(o2);
          }
          r2 = false, e2 = u2;
        }));
      }, i2.Pt = function() {
      }, i2.toString = function() {
        return this.it + "[" + this.derivation.toString() + "]";
      }, i2.valueOf = function() {
        return d(this.get());
      }, i2[Symbol.toPrimitive] = function() {
        return this.valueOf();
      }, O(n2, [{ key: "isComputing", get: function() {
        return p(this.jt, n2.Bt);
      }, set: function(t2) {
        this.jt = y(this.jt, n2.Bt, t2);
      } }, { key: "isRunningSetter", get: function() {
        return p(this.jt, n2.Dt);
      }, set: function(t2) {
        this.jt = y(this.jt, n2.Dt, t2);
      } }, { key: "isBeingObserved", get: function() {
        return p(this.jt, n2.Ot);
      }, set: function(t2) {
        this.jt = y(this.jt, n2.Ot, t2);
      } }, { key: "isPendingUnobservation", get: function() {
        return p(this.jt, n2.xt);
      }, set: function(t2) {
        this.jt = y(this.jt, n2.xt, t2);
      } }, { key: "diffValue", get: function() {
        return p(this.jt, n2.gt) ? 1 : 0;
      }, set: function(t2) {
        this.jt = y(this.jt, n2.gt, 1 === t2);
      } }]);
    })();
    wi.Bt = 1, wi.Dt = 2, wi.Ot = 4, wi.xt = 8, wi.gt = 16;
    var ji;
    var Oi;
    var xi = h("ComputedValue", wi);
    !(function(t2) {
      t2[t2.B = -1] = "NOT_TRACKING_", t2[t2.K = 0] = "UP_TO_DATE_", t2[t2.W = 1] = "POSSIBLY_STALE_", t2[t2.D = 2] = "STALE_";
    })(ji || (ji = {})), (function(t2) {
      t2[t2.NONE = 0] = "NONE", t2[t2.LOG = 1] = "LOG", t2[t2.BREAK = 2] = "BREAK";
    })(Oi || (Oi = {}));
    var gi = function(t2) {
      this.cause = void 0, this.cause = t2;
    };
    var Si = ["mobxGuid", "spyListeners", "enforceActions", "computedRequiresReaction", "reactionRequiresObservable", "observableRequiresReaction", "allowStateReads", "disableErrorBoundaries", "runId", "UNCHANGED", "useProxies"];
    var _i = function() {
      this.version = 6, this.UNCHANGED = {}, this.trackingDerivation = null, this.trackingContext = null, this.runId = 0, this.mobxGuid = 0, this.inBatch = 0, this.pendingUnobservations = [], this.pendingReactions = [], this.isRunningReactions = false, this.allowStateChanges = false, this.allowStateReads = true, this.enforceActions = true, this.spyListeners = [], this.globalReactionErrorHandlers = [], this.computedRequiresReaction = false, this.reactionRequiresObservable = false, this.observableRequiresReaction = false, this.disableErrorBoundaries = false, this.suppressReactionErrors = false, this.useProxies = true, this.verifyProxies = false, this.safeDescriptors = true;
    };
    var Ai = true;
    var Mi = false;
    var ki = (function() {
      var i2 = n();
      return i2.__mobxInstanceCount > 0 && !i2.__mobxGlobals && (Ai = false), i2.__mobxGlobals && i2.__mobxGlobals.version !== new _i().version && (Ai = false), Ai ? i2.__mobxGlobals ? (i2.__mobxInstanceCount += 1, i2.__mobxGlobals.UNCHANGED || (i2.__mobxGlobals.UNCHANGED = {}), i2.__mobxGlobals) : (i2.__mobxInstanceCount = 1, i2.__mobxGlobals = new _i()) : (setTimeout((function() {
        Mi || t(35);
      }), 1), new _i());
    })();
    var Ei = (function() {
      function t2(t3, n3, i2, r2) {
        void 0 === t3 && (t3 = "Reaction"), this.it = void 0, this.Wt = void 0, this.qt = void 0, this.Gt = void 0, this.q = [], this.G = [], this.P = ji.B, this.H = 0, this.U = 0, this.jt = 0, this.Nt = Oi.NONE, this.it = t3, this.Wt = n3, this.qt = i2, this.Gt = r2;
      }
      var n2 = t2.prototype;
      return n2.F = function() {
        this.tt();
      }, n2.tt = function() {
        this.isScheduled || (this.isScheduled = true, ki.pendingReactions.push(this), Rt());
      }, n2.Z = function() {
        if (!this.isDisposed) {
          Mt(), this.isScheduled = false;
          var t3 = ki.trackingContext;
          if (ki.trackingContext = this, bt(this)) {
            this.isTrackPending = true;
            try {
              this.Wt();
            } catch (t4) {
              this.Ht(t4);
            }
          }
          ki.trackingContext = t3, kt();
        }
      }, n2.track = function(t3) {
        if (!this.isDisposed) {
          Mt(), this.isRunning = true;
          var n3 = ki.trackingContext;
          ki.trackingContext = this;
          var i2 = pt(this, t3, void 0);
          ki.trackingContext = n3, this.isRunning = false, this.isTrackPending = false, this.isDisposed && yt(this), dt(i2) && this.Ht(i2.cause), kt();
        }
      }, n2.Ht = function(t3) {
        var n3 = this;
        if (this.qt) this.qt(t3, this);
        else {
          if (ki.disableErrorBoundaries) throw t3;
          ki.suppressReactionErrors || console.error("[mobx] uncaught error in '" + this + "'", t3), ki.globalReactionErrorHandlers.forEach((function(i2) {
            return i2(t3, n3);
          }));
        }
      }, n2.dispose = function() {
        this.isDisposed || (this.isDisposed = true, this.isRunning || (Mt(), yt(this), kt()));
      }, n2.nt = function(t3) {
        var n3 = this, i2 = function i3() {
          n3.dispose(), null == t3 || null == t3.removeEventListener || t3.removeEventListener("abort", i3);
        };
        return null == t3 || null == t3.addEventListener || t3.addEventListener("abort", i2), i2[$n] = this, "dispose" in Symbol && "symbol" == typeof Symbol.dispose && (i2[Symbol.dispose] = i2), i2;
      }, n2.toString = function() {
        return "Reaction[" + this.it + "]";
      }, n2.trace = function() {
      }, O(t2, [{ key: "isDisposed", get: function() {
        return p(this.jt, t2.Ut);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.Ut, n3);
      } }, { key: "isScheduled", get: function() {
        return p(this.jt, t2.Ft);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.Ft, n3);
      } }, { key: "isTrackPending", get: function() {
        return p(this.jt, t2.Xt);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.Xt, n3);
      } }, { key: "isRunning", get: function() {
        return p(this.jt, t2.zt);
      }, set: function(n3) {
        this.jt = y(this.jt, t2.zt, n3);
      } }, { key: "diffValue", get: function() {
        return p(this.jt, t2.gt) ? 1 : 0;
      }, set: function(n3) {
        this.jt = y(this.jt, t2.gt, 1 === n3);
      } }]);
    })();
    Ei.Ut = 1, Ei.Ft = 2, Ei.Xt = 4, Ei.zt = 8, Ei.gt = 16;
    var Vi = function(t2) {
      return t2();
    };
    var Ri = h("Reaction", Ei);
    var Ni = L("action");
    var Ti = L("action.bound", { bound: true });
    var Ci = L("autoAction", { autoAction: true });
    var Ii = L("autoAction.bound", { autoAction: true, bound: true });
    var Li = Ct(false);
    Object.assign(Li, Ni);
    var Pi = Ct(true);
    Object.assign(Pi, Ci), Li.bound = V(Ti), Pi.bound = V(Ii);
    var Ki = function(t2) {
      return t2();
    };
    var Bi = 0;
    var Di = (function(t2) {
      function n2() {
        var i2;
        return i2 = t2.call(this, "FLOW_CANCELLED") || this, Object.setPrototypeOf(i2, (this instanceof n2 ? this.constructor : void 0).prototype), i2.name = "FlowCancellationError", i2;
      }
      return _(n2, t2), n2.prototype.toString = function() {
        return "Error: " + this.message;
      }, n2;
    })(E(Error));
    var Wi = W("flow");
    var qi = W("flow.bound", { bound: true });
    var Gi = Object.assign((function(t2, n2) {
      if (N(n2)) return Wi.t(t2, n2);
      if (u(n2)) return R(t2, n2, Wi);
      var i2 = t2, r2 = i2.name || "<unnamed flow>", o2 = function() {
        var t3, n3 = this, u2 = arguments, o3 = ++Bi, s2 = Li(r2 + " - runid: " + o3 + " - init", i2).apply(n3, u2), f2 = void 0, c2 = new Promise((function(n4, i3) {
          function u3(t4) {
            var n5;
            f2 = void 0;
            try {
              n5 = Li(r2 + " - runid: " + o3 + " - yield " + h2++, s2.next).call(s2, t4);
            } catch (t5) {
              return i3(t5);
            }
            a2(n5);
          }
          function c3(t4) {
            var n5;
            f2 = void 0;
            try {
              n5 = Li(r2 + " - runid: " + o3 + " - yield " + h2++, s2.throw).call(s2, t4);
            } catch (t5) {
              return i3(t5);
            }
            a2(n5);
          }
          function a2(t4) {
            if (!e(null == t4 ? void 0 : t4.then)) return t4.done ? n4(t4.value) : (f2 = Promise.resolve(t4.value)).then(u3, c3);
            t4.then(a2, i3);
          }
          var h2 = 0;
          t3 = i3, u3(void 0);
        }));
        return c2.cancel = Li(r2 + " - runid: " + o3 + " - cancel", (function() {
          try {
            f2 && Ut(f2);
            var n4 = s2.return(void 0), i3 = Promise.resolve(n4.value);
            i3.then(Hn, Hn), Ut(i3), t3(new Di());
          } catch (n5) {
            t3(n5);
          }
        })), c2;
      };
      return o2.isMobXFlow = true, o2;
    }), Wi);
    Gi.bound = V(qi);
    var Hi = { has: function(t2, n2) {
      return en(t2).et(n2);
    }, get: function(t2, n2) {
      return en(t2).lt(n2);
    }, set: function(t2, n2, i2) {
      var r2;
      return !!u(n2) && (null == (r2 = en(t2).vt(n2, i2, true)) || r2);
    }, deleteProperty: function(t2, n2) {
      var i2;
      return !!u(n2) && (null == (i2 = en(t2).$t(n2, true)) || i2);
    }, defineProperty: function(t2, n2, i2) {
      var r2;
      return null == (r2 = en(t2).l(n2, i2)) || r2;
    }, ownKeys: function(t2) {
      return en(t2).ut();
    }, preventExtensions: function() {
      t(13);
    } };
    var Ui = Symbol("mobx-keys");
    var Fi = "update";
    var Xi = { get: function(t2, n2) {
      var i2 = t2[$n];
      return n2 === $n ? i2 : "length" === n2 ? i2.Jt() : "string" != typeof n2 || isNaN(n2) ? b($i, n2) ? $i[n2] : t2[n2] : i2.lt(parseInt(n2));
    }, set: function(t2, n2, i2) {
      var r2 = t2[$n];
      return "length" === n2 && r2.Yt(i2), "symbol" == typeof n2 || isNaN(n2) ? t2[n2] = i2 : r2.vt(parseInt(n2), i2), true;
    }, preventExtensions: function() {
      t(15);
    } };
    var zi = (function() {
      function n2(t2, n3, i3, r2) {
        void 0 === t2 && (t2 = "ObservableArray"), this.Qt = void 0, this.Zt = void 0, this.ct = void 0, this.j = [], this.ot = void 0, this.st = void 0, this.tn = void 0, this.dehancer = void 0, this.v = void 0, this.nn = 0, this.Qt = i3, this.Zt = r2, this.ct = new Jn(t2), this.tn = function(t3, i4) {
          return n3(t3, i4, "ObservableArray[..]");
        };
      }
      var i2 = n2.prototype;
      return i2.in = function(t2) {
        return void 0 !== this.dehancer ? this.dehancer(t2) : t2;
      }, i2.ht = function(t2) {
        return void 0 !== this.dehancer && t2.length > 0 ? t2.map(this.dehancer) : t2;
      }, i2.kt = function(t2) {
        return on(this, t2);
      }, i2.Et = function(t2, n3) {
        return void 0 === n3 && (n3 = false), n3 && t2({ observableKind: "array", object: this.v, debugObjectName: this.ct.it, type: "splice", index: 0, added: this.j.slice(), addedCount: this.j.length, removed: [], removedCount: 0 }), cn(this, t2);
      }, i2.Jt = function() {
        return this.ct.reportObserved(), this.j.length;
      }, i2.Yt = function(n3) {
        ("number" != typeof n3 || isNaN(n3) || n3 < 0) && t("Out of range: " + n3);
        var i3 = this.j.length;
        if (n3 !== i3) if (n3 > i3) {
          for (var r2 = new Array(n3 - i3), e2 = 0; e2 < n3 - i3; e2++) r2[e2] = void 0;
          this.ft(i3, 0, r2);
        } else this.ft(n3, i3 - n3);
      }, i2.rn = function(n3, i3) {
        n3 !== this.nn && t(16), this.nn += i3, this.Zt && i3 > 0 && _n(n3 + i3 + 1);
      }, i2.ft = function(t2, n3, i3) {
        var r2 = this, e2 = this.j.length;
        if (void 0 === t2 ? t2 = 0 : t2 > e2 ? t2 = e2 : t2 < 0 && (t2 = Math.max(0, e2 + t2)), n3 = 1 === arguments.length ? e2 - t2 : null == n3 ? 0 : Math.max(0, Math.min(n3, e2 - t2)), void 0 === i3 && (i3 = Dn), un(this)) {
          var u2 = sn(this, { object: this.v, type: "splice", index: t2, removedCount: n3, added: i3 });
          if (!u2) return Dn;
          n3 = u2.removedCount, i3 = u2.added;
        }
        if (i3 = 0 === i3.length ? i3 : i3.map((function(t3) {
          return r2.tn(t3, void 0);
        })), this.Zt) {
          var o2 = i3.length - n3;
          this.rn(e2, o2);
        }
        var s2 = this.en(t2, n3, i3);
        return 0 === n3 && 0 === i3.length || this.un(t2, i3, s2), this.ht(s2);
      }, i2.en = function(t2, n3, i3) {
        var r2;
        if (i3.length < 1e4) return (r2 = this.j).splice.apply(r2, [t2, n3].concat(i3));
        var e2 = this.j.slice(t2, t2 + n3), u2 = this.j.slice(t2 + n3);
        this.j.length += i3.length - n3;
        for (var o2 = 0; o2 < i3.length; o2++) this.j[t2 + o2] = i3[o2];
        for (var s2 = 0; s2 < u2.length; s2++) this.j[t2 + i3.length + s2] = u2[s2];
        return e2;
      }, i2.on = function(t2, n3, i3) {
        var r2 = !this.Qt && false, e2 = fn(this), u2 = e2 || r2 ? { observableKind: "array", object: this.v, type: Fi, debugObjectName: this.ct.it, index: t2, newValue: n3, oldValue: i3 } : null;
        this.ct.reportChanged(), e2 && an(this, u2);
      }, i2.un = function(t2, n3, i3) {
        var r2 = !this.Qt && false, e2 = fn(this), u2 = e2 || r2 ? { observableKind: "array", object: this.v, debugObjectName: this.ct.it, type: "splice", index: t2, removed: i3, added: n3, removedCount: i3.length, addedCount: n3.length } : null;
        this.ct.reportChanged(), e2 && an(this, u2);
      }, i2.lt = function(t2) {
        if (!(this.Zt && t2 >= this.j.length)) return this.ct.reportObserved(), this.in(this.j[t2]);
        console.warn("[mobx] Out of bounds read: " + t2);
      }, i2.vt = function(n3, i3) {
        var r2 = this.j;
        if (this.Zt && n3 > r2.length && t(17, n3, r2.length), n3 < r2.length) {
          var e2 = r2[n3];
          if (un(this)) {
            var u2 = sn(this, { type: Fi, object: this.v, index: n3, newValue: i3 });
            if (!u2) return;
            i3 = u2.newValue;
          }
          (i3 = this.tn(i3, e2)) !== e2 && (r2[n3] = i3, this.on(n3, i3, e2));
        } else {
          for (var o2 = new Array(n3 + 1 - r2.length), s2 = 0; s2 < o2.length - 1; s2++) o2[s2] = void 0;
          o2[o2.length - 1] = i3, this.ft(r2.length, 0, o2);
        }
      }, n2;
    })();
    var $i = { clear: function() {
      return this.splice(0);
    }, replace: function(t2) {
      var n2 = this[$n];
      return n2.ft(0, n2.j.length, t2);
    }, toJSON: function() {
      return this.slice();
    }, splice: function(t2, n2) {
      for (var i2 = arguments.length, r2 = new Array(i2 > 2 ? i2 - 2 : 0), e2 = 2; e2 < i2; e2++) r2[e2 - 2] = arguments[e2];
      var u2 = this[$n];
      switch (arguments.length) {
        case 0:
          return [];
        case 1:
          return u2.ft(t2);
        case 2:
          return u2.ft(t2, n2);
      }
      return u2.ft(t2, n2, r2);
    }, spliceWithArray: function(t2, n2, i2) {
      return this[$n].ft(t2, n2, i2);
    }, push: function() {
      for (var t2 = this[$n], n2 = arguments.length, i2 = new Array(n2), r2 = 0; r2 < n2; r2++) i2[r2] = arguments[r2];
      return t2.ft(t2.j.length, 0, i2), t2.j.length;
    }, pop: function() {
      return this.splice(Math.max(this[$n].j.length - 1, 0), 1)[0];
    }, shift: function() {
      return this.splice(0, 1)[0];
    }, unshift: function() {
      for (var t2 = this[$n], n2 = arguments.length, i2 = new Array(n2), r2 = 0; r2 < n2; r2++) i2[r2] = arguments[r2];
      return t2.ft(0, 0, i2), t2.j.length;
    }, reverse: function() {
      return ki.trackingDerivation && t(37, "reverse"), this.replace(this.slice().reverse()), this;
    }, sort: function() {
      ki.trackingDerivation && t(37, "sort");
      var n2 = this.slice();
      return n2.sort.apply(n2, arguments), this.replace(n2), this;
    }, remove: function(t2) {
      var n2 = this[$n], i2 = n2.ht(n2.j).indexOf(t2);
      return i2 > -1 && (this.splice(i2, 1), true);
    } };
    ln("at", vn), ln("concat", vn), ln("flat", vn), ln("includes", vn), ln("indexOf", vn), ln("join", vn), ln("lastIndexOf", vn), ln("slice", vn), ln("toString", vn), ln("toLocaleString", vn), ln("toSorted", vn), ln("toSpliced", vn), ln("with", vn), ln("every", dn), ln("filter", dn), ln("find", dn), ln("findIndex", dn), ln("findLast", dn), ln("findLastIndex", dn), ln("flatMap", dn), ln("forEach", dn), ln("map", dn), ln("some", dn), ln("toReversed", dn), ln("reduce", bn), ln("reduceRight", bn);
    var Ji;
    var Yi;
    var Qi = h("ObservableArrayAdministration", zi);
    var Zi = {};
    var tr = "add";
    var nr = (function() {
      function n2(n3, i3, r2) {
        var u2 = this;
        void 0 === i3 && (i3 = C), void 0 === r2 && (r2 = "ObservableMap"), this.tn = void 0, this.it = void 0, this[$n] = Zi, this.bt = void 0, this.pt = void 0, this.dt = void 0, this.ot = void 0, this.st = void 0, this.dehancer = void 0, this.tn = i3, this.it = r2, e(Map) || t(18), Vn((function() {
          u2.dt = T("ObservableMap.keys()"), u2.bt = /* @__PURE__ */ new Map(), u2.pt = /* @__PURE__ */ new Map(), n3 && u2.merge(n3);
        }));
      }
      var i2 = n2.prototype;
      return i2.et = function(t2) {
        return this.bt.has(t2);
      }, i2.has = function(t2) {
        var n3 = this;
        if (!ki.trackingDerivation) return this.et(t2);
        var i3 = this.pt.get(t2);
        if (!i3) {
          var r2 = i3 = new yi(this.et(t2), I, "ObservableMap.key?", false);
          this.pt.set(t2, r2), Dt(r2, (function() {
            return n3.pt.delete(t2);
          }));
        }
        return i3.get();
      }, i2.set = function(t2, n3) {
        var i3 = this.et(t2);
        if (un(this)) {
          var r2 = sn(this, { type: i3 ? Fi : tr, object: this, newValue: n3, name: t2 });
          if (!r2) return this;
          n3 = r2.newValue;
        }
        return i3 ? this.sn(t2, n3) : this.fn(t2, n3), this;
      }, i2.delete = function(t2) {
        var n3 = this;
        if (un(this) && !sn(this, { type: "delete", object: this, name: t2 })) return false;
        if (this.et(t2)) {
          var i3 = fn(this), r2 = i3 ? { observableKind: "map", debugObjectName: this.it, type: "delete", object: this, oldValue: this.bt.get(t2)._t, name: t2 } : null;
          return tn((function() {
            var i4;
            n3.dt.reportChanged(), null == (i4 = n3.pt.get(t2)) || i4.Mt(false), n3.bt.get(t2).Mt(void 0), n3.bt.delete(t2);
          })), i3 && an(this, r2), true;
        }
        return false;
      }, i2.sn = function(t2, n3) {
        var i3 = this.bt.get(t2);
        if ((n3 = i3.At(n3)) !== ki.UNCHANGED) {
          var r2 = fn(this), e2 = r2 ? { observableKind: "map", debugObjectName: this.it, type: Fi, object: this, oldValue: i3._t, name: t2, newValue: n3 } : null;
          i3.Mt(n3), r2 && an(this, e2);
        }
      }, i2.fn = function(t2, n3) {
        var i3 = this;
        tn((function() {
          var r3, e2 = new yi(n3, i3.tn, "ObservableMap.key", false);
          i3.bt.set(t2, e2), n3 = e2._t, null == (r3 = i3.pt.get(t2)) || r3.Mt(true), i3.dt.reportChanged();
        }));
        var r2 = fn(this);
        r2 && an(this, r2 ? { observableKind: "map", debugObjectName: this.it, type: tr, object: this, name: t2, newValue: n3 } : null);
      }, i2.get = function(t2) {
        return this.has(t2) ? this.in(this.bt.get(t2).get()) : this.in(void 0);
      }, i2.getOrInsert = function(t2, n3) {
        return this.has(t2) || this.set(t2, n3), this.get(t2);
      }, i2.getOrInsertComputed = function(t2, n3) {
        return this.has(t2) || this.set(t2, n3(t2)), this.get(t2);
      }, i2.in = function(t2) {
        return void 0 !== this.dehancer ? this.dehancer(t2) : t2;
      }, i2.keys = function() {
        return this.dt.reportObserved(), this.bt.keys();
      }, i2.values = function() {
        var t2 = this, n3 = this.keys();
        return yn({ next: function() {
          var i3 = n3.next(), r2 = i3.done;
          return { done: r2, value: r2 ? void 0 : t2.get(i3.value) };
        } });
      }, i2.entries = function() {
        var t2 = this, n3 = this.keys();
        return yn({ next: function() {
          var i3 = n3.next(), r2 = i3.done, e2 = i3.value;
          return { done: r2, value: r2 ? void 0 : [e2, t2.get(e2)] };
        } });
      }, i2[Symbol.iterator] = function() {
        return this.entries();
      }, i2.forEach = function(t2, n3) {
        for (var i3, r2 = x(this); !(i3 = r2()).done; ) {
          var e2 = i3.value;
          t2.call(n3, e2[1], e2[0], this);
        }
      }, i2.merge = function(n3) {
        var i3 = this;
        return ir(n3) && (n3 = new Map(n3)), tn((function() {
          var r2, e2;
          s(n3) ? (function(t2) {
            var n4 = Object.keys(t2);
            if (!Un) return n4;
            var i4 = Object.getOwnPropertySymbols(t2);
            return i4.length ? [].concat(n4, i4.filter((function(n5) {
              return Bn.propertyIsEnumerable.call(t2, n5);
            }))) : n4;
          })(n3).forEach((function(t2) {
            return i3.set(t2, n3[t2]);
          })) : Array.isArray(n3) ? n3.forEach((function(t2) {
            return i3.set(t2[0], t2[1]);
          })) : l(n3) ? (r2 = Object.getPrototypeOf(n3), e2 = Object.getPrototypeOf(r2), null !== Object.getPrototypeOf(e2) && t(19, n3), n3.forEach((function(t2, n4) {
            return i3.set(n4, t2);
          }))) : null != n3 && t(20, n3);
        })), this;
      }, i2.clear = function() {
        var t2 = this;
        tn((function() {
          mt((function() {
            for (var n3, i3 = x(t2.keys()); !(n3 = i3()).done; ) t2.delete(n3.value);
          }));
        }));
      }, i2.replace = function(n3) {
        var i3 = this;
        return tn((function() {
          for (var r2, e2 = (function(n4) {
            if (l(n4) || ir(n4)) return n4;
            if (Array.isArray(n4)) return new Map(n4);
            if (s(n4)) {
              var i4 = /* @__PURE__ */ new Map();
              for (var r3 in n4) i4.set(r3, n4[r3]);
              return i4;
            }
            return t(21, n4);
          })(n3), u2 = /* @__PURE__ */ new Map(), o2 = false, f2 = x(i3.bt.keys()); !(r2 = f2()).done; ) {
            var c2 = r2.value;
            if (!e2.has(c2)) if (i3.delete(c2)) o2 = true;
            else {
              var a2 = i3.bt.get(c2);
              u2.set(c2, a2);
            }
          }
          for (var h2, v2 = x(e2.entries()); !(h2 = v2()).done; ) {
            var d2 = h2.value, b2 = d2[0], p2 = d2[1], y2 = i3.bt.has(b2);
            if (i3.set(b2, p2), i3.bt.has(b2)) {
              var m2 = i3.bt.get(b2);
              u2.set(b2, m2), y2 || (o2 = true);
            }
          }
          if (!o2) if (i3.bt.size !== u2.size) i3.dt.reportChanged();
          else for (var w2 = i3.bt.keys(), j2 = u2.keys(), O2 = w2.next(), g2 = j2.next(); !O2.done; ) {
            if (O2.value !== g2.value) {
              i3.dt.reportChanged();
              break;
            }
            O2 = w2.next(), g2 = j2.next();
          }
          i3.bt = u2;
        })), this;
      }, i2.toString = function() {
        return "[object ObservableMap]";
      }, i2.toJSON = function() {
        return Array.from(this);
      }, i2.Et = function(t2) {
        return cn(this, t2);
      }, i2.kt = function(t2) {
        return on(this, t2);
      }, O(n2, [{ key: "size", get: function() {
        return this.dt.reportObserved(), this.bt.size;
      } }, { key: Symbol.toStringTag, get: function() {
        return "Map";
      } }]);
    })();
    var ir = h("ObservableMap", nr);
    var rr = {};
    var er = (function() {
      function n2(n3, i3, r2) {
        var u2 = this;
        void 0 === i3 && (i3 = C), void 0 === r2 && (r2 = "ObservableSet"), this.it = void 0, this[$n] = rr, this.bt = /* @__PURE__ */ new Set(), this.ct = void 0, this.st = void 0, this.ot = void 0, this.dehancer = void 0, this.tn = void 0, this.it = r2, e(Set) || t(22), this.tn = function(t2, n4) {
          return i3(t2, n4, r2);
        }, Vn((function() {
          u2.ct = T(u2.it), n3 && u2.replace(n3);
        }));
      }
      var i2 = n2.prototype;
      return i2.in = function(t2) {
        return void 0 !== this.dehancer ? this.dehancer(t2) : t2;
      }, i2.clear = function() {
        var t2 = this;
        tn((function() {
          mt((function() {
            for (var n3, i3 = x(t2.bt.values()); !(n3 = i3()).done; ) t2.delete(n3.value);
          }));
        }));
      }, i2.forEach = function(t2, n3) {
        for (var i3, r2 = x(this); !(i3 = r2()).done; ) {
          var e2 = i3.value;
          t2.call(n3, e2, e2, this);
        }
      }, i2.add = function(t2) {
        var n3 = this;
        if (un(this)) {
          var i3 = sn(this, { type: tr, object: this, newValue: t2 });
          if (!i3) return this;
          t2 = i3.newValue;
        }
        if (!this.has(t2)) {
          tn((function() {
            n3.bt.add(n3.tn(t2, void 0)), n3.ct.reportChanged();
          }));
          var r2 = fn(this);
          r2 && an(this, r2 ? { observableKind: "set", debugObjectName: this.it, type: tr, object: this, newValue: t2 } : null);
        }
        return this;
      }, i2.delete = function(t2) {
        var n3 = this;
        if (un(this) && !sn(this, { type: "delete", object: this, oldValue: t2 })) return false;
        if (this.has(t2)) {
          var i3 = fn(this), r2 = i3 ? { observableKind: "set", debugObjectName: this.it, type: "delete", object: this, oldValue: t2 } : null;
          return tn((function() {
            n3.ct.reportChanged(), n3.bt.delete(t2);
          })), i3 && an(this, r2), true;
        }
        return false;
      }, i2.has = function(t2) {
        return this.ct.reportObserved(), this.bt.has(this.in(t2));
      }, i2.entries = function() {
        var t2 = this.values();
        return mn({ next: function() {
          var n3 = t2.next(), i3 = n3.value, r2 = n3.done;
          return r2 ? { value: void 0, done: r2 } : { value: [i3, i3], done: r2 };
        } });
      }, i2.keys = function() {
        return this.values();
      }, i2.values = function() {
        this.ct.reportObserved();
        var t2 = this, n3 = this.bt.values();
        return mn({ next: function() {
          var i3 = n3.next(), r2 = i3.done;
          return r2 ? { value: void 0, done: r2 } : { value: t2.in(i3.value), done: r2 };
        } });
      }, i2.intersection = function(t2) {
        return v(t2) && !ur(t2) ? t2.intersection(this) : new Set(this).intersection(t2);
      }, i2.union = function(t2) {
        return v(t2) && !ur(t2) ? t2.union(this) : new Set(this).union(t2);
      }, i2.difference = function(t2) {
        return new Set(this).difference(t2);
      }, i2.symmetricDifference = function(t2) {
        return v(t2) && !ur(t2) ? t2.symmetricDifference(this) : new Set(this).symmetricDifference(t2);
      }, i2.isSubsetOf = function(t2) {
        return new Set(this).isSubsetOf(t2);
      }, i2.isSupersetOf = function(t2) {
        return new Set(this).isSupersetOf(t2);
      }, i2.isDisjointFrom = function(t2) {
        return v(t2) && !ur(t2) ? t2.isDisjointFrom(this) : new Set(this).isDisjointFrom(t2);
      }, i2.replace = function(n3) {
        var i3 = this;
        return ur(n3) && (n3 = new Set(n3)), tn((function() {
          Array.isArray(n3) || v(n3) ? (i3.clear(), n3.forEach((function(t2) {
            return i3.add(t2);
          }))) : null != n3 && t("Cannot initialize set from " + n3);
        })), this;
      }, i2.Et = function(t2) {
        return cn(this, t2);
      }, i2.kt = function(t2) {
        return on(this, t2);
      }, i2.toJSON = function() {
        return Array.from(this);
      }, i2.toString = function() {
        return "[object ObservableSet]";
      }, i2[Symbol.iterator] = function() {
        return this.values();
      }, O(n2, [{ key: "size", get: function() {
        return this.ct.reportObserved(), this.bt.size;
      } }, { key: Symbol.toStringTag, get: function() {
        return "Set";
      } }]);
    })();
    var ur = h("ObservableSet", er);
    var or = /* @__PURE__ */ Object.create(null);
    var sr = (function() {
      function n2(t2, n3, i3, r2) {
        void 0 === n3 && (n3 = /* @__PURE__ */ new Map()), void 0 === r2 && (r2 = ti), this.h = void 0, this.j = void 0, this.it = void 0, this.cn = void 0, this.dt = void 0, this.st = void 0, this.ot = void 0, this.v = void 0, this.p = void 0, this.an = void 0, this.hn = void 0, this.O = void 0, this._ = void 0, this.h = t2, this.j = n3, this.it = i3, this.cn = r2, this.dt = new Jn("ObservableObject.keys"), this.p = s(this.h);
      }
      var i2 = n2.prototype;
      return i2.g = function(t2) {
        var n3, i3;
        return (null != (n3 = null != (i3 = this.j.get(t2)) ? i3 : this.yt(t2)) ? n3 : this.wt(t2)).get();
      }, i2.yt = function(t2) {
        var n3, i3 = null == (n3 = this.O) ? void 0 : n3.get(t2);
        if (i3) {
          this.O.delete(t2), 0 === this.O.size && (this.O = void 0);
          var r2 = i3();
          return this.j.set(t2, r2), r2;
        }
      }, i2.wt = function(t2) {
        var n3, i3 = null == (n3 = this._) ? void 0 : n3.get(t2);
        if (i3) {
          this._.delete(t2), 0 === this._.size && (this._ = void 0);
          var r2 = i3();
          return this.j.set(t2, r2), r2;
        }
      }, i2.A = function(t2, n3) {
        var i3, r2, e2 = null != (i3 = null != (r2 = this.j.get(t2)) ? r2 : this.yt(t2)) ? i3 : this.wt(t2);
        if (e2 instanceof wi) return e2.set(n3), true;
        if (un(this)) {
          var u2 = sn(this, { type: Fi, object: this.v || this.h, name: t2, newValue: n3 });
          if (!u2) return null;
          n3 = u2.newValue;
        }
        if ((n3 = e2.At(n3)) !== ki.UNCHANGED) {
          var o2 = fn(this), s2 = o2 ? { type: Fi, observableKind: "object", debugObjectName: this.it, object: this.v || this.h, oldValue: e2._t, name: t2, newValue: n3 } : null;
          e2.Mt(n3), o2 && an(this, s2);
        }
        return true;
      }, i2.lt = function(t2) {
        return ki.trackingDerivation && !b(this.h, t2) && this.et(t2), this.h[t2];
      }, i2.vt = function(t2, n3, i3) {
        return void 0 === i3 && (i3 = false), b(this.h, t2) ? this.j.has(t2) ? this.A(t2, n3) : i3 ? Reflect.set(this.h, t2, n3) : (this.h[t2] = n3, true) : this.s(t2, { value: n3, enumerable: true, writable: true, configurable: true }, this.cn, i3);
      }, i2.et = function(t2) {
        if (!ki.trackingDerivation) return t2 in this.h;
        this.hn || (this.hn = /* @__PURE__ */ new Map());
        var n3 = this.hn.get(t2);
        return n3 || (n3 = new yi(t2 in this.h, I, "ObservableObject.key?", false), this.hn.set(t2, n3)), n3.get();
      }, i2.o = function(n3, i3) {
        if (true === i3 && (i3 = this.cn), false !== i3) {
          if (!(n3 in this.h)) {
            var r2;
            if (null != (r2 = this.h[zn]) && r2[n3]) return;
            t(1, i3.i, this.it + "." + n3.toString());
          }
          for (var e2 = this.h; e2 && e2 !== Bn; ) {
            var u2 = Pn(e2, n3);
            if (u2) {
              var o2 = i3.o(this, n3, u2, e2);
              if (0 === o2) return;
              if (1 === o2) break;
            }
            e2 = Object.getPrototypeOf(e2);
          }
          xn(this, 0, n3);
        }
      }, i2.s = function(t2, n3, i3, r2) {
        if (void 0 === r2 && (r2 = false), true === i3 && (i3 = this.cn), false === i3) return this.l(t2, n3, r2);
        var e2 = i3.s(this, t2, n3, r2);
        return e2 && xn(this, 0, t2), e2;
      }, i2.l = function(t2, n3, i3) {
        void 0 === i3 && (i3 = false);
        try {
          Mt();
          var r2 = this.$t(t2);
          if (!r2) return r2;
          if (un(this)) {
            var e2 = sn(this, { object: this.v || this.h, name: t2, type: tr, newValue: n3.value });
            if (!e2) return null;
            var u2 = e2.newValue;
            n3.value !== u2 && (n3 = g({}, n3, { value: u2 }));
          }
          if (i3) {
            if (!Reflect.defineProperty(this.h, t2, n3)) return false;
          } else Kn(this.h, t2, n3);
          this.ln(t2, n3.value);
        } finally {
          kt();
        }
        return true;
      }, i2.S = function(t2, n3, i3, r2) {
        void 0 === r2 && (r2 = false);
        try {
          Mt();
          var e2 = this.$t(t2);
          if (!e2) return e2;
          if (un(this)) {
            var u2 = sn(this, { object: this.v || this.h, name: t2, type: tr, newValue: n3 });
            if (!u2) return null;
            n3 = u2.newValue;
          }
          var o2 = jn(t2), s2 = { configurable: !ki.safeDescriptors || this.p, enumerable: true, get: o2.get, set: o2.set };
          if (r2) {
            if (!Reflect.defineProperty(this.h, t2, s2)) return false;
          } else Kn(this.h, t2, s2);
          var f2 = new yi(n3, i3, "ObservableObject.key", false);
          this.j.set(t2, f2), this.ln(t2, f2._t);
        } finally {
          kt();
        }
        return true;
      }, i2.m = function(t2, n3, i3) {
        void 0 === i3 && (i3 = false);
        try {
          Mt();
          var r2 = this.$t(t2);
          if (!r2) return r2;
          if (un(this) && !sn(this, { object: this.v || this.h, name: t2, type: tr, newValue: void 0 })) return null;
          n3.name || (n3.name = "ObservableObject.key"), n3.context = this.v || this.h;
          var e2 = jn(t2), u2 = { configurable: !ki.safeDescriptors || this.p, enumerable: false, get: e2.get, set: e2.set };
          if (i3) {
            if (!Reflect.defineProperty(this.h, t2, u2)) return false;
          } else Kn(this.h, t2, u2);
          this.j.set(t2, new wi(n3)), this.ln(t2, void 0);
        } finally {
          kt();
        }
        return true;
      }, i2.$t = function(t2, n3) {
        if (void 0 === n3 && (n3 = false), !b(this.h, t2)) return true;
        if (un(this) && !sn(this, { object: this.v || this.h, name: t2, type: "remove" })) return null;
        try {
          var i3;
          Mt();
          var r2, e2 = fn(this), u2 = this.j.get(t2), o2 = void 0;
          if (!u2 && e2 && (o2 = null == (r2 = Pn(this.h, t2)) ? void 0 : r2.value), n3) {
            if (!Reflect.deleteProperty(this.h, t2)) return false;
          } else delete this.h[t2];
          u2 && (this.j.delete(t2), u2 instanceof yi && (o2 = u2._t), Vt(u2)), this.dt.reportChanged(), null == (i3 = this.hn) || null == (i3 = i3.get(t2)) || i3.set(t2 in this.h), e2 && e2 && an(this, { type: "remove", observableKind: "object", object: this.v || this.h, debugObjectName: this.it, oldValue: o2, name: t2 });
        } finally {
          kt();
        }
        return true;
      }, i2.Et = function(t2) {
        return cn(this, t2);
      }, i2.kt = function(t2) {
        return on(this, t2);
      }, i2.ln = function(t2, n3) {
        var i3, r2 = fn(this);
        r2 && r2 && an(this, r2 ? { type: tr, observableKind: "object", debugObjectName: this.it, object: this.v || this.h, name: t2, newValue: n3 } : null), null == (i3 = this.hn) || null == (i3 = i3.get(t2)) || i3.set(true), this.dt.reportChanged();
      }, i2.ut = function() {
        return this.dt.reportObserved(), Fn(this.h);
      }, i2.rt = function() {
        return this.dt.reportObserved(), Object.keys(this.h);
      }, n2;
    })();
    var fr = h("ObservableObjectAdministration", sr);
    var cr = gn(0);
    var ar = (function() {
      var t2 = false, n2 = {};
      return Object.defineProperty(n2, "0", { set: function() {
        t2 = true;
      } }), Object.create(n2)[0] = 1, false === t2;
    })();
    var hr = 0;
    var lr = function() {
    };
    Ji = lr, Yi = Array.prototype, Object.setPrototypeOf ? Object.setPrototypeOf(Ji.prototype, Yi) : void 0 !== Ji.prototype.__proto__ ? Ji.prototype.__proto__ = Yi : Ji.prototype = Yi;
    var vr = (function(t2) {
      function n2(n3, i3, r2, e2) {
        var u2;
        return void 0 === r2 && (r2 = "ObservableArray"), void 0 === e2 && (e2 = false), u2 = t2.call(this) || this, Vn((function() {
          var t3 = new zi(r2, i3, e2, true);
          t3.v = u2, a(u2, $n, t3), n3 && n3.length && u2.spliceWithArray(0, 0, n3), ar && Object.defineProperty(u2, "0", cr);
        })), u2;
      }
      _(n2, t2);
      var i2 = n2.prototype;
      return i2.concat = function() {
        this[$n].ct.reportObserved();
        for (var t3 = arguments.length, n3 = new Array(t3), i3 = 0; i3 < t3; i3++) n3[i3] = arguments[i3];
        return Array.prototype.concat.apply(this.slice(), n3.map((function(t4) {
          return pn(t4) ? t4.slice() : t4;
        })));
      }, i2[Symbol.iterator] = function() {
        var t3 = this, n3 = 0;
        return Tn({ next: function() {
          return n3 < t3.length ? { value: t3[n3++], done: false } : { done: true, value: void 0 };
        } });
      }, O(n2, [{ key: "length", get: function() {
        return this[$n].Jt();
      }, set: function(t3) {
        this[$n].Yt(t3);
      } }, { key: Symbol.toStringTag, get: function() {
        return "Array";
      } }]);
    })(lr);
    Object.entries($i).forEach((function(t2) {
      var n2 = t2[0];
      "concat" !== n2 && c(vr.prototype, n2, t2[1]);
    })), _n(1e3);
    var dr;
    var br = Bn.toString;
    var pr = (null == (dr = n().Iterator) ? void 0 : dr.prototype) || {};
    ["Symbol", "Map", "Set"].forEach((function(i2) {
      void 0 === n()[i2] && t("MobX requires global '" + i2 + "' to be available or polyfilled");
    })), "object" == typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ && __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({ spy: Tt, extras: { getDebugName: En }, $mobx: $n }), exports2.$mobx = $n, exports2.FlowCancellationError = Di, exports2.ObservableMap = nr, exports2.ObservableSet = er, exports2.Reaction = Ei, exports2._allowStateChanges = ht, exports2._allowStateChangesInsideComputed = It, exports2._allowStateReadsEnd = xt, exports2._allowStateReadsStart = Ot, exports2._autoAction = Pi, exports2._endAction = at, exports2._getAdministration = kn, exports2._getGlobalState = function() {
      return ki;
    }, exports2._interceptReads = function(t2, n2, i2) {
      var r2;
      return ir(t2) || pn(t2) || mi(t2) ? r2 = kn(t2) : On(t2) && (r2 = kn(t2, n2)), r2.dehancer = "function" == typeof n2 ? n2 : i2, function() {
        r2.dehancer = void 0;
      };
    }, exports2._isComputingDerivation = function() {
      return null !== ki.trackingDerivation;
    }, exports2._resetGlobalState = function() {
      var t2 = new _i();
      for (var n2 in t2) -1 === Si.indexOf(n2) && (ki[n2] = t2[n2]);
      ki.allowStateChanges = !ki.enforceActions;
    }, exports2._startAction = ct, exports2.action = Li, exports2.autorun = Pt, exports2.comparer = Qn, exports2.computed = li, exports2.configure = function(i2) {
      true === i2.isolateGlobalState && (function() {
        if ((ki.pendingReactions.length || ki.inBatch || ki.isRunningReactions) && t(36), Mi = true, Ai) {
          var i3 = n();
          0 == --i3.__mobxInstanceCount && (i3.__mobxGlobals = void 0), ki = new _i();
        }
      })();
      var r2, e2, u2 = i2.useProxies, o2 = i2.enforceActions;
      if (void 0 !== u2 && (ki.useProxies = "always" === u2 || "never" !== u2 && "undefined" != typeof Proxy), "ifavailable" === u2 && (ki.verifyProxies = true), void 0 !== o2) {
        var s2 = "always" === o2 ? "always" : "observed" === o2;
        ki.enforceActions = s2, ki.allowStateChanges = true !== s2 && "always" !== s2;
      }
      ["computedRequiresReaction", "reactionRequiresObservable", "observableRequiresReaction", "disableErrorBoundaries", "safeDescriptors"].forEach((function(t2) {
        t2 in i2 && (ki[t2] = !!i2[t2]);
      })), ki.allowStateReads = !ki.observableRequiresReaction, i2.reactionScheduler && (r2 = i2.reactionScheduler, e2 = Vi, Vi = function(t2) {
        return r2((function() {
          return e2(t2);
        }));
      });
    }, exports2.createAtom = T, exports2.defineProperty = function(n2, i2, r2) {
      if (On(n2)) return n2[$n].l(i2, r2);
      t(39);
    }, exports2.entries = function(n2) {
      return On(n2) ? Jt(n2).map((function(t2) {
        return [t2, n2[t2]];
      })) : ir(n2) ? Jt(n2).map((function(t2) {
        return [t2, n2.get(t2)];
      })) : ur(n2) ? Array.from(n2.entries()) : pn(n2) ? n2.map((function(t2, n3) {
        return [n3, t2];
      })) : void t(7);
    }, exports2.extendObservable = qt, exports2.flow = Gi, exports2.flowResult = function(t2) {
      return t2;
    }, exports2.get = function(n2, i2) {
      if (Yt(n2, i2)) return On(n2) ? n2[$n].lt(i2) : ir(n2) ? n2.get(i2) : pn(n2) ? n2[i2] : void t(11);
    }, exports2.getAtom = Mn, exports2.getDebugName = En, exports2.getDependencyTree = function(t2, n2) {
      return Gt(Mn(t2, n2));
    }, exports2.getObserverTree = function(t2, n2) {
      return Ht(Mn(t2, n2));
    }, exports2.has = Yt, exports2.intercept = function(t2, n2, i2) {
      return e(i2) ? (function(t3, n3, i3) {
        return kn(t3, n3).kt(i3);
      })(t2, n2, i2) : (function(t3, n3) {
        return kn(t3).kt(n3);
      })(t2, n2);
    }, exports2.isAction = Lt, exports2.isBoxedObservable = mi, exports2.isComputed = function(t2) {
      return Xt(t2);
    }, exports2.isComputedProp = function(t2, n2) {
      return Xt(t2, n2);
    }, exports2.isFlow = Ft, exports2.isFlowCancellationError = function(t2) {
      return t2 instanceof Di;
    }, exports2.isObservable = $t, exports2.isObservableArray = pn, exports2.isObservableMap = ir, exports2.isObservableObject = On, exports2.isObservableProp = function(t2, n2) {
      return zt(t2, n2);
    }, exports2.isObservableSet = ur, exports2.keys = Jt, exports2.makeAutoObservable = function(t2, n2, i2) {
      return s(t2) ? qt(t2, t2, n2, i2) : (Vn((function() {
        var r2 = wn(t2, i2)[$n];
        if (!t2[Ui]) {
          var e2 = Object.getPrototypeOf(t2), u2 = new Set([].concat(Fn(t2), Fn(e2)));
          u2.delete("constructor"), u2.delete($n), c(e2, Ui, u2);
        }
        t2[Ui].forEach((function(t3) {
          return r2.o(t3, !n2 || !(t3 in n2) || n2[t3]);
        }));
      })), t2);
    }, exports2.makeObservable = function(t2, n2, i2) {
      return Vn((function() {
        var r2 = wn(t2, i2)[$n];
        null != n2 || (n2 = (function(t3) {
          return b(t3, zn) || c(t3, zn, g({}, t3[zn])), t3[zn];
        })(t2)), Fn(n2).forEach((function(t3) {
          return r2.o(t3, n2[t3]);
        }));
      })), t2;
    }, exports2.observable = ci, exports2.observe = function(t2, n2, i2, r2) {
      return e(i2) ? (function(t3, n3, i3, r3) {
        return kn(t3, n3).Et(i3, r3);
      })(t2, n2, i2, r2) : (function(t3, n3, i3) {
        return kn(t3).Et(n3, i3);
      })(t2, n2, i2);
    }, exports2.onBecomeObserved = Bt, exports2.onBecomeUnobserved = Dt, exports2.onReactionError = function(t2) {
      return ki.globalReactionErrorHandlers.push(t2), function() {
        var n2 = ki.globalReactionErrorHandlers.indexOf(t2);
        n2 >= 0 && ki.globalReactionErrorHandlers.splice(n2, 1);
      };
    }, exports2.override = Zn, exports2.ownKeys = Qt, exports2.reaction = function(t2, n2, i2) {
      function r2() {
        if (b2 = false, !y2.isDisposed) {
          var n3 = false, r3 = c2;
          y2.track((function() {
            var i3 = ht(false, (function() {
              return t2(y2);
            }));
            n3 = d2 || !p2(c2, i3), c2 = i3;
          })), (d2 && i2.fireImmediately || !d2 && n3) && h2(c2, r3, y2), d2 = false;
        }
      }
      var e2, u2, o2;
      void 0 === i2 && (i2 = Wn);
      var s2, f2, c2, a2 = null != (e2 = i2.name) ? e2 : "Reaction", h2 = Li(a2, i2.onError ? (s2 = i2.onError, f2 = n2, function() {
        try {
          return f2.apply(this, arguments);
        } catch (t3) {
          s2.call(this, t3);
        }
      }) : n2), l2 = !i2.scheduler && !i2.delay, v2 = Kt(i2), d2 = true, b2 = false, p2 = i2.compareStructural ? Qn.structural : i2.equals || Qn.default, y2 = new Ei(a2, (function() {
        d2 || l2 ? r2() : b2 || (b2 = true, v2(r2));
      }), i2.onError, i2.requiresObservable);
      return null != (u2 = i2) && null != (u2 = u2.signal) && u2.aborted || y2.tt(), y2.nt(null == (o2 = i2) ? void 0 : o2.signal);
    }, exports2.remove = function(n2, i2) {
      On(n2) ? n2[$n].$t(i2) : ir(n2) || ur(n2) ? n2.delete(i2) : pn(n2) ? ("number" != typeof i2 && (i2 = parseInt(i2, 10)), n2.splice(i2, 1)) : t(9);
    }, exports2.runInAction = It, exports2.set = function n2(i2, r2, e2) {
      if (2 !== arguments.length || ur(i2)) On(i2) ? i2[$n].vt(r2, e2) : ir(i2) ? i2.set(r2, e2) : ur(i2) ? i2.add(r2) : pn(i2) ? ("number" != typeof r2 && (r2 = parseInt(r2, 10)), r2 < 0 && t("Invalid index: '" + r2 + "'"), Mt(), r2 >= i2.length && (i2.length = r2 + 1), i2[r2] = e2, kt()) : t(8);
      else {
        Mt();
        var u2 = r2;
        try {
          for (var o2 in u2) n2(i2, o2, u2[o2]);
        } finally {
          kt();
        }
      }
    }, exports2.spy = Tt, exports2.toJS = function(t2) {
      return (function t3(n2, i2) {
        if (null == n2 || "object" != typeof n2 || n2 instanceof Date || !$t(n2)) return n2;
        if (mi(n2) || xi(n2)) return t3(n2.get(), i2);
        if (i2.has(n2)) return i2.get(n2);
        if (pn(n2)) {
          var r2 = Zt(i2, n2, new Array(n2.length));
          return n2.forEach((function(n3, e3) {
            r2[e3] = t3(n3, i2);
          })), r2;
        }
        if (ur(n2)) {
          var e2 = Zt(i2, n2, /* @__PURE__ */ new Set());
          return n2.forEach((function(n3) {
            e2.add(t3(n3, i2));
          })), e2;
        }
        if (ir(n2)) {
          var u2 = Zt(i2, n2, /* @__PURE__ */ new Map());
          return n2.forEach((function(n3, r3) {
            u2.set(r3, t3(n3, i2));
          })), u2;
        }
        var o2 = Zt(i2, n2, {});
        return Qt(n2).forEach((function(r3) {
          Bn.propertyIsEnumerable.call(n2, r3) && (o2[r3] = t3(n2[r3], i2));
        })), o2;
      })(t2, /* @__PURE__ */ new Map());
    }, exports2.trace = function() {
    }, exports2.transaction = tn, exports2.untracked = mt, exports2.values = function(n2) {
      return On(n2) ? Jt(n2).map((function(t2) {
        return n2[t2];
      })) : ir(n2) ? Jt(n2).map((function(t2) {
        return n2.get(t2);
      })) : ur(n2) ? Array.from(n2.values()) : pn(n2) ? n2.slice() : void t(6);
    }, exports2.when = function(t2, n2, i2) {
      return 1 === arguments.length || n2 && "object" == typeof n2 ? rn(t2, n2) : nn(t2, n2, i2 || {});
    };
  }
});

// ../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/mobx.cjs.development.js
var require_mobx_cjs_development = __commonJS({
  "../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/mobx.cjs.development.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var niceErrors = {
      0: "Invalid value for configuration 'enforceActions', expected 'never', 'always' or 'observed'",
      1: function _(annotationType, key) {
        return "Cannot apply '" + annotationType + "' to '" + key.toString() + "': Field not found.";
      },
      /*
      2(prop) {
          return `invalid decorator for '${prop.toString()}'`
      },
      3(prop) {
          return `Cannot decorate '${prop.toString()}': action can only be used on properties with a function value.`
      },
      4(prop) {
          return `Cannot decorate '${prop.toString()}': computed can only be used on getter properties.`
      },
      */
      5: "'keys()' can only be used on observable objects, arrays, sets and maps",
      6: "'values()' can only be used on observable objects, arrays, sets and maps",
      7: "'entries()' can only be used on observable objects, arrays and maps",
      8: "'set()' can only be used on observable objects, arrays and maps",
      9: "'remove()' can only be used on observable objects, arrays and maps",
      10: "'has()' can only be used on observable objects, arrays and maps",
      11: "'get()' can only be used on observable objects, arrays and maps",
      12: "Invalid annotation",
      13: "Dynamic observable objects cannot be frozen. If you're passing observables to 3rd party component/function that calls Object.freeze, pass copy instead: toJS(observable)",
      14: "Intercept handlers should return nothing or a change object",
      15: "Observable arrays cannot be frozen. If you're passing observables to 3rd party component/function that calls Object.freeze, pass copy instead: toJS(observable)",
      16: "Modification exception: the internal structure of an observable array was changed.",
      17: function _(index, length) {
        return "[mobx.array] Index out of bounds, " + index + " is larger than " + length;
      },
      18: "mobx.map requires Map polyfill for the current browser. Check babel-polyfill or core-js/es6/map.js",
      19: function _(other) {
        return "Cannot initialize from classes that inherit from Map: " + other.constructor.name;
      },
      20: function _(other) {
        return "Cannot initialize map from " + other;
      },
      21: function _(dataStructure) {
        return "Cannot convert to map from '" + dataStructure + "'";
      },
      22: "mobx.set requires Set polyfill for the current browser. Check babel-polyfill or core-js/es6/set.js",
      23: "It is not possible to get index atoms from arrays",
      24: function _(thing) {
        return "Cannot obtain administration from " + thing;
      },
      25: function _(property, name) {
        return "the entry '" + property + "' does not exist in the observable map '" + name + "'";
      },
      26: "please specify a property",
      27: function _(property, name) {
        return "no observable property '" + property.toString() + "' found on the observable object '" + name + "'";
      },
      28: function _(thing) {
        return "Cannot obtain atom from " + thing;
      },
      29: "Expecting some object",
      30: "invalid action stack. did you forget to finish an action?",
      31: "missing option for computed: get",
      32: function _(name, derivation) {
        return "Cycle detected in computation " + name + ": " + derivation;
      },
      33: function _(name) {
        return "The setter of computed value '" + name + "' is trying to update itself. Did you intend to update an _observable_ value, instead of the computed property?";
      },
      34: function _(name) {
        return "[ComputedValue '" + name + "'] It is not possible to assign a new value to a computed value.";
      },
      35: "There are multiple, different versions of MobX active. Make sure MobX is loaded only once or use `configure({ isolateGlobalState: true })`",
      36: "isolateGlobalState should be called before MobX is running any reactions",
      37: function _(method) {
        return "[mobx] `observableArray." + method + "()` mutates the array in-place, which is not allowed inside a derivation. Use `array.slice()." + method + "()` instead";
      },
      38: "'ownKeys()' can only be used on observable objects",
      39: "'defineProperty()' can only be used on observable objects"
    };
    var errors = niceErrors;
    function die(error) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      {
        var e = typeof error === "string" ? error : errors[error];
        if (typeof e === "function") e = e.apply(null, args);
        throw new Error("[MobX] " + e);
      }
    }
    var mockGlobal = {};
    function getGlobal() {
      if (typeof globalThis !== "undefined") {
        return globalThis;
      }
      if (typeof window !== "undefined") {
        return window;
      }
      if (typeof global !== "undefined") {
        return global;
      }
      if (typeof self !== "undefined") {
        return self;
      }
      return mockGlobal;
    }
    var assign = Object.assign;
    var getDescriptor = Object.getOwnPropertyDescriptor;
    var defineProperty = Object.defineProperty;
    var objectPrototype = Object.prototype;
    var EMPTY_ARRAY = [];
    Object.freeze(EMPTY_ARRAY);
    var EMPTY_OBJECT = {};
    Object.freeze(EMPTY_OBJECT);
    var hasProxy = typeof Proxy !== "undefined";
    var plainObjectString = /* @__PURE__ */ Object.toString();
    function assertProxies() {
      if (!hasProxy) {
        die("`Proxy` objects are not available in the current environment. Please configure MobX to enable a fallback implementation.`");
      }
    }
    function warnAboutProxyRequirement(msg) {
      if (globalState.verifyProxies) {
        die("MobX is currently configured to be able to run in ES5 mode, but in ES5 MobX won't be able to " + msg);
      }
    }
    function getNextId() {
      return ++globalState.mobxGuid;
    }
    function once(func) {
      var invoked = false;
      return function() {
        if (invoked) {
          return;
        }
        invoked = true;
        return func.apply(this, arguments);
      };
    }
    var noop = function noop2() {
    };
    function isFunction(fn) {
      return typeof fn === "function";
    }
    function isStringish(value) {
      var t = typeof value;
      switch (t) {
        case "string":
        case "symbol":
        case "number":
          return true;
      }
      return false;
    }
    function isObject(value) {
      return value !== null && typeof value === "object";
    }
    function isPlainObject(value) {
      if (!isObject(value)) {
        return false;
      }
      var proto = Object.getPrototypeOf(value);
      if (proto == null) {
        return true;
      }
      var protoConstructor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
      return typeof protoConstructor === "function" && protoConstructor.toString() === plainObjectString;
    }
    function isGenerator(obj) {
      var constructor = obj == null ? void 0 : obj.constructor;
      if (!constructor) {
        return false;
      }
      if ("GeneratorFunction" === constructor.name || "GeneratorFunction" === constructor.displayName) {
        return true;
      }
      return false;
    }
    function addHiddenProp(object, propName, value) {
      defineProperty(object, propName, {
        enumerable: false,
        writable: true,
        configurable: true,
        value
      });
    }
    function addHiddenFinalProp(object, propName, value) {
      defineProperty(object, propName, {
        enumerable: false,
        writable: false,
        configurable: true,
        value
      });
    }
    function createInstanceofPredicate(name, theClass) {
      var propName = "isMobX" + name;
      theClass.prototype[propName] = true;
      return function(x) {
        return isObject(x) && x[propName] === true;
      };
    }
    function isES6Map(thing) {
      return thing != null && Object.prototype.toString.call(thing) === "[object Map]";
    }
    function isPlainES6Map(thing) {
      var mapProto = Object.getPrototypeOf(thing);
      var objectProto = Object.getPrototypeOf(mapProto);
      var nullProto = Object.getPrototypeOf(objectProto);
      return nullProto === null;
    }
    function isES6Set(thing) {
      return thing != null && Object.prototype.toString.call(thing) === "[object Set]";
    }
    var hasGetOwnPropertySymbols = typeof Object.getOwnPropertySymbols !== "undefined";
    function getPlainObjectKeys(object) {
      var keys2 = Object.keys(object);
      if (!hasGetOwnPropertySymbols) {
        return keys2;
      }
      var symbols = Object.getOwnPropertySymbols(object);
      if (!symbols.length) {
        return keys2;
      }
      return [].concat(keys2, symbols.filter(function(s) {
        return objectPrototype.propertyIsEnumerable.call(object, s);
      }));
    }
    var ownKeys = typeof Reflect !== "undefined" && Reflect.ownKeys ? Reflect.ownKeys : hasGetOwnPropertySymbols ? function(obj) {
      return Object.getOwnPropertyNames(obj).concat(Object.getOwnPropertySymbols(obj));
    } : (
      /* istanbul ignore next */
      Object.getOwnPropertyNames
    );
    function stringifyKey(key) {
      if (typeof key === "string") {
        return key;
      }
      if (typeof key === "symbol") {
        return key.toString();
      }
      return new String(key).toString();
    }
    function toPrimitive(value) {
      return value === null ? null : typeof value === "object" ? "" + value : value;
    }
    function hasProp(target, prop) {
      return objectPrototype.hasOwnProperty.call(target, prop);
    }
    var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors2(target) {
      var res = {};
      ownKeys(target).forEach(function(key) {
        res[key] = getDescriptor(target, key);
      });
      return res;
    };
    function getFlag(flags, mask) {
      return !!(flags & mask);
    }
    function setFlag(flags, mask, newValue) {
      if (newValue) {
        flags |= mask;
      } else {
        flags &= ~mask;
      }
      return flags;
    }
    function _arrayLikeToArray(r, a) {
      (null == a || a > r.length) && (a = r.length);
      for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
      return n;
    }
    function _construct(t, e, r) {
      if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
      var o = [null];
      o.push.apply(o, e);
      var p = new (t.bind.apply(t, o))();
      return r && _setPrototypeOf(p, r.prototype), p;
    }
    function _defineProperties(e, r) {
      for (var t = 0; t < r.length; t++) {
        var o = r[t];
        o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey(o.key), o);
      }
    }
    function _createClass(e, r, t) {
      return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
        writable: false
      }), e;
    }
    function _createForOfIteratorHelperLoose(r, e) {
      var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
      if (t) return (t = t.call(r)).next.bind(t);
      if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {
        t && (r = t);
        var o = 0;
        return function() {
          return o >= r.length ? {
            done: true
          } : {
            done: false,
            value: r[o++]
          };
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    function _extends() {
      return _extends = Object.assign ? Object.assign.bind() : function(n) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];
          for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
        }
        return n;
      }, _extends.apply(null, arguments);
    }
    function _getPrototypeOf(t) {
      return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(t2) {
        return t2.__proto__ || Object.getPrototypeOf(t2);
      }, _getPrototypeOf(t);
    }
    function _inheritsLoose(t, o) {
      t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
    }
    function _isNativeFunction(t) {
      try {
        return -1 !== Function.toString.call(t).indexOf("[native code]");
      } catch (n) {
        return "function" == typeof t;
      }
    }
    function _isNativeReflectConstruct() {
      try {
        var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
        }));
      } catch (t2) {
      }
      return (_isNativeReflectConstruct = function() {
        return !!t;
      })();
    }
    function _setPrototypeOf(t, e) {
      return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t2, e2) {
        return t2.__proto__ = e2, t2;
      }, _setPrototypeOf(t, e);
    }
    function _toPrimitive(t, r) {
      if ("object" != typeof t || !t) return t;
      var e = t[Symbol.toPrimitive];
      if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    function _toPropertyKey(t) {
      var i = _toPrimitive(t, "string");
      return "symbol" == typeof i ? i : i + "";
    }
    function _unsupportedIterableToArray(r, a) {
      if (r) {
        if ("string" == typeof r) return _arrayLikeToArray(r, a);
        var t = {}.toString.call(r).slice(8, -1);
        return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
      }
    }
    function _wrapNativeSuper(t) {
      var r = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
      return _wrapNativeSuper = function(t2) {
        if (null === t2 || !_isNativeFunction(t2)) return t2;
        if ("function" != typeof t2) throw new TypeError("Super expression must either be null or a function");
        if (void 0 !== r) {
          if (r.has(t2)) return r.get(t2);
          r.set(t2, Wrapper);
        }
        function Wrapper() {
          return _construct(t2, arguments, _getPrototypeOf(this).constructor);
        }
        return Wrapper.prototype = Object.create(t2.prototype, {
          constructor: {
            value: Wrapper,
            enumerable: false,
            writable: true,
            configurable: true
          }
        }), _setPrototypeOf(Wrapper, t2);
      }, _wrapNativeSuper(t);
    }
    var storedAnnotationsSymbol = /* @__PURE__ */ Symbol("mobx-stored-annotations");
    function createDecoratorAnnotation(annotation) {
      function decorator(target, property) {
        if (is20223Decorator(property)) {
          return annotation.decorate_20223_(target, property);
        } else {
          storeAnnotation(target, property, annotation);
        }
      }
      return Object.assign(decorator, annotation);
    }
    function storeAnnotation(prototype, key, annotation) {
      if (!hasProp(prototype, storedAnnotationsSymbol)) {
        addHiddenProp(prototype, storedAnnotationsSymbol, _extends({}, prototype[storedAnnotationsSymbol]));
      }
      if (isOverride(annotation) && !hasProp(prototype[storedAnnotationsSymbol], key)) {
        var fieldName = prototype.constructor.name + ".prototype." + key.toString();
        die("'" + fieldName + "' is decorated with 'override', but no such decorated member was found on prototype.");
      }
      assertNotDecorated(prototype, annotation, key);
      if (!isOverride(annotation)) {
        prototype[storedAnnotationsSymbol][key] = annotation;
      }
    }
    function assertNotDecorated(prototype, annotation, key) {
      if (!isOverride(annotation) && hasProp(prototype[storedAnnotationsSymbol], key)) {
        var fieldName = prototype.constructor.name + ".prototype." + key.toString();
        var currentAnnotationType = prototype[storedAnnotationsSymbol][key].annotationType_;
        var requestedAnnotationType = annotation.annotationType_;
        die("Cannot apply '@" + requestedAnnotationType + "' to '" + fieldName + "':" + ("\nThe field is already decorated with '@" + currentAnnotationType + "'.") + "\nRe-decorating fields is not allowed.\nUse '@override' decorator for methods overridden by subclass.");
      }
    }
    function collectStoredAnnotations(target) {
      if (!hasProp(target, storedAnnotationsSymbol)) {
        addHiddenProp(target, storedAnnotationsSymbol, _extends({}, target[storedAnnotationsSymbol]));
      }
      return target[storedAnnotationsSymbol];
    }
    function is20223Decorator(context) {
      return typeof context == "object" && typeof context["kind"] == "string";
    }
    function assert20223DecoratorType(context, types) {
      if (!types.includes(context.kind)) {
        die("The decorator applied to '" + String(context.name) + "' cannot be used on a " + context.kind + " element");
      }
    }
    var $mobx = /* @__PURE__ */ Symbol("mobx administration");
    var Atom = /* @__PURE__ */ (function() {
      function Atom2(name_) {
        if (name_ === void 0) {
          name_ = "Atom@" + getNextId();
        }
        this.name_ = void 0;
        this.flags_ = 0;
        this.observers_ = /* @__PURE__ */ new Set();
        this.lastAccessedBy_ = 0;
        this.lowestObserverState_ = IDerivationState_.NOT_TRACKING_;
        this.onBOL = void 0;
        this.onBUOL = void 0;
        this.name_ = name_;
      }
      var _proto = Atom2.prototype;
      _proto.onBO = function onBO() {
        if (this.onBOL) {
          this.onBOL.forEach(function(listener) {
            return listener();
          });
        }
      };
      _proto.onBUO = function onBUO() {
        if (this.onBUOL) {
          this.onBUOL.forEach(function(listener) {
            return listener();
          });
        }
      };
      _proto.reportObserved = function reportObserved$1() {
        return reportObserved(this);
      };
      _proto.reportChanged = function reportChanged() {
        startBatch();
        propagateChanged(this);
        endBatch();
      };
      _proto.toString = function toString2() {
        return this.name_;
      };
      return _createClass(Atom2, [{
        key: "isBeingObserved",
        get: function get2() {
          return getFlag(this.flags_, Atom2.isBeingObservedMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Atom2.isBeingObservedMask_, newValue);
        }
      }, {
        key: "isPendingUnobservation",
        get: function get2() {
          return getFlag(this.flags_, Atom2.isPendingUnobservationMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Atom2.isPendingUnobservationMask_, newValue);
        }
      }, {
        key: "diffValue",
        get: function get2() {
          return getFlag(this.flags_, Atom2.diffValueMask_) ? 1 : 0;
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Atom2.diffValueMask_, newValue === 1 ? true : false);
        }
      }]);
    })();
    Atom.isBeingObservedMask_ = 1;
    Atom.isPendingUnobservationMask_ = 2;
    Atom.diffValueMask_ = 4;
    var isAtom = /* @__PURE__ */ createInstanceofPredicate("Atom", Atom);
    function createAtom(name, onBecomeObservedHandler, onBecomeUnobservedHandler) {
      if (onBecomeObservedHandler === void 0) {
        onBecomeObservedHandler = noop;
      }
      if (onBecomeUnobservedHandler === void 0) {
        onBecomeUnobservedHandler = noop;
      }
      var atom = new Atom(name);
      if (onBecomeObservedHandler !== noop) {
        onBecomeObserved(atom, onBecomeObservedHandler);
      }
      if (onBecomeUnobservedHandler !== noop) {
        onBecomeUnobserved(atom, onBecomeUnobservedHandler);
      }
      return atom;
    }
    function identityComparer(a, b) {
      return a === b;
    }
    function structuralComparer(a, b) {
      return deepEqual(a, b);
    }
    function shallowComparer(a, b) {
      return deepEqual(a, b, 1);
    }
    function defaultComparer(a, b) {
      if (Object.is) {
        return Object.is(a, b);
      }
      return a === b ? a !== 0 || 1 / a === 1 / b : a !== a && b !== b;
    }
    var comparer = {
      identity: identityComparer,
      structural: structuralComparer,
      "default": defaultComparer,
      shallow: shallowComparer
    };
    function deepEnhancer(v, _, name) {
      if (isObservable(v)) {
        return v;
      }
      if (Array.isArray(v)) {
        return observable.array(v, {
          name
        });
      }
      if (isPlainObject(v)) {
        return observable.object(v, void 0, {
          name
        });
      }
      if (isES6Map(v)) {
        return observable.map(v, {
          name
        });
      }
      if (isES6Set(v)) {
        return observable.set(v, {
          name
        });
      }
      if (typeof v === "function" && !isAction(v) && !isFlow(v)) {
        if (isGenerator(v)) {
          return flow(v);
        } else {
          return autoAction(name, v);
        }
      }
      return v;
    }
    function shallowEnhancer(v, _, name) {
      if (v === void 0 || v === null) {
        return v;
      }
      if (isObservableObject(v) || isObservableArray(v) || isObservableMap(v) || isObservableSet(v)) {
        return v;
      }
      if (Array.isArray(v)) {
        return observable.array(v, {
          name,
          deep: false
        });
      }
      if (isPlainObject(v)) {
        return observable.object(v, void 0, {
          name,
          deep: false
        });
      }
      if (isES6Map(v)) {
        return observable.map(v, {
          name,
          deep: false
        });
      }
      if (isES6Set(v)) {
        return observable.set(v, {
          name,
          deep: false
        });
      }
      {
        die("The shallow modifier / decorator can only used in combination with arrays, objects, maps and sets");
      }
    }
    function referenceEnhancer(newValue) {
      return newValue;
    }
    function refStructEnhancer(v, oldValue) {
      if (isObservable(v)) {
        die("observable.struct should not be used with observable values");
      }
      if (deepEqual(v, oldValue)) {
        return oldValue;
      }
      return v;
    }
    var OVERRIDE = "override";
    var override = /* @__PURE__ */ createDecoratorAnnotation({
      annotationType_: OVERRIDE,
      make_,
      extend_,
      decorate_20223_
    });
    function isOverride(annotation) {
      return annotation.annotationType_ === OVERRIDE;
    }
    function make_(adm, key) {
      if (adm.isPlainObject_) {
        die("Cannot apply '" + this.annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + this.annotationType_ + "' cannot be used on plain objects."));
      }
      if (!hasProp(adm.appliedAnnotations_, key)) {
        die("'" + adm.name_ + "." + key.toString() + "' is annotated with '" + this.annotationType_ + "', but no such annotated member was found on prototype.");
      }
      return 0;
    }
    function extend_(adm, key, descriptor, proxyTrap) {
      die("'" + this.annotationType_ + "' can only be used with 'makeObservable'");
    }
    function decorate_20223_(desc, context) {
      console.warn("'" + this.annotationType_ + "' cannot be used with decorators - this is a no-op");
    }
    function createActionAnnotation(name, options) {
      return {
        annotationType_: name,
        options_: options,
        make_: make_$1,
        extend_: extend_$1,
        decorate_20223_: decorate_20223_$1
      };
    }
    function make_$1(adm, key, descriptor, source) {
      var _this$options_;
      if ((_this$options_ = this.options_) != null && _this$options_.bound) {
        return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
      }
      if (source === adm.target_) {
        return this.extend_(adm, key, descriptor, false) === null ? 0 : 2;
      }
      if (isAction(descriptor.value)) {
        return 1;
      }
      var actionDescriptor = createActionDescriptor(adm, this, key, descriptor, false);
      defineProperty(source, key, actionDescriptor);
      return 2;
    }
    function extend_$1(adm, key, descriptor, proxyTrap) {
      var actionDescriptor = createActionDescriptor(adm, this, key, descriptor);
      return adm.defineProperty_(key, actionDescriptor, proxyTrap);
    }
    function decorate_20223_$1(mthd, context) {
      {
        assert20223DecoratorType(context, ["method", "field"]);
      }
      var kind = context.kind, name = context.name, addInitializer = context.addInitializer;
      var ann = this;
      var _createAction = function _createAction2(m) {
        var _ann$options_$name, _ann$options_, _ann$options_$autoAct, _ann$options_2;
        return createAction((_ann$options_$name = (_ann$options_ = ann.options_) == null ? void 0 : _ann$options_.name) != null ? _ann$options_$name : name.toString(), m, (_ann$options_$autoAct = (_ann$options_2 = ann.options_) == null ? void 0 : _ann$options_2.autoAction) != null ? _ann$options_$autoAct : false);
      };
      if (kind == "field") {
        return function(initMthd) {
          var _ann$options_3;
          var mthd2 = initMthd;
          if (!isAction(mthd2)) {
            mthd2 = _createAction(mthd2);
          }
          if ((_ann$options_3 = ann.options_) != null && _ann$options_3.bound) {
            mthd2 = mthd2.bind(this);
            mthd2.isMobxAction = true;
          }
          return mthd2;
        };
      }
      if (kind == "method") {
        var _this$options_2;
        if (!isAction(mthd)) {
          mthd = _createAction(mthd);
        }
        if ((_this$options_2 = this.options_) != null && _this$options_2.bound) {
          addInitializer(function() {
            var self2 = this;
            var bound = self2[name].bind(self2);
            bound.isMobxAction = true;
            self2[name] = bound;
          });
        }
        return mthd;
      }
      die("Cannot apply '" + ann.annotationType_ + "' to '" + String(name) + "' (kind: " + kind + "):" + ("\n'" + ann.annotationType_ + "' can only be used on properties with a function value."));
    }
    function assertActionDescriptor(adm, _ref, key, _ref2) {
      var annotationType_ = _ref.annotationType_;
      var value = _ref2.value;
      if (!isFunction(value)) {
        die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on properties with a function value."));
      }
    }
    function createActionDescriptor(adm, annotation, key, descriptor, safeDescriptors) {
      var _annotation$options_, _annotation$options_$, _annotation$options_2, _annotation$options_$2, _annotation$options_3, _annotation$options_4, _adm$proxy_2;
      if (safeDescriptors === void 0) {
        safeDescriptors = globalState.safeDescriptors;
      }
      assertActionDescriptor(adm, annotation, key, descriptor);
      var value = descriptor.value;
      if ((_annotation$options_ = annotation.options_) != null && _annotation$options_.bound) {
        var _adm$proxy_;
        value = value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
      }
      return {
        value: createAction(
          (_annotation$options_$ = (_annotation$options_2 = annotation.options_) == null ? void 0 : _annotation$options_2.name) != null ? _annotation$options_$ : key.toString(),
          value,
          (_annotation$options_$2 = (_annotation$options_3 = annotation.options_) == null ? void 0 : _annotation$options_3.autoAction) != null ? _annotation$options_$2 : false,
          // https://github.com/mobxjs/mobx/discussions/3140
          (_annotation$options_4 = annotation.options_) != null && _annotation$options_4.bound ? (_adm$proxy_2 = adm.proxy_) != null ? _adm$proxy_2 : adm.target_ : void 0
        ),
        // Non-configurable for classes
        // prevents accidental field redefinition in subclass
        configurable: safeDescriptors ? adm.isPlainObject_ : true,
        // https://github.com/mobxjs/mobx/pull/2641#issuecomment-737292058
        enumerable: false,
        // Non-obsevable, therefore non-writable
        // Also prevents rewriting in subclass constructor
        writable: safeDescriptors ? false : true
      };
    }
    function createFlowAnnotation(name, options) {
      return {
        annotationType_: name,
        options_: options,
        make_: make_$2,
        extend_: extend_$2,
        decorate_20223_: decorate_20223_$2
      };
    }
    function make_$2(adm, key, descriptor, source) {
      var _this$options_;
      if (source === adm.target_) {
        return this.extend_(adm, key, descriptor, false) === null ? 0 : 2;
      }
      if ((_this$options_ = this.options_) != null && _this$options_.bound && (!hasProp(adm.target_, key) || !isFlow(adm.target_[key]))) {
        if (this.extend_(adm, key, descriptor, false) === null) {
          return 0;
        }
      }
      if (isFlow(descriptor.value)) {
        return 1;
      }
      var flowDescriptor = createFlowDescriptor(adm, this, key, descriptor, false, false);
      defineProperty(source, key, flowDescriptor);
      return 2;
    }
    function extend_$2(adm, key, descriptor, proxyTrap) {
      var _this$options_2;
      var flowDescriptor = createFlowDescriptor(adm, this, key, descriptor, (_this$options_2 = this.options_) == null ? void 0 : _this$options_2.bound);
      return adm.defineProperty_(key, flowDescriptor, proxyTrap);
    }
    function decorate_20223_$2(mthd, context) {
      var _this$options_3;
      {
        assert20223DecoratorType(context, ["method"]);
      }
      var name = context.name, addInitializer = context.addInitializer;
      if (!isFlow(mthd)) {
        mthd = flow(mthd);
      }
      if ((_this$options_3 = this.options_) != null && _this$options_3.bound) {
        addInitializer(function() {
          var self2 = this;
          var bound = self2[name].bind(self2);
          bound.isMobXFlow = true;
          self2[name] = bound;
        });
      }
      return mthd;
    }
    function assertFlowDescriptor(adm, _ref, key, _ref2) {
      var annotationType_ = _ref.annotationType_;
      var value = _ref2.value;
      if (!isFunction(value)) {
        die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on properties with a generator function value."));
      }
    }
    function createFlowDescriptor(adm, annotation, key, descriptor, bound, safeDescriptors) {
      if (safeDescriptors === void 0) {
        safeDescriptors = globalState.safeDescriptors;
      }
      assertFlowDescriptor(adm, annotation, key, descriptor);
      var value = descriptor.value;
      if (!isFlow(value)) {
        value = flow(value);
      }
      if (bound) {
        var _adm$proxy_;
        value = value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
        value.isMobXFlow = true;
      }
      return {
        value,
        // Non-configurable for classes
        // prevents accidental field redefinition in subclass
        configurable: safeDescriptors ? adm.isPlainObject_ : true,
        // https://github.com/mobxjs/mobx/pull/2641#issuecomment-737292058
        enumerable: false,
        // Non-obsevable, therefore non-writable
        // Also prevents rewriting in subclass constructor
        writable: safeDescriptors ? false : true
      };
    }
    function createComputedAnnotation(name, options) {
      return {
        annotationType_: name,
        options_: options,
        make_: make_$3,
        extend_: extend_$3,
        decorate_20223_: decorate_20223_$3
      };
    }
    function make_$3(adm, key, descriptor) {
      return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
    }
    function extend_$3(adm, key, descriptor, proxyTrap) {
      assertComputedDescriptor(adm, this, key, descriptor);
      return adm.defineComputedProperty_(key, _extends({}, this.options_, {
        get: descriptor.get,
        set: descriptor.set
      }), proxyTrap);
    }
    function decorate_20223_$3(get2, context) {
      {
        assert20223DecoratorType(context, ["getter"]);
      }
      var ann = this;
      var key = context.name, addInitializer = context.addInitializer;
      var computedValues;
      function createComputedValue(target, adm) {
        var options = _extends({}, ann.options_, {
          get: get2,
          context: target
        });
        options.name || (options.name = adm.name_ + "." + key.toString());
        return new ComputedValue(options);
      }
      addInitializer(function() {
        var _adm$lazyComputedKeys;
        var adm = asObservableObject(this)[$mobx];
        var target = this;
        var observable2 = adm.values_.get(key);
        if (observable2 instanceof ComputedValue && observable2.derivation !== get2) {
          adm.values_["delete"](key);
        }
        ((_adm$lazyComputedKeys = adm.lazyComputedKeys_) != null ? _adm$lazyComputedKeys : adm.lazyComputedKeys_ = /* @__PURE__ */ new Map()).set(key, function() {
          return createComputedValue(target, adm);
        });
      });
      return function() {
        var adm = this[$mobx];
        var observable2 = adm.values_.get(key);
        if (observable2 instanceof ComputedValue && observable2.derivation !== get2) {
          var _computedValues;
          var computed2 = (_computedValues = computedValues) == null ? void 0 : _computedValues.get(this);
          if (!computed2) {
            var _computedValues2;
            computed2 = createComputedValue(this, adm);
            ((_computedValues2 = computedValues) != null ? _computedValues2 : computedValues = /* @__PURE__ */ new WeakMap()).set(this, computed2);
          }
          return computed2.get();
        }
        return adm.getObservablePropValue_(key);
      };
    }
    function assertComputedDescriptor(adm, _ref, key, _ref2) {
      var annotationType_ = _ref.annotationType_;
      var get2 = _ref2.get;
      if (!get2) {
        die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' can only be used on getter(+setter) properties."));
      }
    }
    function createObservableAnnotation(name, options) {
      return {
        annotationType_: name,
        options_: options,
        make_: make_$4,
        extend_: extend_$4,
        decorate_20223_: decorate_20223_$4
      };
    }
    function make_$4(adm, key, descriptor) {
      return this.extend_(adm, key, descriptor, false) === null ? 0 : 1;
    }
    function extend_$4(adm, key, descriptor, proxyTrap) {
      var _this$options_$enhanc, _this$options_;
      assertObservableDescriptor(adm, this, key, descriptor);
      return adm.defineObservableProperty_(key, descriptor.value, (_this$options_$enhanc = (_this$options_ = this.options_) == null ? void 0 : _this$options_.enhancer) != null ? _this$options_$enhanc : deepEnhancer, proxyTrap);
    }
    function decorate_20223_$4(desc, context) {
      {
        if (context.kind === "field") {
          throw die("Please use `@observable accessor " + String(context.name) + "` instead of `@observable " + String(context.name) + "`");
        }
        assert20223DecoratorType(context, ["accessor"]);
      }
      var ann = this;
      var kind = context.kind, name = context.name;
      if (kind !== "accessor") {
        return;
      }
      function registerLazy(target, value) {
        var _adm$lazyObservableKe;
        var adm = asObservableObject(target)[$mobx];
        ((_adm$lazyObservableKe = adm.lazyObservableKeys_) != null ? _adm$lazyObservableKe : adm.lazyObservableKeys_ = /* @__PURE__ */ new Map()).set(name, function() {
          var _ann$options_$enhance, _ann$options_;
          return new ObservableValue(value, (_ann$options_$enhance = (_ann$options_ = ann.options_) == null ? void 0 : _ann$options_.enhancer) != null ? _ann$options_$enhance : deepEnhancer, adm.name_ + "." + name.toString(), false);
        });
        return adm;
      }
      return {
        get: function get2() {
          var _this$$mobx;
          var adm = (_this$$mobx = this[$mobx]) != null ? _this$$mobx : registerLazy(this, desc.get.call(this));
          return adm.getObservablePropValue_(name);
        },
        set: function set2(value) {
          var _this$$mobx2;
          var adm = (_this$$mobx2 = this[$mobx]) != null ? _this$$mobx2 : registerLazy(this, value);
          return adm.setObservablePropValue_(name, value);
        },
        init: function init(value) {
          registerLazy(this, value);
          return value;
        }
      };
    }
    function assertObservableDescriptor(adm, _ref, key, descriptor) {
      var annotationType_ = _ref.annotationType_;
      if (!("value" in descriptor)) {
        die("Cannot apply '" + annotationType_ + "' to '" + adm.name_ + "." + key.toString() + "':" + ("\n'" + annotationType_ + "' cannot be used on getter/setter properties"));
      }
    }
    var AUTO = "true";
    var autoAnnotation = /* @__PURE__ */ createAutoAnnotation();
    function createAutoAnnotation(options) {
      return {
        annotationType_: AUTO,
        options_: options,
        make_: make_$5,
        extend_: extend_$5,
        decorate_20223_: decorate_20223_$5
      };
    }
    function make_$5(adm, key, descriptor, source) {
      var _this$options_3, _this$options_4;
      if (descriptor.get) {
        return computed.make_(adm, key, descriptor, source);
      }
      if (descriptor.set) {
        var set2 = isAction(descriptor.set) ? descriptor.set : createAction(key.toString(), descriptor.set);
        if (source === adm.target_) {
          return adm.defineProperty_(key, {
            configurable: globalState.safeDescriptors ? adm.isPlainObject_ : true,
            set: set2
          }) === null ? 0 : 2;
        }
        defineProperty(source, key, {
          configurable: true,
          set: set2
        });
        return 2;
      }
      if (source !== adm.target_ && typeof descriptor.value === "function") {
        var _this$options_2;
        if (isGenerator(descriptor.value)) {
          var _this$options_;
          var flowAnnotation2 = (_this$options_ = this.options_) != null && _this$options_.autoBind ? flow.bound : flow;
          return flowAnnotation2.make_(adm, key, descriptor, source);
        }
        var actionAnnotation2 = (_this$options_2 = this.options_) != null && _this$options_2.autoBind ? autoAction.bound : autoAction;
        return actionAnnotation2.make_(adm, key, descriptor, source);
      }
      var observableAnnotation2 = ((_this$options_3 = this.options_) == null ? void 0 : _this$options_3.deep) === false ? observable.ref : observable;
      if (typeof descriptor.value === "function" && (_this$options_4 = this.options_) != null && _this$options_4.autoBind) {
        var _adm$proxy_;
        descriptor.value = descriptor.value.bind((_adm$proxy_ = adm.proxy_) != null ? _adm$proxy_ : adm.target_);
      }
      return observableAnnotation2.make_(adm, key, descriptor, source);
    }
    function extend_$5(adm, key, descriptor, proxyTrap) {
      var _this$options_5, _this$options_6;
      if (descriptor.get) {
        return computed.extend_(adm, key, descriptor, proxyTrap);
      }
      if (descriptor.set) {
        return adm.defineProperty_(key, {
          configurable: globalState.safeDescriptors ? adm.isPlainObject_ : true,
          set: createAction(key.toString(), descriptor.set)
        }, proxyTrap);
      }
      if (typeof descriptor.value === "function" && (_this$options_5 = this.options_) != null && _this$options_5.autoBind) {
        var _adm$proxy_2;
        descriptor.value = descriptor.value.bind((_adm$proxy_2 = adm.proxy_) != null ? _adm$proxy_2 : adm.target_);
      }
      var observableAnnotation2 = ((_this$options_6 = this.options_) == null ? void 0 : _this$options_6.deep) === false ? observable.ref : observable;
      return observableAnnotation2.extend_(adm, key, descriptor, proxyTrap);
    }
    function decorate_20223_$5(desc, context) {
      die("'" + this.annotationType_ + "' cannot be used as a decorator");
    }
    var OBSERVABLE = "observable";
    var OBSERVABLE_REF = "observable.ref";
    var OBSERVABLE_SHALLOW = "observable.shallow";
    var OBSERVABLE_STRUCT = "observable.struct";
    var defaultCreateObservableOptions = {
      deep: true,
      name: void 0,
      defaultDecorator: void 0,
      proxy: true
    };
    Object.freeze(defaultCreateObservableOptions);
    function asCreateObservableOptions(thing) {
      return thing || defaultCreateObservableOptions;
    }
    var observableAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE);
    var observableRefAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_REF, {
      enhancer: referenceEnhancer
    });
    var observableShallowAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_SHALLOW, {
      enhancer: shallowEnhancer
    });
    var observableStructAnnotation = /* @__PURE__ */ createObservableAnnotation(OBSERVABLE_STRUCT, {
      enhancer: refStructEnhancer
    });
    var observableDecoratorAnnotation = /* @__PURE__ */ createDecoratorAnnotation(observableAnnotation);
    function getEnhancerFromOptions(options) {
      return options.deep === true ? deepEnhancer : options.deep === false ? referenceEnhancer : getEnhancerFromAnnotation(options.defaultDecorator);
    }
    function getAnnotationFromOptions(options) {
      var _options$defaultDecor;
      return options ? (_options$defaultDecor = options.defaultDecorator) != null ? _options$defaultDecor : createAutoAnnotation(options) : void 0;
    }
    function getEnhancerFromAnnotation(annotation) {
      var _annotation$options_$, _annotation$options_;
      return !annotation ? deepEnhancer : (_annotation$options_$ = (_annotation$options_ = annotation.options_) == null ? void 0 : _annotation$options_.enhancer) != null ? _annotation$options_$ : deepEnhancer;
    }
    function createObservable(v, arg2, arg3) {
      if (is20223Decorator(arg2)) {
        return observableAnnotation.decorate_20223_(v, arg2);
      }
      if (isStringish(arg2)) {
        storeAnnotation(v, arg2, observableAnnotation);
        return;
      }
      if (isObservable(v)) {
        return v;
      }
      if (isPlainObject(v)) {
        return observable.object(v, arg2, arg3);
      }
      if (Array.isArray(v)) {
        return observable.array(v, arg2);
      }
      if (isES6Map(v)) {
        return observable.map(v, arg2);
      }
      if (isES6Set(v)) {
        return observable.set(v, arg2);
      }
      if (typeof v === "object" && v !== null) {
        return v;
      }
      return observable.box(v, arg2);
    }
    assign(createObservable, observableDecoratorAnnotation);
    var observableFactories = {
      box: function box(value, options) {
        var o = asCreateObservableOptions(options);
        return new ObservableValue(value, getEnhancerFromOptions(o), o.name, true, o.equals);
      },
      array: function array(initialValues, options) {
        var o = asCreateObservableOptions(options);
        return (globalState.useProxies === false || o.proxy === false ? createLegacyArray : createObservableArray)(initialValues, getEnhancerFromOptions(o), o.name);
      },
      map: function map(initialValues, options) {
        var o = asCreateObservableOptions(options);
        return new ObservableMap(initialValues, getEnhancerFromOptions(o), o.name);
      },
      set: function set2(initialValues, options) {
        var o = asCreateObservableOptions(options);
        return new ObservableSet(initialValues, getEnhancerFromOptions(o), o.name);
      },
      object: function object(props, decorators, options) {
        return initObservable(function() {
          return extendObservable(globalState.useProxies === false || (options == null ? void 0 : options.proxy) === false ? asObservableObject({}, options) : asDynamicObservableObject({}, options), props, decorators);
        });
      },
      ref: /* @__PURE__ */ createDecoratorAnnotation(observableRefAnnotation),
      shallow: /* @__PURE__ */ createDecoratorAnnotation(observableShallowAnnotation),
      deep: observableDecoratorAnnotation,
      struct: /* @__PURE__ */ createDecoratorAnnotation(observableStructAnnotation)
    };
    var observable = /* @__PURE__ */ assign(createObservable, observableFactories);
    var COMPUTED = "computed";
    var COMPUTED_STRUCT = "computed.struct";
    var computedAnnotation = /* @__PURE__ */ createComputedAnnotation(COMPUTED);
    var computedStructAnnotation = /* @__PURE__ */ createComputedAnnotation(COMPUTED_STRUCT, {
      equals: comparer.structural
    });
    var computed = function computed2(arg1, arg2) {
      if (is20223Decorator(arg2)) {
        return computedAnnotation.decorate_20223_(arg1, arg2);
      }
      if (isStringish(arg2)) {
        return storeAnnotation(arg1, arg2, computedAnnotation);
      }
      if (isPlainObject(arg1)) {
        return createDecoratorAnnotation(createComputedAnnotation(COMPUTED, arg1));
      }
      {
        if (!isFunction(arg1)) {
          die("First argument to `computed` should be an expression.");
        }
        if (isFunction(arg2)) {
          die("A setter as second argument is no longer supported, use `{ set: fn }` option instead");
        }
      }
      var opts = isPlainObject(arg2) ? arg2 : {};
      opts.get = arg1;
      opts.name || (opts.name = arg1.name || "");
      return new ComputedValue(opts);
    };
    Object.assign(computed, computedAnnotation);
    computed.struct = /* @__PURE__ */ createDecoratorAnnotation(computedStructAnnotation);
    var _getDescriptor$config;
    var _getDescriptor;
    var currentActionId = 0;
    var nextActionId = 1;
    var isFunctionNameConfigurable = (_getDescriptor$config = (_getDescriptor = /* @__PURE__ */ getDescriptor(function() {
    }, "name")) == null ? void 0 : _getDescriptor.configurable) != null ? _getDescriptor$config : false;
    var tmpNameDescriptor = {
      value: "action",
      configurable: true,
      writable: false,
      enumerable: false
    };
    function createAction(actionName, fn, autoAction2, ref) {
      if (autoAction2 === void 0) {
        autoAction2 = false;
      }
      {
        if (!isFunction(fn)) {
          die("`action` can only be invoked on functions");
        }
        if (typeof actionName !== "string" || !actionName) {
          die("actions should have valid names, got: '" + actionName + "'");
        }
      }
      function res() {
        return executeAction(actionName, autoAction2, fn, ref || this, arguments);
      }
      res.isMobxAction = true;
      res.toString = function() {
        return fn.toString();
      };
      if (isFunctionNameConfigurable) {
        tmpNameDescriptor.value = actionName;
        defineProperty(res, "name", tmpNameDescriptor);
      }
      return res;
    }
    function executeAction(actionName, canRunAsDerivation, fn, scope, args) {
      var runInfo = _startAction(actionName, canRunAsDerivation, scope, args);
      try {
        return fn.apply(scope, args);
      } catch (err) {
        runInfo.error_ = err;
        throw err;
      } finally {
        _endAction(runInfo);
      }
    }
    function _startAction(actionName, canRunAsDerivation, scope, args) {
      var notifySpy_ = isSpyEnabled() && !!actionName;
      var startTime_ = 0;
      if (notifySpy_) {
        startTime_ = Date.now();
        var flattenedArgs = args ? Array.from(args) : EMPTY_ARRAY;
        spyReportStart({
          type: ACTION,
          name: actionName,
          object: scope,
          arguments: flattenedArgs
        });
      }
      var prevDerivation_ = globalState.trackingDerivation;
      var runAsAction = !canRunAsDerivation || !prevDerivation_;
      startBatch();
      var prevAllowStateChanges_ = globalState.allowStateChanges;
      if (runAsAction) {
        untrackedStart();
        prevAllowStateChanges_ = allowStateChangesStart(true);
      }
      var prevAllowStateReads_ = allowStateReadsStart(true);
      var runInfo = {
        runAsAction_: runAsAction,
        prevDerivation_,
        prevAllowStateChanges_,
        prevAllowStateReads_,
        notifySpy_,
        startTime_,
        actionId_: nextActionId++,
        parentActionId_: currentActionId
      };
      currentActionId = runInfo.actionId_;
      return runInfo;
    }
    function _endAction(runInfo) {
      if (currentActionId !== runInfo.actionId_) {
        die(30);
      }
      currentActionId = runInfo.parentActionId_;
      if (runInfo.error_ !== void 0) {
        globalState.suppressReactionErrors = true;
      }
      allowStateChangesEnd(runInfo.prevAllowStateChanges_);
      allowStateReadsEnd(runInfo.prevAllowStateReads_);
      endBatch();
      if (runInfo.runAsAction_) {
        untrackedEnd(runInfo.prevDerivation_);
      }
      if (runInfo.notifySpy_) {
        spyReportEnd({
          time: Date.now() - runInfo.startTime_
        });
      }
      globalState.suppressReactionErrors = false;
    }
    function allowStateChanges(allowStateChanges2, func) {
      var prev = allowStateChangesStart(allowStateChanges2);
      try {
        return func();
      } finally {
        allowStateChangesEnd(prev);
      }
    }
    function allowStateChangesStart(allowStateChanges2) {
      var prev = globalState.allowStateChanges;
      globalState.allowStateChanges = allowStateChanges2;
      return prev;
    }
    function allowStateChangesEnd(prev) {
      globalState.allowStateChanges = prev;
    }
    var CREATE = "create";
    var ObservableValue = /* @__PURE__ */ (function(_Atom) {
      function ObservableValue2(value, enhancer, name_, notifySpy, equals) {
        var _this;
        if (name_ === void 0) {
          name_ = "ObservableValue@" + getNextId();
        }
        if (notifySpy === void 0) {
          notifySpy = true;
        }
        if (equals === void 0) {
          equals = comparer["default"];
        }
        _this = _Atom.call(this, name_) || this;
        _this.enhancer = void 0;
        _this.name_ = void 0;
        _this.equals = void 0;
        _this.hasUnreportedChange_ = false;
        _this.interceptors_ = void 0;
        _this.changeListeners_ = void 0;
        _this.value_ = void 0;
        _this.dehancer = void 0;
        _this.enhancer = enhancer;
        _this.name_ = name_;
        _this.equals = equals;
        _this.value_ = enhancer(value, void 0, name_);
        if (notifySpy && isSpyEnabled()) {
          var _this$value_;
          spyReport({
            type: CREATE,
            object: _this,
            observableKind: "value",
            debugObjectName: _this.name_,
            newValue: "" + ((_this$value_ = _this.value_) == null ? void 0 : _this$value_.toString())
          });
        }
        return _this;
      }
      _inheritsLoose(ObservableValue2, _Atom);
      var _proto = ObservableValue2.prototype;
      _proto.dehanceValue = function dehanceValue(value) {
        if (this.dehancer !== void 0) {
          return this.dehancer(value);
        }
        return value;
      };
      _proto.set = function set2(newValue) {
        var oldValue = this.value_;
        newValue = this.prepareNewValue_(newValue);
        if (newValue !== globalState.UNCHANGED) {
          var notifySpy = isSpyEnabled();
          if (notifySpy) {
            spyReportStart({
              type: UPDATE,
              object: this,
              observableKind: "value",
              debugObjectName: this.name_,
              newValue,
              oldValue
            });
          }
          this.setNewValue_(newValue);
          if (notifySpy) {
            spyReportEnd();
          }
        }
      };
      _proto.prepareNewValue_ = function prepareNewValue_(newValue) {
        checkIfStateModificationsAreAllowed(this);
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            object: this,
            type: UPDATE,
            newValue
          });
          if (!change) {
            return globalState.UNCHANGED;
          }
          newValue = change.newValue;
        }
        newValue = this.enhancer(newValue, this.value_, this.name_);
        return this.equals(this.value_, newValue) ? globalState.UNCHANGED : newValue;
      };
      _proto.setNewValue_ = function setNewValue_(newValue) {
        var oldValue = this.value_;
        this.value_ = newValue;
        this.reportChanged();
        if (hasListeners(this)) {
          notifyListeners(this, {
            type: UPDATE,
            object: this,
            newValue,
            oldValue
          });
        }
      };
      _proto.get = function get2() {
        this.reportObserved();
        return this.dehanceValue(this.value_);
      };
      _proto.intercept_ = function intercept_(handler) {
        return registerInterceptor(this, handler);
      };
      _proto.observe_ = function observe_(listener, fireImmediately) {
        if (fireImmediately) {
          listener({
            observableKind: "value",
            debugObjectName: this.name_,
            object: this,
            type: UPDATE,
            newValue: this.value_,
            oldValue: void 0
          });
        }
        return registerListener(this, listener);
      };
      _proto.raw = function raw() {
        return this.value_;
      };
      _proto.toJSON = function toJSON() {
        return this.get();
      };
      _proto.toString = function toString2() {
        return this.name_ + "[" + this.value_ + "]";
      };
      _proto.valueOf = function valueOf() {
        return toPrimitive(this.get());
      };
      _proto[Symbol.toPrimitive] = function() {
        return this.valueOf();
      };
      return ObservableValue2;
    })(Atom);
    var isObservableValue = /* @__PURE__ */ createInstanceofPredicate("ObservableValue", ObservableValue);
    var ComputedValue = /* @__PURE__ */ (function() {
      function ComputedValue2(options) {
        this.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
        this.observing_ = [];
        this.newObserving_ = null;
        this.observers_ = /* @__PURE__ */ new Set();
        this.runId_ = 0;
        this.lastAccessedBy_ = 0;
        this.lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
        this.unboundDepsCount_ = 0;
        this.value_ = new CaughtException(null);
        this.name_ = void 0;
        this.triggeredBy_ = void 0;
        this.flags_ = 0;
        this.derivation = void 0;
        this.setter_ = void 0;
        this.isTracing_ = TraceMode.NONE;
        this.scope_ = void 0;
        this.equals_ = void 0;
        this.requiresReaction_ = void 0;
        this.keepAlive_ = void 0;
        this.onBOL = void 0;
        this.onBUOL = void 0;
        if (!options.get) {
          die(31);
        }
        this.derivation = options.get;
        this.name_ = options.name || "ComputedValue@" + getNextId();
        if (options.set) {
          this.setter_ = createAction(this.name_ + "-setter", options.set);
        }
        this.equals_ = options.equals || (options.compareStructural || options.struct ? comparer.structural : comparer["default"]);
        this.scope_ = options.context;
        this.requiresReaction_ = options.requiresReaction;
        this.keepAlive_ = !!options.keepAlive;
      }
      var _proto = ComputedValue2.prototype;
      _proto.onBecomeStale_ = function onBecomeStale_() {
        propagateMaybeChanged(this);
      };
      _proto.onBO = function onBO() {
        if (this.onBOL) {
          this.onBOL.forEach(function(listener) {
            return listener();
          });
        }
      };
      _proto.onBUO = function onBUO() {
        if (this.onBUOL) {
          this.onBUOL.forEach(function(listener) {
            return listener();
          });
        }
      };
      _proto.get = function get2() {
        if (this.isComputing) {
          die(32, this.name_, this.derivation);
        }
        if (globalState.inBatch === 0 && // !globalState.trackingDerivatpion &&
        this.observers_.size === 0 && !this.keepAlive_) {
          if (shouldCompute(this)) {
            this.warnAboutUntrackedRead_();
            startBatch();
            this.value_ = this.computeValue_(false);
            endBatch();
          }
        } else {
          reportObserved(this);
          if (shouldCompute(this)) {
            var prevTrackingContext = globalState.trackingContext;
            if (this.keepAlive_ && !prevTrackingContext) {
              globalState.trackingContext = this;
            }
            if (this.trackAndCompute()) {
              propagateChangeConfirmed(this);
            }
            globalState.trackingContext = prevTrackingContext;
          }
        }
        var result = this.value_;
        if (isCaughtException(result)) {
          throw result.cause;
        }
        return result;
      };
      _proto.set = function set2(value) {
        if (this.setter_) {
          if (this.isRunningSetter) {
            die(33, this.name_);
          }
          this.isRunningSetter = true;
          try {
            this.setter_.call(this.scope_, value);
          } finally {
            this.isRunningSetter = false;
          }
        } else {
          die(34, this.name_);
        }
      };
      _proto.trackAndCompute = function trackAndCompute() {
        var oldValue = this.value_;
        var wasSuspended = (
          /* see #1208 */
          this.dependenciesState_ === IDerivationState_.NOT_TRACKING_
        );
        var newValue = this.computeValue_(true);
        var changed = wasSuspended || isCaughtException(oldValue) || isCaughtException(newValue) || !this.equals_(oldValue, newValue);
        if (changed) {
          this.value_ = newValue;
          if (isSpyEnabled()) {
            spyReport({
              observableKind: "computed",
              debugObjectName: this.name_,
              object: this.scope_,
              type: "update",
              oldValue,
              newValue
            });
          }
        }
        return changed;
      };
      _proto.computeValue_ = function computeValue_(track) {
        this.isComputing = true;
        var prev = allowStateChangesStart(false);
        var res;
        if (track) {
          res = trackDerivedFunction(this, this.derivation, this.scope_);
        } else {
          if (globalState.disableErrorBoundaries === true) {
            res = this.derivation.call(this.scope_);
          } else {
            try {
              res = this.derivation.call(this.scope_);
            } catch (e) {
              res = new CaughtException(e);
            }
          }
        }
        allowStateChangesEnd(prev);
        this.isComputing = false;
        return res;
      };
      _proto.suspend_ = function suspend_() {
        if (!this.keepAlive_) {
          clearObserving(this);
          this.value_ = void 0;
          if (this.isTracing_ !== TraceMode.NONE) {
            console.log("[mobx.trace] Computed value '" + this.name_ + "' was suspended and it will recompute on the next access.");
          }
        }
      };
      _proto.observe_ = function observe_(listener, fireImmediately) {
        var _this = this;
        var firstTime = true;
        var prevValue = void 0;
        return autorun(function() {
          var newValue = _this.get();
          if (!firstTime || fireImmediately) {
            var prevU = untrackedStart();
            listener({
              observableKind: "computed",
              debugObjectName: _this.name_,
              type: UPDATE,
              object: _this,
              newValue,
              oldValue: prevValue
            });
            untrackedEnd(prevU);
          }
          firstTime = false;
          prevValue = newValue;
        });
      };
      _proto.warnAboutUntrackedRead_ = function warnAboutUntrackedRead_() {
        if (this.isTracing_ !== TraceMode.NONE) {
          console.log("[mobx.trace] Computed value '" + this.name_ + "' is being read outside a reactive context. Doing a full recompute.");
        }
        if (typeof this.requiresReaction_ === "boolean" ? this.requiresReaction_ : globalState.computedRequiresReaction) {
          console.warn("[mobx] Computed value '" + this.name_ + "' is being read outside a reactive context. Doing a full recompute.");
        }
      };
      _proto.toString = function toString2() {
        return this.name_ + "[" + this.derivation.toString() + "]";
      };
      _proto.valueOf = function valueOf() {
        return toPrimitive(this.get());
      };
      _proto[Symbol.toPrimitive] = function() {
        return this.valueOf();
      };
      return _createClass(ComputedValue2, [{
        key: "isComputing",
        get: function get2() {
          return getFlag(this.flags_, ComputedValue2.isComputingMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, ComputedValue2.isComputingMask_, newValue);
        }
      }, {
        key: "isRunningSetter",
        get: function get2() {
          return getFlag(this.flags_, ComputedValue2.isRunningSetterMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, ComputedValue2.isRunningSetterMask_, newValue);
        }
      }, {
        key: "isBeingObserved",
        get: function get2() {
          return getFlag(this.flags_, ComputedValue2.isBeingObservedMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, ComputedValue2.isBeingObservedMask_, newValue);
        }
      }, {
        key: "isPendingUnobservation",
        get: function get2() {
          return getFlag(this.flags_, ComputedValue2.isPendingUnobservationMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, ComputedValue2.isPendingUnobservationMask_, newValue);
        }
      }, {
        key: "diffValue",
        get: function get2() {
          return getFlag(this.flags_, ComputedValue2.diffValueMask_) ? 1 : 0;
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, ComputedValue2.diffValueMask_, newValue === 1 ? true : false);
        }
      }]);
    })();
    ComputedValue.isComputingMask_ = 1;
    ComputedValue.isRunningSetterMask_ = 2;
    ComputedValue.isBeingObservedMask_ = 4;
    ComputedValue.isPendingUnobservationMask_ = 8;
    ComputedValue.diffValueMask_ = 16;
    var isComputedValue = /* @__PURE__ */ createInstanceofPredicate("ComputedValue", ComputedValue);
    var IDerivationState_;
    (function(IDerivationState_2) {
      IDerivationState_2[IDerivationState_2["NOT_TRACKING_"] = -1] = "NOT_TRACKING_";
      IDerivationState_2[IDerivationState_2["UP_TO_DATE_"] = 0] = "UP_TO_DATE_";
      IDerivationState_2[IDerivationState_2["POSSIBLY_STALE_"] = 1] = "POSSIBLY_STALE_";
      IDerivationState_2[IDerivationState_2["STALE_"] = 2] = "STALE_";
    })(IDerivationState_ || (IDerivationState_ = {}));
    var TraceMode;
    (function(TraceMode2) {
      TraceMode2[TraceMode2["NONE"] = 0] = "NONE";
      TraceMode2[TraceMode2["LOG"] = 1] = "LOG";
      TraceMode2[TraceMode2["BREAK"] = 2] = "BREAK";
    })(TraceMode || (TraceMode = {}));
    var CaughtException = function CaughtException2(cause) {
      this.cause = void 0;
      this.cause = cause;
    };
    function isCaughtException(e) {
      return e instanceof CaughtException;
    }
    function shouldCompute(derivation) {
      switch (derivation.dependenciesState_) {
        case IDerivationState_.UP_TO_DATE_:
          return false;
        case IDerivationState_.NOT_TRACKING_:
        case IDerivationState_.STALE_:
          return true;
        case IDerivationState_.POSSIBLY_STALE_: {
          var prevAllowStateReads = allowStateReadsStart(true);
          var prevUntracked = untrackedStart();
          var obs = derivation.observing_, l = obs.length;
          for (var i = 0; i < l; i++) {
            var obj = obs[i];
            if (isComputedValue(obj)) {
              if (globalState.disableErrorBoundaries) {
                obj.get();
              } else {
                try {
                  obj.get();
                } catch (e) {
                  untrackedEnd(prevUntracked);
                  allowStateReadsEnd(prevAllowStateReads);
                  return true;
                }
              }
              if (derivation.dependenciesState_ === IDerivationState_.STALE_) {
                untrackedEnd(prevUntracked);
                allowStateReadsEnd(prevAllowStateReads);
                return true;
              }
            }
          }
          changeDependenciesStateTo0(derivation);
          untrackedEnd(prevUntracked);
          allowStateReadsEnd(prevAllowStateReads);
          return false;
        }
      }
    }
    function isComputingDerivation() {
      return globalState.trackingDerivation !== null;
    }
    function checkIfStateModificationsAreAllowed(atom) {
      var hasObservers2 = atom.observers_.size > 0;
      if (!globalState.allowStateChanges && (hasObservers2 || globalState.enforceActions === "always")) {
        console.warn("[MobX] " + (globalState.enforceActions ? "Since strict-mode is enabled, changing (observed) observable values without using an action is not allowed. Tried to modify: " : "Side effects like changing state are not allowed at this point. Are you trying to modify state from, for example, a computed value or the render function of a React component? You can wrap side effects in 'runInAction' (or decorate functions with 'action') if needed. Tried to modify: ") + atom.name_);
      }
    }
    function checkIfStateReadsAreAllowed(observable2) {
      if (!globalState.allowStateReads && globalState.observableRequiresReaction) {
        console.warn("[mobx] Observable '" + observable2.name_ + "' being read outside a reactive context.");
      }
    }
    function trackDerivedFunction(derivation, f, context) {
      var prevAllowStateReads = allowStateReadsStart(true);
      changeDependenciesStateTo0(derivation);
      derivation.newObserving_ = new Array(
        // Reserve constant space for initial dependencies, dynamic space otherwise.
        // See https://github.com/mobxjs/mobx/pull/3833
        derivation.runId_ === 0 ? 100 : derivation.observing_.length
      );
      derivation.unboundDepsCount_ = 0;
      derivation.runId_ = ++globalState.runId;
      var prevTracking = globalState.trackingDerivation;
      globalState.trackingDerivation = derivation;
      globalState.inBatch++;
      var result;
      if (globalState.disableErrorBoundaries === true) {
        result = f.call(context);
      } else {
        try {
          result = f.call(context);
        } catch (e) {
          result = new CaughtException(e);
        }
      }
      globalState.inBatch--;
      globalState.trackingDerivation = prevTracking;
      bindDependencies(derivation);
      warnAboutDerivationWithoutDependencies(derivation);
      allowStateReadsEnd(prevAllowStateReads);
      return result;
    }
    function warnAboutDerivationWithoutDependencies(derivation) {
      if (derivation.observing_.length !== 0) {
        return;
      }
      if (typeof derivation.requiresObservable_ === "boolean" ? derivation.requiresObservable_ : globalState.reactionRequiresObservable) {
        console.warn("[mobx] Derivation '" + derivation.name_ + "' is created/updated without reading any observable value.");
      }
    }
    function bindDependencies(derivation) {
      var prevObserving = derivation.observing_;
      var observing = derivation.observing_ = derivation.newObserving_;
      var lowestNewObservingDerivationState = IDerivationState_.UP_TO_DATE_;
      var i0 = 0, l = derivation.unboundDepsCount_;
      for (var i = 0; i < l; i++) {
        var dep = observing[i];
        if (dep.diffValue === 0) {
          dep.diffValue = 1;
          if (i0 !== i) {
            observing[i0] = dep;
          }
          i0++;
        }
        if (dep.dependenciesState_ > lowestNewObservingDerivationState) {
          lowestNewObservingDerivationState = dep.dependenciesState_;
        }
      }
      observing.length = i0;
      derivation.newObserving_ = null;
      l = prevObserving.length;
      while (l--) {
        var _dep = prevObserving[l];
        if (_dep.diffValue === 0) {
          removeObserver(_dep, derivation);
        }
        _dep.diffValue = 0;
      }
      while (i0--) {
        var _dep2 = observing[i0];
        if (_dep2.diffValue === 1) {
          _dep2.diffValue = 0;
          addObserver(_dep2, derivation);
        }
      }
      if (lowestNewObservingDerivationState !== IDerivationState_.UP_TO_DATE_) {
        derivation.dependenciesState_ = lowestNewObservingDerivationState;
        derivation.onBecomeStale_();
      }
    }
    function clearObserving(derivation) {
      var obs = derivation.observing_;
      derivation.observing_ = [];
      var i = obs.length;
      while (i--) {
        removeObserver(obs[i], derivation);
      }
      derivation.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
    }
    function untracked(action2) {
      var prev = untrackedStart();
      try {
        return action2();
      } finally {
        untrackedEnd(prev);
      }
    }
    function untrackedStart() {
      var prev = globalState.trackingDerivation;
      globalState.trackingDerivation = null;
      return prev;
    }
    function untrackedEnd(prev) {
      globalState.trackingDerivation = prev;
    }
    function allowStateReadsStart(allowStateReads) {
      var prev = globalState.allowStateReads;
      globalState.allowStateReads = allowStateReads;
      return prev;
    }
    function allowStateReadsEnd(prev) {
      globalState.allowStateReads = prev;
    }
    function changeDependenciesStateTo0(derivation) {
      if (derivation.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
        return;
      }
      derivation.dependenciesState_ = IDerivationState_.UP_TO_DATE_;
      var obs = derivation.observing_;
      var i = obs.length;
      while (i--) {
        obs[i].lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
      }
    }
    var persistentKeys = ["mobxGuid", "spyListeners", "enforceActions", "computedRequiresReaction", "reactionRequiresObservable", "observableRequiresReaction", "allowStateReads", "disableErrorBoundaries", "runId", "UNCHANGED", "useProxies"];
    var MobXGlobals = function MobXGlobals2() {
      this.version = 6;
      this.UNCHANGED = {};
      this.trackingDerivation = null;
      this.trackingContext = null;
      this.runId = 0;
      this.mobxGuid = 0;
      this.inBatch = 0;
      this.pendingUnobservations = [];
      this.pendingReactions = [];
      this.isRunningReactions = false;
      this.allowStateChanges = false;
      this.allowStateReads = true;
      this.enforceActions = true;
      this.spyListeners = [];
      this.globalReactionErrorHandlers = [];
      this.computedRequiresReaction = false;
      this.reactionRequiresObservable = false;
      this.observableRequiresReaction = false;
      this.disableErrorBoundaries = false;
      this.suppressReactionErrors = false;
      this.useProxies = true;
      this.verifyProxies = false;
      this.safeDescriptors = true;
    };
    var canMergeGlobalState = true;
    var isolateCalled = false;
    var globalState = /* @__PURE__ */ (function() {
      var global2 = /* @__PURE__ */ getGlobal();
      if (global2.__mobxInstanceCount > 0 && !global2.__mobxGlobals) {
        canMergeGlobalState = false;
      }
      if (global2.__mobxGlobals && global2.__mobxGlobals.version !== new MobXGlobals().version) {
        canMergeGlobalState = false;
      }
      if (!canMergeGlobalState) {
        setTimeout(function() {
          if (!isolateCalled) {
            die(35);
          }
        }, 1);
        return new MobXGlobals();
      } else if (global2.__mobxGlobals) {
        global2.__mobxInstanceCount += 1;
        if (!global2.__mobxGlobals.UNCHANGED) {
          global2.__mobxGlobals.UNCHANGED = {};
        }
        return global2.__mobxGlobals;
      } else {
        global2.__mobxInstanceCount = 1;
        return global2.__mobxGlobals = /* @__PURE__ */ new MobXGlobals();
      }
    })();
    function isolateGlobalState() {
      if (globalState.pendingReactions.length || globalState.inBatch || globalState.isRunningReactions) {
        die(36);
      }
      isolateCalled = true;
      if (canMergeGlobalState) {
        var global2 = getGlobal();
        if (--global2.__mobxInstanceCount === 0) {
          global2.__mobxGlobals = void 0;
        }
        globalState = new MobXGlobals();
      }
    }
    function getGlobalState() {
      return globalState;
    }
    function resetGlobalState() {
      var defaultGlobals = new MobXGlobals();
      for (var key in defaultGlobals) {
        if (persistentKeys.indexOf(key) === -1) {
          globalState[key] = defaultGlobals[key];
        }
      }
      globalState.allowStateChanges = !globalState.enforceActions;
    }
    function hasObservers(observable2) {
      return observable2.observers_ && observable2.observers_.size > 0;
    }
    function getObservers(observable2) {
      return observable2.observers_;
    }
    function addObserver(observable2, node) {
      observable2.observers_.add(node);
      if (observable2.lowestObserverState_ > node.dependenciesState_) {
        observable2.lowestObserverState_ = node.dependenciesState_;
      }
    }
    function removeObserver(observable2, node) {
      observable2.observers_["delete"](node);
      if (observable2.observers_.size === 0) {
        queueForUnobservation(observable2);
      }
    }
    function queueForUnobservation(observable2) {
      if (observable2.isPendingUnobservation === false) {
        observable2.isPendingUnobservation = true;
        globalState.pendingUnobservations.push(observable2);
      }
    }
    function startBatch() {
      globalState.inBatch++;
    }
    function endBatch() {
      if (--globalState.inBatch === 0) {
        runReactions();
        var list = globalState.pendingUnobservations;
        for (var i = 0; i < list.length; i++) {
          var observable2 = list[i];
          observable2.isPendingUnobservation = false;
          if (observable2.observers_.size === 0) {
            if (observable2.isBeingObserved) {
              observable2.isBeingObserved = false;
              observable2.onBUO();
            }
            if (observable2 instanceof ComputedValue) {
              observable2.suspend_();
            }
          }
        }
        globalState.pendingUnobservations = [];
      }
    }
    function reportObserved(observable2) {
      checkIfStateReadsAreAllowed(observable2);
      var derivation = globalState.trackingDerivation;
      if (derivation !== null) {
        if (derivation.runId_ !== observable2.lastAccessedBy_) {
          observable2.lastAccessedBy_ = derivation.runId_;
          derivation.newObserving_[derivation.unboundDepsCount_++] = observable2;
          if (!observable2.isBeingObserved && globalState.trackingContext) {
            observable2.isBeingObserved = true;
            observable2.onBO();
          }
        }
        return observable2.isBeingObserved;
      } else if (observable2.observers_.size === 0 && globalState.inBatch > 0) {
        queueForUnobservation(observable2);
      }
      return false;
    }
    function propagateChanged(observable2) {
      if (observable2.lowestObserverState_ === IDerivationState_.STALE_) {
        return;
      }
      observable2.lowestObserverState_ = IDerivationState_.STALE_;
      observable2.observers_.forEach(function(d) {
        if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
          if (d.isTracing_ !== TraceMode.NONE) {
            logTraceInfo(d, observable2);
          }
          d.onBecomeStale_();
        }
        d.dependenciesState_ = IDerivationState_.STALE_;
      });
    }
    function propagateChangeConfirmed(observable2) {
      if (observable2.lowestObserverState_ === IDerivationState_.STALE_) {
        return;
      }
      observable2.lowestObserverState_ = IDerivationState_.STALE_;
      observable2.observers_.forEach(function(d) {
        if (d.dependenciesState_ === IDerivationState_.POSSIBLY_STALE_) {
          d.dependenciesState_ = IDerivationState_.STALE_;
          if (d.isTracing_ !== TraceMode.NONE) {
            logTraceInfo(d, observable2);
          }
        } else if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
          observable2.lowestObserverState_ = IDerivationState_.UP_TO_DATE_;
        }
      });
    }
    function propagateMaybeChanged(observable2) {
      if (observable2.lowestObserverState_ !== IDerivationState_.UP_TO_DATE_) {
        return;
      }
      observable2.lowestObserverState_ = IDerivationState_.POSSIBLY_STALE_;
      observable2.observers_.forEach(function(d) {
        if (d.dependenciesState_ === IDerivationState_.UP_TO_DATE_) {
          d.dependenciesState_ = IDerivationState_.POSSIBLY_STALE_;
          d.onBecomeStale_();
        }
      });
    }
    function logTraceInfo(derivation, observable2) {
      console.log("[mobx.trace] '" + derivation.name_ + "' is invalidated due to a change in: '" + observable2.name_ + "'");
      if (derivation.isTracing_ === TraceMode.BREAK) {
        var lines = [];
        printDepTree(getDependencyTree(derivation), lines, 1);
        new Function("debugger;\n/*\nTracing '" + derivation.name_ + "'\n\nYou are entering this break point because derivation '" + derivation.name_ + "' is being traced and '" + observable2.name_ + "' is now forcing it to update.\nJust follow the stacktrace you should now see in the devtools to see precisely what piece of your code is causing this update\nThe stackframe you are looking for is at least ~6-8 stack-frames up.\n\n" + (derivation instanceof ComputedValue ? derivation.derivation.toString().replace(/[*]\//g, "/") : "") + "\n\nThe dependencies for this derivation are:\n\n" + lines.join("\n") + "\n*/\n    ")();
      }
    }
    function printDepTree(tree, lines, depth) {
      if (lines.length >= 1e3) {
        lines.push("(and many more)");
        return;
      }
      lines.push("" + "	".repeat(depth - 1) + tree.name);
      if (tree.dependencies) {
        tree.dependencies.forEach(function(child) {
          return printDepTree(child, lines, depth + 1);
        });
      }
    }
    var Reaction = /* @__PURE__ */ (function() {
      function Reaction2(name_, onInvalidate_, errorHandler_, requiresObservable_) {
        if (name_ === void 0) {
          name_ = "Reaction@" + getNextId();
        }
        this.name_ = void 0;
        this.onInvalidate_ = void 0;
        this.errorHandler_ = void 0;
        this.requiresObservable_ = void 0;
        this.observing_ = [];
        this.newObserving_ = [];
        this.dependenciesState_ = IDerivationState_.NOT_TRACKING_;
        this.runId_ = 0;
        this.unboundDepsCount_ = 0;
        this.flags_ = 0;
        this.isTracing_ = TraceMode.NONE;
        this.name_ = name_;
        this.onInvalidate_ = onInvalidate_;
        this.errorHandler_ = errorHandler_;
        this.requiresObservable_ = requiresObservable_;
      }
      var _proto = Reaction2.prototype;
      _proto.onBecomeStale_ = function onBecomeStale_() {
        this.schedule_();
      };
      _proto.schedule_ = function schedule_() {
        if (!this.isScheduled) {
          this.isScheduled = true;
          globalState.pendingReactions.push(this);
          runReactions();
        }
      };
      _proto.runReaction_ = function runReaction_() {
        if (!this.isDisposed) {
          startBatch();
          this.isScheduled = false;
          var prev = globalState.trackingContext;
          globalState.trackingContext = this;
          if (shouldCompute(this)) {
            this.isTrackPending = true;
            try {
              this.onInvalidate_();
              if (this.isTrackPending && isSpyEnabled()) {
                spyReport({
                  name: this.name_,
                  type: "scheduled-reaction"
                });
              }
            } catch (e) {
              this.reportExceptionInDerivation_(e);
            }
          }
          globalState.trackingContext = prev;
          endBatch();
        }
      };
      _proto.track = function track(fn) {
        if (this.isDisposed) {
          return;
        }
        startBatch();
        var notify = isSpyEnabled();
        var startTime;
        if (notify) {
          startTime = Date.now();
          spyReportStart({
            name: this.name_,
            type: "reaction"
          });
        }
        this.isRunning = true;
        var prevReaction = globalState.trackingContext;
        globalState.trackingContext = this;
        var result = trackDerivedFunction(this, fn, void 0);
        globalState.trackingContext = prevReaction;
        this.isRunning = false;
        this.isTrackPending = false;
        if (this.isDisposed) {
          clearObserving(this);
        }
        if (isCaughtException(result)) {
          this.reportExceptionInDerivation_(result.cause);
        }
        if (notify) {
          spyReportEnd({
            time: Date.now() - startTime
          });
        }
        endBatch();
      };
      _proto.reportExceptionInDerivation_ = function reportExceptionInDerivation_(error) {
        var _this = this;
        if (this.errorHandler_) {
          this.errorHandler_(error, this);
          return;
        }
        if (globalState.disableErrorBoundaries) {
          throw error;
        }
        var message = "[mobx] Encountered an uncaught exception that was thrown by a reaction or observer component, in: '" + this + "'";
        if (!globalState.suppressReactionErrors) {
          console.error(message, error);
        } else {
          console.warn("[mobx] (error in reaction '" + this.name_ + "' suppressed, fix error of causing action below)");
        }
        if (isSpyEnabled()) {
          spyReport({
            type: "error",
            name: this.name_,
            message,
            error: "" + error
          });
        }
        globalState.globalReactionErrorHandlers.forEach(function(f) {
          return f(error, _this);
        });
      };
      _proto.dispose = function dispose() {
        if (!this.isDisposed) {
          this.isDisposed = true;
          if (!this.isRunning) {
            startBatch();
            clearObserving(this);
            endBatch();
          }
        }
      };
      _proto.getDisposer_ = function getDisposer_(abortSignal) {
        var _this2 = this;
        var dispose = function dispose2() {
          _this2.dispose();
          abortSignal == null || abortSignal.removeEventListener == null || abortSignal.removeEventListener("abort", dispose2);
        };
        abortSignal == null || abortSignal.addEventListener == null || abortSignal.addEventListener("abort", dispose);
        dispose[$mobx] = this;
        if ("dispose" in Symbol && typeof Symbol.dispose === "symbol") {
          dispose[Symbol.dispose] = dispose;
        }
        return dispose;
      };
      _proto.toString = function toString2() {
        return "Reaction[" + this.name_ + "]";
      };
      _proto.trace = function trace$1(enterBreakPoint) {
        if (enterBreakPoint === void 0) {
          enterBreakPoint = false;
        }
        trace(this, enterBreakPoint);
      };
      return _createClass(Reaction2, [{
        key: "isDisposed",
        get: function get2() {
          return getFlag(this.flags_, Reaction2.isDisposedMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Reaction2.isDisposedMask_, newValue);
        }
      }, {
        key: "isScheduled",
        get: function get2() {
          return getFlag(this.flags_, Reaction2.isScheduledMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Reaction2.isScheduledMask_, newValue);
        }
      }, {
        key: "isTrackPending",
        get: function get2() {
          return getFlag(this.flags_, Reaction2.isTrackPendingMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Reaction2.isTrackPendingMask_, newValue);
        }
      }, {
        key: "isRunning",
        get: function get2() {
          return getFlag(this.flags_, Reaction2.isRunningMask_);
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Reaction2.isRunningMask_, newValue);
        }
      }, {
        key: "diffValue",
        get: function get2() {
          return getFlag(this.flags_, Reaction2.diffValueMask_) ? 1 : 0;
        },
        set: function set2(newValue) {
          this.flags_ = setFlag(this.flags_, Reaction2.diffValueMask_, newValue === 1 ? true : false);
        }
      }]);
    })();
    Reaction.isDisposedMask_ = 1;
    Reaction.isScheduledMask_ = 2;
    Reaction.isTrackPendingMask_ = 4;
    Reaction.isRunningMask_ = 8;
    Reaction.diffValueMask_ = 16;
    function onReactionError(handler) {
      globalState.globalReactionErrorHandlers.push(handler);
      return function() {
        var idx = globalState.globalReactionErrorHandlers.indexOf(handler);
        if (idx >= 0) {
          globalState.globalReactionErrorHandlers.splice(idx, 1);
        }
      };
    }
    var MAX_REACTION_ITERATIONS = 100;
    var reactionScheduler = function reactionScheduler2(f) {
      return f();
    };
    function runReactions() {
      if (globalState.inBatch > 0 || globalState.isRunningReactions) {
        return;
      }
      reactionScheduler(runReactionsHelper);
    }
    function runReactionsHelper() {
      globalState.isRunningReactions = true;
      var allReactions = globalState.pendingReactions;
      var iterations = 0;
      while (allReactions.length > 0) {
        if (++iterations === MAX_REACTION_ITERATIONS) {
          console.error("Reaction doesn't converge to a stable state after " + MAX_REACTION_ITERATIONS + " iterations." + (" Probably there is a cycle in the reactive function: " + allReactions[0]));
          allReactions.splice(0);
        }
        var remainingReactions = allReactions.splice(0);
        for (var i = 0, l = remainingReactions.length; i < l; i++) {
          remainingReactions[i].runReaction_();
        }
      }
      globalState.isRunningReactions = false;
    }
    var isReaction = /* @__PURE__ */ createInstanceofPredicate("Reaction", Reaction);
    function setReactionScheduler(fn) {
      var baseScheduler = reactionScheduler;
      reactionScheduler = function reactionScheduler2(f) {
        return fn(function() {
          return baseScheduler(f);
        });
      };
    }
    function isSpyEnabled() {
      return !!globalState.spyListeners.length;
    }
    function spyReport(event) {
      if (!globalState.spyListeners.length) {
        return;
      }
      var listeners = globalState.spyListeners;
      for (var i = 0, l = listeners.length; i < l; i++) {
        listeners[i](event);
      }
    }
    function spyReportStart(event) {
      var change = _extends({}, event, {
        spyReportStart: true
      });
      spyReport(change);
    }
    var END_EVENT = {
      type: "report-end",
      spyReportEnd: true
    };
    function spyReportEnd(change) {
      if (change) {
        spyReport(_extends({}, change, {
          type: "report-end",
          spyReportEnd: true
        }));
      } else {
        spyReport(END_EVENT);
      }
    }
    function spy(listener) {
      {
        globalState.spyListeners.push(listener);
        return once(function() {
          globalState.spyListeners = globalState.spyListeners.filter(function(l) {
            return l !== listener;
          });
        });
      }
    }
    var ACTION = "action";
    var ACTION_BOUND = "action.bound";
    var AUTOACTION = "autoAction";
    var AUTOACTION_BOUND = "autoAction.bound";
    var DEFAULT_ACTION_NAME = "<unnamed action>";
    var actionAnnotation = /* @__PURE__ */ createActionAnnotation(ACTION);
    var actionBoundAnnotation = /* @__PURE__ */ createActionAnnotation(ACTION_BOUND, {
      bound: true
    });
    var autoActionAnnotation = /* @__PURE__ */ createActionAnnotation(AUTOACTION, {
      autoAction: true
    });
    var autoActionBoundAnnotation = /* @__PURE__ */ createActionAnnotation(AUTOACTION_BOUND, {
      autoAction: true,
      bound: true
    });
    function createActionFactory(autoAction2) {
      var res = function action2(arg1, arg2) {
        if (isFunction(arg1)) {
          return createAction(arg1.name || DEFAULT_ACTION_NAME, arg1, autoAction2);
        }
        if (isFunction(arg2)) {
          return createAction(arg1, arg2, autoAction2);
        }
        if (is20223Decorator(arg2)) {
          return (autoAction2 ? autoActionAnnotation : actionAnnotation).decorate_20223_(arg1, arg2);
        }
        if (isStringish(arg2)) {
          return storeAnnotation(arg1, arg2, autoAction2 ? autoActionAnnotation : actionAnnotation);
        }
        if (isStringish(arg1)) {
          return createDecoratorAnnotation(createActionAnnotation(autoAction2 ? AUTOACTION : ACTION, {
            name: arg1,
            autoAction: autoAction2
          }));
        }
        {
          die("Invalid arguments for `action`");
        }
      };
      return res;
    }
    var action = /* @__PURE__ */ createActionFactory(false);
    Object.assign(action, actionAnnotation);
    var autoAction = /* @__PURE__ */ createActionFactory(true);
    Object.assign(autoAction, autoActionAnnotation);
    action.bound = /* @__PURE__ */ createDecoratorAnnotation(actionBoundAnnotation);
    autoAction.bound = /* @__PURE__ */ createDecoratorAnnotation(autoActionBoundAnnotation);
    function runInAction3(fn) {
      return executeAction(fn.name || DEFAULT_ACTION_NAME, false, fn, this, void 0);
    }
    function isAction(thing) {
      return isFunction(thing) && thing.isMobxAction === true;
    }
    function autorun(view, opts) {
      var _opts$name, _opts, _opts2, _opts3;
      if (opts === void 0) {
        opts = EMPTY_OBJECT;
      }
      {
        if (!isFunction(view)) {
          die("Autorun expects a function as first argument");
        }
        if (isAction(view)) {
          die("Autorun does not accept actions since actions are untrackable");
        }
      }
      var name = (_opts$name = (_opts = opts) == null ? void 0 : _opts.name) != null ? _opts$name : view.name || "Autorun@" + getNextId();
      var runSync = !opts.scheduler && !opts.delay;
      var reaction2;
      if (runSync) {
        reaction2 = new Reaction(name, function() {
          this.track(reactionRunner);
        }, opts.onError, opts.requiresObservable);
      } else {
        var scheduler = createSchedulerFromOptions(opts);
        var isScheduled = false;
        reaction2 = new Reaction(name, function() {
          if (!isScheduled) {
            isScheduled = true;
            scheduler(function() {
              isScheduled = false;
              if (!reaction2.isDisposed) {
                reaction2.track(reactionRunner);
              }
            });
          }
        }, opts.onError, opts.requiresObservable);
      }
      function reactionRunner() {
        view(reaction2);
      }
      if (!((_opts2 = opts) != null && (_opts2 = _opts2.signal) != null && _opts2.aborted)) {
        reaction2.schedule_();
      }
      return reaction2.getDisposer_((_opts3 = opts) == null ? void 0 : _opts3.signal);
    }
    var run = function run2(f) {
      return f();
    };
    function createSchedulerFromOptions(opts) {
      return opts.scheduler ? opts.scheduler : opts.delay ? function(f) {
        return setTimeout(f, opts.delay);
      } : run;
    }
    function reaction(expression, effect, opts) {
      var _opts$name2, _opts4, _opts5;
      if (opts === void 0) {
        opts = EMPTY_OBJECT;
      }
      {
        if (!isFunction(expression) || !isFunction(effect)) {
          die("First and second argument to reaction should be functions");
        }
        if (!isPlainObject(opts)) {
          die("Third argument of reactions should be an object");
        }
      }
      var name = (_opts$name2 = opts.name) != null ? _opts$name2 : "Reaction@" + getNextId();
      var effectAction = action(name, opts.onError ? wrapErrorHandler(opts.onError, effect) : effect);
      var runSync = !opts.scheduler && !opts.delay;
      var scheduler = createSchedulerFromOptions(opts);
      var firstTime = true;
      var isScheduled = false;
      var value;
      var equals = opts.compareStructural ? comparer.structural : opts.equals || comparer["default"];
      var r = new Reaction(name, function() {
        if (firstTime || runSync) {
          reactionRunner();
        } else if (!isScheduled) {
          isScheduled = true;
          scheduler(reactionRunner);
        }
      }, opts.onError, opts.requiresObservable);
      function reactionRunner() {
        isScheduled = false;
        if (r.isDisposed) {
          return;
        }
        var changed = false;
        var oldValue = value;
        r.track(function() {
          var nextValue = allowStateChanges(false, function() {
            return expression(r);
          });
          changed = firstTime || !equals(value, nextValue);
          value = nextValue;
        });
        if (firstTime && opts.fireImmediately) {
          effectAction(value, oldValue, r);
        } else if (!firstTime && changed) {
          effectAction(value, oldValue, r);
        }
        firstTime = false;
      }
      if (!((_opts4 = opts) != null && (_opts4 = _opts4.signal) != null && _opts4.aborted)) {
        r.schedule_();
      }
      return r.getDisposer_((_opts5 = opts) == null ? void 0 : _opts5.signal);
    }
    function wrapErrorHandler(errorHandler, baseFn) {
      return function() {
        try {
          return baseFn.apply(this, arguments);
        } catch (e) {
          errorHandler.call(this, e);
        }
      };
    }
    var ON_BECOME_OBSERVED = "onBO";
    var ON_BECOME_UNOBSERVED = "onBUO";
    function onBecomeObserved(thing, arg2, arg3) {
      return interceptHook(ON_BECOME_OBSERVED, thing, arg2, arg3);
    }
    function onBecomeUnobserved(thing, arg2, arg3) {
      return interceptHook(ON_BECOME_UNOBSERVED, thing, arg2, arg3);
    }
    function interceptHook(hook, thing, arg2, arg3) {
      var atom = typeof arg3 === "function" ? getAtom(thing, arg2) : getAtom(thing);
      var cb = isFunction(arg3) ? arg3 : arg2;
      var listenersKey = hook + "L";
      if (atom[listenersKey]) {
        atom[listenersKey].add(cb);
      } else {
        atom[listenersKey] = /* @__PURE__ */ new Set([cb]);
      }
      return function() {
        var hookListeners = atom[listenersKey];
        if (hookListeners) {
          hookListeners["delete"](cb);
          if (hookListeners.size === 0) {
            delete atom[listenersKey];
          }
        }
      };
    }
    var NEVER = "never";
    var ALWAYS = "always";
    var OBSERVED = "observed";
    function configure(options) {
      if (options.isolateGlobalState === true) {
        isolateGlobalState();
      }
      var useProxies = options.useProxies, enforceActions = options.enforceActions;
      if (useProxies !== void 0) {
        globalState.useProxies = useProxies === ALWAYS ? true : useProxies === NEVER ? false : typeof Proxy !== "undefined";
      }
      if (useProxies === "ifavailable") {
        globalState.verifyProxies = true;
      }
      if (enforceActions !== void 0) {
        var ea = enforceActions === ALWAYS ? ALWAYS : enforceActions === OBSERVED;
        globalState.enforceActions = ea;
        globalState.allowStateChanges = ea === true || ea === ALWAYS ? false : true;
      }
      ["computedRequiresReaction", "reactionRequiresObservable", "observableRequiresReaction", "disableErrorBoundaries", "safeDescriptors"].forEach(function(key) {
        if (key in options) {
          globalState[key] = !!options[key];
        }
      });
      globalState.allowStateReads = !globalState.observableRequiresReaction;
      if (globalState.disableErrorBoundaries === true) {
        console.warn("WARNING: Debug feature only. MobX will NOT recover from errors when `disableErrorBoundaries` is enabled.");
      }
      if (options.reactionScheduler) {
        setReactionScheduler(options.reactionScheduler);
      }
    }
    function extendObservable(target, properties, annotations, options) {
      {
        if (arguments.length > 4) {
          die("'extendObservable' expected 2-4 arguments");
        }
        if (typeof target !== "object") {
          die("'extendObservable' expects an object as first argument");
        }
        if (isObservableMap(target)) {
          die("'extendObservable' should not be used on maps, use map.merge instead");
        }
        if (!isPlainObject(properties)) {
          die("'extendObservable' only accepts plain objects as second argument");
        }
        if (isObservable(properties) || isObservable(annotations)) {
          die("Extending an object with another observable (object) is not supported");
        }
      }
      var descriptors = getOwnPropertyDescriptors(properties);
      initObservable(function() {
        var adm = asObservableObject(target, options)[$mobx];
        ownKeys(descriptors).forEach(function(key) {
          adm.extend_(
            key,
            descriptors[key],
            // must pass "undefined" for { key: undefined }
            !annotations ? true : key in annotations ? annotations[key] : true
          );
        });
      });
      return target;
    }
    function getDependencyTree(thing, property) {
      return nodeToDependencyTree(getAtom(thing, property));
    }
    function nodeToDependencyTree(node) {
      var result = {
        name: node.name_
      };
      if (node.observing_ && node.observing_.length > 0) {
        result.dependencies = unique(node.observing_).map(nodeToDependencyTree);
      }
      return result;
    }
    function getObserverTree(thing, property) {
      return nodeToObserverTree(getAtom(thing, property));
    }
    function nodeToObserverTree(node) {
      var result = {
        name: node.name_
      };
      if (hasObservers(node)) {
        result.observers = Array.from(getObservers(node)).map(nodeToObserverTree);
      }
      return result;
    }
    function unique(list) {
      return Array.from(new Set(list));
    }
    var generatorId = 0;
    var FlowCancellationError = /* @__PURE__ */ (function(_Error) {
      function FlowCancellationError2() {
        var _this;
        _this = _Error.call(this, "FLOW_CANCELLED") || this;
        Object.setPrototypeOf(_this, (this instanceof FlowCancellationError2 ? this.constructor : void 0).prototype);
        _this.name = "FlowCancellationError";
        return _this;
      }
      _inheritsLoose(FlowCancellationError2, _Error);
      var _proto = FlowCancellationError2.prototype;
      _proto.toString = function toString2() {
        return "Error: " + this.message;
      };
      return FlowCancellationError2;
    })(/* @__PURE__ */ _wrapNativeSuper(Error));
    function isFlowCancellationError(error) {
      return error instanceof FlowCancellationError;
    }
    var flowAnnotation = /* @__PURE__ */ createFlowAnnotation("flow");
    var flowBoundAnnotation = /* @__PURE__ */ createFlowAnnotation("flow.bound", {
      bound: true
    });
    var flow = /* @__PURE__ */ Object.assign(function flow2(arg1, arg2) {
      if (is20223Decorator(arg2)) {
        return flowAnnotation.decorate_20223_(arg1, arg2);
      }
      if (isStringish(arg2)) {
        return storeAnnotation(arg1, arg2, flowAnnotation);
      }
      if (arguments.length !== 1) {
        die("Flow expects single argument with generator function");
      }
      var generator = arg1;
      var name = generator.name || "<unnamed flow>";
      var res = function res2() {
        var ctx = this;
        var args = arguments;
        var runId = ++generatorId;
        var gen = action(name + " - runid: " + runId + " - init", generator).apply(ctx, args);
        var rejector;
        var pendingPromise = void 0;
        var promise = new Promise(function(resolve, reject) {
          var stepId = 0;
          rejector = reject;
          function onFulfilled(res3) {
            pendingPromise = void 0;
            var ret;
            try {
              ret = action(name + " - runid: " + runId + " - yield " + stepId++, gen.next).call(gen, res3);
            } catch (e) {
              return reject(e);
            }
            next(ret);
          }
          function onRejected(err) {
            pendingPromise = void 0;
            var ret;
            try {
              ret = action(name + " - runid: " + runId + " - yield " + stepId++, gen["throw"]).call(gen, err);
            } catch (e) {
              return reject(e);
            }
            next(ret);
          }
          function next(ret) {
            if (isFunction(ret == null ? void 0 : ret.then)) {
              ret.then(next, reject);
              return;
            }
            if (ret.done) {
              return resolve(ret.value);
            }
            pendingPromise = Promise.resolve(ret.value);
            return pendingPromise.then(onFulfilled, onRejected);
          }
          onFulfilled(void 0);
        });
        promise.cancel = action(name + " - runid: " + runId + " - cancel", function() {
          try {
            if (pendingPromise) {
              cancelPromise(pendingPromise);
            }
            var _res = gen["return"](void 0);
            var yieldedPromise = Promise.resolve(_res.value);
            yieldedPromise.then(noop, noop);
            cancelPromise(yieldedPromise);
            rejector(new FlowCancellationError());
          } catch (e) {
            rejector(e);
          }
        });
        return promise;
      };
      res.isMobXFlow = true;
      return res;
    }, flowAnnotation);
    flow.bound = /* @__PURE__ */ createDecoratorAnnotation(flowBoundAnnotation);
    function cancelPromise(promise) {
      if (isFunction(promise.cancel)) {
        promise.cancel();
      }
    }
    function flowResult(result) {
      return result;
    }
    function isFlow(fn) {
      return (fn == null ? void 0 : fn.isMobXFlow) === true;
    }
    function interceptReads(thing, propOrHandler, handler) {
      var target;
      if (isObservableMap(thing) || isObservableArray(thing) || isObservableValue(thing)) {
        target = getAdministration(thing);
      } else if (isObservableObject(thing)) {
        if (!isStringish(propOrHandler)) {
          return die("InterceptReads can only be used with a specific property, not with an object in general");
        }
        target = getAdministration(thing, propOrHandler);
      } else {
        return die("Expected observable map, object or array as first array");
      }
      if (target.dehancer !== void 0) {
        return die("An intercept reader was already established");
      }
      target.dehancer = typeof propOrHandler === "function" ? propOrHandler : handler;
      return function() {
        target.dehancer = void 0;
      };
    }
    function intercept(thing, propOrHandler, handler) {
      if (isFunction(handler)) {
        return interceptProperty(thing, propOrHandler, handler);
      } else {
        return interceptInterceptable(thing, propOrHandler);
      }
    }
    function interceptInterceptable(thing, handler) {
      return getAdministration(thing).intercept_(handler);
    }
    function interceptProperty(thing, property, handler) {
      return getAdministration(thing, property).intercept_(handler);
    }
    function _isComputed(value, property) {
      var _adm$lazyComputedKeys;
      if (property === void 0) {
        return isComputedValue(value);
      }
      if (isObservableObject(value) === false) {
        return false;
      }
      var adm = value[$mobx];
      if ((_adm$lazyComputedKeys = adm.lazyComputedKeys_) != null && _adm$lazyComputedKeys.has(property)) {
        return true;
      }
      if (!adm.values_.has(property)) {
        return false;
      }
      var atom = getAtom(value, property);
      return isComputedValue(atom);
    }
    function isComputed(value) {
      if (arguments.length > 1) {
        return die("isComputed expects only 1 argument. Use isComputedProp to inspect the observability of a property");
      }
      return _isComputed(value);
    }
    function isComputedProp(value, propName) {
      if (!isStringish(propName)) {
        return die("isComputed expected a property name as second argument");
      }
      return _isComputed(value, propName);
    }
    function _isObservable(value, property) {
      if (!value) {
        return false;
      }
      if (property !== void 0) {
        if (isObservableMap(value) || isObservableArray(value)) {
          return die("isObservable(object, propertyName) is not supported for arrays and maps. Use map.has or array.length instead.");
        }
        if (isObservableObject(value)) {
          var _adm$lazyComputedKeys, _adm$lazyObservableKe;
          var adm = value[$mobx];
          return adm.values_.has(property) || !!((_adm$lazyComputedKeys = adm.lazyComputedKeys_) != null && _adm$lazyComputedKeys.has(property)) || !!((_adm$lazyObservableKe = adm.lazyObservableKeys_) != null && _adm$lazyObservableKe.has(property));
        }
        return false;
      }
      return isObservableObject(value) || !!value[$mobx] || isAtom(value) || isReaction(value) || isComputedValue(value);
    }
    function isObservable(value) {
      if (arguments.length !== 1) {
        die("isObservable expects only 1 argument. Use isObservableProp to inspect the observability of a property");
      }
      return _isObservable(value);
    }
    function isObservableProp(value, propName) {
      if (!isStringish(propName)) {
        return die("expected a property name as second argument");
      }
      return _isObservable(value, propName);
    }
    function keys(obj) {
      if (isObservableObject(obj)) {
        return obj[$mobx].keys_();
      }
      if (isObservableMap(obj) || isObservableSet(obj)) {
        return Array.from(obj.keys());
      }
      if (isObservableArray(obj)) {
        return obj.map(function(_, index) {
          return index;
        });
      }
      die(5);
    }
    function values(obj) {
      if (isObservableObject(obj)) {
        return keys(obj).map(function(key) {
          return obj[key];
        });
      }
      if (isObservableMap(obj)) {
        return keys(obj).map(function(key) {
          return obj.get(key);
        });
      }
      if (isObservableSet(obj)) {
        return Array.from(obj.values());
      }
      if (isObservableArray(obj)) {
        return obj.slice();
      }
      die(6);
    }
    function entries(obj) {
      if (isObservableObject(obj)) {
        return keys(obj).map(function(key) {
          return [key, obj[key]];
        });
      }
      if (isObservableMap(obj)) {
        return keys(obj).map(function(key) {
          return [key, obj.get(key)];
        });
      }
      if (isObservableSet(obj)) {
        return Array.from(obj.entries());
      }
      if (isObservableArray(obj)) {
        return obj.map(function(key, index) {
          return [index, key];
        });
      }
      die(7);
    }
    function set(obj, key, value) {
      if (arguments.length === 2 && !isObservableSet(obj)) {
        startBatch();
        var _values = key;
        try {
          for (var _key in _values) {
            set(obj, _key, _values[_key]);
          }
        } finally {
          endBatch();
        }
        return;
      }
      if (isObservableObject(obj)) {
        obj[$mobx].set_(key, value);
      } else if (isObservableMap(obj)) {
        obj.set(key, value);
      } else if (isObservableSet(obj)) {
        obj.add(key);
      } else if (isObservableArray(obj)) {
        if (typeof key !== "number") {
          key = parseInt(key, 10);
        }
        if (key < 0) {
          die("Invalid index: '" + key + "'");
        }
        startBatch();
        if (key >= obj.length) {
          obj.length = key + 1;
        }
        obj[key] = value;
        endBatch();
      } else {
        die(8);
      }
    }
    function remove(obj, key) {
      if (isObservableObject(obj)) {
        obj[$mobx].delete_(key);
      } else if (isObservableMap(obj)) {
        obj["delete"](key);
      } else if (isObservableSet(obj)) {
        obj["delete"](key);
      } else if (isObservableArray(obj)) {
        if (typeof key !== "number") {
          key = parseInt(key, 10);
        }
        obj.splice(key, 1);
      } else {
        die(9);
      }
    }
    function has(obj, key) {
      if (isObservableObject(obj)) {
        return obj[$mobx].has_(key);
      } else if (isObservableMap(obj)) {
        return obj.has(key);
      } else if (isObservableSet(obj)) {
        return obj.has(key);
      } else if (isObservableArray(obj)) {
        return key >= 0 && key < obj.length;
      }
      die(10);
    }
    function get(obj, key) {
      if (!has(obj, key)) {
        return void 0;
      }
      if (isObservableObject(obj)) {
        return obj[$mobx].get_(key);
      } else if (isObservableMap(obj)) {
        return obj.get(key);
      } else if (isObservableArray(obj)) {
        return obj[key];
      }
      die(11);
    }
    function apiDefineProperty(obj, key, descriptor) {
      if (isObservableObject(obj)) {
        return obj[$mobx].defineProperty_(key, descriptor);
      }
      die(39);
    }
    function apiOwnKeys(obj) {
      if (isObservableObject(obj)) {
        return obj[$mobx].ownKeys_();
      }
      die(38);
    }
    function observe(thing, propOrCb, cbOrFire, fireImmediately) {
      if (isFunction(cbOrFire)) {
        return observeObservableProperty(thing, propOrCb, cbOrFire, fireImmediately);
      } else {
        return observeObservable(thing, propOrCb, cbOrFire);
      }
    }
    function observeObservable(thing, listener, fireImmediately) {
      return getAdministration(thing).observe_(listener, fireImmediately);
    }
    function observeObservableProperty(thing, property, listener, fireImmediately) {
      return getAdministration(thing, property).observe_(listener, fireImmediately);
    }
    function cache(map, key, value) {
      map.set(key, value);
      return value;
    }
    function toJSHelper(source, __alreadySeen) {
      if (source == null || typeof source !== "object" || source instanceof Date || !isObservable(source)) {
        return source;
      }
      if (isObservableValue(source) || isComputedValue(source)) {
        return toJSHelper(source.get(), __alreadySeen);
      }
      if (__alreadySeen.has(source)) {
        return __alreadySeen.get(source);
      }
      if (isObservableArray(source)) {
        var res = cache(__alreadySeen, source, new Array(source.length));
        source.forEach(function(value, idx) {
          res[idx] = toJSHelper(value, __alreadySeen);
        });
        return res;
      }
      if (isObservableSet(source)) {
        var _res = cache(__alreadySeen, source, /* @__PURE__ */ new Set());
        source.forEach(function(value) {
          _res.add(toJSHelper(value, __alreadySeen));
        });
        return _res;
      }
      if (isObservableMap(source)) {
        var _res2 = cache(__alreadySeen, source, /* @__PURE__ */ new Map());
        source.forEach(function(value, key) {
          _res2.set(key, toJSHelper(value, __alreadySeen));
        });
        return _res2;
      } else {
        var _res3 = cache(__alreadySeen, source, {});
        apiOwnKeys(source).forEach(function(key) {
          if (objectPrototype.propertyIsEnumerable.call(source, key)) {
            _res3[key] = toJSHelper(source[key], __alreadySeen);
          }
        });
        return _res3;
      }
    }
    function toJS(source, options) {
      if (options) {
        die("toJS no longer supports options");
      }
      return toJSHelper(source, /* @__PURE__ */ new Map());
    }
    function trace() {
      var enterBreakPoint = false;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      if (typeof args[args.length - 1] === "boolean") {
        enterBreakPoint = args.pop();
      }
      var derivation = getAtomFromArgs(args);
      if (!derivation) {
        return die("'trace(break?)' can only be used inside a tracked computed value or a Reaction. Consider passing in the computed value or reaction explicitly");
      }
      if (derivation.isTracing_ === TraceMode.NONE) {
        console.log("[mobx.trace] '" + derivation.name_ + "' tracing enabled");
      }
      derivation.isTracing_ = enterBreakPoint ? TraceMode.BREAK : TraceMode.LOG;
    }
    function getAtomFromArgs(args) {
      switch (args.length) {
        case 0:
          return globalState.trackingDerivation;
        case 1:
          return getAtom(args[0]);
        case 2:
          return getAtom(args[0], args[1]);
      }
    }
    function transaction(action2, thisArg) {
      if (thisArg === void 0) {
        thisArg = void 0;
      }
      startBatch();
      try {
        return action2.apply(thisArg);
      } finally {
        endBatch();
      }
    }
    function when2(predicate, arg1, arg2) {
      if (arguments.length === 1 || arg1 && typeof arg1 === "object") {
        return whenPromise(predicate, arg1);
      }
      return _when(predicate, arg1, arg2 || {});
    }
    function _when(predicate, effect, opts) {
      var timeoutHandle;
      if (typeof opts.timeout === "number") {
        var error = new Error("WHEN_TIMEOUT");
        timeoutHandle = setTimeout(function() {
          if (!disposer[$mobx].isDisposed) {
            disposer();
            if (opts.onError) {
              opts.onError(error);
            } else {
              throw error;
            }
          }
        }, opts.timeout);
      }
      opts.name = opts.name || "When@" + getNextId();
      var effectAction = createAction(opts.name + "-effect", effect);
      var disposer = autorun(function(r) {
        var cond = allowStateChanges(false, predicate);
        if (cond) {
          r.dispose();
          if (timeoutHandle) {
            clearTimeout(timeoutHandle);
          }
          effectAction();
        }
      }, opts);
      return disposer;
    }
    function whenPromise(predicate, opts) {
      var _opts$signal;
      if (opts && opts.onError) {
        return die("the options 'onError' and 'promise' cannot be combined");
      }
      if (opts != null && (_opts$signal = opts.signal) != null && _opts$signal.aborted) {
        return Object.assign(Promise.reject(new Error("WHEN_ABORTED")), {
          cancel: function cancel2() {
            return null;
          }
        });
      }
      var cancel;
      var abort;
      var res = new Promise(function(resolve, reject) {
        var _opts$signal2;
        var disposer = _when(predicate, resolve, _extends({}, opts, {
          onError: reject
        }));
        cancel = function cancel2() {
          disposer();
          reject(new Error("WHEN_CANCELLED"));
        };
        abort = function abort2() {
          disposer();
          reject(new Error("WHEN_ABORTED"));
        };
        opts == null || (_opts$signal2 = opts.signal) == null || _opts$signal2.addEventListener == null || _opts$signal2.addEventListener("abort", abort);
      })["finally"](function() {
        var _opts$signal3;
        return opts == null || (_opts$signal3 = opts.signal) == null || _opts$signal3.removeEventListener == null ? void 0 : _opts$signal3.removeEventListener("abort", abort);
      });
      res.cancel = cancel;
      return res;
    }
    function getAdm(target) {
      return target[$mobx];
    }
    var objectProxyTraps = {
      has: function has2(target, name) {
        if (globalState.trackingDerivation) {
          warnAboutProxyRequirement("detect new properties using the 'in' operator. Use 'has' from 'mobx' instead.");
        }
        return getAdm(target).has_(name);
      },
      get: function get2(target, name) {
        return getAdm(target).get_(name);
      },
      set: function set2(target, name, value) {
        var _getAdm$set_;
        if (!isStringish(name)) {
          return false;
        }
        if (!getAdm(target).values_.has(name)) {
          warnAboutProxyRequirement("add a new observable property through direct assignment. Use 'set' from 'mobx' instead.");
        }
        return (_getAdm$set_ = getAdm(target).set_(name, value, true)) != null ? _getAdm$set_ : true;
      },
      deleteProperty: function deleteProperty(target, name) {
        var _getAdm$delete_;
        {
          warnAboutProxyRequirement("delete properties from an observable object. Use 'remove' from 'mobx' instead.");
        }
        if (!isStringish(name)) {
          return false;
        }
        return (_getAdm$delete_ = getAdm(target).delete_(name, true)) != null ? _getAdm$delete_ : true;
      },
      defineProperty: function defineProperty2(target, name, descriptor) {
        var _getAdm$definePropert;
        {
          warnAboutProxyRequirement("define property on an observable object. Use 'defineProperty' from 'mobx' instead.");
        }
        return (_getAdm$definePropert = getAdm(target).defineProperty_(name, descriptor)) != null ? _getAdm$definePropert : true;
      },
      ownKeys: function ownKeys2(target) {
        if (globalState.trackingDerivation) {
          warnAboutProxyRequirement("iterate keys to detect added / removed properties. Use 'keys' from 'mobx' instead.");
        }
        return getAdm(target).ownKeys_();
      },
      preventExtensions: function preventExtensions(target) {
        die(13);
      }
    };
    function asDynamicObservableObject(target, options) {
      var _target$$mobx, _target$$mobx$proxy_;
      assertProxies();
      target = asObservableObject(target, options);
      return (_target$$mobx$proxy_ = (_target$$mobx = target[$mobx]).proxy_) != null ? _target$$mobx$proxy_ : _target$$mobx.proxy_ = new Proxy(target, objectProxyTraps);
    }
    function hasInterceptors(interceptable) {
      return interceptable.interceptors_ !== void 0 && interceptable.interceptors_.length > 0;
    }
    function registerInterceptor(interceptable, handler) {
      var interceptors = interceptable.interceptors_ || (interceptable.interceptors_ = []);
      interceptors.push(handler);
      return once(function() {
        var idx = interceptors.indexOf(handler);
        if (idx !== -1) {
          interceptors.splice(idx, 1);
        }
      });
    }
    function interceptChange(interceptable, change) {
      var prevU = untrackedStart();
      try {
        var interceptors = [].concat(interceptable.interceptors_ || []);
        for (var i = 0, l = interceptors.length; i < l; i++) {
          change = interceptors[i](change);
          if (change && !change.type) {
            die(14);
          }
          if (!change) {
            break;
          }
        }
        return change;
      } finally {
        untrackedEnd(prevU);
      }
    }
    function hasListeners(listenable) {
      return listenable.changeListeners_ !== void 0 && listenable.changeListeners_.length > 0;
    }
    function registerListener(listenable, handler) {
      var listeners = listenable.changeListeners_ || (listenable.changeListeners_ = []);
      listeners.push(handler);
      return once(function() {
        var idx = listeners.indexOf(handler);
        if (idx !== -1) {
          listeners.splice(idx, 1);
        }
      });
    }
    function notifyListeners(listenable, change) {
      var prevU = untrackedStart();
      var listeners = listenable.changeListeners_;
      if (!listeners) {
        return;
      }
      listeners = listeners.slice();
      for (var i = 0, l = listeners.length; i < l; i++) {
        listeners[i](change);
      }
      untrackedEnd(prevU);
    }
    function makeObservable(target, annotations, options) {
      initObservable(function() {
        var _annotations;
        var adm = asObservableObject(target, options)[$mobx];
        if (annotations && target[storedAnnotationsSymbol]) {
          die("makeObservable second arg must be nullish when using decorators. Mixing @decorator syntax with annotations is not supported.");
        }
        (_annotations = annotations) != null ? _annotations : annotations = collectStoredAnnotations(target);
        ownKeys(annotations).forEach(function(key) {
          return adm.make_(key, annotations[key]);
        });
      });
      return target;
    }
    var keysSymbol = /* @__PURE__ */ Symbol("mobx-keys");
    function makeAutoObservable2(target, overrides, options) {
      {
        if (!isPlainObject(target) && !isPlainObject(Object.getPrototypeOf(target))) {
          die("'makeAutoObservable' can only be used for classes that don't have a superclass");
        }
        if (isObservableObject(target)) {
          die("makeAutoObservable can only be used on objects not already made observable");
        }
      }
      if (isPlainObject(target)) {
        return extendObservable(target, target, overrides, options);
      }
      initObservable(function() {
        var adm = asObservableObject(target, options)[$mobx];
        if (!target[keysSymbol]) {
          var proto = Object.getPrototypeOf(target);
          var keys2 = new Set([].concat(ownKeys(target), ownKeys(proto)));
          keys2["delete"]("constructor");
          keys2["delete"]($mobx);
          addHiddenProp(proto, keysSymbol, keys2);
        }
        target[keysSymbol].forEach(function(key) {
          return adm.make_(
            key,
            // must pass "undefined" for { key: undefined }
            !overrides ? true : key in overrides ? overrides[key] : true
          );
        });
      });
      return target;
    }
    var SPLICE = "splice";
    var UPDATE = "update";
    var MAX_SPLICE_SIZE = 1e4;
    var arrayTraps = {
      get: function get2(target, name) {
        var adm = target[$mobx];
        if (name === $mobx) {
          return adm;
        }
        if (name === "length") {
          return adm.getArrayLength_();
        }
        if (typeof name === "string" && !isNaN(name)) {
          return adm.get_(parseInt(name));
        }
        if (hasProp(arrayExtensions, name)) {
          return arrayExtensions[name];
        }
        return target[name];
      },
      set: function set2(target, name, value) {
        var adm = target[$mobx];
        if (name === "length") {
          adm.setArrayLength_(value);
        }
        if (typeof name === "symbol" || isNaN(name)) {
          target[name] = value;
        } else {
          adm.set_(parseInt(name), value);
        }
        return true;
      },
      preventExtensions: function preventExtensions() {
        die(15);
      }
    };
    var ObservableArrayAdministration = /* @__PURE__ */ (function() {
      function ObservableArrayAdministration2(name, enhancer, owned_, legacyMode_) {
        if (name === void 0) {
          name = "ObservableArray@" + getNextId();
        }
        this.owned_ = void 0;
        this.legacyMode_ = void 0;
        this.atom_ = void 0;
        this.values_ = [];
        this.interceptors_ = void 0;
        this.changeListeners_ = void 0;
        this.enhancer_ = void 0;
        this.dehancer = void 0;
        this.proxy_ = void 0;
        this.lastKnownLength_ = 0;
        this.owned_ = owned_;
        this.legacyMode_ = legacyMode_;
        this.atom_ = new Atom(name);
        this.enhancer_ = function(newV, oldV) {
          return enhancer(newV, oldV, name + "[..]");
        };
      }
      var _proto = ObservableArrayAdministration2.prototype;
      _proto.dehanceValue_ = function dehanceValue_(value) {
        if (this.dehancer !== void 0) {
          return this.dehancer(value);
        }
        return value;
      };
      _proto.dehanceValues_ = function dehanceValues_(values2) {
        if (this.dehancer !== void 0 && values2.length > 0) {
          return values2.map(this.dehancer);
        }
        return values2;
      };
      _proto.intercept_ = function intercept_(handler) {
        return registerInterceptor(this, handler);
      };
      _proto.observe_ = function observe_(listener, fireImmediately) {
        if (fireImmediately === void 0) {
          fireImmediately = false;
        }
        if (fireImmediately) {
          listener({
            observableKind: "array",
            object: this.proxy_,
            debugObjectName: this.atom_.name_,
            type: "splice",
            index: 0,
            added: this.values_.slice(),
            addedCount: this.values_.length,
            removed: [],
            removedCount: 0
          });
        }
        return registerListener(this, listener);
      };
      _proto.getArrayLength_ = function getArrayLength_() {
        this.atom_.reportObserved();
        return this.values_.length;
      };
      _proto.setArrayLength_ = function setArrayLength_(newLength) {
        if (typeof newLength !== "number" || isNaN(newLength) || newLength < 0) {
          die("Out of range: " + newLength);
        }
        var currentLength = this.values_.length;
        if (newLength === currentLength) {
          return;
        } else if (newLength > currentLength) {
          var newItems = new Array(newLength - currentLength);
          for (var i = 0; i < newLength - currentLength; i++) {
            newItems[i] = void 0;
          }
          this.spliceWithArray_(currentLength, 0, newItems);
        } else {
          this.spliceWithArray_(newLength, currentLength - newLength);
        }
      };
      _proto.updateArrayLength_ = function updateArrayLength_(oldLength, delta) {
        if (oldLength !== this.lastKnownLength_) {
          die(16);
        }
        this.lastKnownLength_ += delta;
        if (this.legacyMode_ && delta > 0) {
          reserveArrayBuffer(oldLength + delta + 1);
        }
      };
      _proto.spliceWithArray_ = function spliceWithArray_(index, deleteCount, newItems) {
        var _this = this;
        checkIfStateModificationsAreAllowed(this.atom_);
        var length = this.values_.length;
        if (index === void 0) {
          index = 0;
        } else if (index > length) {
          index = length;
        } else if (index < 0) {
          index = Math.max(0, length + index);
        }
        if (arguments.length === 1) {
          deleteCount = length - index;
        } else if (deleteCount === void 0 || deleteCount === null) {
          deleteCount = 0;
        } else {
          deleteCount = Math.max(0, Math.min(deleteCount, length - index));
        }
        if (newItems === void 0) {
          newItems = EMPTY_ARRAY;
        }
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            object: this.proxy_,
            type: SPLICE,
            index,
            removedCount: deleteCount,
            added: newItems
          });
          if (!change) {
            return EMPTY_ARRAY;
          }
          deleteCount = change.removedCount;
          newItems = change.added;
        }
        newItems = newItems.length === 0 ? newItems : newItems.map(function(v) {
          return _this.enhancer_(v, void 0);
        });
        if (this.legacyMode_ || true) {
          var lengthDelta = newItems.length - deleteCount;
          this.updateArrayLength_(length, lengthDelta);
        }
        var res = this.spliceItemsIntoValues_(index, deleteCount, newItems);
        if (deleteCount !== 0 || newItems.length !== 0) {
          this.notifyArraySplice_(index, newItems, res);
        }
        return this.dehanceValues_(res);
      };
      _proto.spliceItemsIntoValues_ = function spliceItemsIntoValues_(index, deleteCount, newItems) {
        if (newItems.length < MAX_SPLICE_SIZE) {
          var _this$values_;
          return (_this$values_ = this.values_).splice.apply(_this$values_, [index, deleteCount].concat(newItems));
        } else {
          var res = this.values_.slice(index, index + deleteCount);
          var oldItems = this.values_.slice(index + deleteCount);
          this.values_.length += newItems.length - deleteCount;
          for (var i = 0; i < newItems.length; i++) {
            this.values_[index + i] = newItems[i];
          }
          for (var _i = 0; _i < oldItems.length; _i++) {
            this.values_[index + newItems.length + _i] = oldItems[_i];
          }
          return res;
        }
      };
      _proto.notifyArrayChildUpdate_ = function notifyArrayChildUpdate_(index, newValue, oldValue) {
        var notifySpy = !this.owned_ && isSpyEnabled();
        var notify = hasListeners(this);
        var change = notify || notifySpy ? {
          observableKind: "array",
          object: this.proxy_,
          type: UPDATE,
          debugObjectName: this.atom_.name_,
          index,
          newValue,
          oldValue
        } : null;
        if (notifySpy) {
          spyReportStart(change);
        }
        this.atom_.reportChanged();
        if (notify) {
          notifyListeners(this, change);
        }
        if (notifySpy) {
          spyReportEnd();
        }
      };
      _proto.notifyArraySplice_ = function notifyArraySplice_(index, added, removed) {
        var notifySpy = !this.owned_ && isSpyEnabled();
        var notify = hasListeners(this);
        var change = notify || notifySpy ? {
          observableKind: "array",
          object: this.proxy_,
          debugObjectName: this.atom_.name_,
          type: SPLICE,
          index,
          removed,
          added,
          removedCount: removed.length,
          addedCount: added.length
        } : null;
        if (notifySpy) {
          spyReportStart(change);
        }
        this.atom_.reportChanged();
        if (notify) {
          notifyListeners(this, change);
        }
        if (notifySpy) {
          spyReportEnd();
        }
      };
      _proto.get_ = function get_(index) {
        if (this.legacyMode_ && index >= this.values_.length) {
          console.warn("[mobx.array] Attempt to read an array index (" + index + ") that is out of bounds (" + this.values_.length + "). Please check length first. Out of bound indices will not be tracked by MobX");
          return void 0;
        }
        this.atom_.reportObserved();
        return this.dehanceValue_(this.values_[index]);
      };
      _proto.set_ = function set_(index, newValue) {
        var values2 = this.values_;
        if (this.legacyMode_ && index > values2.length) {
          die(17, index, values2.length);
        }
        if (index < values2.length) {
          checkIfStateModificationsAreAllowed(this.atom_);
          var oldValue = values2[index];
          if (hasInterceptors(this)) {
            var change = interceptChange(this, {
              type: UPDATE,
              object: this.proxy_,
              // since "this" is the real array we need to pass its proxy
              index,
              newValue
            });
            if (!change) {
              return;
            }
            newValue = change.newValue;
          }
          newValue = this.enhancer_(newValue, oldValue);
          var changed = newValue !== oldValue;
          if (changed) {
            values2[index] = newValue;
            this.notifyArrayChildUpdate_(index, newValue, oldValue);
          }
        } else {
          var newItems = new Array(index + 1 - values2.length);
          for (var i = 0; i < newItems.length - 1; i++) {
            newItems[i] = void 0;
          }
          newItems[newItems.length - 1] = newValue;
          this.spliceWithArray_(values2.length, 0, newItems);
        }
      };
      return ObservableArrayAdministration2;
    })();
    function createObservableArray(initialValues, enhancer, name, owned) {
      if (name === void 0) {
        name = "ObservableArray@" + getNextId();
      }
      if (owned === void 0) {
        owned = false;
      }
      assertProxies();
      return initObservable(function() {
        var adm = new ObservableArrayAdministration(name, enhancer, owned, false);
        addHiddenFinalProp(adm.values_, $mobx, adm);
        var proxy = new Proxy(adm.values_, arrayTraps);
        adm.proxy_ = proxy;
        if (initialValues && initialValues.length) {
          adm.spliceWithArray_(0, 0, initialValues);
        }
        return proxy;
      });
    }
    var arrayExtensions = {
      clear: function clear() {
        return this.splice(0);
      },
      replace: function replace(newItems) {
        var adm = this[$mobx];
        return adm.spliceWithArray_(0, adm.values_.length, newItems);
      },
      // Used by JSON.stringify
      toJSON: function toJSON() {
        return this.slice();
      },
      /*
       * functions that do alter the internal structure of the array, (based on lib.es6.d.ts)
       * since these functions alter the inner structure of the array, the have side effects.
       * Because the have side effects, they should not be used in computed function,
       * and for that reason the do not call dependencyState.notifyObserved
       */
      splice: function splice(index, deleteCount) {
        for (var _len = arguments.length, newItems = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          newItems[_key - 2] = arguments[_key];
        }
        var adm = this[$mobx];
        switch (arguments.length) {
          case 0:
            return [];
          case 1:
            return adm.spliceWithArray_(index);
          case 2:
            return adm.spliceWithArray_(index, deleteCount);
        }
        return adm.spliceWithArray_(index, deleteCount, newItems);
      },
      spliceWithArray: function spliceWithArray(index, deleteCount, newItems) {
        return this[$mobx].spliceWithArray_(index, deleteCount, newItems);
      },
      push: function push() {
        var adm = this[$mobx];
        for (var _len2 = arguments.length, items = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          items[_key2] = arguments[_key2];
        }
        adm.spliceWithArray_(adm.values_.length, 0, items);
        return adm.values_.length;
      },
      pop: function pop() {
        return this.splice(Math.max(this[$mobx].values_.length - 1, 0), 1)[0];
      },
      shift: function shift() {
        return this.splice(0, 1)[0];
      },
      unshift: function unshift() {
        var adm = this[$mobx];
        for (var _len3 = arguments.length, items = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          items[_key3] = arguments[_key3];
        }
        adm.spliceWithArray_(0, 0, items);
        return adm.values_.length;
      },
      reverse: function reverse() {
        if (globalState.trackingDerivation) {
          die(37, "reverse");
        }
        this.replace(this.slice().reverse());
        return this;
      },
      sort: function sort() {
        if (globalState.trackingDerivation) {
          die(37, "sort");
        }
        var copy = this.slice();
        copy.sort.apply(copy, arguments);
        this.replace(copy);
        return this;
      },
      remove: function remove2(value) {
        var adm = this[$mobx];
        var idx = adm.dehanceValues_(adm.values_).indexOf(value);
        if (idx > -1) {
          this.splice(idx, 1);
          return true;
        }
        return false;
      }
    };
    addArrayExtension("at", simpleFunc);
    addArrayExtension("concat", simpleFunc);
    addArrayExtension("flat", simpleFunc);
    addArrayExtension("includes", simpleFunc);
    addArrayExtension("indexOf", simpleFunc);
    addArrayExtension("join", simpleFunc);
    addArrayExtension("lastIndexOf", simpleFunc);
    addArrayExtension("slice", simpleFunc);
    addArrayExtension("toString", simpleFunc);
    addArrayExtension("toLocaleString", simpleFunc);
    addArrayExtension("toSorted", simpleFunc);
    addArrayExtension("toSpliced", simpleFunc);
    addArrayExtension("with", simpleFunc);
    addArrayExtension("every", mapLikeFunc);
    addArrayExtension("filter", mapLikeFunc);
    addArrayExtension("find", mapLikeFunc);
    addArrayExtension("findIndex", mapLikeFunc);
    addArrayExtension("findLast", mapLikeFunc);
    addArrayExtension("findLastIndex", mapLikeFunc);
    addArrayExtension("flatMap", mapLikeFunc);
    addArrayExtension("forEach", mapLikeFunc);
    addArrayExtension("map", mapLikeFunc);
    addArrayExtension("some", mapLikeFunc);
    addArrayExtension("toReversed", mapLikeFunc);
    addArrayExtension("reduce", reduceLikeFunc);
    addArrayExtension("reduceRight", reduceLikeFunc);
    function addArrayExtension(funcName, funcFactory) {
      if (typeof Array.prototype[funcName] === "function") {
        arrayExtensions[funcName] = funcFactory(funcName);
      }
    }
    function simpleFunc(funcName) {
      return function() {
        var adm = this[$mobx];
        adm.atom_.reportObserved();
        var dehancedValues = adm.dehanceValues_(adm.values_);
        return dehancedValues[funcName].apply(dehancedValues, arguments);
      };
    }
    function mapLikeFunc(funcName) {
      return function(callback, thisArg) {
        var _this2 = this;
        var adm = this[$mobx];
        adm.atom_.reportObserved();
        var dehancedValues = adm.dehanceValues_(adm.values_);
        return dehancedValues[funcName](function(element, index) {
          return callback.call(thisArg, element, index, _this2);
        });
      };
    }
    function reduceLikeFunc(funcName) {
      return function() {
        var _this3 = this;
        var adm = this[$mobx];
        adm.atom_.reportObserved();
        var dehancedValues = adm.dehanceValues_(adm.values_);
        var callback = arguments[0];
        arguments[0] = function(accumulator, currentValue, index) {
          return callback(accumulator, currentValue, index, _this3);
        };
        return dehancedValues[funcName].apply(dehancedValues, arguments);
      };
    }
    var isObservableArrayAdministration = /* @__PURE__ */ createInstanceofPredicate("ObservableArrayAdministration", ObservableArrayAdministration);
    function isObservableArray(thing) {
      return isObject(thing) && isObservableArrayAdministration(thing[$mobx]);
    }
    var ObservableMapMarker = {};
    var ADD = "add";
    var DELETE = "delete";
    var ObservableMap = /* @__PURE__ */ (function() {
      function ObservableMap2(initialData, enhancer_, name_) {
        var _this = this;
        if (enhancer_ === void 0) {
          enhancer_ = deepEnhancer;
        }
        if (name_ === void 0) {
          name_ = "ObservableMap@" + getNextId();
        }
        this.enhancer_ = void 0;
        this.name_ = void 0;
        this[$mobx] = ObservableMapMarker;
        this.data_ = void 0;
        this.hasMap_ = void 0;
        this.keysAtom_ = void 0;
        this.interceptors_ = void 0;
        this.changeListeners_ = void 0;
        this.dehancer = void 0;
        this.enhancer_ = enhancer_;
        this.name_ = name_;
        if (!isFunction(Map)) {
          die(18);
        }
        initObservable(function() {
          _this.keysAtom_ = createAtom(true ? _this.name_ + ".keys()" : "ObservableMap.keys()");
          _this.data_ = /* @__PURE__ */ new Map();
          _this.hasMap_ = /* @__PURE__ */ new Map();
          if (initialData) {
            _this.merge(initialData);
          }
        });
      }
      var _proto = ObservableMap2.prototype;
      _proto.has_ = function has_(key) {
        return this.data_.has(key);
      };
      _proto.has = function has2(key) {
        var _this2 = this;
        if (!globalState.trackingDerivation) {
          return this.has_(key);
        }
        var entry = this.hasMap_.get(key);
        if (!entry) {
          var newEntry = entry = new ObservableValue(this.has_(key), referenceEnhancer, this.name_ + "." + stringifyKey(key) + "?", false);
          this.hasMap_.set(key, newEntry);
          onBecomeUnobserved(newEntry, function() {
            return _this2.hasMap_["delete"](key);
          });
        }
        return entry.get();
      };
      _proto.set = function set2(key, value) {
        var hasKey = this.has_(key);
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            type: hasKey ? UPDATE : ADD,
            object: this,
            newValue: value,
            name: key
          });
          if (!change) {
            return this;
          }
          value = change.newValue;
        }
        if (hasKey) {
          this.updateValue_(key, value);
        } else {
          this.addValue_(key, value);
        }
        return this;
      };
      _proto["delete"] = function _delete(key) {
        var _this3 = this;
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            type: DELETE,
            object: this,
            name: key
          });
          if (!change) {
            return false;
          }
        }
        if (this.has_(key)) {
          var notifySpy = isSpyEnabled();
          var notify = hasListeners(this);
          var _change = notify || notifySpy ? {
            observableKind: "map",
            debugObjectName: this.name_,
            type: DELETE,
            object: this,
            oldValue: this.data_.get(key).value_,
            name: key
          } : null;
          if (notifySpy) {
            spyReportStart(_change);
          }
          transaction(function() {
            var _this3$hasMap_$get;
            _this3.keysAtom_.reportChanged();
            (_this3$hasMap_$get = _this3.hasMap_.get(key)) == null || _this3$hasMap_$get.setNewValue_(false);
            var observable2 = _this3.data_.get(key);
            observable2.setNewValue_(void 0);
            _this3.data_["delete"](key);
          });
          if (notify) {
            notifyListeners(this, _change);
          }
          if (notifySpy) {
            spyReportEnd();
          }
          return true;
        }
        return false;
      };
      _proto.updateValue_ = function updateValue_(key, newValue) {
        var observable2 = this.data_.get(key);
        newValue = observable2.prepareNewValue_(newValue);
        if (newValue !== globalState.UNCHANGED) {
          var notifySpy = isSpyEnabled();
          var notify = hasListeners(this);
          var change = notify || notifySpy ? {
            observableKind: "map",
            debugObjectName: this.name_,
            type: UPDATE,
            object: this,
            oldValue: observable2.value_,
            name: key,
            newValue
          } : null;
          if (notifySpy) {
            spyReportStart(change);
          }
          observable2.setNewValue_(newValue);
          if (notify) {
            notifyListeners(this, change);
          }
          if (notifySpy) {
            spyReportEnd();
          }
        }
      };
      _proto.addValue_ = function addValue_(key, newValue) {
        var _this4 = this;
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        transaction(function() {
          var _this4$hasMap_$get;
          var observable2 = new ObservableValue(newValue, _this4.enhancer_, _this4.name_ + "." + stringifyKey(key), false);
          _this4.data_.set(key, observable2);
          newValue = observable2.value_;
          (_this4$hasMap_$get = _this4.hasMap_.get(key)) == null || _this4$hasMap_$get.setNewValue_(true);
          _this4.keysAtom_.reportChanged();
        });
        var notifySpy = isSpyEnabled();
        var notify = hasListeners(this);
        var change = notify || notifySpy ? {
          observableKind: "map",
          debugObjectName: this.name_,
          type: ADD,
          object: this,
          name: key,
          newValue
        } : null;
        if (notifySpy) {
          spyReportStart(change);
        }
        if (notify) {
          notifyListeners(this, change);
        }
        if (notifySpy) {
          spyReportEnd();
        }
      };
      _proto.get = function get2(key) {
        if (this.has(key)) {
          return this.dehanceValue_(this.data_.get(key).get());
        }
        return this.dehanceValue_(void 0);
      };
      _proto.getOrInsert = function getOrInsert(key, value) {
        if (!this.has(key)) {
          this.set(key, value);
        }
        return this.get(key);
      };
      _proto.getOrInsertComputed = function getOrInsertComputed(key, callback) {
        if (!this.has(key)) {
          this.set(key, callback(key));
        }
        return this.get(key);
      };
      _proto.dehanceValue_ = function dehanceValue_(value) {
        if (this.dehancer !== void 0) {
          return this.dehancer(value);
        }
        return value;
      };
      _proto.keys = function keys2() {
        this.keysAtom_.reportObserved();
        return this.data_.keys();
      };
      _proto.values = function values2() {
        var self2 = this;
        var keys2 = this.keys();
        return makeIterableForMap({
          next: function next() {
            var _keys$next = keys2.next(), done = _keys$next.done, value = _keys$next.value;
            return {
              done,
              value: done ? void 0 : self2.get(value)
            };
          }
        });
      };
      _proto.entries = function entries2() {
        var self2 = this;
        var keys2 = this.keys();
        return makeIterableForMap({
          next: function next() {
            var _keys$next2 = keys2.next(), done = _keys$next2.done, value = _keys$next2.value;
            return {
              done,
              value: done ? void 0 : [value, self2.get(value)]
            };
          }
        });
      };
      _proto[Symbol.iterator] = function() {
        return this.entries();
      };
      _proto.forEach = function forEach(callback, thisArg) {
        for (var _iterator = _createForOfIteratorHelperLoose(this), _step; !(_step = _iterator()).done; ) {
          var _step$value = _step.value, key = _step$value[0], value = _step$value[1];
          callback.call(thisArg, value, key, this);
        }
      };
      _proto.merge = function merge(other) {
        var _this5 = this;
        if (isObservableMap(other)) {
          other = new Map(other);
        }
        transaction(function() {
          if (isPlainObject(other)) {
            getPlainObjectKeys(other).forEach(function(key) {
              return _this5.set(key, other[key]);
            });
          } else if (Array.isArray(other)) {
            other.forEach(function(_ref) {
              var key = _ref[0], value = _ref[1];
              return _this5.set(key, value);
            });
          } else if (isES6Map(other)) {
            if (!isPlainES6Map(other)) {
              die(19, other);
            }
            other.forEach(function(value, key) {
              return _this5.set(key, value);
            });
          } else if (other !== null && other !== void 0) {
            die(20, other);
          }
        });
        return this;
      };
      _proto.clear = function clear() {
        var _this6 = this;
        transaction(function() {
          untracked(function() {
            for (var _iterator2 = _createForOfIteratorHelperLoose(_this6.keys()), _step2; !(_step2 = _iterator2()).done; ) {
              var key = _step2.value;
              _this6["delete"](key);
            }
          });
        });
      };
      _proto.replace = function replace(values2) {
        var _this7 = this;
        transaction(function() {
          var replacementMap = convertToMap(values2);
          var orderedData = /* @__PURE__ */ new Map();
          var keysReportChangedCalled = false;
          for (var _iterator3 = _createForOfIteratorHelperLoose(_this7.data_.keys()), _step3; !(_step3 = _iterator3()).done; ) {
            var key = _step3.value;
            if (!replacementMap.has(key)) {
              var deleted = _this7["delete"](key);
              if (deleted) {
                keysReportChangedCalled = true;
              } else {
                var value = _this7.data_.get(key);
                orderedData.set(key, value);
              }
            }
          }
          for (var _iterator4 = _createForOfIteratorHelperLoose(replacementMap.entries()), _step4; !(_step4 = _iterator4()).done; ) {
            var _step4$value = _step4.value, _key = _step4$value[0], _value = _step4$value[1];
            var keyExisted = _this7.data_.has(_key);
            _this7.set(_key, _value);
            if (_this7.data_.has(_key)) {
              var _value2 = _this7.data_.get(_key);
              orderedData.set(_key, _value2);
              if (!keyExisted) {
                keysReportChangedCalled = true;
              }
            }
          }
          if (!keysReportChangedCalled) {
            if (_this7.data_.size !== orderedData.size) {
              _this7.keysAtom_.reportChanged();
            } else {
              var iter1 = _this7.data_.keys();
              var iter2 = orderedData.keys();
              var next1 = iter1.next();
              var next2 = iter2.next();
              while (!next1.done) {
                if (next1.value !== next2.value) {
                  _this7.keysAtom_.reportChanged();
                  break;
                }
                next1 = iter1.next();
                next2 = iter2.next();
              }
            }
          }
          _this7.data_ = orderedData;
        });
        return this;
      };
      _proto.toString = function toString2() {
        return "[object ObservableMap]";
      };
      _proto.toJSON = function toJSON() {
        return Array.from(this);
      };
      _proto.observe_ = function observe_(listener, fireImmediately) {
        if (fireImmediately === true) {
          die("`observe` doesn't support fireImmediately=true in combination with maps.");
        }
        return registerListener(this, listener);
      };
      _proto.intercept_ = function intercept_(handler) {
        return registerInterceptor(this, handler);
      };
      return _createClass(ObservableMap2, [{
        key: "size",
        get: function get2() {
          this.keysAtom_.reportObserved();
          return this.data_.size;
        }
      }, {
        key: Symbol.toStringTag,
        get: function get2() {
          return "Map";
        }
      }]);
    })();
    var isObservableMap = /* @__PURE__ */ createInstanceofPredicate("ObservableMap", ObservableMap);
    function makeIterableForMap(iterator) {
      iterator[Symbol.toStringTag] = "MapIterator";
      return makeIterable(iterator);
    }
    function convertToMap(dataStructure) {
      if (isES6Map(dataStructure) || isObservableMap(dataStructure)) {
        return dataStructure;
      } else if (Array.isArray(dataStructure)) {
        return new Map(dataStructure);
      } else if (isPlainObject(dataStructure)) {
        var map = /* @__PURE__ */ new Map();
        for (var key in dataStructure) {
          map.set(key, dataStructure[key]);
        }
        return map;
      } else {
        return die(21, dataStructure);
      }
    }
    var ObservableSetMarker = {};
    var ObservableSet = /* @__PURE__ */ (function() {
      function ObservableSet2(initialData, enhancer, name_) {
        var _this = this;
        if (enhancer === void 0) {
          enhancer = deepEnhancer;
        }
        if (name_ === void 0) {
          name_ = "ObservableSet@" + getNextId();
        }
        this.name_ = void 0;
        this[$mobx] = ObservableSetMarker;
        this.data_ = /* @__PURE__ */ new Set();
        this.atom_ = void 0;
        this.changeListeners_ = void 0;
        this.interceptors_ = void 0;
        this.dehancer = void 0;
        this.enhancer_ = void 0;
        this.name_ = name_;
        if (!isFunction(Set)) {
          die(22);
        }
        this.enhancer_ = function(newV, oldV) {
          return enhancer(newV, oldV, name_);
        };
        initObservable(function() {
          _this.atom_ = createAtom(_this.name_);
          if (initialData) {
            _this.replace(initialData);
          }
        });
      }
      var _proto = ObservableSet2.prototype;
      _proto.dehanceValue_ = function dehanceValue_(value) {
        if (this.dehancer !== void 0) {
          return this.dehancer(value);
        }
        return value;
      };
      _proto.clear = function clear() {
        var _this2 = this;
        transaction(function() {
          untracked(function() {
            for (var _iterator = _createForOfIteratorHelperLoose(_this2.data_.values()), _step; !(_step = _iterator()).done; ) {
              var value = _step.value;
              _this2["delete"](value);
            }
          });
        });
      };
      _proto.forEach = function forEach(callbackFn, thisArg) {
        for (var _iterator2 = _createForOfIteratorHelperLoose(this), _step2; !(_step2 = _iterator2()).done; ) {
          var value = _step2.value;
          callbackFn.call(thisArg, value, value, this);
        }
      };
      _proto.add = function add(value) {
        var _this3 = this;
        checkIfStateModificationsAreAllowed(this.atom_);
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            type: ADD,
            object: this,
            newValue: value
          });
          if (!change) {
            return this;
          }
          value = change.newValue;
        }
        if (!this.has(value)) {
          transaction(function() {
            _this3.data_.add(_this3.enhancer_(value, void 0));
            _this3.atom_.reportChanged();
          });
          var notifySpy = isSpyEnabled();
          var notify = hasListeners(this);
          var _change = notify || notifySpy ? {
            observableKind: "set",
            debugObjectName: this.name_,
            type: ADD,
            object: this,
            newValue: value
          } : null;
          if (notifySpy && true) {
            spyReportStart(_change);
          }
          if (notify) {
            notifyListeners(this, _change);
          }
          if (notifySpy && true) {
            spyReportEnd();
          }
        }
        return this;
      };
      _proto["delete"] = function _delete(value) {
        var _this4 = this;
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            type: DELETE,
            object: this,
            oldValue: value
          });
          if (!change) {
            return false;
          }
        }
        if (this.has(value)) {
          var notifySpy = isSpyEnabled();
          var notify = hasListeners(this);
          var _change2 = notify || notifySpy ? {
            observableKind: "set",
            debugObjectName: this.name_,
            type: DELETE,
            object: this,
            oldValue: value
          } : null;
          if (notifySpy && true) {
            spyReportStart(_change2);
          }
          transaction(function() {
            _this4.atom_.reportChanged();
            _this4.data_["delete"](value);
          });
          if (notify) {
            notifyListeners(this, _change2);
          }
          if (notifySpy && true) {
            spyReportEnd();
          }
          return true;
        }
        return false;
      };
      _proto.has = function has2(value) {
        this.atom_.reportObserved();
        return this.data_.has(this.dehanceValue_(value));
      };
      _proto.entries = function entries2() {
        var values2 = this.values();
        return makeIterableForSet({
          next: function next() {
            var _values$next = values2.next(), value = _values$next.value, done = _values$next.done;
            return !done ? {
              value: [value, value],
              done
            } : {
              value: void 0,
              done
            };
          }
        });
      };
      _proto.keys = function keys2() {
        return this.values();
      };
      _proto.values = function values2() {
        this.atom_.reportObserved();
        var self2 = this;
        var values3 = this.data_.values();
        return makeIterableForSet({
          next: function next() {
            var _values$next2 = values3.next(), value = _values$next2.value, done = _values$next2.done;
            return !done ? {
              value: self2.dehanceValue_(value),
              done
            } : {
              value: void 0,
              done
            };
          }
        });
      };
      _proto.intersection = function intersection(otherSet) {
        if (isES6Set(otherSet) && !isObservableSet(otherSet)) {
          return otherSet.intersection(this);
        } else {
          var dehancedSet = new Set(this);
          return dehancedSet.intersection(otherSet);
        }
      };
      _proto.union = function union(otherSet) {
        if (isES6Set(otherSet) && !isObservableSet(otherSet)) {
          return otherSet.union(this);
        } else {
          var dehancedSet = new Set(this);
          return dehancedSet.union(otherSet);
        }
      };
      _proto.difference = function difference(otherSet) {
        return new Set(this).difference(otherSet);
      };
      _proto.symmetricDifference = function symmetricDifference(otherSet) {
        if (isES6Set(otherSet) && !isObservableSet(otherSet)) {
          return otherSet.symmetricDifference(this);
        } else {
          var dehancedSet = new Set(this);
          return dehancedSet.symmetricDifference(otherSet);
        }
      };
      _proto.isSubsetOf = function isSubsetOf(otherSet) {
        return new Set(this).isSubsetOf(otherSet);
      };
      _proto.isSupersetOf = function isSupersetOf(otherSet) {
        return new Set(this).isSupersetOf(otherSet);
      };
      _proto.isDisjointFrom = function isDisjointFrom(otherSet) {
        if (isES6Set(otherSet) && !isObservableSet(otherSet)) {
          return otherSet.isDisjointFrom(this);
        } else {
          var dehancedSet = new Set(this);
          return dehancedSet.isDisjointFrom(otherSet);
        }
      };
      _proto.replace = function replace(other) {
        var _this5 = this;
        if (isObservableSet(other)) {
          other = new Set(other);
        }
        transaction(function() {
          if (Array.isArray(other)) {
            _this5.clear();
            other.forEach(function(value) {
              return _this5.add(value);
            });
          } else if (isES6Set(other)) {
            _this5.clear();
            other.forEach(function(value) {
              return _this5.add(value);
            });
          } else if (other !== null && other !== void 0) {
            die("Cannot initialize set from " + other);
          }
        });
        return this;
      };
      _proto.observe_ = function observe_(listener, fireImmediately) {
        if (fireImmediately === true) {
          die("`observe` doesn't support fireImmediately=true in combination with sets.");
        }
        return registerListener(this, listener);
      };
      _proto.intercept_ = function intercept_(handler) {
        return registerInterceptor(this, handler);
      };
      _proto.toJSON = function toJSON() {
        return Array.from(this);
      };
      _proto.toString = function toString2() {
        return "[object ObservableSet]";
      };
      _proto[Symbol.iterator] = function() {
        return this.values();
      };
      return _createClass(ObservableSet2, [{
        key: "size",
        get: function get2() {
          this.atom_.reportObserved();
          return this.data_.size;
        }
      }, {
        key: Symbol.toStringTag,
        get: function get2() {
          return "Set";
        }
      }]);
    })();
    var isObservableSet = /* @__PURE__ */ createInstanceofPredicate("ObservableSet", ObservableSet);
    function makeIterableForSet(iterator) {
      iterator[Symbol.toStringTag] = "SetIterator";
      return makeIterable(iterator);
    }
    var descriptorCache = /* @__PURE__ */ Object.create(null);
    var REMOVE = "remove";
    var ObservableObjectAdministration = /* @__PURE__ */ (function() {
      function ObservableObjectAdministration2(target_, values_, name_, defaultAnnotation_) {
        if (values_ === void 0) {
          values_ = /* @__PURE__ */ new Map();
        }
        if (defaultAnnotation_ === void 0) {
          defaultAnnotation_ = autoAnnotation;
        }
        this.target_ = void 0;
        this.values_ = void 0;
        this.name_ = void 0;
        this.defaultAnnotation_ = void 0;
        this.keysAtom_ = void 0;
        this.changeListeners_ = void 0;
        this.interceptors_ = void 0;
        this.proxy_ = void 0;
        this.isPlainObject_ = void 0;
        this.appliedAnnotations_ = void 0;
        this.pendingKeys_ = void 0;
        this.lazyComputedKeys_ = void 0;
        this.lazyObservableKeys_ = void 0;
        this.target_ = target_;
        this.values_ = values_;
        this.name_ = name_;
        this.defaultAnnotation_ = defaultAnnotation_;
        this.keysAtom_ = new Atom(this.name_ + ".keys");
        this.isPlainObject_ = isPlainObject(this.target_);
        if (!isAnnotation(this.defaultAnnotation_)) {
          die("defaultAnnotation must be valid annotation");
        }
        {
          this.appliedAnnotations_ = {};
        }
      }
      var _proto = ObservableObjectAdministration2.prototype;
      _proto.getObservablePropValue_ = function getObservablePropValue_(key) {
        var _ref, _this$values_$get;
        var observable2 = (_ref = (_this$values_$get = this.values_.get(key)) != null ? _this$values_$get : this.materializeLazyComputed_(key)) != null ? _ref : this.materializeLazyObservable_(key);
        return observable2.get();
      };
      _proto.materializeLazyComputed_ = function materializeLazyComputed_(key) {
        var _this$lazyComputedKey;
        var factory = (_this$lazyComputedKey = this.lazyComputedKeys_) == null ? void 0 : _this$lazyComputedKey.get(key);
        if (!factory) {
          return void 0;
        }
        this.lazyComputedKeys_["delete"](key);
        if (this.lazyComputedKeys_.size === 0) {
          this.lazyComputedKeys_ = void 0;
        }
        var computed2 = factory();
        this.values_.set(key, computed2);
        return computed2;
      };
      _proto.materializeLazyObservable_ = function materializeLazyObservable_(key) {
        var _this$lazyObservableK;
        var factory = (_this$lazyObservableK = this.lazyObservableKeys_) == null ? void 0 : _this$lazyObservableK.get(key);
        if (!factory) {
          return void 0;
        }
        this.lazyObservableKeys_["delete"](key);
        if (this.lazyObservableKeys_.size === 0) {
          this.lazyObservableKeys_ = void 0;
        }
        var observable2 = factory();
        this.values_.set(key, observable2);
        return observable2;
      };
      _proto.setObservablePropValue_ = function setObservablePropValue_(key, newValue) {
        var _ref2, _this$values_$get2;
        var observable2 = (_ref2 = (_this$values_$get2 = this.values_.get(key)) != null ? _this$values_$get2 : this.materializeLazyComputed_(key)) != null ? _ref2 : this.materializeLazyObservable_(key);
        if (observable2 instanceof ComputedValue) {
          observable2.set(newValue);
          return true;
        }
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            type: UPDATE,
            object: this.proxy_ || this.target_,
            name: key,
            newValue
          });
          if (!change) {
            return null;
          }
          newValue = change.newValue;
        }
        newValue = observable2.prepareNewValue_(newValue);
        if (newValue !== globalState.UNCHANGED) {
          var notify = hasListeners(this);
          var notifySpy = isSpyEnabled();
          var _change = notify || notifySpy ? {
            type: UPDATE,
            observableKind: "object",
            debugObjectName: this.name_,
            object: this.proxy_ || this.target_,
            oldValue: observable2.value_,
            name: key,
            newValue
          } : null;
          if (notifySpy) {
            spyReportStart(_change);
          }
          observable2.setNewValue_(newValue);
          if (notify) {
            notifyListeners(this, _change);
          }
          if (notifySpy) {
            spyReportEnd();
          }
        }
        return true;
      };
      _proto.get_ = function get_(key) {
        if (globalState.trackingDerivation && !hasProp(this.target_, key)) {
          this.has_(key);
        }
        return this.target_[key];
      };
      _proto.set_ = function set_(key, value, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        if (hasProp(this.target_, key)) {
          if (this.values_.has(key)) {
            return this.setObservablePropValue_(key, value);
          } else if (proxyTrap) {
            return Reflect.set(this.target_, key, value);
          } else {
            this.target_[key] = value;
            return true;
          }
        } else {
          return this.extend_(key, {
            value,
            enumerable: true,
            writable: true,
            configurable: true
          }, this.defaultAnnotation_, proxyTrap);
        }
      };
      _proto.has_ = function has_(key) {
        if (!globalState.trackingDerivation) {
          return key in this.target_;
        }
        this.pendingKeys_ || (this.pendingKeys_ = /* @__PURE__ */ new Map());
        var entry = this.pendingKeys_.get(key);
        if (!entry) {
          entry = new ObservableValue(key in this.target_, referenceEnhancer, this.name_ + "." + stringifyKey(key) + "?", false);
          this.pendingKeys_.set(key, entry);
        }
        return entry.get();
      };
      _proto.make_ = function make_2(key, annotation) {
        if (annotation === true) {
          annotation = this.defaultAnnotation_;
        }
        if (annotation === false) {
          return;
        }
        assertAnnotable(this, annotation, key);
        if (!(key in this.target_)) {
          var _this$target_$storedA;
          if ((_this$target_$storedA = this.target_[storedAnnotationsSymbol]) != null && _this$target_$storedA[key]) {
            return;
          } else {
            die(1, annotation.annotationType_, this.name_ + "." + key.toString());
          }
        }
        var source = this.target_;
        while (source && source !== objectPrototype) {
          var descriptor = getDescriptor(source, key);
          if (descriptor) {
            var outcome = annotation.make_(this, key, descriptor, source);
            if (outcome === 0) {
              return;
            }
            if (outcome === 1) {
              break;
            }
          }
          source = Object.getPrototypeOf(source);
        }
        recordAnnotationApplied(this, annotation, key);
      };
      _proto.extend_ = function extend_2(key, descriptor, annotation, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        if (annotation === true) {
          annotation = this.defaultAnnotation_;
        }
        if (annotation === false) {
          return this.defineProperty_(key, descriptor, proxyTrap);
        }
        assertAnnotable(this, annotation, key);
        var outcome = annotation.extend_(this, key, descriptor, proxyTrap);
        if (outcome) {
          recordAnnotationApplied(this, annotation, key);
        }
        return outcome;
      };
      _proto.defineProperty_ = function defineProperty_(key, descriptor, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        try {
          startBatch();
          var deleteOutcome = this.delete_(key);
          if (!deleteOutcome) {
            return deleteOutcome;
          }
          if (hasInterceptors(this)) {
            var change = interceptChange(this, {
              object: this.proxy_ || this.target_,
              name: key,
              type: ADD,
              newValue: descriptor.value
            });
            if (!change) {
              return null;
            }
            var newValue = change.newValue;
            if (descriptor.value !== newValue) {
              descriptor = _extends({}, descriptor, {
                value: newValue
              });
            }
          }
          if (proxyTrap) {
            if (!Reflect.defineProperty(this.target_, key, descriptor)) {
              return false;
            }
          } else {
            defineProperty(this.target_, key, descriptor);
          }
          this.notifyPropertyAddition_(key, descriptor.value);
        } finally {
          endBatch();
        }
        return true;
      };
      _proto.defineObservableProperty_ = function defineObservableProperty_(key, value, enhancer, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        try {
          startBatch();
          var deleteOutcome = this.delete_(key);
          if (!deleteOutcome) {
            return deleteOutcome;
          }
          if (hasInterceptors(this)) {
            var change = interceptChange(this, {
              object: this.proxy_ || this.target_,
              name: key,
              type: ADD,
              newValue: value
            });
            if (!change) {
              return null;
            }
            value = change.newValue;
          }
          var cachedDescriptor = getCachedObservablePropDescriptor(key);
          var descriptor = {
            configurable: globalState.safeDescriptors ? this.isPlainObject_ : true,
            enumerable: true,
            get: cachedDescriptor.get,
            set: cachedDescriptor.set
          };
          if (proxyTrap) {
            if (!Reflect.defineProperty(this.target_, key, descriptor)) {
              return false;
            }
          } else {
            defineProperty(this.target_, key, descriptor);
          }
          var observable2 = new ObservableValue(value, enhancer, true ? this.name_ + "." + key.toString() : "ObservableObject.key", false);
          this.values_.set(key, observable2);
          this.notifyPropertyAddition_(key, observable2.value_);
        } finally {
          endBatch();
        }
        return true;
      };
      _proto.defineComputedProperty_ = function defineComputedProperty_(key, options, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        try {
          startBatch();
          var deleteOutcome = this.delete_(key);
          if (!deleteOutcome) {
            return deleteOutcome;
          }
          if (hasInterceptors(this)) {
            var change = interceptChange(this, {
              object: this.proxy_ || this.target_,
              name: key,
              type: ADD,
              newValue: void 0
            });
            if (!change) {
              return null;
            }
          }
          options.name || (options.name = true ? this.name_ + "." + key.toString() : "ObservableObject.key");
          options.context = this.proxy_ || this.target_;
          var cachedDescriptor = getCachedObservablePropDescriptor(key);
          var descriptor = {
            configurable: globalState.safeDescriptors ? this.isPlainObject_ : true,
            enumerable: false,
            get: cachedDescriptor.get,
            set: cachedDescriptor.set
          };
          if (proxyTrap) {
            if (!Reflect.defineProperty(this.target_, key, descriptor)) {
              return false;
            }
          } else {
            defineProperty(this.target_, key, descriptor);
          }
          this.values_.set(key, new ComputedValue(options));
          this.notifyPropertyAddition_(key, void 0);
        } finally {
          endBatch();
        }
        return true;
      };
      _proto.delete_ = function delete_(key, proxyTrap) {
        if (proxyTrap === void 0) {
          proxyTrap = false;
        }
        checkIfStateModificationsAreAllowed(this.keysAtom_);
        if (!hasProp(this.target_, key)) {
          return true;
        }
        if (hasInterceptors(this)) {
          var change = interceptChange(this, {
            object: this.proxy_ || this.target_,
            name: key,
            type: REMOVE
          });
          if (!change) {
            return null;
          }
        }
        try {
          var _this$pendingKeys_;
          startBatch();
          var notify = hasListeners(this);
          var notifySpy = isSpyEnabled();
          var observable2 = this.values_.get(key);
          var value = void 0;
          if (!observable2 && (notify || notifySpy)) {
            var _getDescriptor2;
            value = (_getDescriptor2 = getDescriptor(this.target_, key)) == null ? void 0 : _getDescriptor2.value;
          }
          if (proxyTrap) {
            if (!Reflect.deleteProperty(this.target_, key)) {
              return false;
            }
          } else {
            delete this.target_[key];
          }
          if (true) {
            delete this.appliedAnnotations_[key];
          }
          if (observable2) {
            this.values_["delete"](key);
            if (observable2 instanceof ObservableValue) {
              value = observable2.value_;
            }
            propagateChanged(observable2);
          }
          this.keysAtom_.reportChanged();
          (_this$pendingKeys_ = this.pendingKeys_) == null || (_this$pendingKeys_ = _this$pendingKeys_.get(key)) == null || _this$pendingKeys_.set(key in this.target_);
          if (notify || notifySpy) {
            var _change2 = {
              type: REMOVE,
              observableKind: "object",
              object: this.proxy_ || this.target_,
              debugObjectName: this.name_,
              oldValue: value,
              name: key
            };
            if (notifySpy) {
              spyReportStart(_change2);
            }
            if (notify) {
              notifyListeners(this, _change2);
            }
            if (notifySpy) {
              spyReportEnd();
            }
          }
        } finally {
          endBatch();
        }
        return true;
      };
      _proto.observe_ = function observe_(callback, fireImmediately) {
        if (fireImmediately === true) {
          die("`observe` doesn't support the fire immediately property for observable objects.");
        }
        return registerListener(this, callback);
      };
      _proto.intercept_ = function intercept_(handler) {
        return registerInterceptor(this, handler);
      };
      _proto.notifyPropertyAddition_ = function notifyPropertyAddition_(key, value) {
        var _this$pendingKeys_2;
        var notify = hasListeners(this);
        var notifySpy = isSpyEnabled();
        if (notify || notifySpy) {
          var change = notify || notifySpy ? {
            type: ADD,
            observableKind: "object",
            debugObjectName: this.name_,
            object: this.proxy_ || this.target_,
            name: key,
            newValue: value
          } : null;
          if (notifySpy) {
            spyReportStart(change);
          }
          if (notify) {
            notifyListeners(this, change);
          }
          if (notifySpy) {
            spyReportEnd();
          }
        }
        (_this$pendingKeys_2 = this.pendingKeys_) == null || (_this$pendingKeys_2 = _this$pendingKeys_2.get(key)) == null || _this$pendingKeys_2.set(true);
        this.keysAtom_.reportChanged();
      };
      _proto.ownKeys_ = function ownKeys_() {
        this.keysAtom_.reportObserved();
        return ownKeys(this.target_);
      };
      _proto.keys_ = function keys_() {
        this.keysAtom_.reportObserved();
        return Object.keys(this.target_);
      };
      return ObservableObjectAdministration2;
    })();
    function asObservableObject(target, options) {
      var _options$name;
      if (options && isObservableObject(target)) {
        die("Options can't be provided for already observable objects.");
      }
      if (hasProp(target, $mobx)) {
        if (!(getAdministration(target) instanceof ObservableObjectAdministration)) {
          die("Cannot convert '" + getDebugName(target) + "' into observable object:\nThe target is already observable of different type.\nExtending builtins is not supported.");
        }
        return target;
      }
      if (!Object.isExtensible(target)) {
        die("Cannot make the designated object observable; it is not extensible");
      }
      var name = (_options$name = options == null ? void 0 : options.name) != null ? _options$name : (isPlainObject(target) ? "ObservableObject" : target.constructor.name) + "@" + getNextId();
      var adm = new ObservableObjectAdministration(target, /* @__PURE__ */ new Map(), String(name), getAnnotationFromOptions(options));
      addHiddenProp(target, $mobx, adm);
      return target;
    }
    var isObservableObjectAdministration = /* @__PURE__ */ createInstanceofPredicate("ObservableObjectAdministration", ObservableObjectAdministration);
    function getCachedObservablePropDescriptor(key) {
      return descriptorCache[key] || (descriptorCache[key] = {
        get: function get2() {
          return this[$mobx].getObservablePropValue_(key);
        },
        set: function set2(value) {
          return this[$mobx].setObservablePropValue_(key, value);
        }
      });
    }
    function isObservableObject(thing) {
      if (isObject(thing)) {
        return isObservableObjectAdministration(thing[$mobx]);
      }
      return false;
    }
    function recordAnnotationApplied(adm, annotation, key) {
      var _adm$target_$storedAn;
      {
        adm.appliedAnnotations_[key] = annotation;
      }
      (_adm$target_$storedAn = adm.target_[storedAnnotationsSymbol]) == null || delete _adm$target_$storedAn[key];
    }
    function assertAnnotable(adm, annotation, key) {
      if (!isAnnotation(annotation)) {
        die("Cannot annotate '" + adm.name_ + "." + key.toString() + "': Invalid annotation.");
      }
      if (!isOverride(annotation) && hasProp(adm.appliedAnnotations_, key)) {
        var fieldName = adm.name_ + "." + key.toString();
        var currentAnnotationType = adm.appliedAnnotations_[key].annotationType_;
        var requestedAnnotationType = annotation.annotationType_;
        die("Cannot apply '" + requestedAnnotationType + "' to '" + fieldName + "':" + ("\nThe field is already annotated with '" + currentAnnotationType + "'.") + "\nRe-annotating fields is not allowed.\nUse 'override' annotation for methods overridden by subclass.");
      }
    }
    var ENTRY_0 = /* @__PURE__ */ createArrayEntryDescriptor(0);
    var safariPrototypeSetterInheritanceBug = /* @__PURE__ */ (function() {
      var v = false;
      var p = {};
      Object.defineProperty(p, "0", {
        set: function set2() {
          v = true;
        }
      });
      Object.create(p)["0"] = 1;
      return v === false;
    })();
    var OBSERVABLE_ARRAY_BUFFER_SIZE = 0;
    var StubArray = function StubArray2() {
    };
    function inherit(ctor, proto) {
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(ctor.prototype, proto);
      } else if (ctor.prototype.__proto__ !== void 0) {
        ctor.prototype.__proto__ = proto;
      } else {
        ctor.prototype = proto;
      }
    }
    inherit(StubArray, Array.prototype);
    var LegacyObservableArray = /* @__PURE__ */ (function(_StubArray) {
      function LegacyObservableArray2(initialValues, enhancer, name, owned) {
        var _this;
        if (name === void 0) {
          name = "ObservableArray@" + getNextId();
        }
        if (owned === void 0) {
          owned = false;
        }
        _this = _StubArray.call(this) || this;
        initObservable(function() {
          var adm = new ObservableArrayAdministration(name, enhancer, owned, true);
          adm.proxy_ = _this;
          addHiddenFinalProp(_this, $mobx, adm);
          if (initialValues && initialValues.length) {
            _this.spliceWithArray(0, 0, initialValues);
          }
          if (safariPrototypeSetterInheritanceBug) {
            Object.defineProperty(_this, "0", ENTRY_0);
          }
        });
        return _this;
      }
      _inheritsLoose(LegacyObservableArray2, _StubArray);
      var _proto = LegacyObservableArray2.prototype;
      _proto.concat = function concat() {
        this[$mobx].atom_.reportObserved();
        for (var _len = arguments.length, arrays = new Array(_len), _key = 0; _key < _len; _key++) {
          arrays[_key] = arguments[_key];
        }
        return Array.prototype.concat.apply(
          this.slice(),
          //@ts-ignore
          arrays.map(function(a) {
            return isObservableArray(a) ? a.slice() : a;
          })
        );
      };
      _proto[Symbol.iterator] = function() {
        var self2 = this;
        var nextIndex = 0;
        return makeIterable({
          next: function next() {
            return nextIndex < self2.length ? {
              value: self2[nextIndex++],
              done: false
            } : {
              done: true,
              value: void 0
            };
          }
        });
      };
      return _createClass(LegacyObservableArray2, [{
        key: "length",
        get: function get2() {
          return this[$mobx].getArrayLength_();
        },
        set: function set2(newLength) {
          this[$mobx].setArrayLength_(newLength);
        }
      }, {
        key: Symbol.toStringTag,
        get: function get2() {
          return "Array";
        }
      }]);
    })(StubArray);
    Object.entries(arrayExtensions).forEach(function(_ref) {
      var prop = _ref[0], fn = _ref[1];
      if (prop !== "concat") {
        addHiddenProp(LegacyObservableArray.prototype, prop, fn);
      }
    });
    function createArrayEntryDescriptor(index) {
      return {
        enumerable: false,
        configurable: true,
        get: function get2() {
          return this[$mobx].get_(index);
        },
        set: function set2(value) {
          this[$mobx].set_(index, value);
        }
      };
    }
    function createArrayBufferItem(index) {
      defineProperty(LegacyObservableArray.prototype, "" + index, createArrayEntryDescriptor(index));
    }
    function reserveArrayBuffer(max) {
      if (max > OBSERVABLE_ARRAY_BUFFER_SIZE) {
        for (var index = OBSERVABLE_ARRAY_BUFFER_SIZE; index < max + 100; index++) {
          createArrayBufferItem(index);
        }
        OBSERVABLE_ARRAY_BUFFER_SIZE = max;
      }
    }
    reserveArrayBuffer(1e3);
    function createLegacyArray(initialValues, enhancer, name) {
      return new LegacyObservableArray(initialValues, enhancer, name);
    }
    function getAtom(thing, property) {
      if (typeof thing === "object" && thing !== null) {
        if (isObservableArray(thing)) {
          if (property !== void 0) {
            die(23);
          }
          return thing[$mobx].atom_;
        }
        if (isObservableSet(thing)) {
          return thing.atom_;
        }
        if (isObservableMap(thing)) {
          if (property === void 0) {
            return thing.keysAtom_;
          }
          var observable2 = thing.data_.get(property) || thing.hasMap_.get(property);
          if (!observable2) {
            die(25, property, getDebugName(thing));
          }
          return observable2;
        }
        if (isObservableObject(thing)) {
          var _ref, _adm$values_$get;
          if (!property) {
            return die(26);
          }
          var adm = thing[$mobx];
          var _observable = (_ref = (_adm$values_$get = adm.values_.get(property)) != null ? _adm$values_$get : adm.materializeLazyComputed_(property)) != null ? _ref : adm.materializeLazyObservable_(property);
          if (!_observable) {
            die(27, property, getDebugName(thing));
          }
          return _observable;
        }
        if (isAtom(thing) || isComputedValue(thing) || isReaction(thing)) {
          return thing;
        }
      } else if (isFunction(thing)) {
        if (isReaction(thing[$mobx])) {
          return thing[$mobx];
        }
      }
      die(28);
    }
    function getAdministration(thing, property) {
      if (!thing) {
        die(29);
      }
      if (property !== void 0) {
        return getAdministration(getAtom(thing, property));
      }
      if (isAtom(thing) || isComputedValue(thing) || isReaction(thing)) {
        return thing;
      }
      if (isObservableMap(thing) || isObservableSet(thing)) {
        return thing;
      }
      if (thing[$mobx]) {
        return thing[$mobx];
      }
      die(24, thing);
    }
    function getDebugName(thing, property) {
      var named;
      if (property !== void 0) {
        named = getAtom(thing, property);
      } else if (isAction(thing)) {
        return thing.name;
      } else if (isObservableObject(thing) || isObservableMap(thing) || isObservableSet(thing)) {
        named = getAdministration(thing);
      } else {
        named = getAtom(thing);
      }
      return named.name_;
    }
    function initObservable(cb) {
      var derivation = untrackedStart();
      var allowStateChanges2 = allowStateChangesStart(true);
      startBatch();
      try {
        return cb();
      } finally {
        endBatch();
        allowStateChangesEnd(allowStateChanges2);
        untrackedEnd(derivation);
      }
    }
    var toString = objectPrototype.toString;
    function deepEqual(a, b, depth) {
      if (depth === void 0) {
        depth = -1;
      }
      return eq(a, b, depth);
    }
    function eq(a, b, depth, aStack, bStack) {
      if (a === b) {
        return a !== 0 || 1 / a === 1 / b;
      }
      if (a == null || b == null) {
        return false;
      }
      if (a !== a) {
        return b !== b;
      }
      var type = typeof a;
      if (type !== "function" && type !== "object" && typeof b != "object") {
        return false;
      }
      var className = toString.call(a);
      if (className !== toString.call(b)) {
        return false;
      }
      switch (className) {
        // Strings, numbers, regular expressions, dates, and booleans are compared by value.
        case "[object RegExp]":
        // RegExps are coerced to strings for comparison (Note: '' + /a/i === '/a/i')
        case "[object String]":
          return "" + a === "" + b;
        case "[object Number]":
          if (+a !== +a) {
            return +b !== +b;
          }
          return +a === 0 ? 1 / +a === 1 / b : +a === +b;
        case "[object Date]":
        case "[object Boolean]":
          return +a === +b;
        case "[object Symbol]":
          return typeof Symbol !== "undefined" && Symbol.valueOf.call(a) === Symbol.valueOf.call(b);
        case "[object Map]":
        case "[object Set]":
          if (depth >= 0) {
            depth++;
          }
          break;
      }
      a = unwrap(a);
      b = unwrap(b);
      var areArrays = className === "[object Array]";
      if (!areArrays) {
        if (typeof a != "object" || typeof b != "object") {
          return false;
        }
        var aCtor = a.constructor, bCtor = b.constructor;
        if (aCtor !== bCtor && !(isFunction(aCtor) && aCtor instanceof aCtor && isFunction(bCtor) && bCtor instanceof bCtor) && "constructor" in a && "constructor" in b) {
          return false;
        }
      }
      if (depth === 0) {
        return false;
      } else if (depth < 0) {
        depth = -1;
      }
      aStack = aStack || [];
      bStack = bStack || [];
      var length = aStack.length;
      while (length--) {
        if (aStack[length] === a) {
          return bStack[length] === b;
        }
      }
      aStack.push(a);
      bStack.push(b);
      if (areArrays) {
        length = a.length;
        if (length !== b.length) {
          return false;
        }
        while (length--) {
          if (!eq(a[length], b[length], depth - 1, aStack, bStack)) {
            return false;
          }
        }
      } else {
        var keys2 = Object.keys(a);
        var _length = keys2.length;
        if (Object.keys(b).length !== _length) {
          return false;
        }
        for (var i = 0; i < _length; i++) {
          var key = keys2[i];
          if (!(hasProp(b, key) && eq(a[key], b[key], depth - 1, aStack, bStack))) {
            return false;
          }
        }
      }
      aStack.pop();
      bStack.pop();
      return true;
    }
    function unwrap(a) {
      if (isObservableArray(a)) {
        return a.slice();
      }
      if (isES6Map(a) || isObservableMap(a)) {
        return Array.from(a.entries());
      }
      if (isES6Set(a) || isObservableSet(a)) {
        return Array.from(a.entries());
      }
      return a;
    }
    var _global$Iterator;
    var global$1 = /* @__PURE__ */ getGlobal();
    var maybeIteratorPrototype = ((_global$Iterator = global$1.Iterator) == null ? void 0 : _global$Iterator.prototype) || {};
    function makeIterable(iterator) {
      iterator[Symbol.iterator] = getSelf;
      return Object.assign(Object.create(maybeIteratorPrototype), iterator);
    }
    function getSelf() {
      return this;
    }
    function isAnnotation(thing) {
      return (
        // Can be function
        thing instanceof Object && typeof thing.annotationType_ === "string" && isFunction(thing.make_) && isFunction(thing.extend_)
      );
    }
    ["Symbol", "Map", "Set"].forEach(function(m) {
      var g = getGlobal();
      if (typeof g[m] === "undefined") {
        die("MobX requires global '" + m + "' to be available or polyfilled");
      }
    });
    if (typeof __MOBX_DEVTOOLS_GLOBAL_HOOK__ === "object") {
      __MOBX_DEVTOOLS_GLOBAL_HOOK__.injectMobx({
        spy,
        extras: {
          getDebugName
        },
        $mobx
      });
    }
    exports2.$mobx = $mobx;
    exports2.FlowCancellationError = FlowCancellationError;
    exports2.ObservableMap = ObservableMap;
    exports2.ObservableSet = ObservableSet;
    exports2.Reaction = Reaction;
    exports2._allowStateChanges = allowStateChanges;
    exports2._allowStateChangesInsideComputed = runInAction3;
    exports2._allowStateReadsEnd = allowStateReadsEnd;
    exports2._allowStateReadsStart = allowStateReadsStart;
    exports2._autoAction = autoAction;
    exports2._endAction = _endAction;
    exports2._getAdministration = getAdministration;
    exports2._getGlobalState = getGlobalState;
    exports2._interceptReads = interceptReads;
    exports2._isComputingDerivation = isComputingDerivation;
    exports2._resetGlobalState = resetGlobalState;
    exports2._startAction = _startAction;
    exports2.action = action;
    exports2.autorun = autorun;
    exports2.comparer = comparer;
    exports2.computed = computed;
    exports2.configure = configure;
    exports2.createAtom = createAtom;
    exports2.defineProperty = apiDefineProperty;
    exports2.entries = entries;
    exports2.extendObservable = extendObservable;
    exports2.flow = flow;
    exports2.flowResult = flowResult;
    exports2.get = get;
    exports2.getAtom = getAtom;
    exports2.getDebugName = getDebugName;
    exports2.getDependencyTree = getDependencyTree;
    exports2.getObserverTree = getObserverTree;
    exports2.has = has;
    exports2.intercept = intercept;
    exports2.isAction = isAction;
    exports2.isBoxedObservable = isObservableValue;
    exports2.isComputed = isComputed;
    exports2.isComputedProp = isComputedProp;
    exports2.isFlow = isFlow;
    exports2.isFlowCancellationError = isFlowCancellationError;
    exports2.isObservable = isObservable;
    exports2.isObservableArray = isObservableArray;
    exports2.isObservableMap = isObservableMap;
    exports2.isObservableObject = isObservableObject;
    exports2.isObservableProp = isObservableProp;
    exports2.isObservableSet = isObservableSet;
    exports2.keys = keys;
    exports2.makeAutoObservable = makeAutoObservable2;
    exports2.makeObservable = makeObservable;
    exports2.observable = observable;
    exports2.observe = observe;
    exports2.onBecomeObserved = onBecomeObserved;
    exports2.onBecomeUnobserved = onBecomeUnobserved;
    exports2.onReactionError = onReactionError;
    exports2.override = override;
    exports2.ownKeys = apiOwnKeys;
    exports2.reaction = reaction;
    exports2.remove = remove;
    exports2.runInAction = runInAction3;
    exports2.set = set;
    exports2.spy = spy;
    exports2.toJS = toJS;
    exports2.trace = trace;
    exports2.transaction = transaction;
    exports2.untracked = untracked;
    exports2.values = values;
    exports2.when = when2;
  }
});

// ../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/index.js
var require_dist = __commonJS({
  "../../hx/hxWork/SmartDD/node_modules/.pnpm/mobx@6.16.1/node_modules/mobx/dist/index.js"(exports2, module2) {
    "use strict";
    if (process.env.NODE_ENV === "production") {
      module2.exports = require_mobx_cjs_production_min();
    } else {
      module2.exports = require_mobx_cjs_development();
    }
  }
});

// fixture:files
var files_exports = {};
__export(files_exports, {
  prepareFileWorkspaceClose: () => prepareFileWorkspaceClose
});
var prepareFileWorkspaceClose;
var init_files = __esm({
  "fixture:files"() {
    prepareFileWorkspaceClose = (...args) => globalThis.__m14UiHarness.prepare(...args);
  }
});

// <stdin>
var stdin_exports = {};
__export(stdin_exports, {
  runInAction: () => import_mobx2.runInAction,
  shouldAutoResume: () => shouldAutoResume,
  tasksStore: () => tasksStore,
  when: () => import_mobx2.when
});
module.exports = __toCommonJS(stdin_exports);

// src/renderer/core/tasks-store.ts
var import_mobx = __toESM(require_dist());

// src/shared/ipc/events.ts
function defineEvent(name) {
  return { name };
}

// src/shared/events.ts
var ptyDataEvent = defineEvent("pty:data");
var ptyExitEvent = defineEvent("pty:exit");
var tasksChangedEvent = defineEvent("tasks:changed");
var browserChangedEvent = defineEvent("browser:changed");
var browserAccessChangedEvent = defineEvent("browser:access-changed");
var browserShortcutEvent = defineEvent("browser:shortcut");
var applicationCleanupProgressEvent = defineEvent("applications:cleanup-progress");
var applicationsChangedEvent = defineEvent("applications:changed");
var fileWatchEvent = defineEvent("files:watch");
var fileSearchEvent = defineEvent("files:search");
var fileCloseEvent = defineEvent("files:close-request");
var fileHtmlEvent = defineEvent("files:html-state");
var fileWorkspaceEvent = defineEvent("files:workspace");
var aiProfilesChangedEvent = defineEvent("aiProfiles:changed");
var menuOpenSettingsEvent = defineEvent("menu:openSettings");
var menuToggleLeftSidebarEvent = defineEvent("menu:toggleLeftSidebar");
var ptyInputEvent = defineEvent("pty:input");
var ptyResizeEvent = defineEvent("pty:resize");
var voiceStatusChangedEvent = defineEvent("voice:changed");
var voiceGlobalErrorEvent = defineEvent("voice:global-error");
var fileViewerUiEvent = defineEvent("files:viewer-ui");

// src/shared/ipc/rpc.ts
function rpcErrorMessage(error) {
  const raw = error instanceof Error ? error.message : String(error);
  return raw.replace(/^Error invoking remote method '[^']*': (?:\w*Error: )?/, "");
}

// fixture:ipc
var rpc = globalThis.__m14UiHarness.rpc;
var events = globalThis.__m14UiHarness.events;

// src/renderer/core/auto-resume.ts
function shouldAutoResume(task, attempted) {
  if (attempted.has(task.id)) return false;
  if (task.ptyId !== null) return false;
  if (task.archivedAt !== null) return false;
  if (task.aiProfileId === null) return false;
  if (task.nativeSessionId && !task.runtimeSnapshot) return false;
  return task.recovery === "resumable" || task.recovery === "fresh";
}

// fixture:navigation
var navigation = globalThis.__m14UiHarness.navigation;

// src/renderer/core/task-tabs.ts
function withTab(tabs, taskId, current) {
  if (tabs.includes(taskId)) return [...tabs];
  const at = current ? tabs.indexOf(current) : -1;
  if (at === -1) return [...tabs, taskId];
  return [...tabs.slice(0, at + 1), taskId, ...tabs.slice(at + 1)];
}
function nextTabAfterClose(tabs, closing, current) {
  const rest = tabs.filter((id) => id !== closing);
  if (current !== closing && current !== null && rest.includes(current)) return current;
  if (rest.length === 0) return null;
  const at = tabs.indexOf(closing);
  return rest[Math.min(Math.max(at, 0), rest.length - 1)];
}

// fixture:size
var terminalSize = () => ({ cols: 80, rows: 24 });

// src/renderer/core/tasks-store.ts
var TasksStore = class {
  tasks = [];
  loaded = false;
  /** Open task tabs, in strip order. */
  tabs = [];
  /** taskId → ptyId of every terminal this window has shown, including exited ones. */
  terminals = /* @__PURE__ */ new Map();
  /** Tabs whose auto-resume is in flight. */
  resuming = /* @__PURE__ */ new Set();
  /** Why the last auto-resume of a tab failed. */
  resumeErrors = /* @__PURE__ */ new Map();
  /** A close is a transaction: its view remains available until every step succeeds. */
  closing = /* @__PURE__ */ new Set();
  resumeEpochs = /* @__PURE__ */ new Map();
  opening = /* @__PURE__ */ new Map();
  /** Tabs already auto-resumed (or that must not be, until reopened): see shouldAutoResume. */
  autoResumed = /* @__PURE__ */ new Set();
  constructor() {
    (0, import_mobx.makeAutoObservable)(this);
    events.on(tasksChangedEvent, () => void this.refresh());
  }
  get byId() {
    return new Map(this.tasks.map((t) => [t.id, t]));
  }
  get current() {
    return navigation.currentTaskId ? this.byId.get(navigation.currentTaskId) ?? null : null;
  }
  get openTabs() {
    return this.tabs.map((id) => this.byId.get(id)).filter((t) => t !== void 0);
  }
  async refresh() {
    const list = await rpc.tasks.list({ includeArchived: true });
    (0, import_mobx.runInAction)(() => {
      this.tasks = list;
      this.loaded = true;
      for (const id of [...this.terminals.keys()]) if (!list.some((t) => t.id === id)) this.terminals.delete(id);
      this.tabs = this.tabs.filter((id) => list.some((t) => t.id === id));
    });
  }
  cancelCreate(token) {
    return rpc.tasks.cancelCreate(token);
  }
  /** Throws so the caller shows the error where the user acted. */
  async create(req) {
    const res = await rpc.tasks.create({ ...terminalSize(), ...req });
    (0, import_mobx.runInAction)(() => {
      this.terminals.set(res.task.id, res.ptyId);
      this.autoResumed.add(res.task.id);
      this.tabs = withTab(this.tabs, res.task.id, navigation.currentViewId === "task" ? navigation.currentTaskId : null);
    });
    await this.refresh();
    navigation.openTask(res.task.id);
    return res.task;
  }
  /**
   * Open a task in its tab (a new one if needed) and, when it is stopped, resume it on the
   * profile it ran on. Unknown native capability history stays read-only until explicit resume,
   * and the stopped panel also stays when there is a real profile choice to make.
   */
  show(taskId) {
    if (this.closing.has(taskId)) return;
    this.tabs = withTab(this.tabs, taskId, navigation.currentViewId === "task" ? navigation.currentTaskId : null);
    navigation.openTask(taskId);
    const task = this.byId.get(taskId);
    if (task && !this.terminals.has(taskId)) void this.autoResume(task);
  }
  /** Resume a stopped task on its original profile, once per opened tab. False: not tried. */
  async autoResume(task) {
    if (this.closing.has(task.id)) return false;
    if (!task.agentSnapshot && ["claude", "codex"].includes(task.runner)) return false;
    if (!shouldAutoResume(task, this.autoResumed)) return false;
    const epoch = this.resumeEpochs.get(task.id) ?? 0;
    this.autoResumed.add(task.id);
    this.resuming.add(task.id);
    this.resumeErrors.delete(task.id);
    try {
      if (task.agentSnapshot) {
        const preview = await rpc.tasks.agentResumePreview(task.id);
        if ((this.resumeEpochs.get(task.id) ?? 0) !== epoch || this.closing.has(task.id) || !this.tabs.includes(task.id)) return false;
        if (preview?.sourceChanged || preview?.model.changed) return false;
      }
      await this.resume({ taskId: task.id });
    } catch (e) {
      if ((this.resumeEpochs.get(task.id) ?? 0) === epoch) (0, import_mobx.runInAction)(() => this.resumeErrors.set(task.id, rpcErrorMessage(e)));
    } finally {
      if ((this.resumeEpochs.get(task.id) ?? 0) === epoch) (0, import_mobx.runInAction)(() => this.resuming.delete(task.id));
    }
    return true;
  }
  async resume(req) {
    if (this.closing.has(req.taskId)) throw new Error("\u4F1A\u8BDD\u6B63\u5728\u5173\u95ED\uFF0C\u8BF7\u7A0D\u540E\u518D\u6253\u5F00");
    if (this.opening.has(req.taskId)) throw new Error("\u4F1A\u8BDD\u6B63\u5728\u6062\u590D\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
    const epoch = this.resumeEpochs.get(req.taskId) ?? 0;
    const hadTab = this.tabs.includes(req.taskId);
    const opening = rpc.tasks.open({ ...terminalSize(), ...req });
    this.opening.set(req.taskId, opening);
    let res;
    try {
      res = await opening;
    } finally {
      if (this.opening.get(req.taskId) === opening) this.opening.delete(req.taskId);
    }
    if ((this.resumeEpochs.get(req.taskId) ?? 0) !== epoch || this.closing.has(req.taskId)) return;
    if (hadTab && !this.tabs.includes(req.taskId)) {
      await rpc.tasks.kill(req.taskId);
      await this.refresh();
      return;
    }
    (0, import_mobx.runInAction)(() => {
      this.terminals.set(req.taskId, res.ptyId);
      this.autoResumed.add(req.taskId);
      this.resumeErrors.delete(req.taskId);
    });
    await this.refresh();
  }
  /** Archive only after main confirms success; preserve other sessions and terminal scrollback. */
  async setArchived(taskId, archived, stopRunning = false) {
    if (this.closing.has(taskId)) throw new Error("\u4F1A\u8BDD\u6B63\u5728\u5173\u95ED\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
    const result = archived && stopRunning ? await rpc.tasks.stopAndArchive(taskId) : await rpc.tasks.setArchived(taskId, archived);
    (0, import_mobx.runInAction)(() => {
      this.tasks = this.tasks.map((task) => task.id === taskId ? result : task);
      this.autoResumed.add(taskId);
      this.resumeErrors.delete(taskId);
      if (archived) {
        const wasVisible = navigation.currentTaskId === taskId && navigation.currentViewId === "task";
        navigation.closeTask(taskId);
        if (wasVisible && result.projectId) navigation.newTask(result.projectId);
      }
    });
    await this.refresh();
  }
  /** Hide an exited terminal so the stopped panel (profile choice, recovery info) shows. */
  dropTerminal(taskId) {
    this.terminals.delete(taskId);
    this.autoResumed.add(taskId);
  }
  /** Closing a tab ends its session; opening the task again resumes it. */
  async closeTab(taskId, action = "save") {
    if (this.closing.has(taskId)) throw new Error("\u4F1A\u8BDD\u6B63\u5728\u5173\u95ED\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
    this.closing.add(taskId);
    this.resumeEpochs.set(taskId, (this.resumeEpochs.get(taskId) ?? 0) + 1);
    let preparation;
    let opened;
    let closed = false;
    try {
      opened = await this.opening.get(taskId)?.catch(() => void 0);
      const { prepareFileWorkspaceClose: prepareFileWorkspaceClose2 } = await Promise.resolve().then(() => (init_files(), files_exports));
      preparation = await prepareFileWorkspaceClose2({ kind: "task", taskId }, action);
      preparation.assertCurrent();
      const result = await rpc.tasks.closeSession(taskId);
      preparation.assertCurrent();
      await preparation.commit();
      (0, import_mobx.runInAction)(() => {
        const next = nextTabAfterClose(this.tabs, taskId, navigation.currentTaskId);
        this.tasks = this.tasks.map((task) => task.id === taskId ? result : task);
        this.tabs = this.tabs.filter((id) => id !== taskId);
        this.terminals.delete(taskId);
        this.autoResumed.delete(taskId);
        this.resumeErrors.delete(taskId);
        if (navigation.currentTaskId === taskId) {
          if (next && navigation.currentViewId === "task") navigation.openTask(next);
          else navigation.closeTask(taskId);
        }
      });
      closed = true;
    } finally {
      preparation?.cancel();
      (0, import_mobx.runInAction)(() => {
        if (!closed && opened && this.tabs.includes(taskId)) this.terminals.set(taskId, opened.ptyId);
        this.resuming.delete(taskId);
        this.closing.delete(taskId);
      });
    }
  }
  async remove(taskId) {
    if (this.closing.has(taskId)) throw new Error("\u4F1A\u8BDD\u6B63\u5728\u5173\u95ED\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
    await rpc.tasks.delete(taskId);
    (0, import_mobx.runInAction)(() => {
      this.terminals.delete(taskId);
      this.tabs = this.tabs.filter((id) => id !== taskId);
    });
    navigation.closeTask(taskId);
    await this.refresh();
  }
};
var tasksStore = new TasksStore();

// <stdin>
var import_mobx2 = __toESM(require_dist());
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  runInAction,
  shouldAutoResume,
  tasksStore,
  when
});
