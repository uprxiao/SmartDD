from pathlib import Path
import json,hashlib
r=Path('/private/tmp/willyou-m14-f09-entry-map');repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
entries=[
('layout-navigation',['src/renderer/lib/layout/workspace.tsx','src/renderer/views/task-view.tsx','src/renderer/views/task-chrome.tsx','src/renderer/core/tasks-store.ts','src/renderer/core/auto-resume.ts']),
('task-open-close',['src/renderer/lib/layout/sidebar-tasks.tsx','src/renderer/lib/layout/left-sidebar.tsx','src/renderer/views/project-view.tsx','src/renderer/views/task-close.tsx','src/renderer/views/task-archive.tsx','src/renderer/views/resume-advice.tsx']),
('file-root-tree',['src/renderer/features/files/workspace-tree.tsx','src/renderer/features/files/file-actions.tsx','src/main/core/files/sources.ts','src/main/core/files/roots.ts']),
('file-edit-save',['src/renderer/features/files/text-editor.tsx','src/renderer/features/files/file-buffer.ts','src/renderer/features/files/workspace-store.ts','src/main/core/files/file-service.ts']),
('file-reference',['src/renderer/features/files/terminal-context/store.ts','src/renderer/features/files/terminal-context/context.tsx','src/renderer/features/files/terminal-context/selection.tsx','src/main/core/files/terminal-context.ts','src/shared/file-terminal.ts']),
('office-pdf-reference',['src/renderer/features/files/pdf/comments.tsx','src/renderer/features/files/office/docx-context.tsx','src/renderer/features/files/office/pptx-context.tsx','src/renderer/features/files/office/pptx-generation.tsx','src/renderer/features/files/office-handoff.ts']),
('image-and-viewer',['src/renderer/features/files/workspace-panel.tsx','src/renderer/features/files/markdown/image-host.tsx','src/main/core/files/terminal-image-cache.ts']),
('browser',['src/renderer/features/browser/workspace.tsx','src/renderer/features/browser/store.ts','src/renderer/features/browser/access-store.ts','src/main/core/browser/service.ts']),
('application-insert',['src/renderer/features/applications/terminal-insertion.tsx','src/main/core/applications/terminal-insertion.ts','src/main/core/applications/terminal-sources.ts','src/shared/application-terminal.ts']),
('plugin-actions',['src/renderer/features/applications/plugin-actions.tsx','src/main/core/applications/plugins/ui-actions.ts','src/main/core/applications/application-service.ts','src/shared/plugin-actions.ts']),
('approval-and-capabilities',['src/renderer/features/applications/plugin-approval.tsx','src/renderer/features/applications/session-applications.tsx','src/renderer/features/skills/workspace.tsx','src/main/core/capabilities/capability-service.ts']),
('project-db-ssh',['src/renderer/views/projects/resource-dialogs.tsx','src/main/core/projects/controller.ts','src/main/core/projects/project-service.ts','src/main/core/connections/db-tester.ts','src/main/core/connections/ssh-tester.ts','resources/standard-skills/project-db-diagnostics/SKILL.md','resources/standard-skills/remote-password-ssh/SKILL.md']),
('voice-home',['src/renderer/views/home-view.tsx','src/renderer/core/navigation.ts','src/renderer/core/voice-store.ts','src/shared/voice.ts','src/main/core/voice/controller.ts','src/main/core/voice/voice-service.ts']),
('project-transfer',['src/renderer/views/projects/project-transfer.tsx','src/renderer/core/project-transfer.ts','src/main/core/projects/transfer-service.ts','src/main/core/projects/transfer-format.ts']),
('agent-transfer',['src/renderer/features/agents/transfer-dialogs.tsx','src/main/core/ai/agent-transfer.ts','src/main/core/ai/agent-transfer-controller.ts'])]
rows=[]
for name,paths in entries:
 for path in paths:
  p=repo/path;assert p.is_file(),str(p)
 rows.append({'entry':name,'sources':paths})
sources=[{'repository':'SmartDD','path':p,'sha256':sha(repo/p)} for p in sorted(set(p for _,ps in entries for p in ps))]
for p in ['apps/web/src/lib/composerContextReferences.ts','packages/client-runtime/src/state/composerDispatch.ts']:
 sources.append({'repository':'t3code','path':p,'sha256':sha(t3/p)})
reuse=[]
def audit(label,rows,base):
 out=[]
 for x in rows:
  if not x.get('sha256'):continue
  p=Path(x.get('path') or x.get('name'));p=p if p.is_absolute() else base/p
  out.append({'path':str(p),'expected':x['sha256'],'actual':sha(p) if p.exists() else None})
 changed=[x for x in out if x['expected']!=x['actual']];reuse.append({'evidence':label,'checked':len(out),'changed':changed})
audit('U01-U07 original store build',json.loads(Path('/private/tmp/willyou-m14-ui-boundary/build-inputs.json').read_text()),repo)
d=json.loads(Path('/private/tmp/willyou-m14-ui-entry-probe/build.json').read_text());audit('UIE01-UIE09 existing task/voice build',[x for part in d for x in part['sources']],repo)
d=json.loads(Path('/private/tmp/willyou-m14-transfer-boundary-probe/source-review.json').read_text());audit('T01-T04 encrypted transfer build',d['build']['sources'],repo)
(r/'source-audit.json').write_text(json.dumps({'entries':rows,'sources':sources,'reusedEvidence':reuse,'scope':'Current source review and byte comparison; not a new runtime test of unchanged evidence.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'entries':len(rows),'sources':len(sources),'reuse':[{'name':x['evidence'],'checked':x['checked'],'changed':len(x['changed'])} for x in reuse]}))
