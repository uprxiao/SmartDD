### 10.1.1 F09：既有业务到新任务的具体落点

[F09 入口核对](实验/20261114_F09既有业务入口与新目标映射/README.md)固定十五组入口、七十个 SmartDD／T3 来源文件。源文件清单用于定位，本节规定迁移职责。程序化目标不借用 PTY；文件／浏览器／配置等独立业务继续使用原服务，不因换 Provider 重建身份或清除状态。

| 业务入口 → 原服务 | 程序化路径与身份 | 关闭／失败处理与验收 |
| --- | --- | --- |
| Workspace、任务头、侧栏／项目任务列表 → TasksStore／TaskService | 根据 executionKind 分派旧终端或新任务投影；任务页读取逻辑 task，运行操作携带精确 binding／run／generation。新任务没有 PTY 也可显示、编辑草稿 | show／搜索／归档打开／父子跳转统一分派；旧认证来源缺失保持停止，来源／模型变化仍显示恢复预检，不绕过。A13／43／52 |
| 文件树右键、文件路径 → FileRootsService／FileSourceResolver／FileTerminalService | 根 lease／generation、task／project／cwd 和原文件身份保持；抽出 source prepare／inspect，分别接旧 PTY sink 和新引用 token。Provider 改变不改变已打开来源 | worktree／cwd 改变时旧 ref 保留原根，不默指新路径；不在新运行允许读取范围内的引用标不可用，重新选择。A38／39 |
| 文本编辑／保存／关闭 → FileBuffer／FileService／workspace-store | 缓冲、撤销、ifMatch、版本日志、保存 receipt 仍由文件服务负责，绝不改为“发送给 Agent 保存” | 等待当前保存；冲突／unknown 保留编辑与原文档。关闭任务先 prepareFileWorkspaceClose，再宿主关闭成功后提交 UI；失败保留视图。A38 |
| 文本选区／批注 → selection.tsx／FileTerminalContextStore | 保留 buffer instance／version、行范围、selectedTextHash、inputSettled／IME 校验；新草稿保存来源 token 与显示文本。两者不能互相冒充 | 异步采集后复核原选区与输入目标，变化不插入；草稿冲突保留本地内容。A38／43 |
| PDF／DOCX／PPTX 批注、PPTX 生成指令 → 原 viewer 上下文与共享 formatter | 保留 PDF page／归一化 anchor，DOCX 页码／所选文本，PPTX slideId／page／elementId；原文档版本与指令分开。共享 formatter 的正文可复用，不调用 terminalBodyData | 保留原截断／控制字符处理提示及源位置；不能把显示文本反解析成文件授权。普通 Office viewer、编辑和打开拦截条件保持，不自动迁入浏览器页面。A38 |
| PNG／Markdown 嵌入图 → 原图片授权及导入服务 | 新输入用 F07 对象 pin／表示／预算；图源仍需原 owner、ref、baseHash。旧 TerminalImageCache 仅供旧 PTY | 不按新 run 退出释放被历史引用的图片；模型视觉不支持时保留附件并提示，用户选择其他表示后才发送。A18／38／45 |
| 浏览器工具栏、标签、下载、登录／站点授权 → BrowserService | 页面仍属 logical task／profile；侧栏和文件区继续使用现有组件。用户 UI 操作保留 UI 来源；Agent 操作另以当前 run 签发业务上下文 | 换 Provider 不删 page／profile／Cookie；撤销结束 run 的申请方权限，不能撤销仍有效子 run 对父 task 的授权。暂停／关闭按原服务排空。A37 |
| 应用 Skill 示例、邮件／草稿／禅道引用 → terminal-sources／原模块 UI 读接口 | 从源模块提取 UI source proof 和目标运行兼容检查两部分。新草稿先验证项目、对象修订、包／连接来源，保存引用；启动／发送再对实际选中能力和实时政策核验。没有 run 也可准备草稿 | 不伪造 runs.inputContext；源内容、身份或政策变更要求重选，复制的旧文字不成为审批／执行权。旧终端路径保留原 run 校验。A41／43 |
| 插件列表／详情动作 → PluginUiActions／plugin-actions.tsx | 保留宿主 read receipt、row／tab、声明 action、package／connection scope；现有 insertTerminal 声明兼容映射为“插入输入”，新宿主可选同项目未归档的父或子任务草稿 | 不按活 PTY 过滤新目标，不自动选父任务。openUrl 仍走原 URL 白名单／一次消费；关闭释放临时 proof，已插入草稿的内容和来源记录独立保留。A41／43／52 |
| 插件／邮件审批、会话应用与 Skill／MCP 配置 → 原审批服务／CapabilityService | UI 面板由 task／run 投影驱动，不要求 ptyId。业务请求与原生请求分路由；MCP 按 viewer／宿主委派／宿主业务／用户原生四类保留生命周期 | 应用／插件热变更仍走原当前政策；需要重启的 Skill／MCP 显示变更影响并按新 Driver 能力重启，不调用旧 resume。旧审批不移交新 run。A08／09／39／41／52 |
| 项目 DB／SSH 配置、测试 → ProjectService／connections tester | create/update/testDraft/test/delete 仍是项目级 UI 操作，无需新建任务。密码仍进 SecretsStore，空密码沿原字段语义解析；不放进输入草稿／模型配置 | 不改厂商、只读、sudo、host-key 或原错误分类；测试失败保留编辑，不从导入／配置成功推断连接成功。A42 |
| Agent 使用项目 DB／SSH → CapabilityService／内置 Skill 脚本 | 每个独立 run 根据本项目与当次选用生成 PROJECT_DB_CONFIG／REMOTE_SERVERS_CONFIG 及原 secret env 引用，纳入 F04 不可变启动计划和子进程环境；parent 不把自身环境整体复制给 child | 配置变更走既有重启／预检，新 run 单独签发；脚本的只读事务、目标歧义和危险命令规则保留。不能把模型 URL／Key 当业务凭据。A42 |
| 首页创建／应用“准备新任务” → navigation／home-view／公共任务命令 | 应用准备只建立本项目首页 preset／初稿，不启动 Agent；用户发送才使用 clientCreationId 的创建＋初次输入持久意图。已有任务的引用只走 draft.save | 不复用一次旧 create 回调再额外 send；取消、重复和迟到 ACK 按 §10.2。A43 |
| 语音按钮／全局快捷键 → VoiceStore／VoiceService／Typeless adapter | 保留 home／terminal／settings／global。新 task-composer 增加宿主登记的窗口／目标票据，语音先进入该窗口的暂存输入区，用户确认后按同一引用／草稿 CAS 插入；不要求 Agent 运行 | 详见下段。发出快捷键不是转写完成，不能凭此清空草稿或发送。A42／43／52 |
| 项目／Agent 导入导出 → 原 transfer controller／service | 按 §9.9 保留密码加密、明确携 Key、新本地 ID 与目录选择；导入结果回到配置页，重新解析受管／外部运行资源 | 默认无 Key、不复制登录／运行批准、不覆盖同名身份；原任务 binding 不按名称重新绑定。缺全局 CLI 与受管就绪分开显示。A42 |

**新输入适配的共同合同。** 新宿主 InputInsertionService 为业务来源提供 `prepare(target, sourceDescriptor)` 与 release；target 是主窗口登记的逻辑 task、draftRevision、selectionRevision 和视图 epoch，不能从模型 JSON 或任意插件窗口取得。sourceDescriptor 只传既有受限 source ID／ref／版本／action ID，宿主通过原文件或业务服务取得并校验实际内容。prepare 返回可预览正文、来源摘要及任务／窗口限定的 reference token；没有创建 run、批准业务动作或执行输入。父子任务选择显式绑定各自 task，不能由当前视图变动重新定位。

插入复用 P1.2 `draft.save`：commandId 为本次幂等操作，expectedDraftRevision 与新 blocks 一起提交；reference block 已有 token／revision／contentHash 外形不变。宿主在共同草稿事务核验临时 token 的窗口／task／selectionRevision、源政策／版本和 prepared 内容后，将其转换为持久的任务引用记录、更新草稿／事件／收据；失败回滚，先查原请求摘要的幂等收据再做新的 CAS。纯正文保存不假装携带来源授权；不新增第二条自动 submit 路径。原生接收、历史覆盖和运行许可仍走 F01／F03／F07／F08。

**存储落点。** 沿用 C1.5 的 m14_context_object：业务引用描述存为有 hash 的 JSON 对象，包含 schema、宿主签发 referenceToken、taskId、referenceRevision、sourceKind、原对象／修订／位置、representation、显示正文及来源审计；不存 UI actor、live receipt 或凭据。m14_draft.blocks_json 持有既有 reference block，contentHash 定位该描述对象；宿主同时核对描述内 token／task／revision，不能只凭可猜 hash 读取。提交后 m14_submission.blocks_json 保存同一引用，传输计划继续使用 F07 的 object_ref。对象文件先完成受管暂存／核 hash，再在草稿事务登记 ready 对象和引用，失败只可能留下待清理暂存文件，不能留下引用已提交而对象缺失的成功回执。准备中读租约、草稿／submission 的 JSON 引用及描述依赖的内容对象都是 F10 最终保留查询的显式根；不只读取现有 transfer 外键。此处不新增公共协议或替换既有文件版本库，F10 负责共同保留关系及最终回收验证。

临时 UI read receipt／FileRef lease 不直接作为长期授权持久化。已确认插入时保存不可变的来源类型、对象／修订、包／连接身份、显示内容 hash 和必要内容 pin；后续编辑／重开读取这个任务引用。发送时从所属模块按原身份重新解析有效权限、源版本及当前目标能力，不能重新查询“现在相似的对象”。源变化／无法重取时保留原草稿并标 stale／unavailable，用户可重新选择或明确转换为普通文本；转换不授予工具权限。插件 action 关闭后文本仍可留在草稿，但旧 action receipt 不复活；模型后续调用仍核对当前插件政策。

文件路径、选区、批注位置使用结构化来源字段作为身份，正文只作表达。实际旧 formatter 允许相对文件名含换行；因此新 UI 显示应转义文件名并保留原 token，不能从多行 prompt 解析文件路径。旧 4000 字符选区／200 行／8000 字符引用格式限制及截断提示继续用于这一引用生成入口；F07 的整体输入预算另行累加。新正文不添加 bracketed-paste 转义，不把换行压成空格，也不把“引用已插入”显示为“模型已读取文件”。

**语音的可观察边界。** 现有 adapter 只返回 shortcut-sent，不返回文字或录音结束事件。首期 task-composer 因此保留固定语音暂存区，只有用户确认文本后才插入捕获的任务；不能创建一个假 ASR callback 自动回填当前路由。暂存期间不会把焦点自动转给另一任务输入框；切任务／选择、失焦、关闭来源使原插入票据失效，保留文字供显式重新选目标。App 内其他任务编辑入口在这段语音模式中不接收回填，结束／取消由用户显式退出；全局系统听写仍沿原 OS 焦点语义，应用不承诺控制其他程序的键盘输入。实际临时输入区、焦点／IME 和退出后的输入由 A42／52 验证；这不要求研究期启动 Typeless 或申请系统权限。

**当前源码相对旧证据的修正。** TasksStore 已增加 agentSnapshot 和 agentResumePreview：缺认证来源、来源变化或模型回退都阻止自动启动。当前九项重验使用明确的合成认证存在标记和 preview 替身，证明合法旧路径仍走 open、缺失／变化仍保持停止，以及打开中关闭遇保存失败保留视图；不证明真实认证。新 executionKind 必须在上述旧自动恢复前分派，而不是给新任务填假 snapshot／ptyId。T3 的 composerContextReferences 和 composerDispatch 也将输入内容编辑与实际提交分离，可参考其分层；WillYou 的文件租约、业务 receipt 和 Electron 窗口身份继续使用自身服务。

