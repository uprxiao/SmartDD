from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_复制中断与版本回退验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==3 and not r['error'];p=Path(r['out']);b=json.loads((root/'build.json').read_text())
for x in b['sources']:assert sha(Path(x['path']).read_bytes())==x['sha256']
assert sha(Path(b['output']['file']).read_bytes())==b['output']['sha256']
workers=json.loads((p/'workers.json').read_text());assert len(workers)==5 and sum(x['exit']['signal']=='SIGKILL'for x in workers)==1 and sum(x['exit']['code']==0 for x in workers)==4
assert r['checks'][1]['evidence']['partialRemains']and r['checks'][1]['evidence']['oldStageNotTrackedByJob']
refs=[repo/'src/main/core/applications/resource-store.ts',Path('/Users/hx/projects/t3code/apps/server/src/provider/CodexInstallation.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'build':b,'candidateObservationOnly':'job.mjs differs from prior candidate only by an onChunk checkpoint; original job stored as baseline-job.mjs. ResourceStore rebuilt from current source after eight stale source hashes were detected; old bundle not executed.','scope':'Two synthetic 8 MiB artifact releases, actual worker SIGKILL and ResourceStore. Not actual SDK release upgrade, run lease/GC or public download. T3 source referenced only, not executed.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[(root/n,n)for n in ['probe.mjs','job.mjs','baseline-job.mjs','job.sql','worker.mjs','artifact.mjs','build.mjs','build.json','actual.cjs','preflight-stale-inputs.json','prepare.py','source-review.json']]+[(x,str(x.relative_to(root)))for x in sorted(p.iterdir())if x.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x,n in files:tar.add(x,arcname=n,recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':n,'sha256':sha(x.read_bytes())}for x,n in files]}
for n,v in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 复制中断与版本回退验证

日期：2026-11-14。关联 R11／Q56。独立技术研究，不是产品升级验收。

## 实际执行

复用先前持久安装／激活候选，只增加 onChunk 观察停点。实际 ResourceStore 由当前源码重新构建；旧 bundle 的八个源文件摘要已过期，预检拒绝后未执行它。旧基线差异及本次构建闭包均保存。

在独立资源库安装合成 A，再复制合成 B 的 8 MiB payload。第二个块进入 transform 时暂停，实测私有 stage 已有部分字节且未满；仅对捕获的安装 worker PID 发 SIGKILL，并核对内核出生身份已停止。所有操作都是私有临时资源，不涉及用户安装或真实原生程序升级。

| 检查 | 观察结果 |
| --- | --- |
| C01 复制中途退出 | B 的安装记录仍 requested、prepared_path=null；没有 ready／发布资源，默认仍是 A，A 内容不变 |
| C02 新 worker 恢复 B | 重新复制并完整校验 B 后激活；原半成品目录仍在，而且不被新 prepared_path 关联 |
| C03 显式回退 A、随后重放 B 安装请求 | A 原目录 inode／内容保持；B 返回历史成功回执，但不重新激活，默认仍是 A |

三项观察检查通过；其中 C02 **确认了未解决缺口**，不表示安装恢复完整通过。五个 worker 有终态：一个预定 SIGKILL、四个 exit 0。没有调用模型、启动 Agent 或运行真实租约／GC。

## 设计影响与未解决项

候选流程只有 prepare 完成才写 prepared_path；因此复制过程中退出的目录没有持久归属。恢复成功不会自动清理它。不能靠 requested 状态推断从未创建文件，也不能按目录名／时间扫描删除所有相似目录。

正式方案须在首个数据字节写入前固定安装 attempt／owner 与专用准备目录的归属；目录分配前后的中断也必须可对账。copying 与完整 prepared 分开，半成品不得得到 ready 身份。已确认旧 owner 退出后，重试选择重新准备或经过验证的续传；原 attempt 的临时材料有独立保留／清理记录，不能用新路径覆盖掉旧路径证据。现有完整 prepared 的损坏应继续拒绝，不能混作普通未完成复制。

本轮仅验证旧版本保留、完整重复制和显式回退语义，并暴露缺口；尚未实现上述目录登记／清理候选，也未验证断点续传。真实原生版本、在用会话、网络／磁盘故障、下载中断、跨平台以及原生 GC 仍按其他证据或待验条件分别管理。

## 复现

原始归档内 `node probe.mjs`，需 Node、已记录 SQLite／zod 依赖及 owner-probe 的 Mac 进程身份工具；build.mjs 可从当前 SmartDD 构建本次实际模块，构建后须重新核对源码摘要。依赖含本机绝对路径，不是独立发行包。

[结果](result.json) · [源码与输入](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 anchor='默认指针与安装成功回执必须在同一事务提交；';assert anchor in t
 add='''[复制中断实验](实验/20261114_复制中断与版本回退验证/README.md)补了真实安装 worker 在局部文件已写入、prepare 尚未返回时 SIGKILL 的窗口：旧默认 A 及其目录保持，B 没有发布；新 worker 完整重复制 B 后可激活，显式回退 A 复用原物理目录。但旧半成品 stage 未被 requested／prepared_path=null 的安装记录关联，恢复成功后仍遗留。该缺口尚未修复，不能称安装恢复完整通过。

正式安装记录须区分安装请求、执行 attempt 和资源发布 operation；先固定 attempt／owner、预定准备目录及归属依据，再写入首个资源字节。目录分配与归属确认的中断也纳入对账，不能只在完整 prepare 后落路径。copying 不等于 prepared；重试可重新准备，但须保留原 attempt 的临时材料与清理状态，不用新 prepared_path 覆盖旧现场依据。清理前核对原 owner 已停止、目录／父目录身份与归属、限定文件集合及是否被发布／租用；不按年龄或相似目录名删除未知材料。完整 prepared 校验失败继续保留诊断，不因引入 copying 而自动当作可丢弃半成品。

本批没有实现上述准备目录登记／清理，也没有验证断点续传。资源版本切换只针对后续默认选择；显式回退不重写旧资源，安装成功回执重放不重新激活历史版本，UI 须分别查询当前默认与该操作的历史结果。此证据是合成资源版本，真实 Agent 会话／版本与占用仍按各自联合验证，不自动相加为完整升级通过。

'''
 t=t.replace(anchor,add+anchor)
 t=t.replace('当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、','当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载中途退出、复制中断后的完整归属／清理、')
 return t
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.85 'not in t
 add='''### 4.85 复制中途退出、默认保留与回退

[复制中断实验](实验/20261114_复制中断与版本回退验证/README.md)用当前 ResourceStore 和先前安装候选取得三项观察：真实 worker SIGKILL 后旧默认 A 保持、B 半成品不发布；恢复完整重复制 B 后激活；显式回退 A 保留原目录，重放 B 安装收据不重新激活。五个 worker 均有终态，一次预定 SIGKILL，四次 exit 0。

同时确认实际缺口：复制中途安装仍 requested／prepared_path=null，原半成品未关联，恢复完成仍遗留。本轮没有修复目录登记／清理，也未验真实原生会话升级或租约 GC；技术方案 §12.1 补 attempt、copying、归属与恢复清理合同。旧 bundle 的八个源码摘要过期，预检拒绝并重新构建当前源码；没有把旧产物冒充当前实现。

Q56 已有 §4.50–4.54 及本轮的局部证据，状态从待验改为部分，完整关闭仍为零。Q52 原行误追加的安装实验说明移出该 UI 行；这些证据属于 Q51／53／54／56，不证明 UI、IME 或滚动性能。

'''
 t=t.replace(anchor,add+anchor)
 old='| Q56 | 更新不替换在用程序，资源缺失／损坏／回退不损坏原会话 | E11；新增 R11 | T3 Codex 安装器有租约与受管版本选择参考；WillYou 的升级并发／失败注入仍待验，不自动继承 T3 结论 |'
 new='| Q56 | 更新不替换在用程序，资源缺失／损坏／回退不损坏原会话 | E11；新增 R11 | **部分**：§4.50–4.54 补固定资源发布／回退、安装阶段退出、实际 run 成员保留及启动晚变更；§4.85 补复制中断后旧默认保留、完整重复制和回退收据，发现未登记半成品遗留。准备目录归属／清理、原生 GC、真实会话升级与跨平台仍待验；不自动继承 T3 结论 |';assert old in t;t=t.replace(old,new)
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('| Q52 |'):lines[i]='| Q52 | 流式 UI、IME、快捷键、焦点、滚动、窄窗与性能达标 | E10；T30／33 | 待集成；新 UI 未形成，须走共享原型与真实 App，不能用日志或安装资源实验代替视觉／操作证据 |'
 t='\n'.join(lines)+'\n'
 old='截至 §4.84，56 个宽口径问题项中，48 项有部分实验／限定证据，5 项主要内容仍待验证或产品集成，2 项模板产品已按用户确认延后，1 项可选 SVN 自动管理不开放；整项完整关闭为 0。五项为 Q26、Q42、Q51、Q52。'
 # The preceding baseline still includes Q56; require exact baseline to avoid silent partial edit.
 old=old.replace('Q51、Q52。','Q51、Q52、Q56。')
 new='截至 §4.85，56 个宽口径问题项中，49 项有部分实验／限定证据，4 项主要内容仍待验证或产品集成，2 项模板产品已按用户确认延后，1 项可选 SVN 自动管理不开放；整项完整关闭为 0。四项为 Q26、Q42、Q51、Q52。Q56 本轮按已有安装证据与新增复制中断检查推进为部分，半成品归属／清理缺口未关闭。'
 assert old in t;t=t.replace(old,new).replace('不是只剩五项。','不是只剩四项。').replace('不能用 48／56 作为研究完成率','不能用 49／56 作为研究完成率')
 t=t.replace('公网 HTTPS／代理、复制中途、完整业务 MCP、跨宿主／历史引用及实际原生清理仍待证。','公网 HTTPS／代理、复制归属／恢复清理（§4.85 已复现半成品遗留）、完整业务 MCP、跨宿主／历史引用及实际原生清理仍待证。')
 assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：安装复制中途退出已实跑，旧默认保留、完整重复制和显式回退有证据；发现未登记半成品遗留，已补准备目录归属／清理合同，尚未验证修正。见[技术方案 §12.1](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续验证复制 attempt 与准备目录归属、在用资源保留及恢复清理，并核对完整业务／执行范围的剩余联合证据。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'observations':3,'archiveFiles':len(files),'partial':49,'pending':4,'unresolvedGap':'untracked partial staging directory'}))
