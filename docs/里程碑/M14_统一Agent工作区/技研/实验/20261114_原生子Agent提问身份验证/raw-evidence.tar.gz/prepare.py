from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_原生子Agent提问身份验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
results=[json.loads((root/('latest-'+d+'.json')).read_text())for d in ['claude','codex','claude-two']]
for r in results:assert r['passed']and not r['error']and not r['serverError']and all(x['exit']['code']==0 for x in r['processes'])
a,b,c=results;assert len(a['elicitations'])==1 and len(b['elicitations'])==1 and len(c['elicitations'])==2
assert b['elicitations'][0]['rpcId']==0;assert b['elicitations'][0]['request']['threadId']==b['childId']!=b['rootThread']
assert c['elicitations'][0]['request']==c['elicitations'][1]['request'];assert c['elicitations'][0]['requestId']!=c['elicitations'][1]['requestId']
for r in [a,c]:
 for e in r['elicitations']:assert set(e['optionKeys'])=={'signal','requestId'}and not any(k in e['request']for k in ['agentId','agent_id','threadId','turnId'])
 frames=[json.loads(l)for l in(Path(r['out'])/'frames.jsonl').read_text().splitlines()]
 children={m['agent_id']for m in frames if m.get('type')=='assistant'and m.get('agent_id')and any(x.get('name')=='mcp__wy__ask'for x in m.get('message',{}).get('content',[])if isinstance(x,dict))};assert len(children)==(2 if r.get('two')else 1)
refs=[t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts',Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'runtimes':[json.loads((Path(r['out'])/'native-runtime.json').read_text())for r in [a,b]],'t3Boundary':'Source only: Claude callback uses active turn context and requestId, Codex handler resolves active turn. Neither T3 adapter was executed by this probe.','identityBoundary':'Native child is not a separate host-delegated task. Claude MCP call metadata carries toolUseId, but form callback and raw elicitation envelope do not directly carry it or agentId in this fixed version; a trusted bridge association would require additional evidence.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[(root/n,n)for n in ['probe.mjs','mcp.mjs','model.mjs','native-inputs.mjs','prepare.py','source-review.json']]
for r in results:
 p=Path(r['out']);files += [(x,str(x.relative_to(root)))for x in sorted(p.iterdir())if x.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x,n in files:tar.add(x,arcname=n,recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':n,'sha256':sha(x.read_bytes())}for x,n in files]}
summary={'cases':results,'nativeCases':3,'modelRequests':sum(r['parentRequests']+r['childRequests']for r in results),'elicitationRequests':sum(len(r['elicitations'])for r in results),'fullyIntegratedHostChildRouting':False}
for n,v in [('result.json',summary),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 原生子 Agent 提问身份验证

日期：2026-11-14。关联 R05／R06、Q26／Q29。真实固定版本 native、受控本机模型和 HTTP MCP；没有真人审批、真实业务或产品 UI。

## 实际场景

| 场景 | 观察 |
| --- | --- |
| Claude SDK 0.3.321／native 2.1.321，原生子 Agent 调 MCP 表单 | 子任务工具调用／结果帧有 agent_id、parent_tool_use_id，MCP call 的 meta 有 claudecode/toolUseId；但 onElicitation 及原始 elicitation control_request 没有子 Agent／tool-use 身份 |
| Codex 0.167.1，原生子 Agent 调相同 MCP 表单 | 提问 RPC 带子 threadId／turnId，threadId 等于实际 spawn 结果且不同于父 thread；本次 RPC id=0，仍是合法请求 |
| Claude 两个原生子 Agent 并发发送同文表单 | 两个回调均已到达后才允许回答；serverName／message／schema 完全一致，请求 ID 不同，回调 options 仍只有 signal／requestId；不能用正文区分子 Agent |

三条原生场景通过，共 18 次本机模型请求、4 条表单提问，3 个 native 进程 exit 0。回答由实验宿主自动提供合成内容，不代表用户批准。每次请求独立得到结果，子结果返回父 Agent。

## 设计解释

“请求可独立应答”与“请求可归属到某个原生子 Agent”不是同一个能力。Claude 的 requestId 足以回应原控制请求，但本版本的该回调没有直接子身份；原始控制包也不含前述 toolUseId。受控 MCP 服务可取得工具调用元信息，但将它关联到某个 elicitation 仍需要可信桥的额外记录与验证，不能默认所有第三方服务都提供可信身份。

这不等于 WillYou 的宿主委派子任务无法提问。宿主委派有独立 task／binding／run／Query，创建回调时的受管运行归属仍然明确；同一 Query 内 provider_native 子节点才涉及额外细分。无法细分时应展示已证明的宿主运行归属，原生子节点标为未确认；不要按当前选中会话、最后一个子节点或问题正文猜测。

本轮没有执行 T3 适配器。源码显示 T3 Claude 使用 activeTurn 与 requestId，Codex 查询活跃回合上下文；不能把源码参考升级为 T3 对本场景的实际支持结论。

## 未覆盖与复现

未验证宿主子任务问题账、真实 UI／IPC、子树停止期间的未决表单、迟到回答、跨 Provider 切换或崩溃恢复；此前插件审批和独立表单取消证据仍按各自范围保留，不能直接相加为 Q26 完整通过。Q26 继续待集成，Q29 继续部分。

运行 `node probe.mjs claude`、`node probe.mjs codex`、`node probe.mjs claude --two-children`。需允许本机监听，并具备归档记录的固定 native／SDK／MCP 依赖；二进制启动前校验摘要，全部配置与凭据为隔离合成值。各 attempt 保存当时的驱动，单子与双子变体可分别审计。

[结果](result.json) · [源码与版本](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 anchor='## 8. Git／SVN 与工作目录协调';assert anchor in t and '#### 7.4.2 'not in t
 add='''#### 7.4.2 原生子 Agent 的提问归属

[子 Agent MCP 表单实验](实验/20261114_原生子Agent提问身份验证/README.md)取得两端单子任务及 Claude 双子并发证据。Codex 0.167.1 的 mcpServer/elicitation/request 携带实际子 threadId／turnId，可在当前连接的已知谱系中核对；本次 RPC id 为 0，解码不得用真值判断丢弃合法请求。原始请求身份与宿主生成的请求 ID 分开，归属至少绑定连接代次、driver、run、原生线程／回合和请求标识。

Claude SDK 0.3.321／native 2.1.321 的子工具帧有 agent_id／parent_tool_use_id，MCP 调用 meta 有 claudecode/toolUseId，但 onElicitation 的 options 只有 signal／requestId，原始 elicitation 控制包也没有子身份或 toolUseId。两个子 Agent 同时提问时，serverName／message／schema 可完全一致；requestId 能区分应答，不能自行证明哪一个原生子节点发起。禁止按正文、时序邻近或最近活跃子 Agent 猜归属。受控桥若补关联，需要独立的调用账与可信绑定证据；第三方 meta／展示字段不直接成为授权身份。

宿主委派与原生子 Agent 分别处理：宿主子任务拥有独立 task／binding／run，其 Query／连接的创建归属是已知的；原生子节点可定位能力由 Driver 单独声明。统一问题投影保留 origin、确定的宿主运行归属、可选且有证据的原生子节点。不能细分时在已确定的宿主运行下显示“原生子节点未确认”，不伪造父节点来源，也不把请求转给当前选中的会话。每个请求仍可独立取消／回答，但取消子节点后如何处理未能细分的请求须保持该运行级能力边界，不承诺精确子节点自动路由。

本批没有执行 T3 适配器或 WillYou 问题账／UI，也未联验 Provider 切换、停止与迟到回答；原生身份证据不替代宿主业务授权。Q26 的宿主子任务提问、人工审批及取消恢复仍需同一运行账和真实接线验证。

'''
 return t.replace(anchor,add+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.87 'not in t
 add='''### 4.87 原生子 Agent 提问身份与并发同文

[原生表单实验](实验/20261114_原生子Agent提问身份验证/README.md)三条路径通过：两端子 Agent 经 HTTP MCP 发起并收到合成回答，Claude 另验证两子同文表单同时在途。Codex 回调带实际子 threadId／turnId、RPC id=0；Claude callback／原始 elicitation 包无直接子身份，虽工具帧和 MCP call 另有 agent／tool-use 信息，两条回调内容可完全一致。

三进程 exit 0，18 次本机模型请求、4 条表单；不是人工批准、宿主委派问题账或 T3 实际适配器。技术方案 §7.4.2 区分请求应答与子身份归属，以及独立宿主 run 和原生子节点；缺身份不按正文／活跃节点猜测。Q29 保持部分；Q26 仍待集成，不能把 provider_native 表单实验当作 host_delegated 子任务问题完整接线。

'''
 t=t.replace(anchor,add+anchor).replace('截至 §4.86，56 个宽口径问题项中','截至 §4.87，56 个宽口径问题项中')
 old='原生提问／真实 IPC 未闭环 |'
 # Only Q26 receives this targeted addition; other business rows keep their own scope.
 lines=t.splitlines()
 for i,l in enumerate(lines):
  if l.startswith('| Q26 |'):
   assert old in l;lines[i]=l.replace(old,'原生提问／真实 IPC 未闭环；§4.87 补 provider_native 表单的子身份差异与同文并发，未替代 host_delegated 问题账 |')
 t='\n'.join(lines)+'\n';assert len(re.findall(r'^\| Q\d\d \|',t,re.M))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：两端原生子 Agent 的 MCP 提问及 Claude 同文并发已实跑；明确请求独立应答与子节点身份定位的差异。见[技术方案 §7.4.2](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对宿主委派问题／审批与取消、原生子节点归属能力及完整运行／业务联合证据；资源占用与恢复清理的剩余项继续保留。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'nativeCases':3,'archiveFiles':len(files),'modelRequests':summary['modelRequests'],'forms':summary['elicitationRequests']}))
