import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import {inspect,canonical,digest,planSchema} from './contract.mjs';
const transaction=(store,fn)=>actual.withResourceLock(store.root,()=>store.sqlite.transaction(fn).immediate());
const find=(store,key)=>{const row=store.sqlite.prepare('SELECT * FROM m14_delivery WHERE receipt_id=? AND token=? AND plan_hash=?').get(key.receiptId,key.token,key.planHash);assert(row,'RECEIPT_MISMATCH');assert.equal(row.store_id,store.storeId);return row;};
const current=(db,plan)=>{const p=db.prepare('SELECT * FROM ai_profiles WHERE id=?').get(plan.profileId);assert(p&&!p.command_pending&&p.runner===plan.runner&&p.updated_at===plan.profileRevision,'TARGET_UNAVAILABLE');};
function resources(store,plan){for(const p of plan.resources){const r=store.get(p.resourceId);assert(r.state==='ready'&&r.integrity==='valid'&&r.kind===p.kind&&r.contentHash===p.contentHash&&r.relativePath===p.relativePath&&r.generation===p.generation,'RESOURCE_CHANGED');}}
function owned(store,runs,run,row){assert.equal(runs.store,store);actual.assertOwnedCapabilityRun(runs,run);assert.equal(run.runId,row.run_id,'WRONG_DESTINATION_RUN');const r=runs.bridgePreparation(run.runId).run;assert.equal(r.taskId,row.task_id);}
export async function prepare(store,runs,run,rootResourceId,reader){return transaction(store,()=>{
 actual.assertOwnedCapabilityRun(runs,run);const db=store.sqlite,r=db.prepare('SELECT * FROM capability_runs WHERE run_id=?').get(run.runId),b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(r.binding_id),owner=reader.read(process.pid);assert(owner&&owner.pid===r.owner_pid&&owner.startedAt===r.owner_started_at,'OWNER_IDENTITY_MISMATCH');
 const ids=db.prepare('WITH RECURSIVE needed(id) AS (VALUES(?) UNION SELECT dependency_id FROM capability_resource_dependencies d JOIN needed n ON d.resource_id=n.id) SELECT id FROM needed ORDER BY id').all(rootResourceId);
 const plan=planSchema.parse({schema:'m14-delivery-receipt-probe-v1',receiptId:randomUUID(),token:randomUUID(),storeId:store.storeId,taskId:r.task_id,bindingId:r.binding_id,capabilitySessionId:r.capability_session_id,snapshotHash:r.snapshot_hash,runId:r.run_id,generation:r.generation,runner:r.runner,profileId:b.profile_id,profileRevision:b.profile_revision,resources:ids.map(({id})=>{const r=store.get(id);assert.equal(r.pathScope,'C');return{resourceId:r.resourceId,kind:r.kind,contentHash:r.contentHash,relativePath:r.relativePath,generation:r.generation};})});
 current(db,plan);resources(store,plan);const json=canonical(plan),planHash=digest(json);
 db.prepare("INSERT INTO m14_delivery(receipt_id,token,store_id,task_id,binding_id,cap_id,snapshot_hash,run_id,generation,plan_json,plan_hash,owner_pid,owner_started_at,owner_instance,phase) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'prepared')").run(plan.receiptId,plan.token,plan.storeId,plan.taskId,plan.bindingId,plan.capabilitySessionId,plan.snapshotHash,plan.runId,plan.generation,json,planHash,owner.pid,owner.startedAt,r.owner_instance_id);
 for(const p of plan.resources)db.prepare('INSERT INTO m14_delivery_ref VALUES(?,?,?,?,?,?)').run(plan.receiptId,p.resourceId,p.kind,p.contentHash,p.relativePath,p.generation);
 inspect(db,db.prepare('SELECT * FROM m14_delivery WHERE receipt_id=?').get(plan.receiptId));return{receiptId:plan.receiptId,token:plan.token,planHash};
});}
export async function adopt(store,runs,run,key,checkpoint=()=>{}){return transaction(store,()=>{
 const row=find(store,key),{plan}=inspect(store.sqlite,row);assert(['prepared','adopted'].includes(row.phase),'NOT_ADOPTABLE');owned(store,runs,run,row);current(store.sqlite,plan);resources(store,plan);
 const lease=store.sqlite.prepare("SELECT * FROM capability_resource_leases WHERE owner_kind='run' AND owner_id=? AND host_instance_id=? AND state='active'").get(run.runId,runs.instanceId);assert(lease,'RUN_LEASE_UNAVAILABLE');assert(row.run_lease_id===null||row.run_lease_id===lease.lease_id,'RUN_LEASE_CHANGED');
 for(const r of plan.resources){const old=store.sqlite.prepare('SELECT * FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').get(lease.lease_id,r.resourceId);if(old)assert(old.content_hash===r.contentHash&&old.generation===r.generation,'RUN_MEMBER_CHANGED');else store.sqlite.prepare('INSERT INTO capability_lease_resources VALUES(?,?,?,?)').run(lease.lease_id,r.resourceId,r.contentHash,r.generation);}
 store.sqlite.prepare("UPDATE m14_delivery SET phase='adopted',run_lease_id=? WHERE receipt_id=?").run(lease.lease_id,row.receipt_id);checkpoint('inside-adopt');return{leaseId:lease.lease_id,receiptId:row.receipt_id};
});}
export async function releasePreparation(store,runs,run,key){return transaction(store,()=>{
 const row=find(store,key),{plan}=inspect(store.sqlite,row);assert.equal(row.phase,'adopted','NOT_ADOPTED');owned(store,runs,run,row);resources(store,plan);
 const lease=store.sqlite.prepare('SELECT * FROM capability_resource_leases WHERE lease_id=?').get(row.run_lease_id);assert(lease?.state==='active'&&lease.owner_id===row.run_id&&lease.host_instance_id===runs.instanceId,'RUN_LEASE_CHANGED');
 for(const r of plan.resources){const m=store.sqlite.prepare('SELECT * FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').get(lease.lease_id,r.resourceId);assert(m&&m.content_hash===r.contentHash&&m.generation===r.generation,'RUN_MEMBER_MISSING');}
 store.sqlite.prepare("UPDATE m14_delivery SET phase='released' WHERE receipt_id=?").run(row.receipt_id);
});}
export async function reconcile(store,key,reader){return transaction(store,()=>{
 const row=find(store,key),{run}=inspect(store.sqlite,row);if(['released','abandoned'].includes(row.phase))return{state:row.phase};
 const owner=reader.state({pid:row.owner_pid,startedAt:row.owner_started_at});if(owner!=='stopped')return{state:'held',reason:'OWNER_'+owner};
 const unresolved=store.sqlite.prepare("SELECT 1 FROM capability_run_processes WHERE run_id=? AND state NOT IN ('exited','canceled') UNION ALL SELECT 1 FROM capability_run_activities WHERE run_id=? AND state='active' UNION ALL SELECT 1 FROM capability_resource_leases WHERE owner_kind='run' AND owner_id=? AND state<>'released' LIMIT 1").get(row.run_id,row.run_id,row.run_id);
 if(!['stopped','failed'].includes(run.state)||run.revocation_state!=='revoked'||unresolved)return{state:'held',reason:'RUN_UNRESOLVED'};
 store.sqlite.prepare("UPDATE m14_delivery SET phase='abandoned' WHERE receipt_id=?").run(row.receipt_id);return{state:'abandoned'};
});}
