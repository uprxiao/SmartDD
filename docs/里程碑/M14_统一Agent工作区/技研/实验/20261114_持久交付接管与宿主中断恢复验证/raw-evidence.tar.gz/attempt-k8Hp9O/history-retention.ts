import {storedCapabilitySessionSnapshotSchema} from '/Users/hx/projects/SmartDD/src/shared/application-session-v3.ts';
import {canonicalJson,digest} from '/Users/hx/projects/SmartDD/src/main/core/applications/manifest.ts';

export function historyRetention(store) {
 const db=store.sqlite, names=['m14_binding','m14_cap','m14_revision','m14_ref','m14_unmapped','m14_unmapped_version','m14_migration','m14_preparation_ref','m14_preparation'];
 const present=names.filter(name=>db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name));
 if(!present.length)return{refs:[],issues:[],basis:null};
 if(present.length!==names.length)return{refs:[],issues:['m14-schema-incomplete'],basis:present};
 const bindings=db.prepare('SELECT * FROM m14_binding ORDER BY binding_id').all(),caps=db.prepare('SELECT * FROM m14_cap ORDER BY cap_id').all(),revisions=db.prepare('SELECT * FROM m14_revision ORDER BY cap_id,snapshot_hash').all(),refs=db.prepare('SELECT * FROM m14_ref ORDER BY cap_id,snapshot_hash,ref_id').all(),issues=[];
 const unmapped=db.prepare('SELECT * FROM m14_unmapped ORDER BY task_id').all(),unmappedVersions=db.prepare('SELECT * FROM m14_unmapped_version ORDER BY task_id,snapshot_hash').all(),migration=db.prepare('SELECT * FROM m14_migration ORDER BY version').all();
 if(migration.length!==1||migration[0].version!==1)issues.push('m14-schema-version-unknown');
 for(const row of [...unmapped,...unmappedVersions])issues.push('m14-unmapped-history:'+row.task_id+':'+row.snapshot_hash);
 const preparation=db.prepare('SELECT * FROM m14_preparation_ref ORDER BY binding_id,ref_id').all(),plans=db.prepare('SELECT * FROM m14_preparation ORDER BY binding_id').all();
 for(const b of bindings){
  const hasCap=caps.some(c=>c.binding_id===b.binding_id&&c.task_id===b.task_id),pins=preparation.filter(p=>p.binding_id===b.binding_id);
  if(['historical','prepared'].includes(b.phase)&&!hasCap||b.phase==='preparing'&&!pins.length||b.phase==='planned'&&(hasCap||pins.length||b.native_id!==null)||!['historical','prepared','preparing','planned','canceled'].includes(b.phase))issues.push('m14-binding-unresolved:'+b.binding_id);
  if(b.phase==='canceled'&&pins.length)issues.push('m14-cancel-unresolved:'+b.binding_id);
 }
 for(const p of plans)try{
  const b=bindings.find(b=>b.binding_id===p.binding_id),value=storedCapabilitySessionSnapshotSchema.parse(JSON.parse(p.snapshot_json));if(!b||b.phase!=='preparing'||value.taskId!==b.task_id||value.runner!==b.runner||digest(canonicalJson(value))!==p.snapshot_hash)throw Error('plan');
 }catch{issues.push('m14-plan-unresolved:'+p.binding_id);}
 for(const p of preparation)try{
  const r=store.get(p.ref_id);if(!plans.some(x=>x.binding_id===p.binding_id&&x.token===p.token)||!bindings.some(b=>b.binding_id===p.binding_id&&b.phase==='preparing')||r.state!=='ready'||r.integrity!=='valid'||r.generation!==p.generation||r.kind!==p.ref_kind||r.contentHash!==p.ref_hash||r.relativePath!==p.relative_path)throw Error('preparation integrity');
 }catch{issues.push('m14-preparation-unresolved:'+p.binding_id+':'+p.ref_id);}
 for(const c of caps){
  if(!bindings.some(b=>b.binding_id===c.binding_id&&b.task_id===c.task_id)||!revisions.some(r=>r.cap_id===c.cap_id&&r.snapshot_hash===c.current_hash)||c.retention==='hold')issues.push('m14-history-unresolved:'+c.cap_id);
 }
 for(const r of revisions)try{
  const c=caps.find(c=>c.cap_id===r.cap_id&&c.binding_id===r.binding_id&&c.task_id===r.task_id),b=bindings.find(b=>b.binding_id===r.binding_id&&b.task_id===r.task_id),value=storedCapabilitySessionSnapshotSchema.parse(JSON.parse(r.snapshot_json));
  if(!c||!b||value.taskId!==r.task_id||value.runner!==b.runner||digest(canonicalJson(value))!==r.snapshot_hash)throw Error('identity');
  const expected=new Set(['agent-adapter:'+value.runner+':'+value.adapterBinding.hash,...value.packages.flatMap(p=>['app:'+p.packageHash,'runtime:'+p.runtimeHash]),...value.standardSkills.map(s=>'standard-skill:'+s.skillId+':'+s.hash),...value.mcp.map(m=>(m.kind==='applications'?'runtime:':'legacy-runtime:')+m.runtimeHash)]);
  for(const id of expected)if(!refs.some(f=>f.cap_id===r.cap_id&&f.snapshot_hash===r.snapshot_hash&&f.ref_id===id))throw Error('missing resource');
 }catch{issues.push('m14-revision-unresolved:'+r.cap_id+':'+r.snapshot_hash);}
 for(const f of refs)try{
  const r=store.get(f.ref_id);
  if(!revisions.some(r=>r.cap_id===f.cap_id&&r.snapshot_hash===f.snapshot_hash&&r.task_id===f.task_id)||r.kind!==f.ref_kind||r.contentHash!==f.ref_hash||r.relativePath!==f.relative_path||r.state==='removed')throw Error('resource');
 }catch{issues.push('m14-reference-integrity:'+f.cap_id+':'+f.ref_id);}
 return{refs:[...refs,...preparation.map(p=>({...p,cap_id:p.binding_id,snapshot_hash:p.token}))],issues,basis:{bindings,caps,revisions,refs,unmapped,unmappedVersions,migration,preparation,plans}};
}
