import {writeSync,writeFileSync} from 'node:fs';
import {setup,reader} from './fixture.mjs';
import {prepare,adopt,releasePreparation} from './delivery.mjs';
const [mode,record]=process.argv.slice(2),f=await setup(),key=await prepare(f.store,f.runs,f.run,f.delivery.pack.resourceId,reader());
const evidence={mode,key,database:f.sqlite.name,root:f.root,runId:f.run.runId,bindingId:f.scope.bindingId,sourcePackage:f.application.resourceId,deliveryPackage:f.delivery.pack.resourceId,deliveryRuntime:f.delivery.runtime.resourceId,owner:reader().read(process.pid)};
function stop(phase){writeFileSync(record,JSON.stringify({...evidence,phase},null,2)+'\n');writeSync(1,JSON.stringify({checkpoint:phase,pid:process.pid})+'\n');Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0);}
if(mode==='prepared')stop('prepared-committed');
await adopt(f.store,f.runs,f.run,key,phase=>{if(mode==='transaction')stop(phase);});
if(mode==='overlap')stop('adoption-committed');
if(mode==='unknown'){await f.run.cli.arm();stop('armed-without-attach');}
await releasePreparation(f.store,f.runs,f.run,key);
stop('preparation-released');
