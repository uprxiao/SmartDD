import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,readFileSync,writeFileSync,copyFileSync,existsSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import Database from 'better-sqlite3';
import actual from './actual.cjs';
import {setup,reader,engine} from './fixture.mjs';
import {prepare,adopt,releasePreparation,reconcile} from './delivery.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n');
for(const n of ['build.json','build.mjs','candidate.sql','delivery.sql','contract.mjs','migration.mjs','history-retention.ts','member-retention.ts','retention.ts','delivery.mjs','fixture.mjs','worker.mjs','probe.mjs','resource-gc-plan.ts.variant','resource-graph-maintenance.ts.variant'])copyFileSync(root+'/'+n,out+'/'+n);
async function snapshot(db,id,metadata){assert.deepEqual(db.pragma('integrity_check'),[{integrity_check:'ok'}]);assert.deepEqual(db.pragma('foreign_key_check'),[]);await db.backup(out+'/'+id+'.sqlite');save(out+'/'+id+'-fixture.json',metadata);}
async function check(id,label,fn){const f=await setup();try{const evidence=await fn(f);checks.push({id,label,status:'passed',evidence});console.log(JSON.stringify({id,status:'passed'}));}catch(e){checks.push({id,label,status:'failed',error:e.stack});throw e;}finally{if(f.runs.get(f.run.runId).state==='prepared')await f.run.cancelBeforeFork();await snapshot(f.sqlite,id,{root:f.root,runId:f.run.runId,bindingId:f.scope.bindingId,source:f.application.resourceId,delivery:f.delivery.pack.resourceId});f.sqlite.close();save(out+'/progress.json',{checks});}}
const start=f=>prepare(f.store,f.runs,f.run,f.delivery.pack.resourceId,reader());
const row=(f,key)=>f.sqlite.prepare('SELECT * FROM m14_delivery WHERE receipt_id=?').get(key.receiptId);
async function crash(id,mode){
 const record=out+'/'+id+'-worker.json',p=spawn(process.execPath,[root+'/worker.mjs',mode,record],{env:{PATH:'/usr/bin:/bin',HOME:out,TMPDIR:'/private/tmp'},stdio:['ignore','pipe','pipe']});
 let stdout='',stderr='',checkpoint;const timer=setTimeout(()=>{p.kill('SIGKILL');},45000);
 const ended=new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',(code,signal)=>resolve({pid:p.pid,code,signal}));});
 p.stdout.on('data',b=>{stdout+=b;for(const line of stdout.trim().split('\n'))try{const m=JSON.parse(line);if(m.checkpoint&&!checkpoint){checkpoint=m;p.kill('SIGKILL');}}catch{}});p.stderr.on('data',b=>stderr+=b);
 let db;try{
  const exit=await ended;clearTimeout(timer);save(out+'/'+id+'-process.json',{exit,stdout,stderr,checkpoint});assert.equal(exit.signal,'SIGKILL',stderr);assert(checkpoint,'worker failed or timed out before requested checkpoint');
  const spec=JSON.parse(readFileSync(record));assert.equal(reader().state(spec.owner),'stopped');db=new Database(spec.database);db.pragma('foreign_keys=ON');const store=new actual.ResourceStore(db,spec.root,undefined,{processes:reader()}),gc=engine(store);
  assert(!(await gc.plan(spec.deliveryPackage)).canCollect);const before=await reconcile(store,spec.key,reader());assert.equal(before.state,'held');
  const recovery=await actual.recoverCapabilityRuns(store,reader()),after=await reconcile(store,spec.key,reader()),receipt=db.prepare('SELECT * FROM m14_delivery').get();
  if(mode==='unknown'){
   assert.equal(after.state,'held');assert.equal(after.reason,'RUN_UNRESOLVED');assert.equal(recovery.find(r=>r.runId===spec.runId).state,'orphaned');assert.equal(receipt.phase,'adopted');assert(!(await gc.plan(spec.deliveryPackage)).canCollect);
  }else{
   assert.equal(after.state,mode==='released'?'released':'abandoned');assert.equal(recovery.find(r=>r.runId===spec.runId).state,'stopped');const plan=await gc.plan(spec.deliveryPackage);assert(plan.canCollect);await gc.cleanup(spec.deliveryPackage,plan.planHash);assert.equal(store.get(spec.deliveryPackage).state,'removed');assert(existsSync(store.directory(store.get(spec.sourcePackage))));assert.equal((await reconcile(store,spec.key,reader())).state,after.state);
   if(mode==='transaction')assert.equal(db.prepare('SELECT COUNT(*) n FROM capability_lease_resources WHERE resource_id=?').get(spec.deliveryPackage).n,0);
  }
  await snapshot(db,id,{...spec,recovery,after});checks.push({id,label:'actual host SIGKILL at '+mode,status:'passed',evidence:{exit,checkpoint,recovery,after,sourceHistoryPreserved:true,noAgentSpawned:true,transactionRollback:mode==='transaction'}});console.log(JSON.stringify({id,status:'passed'}));
 }catch(e){checks.push({id,label:'actual host SIGKILL at '+mode,status:'failed',error:e.stack});if(db)await snapshot(db,id,{mode,failed:true});throw e;}finally{clearTimeout(timer);db?.close();save(out+'/progress.json',{checks});}
}
let error;
try{
 await check('D01','combined history, delivery pins and actual run member lifetime',async f=>{
  const key=await start(f),old=await f.engine.plan(f.delivery.pack.resourceId);assert(!old.canCollect);await adopt(f.store,f.runs,f.run,key);await releasePreparation(f.store,f.runs,f.run,key);assert(!(await f.engine.plan(f.delivery.pack.resourceId)).canCollect);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM m14_ref WHERE ref_id=?').get(f.delivery.pack.resourceId).n,0);
  await f.run.cancelBeforeFork();const p=await f.engine.plan(f.delivery.pack.resourceId);assert(p.canCollect);await f.engine.cleanup(f.delivery.pack.resourceId,p.planHash);assert.equal(f.store.get(f.delivery.pack.resourceId).state,'removed');assert(!(await f.engine.plan(f.application.resourceId)).canCollect);assert(existsSync(f.store.directory(f.store.get(f.application.resourceId))));assert.equal(row(f,key).phase,'released');return{historyUnchanged:true,deliveryAuditPreserved:true,runMembersProtect:true,physicalDeleteAfterRelease:true};
 });
 await check('D02','strict identity, exact receipt and owned handle',async f=>{
  const key=await start(f);await assert.rejects(adopt(f.store,f.runs,{...f.run},key),e=>e.code==='SCOPE_DENIED');await assert.rejects(adopt(f.store,f.runs,f.run,{...key,token:randomUUID()}),/RECEIPT_MISMATCH/);
  const original=row(f,key);for(const field of ['bindingId','runId','generation']){const plan=JSON.parse(original.plan_json);plan[field]=field==='generation'?2:randomUUID();f.sqlite.prepare('UPDATE m14_delivery SET plan_json=?,plan_hash=? WHERE receipt_id=?').run(actual.canonicalJson(plan),actual.digest(actual.canonicalJson(plan)),key.receiptId);await assert.rejects(adopt(f.store,f.runs,f.run,{...key,planHash:actual.digest(actual.canonicalJson(plan))}),/PLAN_IDENTITY_CHANGED/);assert(!(await f.engine.plan(f.delivery.pack.resourceId)).canCollect);}
  f.sqlite.prepare('UPDATE m14_delivery SET plan_json=?,plan_hash=? WHERE receipt_id=?').run(original.plan_json,original.plan_hash,key.receiptId);await adopt(f.store,f.runs,f.run,key);return{copiedHandleRejected:true,staleTokenRejected:true,rehashedScopeSubstitutionRejected:true};
 });
 await check('D03','release requires adopted members; retry of the same adoption is idempotent',async f=>{
  const key=await start(f);await assert.rejects(releasePreparation(f.store,f.runs,f.run,key),/NOT_ADOPTED/);const first=await adopt(f.store,f.runs,f.run,key),again=await adopt(f.store,f.runs,f.run,key);assert.deepEqual(again,first);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').get(first.leaseId,f.delivery.pack.resourceId).n,1);
  const member=f.sqlite.prepare('SELECT * FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').get(first.leaseId,f.delivery.pack.resourceId);f.sqlite.prepare('DELETE FROM capability_lease_resources WHERE lease_id=? AND resource_id=?').run(first.leaseId,f.delivery.pack.resourceId);await assert.rejects(releasePreparation(f.store,f.runs,f.run,key),/RUN_MEMBER_MISSING/);assert.equal(row(f,key).phase,'adopted');assert(!(await f.engine.plan(f.delivery.pack.resourceId)).canCollect);f.sqlite.prepare('INSERT INTO capability_lease_resources VALUES(?,?,?,?)').run(member.lease_id,member.resource_id,member.content_hash,member.generation);await releasePreparation(f.store,f.runs,f.run,key);return{sameReceiptIdempotent:true,missingMemberCannotReleasePins:true};
 });
 await check('D04','profile and live policy are rechecked without restoring revoked execution',async f=>{
  const key=await start(f);f.setAllowed(false);await assert.rejects(adopt(f.store,f.runs,f.run,key),e=>e.code==='SCOPE_DENIED');f.setAllowed(true);f.sqlite.prepare('UPDATE ai_profiles SET updated_at=2 WHERE id=?').run(f.profile);await assert.rejects(adopt(f.store,f.runs,f.run,key),/TARGET_UNAVAILABLE/);assert.equal(row(f,key).phase,'prepared');assert(!(await f.engine.plan(f.delivery.pack.resourceId)).canCollect);assert.equal((await reconcile(f.store,key,reader())).reason,'OWNER_running');return{currentPolicyChecked:true,targetRevisionChecked:true,liveHostNotReclaimed:true};
 });
 await check('D05','transaction rollback retains preparation; member-only change invalidates prior GC plan',async f=>{
  const before=await f.engine.plan(f.delivery.pack.resourceId),key=await start(f);await assert.rejects(adopt(f.store,f.runs,f.run,key,()=>{throw Error('injected-transaction-failure');}),/injected-transaction-failure/);assert.equal(row(f,key).phase,'prepared');assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM capability_lease_resources WHERE resource_id=?').get(f.delivery.pack.resourceId).n,0);await adopt(f.store,f.runs,f.run,key);await releasePreparation(f.store,f.runs,f.run,key);await assert.rejects(f.engine.cleanup(f.delivery.pack.resourceId,before.planHash),e=>e.code==='RESOURCE_STATE_CHANGED');return{rollbackAndStaleGcPlan:true};
 });
 for(const [id,mode]of [['D06','prepared'],['D07','transaction'],['D08','overlap'],['D09','released'],['D10','unknown']])await crash(id,mode);
}catch(e){error=e.stack;process.exitCode=1;}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,failed:checks.filter(c=>c.status==='failed').length,error,scope:'Isolated durable delivery receipt ties migrated binding/revision and legacy actual run, combined candidate GC reader, actual owned handles and Mac process recovery. Synthetic packages; no native Agent, full programmatic launcher, business operation or product implementation.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify(result,null,2));
