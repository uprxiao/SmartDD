import Database from '/private/tmp/willyou-m14-owner-probe/node_modules/better-sqlite3/lib/index.js';
import{inventory}from'/private/tmp/willyou-m14-f10-retention/inventory.mjs';
import{readFileSync,writeFileSync,readdirSync}from'node:fs';import{createHash}from'node:crypto';import{execFileSync}from'node:child_process';
const root=import.meta.dirname,result=JSON.parse(readFileSync(root+'/latest.json'));if(result.passed!==7||result.error)throw Error('PROBE_FAILED');
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const old=JSON.parse(readFileSync('/Users/hx/projects/SmartDD/docs/里程碑/M14_统一Agent工作区/技研/实验/20261114_Git工作树基线与成果保留验证/sources.json'));
const sources=old.sources.map(x=>{const p='/Users/hx/projects/'+x.repository+'/'+x.path;const current=sha(p);return{...x,oldSha256:x.sha256,sha256:current,unchanged:current===x.sha256}});
const dbChecks=[];
for(const dir of readdirSync(result.out,{withFileTypes:true}).filter(x=>x.isDirectory())){
 const path=result.out+'/'+dir.name+'/state.sqlite';const db=new Database(path,{readonly:true});const i=inventory(db);dbChecks.push({path,baseline:db.prepare('select revision from m14_contract_baseline').get().revision,issues:i.issues,foreignKeyCheck:db.pragma('foreign_key_check'),integrity:db.pragma('integrity_check')});db.close();
 if(i.issues.length)throw Error(JSON.stringify(dbChecks.at(-1)));
}
const output={sources,dbChecks,heads:Object.fromEntries(['SmartDD','t3code'].map(x=>[x,execFileSync('git',['-C','/Users/hx/projects/'+x,'rev-parse','HEAD'],{encoding:'utf8'}).trim()])),gitVersion:execFileSync('git',['--version'],{encoding:'utf8'}).trim(),candidateHash:sha(root+'/candidate.py'),probeHash:sha(root+'/probe.py'),sqlHash:sha(root+'/contract.sql'),seedAudit:JSON.parse(readFileSync(root+'/seed-audit.json'))};
writeFileSync(root+'/source-audit.json',JSON.stringify(output,null,2));console.log(JSON.stringify({sources:sources.length,changed:sources.filter(x=>!x.unchanged).map(x=>x.path),databases:dbChecks.length,retentionIssues:dbChecks.flatMap(x=>x.issues)}));
