import os,sys,json,sqlite3,subprocess,hashlib,uuid,fcntl,contextlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def digest(b):return hashlib.sha256(b).hexdigest()
def identity(p):
 p=Path(p);s=p.lstat()
 if p.is_symlink():raise ValueError('SYMLINK_IDENTITY')
 return js({'path':str(p.resolve()),'dev':s.st_dev,'ino':s.st_ino})
def connect(p):
 c=sqlite3.connect(p);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');return c
def schema_hash(c):return digest(js([dict(r) for r in c.execute('SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name')]).encode())
def install(c):
 row=c.execute('select * from m14_contract_baseline').fetchone();assert row['revision']=='C1.6';assert schema_hash(c)==row['schema_hash']
 sql=(ROOT/'contract.sql').read_text();c.executescript('BEGIN IMMEDIATE;'+sql)
 c.execute('update m14_contract_baseline set revision=?,schema_hash=?,inputs_hash=?',('C1.7',schema_hash(c),digest(sql.encode())));c.commit()
def env(base):
 home=Path(base)/'home';home.mkdir(exist_ok=True)
 return {'PATH':os.environ['PATH'],'HOME':str(home),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','LC_ALL':'C','GIT_TERMINAL_PROMPT':'0'}
def git(base,repo,*args):
 p=subprocess.run(['git',*args],cwd=repo,env=env(base),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with open(Path(base)/'commands.jsonl','a') as f:f.write(js({'cwd':str(repo),'args':list(args),'code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})+'\n')
 return p

def value(base,repo,*args):
 p=git(base,repo,*args)
 if p.returncode:raise ValueError('GIT_QUERY_FAILED:'+p.stderr.decode(errors='replace'))
 return p.stdout.decode().strip()
def row(c,op):
 r=c.execute('select * from m14_worktree_intent where id=?',(op,)).fetchone();assert r;return dict(r)
@contextlib.contextmanager
def lock(base):
 # One fixture repository per base. Production lock key is the recorded common-dir identity.
 with open(Path(base)/'repository.lock','a') as f:
  fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def observe(base,r):
 repo=Path(r['repo']);path=Path(r['path'])
 common=value(base,repo,'rev-parse','--path-format=absolute','--git-common-dir')
 if identity(common)!=r['common_identity'] or identity(path.parent)!=r['parent_identity']:raise ValueError('SOURCE_IDENTITY_CHANGED')
 records=[]
 for part in git(base,repo,'worktree','list','--porcelain','-z').stdout.split(b'\0\0'):
  fields={}
  for line in part.split(b'\0'):
   k,_,v=line.partition(b' ')
   if k:fields[k.decode()]=v.decode()
  if fields.get('worktree')==str(path):records.append(fields)
 if not path.exists() or len(records)!=1:raise ValueError('MISSING_OR_UNREGISTERED')
 if records[0].get('branch')!='refs/heads/'+r['branch']:raise ValueError('BRANCH_IDENTITY_CHANGED')
 if identity(value(base,path,'rev-parse','--path-format=absolute','--git-common-dir'))!=r['common_identity']:raise ValueError('FOREIGN_REPOSITORY')
 admin=value(base,path,'rev-parse','--absolute-git-dir')
 if Path(admin,'gitdir').read_text().strip()!=str(path/'.git'):raise ValueError('BACKLINK_CHANGED')
 status=git(base,path,'-c','status.showUntrackedFiles=all','status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching','--ignore-submodules=none')
 if status.returncode:raise ValueError('STATUS_UNKNOWN')
 return {'identity':identity(path),'adminIdentity':identity(admin),'head':value(base,path,'rev-parse','HEAD'),'branch':records[0]['branch'],'statusHex':status.stdout.hex(),'gitLocked':'locked' in records[0]}

def reserve(base,c,repo,task):
 with lock(base):
  state=c.execute('select * from m14_task_state where task_id=?',(task,)).fetchone();assert state['record_state']=='active'
  op=uuid.uuid4().hex;bid='git-candidate-'+op;branch='probe/'+op;parent=Path(base)/'worktrees';parent.mkdir(exist_ok=True);path=parent/op
  common=value(base,repo,'rev-parse','--path-format=absolute','--git-common-dir');head=value(base,repo,'rev-parse','HEAD')
  with c:
   c.execute("INSERT INTO m14_binding(binding_id,task_id,runner,cwd,entry_mode,phase) VALUES(?,?,? ,?,'programmatic','planned')",(bid,task,'claude-code',str(repo)))
   c.execute("INSERT INTO m14_worktree_intent(id,task_id,proposed_binding,expected_selection,repo,common_identity,parent_identity,base_commit,branch,path,phase) VALUES(?,?,?,?,?,?,?,?,?,?,'reserved')",(op,task,bid,state['selection_revision'],str(repo),identity(common),identity(parent),head,branch,str(path)))
 return op

def execute(base,c,op,cut):
 with lock(base):
  r=row(c,op);assert r['phase']=='reserved';assert not Path(r['path']).exists()
  # State precedes filesystem mutation. The real child is synchronously waited in this fixture.
  with c:c.execute("update m14_worktree_intent set phase='executing' where id=?",(op,))
  p=git(base,r['repo'],'worktree','add','-b',r['branch'],'--',r['path'],r['base_commit'])
  if cut=='after-command':os._exit(73)
  try:o=observe(base,r);reason=None
  except ValueError as e:o=None;reason=str(e)
  phase='ready' if p.returncode==0 and o and not o['statusHex'] and o['head']==r['base_commit'] else 'retained'
  with c:c.execute('update m14_worktree_intent set phase=?,observation_json=?,git_exit=?,reason=? where id=?',(phase,js(o),p.returncode,reason or ('PREPARE_FAILED_OR_OUTPUT' if phase=='retained' else None),op))
  if cut=='before-binding':os._exit(74)
  return reconcile(base,c,op,locked=True)

def reconcile(base,c,op,locked=False,fail_commit=False):
 if not locked:
  with lock(base):return reconcile(base,c,op,True,fail_commit)
 r=row(c,op)
 try:o=observe(base,r)
 except (ValueError,OSError) as e:
  with c:c.execute("update m14_worktree_intent set phase='retained',reason=? where id=?",(str(e),op))
  return {'result':'retained','reason':str(e)}
 link=c.execute('select * from m14_worktree_binding where binding_id=?',(r['proposed_binding'],)).fetchone()
 if link:
  if link['intent_id']!=op or r['phase']!='bound':raise ValueError('BINDING_DISAGREEMENT')
  return {'result':'bound','idempotent':True,'observation':o}
 if r['phase']!='ready' or r['git_exit']!=0 or not r['observation_json'] or js(o)!=r['observation_json']:
  with c:c.execute("update m14_worktree_intent set phase='retained',reason='UNPROVEN_OR_CHANGED' where id=?",(op,))
  return {'result':'retained','reason':'UNPROVEN_OR_CHANGED','observation':o}
 try:
  c.execute('BEGIN IMMEDIATE')
  state=c.execute('select * from m14_task_state where task_id=?',(r['task_id'],)).fetchone()
  binding=c.execute('select * from m14_binding where binding_id=?',(r['proposed_binding'],)).fetchone()
  if state['record_state']!='active' or state['selection_revision']!=r['expected_selection']:raise ValueError('TASK_CHANGED')
  if binding['phase']!='planned' or binding['native_id'] is not None:raise ValueError('BINDING_ALREADY_PREPARED')
  c.execute('update m14_binding set cwd=? where binding_id=?',(r['path'],r['proposed_binding']))
  c.execute('insert into m14_worktree_binding values(?,?,?)',(r['proposed_binding'],r['task_id'],op))
  c.execute("update m14_worktree_intent set phase='bound' where id=?",(op,))
  if fail_commit:raise ValueError('INJECTED_BEFORE_COMMIT')
  c.commit()
 except Exception:
  c.rollback();raise
 return {'result':'bound','idempotent':False,'nativeRunnable':False,'currentPointerUnchanged':True}

def retention(base,c,op):
 with lock(base):
  r=row(c,op);reasons=[]
  links=c.execute('select binding_id from m14_worktree_binding where intent_id=?',(op,)).fetchall()
  if links:reasons.append('BINDING_HISTORY')
  try:
   o=observe(base,r)
   if o['statusHex']:reasons.append('TRACKED_UNTRACKED_OR_IGNORED_OUTPUT')
   if o['head']!=r['base_commit']:reasons.append('COMMITTED_OUTCOME')
   if o['gitLocked']:reasons.append('GIT_LOCKED')
   if r['observation_json'] and o['identity']!=json.loads(r['observation_json'])['identity']:reasons.append('PATH_REPLACED')
  except (ValueError,OSError) as e:reasons.append(str(e))
  if r['phase']!='ready' or r['git_exit']!=0:reasons.append('UNCONFIRMED_PREPARATION')
  # A recovery query is never an authorization to physically delete a worktree.
  return {'classification':'retain' if reasons else 'owned-unused-candidate','reasons':reasons,'automaticRemovalAllowed':False,'explicitReviewRequired':True}

if __name__=='__main__':
 base=Path(sys.argv[2]);c=connect(base/'state.sqlite');op=sys.argv[3];action=sys.argv[1]
 if action=='execute':result=execute(base,c,op,sys.argv[4])
 elif action=='recover':result=reconcile(base,c,op)
 elif action=='retention':result=retention(base,c,op)
 else:raise ValueError(action)
 c.close();print(js(result))
