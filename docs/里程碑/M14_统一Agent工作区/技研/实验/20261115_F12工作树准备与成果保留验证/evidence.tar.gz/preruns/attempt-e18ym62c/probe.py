from pathlib import Path
import json,sys,os,sqlite3,subprocess,tempfile,shutil,traceback,hashlib
import candidate as a
root=Path(__file__).resolve().parent;out=Path(tempfile.mkdtemp(prefix='attempt-',dir=root));checks=[]
seed=Path('/private/tmp/willyou-m14-f10-retention/attempt-Vuqpo0/baseline/state.sqlite')
def check(name,fn):
 try:checks.append({'id':name,'passed':True,'result':fn()})
 except Exception:checks.append({'id':name,'passed':False,'error':traceback.format_exc()});raise
 finally:(out/'progress.json').write_text(json.dumps(checks,indent=2))
def fixture(name):
 base=out/name;base.mkdir();source=sqlite3.connect('file:'+str(seed)+'?mode=ro',uri=True);target=sqlite3.connect(base/'state.sqlite');source.backup(target);target.close();source.close();c=a.connect(base/'state.sqlite');a.install(c)
 repo=base/'repo';repo.mkdir();a.value(base,repo,'init','-b','main');a.value(base,repo,'config','user.name','Synthetic F12');a.value(base,repo,'config','user.email','fixture@example.invalid');(repo/'tracked.txt').write_text('base\n');(repo/'.gitignore').write_text('ignored/\n');a.value(base,repo,'add','.');a.value(base,repo,'commit','-m','fixture baseline')
 task=c.execute('select task_id from m14_task_state limit 1').fetchone()[0];before=dict(c.execute('select * from m14_task_state where task_id=?',(task,)).fetchone());op=a.reserve(base,c,repo,task)
 return base,c,repo,op,before

def child(base,action,op,cut=None,expected=0):
 args=[sys.executable,str(root/'candidate.py'),action,str(base),op]+([cut] if cut else [])
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with open(base/'children.jsonl','a') as f:f.write(a.js({'args':args,'code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})+'\n')
 assert p.returncode==expected,(p.returncode,p.stderr.decode());return json.loads(p.stdout) if p.stdout else None

def pointer(c,before):assert dict(c.execute('select * from m14_task_state where task_id=?',(before['task_id'],)).fetchone())==before

def first():
 base,c,repo,op,before=fixture('success-crash');child(base,'execute',op,'before-binding',74);r=a.row(c,op);assert r['phase']=='ready' and r['git_exit']==0;assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;pointer(c,before)
 got=child(base,'recover',op);assert got['result']=='bound' and not got['nativeRunnable'];again=child(base,'recover',op);assert again['idempotent'];assert c.execute('select phase,cwd from m14_binding where binding_id=?',(r['proposed_binding'],)).fetchone()[:]==('planned',r['path']);pointer(c,before)
 retained=child(base,'retention',op);assert 'BINDING_HISTORY' in retained['reasons'];assert not retained['automaticRemovalAllowed'];c.close();return {'exitAtDurableReady':74,'restartBindsExactlyOnce':True,'plannedNotRunnable':True,'oldTaskSelectionUnchanged':True,'bindingHistoryRetains':True}

def second():
 rows=[]
 for cut,code in [('before-binding',74),('after-command',73)]:
  base,c,repo,op,before=fixture('failed-hook-'+cut);hook=repo/'.git/hooks/post-checkout';hook.write_text('#!/bin/sh\nmkdir -p ignored\nprintf "ignored-result" > ignored/result.bin\nprintf "user-result" > user-result.txt\nexit 19\n');hook.chmod(0o700)
  child(base,'execute',op,cut,code);r=a.row(c,op);path=Path(r['path']);saved={str(p.relative_to(path)):a.digest(p.read_bytes()) for p in [path/'ignored/result.bin',path/'user-result.txt']}
  got=child(base,'recover',op);assert got['result']=='retained';assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;pointer(c,before)
  p=child(base,'retention',op);assert 'TRACKED_UNTRACKED_OR_IGNORED_OUTPUT' in p['reasons'] and not p['automaticRemovalAllowed']
  assert saved=={name:a.digest((path/name).read_bytes()) for name in saved};assert path.exists();commands=[json.loads(l) for l in (base/'commands.jsonl').read_text().splitlines()];creates=[x for x in commands if x['args'][:2]==['worktree','add']];assert len(creates)==1 and creates[0]['code']==19
  rows.append({'window':cut,'nativeGitExit':19,'outputsPreserved':saved,'registered':True,'noBinding':True});c.close()
 return rows

def third():
 base,c,repo,op,before=fixture('unknown-success');child(base,'execute',op,'after-command',73);assert a.row(c,op)['phase']=='executing';got=child(base,'recover',op);assert got['result']=='retained';assert a.row(c,op)['git_exit'] is None;assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;pointer(c,before);c.close();return {'actualGitSuccessWithoutDurableReceiptNotReady':True,'noRerunOrAutomaticRemoval':True}

def fourth():
 base,c,repo,op,before=fixture('atomic-bind');child(base,'execute',op,'before-binding',74);r=a.row(c,op);binding=dict(c.execute('select * from m14_binding where binding_id=?',(r['proposed_binding'],)).fetchone())
 # SQLite rejects COMMIT itself through a deferred constraint after all three binding writes.
 c.execute('CREATE TEMP TABLE commit_fault(x INTEGER PRIMARY KEY,y INTEGER REFERENCES commit_fault(x) DEFERRABLE INITIALLY DEFERRED)');c.execute('INSERT INTO commit_fault VALUES(1,1)');c.commit()
 class CommitFault:
  def __getattr__(self,k):return getattr(c,k)
  def commit(self):c.execute('INSERT INTO commit_fault VALUES(2,999)');c.commit()
 try:a.reconcile(base,CommitFault(),op)
 except sqlite3.IntegrityError:pass
 else:raise AssertionError('commit should fail')
 assert a.row(c,op)==r;assert dict(c.execute('select * from m14_binding where binding_id=?',(r['proposed_binding'],)).fetchone())==binding;assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;pointer(c,before)
 with c:c.execute('update m14_task_state set selection_revision=selection_revision+1 where task_id=?',(r['task_id'],))
 try:a.reconcile(base,c,op)
 except ValueError as e:assert str(e)=='TASK_CHANGED'
 else:raise AssertionError('stale task accepted')
 assert a.row(c,op)==r;assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;c.close();return {'realSqliteCommitConstraintFailed':True,'cwdLinkAndIntentAllRolledBack':True,'staleSelectionRefused':True,'worktreeRetained':True}

def fifth():
 outcomes=[]
 for kind in ['ignored','untracked','committed','replaced']:
  base,c,repo,op,before=fixture('outcome-'+kind);child(base,'execute',op,'before-binding',74);r=a.row(c,op);path=Path(r['path']);original=None
  if kind=='ignored':(path/'ignored').mkdir();target=path/'ignored/result';target.write_bytes(b'keep ignored')
  elif kind=='untracked':target=path/'untracked';target.write_bytes(b'keep untracked')
  elif kind=='committed':target=path/'tracked.txt';target.write_bytes(b'new commit');a.value(base,path,'add','.');a.value(base,path,'commit','-m','retained outcome')
  else:
   original=path.with_name(path.name+'-original');path.rename(original);path.mkdir();target=path/'replacement-user-data';target.write_bytes(b'new unrelated directory')
  h=a.digest(target.read_bytes());got=child(base,'recover',op);assert got['result']=='retained';assert not child(base,'retention',op)['automaticRemovalAllowed'];assert a.digest(target.read_bytes())==h;assert not original or original.exists();pointer(c,before);assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0;c.close();outcomes.append(kind)
 return {'preserved':outcomes,'changedReadyDoesNotBind':True}

def sixth():
 base,c,repo,op,before=fixture('owner-lock');child(base,'execute',op,'before-binding',74)
 with a.lock(base):
  p=subprocess.run([sys.executable,str(root/'candidate.py'),'recover',str(base),op],capture_output=True);assert p.returncode!=0 and b'BlockingIOError' in p.stderr
  assert a.row(c,op)['phase']=='ready';assert c.execute('select count(*) from m14_worktree_binding').fetchone()[0]==0
 assert child(base,'retention',op)['classification']=='owned-unused-candidate';assert child(base,'recover',op)['result']=='bound';c.close();return {'liveHeldLockBlocksOtherProcess':True,'releasedLockAllowsRecovery':True,'pristineOwnedUnusedDistinguished':True,'deathNotInferredFromElapsedTime':True}

def seventh():
 base,c,repo,op,before=fixture('history-retention');child(base,'execute',op,'before-binding',74);child(base,'recover',op);r=a.row(c,op)
 with c:c.execute("update m14_task_state set record_state='retained' where task_id=?",(r['task_id'],))
 try:
  with c:c.execute('delete from m14_binding where binding_id=?',(r['proposed_binding'],))
 except sqlite3.IntegrityError:pass
 else:raise AssertionError('linked binding deleted')
 assert 'BINDING_HISTORY' in child(base,'retention',op)['reasons'];assert Path(r['path']).exists();c.close();return {'taskRetainedDoesNotDeleteWorktree':True,'foreignKeyProtectsHistoricalBinding':True,'noImplicitBranchRemoval':True}
error=None
try:
 for name,fn in [('G01-success-before-bind-restart',first),('G02-failing-hook-known-and-unknown',second),('G03-success-without-receipt',third),('G04-commit-failure-and-stale-selection',fourth),('G05-output-and-path-replacement',fifth),('G06-live-lock-and-owned-unused',sixth),('G07-history-retention',seventh)]:check(name,fn)
 for p in out.glob('*/state.sqlite'):
  c=a.connect(p);assert not list(c.execute('pragma foreign_key_check'));assert c.execute('pragma integrity_check').fetchone()[0]=='ok';c.close()
 commands=[json.loads(l) for p in out.glob('*/commands.jsonl') for l in p.read_text().splitlines()]
 assert not any(x['args'][:2]==['worktree','remove'] or '--force' in x['args'] or '-D' in x['args'] for x in commands)
except Exception:error=traceback.format_exc()
result={'out':str(out),'passed':sum(x['passed'] for x in checks),'checks':checks,'error':error,'seed':str(seed),'seedSha256':a.digest(seed.read_bytes()),'scope':'Real local Git, SQLite C1.6 copy plus C1.7 research candidate, distinct child process exits/restarts. No SDK, product code or UI; synchronous synthetic hook only. Retention classifies, does not implement user-authorized physical removal or all external writer exclusion.'}
(out/'result.json').write_text(json.dumps(result,indent=2));(root/'latest.json').write_text(json.dumps(result,indent=2));shutil.copy2(root/'probe.py',out/'probe.py');shutil.copy2(root/'candidate.py',out/'candidate.py');print(a.js({'out':str(out),'passed':result['passed'],'error':error}));sys.exit(1 if error else 0)
