from pathlib import Path
import json,hashlib,tarfile,subprocess,re,shutil
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_原生身份占用投影与绑定原子迁移验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes()) if old.exists() else None,'after':sha(data)})
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['error'] is None
b=json.loads((root/'build.json').read_text())
for e in b['sources']+b['outputs']:assert sha(Path(e['path']).read_bytes())==e['sha256'],e['path']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'build':b,'boundary':r['scope'],'candidateTables':['m14_native_claim','m14_native_claim_source'],'transactionBoundary':'installClaims runs in existing temporary migrate before-drop checkpoint while its SQL transaction is active. updateCopiedBinding runs in actual adoptLibrary synchronous commit callback; callback failure rolls back actual and candidate tables. Neither is a product migration.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
files=[root/n for n in ['probe.mjs','claims.mjs','migration.mjs','candidate.sql','build.mjs','build.json','actual.cjs','source-review.json','prepare.py']]+[p for p in Path(r['out']).iterdir() if p.is_file()]
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in files:tf.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())} for p in files]}
for name,obj in [('result.json',r),('source-review.json',review),('archive-manifest.json',m)]:put(exp/name,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 原生身份占用投影与绑定原子迁移验证

日期：2026-11-14。关联 D01、Q13／Q49。实际 SmartDD 会话注册器和历史复制、合法 v3 内容、原生身份表及当前 SQLite；M14 关系表、占用投影和回调为临时候选。

## 六项证据

| 检查 | 结果 |
| --- | --- |
| P01 投影构建失败 | 在旧候选迁移事务内建立占用投影后注入异常；候选表全部回滚，旧表内容保持 |
| P02 成功迁移 | 当前根和原根映射同一 binding，并以外键保存旧快照来源；不同 selection 的保留历史也继续占用原身份 |
| P03 新绑定冲突 | 当前根、原根、原根别名各以同 task 和另一 task 认领，六种均拒绝；新 binding 插入整体回滚 |
| P04 旧入口约束 | 合成新 binding 切根后保留前根占用；实际 sessions.create 及实际 bindNativeSession 对前根的冲突均由新投影守卫拒绝，不留下半条快照或绑定 |
| P05 来源保留 | 删除被身份占用引用的旧 snapshot version 被外键拒绝 |
| P06 复制与新表原子更新 | 在实际 adoptLibrary 的同一提交回调更新 binding 根、claim、source、revision 和 current pointer；注入异常时与旧快照／身份整体回滚，重试成功后三个历史根仍属同一 binding |

六项通过，终态 SQLite 完整性与外键检查通过。P04 的新 binding 切根是合成合法 SQL 操作，未通过真实 Provider；P06 使用真实复制／注册器，但没有真实 TaskService 指针或完整业务 run。没有产品代码修改、Agent 启动或 SVN 代码复制。

## 候选数据约束

claim 主键为 runner／canonical identity_root／非空 native_id，owner 使用 binding_id／task_id／runner 复合外键；按 binding 建索引。来源关联指向原 snapshot_hash，迁移前验证旧内容 Schema、摘要和所属任务，再保存来源外键。空原生 ID 不产生虚构占用；新身份领取在规范化路径后与 binding 插入同事务完成。

旧身份 INSERT／UPDATE 同时查询该投影；历史占用不会因为 binding 当前根更新而删除，同逻辑任务的另一 binding 也不能重复认领。来源仍被引用时不允许普通清理删除；正式释放和恢复冲突应有独立流程，不能通过删约束或忽略来源解决。

本轮只证明合法历史的投影与同步事务联合。未知／hold／损坏来源、既有别名重定向、全部首次身份写入口、投影跨进程恢复、正式资源 GC、TaskService、运行准入及恢复 claim 尚未接为同一服务。新 Provider 首次身份的真实性仍须由原生回调证据合同提供，插入 claim 本身不证明 native 会话可恢复。

## 复现

固定依赖具备时执行 `node build.mjs`、`node probe.mjs`。候选 projection 在旧研究 migrate 的 before-drop 钩子中加入，其事务同时包含关系表、保留来源、占用和迁移回执。源代码与 379 条构建输入摘要、实际产物、失败注入断言及终态数据库均归档。

[结果](result.json) · [来源](source-review.json) · [归档摘要](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
tech_rel=base/'技研/技术方案.md';t=(repo/tech_rel).read_text()
row='| 资源及原生名称 | ref 同时属于精确 session／revision／task，核资源 ID、kind、hash、位置与闭包；MCP 名称和 native claim 的旧 INSERT、首次绑定 UPDATE 及新入口都受统一冲突检查 |'
new=row+'''\n| 原生身份占用 | 非空 native ID 按 driver／canonical root 唯一归属精确 binding／task；同 binding 可保留多个历史根，变更当前根不释放旧根。另一 binding 即便 task 相同也不能重占；新旧入口共用投影并规范化路径，不能只查 binding 当前根 |
| 身份占用来源 | 历史 claim 关联经过 Schema／摘要／任务核验的原 snapshot revision，必要来源受外键／保留规则保护；新建 claim 的原生证据按 §3.2.9 保存。来源损坏／歧义保持待核查，不凭 JSON 存在授予占用或执行权限 |'''
assert row in t;t=t.replace(row,new,1)
anchor='迁移先进入已有启动排他／维护协议，核真实 owner 与进程范围；'
para='''[原生身份占用投影实验](实验/20261114_原生身份占用投影与绑定原子迁移验证/README.md)已验证合法历史在迁移事务中建立索引化 claim／source 关联：投影失败和关系表整体回滚；旧根、当前根及别名归同一绑定；实际旧 create／首次 bind 仍受约束；来源删除被拒绝。实际 adoptLibrary 的同步提交回调进一步将旧快照／身份、binding 当前根、历史 claim、revision 和 current pointer 一起回滚或提交。候选表名为验证载体；正式迁移须把同一合同纳入版本水位、运行准入与现有恢复／资源服务，不能只复制 SQL 后开放新入口。未知／hold／损坏历史、全部写入口与正式 GC／跨进程恢复仍待联合。

'''
assert anchor in t;t=t.replace(anchor,para+anchor,1)
old='实验修正依赖保留旧版本、在同步事务中扫描并拒绝，最终实现需建立可核验的持久占用投影并同步新旧写入口，避免每次认领遍历全部历史；历史清理不能顺带释放仍需保留的身份。正式 Schema、跨进程交接和释放规则仍待联合验证。'
new='前轮扫描旧版本的修正已由 §3.2.2 的持久占用／来源投影候选进一步验证，包括实际旧创建／首次绑定和复制提交回调；正式实现沿索引查询并同步新旧写入口，避免每次认领遍历全部历史。历史清理不能顺带释放仍需保留的身份；全来源兼容、跨进程交接、运行准入和释放规则仍待联合验证。'
assert old in t;t=t.replace(old,new,1);put(tech_rel,t)
ledger_rel=base/'技研/全局设计验证账.md';t=(repo/ledger_rel).read_text();assert '### 4.92 ' not in t
add='''### 4.92 原生身份占用投影与绑定原子更新

[六项检查](实验/20261114_原生身份占用投影与绑定原子迁移验证/README.md)将历史 claim／source 投影加入同一候选迁移事务，验证异常整体回滚、当前／旧根占用、同 task 不同 binding 与别名冲突、实际旧 create／首次 bind 拒绝、来源删除约束。实际 adoptLibrary 同步回调连接 binding 根、claim、revision、current pointer 与原快照，失败整体回滚，重试后三个根仍属一 binding。

合法历史及当前组件局部联合通过；新 binding 切根为合成操作，未启动 Provider，没有真实 TaskService、未知／hold／损坏来源迁移或跨进程投影恢复。SQLite 完整性／外键通过。技术方案 §3.2.2 明确表关系与来源合同，§11.2 改为引用该投影；Q13／49 保持部分，不能将其称为最终产品迁移已通过。

'''
t=t.replace('## 5. 失败与驱动修正',add+'## 5. 失败与驱动修正',1).replace('截至 §4.91，56 个宽口径问题项中','截至 §4.92，56 个宽口径问题项中')
old='下一步是最终占用投影／多 binding 原子提交、复制中途、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
new='§4.92 又补合法历史占用投影／来源、旧写入口和实际复制回调中 binding／revision 同事务提交；剩余为未知／hold 来源、全部写入口／正式资源与恢复联合、复制中途、合法历史续写和旧根回退／释放，不能把进程内收据持久化后继续授权。'
assert old in t;t=t.replace(old,new,1);put(ledger_rel,t)
index_rel=base/'README.md';t=(repo/index_rel).read_text()
t=re.sub(r'^最新进展：.*$', '最新进展：历史身份占用／来源投影已与迁移事务及实际复制提交回调联合验证，新旧入口冲突和来源保留约束已写入方案。见[投影与原子迁移实验](技研/实验/20261114_原生身份占用投影与绑定原子迁移验证/README.md)；数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t,flags=re.M)
t=re.sub(r'^下一步：.*$', '下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)核对迁移未知／保留来源及全部写入口与恢复／资源的共同约束；委派问题账、完整运行／业务与历史续写等未决项继续保留。',t,flags=re.M);put(index_rel,t)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n');shutil.copyfile('/private/tmp/willyou-m14-history-recovery-claim-probe/publish.py',root/'publish.py');print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'checks':r['passed']}))
