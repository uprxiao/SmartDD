import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,writeFileSync,copyFileSync,mkdirSync,symlinkSync,existsSync} from 'node:fs';
import {join,dirname} from 'node:path';
import actual from './actual.cjs';
import {migrate} from './migration.mjs';
import {installClaims,claimNew,putClaim,updateCopiedBinding} from './claims.mjs';
const root=import.meta.dirname,out=mkdtempSync(join(root,'attempt-')),save=(n,v)=>writeFileSync(join(out,n),JSON.stringify(v,null,2));
for(const n of ['build.mjs','build.json','probe.mjs','claims.mjs','migration.mjs','candidate.sql'])copyFileSync(join(root,n),join(out,n));
const checks=[];let f,problem;
const check=async(id,title,fn)=>{try{checks.push({id,title,status:'passed',evidence:await fn()});}catch(e){checks.push({id,title,status:'failed',error:e.stack});throw e;}};
const snapshot=()=>Object.fromEntries(f.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND (name LIKE 'm14_%' OR name LIKE 'capability_session_%' OR name='capability_snapshot_versions') ORDER BY name").all().map(({name})=>[name,f.sqlite.prepare('SELECT * FROM '+name+' ORDER BY 1').all()]));
try{
 f=await actual.runFixture();const db=f.sqlite;
 let current=await f.sessions.adoptLibrary(f.snapshot.taskId,f.session.pointer.snapshotHash,{...f.snapshot,schema:3});const nativeId=randomUUID();current=await f.sessions.bindNativeSession(f.snapshot.taskId,current.pointer.snapshotHash,{runner:current.snapshot.runner,...current.snapshot.native,sessionId:nativeId});
 const from=current.snapshot.native.stateRoot,to=join(f.root,'history-b'),cwd=current.snapshot.native.cwd,taskId=current.snapshot.taskId;
 const file=join(from,'projects',actual.encodeClaudeDir(cwd),nativeId+'.jsonl');mkdirSync(dirname(file),{recursive:true});mkdirSync(to);writeFileSync(file,'{"type":"user","message":"SYNTHETIC_CLAIM_HISTORY"}\n');
 const copied=actual.copyClaudeSession({from,to,cwd,sessionId:nativeId,nativeTarget:false});current=await f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,{...current.snapshot,native:{...current.snapshot.native,stateRoot:to}},{copy:copied,home:f.home,commit:()=>{assert(db.inTransaction);}});
 const alias=join(f.root,'old-alias');symlinkSync(from,alias);let binding;
 await check('P01','claim projection shares migration rollback transaction',async()=>{
  const before=snapshot();await assert.rejects(migrate(db,async point=>{if(point==='before-drop'){installClaims(db);throw Error('INJECTED_PROJECTION_FAILURE');}}),/INJECTED_PROJECTION_FAILURE/);assert.deepEqual(snapshot(),before);assert.equal(db.prepare("SELECT count(*) n FROM sqlite_master WHERE name LIKE 'm14_%'").get().n,0);return{allCandidateTablesRolledBack:true,legacyDataPreserved:true};
 });
 await check('P02','successful migration retains current and former roots with provenance',async()=>{
  await migrate(db,async point=>{if(point==='before-drop')installClaims(db);});binding=db.prepare('SELECT * FROM m14_binding WHERE task_id=?').get(taskId);
  const claims=db.prepare('SELECT * FROM m14_native_claim ORDER BY identity_root').all();assert.equal(claims.length,2);assert.deepEqual(new Set(claims.map(c=>c.identity_root)),new Set([from,to]));assert(claims.every(c=>c.binding_id===binding.binding_id));assert(db.prepare('SELECT count(*) n FROM m14_native_claim_source').get().n>=2);save('after-migration.json',snapshot());return{roots:claims.map(c=>c.identity_root),oneOwner:true,sourceForeignKeys:true};
 });
 await check('P03','new binding cannot claim current/former root or alias, even for same task',async()=>{
  const before=snapshot();for(const identityRoot of [from,to,alias])for(const owner of [taskId,randomUUID()])assert.throws(()=>claimNew(db,{taskId:owner,runner:current.snapshot.runner,identityRoot,nativeId,cwd}),/NATIVE_CLAIM_CONFLICT|native identity already owned|UNIQUE constraint/);assert.deepEqual(snapshot(),before);return{sixConflictsRejected:true,newBindingRolledBack:true};
 });
 let freshId,freshRoot;
 await check('P04','retained new-binding root blocks actual legacy create and first bind',async()=>{
  freshId=randomUUID();freshRoot=join(f.root,'fresh-a');const newer=join(f.root,'fresh-b');mkdirSync(freshRoot);mkdirSync(newer);const freshBinding=claimNew(db,{taskId:randomUUID(),runner:current.snapshot.runner,identityRoot:freshRoot,nativeId:freshId,cwd});
  db.transaction(()=>{putClaim(db,freshBinding,newer,freshId);db.prepare('UPDATE m14_binding SET identity_root=? WHERE binding_id=?').run(newer,freshBinding);}).immediate();
  const attempted={...current.snapshot,taskId:randomUUID(),native:{...current.snapshot.native,stateRoot:freshRoot,sessionId:freshId}},before=snapshot();await assert.rejects(f.sessions.create(attempted,f.home),/M14_NATIVE_CLAIM_CONFLICT/);assert.deepEqual(snapshot(),before);
  const unbound=await f.sessions.create({...attempted,taskId:randomUUID(),native:{...attempted.native,sessionId:null}},f.home);const beforeBind=snapshot();await assert.rejects(f.sessions.bindNativeSession(unbound.snapshot.taskId,unbound.pointer.snapshotHash,{runner:attempted.runner,...attempted.native}),/M14_NATIVE_CLAIM_CONFLICT/);assert.deepEqual(snapshot(),beforeBind);return{legacyInsertRejected:true,legacyFirstBindRejected:true,syntheticNewBindingRootChange:true};
 });
 await check('P05','retained claim source cannot be deleted independently',async()=>{
  const source=db.prepare('SELECT snapshot_hash FROM m14_native_claim_source LIMIT 1').get(),before=snapshot();assert.throws(()=>db.prepare('DELETE FROM capability_snapshot_versions WHERE snapshot_hash=?').run(source.snapshot_hash),/FOREIGN KEY constraint/);assert.deepEqual(snapshot(),before);return{sourceDeleteRestricted:true};
 });
 await check('P06','actual copy adoption and binding/revision/claim changes roll back and commit together',async()=>{
  const third=join(f.root,'history-c');mkdirSync(third);const receipt=actual.copyClaudeSession({from:to,to:third,cwd,sessionId:nativeId,nativeTarget:false}),next={...current.snapshot,native:{...current.snapshot.native,stateRoot:third}},before=snapshot();
  await assert.rejects(f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,{copy:receipt,home:f.home,commit:(_old,after)=>{updateCopiedBinding(db,binding.binding_id,after);throw Error('INJECTED_BINDING_COMMIT_FAILURE');}}),/INJECTED_BINDING_COMMIT_FAILURE/);assert.deepEqual(snapshot(),before);assert(existsSync(join(third,'projects',actual.encodeClaudeDir(cwd),nativeId+'.jsonl')));
  const moved=await f.sessions.adoptLibrary(taskId,current.pointer.snapshotHash,next,{copy:receipt,home:f.home,commit:(_old,after)=>updateCopiedBinding(db,binding.binding_id,after)});const b=db.prepare('SELECT * FROM m14_binding WHERE binding_id=?').get(binding.binding_id),cap=db.prepare('SELECT * FROM m14_cap WHERE binding_id=?').get(binding.binding_id);assert.equal(b.identity_root,third);assert.equal(cap.current_hash,moved.pointer.snapshotHash);assert.equal(db.prepare('SELECT count(*) n FROM m14_native_claim WHERE binding_id=?').get(binding.binding_id).n,3);return{rollbackIncludesBindingClaimsAndRevisions:true,currentPointerMatchesActualSnapshot:true,threeRootsOneBinding:true};
 });
}catch(e){problem=e.stack;process.exitCode=1;}
finally{if(f){save('final-state.json',snapshot());assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.equal(f.sqlite.pragma('integrity_check',{simple:true}),'ok');await f.sqlite.backup(join(out,'final.sqlite'));save('fixture.json',{root:f.root});f.sqlite.close();}}
const result={out,checks,passed:checks.filter(c=>c.status==='passed').length,error:problem??null,scope:'Actual copy/session registry and schema plus isolated M14 claim projection, migration hook and synchronous adoption callback. Synthetic new-binding root change, no real provider. No full TaskService, unknown/held/corrupt source migration, cross-process projection recovery, final resource/GC integration or product modification.'};save('result.json',result);writeFileSync(join(root,'latest.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
