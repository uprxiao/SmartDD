import os,json,hashlib,sqlite3,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VERSION='history-map-v1'
MAX_SOURCE=16*1024*1024;MAX_PARSE_LINE=1024*1024
FORMATS={'claude-transcript-2.1.321','codex-rollout-0.167.1','claude-stream-sdk-0.3.321','codex-rpc-0.167.1','host-request-v1'}
def js(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'),sort_keys=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def connect(p):
 c=sqlite3.connect(p);c.row_factory=sqlite3.Row;c.execute('pragma foreign_keys=on');return c
def schema_hash(c):
 return sha(json.dumps([dict(x) for x in c.execute('SELECT type,name,tbl_name,sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name')],ensure_ascii=False,separators=(',',':')).encode())
def install(c):
 r=c.execute('select * from m14_contract_baseline').fetchone();assert r['revision']=='C1.7' and r['schema_hash']==schema_hash(c)
 sql=(ROOT/'contract.sql').read_text();c.executescript('BEGIN IMMEDIATE;'+sql);c.execute('update m14_contract_baseline set revision=?,schema_hash=?,inputs_hash=?',('C1.8',schema_hash(c),sha(sql.encode())));c.commit()
def source(c,task,binding,driver,native,stream,fmt,identity):
 bound=c.execute('select runner,native_id from m14_binding where binding_id=? and task_id=?',(binding,task)).fetchone();assert bound,'UNKNOWN_BINDING'
 if driver in ['codex','claude']:assert bound['runner']==('claude-code' if driver=='claude' else 'codex') and bound['native_id']==native,'BINDING_NATIVE_IDENTITY_MISMATCH'
 key=sha(js([binding,driver,native,stream]).encode());row=(key,task,binding,driver,native,stream,fmt,js(identity))
 old=c.execute('select * from m14_history_source where source_id=?',(key,)).fetchone()
 if old:
  assert tuple(old[k] for k in ['source_id','task_id','binding_id','driver','native_id','stream','format','identity_json'])==row,'SOURCE_IDENTITY_CONFLICT'
 else:
  with c:c.execute("insert into m14_history_source values(?,?,?,?,?,?,?,?,'unobserved',NULL)",row)
 return key

def normalize(r,s):
 out={'mapperVersion':VERSION,'origin':'imported-history','authorizesLiveUser':False,'actionable':False,'resumeEligible':False,'category':'unknown','parts':[]}
 if not isinstance(r,dict):out['diagnostic']='NON_OBJECT';return out
 if s['format'] not in FORMATS:out['diagnostic']='UNSUPPORTED_FORMAT';return out
 if s['driver']=='claude':
  observed=r.get('sessionId',r.get('session_id'))
  if observed and observed!=s['native_id']:out['diagnostic']='FOREIGN_SESSION';return out
 t=r.get('type');p=r.get('payload') if isinstance(r.get('payload'),dict) else {};method=r.get('method');params=r.get('params') if isinstance(r.get('params'),dict) else {}
 def part(block):
  if not isinstance(block,dict):return {'kind':'unknown'}
  kind=block.get('type')
  if kind in ['text','input_text','output_text']:return {'kind':'text','text':block.get('text')}
  if kind=='tool_use':return {'kind':'tool-call','nativeCallId':block.get('id'),'name':block.get('name'),'arguments':block.get('input'),'outcome':'unknown'}
  if kind=='tool_result':return {'kind':'tool-result','nativeCallId':block.get('tool_use_id'),'content':block.get('content'),'observedError':block.get('is_error'),'outcome':'error' if block.get('is_error') is True else 'observed-result'}
  return {'kind':'unknown','nativeType':kind}
 if s['format']=='host-request-v1':
  if isinstance(r.get('scope'),dict) and 'requestId' in r and isinstance(r.get('raw'),dict):out.update(category='request-history',nativeRequestId=r['requestId'],recordedScope=r['scope'],request=r['raw'],outcome='historical-unresolved')
  return out
 if s['driver']=='claude':
  if t in ['assistant','user'] and isinstance(r.get('message'),dict):
   m=r['message'];contents=m.get('content');contents=[{'type':'text','text':contents}] if isinstance(contents,str) else contents
   if not isinstance(contents,list):out['diagnostic']='MALFORMED_CONTENT';return out
   out.update(category='message',role=m.get('role'),parts=[part(b) for b in contents],nativeParent=r.get('parentUuid'),childAgent=r.get('agentId'),parentToolUseId=r.get('parent_tool_use_id'))
   if out['parts'] and all(x['kind']=='tool-result' for x in out['parts']):out['category']='tool-result'
   elif out['parts'] and all(x['kind']=='tool-call' for x in out['parts']):out['category']='tool-call'
   if any(x['kind']=='unknown' for x in out['parts']):out['diagnostic']='UNSUPPORTED_CONTENT_PART'
   result=r.get('toolUseResult',r.get('tool_use_result'))
   if isinstance(result,dict) and result.get('agentId'):out['childLink']={'agentId':result['agentId'],'observedStatus':result.get('status'),'source':'native-result'}
  elif t=='system' and r.get('subtype') in ['task_started','task_updated','task_notification']:
   out.update(category='child-history',childId=r.get('task_id'),parentToolUseId=r.get('tool_use_id'),observedStatus=r.get('status'),nativeSubtype=r['subtype'],runId=r.get('run_id'))
  elif t in ['attachment','queue-operation','atis-latch','api-request-shape','api-request-blob','api-request','tools-used','last-prompt','cost-state','mode','command_lifecycle'] or t=='system' and r.get('subtype')=='init':
   out.update(category='metadata',nativeType=t)
  elif t=='result':out.update(category='turn-history',observedError=r.get('is_error'),nativeSubtype=r.get('subtype'))
  return out
 if s['format']=='codex-rollout-0.167.1':
  if t=='session_meta':
   if p.get('id',p.get('session_id'))!=s['native_id']:out['diagnostic']='FOREIGN_SESSION';return out
   out.update(category='lineage',nativeId=s['native_id'],parentThreadId=p.get('parent_thread_id'))
  elif t=='response_item':
   k=p.get('type')
   if k=='message':
    out.update(category='message',role=p.get('role'),parts=[part(x) for x in p.get('content',[])])
    if any(x['kind']=='unknown' for x in out['parts']):out['diagnostic']='UNSUPPORTED_CONTENT_PART'
   elif k in ['function_call','custom_tool_call']:out.update(category='tool-call',nativeCallId=p.get('call_id'),name=p.get('name'),arguments=p.get('arguments',p.get('input')),outcome='unknown')
   elif k in ['function_call_output','custom_tool_call_output']:out.update(category='tool-result',nativeCallId=p.get('call_id'),content=p.get('output'),outcome='observed-result')
   else:out['nativeType']=k
  elif t=='event_msg' and p.get('type')=='item_completed':out.update(category='native-mirror',nativeItemId=p.get('item',{}).get('id'),notAnotherMessage=True)
  elif t=='event_msg' and p.get('type') in ['task_started','task_complete']:out.update(category='turn-history',nativeSubtype=p['type'],nativeTurnId=p.get('turn_id'))
  elif t in ['turn_context','world_state','token_usage_record'] or t=='event_msg' and p.get('type') in ['token_count','thread_settings_applied']:out.update(category='metadata',nativeType=t,nativeSubtype=p.get('type'))
  return out
 if s['format']=='codex-rpc-0.167.1':
  if method in ['item/commandExecution/requestApproval','item/fileChange/requestApproval','item/tool/requestUserInput','mcpServer/elicitation/request'] and 'id' in r:out.update(category='request-history',nativeRequestId=r['id'],request=params,outcome='historical-unresolved')
  elif method=='serverRequest/resolved':out.update(category='request-resolution-history',request=params,outcome='resolved-not-an-approval-grant')
  elif method in ['item/started','item/completed']:
   item=params.get('item',{})
   if item.get('type')=='collabAgentToolCall':out.update(category='child-history',nativeItemId=item.get('id'),children=item.get('receiverThreadIds'),observedStatus=item.get('status'),agentsStates=item.get('agentsStates'))
   else:out.update(category='native-mirror',nativeItemId=item.get('id'),notAnotherMessage=True)
  elif method in ['turn/started','turn/completed']:out.update(category='turn-history',nativeMethod=method)
  elif method in ['remoteControl/status/changed','thread/started','mcpServer/startupStatus/updated','warning','thread/status/changed','thread/tokenUsage/updated','account/rateLimits/updated','thread/readState/changed','item/agentMessage/delta'] or 'result' in r:out.update(category='metadata',nativeMethod=method)
  else:out.update(category='unknown',nativeMethod=method)
 return out

def record_key(r,offset):
 if isinstance(r,dict):
  if isinstance(r.get('uuid'),str):return 'uuid:'+r['uuid']
  if isinstance(r.get('ordinal'),int) and not isinstance(r['ordinal'],bool):return 'ordinal:'+str(r['ordinal'])
  if r.get('method') and 'id' in r:return 'rpc:'+js([r['method'],r['id']])
  if 'requestId' in r and 'scope' in r:return 'host-request:'+js([r['scope'],r['requestId']])
 return 'offset:'+str(offset)

def read_source(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd)
  if not stat.S_ISREG(before.st_mode):raise ValueError('SOURCE_NOT_REGULAR_FILE')
  if before.st_size>MAX_SOURCE:raise ValueError('SOURCE_BUDGET_EXCEEDED')
  data=b''
  while True:
   b=os.read(fd,min(65536,MAX_SOURCE+1-len(data)))
   if not b:break
   data+=b
   if len(data)>MAX_SOURCE:raise ValueError('SOURCE_BUDGET_EXCEEDED')
  after=os.fstat(fd)
  if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):raise ValueError('SOURCE_CHANGED_DURING_READ')
  return data,{'dev':after.st_dev,'ino':after.st_ino,'size':after.st_size,'path':str(path)}
 finally:os.close(fd)

def import_file(c,sid,path,fail=False):
 s=dict(c.execute('select * from m14_history_source where source_id=?',(sid,)).fetchone())
 try:data,identity=read_source(path)
 except (OSError,ValueError) as e:
  with c:c.execute('update m14_history_source set state=? where source_id=?',('missing' if isinstance(e,FileNotFoundError) else 'unavailable',sid))
  return {'state':'missing' if isinstance(e,FileNotFoundError) else 'unavailable','error':str(e),'inserted':0,'resumeEligible':False}
 revision=sha(data)
 old=c.execute('select * from m14_history_revision where source_id=? and revision_hash=?',(sid,revision)).fetchone()
 if old:
  conflicts=c.execute('select record_key from m14_history_record where source_id=? group by record_key having count(*)>1',(sid,)).fetchall()
  state='partial' if conflicts else json.loads(old['observation_json'])['state']
  with c:c.execute('update m14_history_source set state=?,current_revision=? where source_id=?',(state,revision,sid))
  return {'state':state,'inserted':0,'revision':revision,'idempotent':True,'conflictStillPresent':bool(conflicts)}
 manifest=[];offset=0;inserts=0;diagnostics=[];records=[]
 source_invalid=False
 if s['format']=='codex-rollout-0.167.1':
  try:
   first=json.loads(data.splitlines()[0]);header=first.get('payload',{});source_invalid=first.get('type')!='session_meta' or header.get('id',header.get('session_id'))!=s['native_id']
  except (ValueError,IndexError,AttributeError):source_invalid=True
 for n,raw in enumerate(data.splitlines(keepends=True)):
  try:
   if len(raw)>MAX_PARSE_LINE:raise ValueError('RECORD_PARSE_BUDGET')
   value=json.loads(raw)
  except (UnicodeError,ValueError) as e:value=None;norm={'category':'corrupt' if len(raw)<=MAX_PARSE_LINE else 'opaque','diagnostic':type(e).__name__,'origin':'imported-history','actionable':False,'authorizesLiveUser':False,'resumeEligible':False}
  else:
   try:norm=normalize(value,s)
   except (TypeError,ValueError,AttributeError) as e:norm={'category':'corrupt','diagnostic':'MALFORMED_KNOWN_SHAPE','origin':'imported-history','actionable':False,'authorizesLiveUser':False,'resumeEligible':False}
  if source_invalid:norm={'category':'unknown','diagnostic':'SOURCE_HEADER_IDENTITY_MISMATCH','origin':'imported-history','actionable':False,'authorizesLiveUser':False,'resumeEligible':False}
  key=record_key(value,offset);rh=sha(raw)
  if norm['category'] in ['unknown','corrupt','opaque'] or norm.get('diagnostic'):diagnostics.append({'ordinal':n,'reason':norm.get('diagnostic',norm['category'])})
  manifest.append({'ordinal':n,'offset':offset,'size':len(raw),'key':key,'rawHash':rh});records.append((sid,key,rh,raw,js(norm)));offset+=len(raw)
 state='partial' if diagnostics else 'readable'
 try:
  c.execute('BEGIN IMMEDIATE')
  for rec in records:inserts+=c.execute('insert or ignore into m14_history_record values(?,?,?,?,?)',rec).rowcount
  conflicts=c.execute('select record_key from m14_history_record where source_id=? group by record_key having count(*)>1',(sid,)).fetchall()
  if conflicts:state='partial';diagnostics.append({'reason':'NATIVE_KEY_CONFLICT','keys':[x[0] for x in conflicts]})
  obs={'state':state,'diagnostics':diagnostics,'sourceIdentity':identity,'mapperVersion':VERSION,'nativeResumeValidated':False}
  c.execute('insert into m14_history_revision values(?,?,?,?,?)',(sid,revision,len(data),js(manifest),js(obs)))
  c.execute('update m14_history_source set state=?,current_revision=? where source_id=?',(state,revision,sid))
  if fail:raise ValueError('INJECTED_BEFORE_COMMIT')
  c.commit()
 except Exception:c.rollback();raise
 return {'state':state,'inserted':inserts,'revision':revision,'diagnostics':diagnostics,'idempotent':False}

def records(c,sid):return [(dict(r),json.loads(r['normalized_json'])) for r in c.execute('select * from m14_history_record where source_id=?',(sid,))]
def reconstruct(c,sid,revision):
 manifest=json.loads(c.execute('select manifest_json from m14_history_revision where source_id=? and revision_hash=?',(sid,revision)).fetchone()[0]);parts=[]
 for item in manifest:
  raw=c.execute('select raw_bytes from m14_history_record where source_id=? and record_key=? and raw_hash=?',(sid,item['key'],item['rawHash'])).fetchone()[0];assert sha(raw)==item['rawHash'];parts.append(raw)
 data=b''.join(parts);assert sha(data)==revision;return data
