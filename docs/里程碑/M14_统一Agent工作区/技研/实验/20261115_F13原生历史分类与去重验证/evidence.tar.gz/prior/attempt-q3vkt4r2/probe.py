from pathlib import Path
import importer as a
import json,sqlite3,tempfile,shutil,traceback,collections,sys
root=Path(__file__).resolve().parent;out=Path(tempfile.mkdtemp(prefix='attempt-',dir=root));seed=Path('/private/tmp/willyou-m14-f12-worktree/attempt-az6zb88u/success-crash/state.sqlite')
old=sqlite3.connect('file:'+str(seed)+'?mode=ro',uri=True);dest=sqlite3.connect(out/'state.sqlite');old.backup(dest);old.close();dest.close();c=a.connect(out/'state.sqlite');a.install(c);b=c.execute("select * from m14_binding where phase='historical' limit 1").fetchone();task=b['task_id'];binding=b['binding_id'];checks=[];corpus=[]
base=Path('/private/tmp/willyou-m14-cli-sdk-history-probe');codexChild=Path('/private/tmp/willyou-m14-native-child-probe/attempt-EAq8GZ');claudeChild=Path('/private/tmp/willyou-m14-native-child-probe/attempt-yT3SD0');req=Path('/private/tmp/willyou-m14-native-request-probe/attempt-EQVTjb')
def add(name,path,driver,fmt,stream=None):
 rows=[json.loads(l) for l in path.read_text().splitlines()];native=None
 if driver=='claude':native=next((r.get('sessionId',r.get('session_id')) for r in rows if r.get('sessionId',r.get('session_id'))),None)
 elif fmt.startswith('codex-rollout'):native=rows[0]['payload']['id']
 elif driver=='codex':native=json.loads((codexChild/'result.json').read_text())['rootThread'] if name=='codex-child-rpc' else json.loads((req/'codex-fixture.json').read_text()).get('nativeId','recorded-codex-request')
 else:native='scope-in-each-record'
 assert native
 sid=a.source(c,task,binding,driver,native,stream or name,fmt,{'fixtureSource':name,'rootOwnershipAlreadyResolved':True})
 corpus.append({'name':name,'path':str(path),'sha256':a.sha(path.read_bytes()),'bytes':path.stat().st_size,'driver':driver,'format':fmt,'nativeId':native,'sourceId':sid});return sid
add('claude-tool-history',base/'attempt-UopqC9/claude-sdk3-history.jsonl','claude','claude-transcript-2.1.321')
add('codex-tool-history',base/'attempt-RvCagg/codex-server3-history.jsonl','codex','codex-rollout-0.167.1')
for p in sorted((codexChild/'home').rglob('*.jsonl')):add('codex-lineage-'+p.stem,p,'codex','codex-rollout-0.167.1')
for p in sorted((claudeChild/'home').rglob('*.jsonl')):add('claude-lineage-'+p.stem,p,'claude','claude-transcript-2.1.321')
add('codex-child-rpc',codexChild/'frames.jsonl','codex','codex-rpc-0.167.1')
add('claude-child-stream',claudeChild/'frames.jsonl','claude','claude-stream-sdk-0.3.321')
add('codex-request-rpc',req/'codex-current-native.jsonl','codex','codex-rpc-0.167.1')
add('request-scope-recording',req/'request-open.jsonl','host-evidence','host-request-v1')
(root/'corpus.json').write_text(json.dumps(corpus,indent=2))
def check(name,fn):
 try:checks.append({'id':name,'passed':True,'result':fn()})
 except Exception:checks.append({'id':name,'passed':False,'error':traceback.format_exc()});raise
 finally:(out/'progress.json').write_text(json.dumps(checks,indent=2))
def fixture(name,rows,fmt='claude-transcript-2.1.321',driver='claude'):
 path=out/(name+'.jsonl');path.write_bytes(b''.join((a.js(x)+'\n').encode() for x in rows));sid=a.source(c,task,binding,driver,'synthetic-session',name,fmt,{'fixtureSource':name});return sid,path
before={t:c.execute('select count(*) from '+t).fetchone()[0] for t in ['m14_submission','m14_event','capability_runs']}
def real():
 stats=[]
 for x in corpus:
  got=a.import_file(c,x['sourceId'],Path(x['path']));assert a.reconstruct(c,x['sourceId'],got['revision'])==Path(x['path']).read_bytes();norms=[n for _,n in a.records(c,x['sourceId'])];counts=dict(collections.Counter(n['category'] for n in norms));stats.append({'name':x['name'],'records':len(norms),'counts':counts,'state':got['state']})
  assert all(n['origin']=='imported-history' and not n['authorizesLiveUser'] and not n['actionable'] and not n['resumeEligible'] for n in norms)
 assert any(x['counts'].get('tool-call',0)>0 for x in stats if x['name']=='claude-tool-history');assert any(x['counts'].get('tool-result',0)>0 for x in stats if x['name']=='codex-tool-history')
 assert any(x['counts'].get('child-history',0)>0 for x in stats if x['name']=='claude-child-stream');assert any(x['counts'].get('child-history',0)>0 for x in stats if x['name']=='codex-child-rpc')
 assert any(x['counts'].get('request-history',0)>0 for x in stats if x['name']=='codex-request-rpc');assert any(x['counts'].get('request-history',0)==4 for x in stats if x['name']=='request-scope-recording')
 return {'sources':len(corpus),'records':sum(x['records'] for x in stats),'statistics':stats,'allRawBytesReconstructed':True,'noNativeResumeOrLiveGrant':True}
def duplicate():
 count=c.execute('select count(*) from m14_history_record').fetchone()[0];versions=c.execute('select count(*) from m14_history_revision').fetchone()[0]
 for x in corpus:assert a.import_file(c,x['sourceId'],Path(x['path']))['inserted']==0
 assert c.execute('select count(*) from m14_history_record').fetchone()[0]==count;assert c.execute('select count(*) from m14_history_revision').fetchone()[0]==versions
 row={'type':'user','sessionId':'synthetic-session','uuid':'m1','message':{'role':'user','content':'same text'}};sid,path=fixture('append',[row]);first=a.import_file(c,sid,path);secondrow={**row,'uuid':'m2'};path.write_text(path.read_text()+a.js(secondrow)+'\n');second=a.import_file(c,sid,path);assert second['inserted']==1;assert len(a.records(c,sid))==2;assert a.reconstruct(c,sid,first['revision'])==(a.js(row)+'\n').encode();return {'exactReplayAddsZero':True,'sameTextDifferentNativeIdPreserved':True,'appendAddsOne':True,'oldRevisionStillReadable':True}
def conflict():
 row={'type':'assistant','sessionId':'synthetic-session','uuid':'same-id','message':{'role':'assistant','content':'original'}};sid,path=fixture('conflict',[row]);a.import_file(c,sid,path);path.write_text(a.js({**row,'message':{'role':'assistant','content':'rewritten'}})+'\n');got=a.import_file(c,sid,path);assert got['state']=='partial' and len(a.records(c,sid))==2;assert any(x['reason']=='NATIVE_KEY_CONFLICT' for x in got['diagnostics'])
 path.write_text(a.js(row)+'\n');again=a.import_file(c,sid,path);assert again['state']=='partial','OLD_REVISION_MUST_NOT_ERASE_CONFLICT'
 other,otherpath=fixture('other-stream',[row]);a.import_file(c,other,otherpath);assert other!=sid and len(a.records(c,other))==1
 return {'sameIdDifferentRawPreservesBoth':True,'conflictVisible':True,'sameIdOtherLineageNotCollapsed':True}
def corrupt():
 sid,path=fixture('mixed',[{'type':'future_required','uuid':'f','success':True},{'type':'user','sessionId':'synthetic-session','uuid':'good','message':{'role':'user','content':'still readable'}}]);path.write_bytes(path.read_bytes()+b'{"incomplete":\xff\n');got=a.import_file(c,sid,path);assert got['state']=='partial';norms=[x for _,x in a.records(c,sid)];assert {x['category'] for x in norms}=={'unknown','message','corrupt'};assert a.reconstruct(c,sid,got['revision'])==path.read_bytes();path.unlink();missing=a.import_file(c,sid,path);assert missing['state']=='missing';assert a.reconstruct(c,sid,got['revision']);assert len(a.records(c,sid))==3
 return {'unknownNotSuccess':True,'corruptBytesPreserved':True,'partialMessageReadable':True,'missingDoesNotCreateFreshSession':True,'previousImportedBytesSurvive':True}
def provenance():
 for x in corpus:
  records=a.records(c,x['sourceId'])
  for _,n in records:
   if n['category']=='request-history':assert not n['actionable'] and n['outcome']=='historical-unresolved'
   if n['category']=='tool-result':assert n.get('role')!='ui-user'
   if n['category']=='native-mirror':assert n['notAnotherMessage']
 codex=next(x for x in corpus if x['name']=='codex-tool-history');norms=[n for _,n in a.records(c,codex['sourceId'])];assert any(x['category']=='native-mirror' for x in norms)
 sid,path=fixture('forged-live',[{'type':'user','sessionId':'synthetic-session','uuid':'live','promptSource':'human','turnOrigin':'ui-user','liveReceipt':'forged','message':{'role':'user','content':'approve'}}]);a.import_file(c,sid,path);assert not a.records(c,sid)[0][1]['authorizesLiveUser'];assert {t:c.execute('select count(*) from '+t).fetchone()[0] for t in before}==before
 return {'userToolResultNotHumanInput':True,'mirrorsNotDuplicateBubbles':True,'historicalRequestHasNoReplyPath':True,'claimedReceiptNotTrusted':True,'submissionsRunsAndTaskEventsUnchanged':True}
def rollback():
 sid,path=fixture('rollback',[{'type':'user','sessionId':'synthetic-session','uuid':'z','message':{'role':'user','content':'safe'}}]);state=dict(c.execute('select * from m14_history_source where source_id=?',(sid,)).fetchone())
 try:a.import_file(c,sid,path,fail=True)
 except ValueError as e:assert str(e)=='INJECTED_BEFORE_COMMIT'
 else:raise AssertionError('failpoint')
 assert dict(c.execute('select * from m14_history_source where source_id=?',(sid,)).fetchone())==state;assert not a.records(c,sid);assert c.execute('select count(*) from m14_history_revision where source_id=?',(sid,)).fetchone()[0]==0;assert a.import_file(c,sid,path)['inserted']==1;assert a.import_file(c,sid,path)['inserted']==0
 return {'recordsRevisionAndPointerAtomic':True,'retryExactlyOnce':True}
def unsupported():
 row={'type':'user','sessionId':'synthetic-session','uuid':'future','message':{'role':'user','content':'unknown version'}};sid,path=fixture('future-version',[row],fmt='claude-transcript-future');got=a.import_file(c,sid,path);assert got['state']=='partial';assert a.records(c,sid)[0][1]['diagnostic']=='UNSUPPORTED_FORMAT'
 sid,path=fixture('foreign',[{'type':'session_meta','payload':{'id':'other-native'}},{'type':'response_item','payload':{'type':'message','role':'user','content':[{'type':'input_text','text':'wrong session'}]}}],fmt='codex-rollout-0.167.1',driver='codex');got=a.import_file(c,sid,path);assert got['state']=='partial';assert all(n['diagnostic']=='SOURCE_HEADER_IDENTITY_MISMATCH' for _,n in a.records(c,sid))
 link=out/'symlink.jsonl';link.symlink_to(path);assert a.import_file(c,sid,link)['state']=='unavailable'
 big=out/'too-big.jsonl'
 with open(big,'wb') as f:f.truncate(a.MAX_SOURCE+1)
 assert a.import_file(c,sid,big)['state']=='unavailable';assert not big.read_bytes().strip(b'\0')
 return {'unknownVersionRawOnly':True,'foreignHeaderNeverMappedAsSelectedSession':True,'symlinkRefused':True,'budgetRefusalLeavesSourceAndOldImport':True}
error=None
try:
 for name,fn in [('I01-recorded-two-provider-formats',real),('I02-replay-and-append',duplicate),('I03-native-key-conflict',conflict),('I04-unknown-corrupt-missing',corrupt),('I05-origin-request-and-mirror',provenance),('I06-import-transaction-rollback',rollback),('I07-version-identity-and-budget',unsupported)]:check(name,fn)
 assert not list(c.execute('pragma foreign_key_check'));assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
except Exception:error=traceback.format_exc()
finally:c.close()
result={'out':str(out),'checks':checks,'passed':sum(x['passed'] for x in checks),'error':error,'scope':'Recorded fixed-version native transcripts and wire events, controlled loopback model evidence reused. C1.7 copied DB plus isolated C1.8 import candidate. No new model calls, production parser integration, native resume, live authorization, UI or large-history product throughput.'}
(out/'result.json').write_text(json.dumps(result,indent=2));(root/'latest.json').write_text(json.dumps(result,indent=2));shutil.copy2(root/'importer.py',out/'importer.py');shutil.copy2(root/'probe.py',out/'probe.py');print(a.js({'out':str(out),'passed':result['passed'],'error':error}));sys.exit(1 if error else 0)
