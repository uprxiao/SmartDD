### 11.4 原生历史分类、lineage 与只读导入（F13）

F13 按[固定格式录制复放](实验/20261115_F13原生历史分类与去重验证/README.md)研究关闭：复用10份此前实际运行的原生 transcript／协议录制，271条去重后的记录、七项定向检查；本批不再启动模型。原生进程当时连接受控本机模型，不能称为真实供应商响应。共同关系在 C1.7 上增量为 **C1.8**，P1.2 命令形状保持；F14须携带这些新增只读历史关系。

**入口与责任。** HistoryImportService 从宿主已解析的 task／binding／原生身份及获准历史来源读取，分派到注册的 HistoryFormatAdapter；输入不接受模型声明的身份、任意文件路径或“真人”标签。复用当前 `native-sessions.ts`／`agent-native-state.ts` 的定位和恢复边界，保持源文件不写、不删、不修复。`NativeEvidenceAdapter`／业务证据读取器用于独立的来源证明，不能因为导入器识别出user就代发业务授权。历史查看、迁移、原生resume各自有准入条件。

T3 的 Claude history worker 调用 SDK `getSessionMessages`，Codex Adapter 经 `thread/read`／原生历史模式获取记录；其运行／回滚身份与查询参数分开。WillYou可以在各driver能力允许时使用其结构化历史接口，但旧CLI文件和缺失／未知记录仍需只读格式适配。SDK历史、原生JSONL、协议录制是不同来源，不把一个来源的记录直接当成另一个来源的真人输入。此次候选读取现存文件，没有执行T3完整适配器或重新调用SDK历史API。

| 声明格式／记录 | 规范历史与关联 | 不得推导 |
| --- | --- | --- |
| Claude native 2.1.321 transcript；SDK 0.3.321已录制stream中的user／assistant | role仅为历史角色；text、tool_use、tool_result分别映射，保留uuid、parentUuid、tool id、agentId／parent_tool_use_id；同记录可含多个块 | user包裹tool_result不是新用户输入；promptSource／turnOrigin／伪造receipt不授真人来源 |
| Claude Agent结果、task_started／updated／notification及子文件 | 保留已声明child id、tool关联和观察到的状态；子流使用独立stream身份；缺子文件显示局部缺失 | 父Agent调用完成不等于全部后代排空；未知子结构不猜成成功 |
| Codex native 0.167.1 rollout的response_item | message／function_call及output／custom_tool_call及output分别建模，保留call id、ordinal、role；session_meta核对选定原生ID并保留parent_thread_id | 文本相同不等于同消息；工具结果存在不证明外部业务已完成 |
| Codex event_msg/item_completed，以及RPC item started／completed | 已有原始message／tool记录时作为原生镜像或状态证据，保留native item关联；collabAgentToolCall明确列出接收子线程与观察状态 | 不再生成第二个用户／助手气泡，不从镜像重复提交输入 |
| 已录制Codex requestApproval／requestUserInput／MCP elicitation；宿主历史请求记录 | request-history保留原请求ID、完整记录scope、结构和有无解决证据；resolution只记历史事实 | 历史请求没有当前回应入口；resolved不等于接受，也不恢复原run／generation的授权 |
| 已声明配置、usage、缓存、turn元数据 | metadata／turn-history，与正文分开；Claude api-request-blob属于缓存记录 | 缓存里的message不再次作为对话导入，结束事件不代替工具／业务最终状态 |
| 未知type／内容块／格式版本、损坏字节或残缺行 | 原字节保留，标unknown／corrupt／opaque；其余可读记录继续展示，覆盖为partial | 不丢原记录、不猜成功、不造完整历史；任意未来协议不在本次支持声明内 |

规范项共享 `origin=imported-history`、`actionable=false`、`authorizesLiveUser=false`、`resumeEligible=false`。此处的false意味着导入结果本身不授予权限，并非否认这些历史后来可经独立准入用于续聊。真正发送旧历史走现有history-transfer输入来源；模型产生的工具结果仍是工具事件，不伪造成新submission。历史请求若确需继续，由当前原生运行重新产生可核验的新请求，禁止直接答复旧记录。

**身份与增量。** sourceId由宿主绑定身份、driver、nativeId和稳定stream/child身份组成，路径只是一次观察位置；Claude主／子流、Codex父／子线程、JSONL与辅助协议录制分别命名。具体driver的source必须匹配binding.runner及nativeId；复制后是否属于同一lineage由F14的来源／claim关系证明，不能只因文件名或内容相同合并。未关联的辅助请求录制保留自己的recordedScope，不能作为当前binding事件接线。

原生key优先用带source范围的Claude uuid、Codex ordinal、带方法及类型的RPC id／完整scope请求id；没有稳定ID时用该流原始字节offset。每个key另存rawHash：相同key／相同原始字节复用；相同文本但不同ID保留；同key不同内容保存两个版本并标冲突，不能覆盖。无ID的流若被重排／前插，offset变化或旧key冲突只能给部分结果，不假装证明跨重写去重。Codex镜像记录单独留存但不生成第二个气泡；JSONL为正文主来源时辅助wire记录只补请求／子状态，不叠加其重复message。主来源无法读取时明确使用哪个备用来源，不能无关联地合并文本。

**持久化与发布。** [C1.8精确SQL](实验/20261115_F13原生历史分类与去重验证/contract.sql)在原库增加history_source／history_revision／history_record。source连接原task／binding及格式身份；revision保存完整来源hash、字节数、按原顺序的记录key/hash/offset/长度清单和观察状态；record保存不可变raw bytes及带mapperVersion的规范表示。同一原始记录跨来源修订复用，一份manifest仍保留每次出现，能逐字节还原被接受的来源版本。即使未知或后来缺文件，已导入字节也不依赖原文件继续存在。原始信息仅在原任务权限内查询，不默认导出或发送给模型；原生日志可能包含敏感内容，不能把诊断导出等同完整原文授权。

记录、新revision、当前来源指针同事务提交；失败全部回滚，重试相同来源不再插入记录。source.current_revision有复合外键。历史冲突按该source的全部已存版本复核：曾出现同key不同raw，即使来源又恢复某个旧hash，仍标partial，不能用旧revision当时的readable清掉冲突。格式／mapper升级需显式重投影或迁移，不随SDK版本变化自动覆盖旧映射。真正宿主提交还须按§4.2在同一事务发布历史投影变化及taskSeq，通知仅在提交后发出；本批候选未改动运行、submission或task事件表，IPC接线留A46／F16。

这些raw bytes在历史表内，不是新增的可执行包或外部对象引用；原native／插件资源仍由原binding／能力引用保留。新增source外键阻止历史仍在时物理删除binding；缺源、归档、缺子文件均不抹导入账。历史数据与事件重放缓存分开保留，不能因为通知日志裁剪就删除raw记录；明确删除历史必须按任务保留及未决交接约束执行。F14复制、回退和版本门禁必须包括C1.8，旧程序不得忽略这三表后继续写。

**不足、预算与验收。** 文件消失为missing，身份不符／链接／读取失败为unavailable，旧导入保留；未知格式或语义冲突为partial。对已声明父子来源集合逐项汇总，缺子流不隐藏父消息，也不宣称整个树完整。数据可读不证明原生状态可恢复，原生resume仍遵循§11.1及旧“曾观察到历史”规则。

探针一次来源读取上限16MiB、单记录JSON解析上限1MiB；超解析上限保留不解释的raw，超来源预算明确拒绝本次导入且不写源、不清掉旧投影。该预算是本轮隔离验证范围，不作为未经产品测量的性能承诺。正式服务必须采用有界批次／可恢复游标处理长历史，不能把整份raw或normalized JSON塞入IPC；列表只返回必要摘要与原文定位，原文按受控范围读取，帧／分页／缓存预算按F16。长历史成品吞吐和完整UI不计本批通过。

七项检查及首败修正见F13证据：两端真实录制分类／字节还原，重复／增量，key冲突及回到旧版本，未知／损坏／缺子文件，历史来源及镜像，事务失败，未知版本／错误binding／源身份与预算。按§7.2关闭Q46；原A46继续验证实际导入服务、原生续聊／换根、权限和UI，C1.8本身不是产品迁移已执行。
