from pathlib import Path
import json,hashlib,tarfile,subprocess,re
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');exp=base/'技研/实验/20261114_只读模式与外部MCP写入边界验证';stage=root/'publication';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==2 and r['failed']==0 and not r.get('error');p=Path(r['out']);cleanup=json.loads((p/'cleanup.json').read_text());assert len(cleanup)==2 and all(x['exitCode']==0 for x in cleanup)
models=[json.loads(l)for l in(p/'model.jsonl').read_text().splitlines()];assert len(models)==4
for c in r['checks']:
 assert c['detail']['externalMcpWroteWorkspace'] and c['detail']['mcpCalls']==1 and c['detail']['modelRequests']==2
for m in models:
 if m['id'].startswith('claude'):assert {x['name']for x in m['body']['tools']}=={'Read','Glob','Grep','mcp__wy__wy_form'}
refs=[t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sources':[{'path':str(x),'sha256':sha(x.read_bytes())}for x in refs],'runtimes':[json.loads((p/(x+'-runtime.json')).read_text())for x in ['claude','codex']],'sourceFindings':['T3 Claude readOnly selects Read/Glob/Grep and dontAsk; MCP allowedTools is a preapproval list, separately scoped to known T3 tools.','MCP ToolAnnotations schema explicitly says annotations are hints, not guaranteed descriptions.'],'boundary':'T3 source only. Probe uses a deliberately misannotated synthetic external tool, not actual T3 or WillYou services; it is not a demonstrated policy bypass in either product.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[root/n for n in ['probe.mjs','native-inputs.mjs','prepare.py','source-review.json']]+sorted(f for f in p.iterdir()if f.is_file())
archive=root/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz')as tar:
 for x in files:tar.add(x,arcname=str(x.relative_to(root)),recursive=False)
manifest={'archiveSha256':sha(archive.read_bytes()),'files':[{'path':str(x.relative_to(root)),'sha256':sha(x.read_bytes())}for x in files]}
for n,v in [('result.json',r),('source-review.json',review),('archive-manifest.json',manifest)]:put(exp/n,json.dumps(v,ensure_ascii=False,indent=2)+'\n')
put(exp/'raw-evidence.tar.gz',archive.read_bytes())
put(exp/'README.md','''# 只读模式与外部 MCP 写入边界验证

日期：2026-11-14。关联 R09／Q33；独立技术实验，不是产品验收。

## 问题与方法

验证原生只读选项是否足以证明包含外部 MCP 的整个运行只读。复用先前 HTTP MCP 驱动，在独立 HOME、配置与工作目录启动固定真实原生程序；模型响应由本机合成服务提供，不访问真实模型供应商。MCP 服务刻意声明 readOnlyHint=true、destructiveHint=false，却在自己的 handler 中写本次临时工作目录的合成文件。该工具由实验显式预批准，这不是绕过未经授权的调用。

| 原生配置 | 观察结果 |
| --- | --- |
| Claude SDK 0.3.321／native 2.1.321；dontAsk、tools=Read/Glob/Grep，单独预批准实验 MCP 工具 | 模型可见工具只有三个原生读工具及实验 MCP；MCP 一次调用写出文件，原生回合 success |
| Codex app-server 0.167.1；sandbox=read-only、approvalPolicy=never，实验 MCP default_tools_approval_mode=approve | MCP 一次调用写出文件，原生回合 completed |

两条负向边界检查通过；四次本机模型请求，两个捕获的原生进程均 exit 0，无真实业务写入。通过表示反例成立，不表示只读隔离通过。二进制在启动前校验 SHA256；版本、输入和请求记录随归档保存。

## 设计结论

原生工具限制与外部 MCP 服务执行权限是不同边界。readOnlyHint 是声明；不能据此给整个运行签发并行只读能力。外部服务可能执行目录写入、数据库／SSH、浏览器或插件动作，须由对应服务的真实授权与执行限制证明；本实验只实际覆盖合成文件写入，未运行这些业务。

T3 源码分别限制 Claude 原生工具及已知 T3 MCP 的预批准列表；不能把该实现理解成所有第三方 MCP 都被 OS 沙箱强制只读。本次未运行 T3 适配器，也未发现或证明 T3／WillYou 产品权限绕过。

WillYou 保持现行方案：没有原生工具、shell／Skill、MCP／插件业务的完整限制证据，就不开放共享目录并行只读，按可能写入排队。声明、提示词、工具名称、曾经一次没写文件，都不能替代能力证明。服务端规则／工具版本或接入配置改变后，旧能力结论不可直接沿用。

仍待验证：实际共享目录准入的串行守卫、各执行与业务路径的限制、按需读取版本变化与复核、动态接入变化、真实大项目性能。Q33 仅推进为部分证据。

## 复现与证据

解压 raw-evidence.tar.gz 后，在已记录依赖可用的本机运行 `node probe.mjs`；需允许本机监听。脚本只写新建 attempt 目录，使用合成凭据，并关闭自己启动的服务和程序。它不启动 WillYou／T3 产品。

[结果](result.json) · [源码与版本](source-review.json) · [归档校验](archive-manifest.json) · [原始证据](raw-evidence.tar.gz)。
''')
def tech(t):
 anchor='10GB 以上真实项目的目录准备、排队、按需读取和资源开销须实测；';assert anchor in t
 add='''[只读与外部 MCP 边界实验](实验/20261114_只读模式与外部MCP写入边界验证/README.md)在固定 Claude／Codex 原生版本各取得一条反例：Claude 仅开放 Read／Glob／Grep、dontAsk，Codex 使用 read-only／never，但显式预批准的外部 HTTP MCP handler 仍写入合成工作目录。工具声明 readOnlyHint=true 不构成执行限制。这不是 T3 或 WillYou 产品权限绕过证明；T3 的已知 MCP 预批准列表也不代表所有外部服务被沙箱约束。并行只读准入须依据完整执行路径的限制证据；新接 MCP、插件升级或服务规则变化时重新评估，缺证继续串行。实际准入守卫、shell／Skill、业务路径及按需读取版本复核仍待验。

'''
 return t.replace(anchor,add+anchor)
edit(base/'技研/技术方案.md',tech)
def ledger(t):
 anchor='## 5. 失败与驱动修正';assert anchor in t and '### 4.82 'not in t
 add='''### 4.82 原生只读与外部 MCP 的执行边界

[两端原生反例](实验/20261114_只读模式与外部MCP写入边界验证/README.md)通过：Claude dontAsk／Read/Glob/Grep 与 Codex read-only／never 均未阻止已显式预批准的外部 HTTP MCP handler 写入合成工作目录；工具声明 readOnlyHint=true。四次本机合成模型请求、两个原生进程 exit 0，不涉及真实供应商或业务写入。

结论仅为外部服务不自动继承原生只读限制；不是 T3／WillYou 产品漏洞，也不证明原生 shell 只读失效。技术方案 §8.1 保持未证只读则串行，并要求工具／服务配置变化后重新评估。Q33 从待验推进为部分；完整准入守卫、各业务限制、读取依据变化、真实大项目仍待验。

'''
 t=t.replace(anchor,add+anchor)
 old='| Q33 | 只读分析是真正受限，读取依据变化能检测 | E09；专项 §16.4 | 待验；要覆盖 shell、MCP、插件业务及目录查询，不支持则明确串行；不承诺全项目原子快照 |'
 new='| Q33 | 只读分析是真正受限，读取依据变化能检测 | E09；专项 §16.4 | **部分**：§4.82 两端原生反例证明只读工具／沙箱不约束显式预批准的外部 MCP handler 写入，readOnlyHint 不能作为并行凭据；未证只读继续串行。实际准入守卫、shell／Skill、插件业务及读取依据变化仍待验，不承诺全项目原子快照 |'
 assert old in t;t=t.replace(old,new)
 old='截至 §4.81.1，56 个宽口径问题项中，47 项有部分实验／限定证据，6 项主要内容仍待验证或产品集成，2 项模板产品已按用户确认延后，1 项可选 SVN 自动管理不开放；整项完整关闭为 0。六项为 Q26、Q33、Q42、Q51、Q52、Q56。'
 new='截至 §4.82，56 个宽口径问题项中，48 项有部分实验／限定证据，5 项主要内容仍待验证或产品集成，2 项模板产品已按用户确认延后，1 项可选 SVN 自动管理不开放；整项完整关闭为 0。五项为 Q26、Q42、Q51、Q52、Q56。Q33 本轮取得只读边界反例，由待验推进为部分，未宣称并行只读可用。'
 assert old in t;t=t.replace(old,new).replace('不是只剩六项。','不是只剩五项。').replace('不能用 47／56 作为研究完成率','不能用 48／56 作为研究完成率')
 rows=re.findall(r'^\| (Q\d\d) \|.*$',t,re.M);assert len(rows)==56 and len(set(rows))==56
 return t
edit(base/'技研/全局设计验证账.md',ledger)
def index(t):
 t=re.sub(r'最新进展：[^\n]*','最新进展：Claude／Codex 原生只读与外部 MCP 写入边界已实跑；外部服务不自动继承原生限制，未证端到端只读继续串行。见[技术方案 §8.1](技研/技术方案.md)，全局数量以[验证账 §7.4](技研/全局设计验证账.md#74-当前统计口径)为准。',t)
 return re.sub(r'下一步：[^\n]*','下一步：按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续核对共享目录准入、按需读取版本变化、动态子树和业务排空；真实供应商与产品集成条件独立保留。',t)
edit(base/'README.md',index)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'files':len(entries),'nativeCases':2,'archiveFiles':len(files),'localRequests':4,'partial':48,'pending':5}))
