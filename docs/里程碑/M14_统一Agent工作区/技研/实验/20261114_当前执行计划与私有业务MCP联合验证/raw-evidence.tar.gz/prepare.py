from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_当前执行计划与私有业务MCP联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==3 and not r.get('error');a=Path(r['out']);sources={};outputs=[]
for n in ['build.json','profile-build.json','bridge-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s['sha256']
 for o in b['outputs']:
  assert sha((root/Path(o['file']).name).read_bytes())==o['sha256'];outputs.append(o)
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[]
for attempt in sorted(root.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());cleanup=json.loads((attempt/'cleanup.json').read_text());assert len(cleanup['nativeExits'])==2 and all(x['code']==(0 if x['driver']=='codex'else 143)for x in cleanup['nativeExits']);assert all(x['state']['runState']=='stopped'for x in cleanup['cleanup'])
 db=sqlite3.connect((attempt/'final.sqlite').as_uri()+'?mode=ro',uri=True)
 assert db.execute("SELECT COUNT(*) FROM capability_resource_leases WHERE state<>'released'").fetchone()==(0,);assert db.execute("SELECT COUNT(*) FROM capability_runs WHERE state<>'stopped' OR revocation_state<>'revoked'").fetchone()==(0,);assert db.execute("SELECT COUNT(*) FROM capability_run_processes WHERE state NOT IN('exited','canceled')").fetchone()==(0,);db.close()
 attempts.append({'attempt':attempt.name,'checksPassed':result['passed'],'error':result.get('error'),'nativeExits':cleanup['nativeExits'],'modelRequests':len(json.loads((attempt/'models.json').read_text())),'peerProofs':len(json.loads((attempt/'proofs.json').read_text())),'allOwnedRunsAndLeasesSettled':True})
assert len(attempts)==2
calls=json.loads((a/'executions.json').read_text());inv=json.loads((a/'invocations.json').read_text());models=json.loads((a/'models.json').read_text());proofs=json.loads((a/'proofs.json').read_text());assert len(calls)==len(inv)==len(proofs)==2 and len(models)==6;assert len(set(x['taskId']for x in calls))==1 and len(set(x['runId']for x in calls))==2;assert all(x['state']=='succeeded'and x['attempt_count']==1 and x['effect_state']=='read-only'for x in inv)
for driver in ['codex','claude']:
 rows=[x for x in models if x['driver']==driver];assert len(rows)==3 and 'PRIVATE_BRIDGE_'+driver in json.dumps(rows[1]['body'])and 'APP_NOT_ENABLED'in json.dumps(rows[2]['body'])
runtime={'attempts':attempts,'finalAttempt':a.name,'finalChecks':3,'finalInvocations':inv,'businessHandler':'Synthetic read only; actual broker/runtime/authorization/ToolService. No real business connector executed.','initialFailure':'Old-run reserveBridge correctly returned CANCELED; probe had expected SCOPE_DENIED. Only assertion changed.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/private-broker.ts',repo/'src/main/core/applications/agent-bridge-processes.ts',repo/'src/main/core/applications/bridge-runtime.ts',repo/'src/main/core/applications/tool-service.ts',repo/'src/main/core/applications/current-authorization.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',t3/'apps/server/src/orchestration-v2/ProviderContinuationService.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'outputs':outputs,'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'buildScope':'Actual private broker, kernel peer supervisor, bridge runtime and ToolService; existing temporary programmatic run/session/retention source variants reused. Fixture composes onRevoke and real bridge bytes, no production source edit.','t3Boundary':'Provider adapter/host continuation separation referenced; does not transplant T3 MCP into WillYou or run T3 itself.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.variant','.py','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 当前程序化执行计划与私有业务 MCP 联合验证

2026-11-14；R02／03／08／10／12，Q04／09／27／28。技术方案 §9.4，验证账 §4.64。仅独立技术研究；生产与共享原型未修改。

## 本批补齐的链路

§4.18 的旧运行模型已接私有桥，§4.54 的当前程序化运行已接直接宿主业务检查。本批把当前候选的同一 task、多 binding、私有 owner、配置修订、ApplicationRunPlan／ExecutionPlan 和实际 native 接到现有私有桥：

`Claude SDK / Codex app-server → 原生启动 stdio MCP → 实际 bridge-runtime → 单次票据／Unix socket → 内核 peer 身份／祖先链 → PrivateApplicationBroker → CurrentApplicationAuthorization → ApplicationToolService → 合成只读 handler`

没有改用 dynamicTools 或直接 in-process MCP 绕过业务桥。桥的运行资源通过实际 RuntimeRegistry 发布；私有 bootstrap 和 stdio 参数仍由临时宿主组合，不能称最终 Driver／Electron 分发已实施。程序化 run／session 和资源保留继续使用之前的隔离源码变体，其余桥／权限／工具服务直接打包当前源码。

## {a.name}：3 项检查

| 检查 | 结论 |
| --- | --- |
| B01 Codex | 实际 app-server 原生发现私有 stdio 工具；内核 peer 与本 run 原生祖先匹配；合成 read 执行一次，结果进入下一模型请求；随后停用应用，第二次原生工具调用返回 APP_NOT_ENABLED，handler 未执行；冻结启动计划不变 |
| B02 Claude／切换 | 同一逻辑 task 的旧 Codex 排空后换 Claude binding；实际 SDK 原生启动新桥，重复正常调用／实时停用检查通过；旧 run 的工具入口 SCOPE_DENIED，新增桥 CANCELED，不借新 Provider 重新取得旧权 |
| B03 收口 | 两个实际 application_invocations 均 succeeded／attempt_count=1／read-only，分别属于两个 run、同一 task；无 running 调用，无重放，全部运行与桥结束后资源租约 released |

最终两次 native：Codex 退出 0、Claude 受控 close 退出 143；两份实际内核桥证明，六次本机模拟模型请求、两次合成只读执行。两个 native 回合分别取得 completed／success 终态；进程退出码不替代回合证据。被实时停用拒绝的第二次调用没有进入 handler，不应补造成功 invocation。

## 保留的初次失败

attempt-wU701K 的 Codex 检查通过，Claude 已初始化但未发送本轮模型输入；驱动断言旧 run 新增桥应返回 SCOPE_DENIED，实际 reserveBridge 按源码返回 CANCELED，导致检查停止。拒绝行为有效，仅把断言改为精确 CANCELED 后重跑，未放宽权限规则。初次三个模型请求、一份桥证明和全部清理记录保留；两批四个 native 均已退出，初次未启动桥记录 canceled。

## 设计结论与限制

通用 Driver 负责原生启动与 MCP 参数映射；现有业务权威仍留在私有 broker、真实 run 和实时策略服务。冻结启动材料不能冻结业务允许状态。Provider 切换后保留逻辑任务身份，创建新 run／桥凭据；旧 run 不因新运行存在而恢复。

身份由宿主所有权与内核 peer 证明，工具参数仅含业务输入；模型不能提供 runId／PID 来获得权限。业务结果和拒绝都经过真实原生 MCP 回包进入后续模型请求。停止顺序实际包含撤销 broker、关闭自有 native、监督桥退出、再收口运行与租约；只关 UI 或认为 SDK close 即等于全部资源释放不足以替代这些条件。

业务 handler 是合成 read，未调用真实禅道／浏览器／邮件／DB／SSH／外部插件；没有真实写入或产品 UI。没有接父子委派树、在途业务中断、宿主崩溃、完整历史交接、受管 native 二进制目录或跨平台发行。配置／私有桥联合可复用，但不能把它标成所有业务已兼容。

## 证据

[结果](result.json)、[运行及调用账](runtime-audit.json)、[构建／源码依据](source-review.json)、[摘要](archive-manifest.json)、[协议／内核证明／SQLite](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性和外键通过，{len(sources)} 个构建输入复核。

复跑需固定依赖与 native 路径；执行 build.mjs、build-bridge.mjs，再执行 probe.mjs。仅临时 HOME、SQLite、私有 Unix socket 和 localhost 模型，不触碰日常配置或真实业务。
''')
section='''### 9.4 当前执行计划接入既有私有业务桥

[私有业务 MCP 联合实验](实验/20261114_当前执行计划与私有业务MCP联合验证/README.md)将当前程序化 owner／配置修订／冻结执行计划接到实际 PrivateApplicationBroker、AgentBridgeProcesses、bridge-runtime 和 ApplicationToolService。Codex→Claude 保持同一逻辑 task；两端都由原生启动 stdio MCP，经单次票据与内核 peer／祖先证明进入业务服务，正常结果和实时停用拒绝均进入后续模型请求。

Driver 只负责原生协议及经过宿主解析的桥参数，不另建绕过现有业务授权的工具通道。准备时把桥 runtime 纳入既有资源和运行计划，派发前仍校验当前 owner；认证由宿主核对原 run、桥进程及原生祖先。模型／renderer 传入的 taskId、runId 或 PID 不能代替这条权威链。

ApplicationRunPlan／ExecutionPlan 的不可变性与 R17 的实时授权并存。实际实验在原生第一次读取成功后停用应用，第二次调用得到 APP_NOT_ENABLED，handler 不执行，冻结计划保持原字节。迁移不能把“已启动时允许”当作余下会话的永久权限，也不应为停用去改写历史启动计划。

切换 Provider 时保留逻辑 task，原 run／桥／租约排空后创建新 binding 运行和私有票据。旧 run 的工具调用 SCOPE_DENIED、新增桥 CANCELED；新运行存在不恢复旧凭据。业务调用账仍记录真实 run／task／operationId，一次成功只执行一次。bridge、native 和业务 activity 的结束分别核对，再释放运行资源。

本批 handler 为合成 read，不包含真实浏览器、文件、插件、邮件、DB／SSH；临时宿主组装 bridge 参数，尚非最终 Driver／IPC 接线。它补齐当前运行模型到现有私有桥的协议与权限联合，后续仍需逐业务上下文、在途操作、宿主恢复和实际产品回归，不将本证据替代 §9.1–9.3 或完整业务完成。

'''
def tech(t):
 assert '### 9.4 'not in t;return t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
edit(base/'技研/技术方案.md',tech)
record='''### 4.64 当前执行计划与私有业务 MCP 联合

[业务桥联合实验](实验/20261114_当前执行计划与私有业务MCP联合验证/README.md)最终 B01–03 通过；实际 Codex／Claude 在同一逻辑 task 下，经当前候选程序化 owner／执行计划、原生 stdio MCP、现有单次票据／内核 peer／私有 broker／R17／ToolService 完成两次合成只读。每端先成功，再运行中停用；拒绝进入后续模型请求且不执行 handler，冻结计划不变。换 Provider 后旧工具入口和旧桥创建分别拒绝，最终所有租约释放。

首批驱动错误预期旧桥拒绝码为 SCOPE_DENIED，实际按源码为 CANCELED；仅修正断言后重跑，保留失败。两批四个 native 已结束；最终六次本机模型请求、两份桥证明、两条 succeeded／attempt_count=1 调用账。未验证真实业务 handler、父子树、在途中断、崩溃或 UI。已补技术方案 §9.4。

'''
def ledger(t):
 assert '### 4.64 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q04','Q09','Q27','Q28']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.64 补当前程序化计划／两端原生私有 MCP／R17／调用账和换 Provider 旧身份拒绝；真实业务 handler 与崩溃仍待验 |'
 t='\n'.join(lines)+'\n';t=t.replace('继续补真实程序化 owner／业务桥与实际业务上下文联合','§4.64 已补当前程序化 owner／计划与两端真实私有桥、R17 和合成读；继续补实际业务 handler／上下文及在途操作联合');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：当前程序化执行计划已与 Codex／Claude 原生私有 MCP、内核身份、现有 R17 和工具调用账联合验证；实时停用有效，换 Provider 后旧运行权限不复活，见[技术方案 §9.4](技研/技术方案.md)。业务 handler 仍是合成只读，产品未改。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：沿已接通的私有桥补实际业务上下文／handler 与在途操作，继续回执持久化和宿主退出恢复；其他责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
