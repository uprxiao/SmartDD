import assert from 'node:assert/strict';
import {createInterface} from 'node:readline';
import {appendFileSync,mkdirSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {query} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {deferred} from './launch.mjs';
export function native(out,f,c,io){return(spawn,prepared)=>{
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});const log=(kind,x)=>appendFileSync(out+'/'+c.id+'-'+kind+'.jsonl',JSON.stringify(x)+'\n'),done=deferred();
 if(c.driver==='claude'){
  const input=deferred(),end=deferred(),uid=randomUUID(),cleanup=[];
  const q=query({prompt:(async function*(){await input.promise;yield{type:'user',uuid:uid,parent_tool_use_id:null,session_id:'',message:{role:'user',content:'Use the isolated HTTP MCP form once.'}};await end.promise;})(),options:{pathToClaudeCodeExecutable:prepared.executable,cwd:f.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:prepared.env,mcpServers:{wy:{type:'http',url:c.mcpUrl,headers:{Authorization:'Bearer synthetic-mcp-only'}}},allowedTools:['mcp__wy__wy_form'],hooks:{ElicitationResult:[{hooks:[async value=>{log('elicitation-result-hook',value);c.hooks.push(value);return{};}]}]},onElicitation:async(request,options)=>{
   const d=deferred();cleanup.push(()=>d.resolve({action:'cancel'}));log('elicitation',{request,requestId:options.requestId,signalAborted:options.signal.aborted});options.signal.addEventListener('abort',()=>{c.signalAborted=true;log('elicitation-abort',{requestId:options.requestId});},{once:true});
   io.request(request,{id:options.requestId,namespace:'claude:wy',turnId:null},async value=>{d.resolve(value);return'unknown';});return d.promise;
  },spawnClaudeCodeProcess:o=>spawn(o.command,o.args,{cwd:f.snapshot.native.cwd,env:prepared.env})}});
  const consume=(async()=>{try{for await(const m of q){log('native',m);if(m.type==='result'&&m.user_message_uuid===uid)done.resolve(m);}}catch(e){log('consumer-error',{message:e.message});done.reject(e);}})();
  return{ready:()=>q.initializationResult(),begin:()=>input.resolve(),interrupt:()=>q.interrupt(),done:done.promise,consume,close:()=>{end.resolve();q.close();for(const f of cleanup)f();}};
 }
 const child=spawn(prepared.executable,['app-server','--disable','plugins','-c','analytics.enabled=false','-c','thread_unload_delay_secs=0','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(c.modelUrl+'/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}','-c','mcp_servers.wy={url='+JSON.stringify(c.mcpUrl)+',bearer_token_env_var="WY_MCP_TOKEN",default_tools_approval_mode="approve"}'],{cwd:f.snapshot.native.cwd,env:prepared.env}),pending=new Map();let sequence=0,thread,turn;
 const rpc=(method,params)=>{const id=++sequence,d=deferred();pending.set(id,d);const frame={id,method,params};log('requests',frame);child.stdin.write(JSON.stringify(frame)+'\n');return d.promise;};
 createInterface({input:child.stdout}).on('line',line=>{try{const m=JSON.parse(line);log('native',m);
  if(m.method&&m.id!==undefined){assert.equal(m.method,'mcpServer/elicitation/request');assert.equal(m.params.threadId,thread);if(turn)assert.equal(m.params.turnId,turn);io.request(m.params,{id:m.id,namespace:'codex:'+m.params.threadId+':'+m.params.serverName,turnId:m.params.turnId??null},async value=>{assert(child.exitCode===null&&child.signalCode===null,'NATIVE_NOT_LIVE');log('response-write',{id:m.id,result:value});child.stdin.write(JSON.stringify({id:m.id,result:value})+'\n');return'unknown';});return;}
  if(m.id!==undefined){const d=pending.get(m.id);assert(d,'UNMATCHED_REPLY');pending.delete(m.id);m.error?d.reject(Error(JSON.stringify(m.error))):d.resolve(m.result);}
  if(m.method==='serverRequest/resolved')c.closedRequests.push(m.params);
  if(m.method==='turn/completed')done.resolve(m.params.turn);
 }catch(e){done.reject(e);}});
 child.stderr.on('data',b=>appendFileSync(out+'/'+c.id+'-stderr.log',b));child.once('exit',()=>{for(const d of pending.values())d.reject(Error('NATIVE_EXIT'));pending.clear();});
 return{ready:async()=>{const r=await rpc('initialize',{clientInfo:{name:'m14_request_scope_probe',version:'1'},capabilities:{experimentalApi:true}});child.stdin.write('{"method":"initialized"}\n');return r;},begin:async()=>{const t=await rpc('thread/start',{cwd:f.snapshot.native.cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'on-request',sandbox:'read-only'});thread=t.thread.id;const v=await rpc('turn/start',{threadId:thread,clientUserMessageId:randomUUID(),input:[{type:'text',text:'Use the isolated HTTP MCP form once.',text_elements:[]}]});turn=v.turn.id;},interrupt:()=>rpc('turn/interrupt',{threadId:thread,turnId:turn}),done:done.promise,consume:Promise.resolve(),close:()=>child.stdin.end()};
};}
