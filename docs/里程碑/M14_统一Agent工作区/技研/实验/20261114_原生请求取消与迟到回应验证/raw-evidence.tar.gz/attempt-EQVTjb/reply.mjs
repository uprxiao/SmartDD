import{randomUUID}from'node:crypto';
export function reply(res,driver,body,decision){
 res.writeHead(200,{'content-type':'text/event-stream'});const e=(type,obj)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...obj})}\n\n`),call=!!decision.tool;
 if(driver==='claude'){
  e('message_start',{message:{id:'m'+randomUUID(),type:'message',role:'assistant',model:body.model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});e('content_block_start',{index:0,content_block:call?{type:'tool_use',id:'toolu_'+randomUUID(),name:decision.tool.name,input:{}}:{type:'text',text:''}});e('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(decision.args)}:{type:'text_delta',text:decision.text}});e('content_block_stop',{index:0});e('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});e('message_stop',{});
 }else{
  const rid='r'+randomUUID(),item=call?{id:'fc'+randomUUID(),type:'function_call',call_id:'call'+randomUUID(),name:decision.tool.name,...(decision.tool.namespace?{namespace:decision.tool.namespace}:{}),arguments:JSON.stringify(decision.args),status:'completed'}:{id:'m'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:decision.text,annotations:[]}]};e('response.created',{response:{id:rid,status:'in_progress',output:[]}});e('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});if(!call)e('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:decision.text});e('response.output_item.done',{output_index:0,item});e('response.completed',{response:{id:rid,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
 }res.end();
}
