from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生请求取消与迟到回应验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and not r.get('error');a=Path(r['out']);sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s
 for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.ts','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
assert (root/'request-contract.mjs').read_bytes()==Path('/private/tmp/willyou-m14-contract-probe/contract.mjs').read_bytes()
c=json.loads((a/'cleanup.json').read_text());assert all(x['state']['runState']=='stopped'for x in c['cleanup']);assert len(c['nativeExits'])==4;assert {x['id']:x['code']for x in c['nativeExits']}=={'codex-old':0,'codex-current':0,'claude-old':143,'claude-current':143};assert all(x['signal']is None for x in c['nativeExits'])
requests=json.loads((a/'native-requests.json').read_text());byId={x['id']:x for x in requests};assert len(requests)==4 and sum(x['modelCount']for x in requests)==6
accepted={'label':'isolated-choice','count':2,'enabled':True}
for driver in ['codex','claude']:
 old,new=byId[driver+'-old'],byId[driver+'-current'];assert old['sendCount']==0 and new['sendCount']==1;assert old['toolResults']==[{'action':'cancel'}]and new['toolResults']==[{'action':'accept','content':accepted}];assert old['generation']==1 and new['generation']==2 and old['requestId']!=new['requestId']
 db=sqlite3.connect(a/(driver+'-final.sqlite'));assert db.execute("select count(*)from capability_runs where state not in ('stopped','failed')").fetchone()[0]==0;assert db.execute("select count(*)from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;db.close()
assert byId['codex-old']['identity']['id']==byId['codex-current']['identity']['id']==0
for name in ['codex-old','codex-current']:
 q=byId[name];assert len(q['closedRequests'])==1 and q['closedRequests'][0]['requestId']==0 and 'action'not in q['closedRequests'][0]
assert byId['claude-old']['signalAborted'];terminal=json.loads((a/'claude-old-terminal.json').read_text());assert terminal['is_error']and terminal['terminal_reason']=='aborted_tools'
hook=byId['claude-current']['hooks'];assert len(hook)==1 and hook[0]['action']=='accept'and 'elicitation_id'not in hook[0]and 'requestId'not in hook[0]
db=sqlite3.connect(a/'requests.sqlite');states=[json.loads(x[0])['state']for x in db.execute('select body from requests')];assert sorted(states)==['expired','expired','unknown','unknown'];assert db.execute('select count(*)from responses where state=\'unknown\'').fetchone()[0]==2;db.close()
runtime={'attempt':a.name,'checksPassed':4,'nativeExits':c['nativeExits'],'requests':requests,'requestStates':states,'localModelRequests':6,'supplierModelCalls':0,'nativeUsageCostFields':'Native cost fields are estimates from synthetic token usage, not supplier billing.','scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/run-registry.ts',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts',Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts'),Path('/private/tmp/willyou-m14-contract-probe/contract.mjs')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'versions':{'codex':'0.167.1','claudeSdk':'0.3.321','claudeNative':'2.1.321'},'variants':'Existing programmatic run/session/plan variants and unchanged earlier candidate request kernel; actual private run check before native callback. No product edits.','t3SourceOnly':'RuntimeRequestService gates resolved request and exact live providerSessionId. Source comparison, not executed T3 UI/service.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.variant','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 原生请求取消、迟到回应与请求关闭语义

2026-11-14；R02／03／08／10／12，Q01／04／11／12／27／28／43。技术方案 §4.4.1，验证账 §4.60。仅技术研究，产品和共享原型未改。

## 联合范围

Codex 0.167.1 与 Claude SDK 0.3.321／native 2.1.321 经实际 HTTP MCP 发起表单；沿用程序化私有 run、ExecutionPlan、gated launcher，回应前再核实际 run。复用先前规范请求候选 Kernel，包括完整作用域、typed native ID、revision、commandId、字段校验和私有 UI 句柄。本机固定模型选工具，合成表单不包含真实用户输入。

每个 Provider 独立一个逻辑 task，先中断 generation 1，再打开 generation 2。两个新运行同时持有表单，用于跨 Provider 作用域拒绝；不是同一 task 的 A→B 历史交接，不是完整父子树。没有真实 renderer IPC 或业务审批。

## {a.name}：E01–E04

| 检查 | 证据 |
| --- | --- |
| E01 | Codex 待回应时先撤销候选 live callback，再真实 turn/interrupt；回合 interrupted，MCP 收到 cancel。排空后新 generation 的原生 RPC id 仍为数字 0，但宿主 requestId 不同，旧回应和直接旧 send 均拒绝 |
| E02 | Claude 待回应时同样撤销 callback 并 query.interrupt；原 options.signal 实际 aborted，匹配 result 为 error_during_execution／aborted_tools，MCP 收到 cancel；排空后下一 generation 使用新 callback，旧回应拒绝 |
| E03 | 两个新 Provider 请求同时 pending。跨 Provider scope、旧 run requestId、count 超范围和伪造 UI 句柄均拒绝，原生发送数为零 |
| E04 | 各自合法回应发送一次；重试同 commandId 不再次发送；真实 MCP 收到 accept 和精确 content，随后原生模型请求含工具结果，两个回合完成。候选适配器不把 write／Promise resolve 当 applied，收据保留 unknown |

四个捕获原生退出：Codex 两次 code 0，主动关闭 Claude 两次 code 143；所有 run stopped、租约 released。六次本机模型请求，零供应商调用。原生 JSON 中的 costUSD 是对合成 token 数的本地估价，不是实际模型收费。

## 决定性的反例

**Codex 的 serverRequest/resolved 在取消与正常接受两条路径都出现。** 两条通知都只含匹配 threadId 和 requestId，没有答案／action／接受原因；单独看到它不能认定用户已同意或原答案被接受。两个进程重用数字 0 也实证了不能全局按原生 ID 寻址。

**Claude form 的 ElicitationResult hook 本轮没有 elicitation_id 或控制 requestId。** 它含 session、prompt_id、serverName、action 和 content。SDK 类型把 elicitation_id 作为可选值，说明 hook 发生在结果发给 MCP 之前；本批只观察一张表单，未验证同 server／prompt 并发时的唯一对应，不能把该 hook 单独当所有表单的精确回执。

协议存在结果信号不等于所有信号可直接映射 applied。回调已关闭／请求不再等待、宿主记下的用户选择、对应回应是否被原生消费、后续业务是否成功，是不同事实。

## 对设计的约束

保留三部分：决定记录（commandId、摘要和来源）、投递记录（回调／连接代次及证据）、请求活性（pending／关闭／取消）。宿主知道用户选了什么，不等于知道远端接受了什么；请求结束不构成新的插件、邮件或浏览器授权。

本批复用 Kernel 的状态较粗，故适配器发送后返回 unknown；这是保守探针，不是要求产品每次正常回答都弹人工恢复。正式投影可结束已经可靠关闭的等待卡片，同时保留“已提交，是否生效未确认”的投递诊断；禁止自动重发，并按实际操作账与切换门禁继续处理。最终三维 Schema／迟到信号对账尚未实现和验证，不能把本轮通过称为所有回应恢复已完成。

停止顺序为先撤销宿主 callback／回应入口，再中断原生并排空，最后失效旧运行身份。只更新 UI 状态或仅依赖 SDK 的 abort signal 均不足以替代当前私有 run 检查。取消回包与原用户批准必须区分；内部 cleanup 返回 cancel 不产生用户许可。

## 尚未覆盖

原生命令／文件写审批的所有 decision、同一原生会话多个并发表单、URL／复杂字段、用户提交与取消同时越过发送边界、部分回包、宿主崩溃、已投递结果的最终对账、真实 UI 和父子委派链未在本批通过。actual MCP 接受的观察来自隔离服务，不能假定产品能读取第三方服务器内部状态。T3 仅源码对照其 live providerSessionId／pending callback 边界，未执行 T3 服务或 UI。

## 证据

[结果](result.json)、[运行／信号审计](runtime-audit.json)、[源码基线](source-review.json)、[哈希清单](archive-manifest.json)、[驱动、协议帧及数据库](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性与外键通过、{len(sources)} 个唯一构建输入复核。

在隔离 HOME 和本机端点复跑 build.mjs、profile-build.mjs、probe.mjs。所有进程由启动句柄停止，不向日常 Agent 会话发送测试回应。
''')
section='''#### 4.4.1 请求关闭、回应投递与决定的区别

[原生取消／迟到回应实验](实验/20261114_原生请求取消与迟到回应验证/README.md)把现有请求候选、程序化私有 run 接到两端真实 HTTP MCP 表单。先撤销旧 callback 再原生 interrupt，两个 MCP 都收到 cancel；旧回应被拒绝，新 generation 可重新提问。两个 Provider 同时 pending 时，跨 scope、原生 ID 重用、无效字段和重复 commandId 的隔离已有实证；不是全部原生命令审批或完整父子链。

| 事实 | 可使用的含义 | 不得推断 |
| --- | --- | --- |
| 宿主决定收据已提交 | 知道用户选择及其原请求／来源，可以幂等返回原决定 | 原生已消费、外部操作已获授权或已成功 |
| 回调 Promise resolve／stdin.write | 宿主尝试投递对应回应 | 已消费／applied，或失败时可以自动重发 |
| Codex serverRequest/resolved | 匹配连接／thread／原生 ID 的请求已结束；需再看原决定和取消状态 | 用户已批准；本轮取消与 accept 都发同类通知 |
| Claude ElicitationResult hook | 原生处理到了表单结果、尚在发给 MCP 前；保留实际关联字段 | 所有 form 都带唯一控制请求 ID；本轮没有 elicitation_id／requestId，不能用同 server／prompt 猜并发归属 |
| 对应业务操作账 | 操作自己的 not-started／unknown／completed 等事实 | 单凭请求已结束就补造业务成功或回滚 |

正式合同分别保存 decision、deliveryEvidence 和 request liveness。已有 applied 字段只用于有明确对应及消费证据的路径，不能由通用 resolved 通知或 SDK 回调返回直接填入。无法唯一对账的投递保留未确认，禁止自动重发；关闭已失效等待入口与是否允许继续／切换按实际运行和业务账分别判断。

探针沿用旧 Kernel，所以合法发送也保守记 unknown；这不是产品必须让每次表单都手工恢复的设计。统一 UI 可显示“请求已结束／回应已提交，生效未确认”，仍保留原决定和操作状态。三维 Schema、已发回应与取消的竞争及恢复对账仍需补验；不得用界面结束等待消除未知副作用。

'''
def tech(t):
 assert '#### 4.4.1 'not in t;return t.replace('### 4.5 长输出、背压与存储失败',section+'### 4.5 长输出、背压与存储失败')
edit(base/'技研/技术方案.md',tech)
record='''### 4.60 原生 HTTP MCP 请求取消、迟到回应与关闭信号

[原生请求实验](实验/20261114_原生请求取消与迟到回应验证/README.md)E01–E04 通过：请求候选和实际私有 run 接入两端真实表单，中断后 MCP 收到 cancel、旧发送拒绝，下一 generation 重新取得 callback。跨 Provider 同时 pending 的作用域、无效字段和重复命令均核验；六次本机模型请求、四个捕获原生退出，运行／租约排空。

关键反例：Codex 取消与 accept 都发 serverRequest/resolved，因此该通知不能单独作为批准／消费证明；Claude 本次 form 结果 hook 不带唯一控制请求 ID。§4.4.1 据此拆清决定、投递证据和请求活性。探针正常发送仍保守 unknown，没有冒充最终投递对账；独立 task、合成模型／窗口，不替代同任务切换、业务审批、真实 UI 或崩溃链。产品与原型未改。

'''
def ledger(t):
 assert '### 4.60 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q01','Q04','Q11','Q12','Q27','Q28','Q43']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.60 补实际表单 interrupt／旧回应隔离及 resolved 反例，投递对账和真实 UI 未闭环 |'
 t='\n'.join(lines)+'\n';t=t.replace('两端权限档位、原生子 Agent 可控边界','§4.60 已补真实表单取消／迟到与关闭信号反例，继续核验三维回应账、并发与原生命令审批；两端权限档位、原生子 Agent 可控边界');t=t.replace('原生回调与递归取消未证','§4.60 已补原生 form 回调，递归取消与已发回应对账未证');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：两端真实 HTTP MCP 表单已接程序化 run，补中断、旧回应和新 generation 隔离；确认 Codex resolved 不等于批准，见[技术方案 §4.4.1](技研/技术方案.md)。决定、投递证据和请求活性分开；仅技术研究，完整对账／UI 未闭环。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：围绕已确认的请求信号边界验证最终回应账与发送／取消竞争，再补自动通知竞争和业务私有桥联合；不重复已通过的正常初始化／表单。其他设计责任按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
