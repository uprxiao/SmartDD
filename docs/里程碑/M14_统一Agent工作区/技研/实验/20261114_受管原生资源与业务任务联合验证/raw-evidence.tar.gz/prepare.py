from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_受管原生资源与业务任务联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and not r.get('error');a=Path(r['out']);sources={}
for name in ['build.json','profile-build.json']:
 b=json.loads((root/name).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[s['path']]=s
 for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.ts','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
attempts=[];allExits=[]
for d in sorted(root.glob('attempt-*')):
 result=json.loads((d/'result.json').read_text());cleanup=json.loads((d/'cleanup.json').read_text());assert all('error'not in x and x['state']['runState']=='stopped'for x in cleanup['cleanup']);allExits+=cleanup['nativeExits'];attempts.append({'attempt':d.name,'passed':result['passed'],'error':result.get('error'),'exits':cleanup['nativeExits']})
assert len(allExits)==5;final=json.loads((a/'cleanup.json').read_text())['nativeExits'];assert [(x['id'],x['code'],x['signal'])for x in final]==[('codex',0,None),('after-spawn',73,None),('claude',143,None)]
f=json.loads((a/'fixture.json').read_text());db=sqlite3.connect('file:'+f['db']+'?mode=ro',uri=True);assert db.execute("select count(*) from capability_runs where state not in ('stopped','failed')").fetchone()[0]==0;assert db.execute("select count(*) from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;db.close();verified=0
for driver in ['codex','claude']:
 manifest=json.loads((a/(driver+'-manifest.json')).read_text());target=Path(f['storeRoot'])/f['runtimes'][driver]['resource']['relativePath']
 for item in manifest['files']:
  p=target/item['path'];h=hashlib.sha256()
  with p.open('rb')as stream:
   for chunk in iter(lambda:stream.read(262144),b''):h.update(chunk)
  assert h.hexdigest()==item['sha256']and p.stat().st_size==item['size'];verified+=1
runtime={'finalAttempt':a.name,'attempts':attempts,'totalCapturedExits':len(allExits),'finalExits':final,'verifiedNativeFiles':verified,'nativeModelTurns':0,'businessCalls':'Host invokes actual ToolService with a synthetic read executor; not SDK-origin MCP or real external business access','scope':'Temporary programmatic source variants, actual run/R17/ToolService/profile services, streamed native package and gated launch. No product implementation or GC deletion.'};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/run-registry.ts',repo/'src/main/core/applications/tool-service.ts',repo/'src/main/core/applications/current-authorization.ts',repo/'src/main/core/ai/ai-profile-service.ts',t3/'apps/server/src/provider/CodexInstallation.ts'];review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Build retains prior programmatic scope/source/run variants; changes are isolated delivery/execution/native proof helpers. Source variants are not product changes.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','data','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.variant','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)]and c.execute('pragma foreign_key_check').fetchall()==[];c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 受管原生资源接入业务任务：联合技术验证

2026-11-14；R01／02／08／10／11，Q01／03／09／48／51／52／53／54；技术方案 §12.1、验证账 §4.54。临时源码变体和独立 SQLite，不是产品开发或正式验收。

## 路径与结果

沿用 §4.47 的程序化 scope、来源修订、实际 CapabilityRunRegistry、配置修订、v1 ApplicationRunPlan、交付准备与门控启动候选。此前 managed ExecutionPlan 虽有类型，却没有把 native 根加入交付引用；基线实际拒绝 RUNTIME_NOT_PINNED，不能凭类型存在宣称已支持受管程序。

候选在同一事务写交付资源引用与 ExecutionPlan，将 adapter 和完整 native 包作为独立根。启动时先将准备资源交给实际 run 租约，核验全部成员后才释放准备占用。native 清单在事务外流式复核；进程内证明保留完整文件集合与 inode／大小／模式／时间身份，启动前和 gated 子进程附着后再短检查，避免在 C 锁／业务事务里反复整读数百 MiB。SDK JS 依赖仍是隔离环境固定包，未纳入新 native 包的资源闭包。

| 检查 | 证据 |
| --- | --- |
| M01 | 旧候选缺 native 交付引用，拒绝且事务回滚 |
| M02 | after-pins／after-plan 注入异常，交付、引用和执行计划共同回滚；正常重试固定原计划，换版本拒绝；准备完成时 native 仍由交付记录持有，尚未冒充 run 接管 |
| M03 | 受管 Codex 真实初始化，native 进入实际业务 run 租约；宿主调用实际 ToolService 的合成只读执行器成功；关闭项目应用后下一调用 APP_NOT_ENABLED，原 v1 计划不变；退出后释放 |
| M04 | after-arm 时将辅助 rg 换成相同字节但不同 inode，主程序未变；完整文件身份检查拒绝，spawnCount=0 |
| M05 | gated wrapper 已创建后替换 rg，附着后的检查拒绝，payloadReleased=false；只退出捕获的等待进程，run 排空 |
| M06 | Claude SDK 0.3.321 从受管 2.1.321 路径初始化，同一 run 保有业务上下文及 native 租约；结束后释放，无模型回合 |

最终 {a.name} 六项通过。最终三个捕获进程：Codex code 0；被阻止的等待 wrapper code 73；主动取消的 Claude code 143。后两者是预期停止，不写成正常完成模型任务。最终全部 run stopped、run 租约 released。两端原生包共 {verified} 文件事后逐一重算摘要，未把受管目录缺失或恢复后的错误内容藏起来。

## 未完成尝试

attempt-Da3SWa：M01–M02 通过，M03 已返回真实 status=ok，驱动却检查 response.ok，因字段错误失败。修正驱动，不修改 ToolService。

attempt-rSCv8p：M01–M03 通过，M04 故障注入误写 bin/rg，实际包路径是 codex-path/rg，ENOENT 不能算晚变更防护通过。改为从固定清单找辅助程序后重跑。每次新运行准备重新流式建立文件身份，避免把故障恢复造成的 ctime 变化当成旧证明仍有效。三次尝试共五个捕获退出回执，原失败与数据库都保留。

## 对设计的意义及边界

原生生命周期 guard 与完整业务 run 不是同一种授权。本批已将 native 接到原程序化业务候选，不要求撤掉 R17、Skill／MCP 的业务桥合同。任务、能力来源、配置修订、应用计划、运行资源与实际子进程仍分别绑定；更换 provider 不能靠重用另一个 run 的私有句柄完成。

run 本身先预留，随后交付引用与 ExecutionPlan 原子生成。正式启动入口必须统一要求完整执行计划和资源接管，不能存在只看到 run=prepared 就直接 fork 的旁路。前置异步校验尚未持有安装／准备租约时，清理竞争可导致准备失败，不能从本批推导该窗口已有无中断可用性保证。

准备→run 交棒已测，但执行计划的长期历史保留、跨宿主重新建立文件证明、默认版本变化与任务接受时的绑定政策、真实 GC 的删除／恢复仍待联合。门控放行后到内核 exec 之间不声称 OS 级文件封存；本机 metadata 校验不能等同全平台防替换保证。

M03 是宿主使用已认证 run 调用实际 ToolService，执行器为合成只读返回；不是模型通过私有 MCP 发起浏览器、邮件或插件操作。没有真实账号、外部业务写入或模型费用；完整原业务回归和 SDK-origin MCP 链继续独立核验，不以本批替代。

T3 的安装／启动资源分层仍是参考，WillYou 需保留自身业务权限与持久资源关系。本批不修改 T3，也不将其机制直接当作 WillYou 已集成。

## 证据

[结果](result.json)、[运行与失败审计](runtime-audit.json)、[源码基线](source-review.json)、[证据摘要](archive-manifest.json)、[驱动、源码变体及数据库](raw-evidence.tar.gz)。{len(files)} 归档文件、{len(dbs)} 份 SQLite 完整性／外键通过、{len(sources)} 个唯一构建输入复核。大 native 二进制不重复入库。

复跑需在新临时目录恢复依赖、路径和进程身份 helper，先 build.mjs 与 profile-build.mjs，再 probe.mjs。配置使用合成值和隔离 HOME；故障只改本轮受管副本，取消只操作自己捕获的进程。不能将研究候选当作产品安装器运行。
''')
def tech(t):
 anchor='当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、真实磁盘耗尽、带业务授权的完整 run 资源联合、真正的原生 GC／删除恢复、原生文件晚变更到 fork 的联合封装、完整 App／系统重启、历史格式兼容或目标平台安装。'
 new='''[受管资源与业务任务实验](实验/20261114_受管原生资源与业务任务联合验证/README.md)进一步接入程序化业务 run：交付准备把 adapter 与完整 native 包作为独立根，与 ExecutionPlan 同事务写入；启动前接到实际 run 租约，核对后释放准备占用。真实 Codex／Claude 初始化通过；宿主通过实际 ToolService 调合成只读执行器成功，关闭应用后的下一调用被 R17 拒绝，原应用计划保持不变。该证据不是模型发起的 MCP 或完整业务回归。

native 全文件清单在业务事务外流式复核，执行计划的活读和门控放行只做固定文件身份检查。辅助 rg 在 arm 后、或等待 wrapper 创建后被相同字节替换，两窗口都拒绝；分别未创建进程、未放行 native。只有运行代码 ready 不足以启动，正式入口必须同时要求执行计划、确切资源准备／接管及当前授权，关闭只凭 run=prepared 直接 fork 的旁路。文件证明不可跨进程直接复用，重启需依据原固定清单重建；门控释放后不宣称 OS 级执行封存。

当前仍未证明公网 HTTPS／企业代理、其他 archive 变体／极端预算、下载或复制中途退出、未记录准备目录清理、真实磁盘耗尽、受管程序发起业务 MCP 的完整链、跨宿主重建与历史资源保留、真正的原生 GC／删除恢复、完整 App／系统重启、历史格式兼容或目标平台安装。'''
 assert anchor in t;return t.replace(anchor,new)
edit(base/'技研/技术方案.md',tech)
section='''### 4.54 受管 native 与程序化业务 run 联合

[联合实验](实验/20261114_受管原生资源与业务任务联合验证/README.md)M01–M06 将独立 native 根加入交付准备／ExecutionPlan 同事务，启动时转入实际 run 租约。真实 Codex／Claude 初始化成功；宿主通过实际 ToolService 调合成只读执行器成功，随后禁用应用被 R17 拒绝，固定 v1 计划不变。原生包流式完整校验在事务外，启动前和 gated wrapper 附着后再做文件身份复核；辅助 rg 的相同字节替换两窗口都阻止放行。

原基线因缺 runtime pin 拒绝，候选补齐；准备／计划故障回滚、重复计划和版本替换拒绝有证据。两次未完成尝试分别为驱动检查错返回字段、故障注入用错 rg 路径，保留失败后修正；最终 attempt-bIScVV 六项通过，三次共五个捕获进程均有退出回执。

仅证明上述业务候选链，不是模型经 MCP 调实际外部业务。跨宿主文件证明、历史资源保留、默认版本接受政策、最终 GC／删除恢复和门控释放后的内核封存仍未覆盖。技术方案 §12.1 已同步，产品与原型均未改。

'''
def ledger(t):
 assert '### 4.54 'not in t;t=t.replace('## 5. 失败与驱动修正',section+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q01','Q03','Q09','Q48','Q51','Q52','Q53','Q54']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.54 补受管 native／业务 run／R17 与两处晚变更启动防护，完整 MCP 与 GC 仍待证 |'
 t='\n'.join(lines)+'\n';t=t.replace('公网 HTTPS／代理、复制中途、业务 run 资源联合、实际原生清理及遗留准备清理仍待证。','§4.54 补受管 native 与业务 run／R17、启动晚变更联合；公网 HTTPS／代理、复制中途、完整业务 MCP、跨宿主／历史引用及实际原生清理仍待证。');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补受管 Codex／Claude 到程序化业务 run、交付资源接管、真实初始化和 R17 的联合验证，见[技术方案 §12.1](技研/技术方案.md)。辅助程序在两处启动窗口被替换均拒绝放行；未把宿主合成只读调用算成完整业务 MCP。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：优先按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)收口 Provider 切换与多 Agent 的跨宿主输入／结果对账和协议合同；资源历史／GC、原业务 MCP、平台、性能及界面状态设计仍保留。复用已有证据，避免重复局部验证；当前只做研究与设计，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
