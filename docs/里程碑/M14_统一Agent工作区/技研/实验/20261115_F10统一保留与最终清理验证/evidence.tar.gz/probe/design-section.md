### 3.2.17 统一保留查询与按资源种类清理（F10）

F10 按[当前实验与来源审计](实验/20261115_F10统一保留与最终清理验证/README.md)研究关闭。公共命令仍为 P1.2；共同关系实验基线由 C1.5 增量为 **C1.6**，保留之前全部表／触发器，增加安装默认与 attempt 关系、内容描述索引、短期读取租约、冻结目录索引、发布代次及清理意图。原 C1.1–C1.5 不是另一个可任选的实现版本。C1.6 是研究合同及隔离数据库，不是已发布的产品迁移；正式迁移／业务接线仍按 A 用例。

**职责。** 设置一个宿主 `RetentionQuery` 服务：在调用者持有的资源协调范围和同一 SQLite 读取视图内，返回资源身份、保留理由、依赖闭包、无法判定项和依据修订。版本列表／预览、准备／引用提交、清理最终检查、恢复共同调用；每个物理资源仍由其原归属服务校验和处理。查询不签发权限，不调用 Agent，不打开邮件附件或遍历项目代码。F08 的业务只读判定复用，不能再复制一套“run stopped 就完成”的简化状态判断。

| 来源 | 保留规则与责任 |
| --- | --- |
| 旧会话与所有 binding／cap 修订 | 读取原 refs 和新 m14_ref；current pointer 不是全部历史。tombstone 继续保留必需原字节。核快照 hash、完整必需集合及 kind／hash／路径，缺 cap、未映射或损坏历史返回待核查；合法 planned 不制造占用 |
| 准备、交付、执行 | preparing 内容与必需 refs 原子固定；prepared／adopted 交付按确切资源集合保留；完整读取租约根及成员。scope 尚未 drained、coverage unknown、revision 不相符或 workspace hold 未释放时，不因旧 lease 已标 released 就释放执行依赖；恢复记录缺失不能当零引用 |
| 安装与默认项 | 当前 native 默认、未结束安装 job／attempt 保留其已发布资源；尚未发布的 stage 继续由原 attempt 归属和恢复机制处理。默认升级不改历史与正在使用的精确版本，外部 CLI 只登记路径与诊断，宿主不删除其文件 |
| 内容与读取 | transfer、draft、不可变 submission 分别是根。reference 描述索引核 contentHash、token、task、revision，并保留其依赖内容闭包；索引与 ready 对象发布同事务提交，实际字节仍由原内容存储核 hash。准备读取、viewer／附件传输取得宿主签发短期读取句柄；关闭窗口只结束已确实完成的读，未知读保留。句柄副本、可猜 hash、序列化 owner 均不构成读取授权 |
| 独立业务 | 调用／数据操作、浏览器、邮件事实与人工核实、活动来源及 F08 deletion gap 一起参加查询依据。未决业务通过其原 package、run／lease 成员及历史 task 关系映射资源；不能因主 run 停止或 lease 标签已释放丢掉未决依据。无法映射则保留并诊断，不猜成无依赖。已知无关资源仍可清理；人工核实只改变业务结论，不签发执行许可 |
| 外部插件与 Skill | 安装、生命周期过渡、插件运行租约继续保护插件包。冻结 Skill 是独立的已复制产物，按真实 run scope 和读者保留；仅凭 capability_runs.stopped 不够。历史 launch 的审计字段不自动成为原包永久引用；如恢复确实依赖原包，必须持有明确的准备／历史依赖。已完整冻结的副本不反向强制保留原插件包 |
| R16 共享 Skill 库 | 继续按当前选择同步受管条目；不是不可变资源垃圾回收对象。历史保留原内容／摘要及必要来源，不把每一版共享目录路径永久钉住。同步／删除只处理原 owner marker 的条目，用户同名内容仍报冲突；使用具体冻结路径的读取者归冻结资源租约 |

**共同状态与顺序。** 资源登记可读且完整 → 清理意图持久化并标 deleting → 校验原归属和字节 → 删除 → removed。上下文表保持既有 staged／ready／missing／invalid 枚举，通过清理意图区分“已知回收”与“意外缺失”，统一查询对外返回 deleting／removed；不能把 missing 一律当清理成功。插件包记录保留到物理清理结束，删除后仍保留清理 tombstone 与原归属证据。同 hash 重新发布也是新物理代次：原发布服务在共同登记事务中递增 publicationRevision，清理意图精确绑定该代次；仅同资源的未结束清理唯一，终态意图可保留多份。旧 tombstone 不覆盖新 ready 代次，旧预览／恢复不能操作新文件；不得删掉旧意图来假装第一次安装。新引用／读者／启动者须在同一协调顺序与短写事务中检查状态及身份；deleting 后拒绝。历史发布、配置修订变化或任一来源增删改使旧预览失效。

最终守卫必须紧邻物理变更，在共同 C 协调范围与 `BEGIN IMMEDIATE` 下重新查询；不得在查询和 unlink 之间释放写事务或 await。大文件 hash／复制先在事务外流式完成，进入短事务后核原 owner、根与父目录、精确文件身份／代次和当前保留理由。已标 deleting 后异常新增引用时，正常删除与恢复都停在待核查，保留尚存文件；没有新引用且最后真实占用释放后可继续完成，不能以永久拒绝代替正确生命周期。强行绕过所有宿主入口、在某文件已经物理删除后插入伪引用不能恢复已删除字节；此时保留原失败事实，绝不把不完整资源恢复 ready。

| 当前物理入口 | M14 接法与恢复边界 |
| --- | --- |
| ResourceGraphMaintenance.plan／cleanup／assertRows／finish／recover | 现有应用包图、依赖、归属恢复与删除顺序保留；统一查询进入 planHash、最终事务和每次物理删除前，正常／恢复不另写保留逻辑。现有 cleanup 已有意图、quarantine、取消及 owner claim，不重做调度器 |
| PluginLifecycle 的 rollback／finishCleanup → PluginPackageStore.removeUnused | 保留安装／停用／卸载与实时授权语义，包回收转入该插件根下的持久清理意图；继续用原 PackageStore／owned bundle 核包和 marker。包登记直到清理完成才移除，完整恢复或继续删除依据原意图；业务数据、凭据、浏览器 profile 不在该物理集合内。旧 removeUnused 的“删包行后再 rm”不原样充当新通用回收器 |
| TaskCapabilityLauncher.releaseStopped／启动恢复 → FrozenPluginSkills.release／recover | 注册冻结目录身份和执行 scope；调用共同 finisher 后检查当前读租约。正常释放与 recover 使用同一条件。物理准备失败的 stage 仍按原 marker／run 归属处理，不把未知目录顺便扫掉 |
| 新 managed native 与 context object | 独立物理适配器；native 校验可信安装清单与完整辅助文件集合，context 校验原内容 hash／大小。原 gc-tree 单文件上限 256 MiB，不能套到本次主二进制 271,011,440 字节的 native 包；采用流式校验及确定文件清单，精确文件 unlink 后可从持久意图继续。未知文件／根被替换时保留现场，禁止扩大 recursive／force 范围 |

新物理适配器沿用已验证的 store owner／进程身份及 claim 约束；恢复不得仅凭 PID 或时间自动接管。删除阶段需要原有耐久化步骤（意图提交、父目录同步、进度／终态提交）；本批 native／对象／插件原型证明同进程中断续清理和最终保留判据，没有宣称断电耐久性或实现另一套跨进程 owner 系统。正式跨进程接线继续按已有 owner 证据及 A48／53／56 验收。

**证据和停止线。** 本批 10 项关系／业务检查、4 项当前资源图检查、4 项资源种类检查通过。真实受管 native 包复制共 41 文件、366,515,155 字节，hash 分块不超过 256 KiB；未启动 Agent。原生包、内容对象、插件包和实际冻结目录均有保留／释放后的物理结果，插件目录原 owner 保持。历史安装／claim／交付故障证据复用，不新增安装平台或重新跑模型。真实 UI、所有生产写入口接线、删除任务的用户操作和平台／断电成品验收不属于本次研究退出条件；其预期保留在 A40／45／48／53／56。P08 最终复验先发现旧 tombstone 阻止同 hash 重装，再以发布代次及仅活动意图唯一约束修正；同版本重装后可再次清理，旧计划／终态恢复被拒绝，P06 同内容重新发布也可正常读取。

T3 本地 CodexInstallation 的受管／本地来源、活动版本与 leases，以及 ProviderInstallationGate 的入口协调可作为机制参考；WillYou 必须额外纳入既有业务、历史绑定、冻结产物和未知结果，不能把 T3 的 provider 安装状态直接当作 WillYou 的完整保留集合。
