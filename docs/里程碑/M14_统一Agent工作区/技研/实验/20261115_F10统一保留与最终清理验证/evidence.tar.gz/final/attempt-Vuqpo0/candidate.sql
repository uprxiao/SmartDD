CREATE TABLE m14_runtime_default(target TEXT PRIMARY KEY,resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id),revision INTEGER NOT NULL CHECK(revision>0));
CREATE TABLE m14_install_job(id TEXT PRIMARY KEY,request_hash TEXT NOT NULL,manifest_json TEXT NOT NULL,source_path TEXT NOT NULL,expected_revision INTEGER NOT NULL,phase TEXT NOT NULL,owner_instance TEXT,pid INTEGER,birth TEXT,prepared_path TEXT,result_json TEXT,recovery_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE m14_install_attempt(id TEXT PRIMARY KEY,job_id TEXT NOT NULL REFERENCES m14_install_job(id),stage TEXT NOT NULL UNIQUE,parent_identity TEXT NOT NULL,stage_identity TEXT,owner_identity TEXT NOT NULL,state TEXT NOT NULL,manifest_hash TEXT NOT NULL);

CREATE TABLE m14_context_descriptor(content_hash TEXT PRIMARY KEY REFERENCES m14_context_object(content_hash),descriptor_json TEXT NOT NULL CHECK(json_valid(descriptor_json)));
CREATE TABLE m14_frozen_resource(run_id TEXT PRIMARY KEY REFERENCES capability_runs(run_id),content_hash TEXT NOT NULL,relative_path TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN('ready','removed')));
CREATE TABLE m14_resource_publication(resource_key TEXT PRIMARY KEY,revision INTEGER NOT NULL CHECK(revision>0));
INSERT INTO m14_resource_publication SELECT 'resource:'||resource_id,1 FROM capability_resources;
INSERT INTO m14_resource_publication SELECT 'object:'||content_hash,1 FROM m14_context_object;
INSERT INTO m14_resource_publication SELECT 'plugin:'||package_hash,1 FROM plugin_packages;
CREATE TABLE m14_retention_cleanup(id TEXT PRIMARY KEY,resource_key TEXT NOT NULL,receipt_json TEXT NOT NULL CHECK(json_valid(receipt_json)),state TEXT NOT NULL CHECK(state IN('deleting','removed')));
CREATE UNIQUE INDEX m14_one_active_cleanup ON m14_retention_cleanup(resource_key) WHERE state='deleting';
CREATE TABLE m14_retention_read(id TEXT PRIMARY KEY,resource_key TEXT NOT NULL,owner_json TEXT NOT NULL CHECK(json_valid(owner_json)),state TEXT NOT NULL CHECK(state IN('active','released','unknown')));