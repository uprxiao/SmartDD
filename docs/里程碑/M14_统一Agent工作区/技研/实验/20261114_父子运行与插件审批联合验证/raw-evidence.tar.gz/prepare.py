from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_父子运行与插件审批联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==6 and r['secretReads']==0 and not r.get('error');a=Path(r['out']);sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s
 for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.ts','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
c=json.loads((a/'cleanup.json').read_text());assert all(x['state']['runState']=='stopped'for x in c['cleanup']);assert len(c['nativeExits'])==4;assert {x['id']:x['code']for x in c['nativeExits']}=={'parent-A':143,'child-B':0,'parent-C':0,'child-B2':0};assert all(x['signal']is None for x in c['nativeExits'])
pluginExits=json.loads((root/'plugin-exit-audit.json').read_text());assert len(pluginExits)==2 and all(x['observedState']=='stopped'and x['leaseState']=='closed'for x in pluginExits)
db=sqlite3.connect(a/'final.sqlite');db.row_factory=sqlite3.Row
assert db.execute("select count(*)from capability_runs where state not in ('stopped','failed')").fetchone()[0]==0;assert db.execute("select count(*)from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;assert db.execute("select count(*)from plugin_runtime_leases where state<>'closed'").fetchone()[0]==0
invocations=[dict(x)for x in db.execute('select operation_id,run_id,state,effect_state,error_code from application_invocations')];assert len(invocations)==4;assert sum(x['state']=='succeeded'and x['effect_state']=='completed'for x in invocations)==1;assert sum(x['state']=='failed'and x['effect_state']=='not-started'for x in invocations)==3
approvals=[dict(x)for x in db.execute('select approval_id,run_id,state,review_hash from plugin_write_approvals')];assert sorted(x['state']for x in approvals)==['allowed','allowed','cancelled','invalidated'];db.close();calls=json.loads((a/'plugin-calls.json').read_text());assert len(calls)==1 and calls[0]['input']['value']=='approved-isolated-write'
failed=json.loads((root/'attempt-goKhbM/result.json').read_text());assert failed['passed']==0 and '插件沙箱准备失败'in failed['error'];failureAudit=json.loads((root/'attempt-goKhbM/failure-audit.json').read_text());assert failureAudit['changes'][0]['state']=='rolled-back'and failureAudit['pluginLeases']==0
runtime={'finalAttempt':a.name,'checksPassed':6,'nativeExits':c['nativeExits'],'pluginExits':pluginExits,'pluginInvocations':calls,'invocations':invocations,'approvals':approvals,'modelRequests':0,'secretReads':0,'failedAttempt':{'attempt':'attempt-goKhbM','passed':0,'cause':'Driver did not create canonical synthetic keychain root required by actual sandbox profile; corrected only temporary driver.','failureAudit':failureAudit},'scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/plugins/write-approvals.ts',repo/'src/main/core/applications/plugins/project-policy.ts',repo/'src/main/core/applications/plugins/host-service.ts',repo/'src/main/core/applications/plugins/__tests__/session-tools.test.ts',repo/'src/shared/plugin-approval.ts',t3/'apps/server/src/orchestration-v2/RuntimeRequestService.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts',t3/'apps/server/src/orchestration-v2/Adapters/ClaudeAdapterV2.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'t3Reference':'RuntimeRequestService requires persisted resolution, exact live providerSessionId and current active session; adapters use current pending callbacks. These source checks are not an executed T3 test.','variants':'Existing programmatic session/run/plan/retention variants; plugin approval, policy, host and tool-service sources unmodified. Temporary facade resolves original pty target inside host; not an actual renderer IPC implementation.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.variant','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 父子运行、Provider 切换与现有插件审批联合验证

2026-11-14；R01／02／03／05／08／10／12，Q09／11／24–28／38／40／43。技术方案 §9.3，验证账 §4.59。仅研究，产品及共享原型未改。

## 路径与复用范围

沿用程序化 task／binding／run、原子委派接受、ExecutionPlan 和 gated launcher 候选；父 Claude 初始化，创建子 Codex 并初始化。父排空后切 Codex，子取消后以原 binding 的下一 generation 启动。调用实际 PluginHostService、PluginProjectPolicy、PluginWriteApprovals、ApplicationToolService、插件生命周期及 sandbox-exec 子进程。

合成插件只在自己的临时数据目录记录一次调用；不访问网络、公司数据或真实业务。请求由隔离宿主直接调用 ToolService，不是 SDK-origin 业务 MCP。原生只做初始化，零模型请求；插件能力无连接槽，未读取任何凭据。

临时统一审批入口接收 source／task／binding／run／generation，重验实际活跃 run 后在宿主内部解析原 pty_id，并调用原审批服务。它保留 reviewHash、displayReceiptId 和 operationId，不让客户端把 native approval 当插件批准。实验中的窗口身份是宿主私有 WeakMap 句柄；未执行 Electron IPC、真实窗口授权或 UI。现有内部 PTY 字段仍保留，不称为去 PTY 数据迁移已完成。

## {a.name}：P01–P06

| 检查 | 已取得证据 |
| --- | --- |
| P01 | 原 present API 拒绝新任务作用域结构；临时 facade 能精确展示子 run 审批且展示对象不含 ptyId；父视图无此审批，未审阅的另一窗口及伪造窗口句柄不能批准 |
| P02 | 父 Claude 实际停止、切为 Codex 后，子 Codex 与原审批仍有效；新父 run 不能把子审批当自己的回应，伪造 task／run 组合拒绝 |
| P03 | 实际子取消使待审批调用 failed／not-started，审批 cancelled；同子 binding 的 generation 2 不能使用旧决定，不发生插件写入 |
| P04 | 原审批允许记录提交后、继续执行前撤销实际项目插件权限，原策略再次核验并阻止执行；审批可为 allowed，业务调用却为 failed／not-started |
| P05 | 新请求以原审阅凭据批准后，实际沙箱插件写一次；相同 requestId 返回原 ToolService 收据，插件执行不增加；旧审批不能再次批准 |
| P06 | 将来源替换成 native-runtime 被入口 Schema 拒绝；待确认时撤销实际项目插件权限，迟到 allow 拒绝，调用 not-started，已有成功结果不重复执行 |

最终四次原生退出：主动关闭 Claude code 143，三个 Codex code 0；全部运行 stopped、run 租约 released。插件有两个真实 PID：安装激活和一次业务调用，监督租约 closed，后续按 PID／出生身份核验均 stopped；另外两个未启动调用预留也 closed。四个业务调用中一个 succeeded／completed，三个 failed／not-started；只有一次临时插件写入。

首轮 attempt-goKhbM 在插件安装前失败：驱动未创建沙箱要求存在的 synthetic-keychain 目录，实际沙箱拒绝启动。只修正临时目录准备后重跑；失败安装按同包 hash 和时间定位到隔离数据库，状态 rolled-back、无 runtime lease，原失败保留。未修改或关闭沙箱策略。

## 设计结论

统一请求展示应通过来源适配接回现有业务权威服务，不能把所有“允许”都交给 Agent SDK 回调。子请求的决定归属于实际子 run，父 Provider 切换不会继承该批准；父停止与取消子树是不同命令，不能隐式相互替代。

迁移过渡可以由主进程从可信 run 解析旧内部 pty_id，让统一页面采用新作用域而旧审批语义继续工作。不能用 renderer 传来的 ptyId、当前聚焦任务或最新 run 猜测；最终字段改名／删除与旧 IPC 兼容仍单独迁移。业务审阅内容、显示回执、当前策略复验及调用结果账保持原服务所有。

特别保留“审批允许”和“操作完成”的区别。P04 确认 allowed 不代表已发送：允许之后的权限撤销仍可使调用 not-started；统一 UI 应同时读取审批决定与实际操作状态，不能把 allowed 画成写入成功。

T3 RuntimeRequestService 在执行回应时核对持久请求状态、live providerSessionId 和活跃会话，两个 adapter 使用各自当前 pending callback；这里只读对照，没有执行 T3 模块。WillYou 可借鉴实际连接身份与回调分离，业务审批仍走自身服务。

## 未覆盖

真实原生提问／审批回调及其迟到回应、父子问题转交、递归子树取消、进程后台未知范围、操作已发送后的取消、宿主崩溃、配置连接／插件版本变更、SDK 经私有 MCP 发起本链、真实窗口和 UI 未在本批通过。共享目录只用于初始化，不证明 SVN 并发写入策略。合成无连接插件通过也不等于全部既有插件兼容。

## 证据

[检查结果](result.json)、[运行／业务账／失败审计](runtime-audit.json)、[源码基线](source-review.json)、[哈希清单](archive-manifest.json)、[驱动、变体及数据库](raw-evidence.tar.gz)。{len(files)} 个归档文件、{len(dbs)} 份 SQLite 完整性／外键检查、{len(sources)} 个唯一构建输入复核。

复跑限定临时 HOME／工作区及合成插件，build.mjs、profile-build.mjs 后执行 probe.mjs；sandbox-exec 的目录边界保持原样，不将夹具窗口句柄替代产品 IPC 身份认证。
''')
section='''### 9.3 子运行的插件审批与统一请求入口

[父子运行／插件审批实验](实验/20261114_父子运行与插件审批联合验证/README.md)把程序化父子 task／binding／run 接到实际 PluginHostService、PluginProjectPolicy、PluginWriteApprovals、ApplicationToolService 和沙箱插件。父 Provider 切换保留子审批所属；子取消后旧批准不能在新 generation 生效；审批允许后的实时权限撤销仍阻止插件派发；有效批准只执行一次并复用调用收据。原生仅初始化，工具由隔离宿主发起，不宣称私有 MCP／真实 UI 已接线。

统一请求采用来源区分和精确运行作用域。plugin-write 请求展示与回应仍由原审批服务保存、审阅并决策，保留 operationId、reviewHash、displayReceiptId、窗口身份和实时策略检查。native-runtime 回调不能替代该证明，父 Agent 不因父子关系获得批准权。真正用户可以切到子任务审阅，不能由父视图把子请求改写为父 run 的请求。

现有业务审批接口和 PluginProjectPolicy.writeScope 仍依赖内部 pty_id。迁移过渡可由宿主在核验 task／binding／run／generation 后解析旧目标，再调用原服务；新 UI 不需要自己生成或猜测 ptyId。实验已验证该 facade 和原接口拒绝新结构的对照；最终内部字段迁移、旧入口兼容、可信 IPC 窗口来源仍需实施前合同与实施后回归，不能直接删掉旧约束。

取消自己的父运行不等于取消子树。若只是切父 Provider，子 run 的审批继续绑定原请求；若用户明确取消子树，逐一撤销子运行与待审操作并等待实际排空，不能只移除卡片。旧批准不向下一 run 转移，重试需要新请求和新审阅。

UI 分别展示审批决定与操作结果。allowed 仅是原审阅被接受，后续复核仍可得到 failed／not-started；已发送的操作另按业务账处理 unknown／completed。权限撤销不删除原批准审计，也不将其重写为“执行成功”。本批尚未验证真实提问回调、递归取消、已发写入和全部插件连接组合。

'''
def tech(t):
 assert '### 9.3 'not in t;t=t.replace('## 10. 统一 UI 与交互落点',section+'## 10. 统一 UI 与交互落点')
 return t.replace('全部表单形态、实际 IPC／业务审批和公共委派服务仍未完成，Q01／11 仍为部分。','§9.3 已补实际插件审批与程序化父子 run 的隔离联合；全部表单形态、实际 IPC／原生回调和公共委派服务仍未完成，Q01／11 仍为部分。')
edit(base/'技研/技术方案.md',tech)
record='''### 4.59 程序化父子运行与实际插件审批／业务策略

[插件审批联合实验](实验/20261114_父子运行与插件审批联合验证/README.md)P01–P06 通过。实际 PluginHostService／Policy／Approvals／ToolService 接到新父子 run；父切 Provider 不转移子审批，子取消后旧批准不能作用于下一 generation，允许后撤销实际项目权限仍使调用 not-started。有效新审阅实际驱动沙箱合成插件一次，同 requestId 复用收据；来源混用和错误窗口／任务组合拒绝。

attempt-ygCq5f 四次原生初始化／退出、两个真实插件进程最终关闭、零模型请求；四个调用中一项 completed、三项 not-started，秘密读取为零。首轮安装因夹具未建沙箱测试目录失败并回滚，修正仅限临时驱动，失败保留。新统一入口仍通过宿主解析旧内部 pty_id，未改原审批策略；可信窗口为夹具，未验证真实 IPC、原生提问回调、SDK-origin MCP、递归取消或连接配置。技术方案 §9.3 明确迁移边界；不能把局部通过记为整个业务体系已兼容。

'''
def ledger(t):
 assert '### 4.59 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q09','Q11','Q24','Q25','Q26','Q27','Q28','Q38','Q40','Q43']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.59 补实际插件审批／策略与父子 run、切换及迟到批准，原生提问／真实 IPC 未闭环 |'
 t='\n'.join(lines)+'\n';t=t.replace('真实程序化 owner／业务桥与实际业务上下文联合；邮件来源','§4.59 已补实际插件审批／业务策略与程序化父子 run、真实沙箱执行及迟到批准；继续补真实程序化 owner／业务桥与实际业务上下文联合；邮件来源');t=t.replace('子问题和取消迟到回应；父切换时','子问题和取消迟到回应（§4.59 已补实际插件审批，原生回调与递归取消未证）；父切换时');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补程序化父子运行与实际插件审批、实时业务策略、沙箱插件的联合验证；父切换不转移子审批，取消后的旧批准不复活，允许后的撤权仍阻止执行，见[技术方案 §9.3](技研/技术方案.md)。仅隔离研究，真实 UI／原生提问与业务 MCP 尚未闭环。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：优先补原生提问／审批回调的取消迟到、自动通知与主动读取越过发送边界后的竞争，以及现有业务私有桥联合；复用已证实的审批与初始化。协议、资源、平台、性能和 UI 设计继续按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)收口，不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
