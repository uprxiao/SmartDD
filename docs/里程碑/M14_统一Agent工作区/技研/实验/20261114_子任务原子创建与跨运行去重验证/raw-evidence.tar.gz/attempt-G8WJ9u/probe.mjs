import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import actual from './actual.cjs';
import {install,accept,summary,claim,markDispatching,reconcile} from './candidate.mjs';
const require=createRequire(import.meta.url),Database=require('better-sqlite3'),root=import.meta.dirname;
const save=(p,v)=>writeFileSync(p,JSON.stringify(v,null,2)+'\n');
function open(file){const db=new Database(file);db.pragma('foreign_keys=ON');db.pragma('journal_mode=WAL');db.pragma('busy_timeout=5000');return db;}
if(process.argv[2]==='--worker'){
 process.on('message',()=>{});
 const [file,specPath,point]=process.argv.slice(3),spec=JSON.parse(readFileSync(specPath)),db=open(file);
 if(point==='race'){process.send({ready:true});await new Promise(r=>process.once('message',r));}
 const response=await accept(db,spec.scope,spec.input,{checkpoint:point==='race'?undefined:async reached=>{if(reached===point){process.send({point:reached});await new Promise(()=>{});}}});
 process.send({response});db.close();process.disconnect();
}else{
 const out=mkdtempSync(root+'/attempt-'),checks=[];for(const name of ['build.mjs','build.json','candidate.mjs','probe.mjs'])copyFileSync(root+'/'+name,out+'/'+name);let f,run,error;
 const check=async(id,label,fn)=>{try{const evidence=await fn();checks.push({id,label,status:'passed',evidence});console.log(JSON.stringify({id,status:'passed'}));}catch(e){checks.push({id,label,status:'failed',error:e.stack});throw e;}finally{save(out+'/progress.json',{checks});}};
 const clone=async(name,fn)=>{const file=out+'/'+name+'.sqlite';copyFileSync(out+'/baseline.sqlite',file);const db=open(file);try{return await fn(db,file);}finally{assert.deepEqual(db.pragma('integrity_check'),[{integrity_check:'ok'}]);assert.deepEqual(db.pragma('foreign_key_check'),[]);db.close();}};
 const launch=(file,point)=>{
  const p=spawn(process.execPath,[import.meta.filename,'--worker',file,out+'/spec.json',point],{env:{PATH:'/usr/bin:/bin',HOME:out},stdio:['ignore','pipe','pipe','ipc']});let stderr='';const record={pid:p.pid,point};let readyResolve;const ready=new Promise(r=>readyResolve=r);
  p.stderr.on('data',b=>stderr+=b);const exit=new Promise((resolve,reject)=>{p.once('error',reject);p.once('exit',(code,signal)=>{Object.assign(record,{code,signal,stderr});resolve(record);});});
  p.on('message',m=>{if(m.ready)readyResolve();if(m.response)record.response=m.response;if(m.point){assert.equal(m.point,point);record.reached=m.point;p.kill('SIGKILL');}});return{p,exit,ready,record};
 };
 try{
  f=await actual.runFixture();const db=actual.drizzle(f.sqlite,{schema:actual.schema});
  const cipher={isAvailable:()=>true,encrypt:p=>Buffer.from('fixture:'+p),decrypt:b=>b.toString().slice(8)};
  const secrets=new actual.SecretsStore(db,cipher),profiles=new actual.AiProfileService(db,secrets),projects=new actual.ProjectService(db,secrets);
  const nativeRoot=f.home+'/.claude';mkdirSync(nativeRoot,{recursive:true});
  const profile=profiles.create({name:'isolated atomic target',runner:'claude',executable:null,env:[{name:'CLAUDE_CONFIG_DIR',secret:false,value:nativeRoot}],args:[],color:null,isDefault:true});
  f.sqlite.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,runner,title,first_message,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)').run(f.snapshot.taskId,'p1',f.snapshot.native.cwd,profile.id,'claude','parent fixture','',1,1);
  await check('T01','actual legacy create starts PTY before inserting task; launchToken is not durable idempotency',async()=>{
   const project=projects.createProject({name:'legacy task fixture',aliases:[],description:'',rulesPath:null},[{label:'source',path:f.snapshot.native.cwd}]);
   class FakePtys extends EventEmitter{calls=[];fail=false;spawn(opts){if(this.fail)throw Error('fixture spawn failed');this.calls.push({taskRowsAtSpawn:f.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,command:opts.command});return'fixture-pty-'+this.calls.length;}kill(id){this.emit('exit',id,0);}}
   const ptys=new FakePtys(),svc=new actual.TaskService({db,ptys,profiles,projects,baseEnv:()=>({HOME:f.home,PATH:'/usr/bin:/bin'}),onChanged:()=>{}});
   try{const initial=f.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,request={launchToken:randomUUID(),projectId:project.id,dirId:null,aiProfileId:profile.id,firstMessage:'synthetic legacy task'};
    const a=await svc.create(request),b=await svc.create(request);assert.notEqual(a.task.id,b.task.id);assert.deepEqual(ptys.calls.map(c=>c.taskRowsAtSpawn),[initial,initial+1]);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,initial+2);
    ptys.fail=true;await assert.rejects(svc.create({...request,launchToken:randomUUID()}),/fixture spawn failed/);assert.equal(f.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n,initial+2);
    return{actualTaskService:true,pty:'fake, no CLI launched',sameTokenAfterCompletionCreatesDistinctTasks:true,spawnPrecedesInsert:true,failedSpawnLeavesNoTask:true};
   }finally{svc.dispose();}
  });
  run=await f.create();await run.prepare();await run.cli.arm();f.reader.identities.set(71001,'darwin-proc-v1:71001:1');await run.cli.attach(71001,'darwin-proc-v1:71001:1');f.runs.assertActive(run.runId);
  const spec={scope:{taskId:f.snapshot.taskId,runId:run.runId},input:{key:randomUUID(),targetId:profile.id,targetRevision:f.sqlite.prepare('SELECT updated_at FROM ai_profiles WHERE id=?').get(profile.id).updated_at,cwd:f.snapshot.native.cwd,prompt:'synthetic delegated work'}};
  save(out+'/spec.json',spec);install(f.sqlite);await f.sqlite.backup(out+'/baseline.sqlite');
  const authorize=()=>f.runs.assertActive(run.runId),verifyOne=d=>{const s=summary(d);for(const t of ['m14_binding','m14_turn','m14_delegation','m14_receipt','m14_outbox'])assert.equal(s[t].length,1);const child=s.tasks.find(t=>t.id===s.m14_delegation[0].child_task);assert(child);assert.equal(child.native_session_id,null);assert.equal(child.last_launched_at,null);assert.equal(s.m14_binding[0].state,'planned');return s;};
  await check('T02','candidate accepts one logical child with receipt, planned binding, turn and outbox',()=>clone('T02',async d=>{
   const a=await accept(d,spec.scope,spec.input,{authorize}),b=await accept(d,spec.scope,spec.input,{authorize});assert.deepEqual(a,b);await assert.rejects(accept(d,spec.scope,{...spec.input,prompt:'different'},{authorize}),/REQUEST_CONFLICT/);const s=verifyOne(d);return{response:a,counts:Object.fromEntries(Object.entries(s).map(([k,v])=>[k,v.length])),nativeStarted:false};
  }));
  await check('T03','two concurrent worker submissions return one durable child',()=>clone('T03',async(d,file)=>{
   const a=launch(file,'race'),b=launch(file,'race');await Promise.all([a.ready,b.ready]);a.p.send({go:true});b.p.send({go:true});const ends=await Promise.all([a.exit,b.exit]);for(const e of ends)assert.equal(e.code,0,e.stderr);assert.deepEqual(ends[0].response,ends[1].response);verifyOne(d);return{workers:ends};
  }));
  for(const point of ['after-task','after-outbox','after-commit'])await check('T04-'+point,'captured worker SIGKILL at '+point,()=>clone('T04-'+point,async(d,file)=>{
   const worker=launch(file,point),end=await worker.exit;assert.equal(end.signal,'SIGKILL');assert.equal(end.reached,point);const before=summary(d),committed=point==='after-commit';
   for(const t of ['m14_binding','m14_turn','m14_delegation','m14_receipt','m14_outbox'])assert.equal(before[t].length,committed?1:0);const baselineTasks=f.sqlite.prepare('SELECT COUNT(*) n FROM tasks').get().n;assert.equal(before.tasks.length,baselineTasks+(committed?1:0));
   const response=await accept(d,spec.scope,spec.input,{authorize});verifyOne(d);if(committed)assert.equal(response.childTaskId,before.m14_delegation[0].child_task);return{worker:end,committed,recoveredResponse:response};
  }));
  await check('T05','target deletion after acceptance blocks dispatch without changing child or falling back',()=>clone('T05',async d=>{
   const response=await accept(d,spec.scope,spec.input,{authorize});d.prepare('DELETE FROM ai_profiles WHERE id=?').run(profile.id);d.prepare('UPDATE m14_workspace SET held=0').run();assert.deepEqual(claim(d,response.effectId),{state:'blocked',claimed:false});const repeated=await accept(d,spec.scope,spec.input,{authorize});assert.deepEqual(repeated,response);const s=verifyOne(d);assert.equal(s.m14_binding[0].profile_id,profile.id);assert.equal(s.tasks.find(t=>t.id===response.childTaskId).ai_profile_id,null);return{sameReceiptAfterTargetDeletion:true,plannedTargetRetained:true,existingTaskForeignKeySetNull:true,noFallback:true};
  }));
  await check('T06','revoked parent cannot reuse acceptance authority even with a previous receipt',()=>clone('T06',async d=>{
   await accept(d,spec.scope,spec.input,{authorize});d.prepare("UPDATE capability_runs SET revocation_state='revoked' WHERE run_id=?").run(spec.scope.runId);await assert.rejects(accept(d,spec.scope,spec.input),/CALLER_UNAVAILABLE/);d.prepare("UPDATE capability_runs SET revocation_state='open' WHERE run_id=?").run(spec.scope.runId);f.setAllowed(false);try{await assert.rejects(accept(d,spec.scope,spec.input,{authorize}),/fixture current policy revoked/);}finally{f.setAllowed(true);}verifyOne(d);return{persistedScopeGateRejected:true,actualRunRegistryCurrentPolicyRejected:true,receiptDoesNotGrantAuthority:true};
  }));
  await check('T07','shared workspace wait, stale claims and unknown launch are separate',()=>clone('T07',async d=>{
   const response=await accept(d,spec.scope,spec.input,{authorize});assert.deepEqual(claim(d,response.effectId),{state:'waiting_parent_release',claimed:false});d.prepare('UPDATE m14_workspace SET held=0').run();const first=claim(d,response.effectId);assert(first.claimed);assert.throws(()=>reconcile(d,response.effectId,first.token,{ownerStopped:false,forkNotAttempted:true}),/OWNER_NOT_STOPPED/);
   assert.equal(reconcile(d,response.effectId,first.token,{ownerStopped:true,forkNotAttempted:true}),'queued');const second=claim(d,response.effectId);assert.notEqual(first.token,second.token);assert.throws(()=>markDispatching(d,response.effectId,first.token),/STALE_CLAIM/);markDispatching(d,response.effectId,second.token);
   assert.equal(reconcile(d,response.effectId,second.token,{ownerStopped:true,forkNotAttempted:true}),'unknown');assert.deepEqual(claim(d,response.effectId),{state:'unknown',claimed:false});return{waitingDoesNotCreateAnotherChild:true,claimTokenFenced:true,dispatchingNotAutomaticallyRetried:true,noActualNativeOrKernelProofInThisCheck:true};
  }));
 }catch(e){error=e.stack;process.exitCode=1;}
 finally{if(run){f.reader.identities.delete(71001);await run.cli.exited();await run.stop('probe-finished');}if(f){await f.sqlite.backup(out+'/fixture-final.sqlite');f.sqlite.close();}}
 const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,failed:checks.filter(x=>x.status==='failed').length,error,scope:'Actual TaskService with fake PTY; actual schemas/migrations/profile/project services and prepared owner with FixtureProcessReader. Candidate logical creation/outbox on same DB and actual tasks table. Concurrent Node workers and SIGKILL are real; no native agents, final capability projection or production integration.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify(result,null,2));
}
