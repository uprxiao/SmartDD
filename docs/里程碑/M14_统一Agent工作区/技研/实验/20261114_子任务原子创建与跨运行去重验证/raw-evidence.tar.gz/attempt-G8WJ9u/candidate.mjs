import assert from 'node:assert/strict';
import {randomUUID,createHash} from 'node:crypto';
export function install(db){db.exec(`
CREATE TABLE IF NOT EXISTS m14_binding(id TEXT PRIMARY KEY,task_id TEXT NOT NULL UNIQUE REFERENCES tasks(id) ON DELETE RESTRICT,profile_id TEXT NOT NULL,profile_revision INTEGER NOT NULL,driver TEXT NOT NULL,state TEXT NOT NULL CHECK(state='planned'));
CREATE TABLE IF NOT EXISTS m14_turn(id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE RESTRICT,binding_id TEXT NOT NULL REFERENCES m14_binding(id) ON DELETE RESTRICT,input TEXT NOT NULL,state TEXT NOT NULL CHECK(state='queued'));
CREATE TABLE IF NOT EXISTS m14_delegation(id TEXT PRIMARY KEY,parent_task TEXT NOT NULL REFERENCES tasks(id) ON DELETE RESTRICT,parent_run TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,child_task TEXT NOT NULL UNIQUE REFERENCES tasks(id) ON DELETE RESTRICT,turn_id TEXT NOT NULL UNIQUE REFERENCES m14_turn(id) ON DELETE RESTRICT,state TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS m14_receipt(parent_run TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,request_key TEXT NOT NULL,request_hash TEXT NOT NULL,delegation_id TEXT NOT NULL REFERENCES m14_delegation(id) ON DELETE RESTRICT,response TEXT NOT NULL,PRIMARY KEY(parent_run,request_key));
CREATE TABLE IF NOT EXISTS m14_outbox(id TEXT PRIMARY KEY,delegation_id TEXT NOT NULL UNIQUE REFERENCES m14_delegation(id) ON DELETE RESTRICT,state TEXT NOT NULL CHECK(state IN ('queued','claimed','dispatching','done','blocked','unknown')),claim TEXT,reason TEXT);
CREATE TABLE IF NOT EXISTS m14_workspace(id INTEGER PRIMARY KEY CHECK(id=1),held INTEGER NOT NULL CHECK(held IN (0,1)));
INSERT OR IGNORE INTO m14_workspace VALUES(1,1);
`);}
export const summary=db=>Object.fromEntries(['tasks','m14_binding','m14_turn','m14_delegation','m14_receipt','m14_outbox'].map(t=>[t,db.prepare('SELECT * FROM '+t).all()]));
function caller(db,scope){const row=db.prepare('SELECT r.*,t.archived_at AS task_archived,p.archived_at AS project_archived FROM capability_runs r JOIN tasks t ON t.id=r.task_id JOIN projects p ON p.id=t.project_id WHERE r.run_id=? AND r.task_id=?').get(scope.runId,scope.taskId);assert(row&&row.state==='active'&&row.revocation_state==='open'&&row.task_archived===null&&row.project_archived===null,'CALLER_UNAVAILABLE');return row;}
const digest=v=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
// The optional asynchronous checkpoint exists only to kill the isolated worker inside a transaction.
export async function accept(db,scope,input,{authorize=()=>{},checkpoint}={}){
 const requestHash=digest([input.targetId,input.targetRevision,input.cwd,input.prompt]);
 db.exec('BEGIN IMMEDIATE');let committed=false;
 try{
  authorize();const parent=caller(db,scope);
  const old=db.prepare('SELECT * FROM m14_receipt WHERE parent_run=? AND request_key=?').get(scope.runId,input.key);
  if(old){assert.equal(old.request_hash,requestHash,'REQUEST_CONFLICT');db.exec('COMMIT');committed=true;return JSON.parse(old.response);}
  const profile=db.prepare('SELECT * FROM ai_profiles WHERE id=?').get(input.targetId);
  assert(profile&&!profile.command_pending&&profile.updated_at===input.targetRevision,'TARGET_UNAVAILABLE');
  const childId=randomUUID(),bindingId=randomUUID(),turnId=randomUUID(),delegationId=randomUUID(),effectId=randomUUID(),now=Date.now();
  db.prepare('INSERT INTO tasks(id,project_id,cwd,ai_profile_id,ai_profile_name,runner,title,first_message,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(childId,parent.project_id,input.cwd,profile.id,profile.name,profile.runner,'delegated fixture',input.prompt,now,now);
  if(checkpoint)await checkpoint('after-task');
  db.prepare("INSERT INTO m14_binding VALUES(?,?,?,?,?,'planned')").run(bindingId,childId,profile.id,profile.updated_at,profile.runner);
  db.prepare("INSERT INTO m14_turn VALUES(?,?,?,?,'queued')").run(turnId,childId,bindingId,input.prompt);
  db.prepare("INSERT INTO m14_delegation VALUES(?,?,?,?,?,'accepted')").run(delegationId,scope.taskId,scope.runId,childId,turnId);
  db.prepare("INSERT INTO m14_outbox VALUES(?,?,'queued',NULL,NULL)").run(effectId,delegationId);
  const response={status:'accepted',delegationId,childTaskId:childId,bindingId,turnId,effectId};
  db.prepare('INSERT INTO m14_receipt VALUES(?,?,?,?,?)').run(scope.runId,input.key,requestHash,delegationId,JSON.stringify(response));
  if(checkpoint)await checkpoint('after-outbox');
  db.exec('COMMIT');committed=true;
  if(checkpoint)await checkpoint('after-commit');
  return response;
 }catch(e){if(!committed)db.exec('ROLLBACK');throw e;}
}
export function claim(db,effectId){return db.transaction(()=>{
 const row=db.prepare('SELECT o.*,b.profile_id,b.profile_revision FROM m14_outbox o JOIN m14_delegation d ON d.id=o.delegation_id JOIN m14_binding b ON b.task_id=d.child_task WHERE o.id=?').get(effectId);assert(row);
 if(row.state!=='queued')return{state:row.state,claimed:false};
 const p=db.prepare('SELECT * FROM ai_profiles WHERE id=?').get(row.profile_id);
 if(!p||p.command_pending||p.updated_at!==row.profile_revision){db.prepare("UPDATE m14_outbox SET state='blocked',reason='TARGET_UNAVAILABLE' WHERE id=?").run(effectId);return{state:'blocked',claimed:false};}
 if(db.prepare('SELECT held FROM m14_workspace').get().held)return{state:'waiting_parent_release',claimed:false};
 const token=randomUUID();db.prepare("UPDATE m14_outbox SET state='claimed',claim=? WHERE id=?").run(token,effectId);return{state:'claimed',claimed:true,token};
}).immediate();}
export function markDispatching(db,effectId,token){const result=db.prepare("UPDATE m14_outbox SET state='dispatching' WHERE id=? AND state='claimed' AND claim=?").run(effectId,token);assert.equal(result.changes,1,'STALE_CLAIM');}
export function reconcile(db,effectId,token,{ownerStopped,forkNotAttempted}){return db.transaction(()=>{
 assert(ownerStopped,'OWNER_NOT_STOPPED');const row=db.prepare('SELECT * FROM m14_outbox WHERE id=?').get(effectId);assert.equal(row.claim,token,'STALE_CLAIM');
 assert(['claimed','dispatching'].includes(row.state));const next=row.state==='claimed'&&forkNotAttempted?'queued':'unknown';db.prepare('UPDATE m14_outbox SET state=?,claim=NULL WHERE id=?').run(next,effectId);return next;
}).immediate();}
