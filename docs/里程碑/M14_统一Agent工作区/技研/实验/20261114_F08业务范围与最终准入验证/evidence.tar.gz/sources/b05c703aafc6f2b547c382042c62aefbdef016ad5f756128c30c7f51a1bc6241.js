// package.json
var version = "0.32.2";

// src/version.ts
var compatibilityVersion = 7;
export {
  compatibilityVersion,
  version as npmVersion
};
