from pathlib import Path
import json,hashlib,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_跨Provider结果真实传输验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
r=json.loads((root/'latest.json').read_text());assert r['passed']==4 and r['modelRequests']==8 and not r.get('error');a=Path(r['out']);sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((root/n).read_text())
 for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'];sources[s['path']]=s
 for o in b['outputs']:assert sha(Path(o['file']).read_bytes())==o['sha256']
for p in a.iterdir():
 if p.suffix in ['.mjs','.cjs','.sql','.ts','.variant']and(root/p.name).exists():assert p.read_bytes()==(root/p.name).read_bytes(),p.name
c=json.loads((a/'cleanup.json').read_text());assert all(x['state']['runState']=='stopped'for x in c['cleanup']);assert len(c['nativeExits'])==3;assert {x['id']:x['code']for x in c['nativeExits']}=={'codex-held':0,'claude-current':143,'codex-current':0};assert all(x['signal']is None for x in c['nativeExits'])
models=[json.loads(l)for l in (a/'model.jsonl').read_text().splitlines()];assert len(models)==8;assert [x['id']for x in models]==['codex-held']+['claude-current']*4+['codex-current']*3
db=sqlite3.connect(a/'final.sqlite');assert db.execute("select count(*)from capability_runs where state not in ('stopped','failed')").fetchone()[0]==0;assert db.execute("select count(*)from capability_resource_leases where owner_kind='run' and state<>'released'").fetchone()[0]==0;assert db.execute('select count(*),sum(ack_count),sum(observed)from child_result').fetchone()==(2,2,2)
events=[{'type':t,'payload':json.loads(p)}for t,p in db.execute('select type,payload from route_event order by seq')];assert db.execute("select count(*)from result_observation where state='disposed'").fetchone()[0]==1;db.close()
assert not(a/'codex-held-tool-response.jsonl').exists();assert json.loads((a/'codex-held-response-discarded.jsonl').read_text())=={'requestId':0}
runtime={'finalAttempt':a.name,'checksPassed':4,'nativeExits':c['nativeExits'],'localModelRequests':8,'supplierModelCalls':0,'resultEvents':events,'scope':r['scope']};(root/'runtime-audit.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2))
refs=[repo/'src/main/core/applications/run-registry.ts',t3/'apps/server/src/mcp/OrchestratorMcpService.ts',t3/'apps/server/src/mcp/toolkits/orchestrator/tools.ts',t3/'packages/effect-codex-app-server/src/_generated/schema.gen.ts',Path('/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts')]
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(sources),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'t3Difference':'Local T3 task_status documents reading as delivered and OrchestratorMcpService dispatches acknowledgement before returning response. This probe read/ack token protocol is a WillYou candidate, not an existing T3 API.','variants':'Prior scoped session/run/plan and retention variants reused; programmatic result service and transport only in tmp. No product edits.'};(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
schemaNames={'ThreadStartParams.json','DynamicToolCallParams.json','DynamicToolCallResponse.json'}
files=[p for p in root.rglob('*')if p.is_file()and not any(x in p.parts for x in ['node_modules','publication','__pycache__'])and('codex-schema'not in p.parts or p.name in schemaNames)and p.suffix in ['.mjs','.cjs','.json','.jsonl','.sqlite','.sql','.ts','.py','.variant','.log']and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  db=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchall()==[('ok',)]and db.execute('pragma foreign_key_check').fetchall()==[];db.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(r,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['runtime-audit.json','source-review.json']]:put(exp/n,data)
put(exp/'README.md',f'''# 跨 Provider 结果的真实传输与未知读取恢复

2026-11-14；R03／04／05／06／12，Q14／19／24–28／54。验证账 §4.58，技术方案 §7.2.3。技术研究，产品和共享原型未改。

## 验证目标与实际路径

沿用 §4.57 的同一逻辑 task、两个 binding、程序化私有 run 和 ExecutionPlan。结果处理不再仅由驱动直接调用：Codex 0.167.1 通过 app-server 的实验性 dynamicTools／item/tool/call，Claude SDK 0.3.321／native 2.1.321 通过 createSdkMcpServer 的进程内 MCP，调用同一个候选 Results 服务。运行权限由闭包保留的私有 run 核验；不接受模型传入的 run 或 task 身份。

预置两个合成子结果。本机 HTTP 端点返回固定工具调用，记录 SDK／原生实际发出的下一次模型请求；断言其中包含结果正文、revision 和观察 token。不是仅检查工具返回值，也不是模型口头说“读到了”。没有真实子 Agent、供应商调用或模型自主决策。

## {a.name}：T01–T04

| 检查 | 证据 |
| --- | --- |
| T01 | 真实 Codex 动态工具读取已提交，但驱动持有回包；实际停止 Codex 后丢弃该响应。只有一次本机模型请求且不含结果正文；结果仍 unobserved，父切换被 offered 记录阻止 |
| T02 | 原 run 排空后把未确认读取转 unknown，切换仍拒绝；隐式恢复理由拒绝；明确夹具操作废止原观察 token 后才切 Claude，保留结果与未观察状态，不重新启动子任务 |
| T03 | Claude SDK 的进程内 MCP 重新读取同一结果，下一模型请求含正文及新 token；原 Codex token 的实际工具确认被拒绝，新 token 确认一次；四次模型请求、三次工具调用 |
| T04 | 排空后切回 Codex generation 2，通过同一结果服务读取第二个结果并确认；三次模型请求、两次工具调用。另由宿主重放同一有效确认，回原收据，不增加计数 |

三个捕获原生退出为 Codex 0、主动关闭的 Claude 143、Codex 0；所有 run stopped、运行资源租约 released。八次本机模型请求、零供应商请求，最终两个结果分别确认一次。没有重试失败轮。

## 对设计的影响

上一批仅规定 offered 阻止切换，还没有验证其跨 run 恢复出口。本批补齐候选：旧 run 排空后 offered → unknown；没有可靠消费证据时不自动确认或自动重发；由可信用户入口明确废止旧观察尝试，保留未观察结果，再由新 run 显式读取并取得新 token。处置记录、结果身份与正文不能被这个操作删除。

这项“用户入口”只是设计合同。实验调用的是 fixture-explicit-reinspect-unread-result，未验证产品授权界面、权限实现或真实用户批准；不能在真实任务上由后台自动执行。held-response 精确证明本次确实尚未把正文回给原生程序，但一般网络断开不能得到相同判断，因此设计按 unknown 处理。

候选接口将读取和确认分开。T3 当前本地源码的 task_status 文案是读取即标 delivered，OrchestratorMcpService 在返回结果前派发 completion-delivery.acknowledge。WillYou 的二步 token 合同是为其当前 run／恢复需求补的设计，不是声称 T3 已提供同样 API，也不把本实验当作 T3 缺陷证明。它增加模型往返成本；Skill／适配器需要规定确认时机，不能默认每个模型都会遵守。未来若改为传输回执，必须给出相同消费／失联语义的证据。

传输适配与宿主结果服务可以解耦：本批两个入口调用同一服务，但不规定生产 Codex 必须用实验性 dynamicTools；可以选 MCP 等已支持入口，按该版本能力检测。实验性字段不属于“全部版本都支持”的承诺。

## 限制与剩余验证

本批没有业务 ApplicationToolService／私有进程桥，没有四类业务 MCP 回归，也没有使用其授权证明替代结果服务私有 owner 校验。取消发生在宿主活着且持有响应的受控点，不是宿主崩溃、部分 socket 写入或原生已经消费而 ACK 丢失；这些与 §4.31 证据分别记录，不能相加为当前最终 Schema 全链。未测试自动通知、实际子问题／取消迟到、整棵任务树、真实 UI、完整历史交接及 SDK 的其他版本。

## 证据与复跑

[结果](result.json)、[运行审计](runtime-audit.json)、[源码对照](source-review.json)、[哈希清单](archive-manifest.json)、[完整临时驱动及数据](raw-evidence.tar.gz)。共 {len(files)} 个归档文件，{len(dbs)} 份 SQLite 完整性和外键通过，{len(sources)} 个唯一构建输入核对。

Codex schema 由固定原生包执行 app-server generate-json-schema --experimental 生成，归档仅保留本批使用的三份定义。复跑先执行 build.mjs／profile-build.mjs，再 probe.mjs；使用隔离 HOME、临时工作区、合成凭据和本机端点。默认不对日常任务执行恢复处置。
''')
section='''#### 7.2.3 结果回包中断后的跨运行恢复

[真实结果传输实验](实验/20261114_跨Provider结果真实传输验证/README.md)在同一逻辑 task 上，以 Codex app-server 动态工具和 Claude SDK 进程内 MCP 调用同一候选结果服务，核对下一原生模型请求确实包含正文、revision 和 token。旧 run 的 token 在新 Provider 的实际工具调用中被拒绝；新 token 确认一次。本实验入口不替代业务 MCP／ApplicationToolService，也不限定生产必须采用实验性 dynamicTools。

读取落库到原生收到回包之间存在未知窗口。当前候选恢复顺序为：确认旧 run 与资源排空；把未确认 offered 转为 unknown；保留结果未观察状态并阻止自动派发；通过可信用户权限入口明确废止旧观察尝试、记录原因；新 run 再显式读同一 resultId／revision 并取得新 token。废止的是旧读取尝试，不是删除结果、重启子任务或确认已读；不能把它实现成后台自动清空 unknown。

隔离实验已验证回包前主动停止原生程序、切换阻塞、明确处置和新 Provider 重读，但可信用户入口仍是设计合同，未实施 UI／权限接线。宿主崩溃、部分回包、真实消费后确认丢失和自动通知的同时发送仍需按相同身份和状态合同核验。

T3 本地 task_status 在返回前派发 completion-delivery.acknowledge；本方案的独立 read／ack token 是 WillYou 的候选扩展，不称为 T3 原有接口。它增加一次工具／模型往返，需由 Skill 与适配器约定确认时机，并保留未确认状态；实验中的固定模型响应不证明任意模型均会正确确认。若改用其他消费回执，须先明确能证明的传输边界。

'''
def tech(t):
 assert '#### 7.2.3 'not in t;t=t.replace('### 7.3 Skill 交付、更新与调用来源',section+'### 7.3 Skill 交付、更新与调用来源')
 t=t.replace('子结果和通知派发仍是候选夹具，未声称真实结果 MCP 全链通过。','子结果和通知派发仍是候选夹具；§7.2.3 另补同 owner 的原生结果传输，完整业务／父子链未闭环。')
 return t
edit(base/'技研/技术方案.md',tech)
record='''### 4.58 同父任务跨 Provider 的真实结果传输与未知读取出口

[真实传输实验](实验/20261114_跨Provider结果真实传输验证/README.md)T01–T04 通过。使用既有程序化 owner／计划和候选结果服务，经真实 Codex 动态工具、Claude SDK 进程内 MCP 读取合成子结果；下一原生模型请求包含正文、revision 和 token。读取落库但回包前原生停止时仍未观察，offered／unknown 阻止切换；明确夹具废止旧读取尝试后，切 Claude 重读同一结果，实际旧 token 确认拒绝、新 token 确认一次；再切 Codex 完成第二结果。

attempt-YtlGCF 三次捕获原生退出、八次本机合成模型请求，全部 run／租约排空，产品及共享原型未改。新增 §7.2.3 恢复出口及传输适配边界；独立 read／ack 合同是 WillYou 候选，不冒称 T3 原有机制。没有实际子执行、自动通知、宿主崩溃或业务 MCP；处置为夹具，不是生产用户授权。仍不能据此关闭整个 D06。

'''
def ledger(t):
 assert '### 4.58 'not in t;t=t.replace('## 5. 失败与驱动修正',record+'## 5. 失败与驱动修正');lines=t.splitlines()
 for q in ['Q14','Q19','Q24','Q25','Q26','Q27','Q28','Q54']:
  i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.58 补同 owner 的实际结果工具传输及回包前停止恢复，自动通知／完整业务链仍缺 |'
 t='\n'.join(lines)+'\n';t=t.replace('继续验证已派发输入／完整业务和结果链联合、socket 消费窗口','§4.58 已补真实原生结果工具与同父切换、回包前停止及未知读取出口；继续验证已派发输入／完整业务和结果链联合、部分 socket 消费窗口');return t
edit(base/'技研/全局设计验证账.md',ledger)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已将同父任务的结果服务接入真实 Codex 动态工具与 Claude SDK 进程内 MCP，验证结果／令牌进入下一模型请求、旧 run 令牌拒绝、回包前停止后的明确恢复，见[技术方案 §7.2.3](技研/技术方案.md)。仅隔离技术验证，子结果预置，完整业务和自动通知未闭环。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：优先补自动通知与主动读取越过发送边界后的竞争、子问题／取消迟到及最终业务 owner 联合；复用已有初始化与正常结果证据。其余协议、业务 MCP、资源、平台、性能和 UI 设计按[验证账 §7](技研/全局设计验证账.md#7-剩余工作与关闭标准)推进，当前不修改产品或原型。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry);(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sources':len(sources)}))
