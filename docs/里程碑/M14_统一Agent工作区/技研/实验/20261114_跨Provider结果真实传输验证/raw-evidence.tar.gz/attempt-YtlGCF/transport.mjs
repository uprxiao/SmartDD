import assert from 'node:assert/strict';
import {createInterface} from 'node:readline';
import {appendFileSync,mkdirSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {query,tool,createSdkMcpServer} from '/private/tmp/willyou-m14-global-f3zh527k/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs';
import {deferred} from './launch.mjs';
const name='willyou_result';
export function transport(out,f,driver,id,io){return(spawn,prepared)=>{
 mkdirSync(f.snapshot.native.stateRoot,{recursive:true});
 const log=(kind,x)=>appendFileSync(out+'/'+id+'-'+kind+'.jsonl',JSON.stringify(x)+'\n'),done=deferred();
 if(driver==='claude'){
  const input=deferred(),end=deferred(),inputId=randomUUID();
  const server=createSdkMcpServer({name:'results',version:'1',tools:[tool(name,'Inspect and acknowledge isolated delegation result',{action:z.enum(['read','ack']),resultId:z.string(),token:z.string().optional(),revision:z.string().optional()},async args=>{log('tool-call',args);const value=await io.call(args);log('tool-response',value);return{content:[{type:'text',text:JSON.stringify(value)}]};})]});
  const q=query({prompt:(async function*(){const text=await input.promise;yield{type:'user',uuid:inputId,parent_tool_use_id:null,session_id:'',message:{role:'user',content:text}};await end.promise;})(),options:{pathToClaudeCodeExecutable:prepared.executable,cwd:f.snapshot.native.cwd,model:'claude-haiku-4-5',settingSources:[],env:prepared.env,mcpServers:{results:server},allowedTools:['mcp__results__'+name],spawnClaudeCodeProcess:o=>spawn(o.command,o.args,{cwd:f.snapshot.native.cwd,env:prepared.env})}});
  const consume=(async()=>{try{for await(const m of q){log('native',m);if(m.type==='result'&&m.user_message_uuid===inputId)done.resolve(m);}}catch(e){done.reject(e);log('consumer-error',{message:e.message});}})();
  return{ready:()=>q.initializationResult(),begin:async text=>input.resolve(text),done:done.promise,consume,close:()=>{end.resolve();q.close();}};
 }
 const child=spawn(prepared.executable,['app-server','--disable','plugins','-c','analytics.enabled=false','-c','model_provider="m14"','-c','model_providers.m14={name="m14",base_url='+JSON.stringify(f.researchBase+'/v1')+',wire_api="responses",env_key="WY_MODEL_KEY",request_max_retries=0,stream_max_retries=0}'],{cwd:f.snapshot.native.cwd,env:prepared.env}),pending=new Map();let sequence=0,thread,turn;
 const rpc=(method,params)=>{const id=++sequence,d=deferred();pending.set(id,d);const frame={id,method,params};log('requests',frame);child.stdin.write(JSON.stringify(frame)+'\n');return d.promise;};
 createInterface({input:child.stdout}).on('line',line=>{let m;try{m=JSON.parse(line);log('native',m);}catch(e){done.reject(e);return;}
  if(m.method&&m.id!==undefined){(async()=>{assert.equal(m.method,'item/tool/call');assert.equal(m.params.threadId,thread);assert.equal(m.params.tool,name);assert(m.params.callId&&m.params.turnId);if(turn)assert.equal(m.params.turnId,turn);log('tool-call',m.params);const value=await io.call(m.params.arguments);if(child.exitCode!==null||child.signalCode!==null){log('response-discarded',{requestId:m.id});return;}const response={id:m.id,result:{success:true,contentItems:[{type:'inputText',text:JSON.stringify(value)}]}};log('tool-response',response);child.stdin.write(JSON.stringify(response)+'\n');})().catch(e=>done.reject(e));return;}
  if(m.id!==undefined){const d=pending.get(m.id);if(!d){done.reject(Error('UNMATCHED_REPLY'));return;}pending.delete(m.id);m.error?d.reject(Error(JSON.stringify(m.error))):d.resolve(m.result);}
  if(m.method==='turn/completed')done.resolve(m.params.turn);
 });
 child.stderr.on('data',b=>appendFileSync(out+'/'+id+'-stderr.log',b));child.once('exit',()=>{for(const d of pending.values())d.reject(Error('NATIVE_EXIT'));pending.clear();});
 return{ready:async()=>{const r=await rpc('initialize',{clientInfo:{name:'m14_result_transport_probe',version:'1'},capabilities:{experimentalApi:true}});child.stdin.write('{"method":"initialized"}\n');return r;},begin:async text=>{const r=await rpc('thread/start',{cwd:f.snapshot.native.cwd,model:'gpt-5.3-codex',modelProvider:'m14',approvalPolicy:'never',sandbox:'read-only',dynamicTools:[{type:'function',name,description:'Inspect and acknowledge isolated delegation result',inputSchema:{type:'object',properties:{action:{type:'string',enum:['read','ack']},resultId:{type:'string'},token:{type:'string'},revision:{type:'string'}},required:['action','resultId'],additionalProperties:false}}]});thread=r.thread.id;const v=await rpc('turn/start',{threadId:thread,clientUserMessageId:randomUUID(),input:[{type:'text',text,text_elements:[]}]});turn=v.turn.id;return{thread,turn};},done:done.promise,consume:Promise.resolve(),close:()=>child.stdin.end()};
};}
export function reply(res,driver,body,decision){
 res.writeHead(200,{'content-type':'text/event-stream'});const e=(type,obj)=>res.write(`event: ${type}\ndata: ${JSON.stringify({type,...obj})}\n\n`),call=!!decision.tool;
 if(driver==='claude'){
  e('message_start',{message:{id:'m'+randomUUID(),type:'message',role:'assistant',model:body.model,content:[],stop_reason:null,usage:{input_tokens:1,output_tokens:0}}});e('content_block_start',{index:0,content_block:call?{type:'tool_use',id:'toolu_'+randomUUID(),name:decision.tool.name,input:{}}:{type:'text',text:''}});e('content_block_delta',{index:0,delta:call?{type:'input_json_delta',partial_json:JSON.stringify(decision.args)}:{type:'text_delta',text:decision.text}});e('content_block_stop',{index:0});e('message_delta',{delta:{stop_reason:call?'tool_use':'end_turn'},usage:{output_tokens:1}});e('message_stop',{});
 }else{
  const rid='r'+randomUUID(),item=call?{id:'fc'+randomUUID(),type:'function_call',call_id:'call'+randomUUID(),name:decision.tool.name,...(decision.tool.namespace?{namespace:decision.tool.namespace}:{}),arguments:JSON.stringify(decision.args),status:'completed'}:{id:'m'+randomUUID(),type:'message',role:'assistant',status:'completed',content:[{type:'output_text',text:decision.text,annotations:[]}]};e('response.created',{response:{id:rid,status:'in_progress',output:[]}});e('response.output_item.added',{output_index:0,item:{...item,status:'in_progress'}});if(!call)e('response.output_text.delta',{item_id:item.id,output_index:0,content_index:0,delta:decision.text});e('response.output_item.done',{output_index:0,item});e('response.completed',{response:{id:rid,status:'completed',output:[item],usage:{input_tokens:1,output_tokens:1,total_tokens:2}}});
 }res.end();
}
