import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {randomUUID} from 'node:crypto';
import {mkdtempSync,readFileSync,writeFileSync,appendFileSync,copyFileSync,readdirSync} from 'node:fs';
import actual from './candidate.cjs';
import {setup} from './fixture.mjs';
import {profiles} from './joint.mjs';
import {revision} from './revision.mjs';
import {baseEnv,nativeRuntime} from './native-inputs.mjs';
import {prepareExecution} from './execution.mjs';
import {createLaunch,start,cancel,deferred,state} from './launch.mjs';
import {Results} from './result.mjs';
import {reconcileOffered,stopOldObservation} from './reconcile.mjs';
import {transport,reply} from './transport.mjs';
const root=import.meta.dirname,out=mkdtempSync(root+'/attempt-'),checks=[],trace=[],launches=[],save=(p,x)=>writeFileSync(p,JSON.stringify(x,null,2)+'\n');
for(const n of readdirSync(root).filter(n=>/\.(mjs|cjs|json|sql|ts|variant)$/.test(n)))copyFileSync(root+'/'+n,out+'/'+n);
const mark=(id,event,data={})=>{const entry={id,event,...data};trace.push(entry);appendFileSync(out+'/trace.jsonl',JSON.stringify(entry)+'\n');};
const deadline=(p,label)=>{let timer;return Promise.race([p,new Promise((_,reject)=>timer=setTimeout(()=>reject(Error('OBSERVATION_TIMEOUT:'+label)),45000))]).finally(()=>clearTimeout(timer));};
let f,results,server,base,active,error,oldOffer;const models=[],held=deferred(),release=deferred();
const row=id=>f.sqlite.prepare('SELECT * FROM child_result WHERE id=?').get(id);
const check=async(id,label,fn)=>{try{checks.push({id,label,status:'passed',evidence:await fn()});}catch(e){checks.push({id,label,status:'failed',error:e.stack});throw e;}finally{save(out+'/progress.json',{checks});if(f){assert.deepEqual(f.sqlite.pragma('foreign_key_check'),[]);assert.deepEqual(f.sqlite.pragma('integrity_check'),[{integrity_check:'ok'}]);await f.sqlite.backup(out+'/'+id+'.sqlite');}console.log(JSON.stringify({id,status:checks.at(-1).status}));}};
async function parent(driver,id,resultId,{hold=false,staleToken}={}){
 const index=driver==='codex'?1:0,run=await f.reserve(index);await run.prepare();
 const p={...f,run,runs:f.programmaticRuns,snapshot:f.snapshots[index],scope:f.scopes[index],profile:f.profiles[driver],adapter:f.adapters.get(f.snapshots[index].runner),runtime:nativeRuntime(driver)};p.baseEnv=baseEnv(p);p.researchBase=base;
 const plan=await prepareExecution(p,p.runtime),launch=createLaunch(p,plan,{mark:(e,d)=>mark(id,e,d)}),entry={id,driver,p,launch,resultId,count:0,toolCount:0,hold,staleToken,offer:null,input:'INSPECT_CHILD_RESULT '+resultId};launches.push(entry);active=entry;
 const io={call:async args=>{entry.toolCount++;assert.equal(args.resultId,resultId);let value;
  if(args.action==='read'){value=await results.read(run,resultId);entry.offer=value;mark(id,'read-committed',{token:value.token,observed:row(resultId).observed});if(hold){oldOffer=value;held.resolve();await release.promise;}}
  else{assert.equal(args.action,'ack');try{value=await results.ack(run,resultId,args.token,args.revision);}catch(e){if(args.token!==staleToken)throw e;assert.match(e.message,/OBSERVATION_SCOPE_CHANGED/);value={blocked:true,code:'OBSERVATION_SCOPE_CHANGED'};mark(id,'stale-token-rejected');}}
  return value;
 }};
 const started=await start(launch,transport(out,p,driver,id,io));entry.native=started.runtime;await deadline(started.attached,id+' attach');save(out+'/'+id+'-initialize.json',await deadline(entry.native.ready(),id+' init'));await deadline(entry.native.begin(entry.input),id+' begin');return entry;
}
try{
 server=createServer(async(req,res)=>{try{let raw='';for await(const b of req)raw+=b;const body=JSON.parse(raw),e=active;assert(e);e.p.runs.assertActive(e.p.run.runId);e.count++;assert(e.count<=4);models.push({id:e.id,count:e.count,body});appendFileSync(out+'/model.jsonl',JSON.stringify(models.at(-1))+'\n');
  const content=JSON.stringify(body.messages??body.input),tools=(body.tools??[]).flatMap(t=>t.type==='namespace'?(t.tools??[]).map(x=>({...x,namespace:t.name})):[t]),tool=tools.find(t=>t.name.includes('willyou_result'));assert(tool,'RESULT_TOOL_NOT_ADVERTISED');
  let decision;
  if(e.count===1){assert(content.includes(e.input));assert(!content.includes(row(e.resultId).body));assert.equal(row(e.resultId).observed,0);decision={tool,args:{action:'read',resultId:e.resultId}};}
  else{assert(content.includes(e.offer.body));assert(content.includes(e.offer.token));assert(content.includes(e.offer.revision));mark(e.id,'result-and-token-visible-to-native-model',{count:e.count,token:e.offer.token});
   if(e.count===2&&e.staleToken)decision={tool,args:{action:'ack',resultId:e.resultId,token:e.staleToken,revision:e.offer.revision}};
   else if(e.count===(e.staleToken?3:2)){if(e.staleToken){assert(content.includes('OBSERVATION_SCOPE_CHANGED'));assert.equal(row(e.resultId).ack_count,0);}decision={tool,args:{action:'ack',resultId:e.resultId,token:e.offer.token,revision:e.offer.revision}};}
   else{assert.equal(row(e.resultId).ack_count,1);assert(content.includes('observed'));decision={text:'RESULT_RECEIVED_AND_CONFIRMED'};}
  }reply(res,e.driver,body,decision);
 }catch(e){error??=e.stack;res.writeHead(500);res.end('{}');}});
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
 f=await setup(new actual.MacProcessIdentityReader('/private/tmp/willyou-m14-owner-probe/process-identity'));profiles(f);
 const profile=f.profileService.get(f.profiles.claude);f.profileService.update(profile.id,{name:profile.name,runner:profile.runner,executable:profile.executable,env:[{name:'ANTHROPIC_BASE_URL',secret:false,value:base},{name:'ANTHROPIC_AUTH_TOKEN',secret:true,value:'synthetic-only'}],args:[],color:null,isDefault:false});f.sqlite.prepare('UPDATE m14_binding SET profile_revision=? WHERE profile_id=?').run(revision(f.sqlite,profile.id),profile.id);
 f.sqlite.exec(readFileSync(root+'/result.sql','utf8'));f.sqlite.prepare('INSERT INTO route VALUES(?,?,1,0)').run(f.logicalTaskId,f.scopes[1].bindingId);results=new Results(f);
 const first=randomUUID(),second=randomUUID();await results.seed(f.logicalTaskId,first,'SYNTHETIC_UNREAD_RESULT_'+first);await results.seed(f.logicalTaskId,second,'SYNTHETIC_FINAL_RESULT_'+second);let A,B,C;
 await check('T01','real Codex result tool commits but response is held before native consumption',async()=>{A=await parent('codex','codex-held',first,{hold:true});await deadline(held.promise,'held result');assert.equal(A.count,1);assert.equal(A.toolCount,1);assert.equal(row(first).observed,0);assert(!JSON.stringify(models).includes(row(first).body));await cancel(A.launch);release.resolve();assert.equal(state(A.launch).runState,'stopped');await assert.rejects(results.switch(f.logicalTaskId,f.scopes[0].bindingId),/OBSERVATION_UNRESOLVED/);return{actualDynamicToolCall:true,bodyNotInModelRequest:true,readCommittedButUnobserved:true,drainDoesNotClearUnresolvedObservation:true};});
 await check('T02','explicit stopped-run observation disposition preserves unread result and permits switch',async()=>{assert.equal(await reconcileOffered(results,f.logicalTaskId),1);await assert.rejects(results.switch(f.logicalTaskId,f.scopes[0].bindingId),/OBSERVATION_UNRESOLVED/);await assert.rejects(stopOldObservation(results,f.logicalTaskId,oldOffer.token,'implicit-retry'),/EXPLICIT_DECISION_REQUIRED/);await stopOldObservation(results,f.logicalTaskId,oldOffer.token,'fixture-explicit-reinspect-unread-result');assert.equal(row(first).observed,0);await results.switch(f.logicalTaskId,f.scopes[0].bindingId);return{unknownBlocksSwitch:true,fixtureExplicitDisposition:true,noChildRestart:true,noObservationInvented:true};});
 await check('T03','Claude SDK MCP consumes same result and rejects old Codex observation token',async()=>{B=await parent('claude','claude-current',first,{staleToken:oldOffer.token});const end=await deadline(B.native.done,'Claude result');assert.equal(end.is_error,false);assert.equal(end.result,'RESULT_RECEIVED_AND_CONFIRMED');assert.equal(B.count,4);assert.equal(B.toolCount,3);assert.equal(row(first).ack_count,1);assert.notEqual(B.offer.token,oldOffer.token);await cancel(B.launch);await B.native.consume;return{sdkInProcessMcp:true,sameLogicalTask:true,sameResult:true,resultTokenInModelRequest:true,oldTokenRejected:true,ackCount:1};});
 await check('T04','switch back to Codex uses same result service and consumes second unread result',async()=>{await results.switch(f.logicalTaskId,f.scopes[1].bindingId);C=await parent('codex','codex-current',second);const end=await deadline(C.native.done,'Codex result');assert.equal(end.status,'completed');assert.equal(C.count,3);assert.equal(C.toolCount,2);assert.equal(row(second).ack_count,1);assert.equal((await results.ack(C.p.run,second,C.offer.token,C.offer.revision)).replay,true);assert.equal(row(second).ack_count,1);await cancel(C.launch);return{appServerDynamicTool:true,oneSharedService:true,resultTokenInModelRequest:true,ackReplayIdempotent:true};});
}catch(e){error??=e.stack;process.exitCode=1;}
finally{release.resolve();const cleanup=[];if(f){for(const e of [...launches].reverse())try{await deadline(cancel(e.launch),'cleanup '+e.id);await e.native?.consume;cleanup.push({id:e.id,state:state(e.launch)});}catch(e){error??=e.stack;process.exitCode=1;cleanup.push({error:e.stack});}for(const h of f.handles)if(!['stopped','failed'].includes(f.programmaticRuns.get(h.runId).state))await h.stop('cleanup');await f.sqlite.backup(out+'/final.sqlite');save(out+'/fixture.json',{root:f.root,db:f.sqlite.name,taskId:f.logicalTaskId,bindings:f.scopes});f.sqlite.close();}if(server){server.closeAllConnections();await new Promise(r=>server.close(r));}save(out+'/cleanup.json',{cleanup,nativeExits:trace.filter(x=>x.event==='owned-exit')});}
const result={out,checks,passed:checks.filter(x=>x.status==='passed').length,modelRequests:models.length,error,scope:'Real programmatic owner, actual Codex dynamic tools and Claude SDK in-process MCP, same logical parent and candidate result service. Seeded child results and deterministic local model, held read response then actual native cancellation; explicit disposition is fixture host command, not production approval. No real child, automatic notice, business MCP, host crash or UI integration.'};save(out+'/result.json',result);save(root+'/latest.json',result);console.log(JSON.stringify({out,passed:result.passed,error}));
