import assert from 'node:assert/strict';
export async function reconcileOffered(results,task){return results.tx(()=>{
 const rows=results.db.prepare("SELECT o.*,r.state AS run_state,r.revocation_state FROM result_observation o JOIN capability_runs r ON r.run_id=o.run_id JOIN child_result c ON c.id=o.result_id WHERE c.parent_task=? AND o.state='offered'").all(task);
 for(const row of rows){assert(['stopped','failed'].includes(row.run_state)&&row.revocation_state==='revoked','OWNER_NOT_DRAINED');results.db.prepare("UPDATE result_observation SET state='unknown' WHERE token=?").run(row.token);results.event('observation-unknown',{token:row.token});}return rows.length;
});}
export async function stopOldObservation(results,task,token,decision){return results.tx(()=>{
 assert.equal(decision,'fixture-explicit-reinspect-unread-result','EXPLICIT_DECISION_REQUIRED');
 const row=results.db.prepare('SELECT o.*,r.state AS run_state,r.revocation_state FROM result_observation o JOIN capability_runs r ON r.run_id=o.run_id JOIN child_result c ON c.id=o.result_id WHERE c.parent_task=? AND o.token=?').get(task,token);assert(row&&row.state==='unknown'&&['stopped','failed'].includes(row.run_state)&&row.revocation_state==='revoked','OBSERVATION_NOT_DISPOSABLE');results.db.prepare("UPDATE result_observation SET state='disposed' WHERE token=?").run(token);results.event('observation-disposed',{token,decision});
});}
