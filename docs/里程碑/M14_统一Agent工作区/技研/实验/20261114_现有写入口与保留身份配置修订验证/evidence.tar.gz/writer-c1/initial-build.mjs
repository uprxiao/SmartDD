import {build} from '/private/tmp/willyou-m14-owner-probe/node_modules/esbuild/lib/main.js';
import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const r=import.meta.dirname,repo='/Users/hx/projects/SmartDD';
const result=await build({stdin:{contents:`export {TaskService} from '${repo}/src/main/core/tasks/task-service.ts';`,resolveDir:repo,loader:'ts'},bundle:true,platform:'node',format:'cjs',target:'node22',tsconfig:repo+'/tsconfig.node.json',external:['node-pty'],nodePaths:['/private/tmp/willyou-m14-owner-probe/node_modules','/private/tmp/willyou-m10-config-fix-9_31ogou/node_modules'],outfile:r+'/tasks.cjs',metafile:true});
writeFileSync(r+'/build.json',JSON.stringify({inputs:Object.keys(result.metafile.inputs).filter(p=>!p.startsWith('<')).map(p=>{const path=p.startsWith('/')?p:process.cwd()+'/'+p;return{path,sha256:createHash('sha256').update(readFileSync(path)).digest('hex')};})},null,2));
console.log(Object.keys(result.metafile.inputs).length);
