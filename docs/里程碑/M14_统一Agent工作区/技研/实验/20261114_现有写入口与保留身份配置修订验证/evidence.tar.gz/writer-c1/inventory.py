from pathlib import Path
import re,json,hashlib
base=Path('/Users/hx/projects/SmartDD');out=Path(__file__).resolve().parent
names=['tasks','projects','capability_runs','capability_run_processes','capability_run_activities','capability_resource_leases','capability_session_snapshots','capability_session_identities','capability_session_refs','capability_snapshot_versions','capability_session_mcp_names','capability_session_holds','ai_profiles','ai_run_configs','ai_providers','ai_tools','app_secrets']
orm={'tasks':'tasks','projects':'projects','aiProfiles':'ai_profiles','aiRunConfigs':'ai_run_configs','aiProviders':'ai_providers','aiTools':'ai_tools','appSecrets':'app_secrets'}
sql=re.compile(r'\b(INSERT\s+(?:OR\s+\w+\s+)?INTO|UPDATE|DELETE\s+FROM)\s+[`\"]?('+ '|'.join(names)+r')\b',re.I)
obj=re.compile(r'\.(insert|update|delete)\s*\(\s*('+ '|'.join(orm)+r')\s*\)',re.S)
files=[]
for p in sorted((base/'src/main').rglob('*.ts')):
 if '.test.' in p.name or '__tests__' in p.parts:continue
 text=p.read_text();matches=[]
 for pat,kind in [(sql,'literal-sql'),(obj,'orm')]:
  for m in pat.finditer(text):
   line=text.count('\n',0,m.start())+1;table=m.group(2) if kind=='literal-sql' else orm[m.group(2)]
   matches.append({'line':line,'kind':kind,'operation':m.group(1),'table':table,'matched':m.group(0)})
 if matches:files.append({'file':str(p.relative_to(base)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'matches':sorted(matches,key=lambda x:x['line'])})
result={'scope':'Static literal SQL and named Drizzle writes in src/main, excluding test files; not proof of all dynamic SQL, cascade or runtime paths. Direct and indirect callers separately reviewed in README.','tables':names,'files':files,'fileCount':len(files),'matchCount':sum(len(x['matches']) for x in files)}
(out/'writer-inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for x in files:print(x['file'],len(x['matches']),','.join(sorted(set(m['table'] for m in x['matches']))))
print('TOTAL',result['fileCount'],result['matchCount'])
