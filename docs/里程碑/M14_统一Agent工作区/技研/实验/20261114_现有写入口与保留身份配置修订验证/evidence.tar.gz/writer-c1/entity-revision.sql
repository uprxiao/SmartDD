CREATE TRIGGER m14_config_revision_insert AFTER INSERT ON ai_run_configs BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE profile_id=NEW.profile_id AND present=1; END;
CREATE TRIGGER m14_config_revision_change AFTER UPDATE ON ai_run_configs
WHEN OLD.tool_id IS NOT NEW.tool_id OR OLD.source IS NOT NEW.source OR OLD.provider_id IS NOT NEW.provider_id OR OLD.models IS NOT NEW.models OR OLD.default_model IS NOT NEW.default_model OR OLD.logged_out IS NOT NEW.logged_out OR OLD.legacy_reason IS NOT NEW.legacy_reason OR OLD.migration_version IS NOT NEW.migration_version
BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE profile_id IN (OLD.profile_id,NEW.profile_id) AND present=1; END;
CREATE TRIGGER m14_config_revision_delete AFTER DELETE ON ai_run_configs BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE profile_id=OLD.profile_id AND present=1; END;
CREATE TRIGGER m14_tool_revision_change AFTER UPDATE ON ai_tools
WHEN OLD.kind IS NOT NEW.kind OR OLD.executable IS NOT NEW.executable OR OLD.custom_path IS NOT NEW.custom_path OR OLD.version IS NOT NEW.version OR OLD.installed IS NOT NEW.installed OR OLD.login IS NOT NEW.login
BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (SELECT profile_id FROM ai_run_configs WHERE tool_id=NEW.id OR tool_id=OLD.id); END;
CREATE TRIGGER m14_provider_revision_change AFTER UPDATE ON ai_providers
WHEN OLD.preset IS NOT NEW.preset OR OLD.endpoints IS NOT NEW.endpoints OR OLD.auth_type IS NOT NEW.auth_type OR OLD.secret_ref IS NOT NEW.secret_ref OR OLD.identity_revision IS NOT NEW.identity_revision OR OLD.models IS NOT NEW.models OR OLD.recommended IS NOT NEW.recommended
BEGIN UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (SELECT profile_id FROM ai_run_configs WHERE provider_id=NEW.id OR provider_id=OLD.id); END;
CREATE TRIGGER m14_provider_secret_revision_insert AFTER INSERT ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (SELECT c.profile_id FROM ai_run_configs c JOIN ai_providers p ON c.provider_id=p.id WHERE p.secret_ref=NEW.key);
END;
CREATE TRIGGER m14_provider_secret_revision_update AFTER UPDATE ON app_secrets WHEN OLD.key IS NOT NEW.key OR OLD.secret IS NOT NEW.secret BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (SELECT c.profile_id FROM ai_run_configs c JOIN ai_providers p ON c.provider_id=p.id WHERE p.secret_ref=NEW.key OR p.secret_ref=OLD.key);
END;
CREATE TRIGGER m14_provider_secret_revision_delete AFTER DELETE ON app_secrets BEGIN
 UPDATE m14_profile_execution_revision SET revision=revision+1 WHERE present=1 AND profile_id IN (SELECT c.profile_id FROM ai_run_configs c JOIN ai_providers p ON c.provider_id=p.id WHERE p.secret_ref=OLD.key);
END;
