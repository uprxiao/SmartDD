from pathlib import Path
import json,hashlib,sqlite3,subprocess
p=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
result=json.loads((p/'latest.json').read_text());a=Path(result['out']);assert result['passed']==10 and not result.get('error')
assert json.loads((a/'result.json').read_text())==result
for n in ['probe.mjs','programmatic.mjs','native-binding.mjs','codex.mjs','candidate.cjs','profile.cjs','run-registry.ts.variant','session-registry.ts.variant','run-plan.ts.variant']:
 assert (p/n).read_bytes()==(a/n).read_bytes(),n
sources={}
for n in ['build.json','profile-build.json']:
 b=json.loads((p/n).read_text())
 for s in b['sources']:
  assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path'];sources[str(Path(s['path']).resolve())]=s
 for o in b.get('outputs',[]):
  assert sha(Path(o['file']).read_bytes())==o['sha256'];assert sha((a/Path(o['file']).name).read_bytes())==o['sha256']
  for patch in o.get('patches',[]):
   assert sha(Path(patch['path']).read_bytes())==patch['beforeHash'];assert sha((p/(Path(patch['path']).name+'.variant')).read_bytes())==patch['afterHash']
rows=[]
for attempt in sorted(p.glob('attempt-*')):
 r=json.loads((attempt/'result.json').read_text());c=json.loads((attempt/'cleanup.json').read_text());assert all(x.get('stopped') for x in c['cleanup']);assert len(c['nativeExits'])==len(c['cleanup']);assert all(x['code']==0 and x['signal'] is None for x in c['nativeExits'])
 requests=[json.loads(l) for f in attempt.glob('*-requests.jsonl') for l in f.read_text().splitlines()];assert set(x['method']for x in requests)<=set(['initialize','thread/start','thread/resume','thread/inject_items'])
 rows.append({'attempt':attempt.name,'passed':r['passed'],'failed':[x['id']for x in r['checks']if x['status']=='failed'],'exits':c['nativeExits'],'methods':sorted(set(x['method']for x in requests))})
fixture=json.loads((a/'fixture.json').read_text());first=json.loads((a/'first-thread-response.json').read_text())['result']['thread'];resume=json.loads((a/'resume-thread-response.json').read_text())['result']['thread'];assert first['id']==resume['id']==fixture['nativeIdentity']['sessionId']
rollout=Path(resume['path']).resolve();assert rollout.is_relative_to(Path(fixture['root']).resolve());data=rollout.read_bytes();events=[json.loads(l)for l in data.splitlines()];meta=[x for x in events if x['type']=='session_meta'];assert any(x['payload']['id']==resume['id']for x in meta);assert b'ISOLATED_HANDOFF_CONTEXT_NOT_USER_AUTHORITY' in data
(a/'persisted-rollout.jsonl').write_bytes(data)
h={'threadId':resume['id'],'nativeVersion':resume['cliVersion'],'rolloutSha256':sha(data),'rolloutRecords':len(events),'sameNativeIdAfterProcessRestart':True,'syntheticDeveloperHistoryPersisted':True,'modelTurns':0,'limit':'Proves native resume after explicit history injection; not model comprehension, input delivery recovery, or durability of an empty newly created thread.'}
(p/'history-evidence.json').write_text(json.dumps(h,indent=2))
negative=json.loads((p/'attempt-MT5tb8/result.json').read_text());assert negative['passed']==0 and 'CURRENT_REVISION_CHANGED' in negative['error']
(p/'receipt-negative.json').write_text(json.dumps({'attempt':'attempt-MT5tb8','status':'reproduced','finding':'After a real native ID is bound, retrying the original immutable publication receipt was incorrectly required to match the mutable current revision.','error':negative['error'],'scope':'Isolated candidate defect; not a proven production defect.'},indent=2))
for db in p.glob('attempt-*/*.sqlite'):
 c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close()
runtime={'attempts':rows,'nativeExitCount':sum(len(x['exits'])for x in rows),'modelTurns':0,'capturedExitEventsVerified':True,'history':h,'sourceInputs':len(sources)}
(p/'runtime-audit.json').write_text(json.dumps(runtime,indent=2))
print(json.dumps({'final':a.name,'checks':result['passed'],'attempts':len(rows),'nativeExits':runtime['nativeExitCount'],'sourceInputs':len(sources),'history':h}))
