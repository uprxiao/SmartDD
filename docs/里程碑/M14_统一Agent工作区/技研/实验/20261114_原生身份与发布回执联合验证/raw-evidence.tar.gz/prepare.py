from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生身份与发布回执联合验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==10 and not result.get('error');attempt=Path(result['out']);runtime=json.loads((root/'runtime-audit.json').read_text());assert runtime['nativeExitCount']==12
refs=[repo/'src/main/core/applications/session-registry.ts',repo/'src/main/core/applications/run-registry.ts',t3/'apps/server/src/orchestration-v2/Adapters/CodexAdapterV2.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputsUniqueResolved':runtime['sourceInputs'],'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Real Codex 0.167.1 initialization/start/inject/resume with isolated source and ownership variants. T3 ensureThread/resumeNativeThread source review; no claim about unreviewed callers or production end-to-end behavior.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and 'node_modules'not in p.parts and 'publication'not in p.parts and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2))]+[(n,(root/n).read_bytes())for n in ['receipt-negative.json','empty-native-negative.json','runtime-audit.json','source-review.json','history-evidence.json']]+[('result.json',json.dumps(result,indent=2))]:put(exp/n,data)
put(exp/'README.md',f'''# 原生身份、发布回执与后续运行：隔离技术验证

2026-11-14；对应 R02／03／04／08／10，Q13／14／17／24／48，技术方案 §3.2.9、验证账 §4.47。当前是技术研究与临时验证，没有产品开发或正式验收。

## 发现与结论

程序化发布的原始快照没有 native ID。Codex 的真实 `thread/start` 返回身份后，首次绑定推进了当前 revision；此前候选重试发布时却要求原收据 hash 等于当前 hash，产生 `CURRENT_REVISION_CHANGED`。`attempt-MT5tb8` 保存真实失败及数据库。这是隔离候选的设计缺口，不是已证明的产品缺陷。

候选现在分开读取不可变发布事实、每次 run 的不可变启动来源和可推进的当前来源。同 attempt 重试仍用原始请求／来源并返回同一个私有 run；后续明确创建的新 run 才选用当前来源。历史收据查询不授权执行，执行仍必须经过实际 owner、活动能力、资源与当前政策检查。首次 native ID 回调核对实际私有 run、其固定来源及 runner／stateRoot／cwd；已停止的旧 run、复制的 handle、另一 run 的来源不能写入。

第二个实际反例是 `attempt-ScZDFK`：只建会话取得 ID、没有注入历史也没有模型回合，结束进程后以同 ID 恢复，原生返回 `no rollout found`。即使 start 回复带有 path，也不能直接把 ID／path 当成历史已经可恢复的证明。

最终实验显式写入一条合成 developer 上下文后结束旧进程，使用新 run／新原生进程恢复同一 thread ID 成功；保留的 rollout 确认 session_meta 身份一致且包含该记录。此结果只证明这一条件下的磁盘历史与原生恢复，不证明模型理解了上下文、用户输入已执行或整个 App 崩溃后自动恢复。不能用填充无意义消息来掩盖空会话不可恢复。

## 实验路径与结果

复用现有 PackageRegistry、ResourceStore、运行／能力服务和实际配置构建输入，改动的绑定／来源／计划逻辑仅在临时 variant。真实父 Codex 只完成初始化，宿主服务直接接受子请求，子端通过受控 launcher 启动 Codex 0.167.1。独立 HOME／状态目录、合成 Key、模型地址和代理固定为本机不可用地址；没有 `turn/start`、模型费用或业务写入。

最终 `{attempt.name}` N01–N10 通过：

| 项 | 核对的行为 |
| --- | --- |
| N01 | 真正取得首次 native ID 后，重复发布仍返回原始收据 |
| N02 | 原始发布／run 来源、当前 native revision 分离，v1 应用计划、ExecutionPlan、delivery 字节不变 |
| N03 | 同 native ID 重复回调幂等；不同 ID 拒绝，不增加修订 |
| N04 | 同 attempt 使用原来源复用原私有 run 与计划；擅用当前 hash 改写同请求则冲突 |
| N05 | 复制 handle、改变 stateRoot 均不能绑定 |
| N06 | 注入隔离上下文后旧进程退出，generation 2 的明确新 run／新进程恢复同 ID；旧 run 回调拒绝 |
| N07 | 能力 hold 后原发布事实仍可读，活动执行被拒绝 |
| N08 | 篡改历史发布收据被拒绝 |
| N09 | 后续 run 用自己的启动来源回调成功；借前一 run 的来源拒绝 |
| N10 | 真实首次 ID 写入中途故障，身份指针／修订／运行与计划整体回滚；同 ID 精确重试成功 |

`attempt-coa0LI` 是修正后的八项结果；随后新增 N09／N10，最终全批通过。保存四轮完整过程，不将第一次负对照或无历史恢复失败删除。四轮共十二个捕获原生进程均有正常退出回执，最终一轮四个；没有依据名称扫描或终止其他进程。

## T3 对照与适用边界

本地 T3 `CodexAdapterV2.ensureThread` 调用 thread/start；`resumeThread` 使用既有 native ID。所核对的 `resumeNativeThread` 对 archived 和 closing 分别处理，其余错误向上返回；此 helper 没有通用的“恢复失败就创建新身份”。这是所审阅方法的行为，不扩张为全部上层调用的结论。`restoreAdditionalContext` 的历史注入机制可参考，但 WillYou 必须保留输入来源、投递证据与业务授权。

新 run 是正常显式继续，不是上一批 outbox 的死亡宿主 attempt 2。尚未联合验证 native 已接受后的宿主中断、模型输入／业务在途、Claude 的真实 ID 回调、完整协议 Schema 或应用迁移器；首次 native 写入的通用合同不能由 Codex 一端实验直接证明其他 provider。没有修改产品、共享原型或 T3。

## 证据与复跑

[最终结果](result.json)、[发布收据负对照](receipt-negative.json)、[空会话恢复负对照](empty-native-negative.json)、[历史落盘证据](history-evidence.json)、[进程收尾](runtime-audit.json)、[源码依据](source-review.json)、[文件哈希](archive-manifest.json)、[全部轮次](raw-evidence.tar.gz)。归档 {len(files)} 个文件、{len(dbs)} 份通过完整性／外键检查的 SQLite；构建输入按解析后的路径去重为 {runtime['sourceInputs']} 个。

复跑需在新临时目录恢复归档的依赖版本与源码基线、调整绝对路径，执行 build.mjs、profile-build.mjs、probe.mjs，再运行 evidence-audit.py。生成的最终 variant 已含修正，不重复套用 refine-source.py。输入／环境必须隔离，不使用用户凭据、日常数据库或工作目录；观察超时应先核验原捕获进程，不盲目重启。
''')
addition='''
发布收据也必须独立于当前 revision：[真实 Codex 联合实验](实验/20261114_原生身份与发布回执联合验证/README.md)已复现首次 native ID 后，原始发布重试被错误要求等于当前 hash。发布收据保存首次请求与其来源，供历史查询／幂等核对；解析当前来源是另一操作，只允许同 binding／cap 中经过合法首次身份转换的修订。同 attempt 重试保留最初请求，不能拿当前 hash 重写它；下一次明确的新 run 选择当前合法修订。原 v1 应用计划、ExecutionPlan 和 delivery 保持字节不变。历史事实可读不表示活动能力有效，hold／撤权后的执行仍拒绝。

回调必须来自已关联的原生协议响应及实际持有者，核对私有 run、其固定 source、runner、stateRoot、cwd 和当前活动状态；不能接受由工具参数拼出的身份。新 run 回调用自己的 source，旧 run／旧来源／复制的 handle 不可代用。首次写入中途故障须整体回滚，精确重试可幂等完成。此次真实 Codex 证据覆盖这条绑定链，Claude 与完整应用中断链仍分别待验。

原生身份与恢复能力分开记录。Codex 0.167.1 的隔离反例中，thread/start 返回 ID 与 path，空会话退出后 thread/resume 仍报 `no rollout found`；明确注入隔离 developer 历史后，新进程恢复同 ID 成功。因此 ID known 不等于 durable/resumable。恢复记录保存最后一次检查的 run、runtime 版本、身份范围、结果和错误；成功只是当时观察，不是永久保证。遇到缺失历史／状态目录变更／损坏时保留原 binding、统一历史和失败事实，停止自动续传，不能静默换新 ID 并伪装为原生恢复。已有规范历史可用于明确的交接新建，但要生成独立绑定／交接证据并显示恢复差异；未知输入不得因此自动重发。不得为了使空会话“可恢复”自动注入无意义消息。
'''
def tech(t):
 anchor='首次 native ID 的写入必须在同一协调边界和数据库事务更新：';a=t.index(anchor);b=t.index('\n\n',a);t=t[:b]+ '\n'+addition+t[b:]
 old='本批两 runner 夹具、实际 v1 来源检查、事务故障和下一 run 已取得八项局部证据；完整程序化运行入口、真实两端 ID 回调和宿主中断仍待联合。'
 new='早批两 runner 夹具、实际 v1 来源检查、事务故障和下一 run 已取得局部证据；§3.2.13 及本节新增实验补程序化入口与真实 Codex ID 回调，首次身份之后的宿主中断、Claude 原生回调与业务在途仍待联合。'
 assert old in t;t=t.replace(old,new)
 t=t.replace('首次 native ID 已修订后的发布收据查询、完整业务桥及共享目录仍按各自缺口验证。','§3.2.9 已补首次 native ID 后的发布收据、固定来源和当前修订读取；首次身份后的宿主中断、完整业务桥及共享目录仍按各自缺口验证。')
 t=t.replace('已派发／范围未知时的对账、首次 native 回调及业务桥仍待联合','已派发／范围未知时的对账、Claude native 回调及业务桥仍待联合（Codex 首次绑定见 §3.2.9）')
 t=t.replace('完整 App 重启、原生已接受后的恢复、首次 native 修订及业务在途仍须补证；','完整 App 重启、原生已接受后失联与业务在途仍须补证；正常首次 native 修订及原生恢复的限定证据见 §3.2.9；')
 return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.47 真实原生身份、发布收据与后续运行

[联合实验](实验/20261114_原生身份与发布回执联合验证/README.md)以真实 Codex thread/start 复现：首次 native ID 改变当前修订后，旧候选把发布收据误当当前来源而拒绝幂等重试。分开不可变发布事实、每个 run 固定来源和当前修订后，最终 N01–N10 覆盖重试、计划不变、私有 owner、旧／新 run 来源、hold、收据篡改及首次绑定事务回滚。历史可读不授权执行。四轮十二个捕获进程均正常退出，完整保留负对照。

另一个有效负例是空会话获得 ID 后退出，恢复报 no rollout found；明确注入合成 developer 历史后，新 run／新进程恢复同 ID 成功，磁盘 rollout 保存身份及上下文。没有模型回合，不能宣称已证明模型上下文继承或输入恢复。这里是正常新 run，不是宿主崩溃后的自动重试；Claude 实际回调、业务在途和完整应用恢复仍待验证。T0.1 §3.2.9 更新发布／来源／恢复状态的区别；Q13／14／17／24／48 保持部分。

'''
def account(t):
 assert '### 4.47 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q13','Q14','Q17','Q24','Q48']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.47 补真实 Codex 首次身份、不可变发布／运行来源及有历史时新进程恢复，空会话不可恢复负例保留 |';t='\n'.join(lines)+'\n'
 t=t.replace('剩余决定性验证：原生已派发／后台范围不明时的对账、首次 native 回调与来源复用；','§4.47 补真实 Codex 首次回调、发布收据复用与有历史时的显式新 run 恢复。剩余决定性验证：原生已派发／后台范围不明时的对账、Claude 真实回调及跨宿主来源复用；')
 old='接下来优先核验首次 native 身份修订后，发布收据／固定来源／当前修订／运行尝试如何继续读取与恢复；已派发输入、业务在途和未知原生范围不得借未启动重试规则放行。'
 new='§4.47 已补首次 Codex 身份后发布收据／固定来源／当前修订读取，以及有历史时显式新 run 的恢复；保留空会话无法恢复的反例。下一步按矩阵核验跨宿主输入／结果对账、Claude 身份回调及通用合同，避免把原生 ID 当作持久历史或已接受输入的证明；已派发输入、业务在途和未知原生范围不得借未启动重试规则放行。'
 assert old in t;t=t.replace(old,new);return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：已补真实 Codex 首次会话身份、发布收据重试及后续运行恢复的隔离验证，见[技术方案 §3.2.9](技研/技术方案.md)。确认会话 ID／path 不保证空历史可恢复；有明确历史记录时新进程恢复同 ID 成功。未调用模型，未进行产品联调或验收。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续收口跨宿主输入／结果对账、Claude 身份回调与通用协议合同；结果观察竞争、安装／版本／平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs),'sourceInputs':runtime['sourceInputs']}))
