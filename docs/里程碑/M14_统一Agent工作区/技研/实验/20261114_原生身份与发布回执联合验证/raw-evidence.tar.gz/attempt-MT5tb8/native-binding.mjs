import {bindProgrammaticNative} from './programmatic.mjs';
export async function bindOwnedNative(f,scope,native){return bindProgrammaticNative(f.store,scope,native.sessionId);}
