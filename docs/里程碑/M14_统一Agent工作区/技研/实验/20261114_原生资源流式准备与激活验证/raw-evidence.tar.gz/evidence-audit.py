from pathlib import Path
import hashlib,json,sqlite3
p=Path(__file__).resolve().parent;sha=lambda b:hashlib.sha256(b).hexdigest();r=json.loads((p/'latest.json').read_text());a=Path(r['out']);assert r['passed']==12 and not r.get('error');cache=json.loads((p/'cache-latest.json').read_text());assert len(cache['checks'])==3 and not cache.get('error')
for n in ['artifact.mjs','actual.cjs','build.json','probe.mjs']:assert (p/n).read_bytes()==(a/n).read_bytes()
for n in ['artifact.mjs','actual.cjs','cache-probe.mjs']:assert (p/n).read_bytes()==(Path(cache['out'])/n).read_bytes()
b=json.loads((p/'build.json').read_text())
for s in b['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
assert sha(Path(b['output']['file']).read_bytes())==b['output']['sha256'];rows=[]
for attempt in sorted(p.glob('attempt-*')):
 result=json.loads((attempt/'result.json').read_text());exits=json.loads((attempt/'native-exits.json').read_text());assert len(exits)==1 and exits[0]['code']==0 and exits[0]['signal']is None;rows.append({'attempt':attempt.name,'passed':result['passed'],'failure':result.get('error'),'exits':exits})
for db in [*p.glob('attempt-*/*.sqlite'),*p.glob('cache-*/*.sqlite')]:
 c=sqlite3.connect(db.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];assert c.execute('pragma foreign_key_check').fetchall()==[];c.close()
manifest=json.loads((a/'native-manifest.json').read_text());hash_id=sha(json.dumps(manifest,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
# Artifact path is taken from the actual recorded publication, not recomputed with Python's key comparator.
record=next(x for x in r['checks']if x['id']=='S02')['evidence'];fixture=json.loads((a/'fixture.json').read_text());directory=Path(fixture['storeRoot'])/'agent-native'/record['resourceId'].split(':')[1]
for f in manifest['files']:
 path=directory/f['path'];h=hashlib.sha256();size=0
 with path.open('rb')as stream:
  for block in iter(lambda:stream.read(262144),b''):h.update(block);size+=len(block)
 assert size==f['size'] and h.hexdigest()==f['sha256'],f['path']
 assert path.stat().st_mode&0o777==(0o500 if f['executable']else 0o400)
runtime={'attempts':rows,'nativeExitCount':len(rows),'sourceInputs':len(b['sources']),'artifact':record,'publishedFilesRehashed':len(manifest['files']),'cacheChecks':cache['checks'],'limits':['Local package input, not network/archive extraction','Pin is a resource lookup, not a real run lease','No installer host death or platform package test','Chunk bound is not a full RSS or UI performance measurement']};(p/'runtime-audit.json').write_text(json.dumps(runtime,indent=2));print(json.dumps({'mainPassed':12,'cachePassed':3,'nativeExits':len(rows),'publishedFilesRehashed':len(manifest['files']),'sourceInputs':len(b['sources'])}))
