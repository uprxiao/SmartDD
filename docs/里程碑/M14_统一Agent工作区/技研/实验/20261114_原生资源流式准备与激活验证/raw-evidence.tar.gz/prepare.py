from pathlib import Path
import hashlib,json,tarfile,sqlite3,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/hx/projects/SmartDD');t3=Path('/Users/hx/projects/t3code');base=Path('docs/里程碑/M14_统一Agent工作区');stage=root/'publication';exp=base/'技研/实验/20261114_原生资源流式准备与激活验证';entries=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(rel,data):
 if isinstance(data,str):data=data.encode()
 p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);old=repo/rel;entries.append({'path':str(rel),'before':sha(old.read_bytes())if old.exists()else None,'after':sha(data)})
def edit(rel,fn):put(rel,fn((repo/rel).read_text()))
result=json.loads((root/'latest.json').read_text());assert result['passed']==12 and not result.get('error');a=Path(result['out']);cache=json.loads((root/'cache-latest.json').read_text());assert len(cache['checks'])==3 and not cache.get('error');runtime=json.loads((root/'runtime-audit.json').read_text());assert runtime['nativeExitCount']==3
build=json.loads((root/'build.json').read_text())
for s in build['sources']:assert sha(Path(s['path']).read_bytes())==s['sha256'],s['path']
refs=[repo/'src/main/core/applications/resource-store.ts',repo/'src/main/core/applications/resource-lock.ts',repo/'src/main/core/applications/coordinator-lock.ts',t3/'apps/server/src/provider/CodexInstallation.ts']
review={'smartddHead':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'t3Head':subprocess.check_output(['git','-C',str(t3),'rev-parse','HEAD'],text=True).strip(),'sourceInputs':len(build['sources']),'references':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in refs],'scope':'Actual ResourceStore and coordinator, isolated manifest/streaming/activation candidate. Native Codex package copied from isolated dependency cache and executed only with --version. T3 installation is a source reference.'}
(root/'source-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2))
files=[p for p in root.rglob('*')if p.is_file() and not any(x in p.parts for x in ['node_modules','publication','data']) and p.suffix in ['.mjs','.cjs','.sql','.sqlite','.json','.jsonl','.ts','.variant','.log','.py'] and p.name not in ['manifest.json','archive-manifest.json','audit.json','publication-audit.json']];dbs=[]
for p in files:
 if p.suffix=='.sqlite':
  c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)],str(p);assert c.execute('pragma foreign_key_check').fetchall()==[],str(p);c.close();dbs.append(str(p.relative_to(root)))
with tarfile.open(root/'raw-evidence.tar.gz','w:gz')as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
m={'files':[{'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())}for p in sorted(files)],'sqliteIntegrityAndForeignKeys':dbs,'archiveSha256':sha((root/'raw-evidence.tar.gz').read_bytes())}
for n,data in [('raw-evidence.tar.gz',(root/'raw-evidence.tar.gz').read_bytes()),('archive-manifest.json',json.dumps(m,ensure_ascii=False,indent=2)),('result.json',json.dumps(result,indent=2)),('cache-result.json',json.dumps(cache,indent=2))]+[(n,(root/n).read_bytes())for n in ['driver-correction.json','baseline-negative.json','runtime-audit.json','source-review.json']]+[('native-manifest.json',(a/'native-manifest.json').read_bytes())]:put(exp/n,data)
put(exp/'README.md',f'''# 原生资源流式准备、复用与默认激活

2026-11-14；R02／08／10／11／12，Q01／03／46／48／51／52／53／54；技术方案 §12.1，验证账 §4.50。本批是隔离技术验证，未修改产品或共享原型。

## 核心路径

在现有 ResourceStore 外增加临时清单、异步流式准备和激活候选。清单固定 driver／版本／平台架构、入口及完整文件路径、大小、SHA256、执行位；拒绝路径逃逸、大小写同名、父子文件冲突、非执行入口及不匹配平台。准备在 C 资源协调区外逐文件流式复制、累计大小与摘要；完成后设置不可写权限并记录文件身份。传给现有同步 materialize 的工作是同文件系统 rename；最终 verify 核对文件集合和 dev／ino／size／mtimeNs／ctimeNs／mode，无网络或异步 Promise。

此文件身份策略只获得当前 macOS 文件系统上的限定证据，不是跨平台内核执行封存承诺。准备句柄仅在内存 WeakMap 中，尚无持久安装操作／恢复协议；默认表也是临时 SQL。不能把这份实验模块直接当生产安装器。

## 真实资源与检查

完整本地 Codex 0.167.1 平台目录包含 41 个文件、366515155 字节，含 codex、code-mode-host、rg 以及 voice 辅助资源／声明。本批按清单流式准备并发布到新的内容目录，读块最多 262144 字节；从发布后的路径运行 `--version` 得到 codex-cli 0.167.1。收尾审计重新读取全部 41 个文件核对摘要和权限。

这证明大资源不必通过旧 RuntimeBundle 的单个大 Buffer 交付；不证明整个进程 RSS 上限、UI 响应耗时或安装服务性能达标。来源是既有隔离依赖缓存，不是联网下载／上游压缩包解包，也没有启动 app-server 或模型任务。

| 项 | 最终主批 attempt-SGYR4d 的 S01–S12 |
| --- | --- |
| S01 | 清单非法路径／同名拒绝；平台不匹配在准备前拒绝 |
| S02 | 上述真实完整目录流式复制／摘要验证／发布／激活，读块有界 |
| S03 | 发布路径上的实际 native 版本检查成功并退出 |
| S04 | 小型 A／B 资源独立目录，默认修订 1→2→3；切换到 B 再明确回退 A，原 A 固定引用路径与字节保持 |
| S05 | 过期激活修订不能覆盖新默认值 |
| S06 | 内容摘要不符拒绝，默认值不变 |
| S07 | 第一块之后取消大文件准备，本次私有临时目录移除 |
| S08 | 流式阶段注入 ENOSPC，私有目录移除，原默认不变；没有实际耗尽磁盘 |
| S09 | 散列后以同大小、同权限文件替换原文件，最终身份校验拒绝发布就绪 |
| S10 | 离线源缓存缺失明确失败，不改选别的程序 |
| S11 | 序列化／复制句柄不能冒充实际已校验准备 |
| S12 | 重装同内容重新校验既有目录并复用，不覆盖原文件 |

S04 的 pin 是持久资源 ID 的读取，不是实际 run 租约；不得称为已经验证运行中升级或 GC 安全。正式接入仍须走前述 delivery→run 租约成员及资源清理合同。

## 负对照与针对性补验

attempt-2HWzph 的 S09 原先直接写 mode 0500 文件，收到 EACCES，故未触发预期故障；这是驱动错误。改为在本轮私有目录创建同大小／同权限文件并 rename 替换后，故障生效且被校验拒绝。

attempt-JLwD9X 的 S12 是有效候选缺口：新 stage 与现有 ready 目录内容相同，但 inode／时间不同；直接用新 stage 的身份校验原目录导致误拒绝。修正为在协调区外重新流式验证已有目标的清单／大小／摘要／模式及读取前后身份，然后固定这次观察到的目标身份，交由实际发布入口最终复核。已有目录不被覆盖，完成后删除本次未使用的私有 stage。

补充 cache-gZ7ily 的 C01–C03：已有文件内容被替换则 TARGET_HASH_CHANGED；目标散列成功后、实际 publish 前再替换文件则 FILE_IDENTITY_CHANGED；恢复正确内容后重新校验成功，目标 inode 保持，不靠跳过校验解决重装问题。

三轮实际 Codex --version 均有捕获 PID 的 code 0 退出；缓存补验没有新原生进程。所有轮次、失败与修正留存。故障后的未知／recovery-required 发布记录仍保留，未伪造 ready；部分未消费准备仍只在临时目录中，跨宿主垃圾回收不在本批证明范围。

## 设计含义与剩余问题

同内容可有不同物理身份：内容摘要决定版本，当前文件身份用于防止校验后被替换，不能混用。新准备与已有 ready 复用需要不同的身份来源；已有目标仍须验证其内容，不应为了幂等就信任 ready 行。

下载／校验完成、资源 ready、默认版本激活、某次任务固定选择、真实运行租用属于不同状态。激活采用明确预期修订，晚到的操作不能覆盖更新后的选择；已接受任务沿其固定资源，不因默认更新换版。默认回退不等于旧任务历史格式一定兼容，仍按 SDK／native／协议／业务适配组合验证。

未覆盖：公网请求、代理／重定向、上游包解压限制、完整安装与激活崩溃事务、跨进程竞争、实际 run 租约与 GC、清理所有遗留准备、真实磁盘耗尽、Claude native 包、Windows／Linux 与 Electron 安装签名。产物没有作为发行包分发。当前流式输入采用本机文件路径，后续网络／解包适配不得绕过相同清单与发布核验。

## 证据

[主批结果](result.json)、[缓存故障结果](cache-result.json)、[重装负对照](baseline-negative.json)、[驱动修正](driver-correction.json)、[完整文件清单](native-manifest.json)、[运行审计](runtime-audit.json)、[源码依据](source-review.json)、[归档哈希](archive-manifest.json)、[全部驱动／数据库](raw-evidence.tar.gz)。归档 {len(files)} 文件、{len(dbs)} 份 SQLite 完整性／外键通过，{len(build['sources'])} 个构建输入校验。原生大文件保留在隔离依赖／发布目录，文档归档只存清单和哈希，不重复纳入几百 MiB 程序。

复跑需在新临时目录恢复匹配依赖与源码、调整绝对路径，执行 build.mjs、probe.mjs、cache-probe.mjs、evidence-audit.py；需要足够空间存放临时程序副本。只操作实验创建的资源根；不得将替换、缺失或磁盘故障注入应用到用户安装目录。
''')
def tech(t):
 old='此流式接入与性能方案尚待验证。'
 # The preceding paragraph uses a longer closing sentence in the current text.
 old='此流式接入与性能方案尚待验证。' if old in t else '此流式接入与性能方案尚待验证。'
 anchor='不可直接返回 Promise 给现有同步回调，也不可仅凭旧 hash 跳过目标核验。此流式接入与性能方案尚待验证。'
 assert anchor in t
 new='不可直接返回 Promise 给现有同步回调，也不可仅凭旧 hash 跳过目标核验。'
 t=t.replace(anchor,new)
 oldpara='当前已证实旧桥合同不可直接复用、通用发布可保留独立类型、同宿主并发归并、注入磁盘失败保持旧内容、发布晚变更被拒绝。未证明跨进程安装、真实磁盘耗尽、默认激活、在用升级／回退、下载中断或目标平台安装。SmartDD Office 的构建期锁定缓存与 T3 的运行时受管下载仅提供不同层的参考；正式分发选择应在这些验证后定稿，不以本批小文件结果宣布安装生命周期完成。'
 newpara='''[流式准备实验](实验/20261114_原生资源流式准备与激活验证/README.md)补了完整本地 Codex 平台目录（41 文件、366515155 字节）：异步流式摘要和复制、校验后文件身份固定、同步 rename／短身份复核、真实 --version。读块上限 256 KiB 只证明分块处理，不是 RSS／UI 性能指标。清单拒绝非法路径／平台，取消和注入 ENOSPC 清理本次尚未发布的私有 stage；内容损坏和校验后替换被拒绝。

重装同内容不能拿新 stage 的 inode 校验既有目标。已复现该误拒绝；修正为重新验证 ready 目标的内容、大小、模式和读取前后身份，再固定当前目标身份并在实际发布入口复核，原目录不覆盖。补验已覆盖既有内容损坏及目标 hash 完成后被替换，不能为了复用信任 ready 标记或跳过校验。首次发布与原目录复用的物理身份来源不同，内容身份仍一致。

默认激活候选用预期修订原子更新，过期操作拒绝；小型 A→B→A 的显式激活／回退保持原 A 资源路径和字节。固定资源查询不是 run 租约，不据此宣称在用升级／GC 通过。现候选准备句柄仅存于进程内、激活表亦是实验 Schema；安装操作持久化、崩溃恢复、遗留准备清理及与正式租约的联合仍须补验。

当前还未证明网络下载／解包、跨进程安装、真实磁盘耗尽、运行中升级／GC、历史格式兼容或目标平台安装。最终身份校验策略仅取得本机 macOS 文件系统证据，不等同跨平台内核执行封存。SmartDD 构建期缓存与 T3 运行时下载提供不同层的参考；正式分发选择在这些验证后定稿，不能以局部流式成功宣布安装生命周期完成。'''
 assert oldpara in t;t=t.replace(oldpara,newpara);return t
edit(base/'技研/技术方案.md',tech)
ledger='''### 4.50 原生资源流式准备与默认激活

[流式实验](实验/20261114_原生资源流式准备与激活验证/README.md)在实际 ResourceStore 之外接隔离候选：完整本地 Codex 包 41 文件／366515155 字节流式准备、固定文件身份后同步发布，真实 --version 成功。S01–S12 覆盖清单／平台、默认激活修订、显式回退、损坏、取消、注入 ENOSPC、晚替换、离线源缺失及句柄归属。三次捕获原生进程均退出；不是模型或业务运行。

保留 S09 写只读文件导致 EACCES 的无效故障注入，改为私有目录内同尺寸／权限 rename 替换；另复现 S12 同内容重装误用 stage inode 校验现有目录的有效缺口。修正后主批通过，额外 C01–C03 验证现有内容损坏、hash 后替换与恢复后不覆盖复用。流式块有界不等于完整内存／UI 性能；固定资源查询不等于实际 run 租约，网络解包／安装崩溃／遗留准备清理／跨平台仍未覆盖。T0.1 §12.1 已同步，相关 Q 保持部分。

'''
def account(t):
 assert '### 4.50 'not in t;t=t.replace('## 5. 失败与驱动修正',ledger+'## 5. 失败与驱动修正')
 for q in ['Q01','Q03','Q46','Q48','Q51','Q52','Q53','Q54']:
  lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('| '+q+' |'));lines[i]=lines[i][:-2]+'；§4.50 补本地完整 native 包流式准备、原目录复用与默认激活，未接网络解包／真实 run 租约／崩溃恢复 |';t='\n'.join(lines)+'\n'
 t=t.replace('新的流式原生资源准备与激活仍待联合。','§4.50 又补本地完整原生目录流式准备／版本检查、默认激活及缓存故障；网络解包、跨进程恢复、真实 run 租约和遗留准备清理仍待联合。')
 return t
edit(base/'技研/全局设计验证账.md',account)
def entry(t):
 lines=t.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('最新进展：'));lines[i]='最新进展：完整本地 Codex 包的流式准备／发布／版本检查、默认激活与原目录复用已取得隔离证据；重装误用物理身份的缺口已修正，见[技术方案 §12.1](技研/技术方案.md)。这不等于联网安装、真实运行租约或崩溃恢复已经完成。';i=next(i for i,l in enumerate(lines)if l.startswith('下一步：'));lines[i]='下一步：按[验证账 §7 的 D01–D08 矩阵](技研/全局设计验证账.md#7-剩余工作与关闭标准)继续补网络包准备与安装操作持久恢复、真实租约联合、完整协议及跨宿主输入／结果对账；业务、平台、性能和界面状态设计仍保留。当前只完善设计并做临时目录中的独立验证，不修改产品或共享原型；可操作原型、视觉评审及候选包验收留待后续阶段。';return '\n'.join(lines)+'\n'
edit(base/'README.md',entry)
(root/'manifest.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2));print(json.dumps({'staged':len(entries),'archiveFiles':len(files),'sqlite':len(dbs)}))
