import {connectionConfigSchema,type ConnectionConfig} from '@shared/application-connections';
// Retained v1 converters keep their schema and function identity. New providers
// declare converters in their module or use the registry's identity converter.
const auth=(source:unknown)=>{const config=source as ConnectionConfig;return config.kind==='foxmail'?'local-readonly':config.authMode;};
export const retainedConfigViewDefinitions=['zentao','foxmail','smtp'].map(providerId=>({providerId,sourceSchemaVersion:1,targetApiMajor:1,identityContractMajor:1,implementationVersion:'1',sourceSchema:connectionConfigSchema,targetSchema:connectionConfigSchema,outputAuthentication:auth,authModes:providerId==='foxmail'?['local-readonly']:providerId==='smtp'?['password']:['token','password'],authentication:auth,convert:(source:unknown)=>source}));
