import { randomUUID } from 'node:crypto';
import { subscribe, type AsyncSubscription, type SubscribeCallback } from '@parcel/watcher';
import { FileError, type FileEntry, type FileWatchUpdate } from '@shared/files';
import { FileRootsService, identityKey, type RootLease } from './roots';
import type { NativeFileBroker } from './native-broker';
import type { FileRecoveryStore } from './recovery-store';

type Subscribe = (path: string, callback: SubscribeCallback) => Promise<AsyncSubscription>;
interface Consumer {
  id: string; owner: string; lease: RootLease; directories: string[]; files: string[];
  emit: (update: FileWatchUpdate) => void; previous: string | null; sequence: number; version: number; dispose: () => void;
}
interface SharedWatch {
  key: string; path: string; consumers: Map<string, Consumer>; coverage: FileWatchUpdate['coverage'];
  message?: string; native: AsyncSubscription | null; pending: Promise<void> | null;
  timer: ReturnType<typeof setTimeout> | null; running: boolean; again: boolean; closed: boolean;
  interval: number; retryAt: number; hints: number; abort: AbortController; due: number;
}

/** Native events are invalidation hints only. Every visible result is derived
 * from a fresh broker snapshot, including fallback polling and atomic swaps. */
export class FileWatchService {
  private readonly shared = new Map<string, SharedWatch>();
  private readonly consumers = new Map<string, { watch: SharedWatch; consumer: Consumer }>();
  private readonly stops = new Set<Promise<void>>();
  private readonly starts = new Set<Promise<void>>();
  private readonly scans = new Set<Promise<void>>();
  constructor(private readonly roots: FileRootsService, private readonly broker: NativeFileBroker, private readonly recovery: FileRecoveryStore,
    private readonly nativeSubscribe: Subscribe = (path, callback) => subscribe(path, callback, process.platform === 'darwin' ? { backend: 'fs-events' } : {})) {}

  get resourceCounts() { return { roots: this.shared.size, consumers: this.consumers.size, timers: [...this.shared.values()].filter((item) => item.timer).length, stopping: this.stops.size }; }
  start(owner: string, lease: RootLease, directories: string[], files: string[], emit: Consumer['emit']): FileWatchUpdate {
    const key = `${lease.canonicalPath}:${identityKey(lease.identity)}`;
    let watch = this.shared.get(key);
    if (!watch) { watch = { key, path: lease.canonicalPath, consumers: new Map(), coverage: 'none', native: null, pending: null, timer: null, running: false, again: false, closed: false, interval: 1000, retryAt: 0, hints: 0, abort: new AbortController(), due: 0 }; this.shared.set(key, watch); }
    const id = randomUUID(), consumer: Consumer = { id, owner, lease, directories, files, emit, previous: null, sequence: 0, version: 0, dispose: () => this.stop(owner, id) };
    this.consumers.set(id, { watch, consumer }); watch.consumers.set(id, consumer);
    consumer.dispose = () => { consumer.emit({ ...this.update(watch!, consumer, false, true), coverage: 'none', message: '目录来源已失效，监听已停止；已有编辑仍保留' }); this.stop(owner, id); };
    lease.abort.signal.addEventListener('abort', consumer.dispose, { once: true });
    this.connect(watch); this.schedule(watch, 0);
    return this.update(watch, consumer, false, true);
  }
  configure(owner: string, id: string, lease: RootLease, directories: string[], files: string[]): void {
    const { watch, consumer } = this.require(owner, id);
    if (consumer.lease !== lease) throw new FileError('UNTRUSTED', '监听引用不属于此目录来源');
    consumer.version++; consumer.directories = directories; consumer.files = files; consumer.previous = null; this.schedule(watch, 0);
    consumer.emit(this.update(watch, consumer, false, true));
  }
  stop(owner: string, id: string): void {
    const item = this.consumers.get(id); if (!item || item.consumer.owner !== owner) return;
    const { watch, consumer } = item;
    consumer.lease.abort.signal.removeEventListener('abort', consumer.dispose); this.consumers.delete(id); watch.consumers.delete(id);
    if (watch.consumers.size) return;
    watch.closed = true; watch.abort.abort(); if (watch.timer) clearTimeout(watch.timer); watch.timer = null; this.shared.delete(watch.key);
    if (watch.native) { this.unsubscribe(watch.native); watch.native = null; }
  }
  private require(owner: string, id: string) {
    const item = this.consumers.get(id); if (!item || item.consumer.owner !== owner) throw new FileError('UNTRUSTED', '监听引用已失效或不属于当前窗口');
    this.roots.require(owner, item.consumer.lease); return item;
  }
  private unsubscribe(native: AsyncSubscription): void {
    const work = native.unsubscribe().catch((error) => { console.error('[files:watch] unsubscribe failed', error); }).finally(() => this.stops.delete(work));
    this.stops.add(work);
  }
  private update(watch: SharedWatch, consumer: Consumer, changed: boolean, resyncRequired: boolean): FileWatchUpdate {
    return { id: consumer.id, lease: consumer.lease.lease, generation: consumer.lease.generation, sequence: ++consumer.sequence, coverage: watch.coverage, resyncRequired, changed, message: watch.message };
  }
  private publish(watch: SharedWatch, changed = false, resync = true): void {
    if (watch.closed) return;
    for (const consumer of watch.consumers.values()) consumer.emit(this.update(watch, consumer, changed, resync));
  }
  private connect(watch: SharedWatch): void {
    if (watch.closed || watch.pending || watch.native || Date.now() < watch.retryAt) return;
    watch.pending = this.nativeSubscribe(watch.path, (error, events) => {
      if (watch.closed) return;
      if (error) { this.fallback(watch, error.message); return; }
      watch.hints += events.length;
      if (watch.hints > 2000) { watch.message = '目录事件较多，正在重新核对已展开目录与打开文件'; this.publish(watch); }
      this.schedule(watch, 100);
    }).then((native) => {
      if (watch.closed) { this.unsubscribe(native); return; }
      watch.native = native; watch.coverage = 'native'; watch.message = undefined; watch.interval = 1000;
      this.publish(watch); this.schedule(watch, 0);
    }).catch((error) => this.fallback(watch, error instanceof Error ? error.message : String(error))).finally(() => { if (watch.pending) this.starts.delete(watch.pending); watch.pending = null; });
    this.starts.add(watch.pending);
  }
  private fallback(watch: SharedWatch, message: string): void {
    if (watch.closed) return;
    if (watch.native) { this.unsubscribe(watch.native); watch.native = null; }
    watch.coverage = 'poll'; watch.message = `原生监听不可用，正在补扫已展开目录和打开文件：${message}`;
    watch.retryAt = Date.now() + 30_000; watch.interval = 1000;
    this.publish(watch); this.schedule(watch, 0);
  }
  private schedule(watch: SharedWatch, delay: number): void {
    if (watch.closed) return;
    if (watch.running) { watch.again = true; return; }
    const due = Date.now() + delay;
    if (watch.timer && watch.due <= due) return;
    if (watch.timer) clearTimeout(watch.timer);
    watch.due = due;
    watch.timer = setTimeout(() => { watch.timer = null; const work = this.scan(watch).finally(() => this.scans.delete(work)); this.scans.add(work); }, delay);
  }
  private async scan(watch: SharedWatch): Promise<void> {
    if (watch.closed || watch.running) return;
    watch.running = true; watch.again = false; watch.hints = 0;
    const snapshots = new Map<string, Promise<string>>(); let anyChange = false;
    try {
      for (const consumer of [...watch.consumers.values()]) {
        if (watch.closed || !watch.consumers.has(consumer.id)) continue;
        try {
          this.roots.require(consumer.owner, consumer.lease);
          const version = consumer.version;
          const values = await Promise.all([
            ...consumer.directories.map((path) => this.snapshot(consumer.lease, 'list', path, snapshots, watch.abort.signal)),
            ...consumer.files.map((path) => this.snapshot(consumer.lease, 'metadata', path, snapshots, watch.abort.signal)),
          ]);
          this.roots.require(consumer.owner, consumer.lease);
          if (watch.closed || !watch.consumers.has(consumer.id) || version !== consumer.version) continue;
          const next = JSON.stringify(values), changed = consumer.previous !== null && consumer.previous !== next;
          consumer.previous = next; anyChange ||= changed;
          consumer.emit(this.update(watch, consumer, changed, false));
        } catch (error) {
          if (watch.closed || !watch.consumers.has(consumer.id)) continue;
          consumer.emit({ ...this.update(watch, consumer, false, true), coverage: 'none', message: error instanceof Error ? error.message : String(error) });
        }
      }
    } finally {
      watch.running = false;
      if (!watch.closed) { this.connect(watch); watch.interval = anyChange ? 1000 : Math.min(30_000, watch.interval * 2); this.schedule(watch, watch.again ? 100 : watch.coverage === 'native' ? 5000 : watch.interval); }
    }
  }
  private snapshot(lease: RootLease, operation: 'list' | 'metadata', relativePath: string, cache: Map<string, Promise<string>>, signal: AbortSignal): Promise<string> {
    const key = `${operation}:${relativePath}`;
    const existing = cache.get(key); if (existing) return existing;
    const result = this.broker.request<{ entries?: FileEntry[] }>({ operation, root: lease.descriptor, relativePath, protected: this.recovery.protectedIdentities() }, { signal: AbortSignal.any([lease.abort.signal, signal]) }).then((value) => {
      if (value.entries) value.entries.sort((a, b) => a.name.localeCompare(b.name));
      return JSON.stringify(value);
    }).catch((error) => { if (lease.abort.signal.aborted) throw error; return JSON.stringify({ error: error instanceof Error ? error.message : String(error) }); });
    cache.set(key, result); return result;
  }
  async dispose(): Promise<void> {
    for (const { consumer } of [...this.consumers.values()]) this.stop(consumer.owner, consumer.id);
    await Promise.allSettled([...this.starts]); await Promise.allSettled([...this.scans]); await Promise.allSettled([...this.stops]);
  }
}
