import { describe, expect, it, vi } from 'vitest';
import { FileMediaService } from './media-service';
import { installMediaProtocol, registerViewerAssetScheme } from './viewer-assets';

const native = vi.hoisted(() => ({ before: vi.fn(), handle: vi.fn(), register: vi.fn() }));
vi.mock('electron', () => ({ protocol: { handle: native.handle, registerSchemesAsPrivileged: native.register }, session: { defaultSession: { webRequest: { onBeforeRequest: native.before } } } }));
describe('media session gate', () => {
  it('registers streaming without fetch/CSP bypass and rejects child or foreign frames before protocol IO', () => {
    registerViewerAssetScheme();
    expect(native.register.mock.calls[0][0]).toContainEqual({ scheme: 'willyou-media', privileges: { standard: true, secure: true, stream: true } });
    const service = new FileMediaService(() => { throw new Error('unused'); }), allowed = vi.spyOn(service, 'allows').mockImplementation((owner) => owner === '1:2:3');
    installMediaProtocol(service);
    const handler = native.before.mock.calls[0][1], frame = { processId: 2, routingId: 3 }, callback = vi.fn();
    const contents = { id: 1, mainFrame: frame };
    handler({ frame, webContents: contents, url: 'willyou-media://local/token' }, callback); expect(callback).toHaveBeenLastCalledWith({ cancel: false });
    handler({ frame: { ...frame, routingId: 4 }, webContents: contents, url: 'willyou-media://local/token' }, callback); expect(callback).toHaveBeenLastCalledWith({ cancel: true });
    handler({ frame, webContents: { id: 9, mainFrame: frame }, url: 'willyou-media://local/token' }, callback); expect(callback).toHaveBeenLastCalledWith({ cancel: true });
    handler({ frame: null, url: 'willyou-media://local/token' }, callback); expect(callback).toHaveBeenLastCalledWith({ cancel: true });
    expect(allowed).toHaveBeenCalledTimes(2);
  });
});
