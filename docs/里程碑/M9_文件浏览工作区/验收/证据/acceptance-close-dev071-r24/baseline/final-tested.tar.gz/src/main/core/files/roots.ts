import { randomUUID } from 'node:crypto';
import { isAbsolute } from 'node:path';
import { FileError, fileScopeSchema, rootRequestSchema, type FileIdentity, type FileRoot, type FileRoots, type FileScope, type RootRequest } from '@shared/files';
import type { NativeFileBroker, RootDescriptor } from './native-broker';
import { isNonLocalFileSource, NONLOCAL_WORKSPACE_MESSAGE } from '@shared/file-source-boundary.mjs';

export interface RootSource {
  kind: 'project-directory' | 'task-cwd';
  id: string;
  path: string;
  label: string;
  projectId: string | null;
}
export interface SourceResolver { sources(scope: FileScope): RootSource[] }
export interface RootLease extends FileRoot {
  owner: string;
  scope: FileScope;
  projectId: string | null;
  sourcePath: string;
  descriptor: RootDescriptor;
  abort: AbortController;
}
export const identityKey = (identity: FileIdentity) => `${identity.device}:${identity.inode}`;
export const scopeKey = (scope: FileScope) => scope.kind === 'task' ? `task:${scope.taskId}` : `project:${scope.projectId}`;
export const isLocalPath = (value: unknown): value is string => typeof value === 'string' && value.length > 0 && value.length <= 32768 && !value.includes('\0') && !value.startsWith('//') && !value.startsWith('\\\\') && !/^[a-z][a-z\d+.-]*:\/\//i.test(value) && isAbsolute(value);

/** Opaque capabilities are bound to a renderer frame and a specific source.
 * Re-reading the source invalidates edited/deleted project paths; task cwd is
 * its launch snapshot and is never substituted with a new project default.
 */
export class FileRootsService {
  private readonly leases = new Map<string, RootLease>();
  private readonly pending = new Map<string, { generation: number; abort: AbortController }>();
  private sequence = 0;
  constructor(private readonly resolver: SourceResolver, private readonly broker: NativeFileBroker) {}

  async open(owner: string, input: FileScope): Promise<FileRoots> {
    if (isNonLocalFileSource(input)) throw new FileError('UNSUPPORTED', NONLOCAL_WORKSPACE_MESSAGE);
    const scope = fileScopeSchema.parse(input), key = `${owner}/${scopeKey(scope)}`;
    this.closeScope(owner, scope);
    const generation = ++this.sequence, abort = new AbortController();
    this.pending.set(key, { generation, abort });
    const roots: FileRoot[] = [], unavailable: FileRoots['unavailable'] = [];
    try {
      const sources = this.resolver.sources(scope);
      for (const source of sources) {
        try {
          if (isNonLocalFileSource(source)) throw new FileError('UNSUPPORTED', NONLOCAL_WORKSPACE_MESSAGE);
          if (!isLocalPath(source.path)) throw new FileError('UNSUPPORTED', '当前文件工作区仅支持已登记的本机绝对路径');
          const descriptor = await this.broker.request<RootDescriptor>({ operation: 'inspect-root', path: source.path }, { signal: abort.signal });
          descriptor.sourcePath = source.path;
          if (abort.signal.aborted || this.pending.get(key)?.generation !== generation) throw new FileError('CANCELLED', '根请求已失效');
          const latest = this.resolver.sources(scope).find((s) => s.kind === source.kind && s.id === source.id);
          if (!latest || latest.path !== source.path || latest.projectId !== source.projectId) throw new FileError('STALE_ROOT', '目录来源已改变，请重新打开文件区');
          const lease: RootLease = { lease: randomUUID(), generation, source: source.kind, sourceId: source.id, label: source.label, path: source.path, canonicalPath: descriptor.path, identity: descriptor.identity, owner, scope, projectId: source.projectId, sourcePath: source.path, descriptor, abort: new AbortController() };
          this.leases.set(lease.lease, lease);
          roots.push(this.publicRoot(lease));
        } catch (error) {
          if (abort.signal.aborted) throw new FileError('CANCELLED', '根请求已取消');
          unavailable.push({ sourceId: source.id, label: source.label, path: source.path, reason: error instanceof Error ? error.message : String(error) });
        }
      }
      if (abort.signal.aborted || this.pending.get(key)?.generation !== generation) throw new FileError('CANCELLED', '根请求已失效');
      return { roots, unavailable };
    } catch (error) {
      for (const root of roots) this.revoke(root.lease);
      throw error;
    } finally { if (this.pending.get(key)?.generation === generation) this.pending.delete(key); }
  }

  require(owner: string, input: RootRequest): RootLease {
    const request = rootRequestSchema.parse({ lease: input.lease, generation: input.generation });
    const lease = this.leases.get(request.lease);
    if (!lease || lease.owner !== owner || lease.generation !== request.generation || lease.abort.signal.aborted) throw new FileError('UNTRUSTED', '文件根授权已失效或不属于当前窗口');
    let source: RootSource | undefined;
    try { source = this.resolver.sources(lease.scope).find((s) => s.id === lease.sourceId && s.kind === lease.source); } catch { /* a removed task/project invalidates the lease */ }
    if (!source || source.path !== lease.sourcePath || source.projectId !== lease.projectId) {
      this.revoke(lease.lease); throw new FileError('STALE_ROOT', '项目目录或任务来源已改变，请重新打开文件区');
    }
    return lease;
  }

  closeScope(owner: string, scope: FileScope): void {
    const key = `${owner}/${scopeKey(scope)}`; this.pending.get(key)?.abort.abort(); this.pending.delete(key);
    for (const lease of this.leases.values()) if (lease.owner === owner && scopeKey(lease.scope) === scopeKey(scope)) this.revoke(lease.lease);
  }
  closeOwner(owner: string): void {
    for (const [key, pending] of this.pending) if (key.startsWith(`${owner}/`)) { pending.abort.abort(); this.pending.delete(key); }
    for (const lease of this.leases.values()) if (lease.owner === owner) this.revoke(lease.lease);
  }
  private revoke(id: string): void { this.leases.get(id)?.abort.abort(); this.leases.delete(id); }
  private publicRoot({ lease, generation, source, sourceId, label, path, canonicalPath, identity }: RootLease): FileRoot {
    return { lease, generation, source, sourceId, label, path, canonicalPath, identity };
  }
}
