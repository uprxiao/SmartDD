# Diagram Y08

```mermaid
flowchart LR
 A["<script>globalThis.__y08Executed=1</script>Script Safe"] --> B[Safe End]
```

Tail 中文🙂
