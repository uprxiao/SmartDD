# Diagram Y08

```mermaid
sequenceDiagram
 participant Alice
 participant Bob
 Alice->>Bob: Sequence Message
```

Tail 中文🙂
