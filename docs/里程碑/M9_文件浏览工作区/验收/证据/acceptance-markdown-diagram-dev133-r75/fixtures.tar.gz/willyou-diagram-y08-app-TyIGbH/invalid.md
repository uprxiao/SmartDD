# Diagram Y08

```mermaid
flowchart LR
 A[Broken -->
```

Tail 中文🙂
