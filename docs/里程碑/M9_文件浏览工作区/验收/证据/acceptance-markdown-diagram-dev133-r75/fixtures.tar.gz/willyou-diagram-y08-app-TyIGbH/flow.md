# Diagram Y08

```mermaid
flowchart LR
 A[Flow Start] --> B[Flow End]
```

Tail 中文🙂
