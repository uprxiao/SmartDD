# Diagram Y08

```mermaid
flowchart LR
 A[Safe Label] --> B[Safe End]
 click A "https://example.invalid/y08" "No navigation"
```

Tail 中文🙂
