# Diagram Y08

```mermaid
classDiagram
 class Animal {
 +String species
 +move() void
 }
 class Duck
 Animal <|-- Duck
```

Tail 中文🙂
