# B lookalike must not open
