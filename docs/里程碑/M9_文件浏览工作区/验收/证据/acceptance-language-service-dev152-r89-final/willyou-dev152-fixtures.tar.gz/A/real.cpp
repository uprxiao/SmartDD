struct Base { virtual int value() = 0; };
struct Child : Base { int value() override { return 7; } };
int main() { const char* s="中文🙂"; Child c; Base* b=&c; return b->value(); }
