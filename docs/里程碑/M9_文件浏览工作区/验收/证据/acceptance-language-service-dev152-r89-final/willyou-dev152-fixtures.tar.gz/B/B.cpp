int other_root = 13;
