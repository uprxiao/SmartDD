import type { FileEntry, FileRoot, FileRoots, FileScope, FileWatchUpdate, FileSearchRow } from '@shared/files';
import { fileScopeKey, fileWorkspaceSchema, workspaceSnapshotSchema, workspaceUpdateSchema, type FileRoute, type SavedFileWorkspace, type WorkspacePersistence, type WorkspaceSnapshot, type WorkspaceUpdate } from '@shared/file-workspace';
import { fileWatchEvent, fileWorkspaceEvent } from '@shared/events';
import { events, rpc } from '@renderer/lib/ipc';
import { FileBuffer, type FileClient } from './file-buffer';

export type { FileRoute } from '@shared/file-workspace';
export { fileScopeKey } from '@shared/file-workspace';
export interface FileTab { id: string; route: FileRoute; buffer: FileBuffer | null; pinned: boolean; error: string; loading: boolean }
export type DirectoryState = { state: 'loading' } | { state: 'ready'; entries: FileEntry[] } | { state: 'error'; message: string };
const sourceKey = (root: Pick<FileRoot, 'source' | 'sourceId' | 'path'>) => `${root.source}:${root.sourceId}:${root.path}`;
const routeKey = (route: FileRoute) => `${route.source}:${route.sourceId}:${route.sourcePath}/${route.relativePath}`;
const errorMessage = (error: unknown) => error instanceof Error ? error.message : String(error);
// RPC namespaces are proxies created on property access; retain one identity for
// the production default rather than comparing separate rpc.files proxies.
const defaultFileApi = rpc.files;

/** Session state outlives React panels, just as task PTYs outlive their views.
 * Only stable routes/layout are serialized. No leases, bytes, EditorState or
 * resource URLs are persisted. Browser storage is a legacy migration source;
 * production writes are acknowledged by the main process database. */
export class FileWorkspaceStore {
  roots: FileRoots = { roots: [], unavailable: [] };
  treeRoot: FileRoot | null = null;
  loading = false;
  error = '';
  persistenceError = '';
  tabs: FileTab[] = [];
  activeId: string | null = null;
  expanded: Record<string, string[]> = {};
  collapsedRoots: string[] = [];
  filters: Record<string, string> = {};
  directories = new Map<string, DirectoryState>();
  treeWidth = 250;
  readonly scroll = new Map<string, number>();
  readonly watchStates = new Map<string, FileWatchUpdate>();
  readonly metadataRevisions = new Map<string, number>();
  private readonly watches = new Map<string, { signature: string; id: string | null; token: number }>();
  private views = 0;
  private watchToken = 0;
  private unlistenWatch: (() => void) | null = null;
  private readonly listeners = new Set<() => void>();
  private readonly closed: FileRoute[] = [];
  private readonly pendingDirectories = new Map<string, Promise<void>>();
  private revision = 0;
  private initialized = false;
  private disposed = false;
  private epoch = 0;
  private intent = 0;
  private modeIntent = 0;
  private readonly storageKey: string;
  private persistenceQueue: Promise<void> = Promise.resolve();
  private queuedState: string | null = null;
  private committedState: string | null = null;
  private workspaceRevision = 0;
  private workspaceWrites = 0;
  private applyingWorkspace = false;
  private unlistenWorkspace: (() => void) | null = null;
  private pendingWorkspace: WorkspaceSnapshot | null = null;
  private conflictingWorkspace: WorkspaceSnapshot | null = null;
  private readonly workspaceMutations = new Set<string>();
  constructor(readonly scope: FileScope, private readonly api: FileClient = defaultFileApi, private readonly storage: Pick<Storage, 'getItem' | 'setItem'> | null = typeof localStorage === 'undefined' ? null : localStorage,
    private readonly persistence: WorkspacePersistence | null = api === defaultFileApi ? {
      load: (scope) => api.workspace(scope), snapshot: (scope) => api.workspaceSnapshot(scope),
      commit: (scope, state, revision, mutationId) => api.saveWorkspace(scope, state, revision, mutationId),
      subscribe: (listener) => events.on(fileWorkspaceEvent, listener),
    } : null) {
    this.storageKey = `willyou-files-v1:${fileScopeKey(scope)}`;
  }
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => this.listeners.delete(listener); };
  snapshot = () => this.revision;
  get active(): FileTab | null { return this.tabs.find((tab) => tab.id === this.activeId) ?? null; }
  get currentExpanded(): string[] { return this.treeRoot ? this.expanded[sourceKey(this.treeRoot)] ?? [] : []; }
  get rootExpanded(): boolean { return !this.treeRoot || !this.collapsedRoots.includes(sourceKey(this.treeRoot)); }
  toggleRoot(): void { if (!this.treeRoot) return; const key = sourceKey(this.treeRoot); this.collapsedRoots = this.rootExpanded ? [...this.collapsedRoots, key].slice(-200) : this.collapsedRoots.filter((item) => item !== key); this.changed(); }
  get activeRoot(): FileRoot | undefined { return this.active ? this.rootFor(this.active.route) : undefined; }
  get canRestoreClosed(): boolean { return this.closed.length > 0; }
  get filter(): string { return this.treeRoot ? this.filters[sourceKey(this.treeRoot)] ?? '' : ''; }
  setFilter(value: string): void { if (!this.treeRoot) return; this.filters[sourceKey(this.treeRoot)] = value.slice(0, 256); this.changed(); }
  attach(): () => void {
    this.views++;
    if (!this.unlistenWatch) this.unlistenWatch = events.on(fileWatchEvent, (update) => this.receiveWatch(update));
    this.syncWatches();
    return () => {
      this.views--;
      if (this.views > 0) return;
      this.unlistenWatch?.(); this.unlistenWatch = null; this.watchToken++;
      for (const watch of this.watches.values()) if (watch.id) void this.api.stopWatch(watch.id).catch(() => undefined);
      this.watches.clear(); this.watchStates.clear();
    };
  }
  private receiveWatch(update: FileWatchUpdate): void {
    const watch = this.watches.get(update.lease), previous = this.watchStates.get(update.lease);
    if (!this.views || watch?.id !== update.id || previous && update.sequence <= previous.sequence) return;
    this.watchStates.set(update.lease, update); this.changed();
    if (update.changed || update.resyncRequired) {
      const root = this.roots.roots.find((item) => item.lease === update.lease && item.generation === update.generation);
      if (root) void this.refreshRoot(root);
    }
  }
  private syncWatches(): void {
    if (!this.views || this.disposed) return;
    for (const root of this.roots.roots) {
      const directories = this.treeRoot === root ? ['', ...(this.expanded[sourceKey(root)] ?? [])] : [];
      const refs = this.tabs.flatMap((tab) => tab.buffer?.file.ref.lease === root.lease ? [tab.buffer.file.ref] : []);
      const signature = JSON.stringify({ directories, refs }), current = this.watches.get(root.lease);
      if (!directories.length && !refs.length) { if (current?.id) void this.api.stopWatch(current.id).catch(() => undefined); this.watches.delete(root.lease); this.watchStates.delete(root.lease); continue; }
      if (current?.signature === signature) continue;
      // Pending subscriptions reconcile their latest membership after start.
      if (current && !current.id) continue;
      const watch = { signature, id: current?.id ?? null, token: ++this.watchToken };
      this.watches.set(root.lease, watch);
      void this.api.watch(root, directories, refs, watch.id ?? undefined).then((update) => {
        if (this.disposed || !this.views || this.watches.get(root.lease) !== watch) { if (update) void this.api.stopWatch(update.id).catch(() => undefined); return; }
        if (update) { watch.id = update.id; this.receiveWatch(update); }
        this.syncWatches();
      }).catch((error) => {
        if (!this.disposed && this.views && this.watches.get(root.lease) === watch) {
          this.watchStates.set(root.lease, { id: watch.id ?? '', lease: root.lease, generation: root.generation, sequence: 0, coverage: 'none', resyncRequired: true, changed: false, message: errorMessage(error) });
          this.revision++; for (const listener of this.listeners) listener();
        }
      });
    }
  }
  private changed = () => {
    if (this.disposed) return;
    for (const tab of this.tabs) if (tab.buffer?.dirty) tab.pinned = true;
    this.revision++; void this.persist().catch(() => undefined); this.syncWatches(); for (const listener of this.listeners) listener();
  };
  private async saved(): Promise<SavedFileWorkspace | null> {
    let persisted: SavedFileWorkspace | null | undefined;
    if (this.persistence?.snapshot) {
      const snapshot = workspaceSnapshotSchema.parse(await this.persistence.snapshot(this.scope));
      this.workspaceRevision = snapshot.revision; persisted = snapshot.state;
    } else persisted = await this.persistence?.load(this.scope);
    if (persisted) return fileWorkspaceSchema.parse(persisted);
    // Never use a stale browser copy after a main-process read error.
    try { return fileWorkspaceSchema.parse(JSON.parse(this.storage?.getItem(this.storageKey) ?? 'null')); } catch { return null; }
  }
  private workspaceState(): SavedFileWorkspace {
    return { schemaVersion: 1, routes: this.tabs.filter((tab) => tab.pinned).map((tab) => ({ ...tab.route, mode: tab.buffer?.mode ?? tab.route.mode })), active: this.active ? { ...this.active.route, mode: this.active.buffer?.mode ?? this.active.route.mode } : null, treeSource: this.treeRoot ? sourceKey(this.treeRoot) : null, expanded: this.expanded, collapsedRoots: this.collapsedRoots, filters: this.filters, treeWidth: this.treeWidth };
  }
  get persistenceConflict(): boolean { return this.conflictingWorkspace !== null; }
  get hasProtectedBuffers(): boolean { return this.tabs.some(tab => tab.buffer && (tab.buffer.dirty || tab.buffer.saving || tab.buffer.recoveryBlocked || tab.buffer.draftOptions.length > 0)); }
  private workspaceConflict(snapshot: WorkspaceSnapshot): void {
    if (!this.conflictingWorkspace || snapshot.revision > this.conflictingWorkspace.revision) this.conflictingWorkspace = snapshot;
    this.persistenceError = '另一窗口更新了标签；当前标签、选择与草稿已保留。保存当前窗口标签会采用此窗口的布局。';
    this.revision++; for (const listener of this.listeners) listener();
  }
  private receiveWorkspace = (input: WorkspaceUpdate): void => {
    const parsed = workspaceUpdateSchema.safeParse(input); if (!parsed.success || this.disposed) return;
    const update = parsed.data;
    if (fileScopeKey(update.scope) !== fileScopeKey(this.scope) || update.revision <= this.workspaceRevision) return;
    if (this.workspaceMutations.has(update.mutationId)) { this.workspaceRevision = update.revision; return; }
    if (!this.pendingWorkspace || update.revision > this.pendingWorkspace.revision) this.pendingWorkspace = update;
    this.drainWorkspace();
  };
  private drainWorkspace(): void {
    if (this.disposed || !this.initialized || this.loading || this.workspaceWrites || this.applyingWorkspace) return;
    const snapshot = this.pendingWorkspace; if (!snapshot) return;
    this.pendingWorkspace = null;
    if (snapshot.revision <= this.workspaceRevision) return;
    const current = JSON.stringify(this.workspaceState());
    const removesSelection = this.intent > 0 && this.active?.pinned && !snapshot.state?.routes.some(route => routeKey(route) === routeKey(this.active!.route));
    if (this.conflictingWorkspace || this.hasProtectedBuffers || this.committedState !== current || removesSelection) { this.workspaceConflict(snapshot); return; }
    this.applyWorkspace(snapshot);
  }
  private applyWorkspace(snapshot: WorkspaceSnapshot): void {
    const saved = snapshot.state;
    this.applyingWorkspace = true;
    const previous = this.tabs, active = this.active, added: FileTab[] = [], sourceLoads: FileBuffer[] = [];
    const seen = new Set<string>();
    const routes = (saved?.routes ?? []).filter(route => { const key = routeKey(route); if (seen.has(key)) return false; seen.add(key); return true; });
    this.tabs = routes.map(route => {
      const existing = previous.find(tab => routeKey(tab.route) === routeKey(route));
      if (existing) {
        existing.pinned = true; existing.route = route;
        if (existing.buffer) {
          existing.buffer.mode = route.mode;
          if (route.mode === 'source' && !existing.buffer.editor && existing.buffer.content.mime === 'image/svg+xml') sourceLoads.push(existing.buffer);
        }
        return existing;
      }
      const tab: FileTab = { id: crypto.randomUUID(), route, buffer: null, pinned: true, error: '', loading: true }; added.push(tab); return tab;
    });
    for (const tab of previous) {
      if (this.tabs.includes(tab)) continue;
      if (!tab.pinned) this.tabs.push(tab); else tab.buffer?.dispose();
    }
    this.activeId = active && this.intent > 0 && this.tabs.includes(active) ? active.id : this.tabs.find(tab => saved?.active && routeKey(tab.route) === routeKey(saved.active))?.id ?? this.tabs[0]?.id ?? null;
    this.expanded = saved?.expanded ?? {}; this.collapsedRoots = saved?.collapsedRoots ?? []; this.filters = saved?.filters ?? {}; this.treeWidth = saved?.treeWidth ?? 250;
    this.treeRoot = this.roots.roots.find(root => sourceKey(root) === saved?.treeSource) ?? this.roots.roots[0] ?? null;
    this.workspaceRevision = snapshot.revision; this.conflictingWorkspace = null; this.persistenceError = '';
    // The local active/preview may intentionally differ. Treat this projection
    // as acknowledged, so receiving a remote snapshot never echoes a write.
    this.queuedState = this.committedState = JSON.stringify(this.workspaceState());
    this.applyingWorkspace = false; this.revision++; this.syncWatches(); for (const listener of this.listeners) listener();
    for (const tab of added) void this.loadTab(tab);
    for (const buffer of sourceLoads) void buffer.load();
    if (this.treeRoot) void this.list(this.treeRoot, '');
  }
  async reloadPersistence(): Promise<void> {
    if (!this.persistence?.snapshot || this.disposed) return;
    if (this.hasProtectedBuffers) throw new Error('请先处理当前未保存或恢复中的文件；标签与草稿已保留');
    await this.persistenceQueue.catch(() => undefined);
    const before = JSON.stringify(this.workspaceState()), intent = this.intent;
    const snapshot = workspaceSnapshotSchema.parse(await this.persistence.snapshot(this.scope));
    if (this.disposed) return;
    if (this.hasProtectedBuffers || before !== JSON.stringify(this.workspaceState()) || intent !== this.intent) throw new Error('读取期间当前标签已改变；请重试，当前内容已保留');
    this.pendingWorkspace = null; this.applyWorkspace(snapshot);
  }
  async retryPersistence(): Promise<void> {
    if (!this.persistence?.snapshot || !this.conflictingWorkspace) { await this.flushPersistence(); return; }
    await this.persistenceQueue.catch(() => undefined);
    const snapshot = workspaceSnapshotSchema.parse(await this.persistence.snapshot(this.scope));
    if (this.disposed) return;
    // Explicit user action: adopt only the current revision, then CAS the
    // current window layout. No automatic route merge or buffer replacement.
    this.workspaceRevision = snapshot.revision; this.conflictingWorkspace = null; this.pendingWorkspace = null; this.queuedState = null;
    await this.flushPersistence();
  }
  private persist(): Promise<void> {
    if (!this.initialized || this.disposed || this.applyingWorkspace) return this.persistenceQueue;
    if (this.conflictingWorkspace) return Promise.reject(new Error(this.persistenceError));
    const serialized = JSON.stringify(this.workspaceState());
    if (serialized === this.queuedState) return this.persistenceQueue;
    this.queuedState = serialized;
    this.workspaceWrites++;
    // Capture the serialized snapshot: later filter/expanded changes must not
    // mutate an earlier queued write. Failed writes do not poison later retries.
    const operation = this.persistenceQueue.catch(() => undefined).then(async () => {
      if (this.conflictingWorkspace) throw new Error(this.persistenceError);
      if (this.persistence?.commit) {
        const mutationId = crypto.randomUUID(); this.workspaceMutations.add(mutationId);
        try {
          const result = await this.persistence.commit(this.scope, JSON.parse(serialized), this.workspaceRevision, mutationId);
          const snapshot = workspaceSnapshotSchema.parse({ state: result.state, revision: result.revision });
          if (!result.accepted) { this.workspaceConflict(snapshot); throw new Error(this.persistenceError); }
          this.workspaceRevision = Math.max(this.workspaceRevision, snapshot.revision);
        } finally { this.workspaceMutations.delete(mutationId); }
      } else if (this.persistence?.save) await this.persistence.save(this.scope, JSON.parse(serialized));
      else this.storage?.setItem(this.storageKey, serialized);
      this.committedState = serialized;
    });
    this.persistenceQueue = operation;
    void operation.then(() => {
      if (this.queuedState === serialized) this.persistenceError = '';
      if (!this.disposed) { this.revision++; for (const listener of this.listeners) listener(); }
    }, (error) => {
      if (this.queuedState === serialized) this.queuedState = null;
      if (!this.conflictingWorkspace) this.persistenceError = `标签状态尚未保存：${errorMessage(error)}`;
      if (!this.disposed) { this.revision++; for (const listener of this.listeners) listener(); }
    }).finally(() => { this.workspaceWrites--; this.drainWorkspace(); });
    return operation;
  }
  flushPersistence = async (): Promise<void> => { await this.persist(); };
  async initialize(): Promise<void> {
    if (this.initialized || this.loading) return;
    const own = ++this.epoch, restoreIntent = this.intent;
    this.unlistenWorkspace ??= this.persistence?.subscribe?.(this.receiveWorkspace) ?? null;
    this.loading = true; this.error = ''; this.changed();
    try {
      const saved = await this.saved();
      const roots = await this.api.roots(this.scope);
      if (this.disposed || own !== this.epoch) return;
      this.roots = roots; this.expanded = saved?.expanded ?? {}; this.collapsedRoots = saved?.collapsedRoots ?? []; this.filters = saved?.filters ?? {}; this.treeWidth = saved?.treeWidth ?? 250;
      this.treeRoot = roots.roots.find((root) => sourceKey(root) === saved?.treeSource) ?? roots.roots[0] ?? null;
      this.initialized = true;
      this.tabs = (saved?.routes ?? []).map((route) => ({ id: crypto.randomUUID(), route, buffer: null, pinned: true, error: '', loading: true }));
      this.activeId = this.tabs.find((tab) => saved?.active && routeKey(tab.route) === routeKey(saved.active))?.id ?? this.tabs[0]?.id ?? null;
      this.changed();
      const listing = this.treeRoot ? this.list(this.treeRoot, '') : Promise.resolve();
      const restoring = [...this.tabs];
      for (let offset = 0; offset < restoring.length && !this.disposed && own === this.epoch; offset += 4) await Promise.all(restoring.slice(offset, offset + 4).map((tab) => this.loadTab(tab, own, restoreIntent)));
      await listing;
    } catch (error) { if (!this.disposed && own === this.epoch) this.error = errorMessage(error); }
    finally { if (!this.disposed && own === this.epoch) { this.loading = false; this.changed(); this.drainWorkspace(); } }
  }
  private rootFor(route: FileRoute): FileRoot | undefined {
    // A stable source ID alone is insufficient: a changed project path must
    // produce an unavailable route, not point old tabs into another directory.
    return this.roots.roots.find((root) => root.source === route.source && root.sourceId === route.sourceId && root.path === route.sourcePath);
  }
  private async loadTab(tab: FileTab, own = this.epoch, _restoreIntent?: number): Promise<void> {
    try {
      const root = this.rootFor(tab.route);
      if (!root) throw new Error('原目录来源当前不可用；此标签保留原路径，未切换到新目录');
      const file = await this.api.open({ lease: root.lease, generation: root.generation, relativePath: tab.route.relativePath });
      if (this.disposed || own !== this.epoch || !this.tabs.includes(tab)) { void this.api.closeDocument(file.ref).catch(() => undefined); return; }
      const existing = this.tabs.find((other) => other !== tab && other.buffer?.file.documentKey === file.documentKey);
      if (existing) {
        existing.pinned ||= tab.pinned;
        this.tabs = this.tabs.filter((other) => other !== tab);
        if (this.activeId === tab.id) this.activeId = existing.id;
        void this.api.closeDocument(file.ref).catch(() => undefined); this.changed(); return;
      }
      tab.buffer = new FileBuffer(file, this.api, this.changed, this.flushPersistence); tab.buffer.mode = tab.route.mode;
      tab.loading = false; tab.error = ''; this.changed();
      await tab.buffer.load();
    } catch (error) { if (!this.disposed && own === this.epoch && this.tabs.includes(tab)) { tab.error = errorMessage(error); tab.loading = false; this.changed(); } }
  }
  async open(root: FileRoot, relativePath: string, pin = false): Promise<void> {
    this.intent++;
    const route: FileRoute = { source: root.source, sourceId: root.sourceId, sourcePath: root.path, relativePath, mode: /\.(?:csv|tsv|html?|tex)$/i.test(relativePath) ? 'source' : 'document' };
    const existing = this.tabs.find((tab) => routeKey(tab.route) === routeKey(route));
    if (existing) { existing.pinned ||= pin; this.activeId = existing.id; this.changed(); void existing.buffer?.refresh(); return; }
    const preview = this.tabs.find((tab) => !tab.pinned && !tab.buffer?.dirty);
    if (preview) this.remove(preview, false);
    const tab: FileTab = { id: crypto.randomUUID(), route, buffer: null, pinned: pin, loading: true, error: '' };
    this.tabs.push(tab); this.activeId = tab.id; this.changed();
    await this.loadTab(tab);
  }
  activate(id: string): void {
    this.intent++; const tab = this.tabs.find((item) => item.id === id); if (!tab) return;
    this.activeId = id; this.changed(); void tab.buffer?.refresh();
  }
  async openRelated(buffer: FileBuffer, href: string): Promise<void> {
    const tab = this.tabs.find((entry) => entry.buffer === buffer);
    if (!tab) return;
    const root = this.rootFor(tab.route); if (!root) throw new Error('文档来源已失效');
    const document = await this.api.related(buffer.file.ref, href);
    try { if (this.tabs.includes(tab) && tab.buffer === buffer) await this.open(root, document.relativePath); }
    finally { await this.api.closeDocument(document.ref).catch(() => undefined); }
  }
  async setMode(buffer: FileBuffer, mode: 'document' | 'source'): Promise<void> {
    // Even an explicit request to keep the current mode supersedes an older
    // switch that is still waiting for its save to finish.
    const request = ++this.modeIntent;
    const tab = this.tabs.find((entry) => entry.buffer === buffer);
    if (!tab || this.disposed || buffer.mode === mode) return;
    const intent = this.intent, activeId = this.activeId, previousMode = buffer.mode, version = buffer.version;
    const current = () => !this.disposed && this.modeIntent === request && this.intent === intent
      && this.activeId === activeId && this.tabs.includes(tab) && tab.buffer === buffer
      && buffer.mode === previousMode && buffer.version === version;
    if (buffer.dirty || buffer.saving) {
      let saved: boolean;
      try { saved = await buffer.save(); }
      catch (error) { if (current()) throw error; return; }
      // A started write still completes, but its obsolete success/error must
      // not change the newly selected file, mode or replacement save.
      if (!current() || buffer.saving) return;
      if (!saved) throw new Error(buffer.saveError || '文件尚未保存，保留当前模式');
    }
    if (!current() || buffer.dirty || buffer.saving) return;
    buffer.mode = mode; tab.route.mode = mode; this.changed();
    if (mode === 'source' && !buffer.editor && buffer.content.mime === 'image/svg+xml') await buffer.load();
  }
  async openSearchRow(root: FileRoot, row: FileSearchRow): Promise<void> {
    const work = this.open(root, row.relativePath); const intent = this.intent;
    await work;
    if (this.disposed || this.intent !== intent) return;
    const buffer = this.active?.buffer;
    if (!buffer?.editor) throw new Error('此搜索结果当前无法作为文本定位');
    if (buffer.dirty || buffer.file.revision.hash !== row.revision.hash || buffer.file.revision.device !== row.revision.device || buffer.file.revision.inode !== row.revision.inode) throw new Error('文件在搜索后已改变，已打开当前内容；请重新搜索后定位');
    const range = row.ranges[0]; if (range) buffer.revealSourceRange(row.rawOffset + range.from, row.rawOffset + range.to);
  }
  pin(id: string): void { const tab = this.tabs.find((item) => item.id === id); if (tab) { tab.pinned = true; this.changed(); } }
  reorder(from: string, before: string): void {
    const item = this.tabs.find((tab) => tab.id === from), at = this.tabs.findIndex((tab) => tab.id === before);
    if (!item || at < 0 || from === before) return;
    this.tabs = this.tabs.filter((tab) => tab !== item); this.tabs.splice(this.tabs.findIndex((tab) => tab.id === before), 0, item); this.changed();
  }
  async close(id: string, discard = false): Promise<'closed' | 'blocked' | 'stale'> {
    const tab = this.tabs.find((item) => item.id === id); if (!tab) return 'stale';
    const instance = tab.buffer?.instance;
    if (tab.buffer?.dirty || tab.buffer?.recoveryBlocked) {
      if (discard) { try { await tab.buffer.discardDraft(); } catch (error) { tab.error = errorMessage(error); this.changed(); return 'blocked'; } }
      else if (!await tab.buffer.save()) return 'blocked';
    }
    if (!this.tabs.includes(tab) || tab.buffer?.instance !== instance) return 'stale';
    if (!discard && tab.buffer?.dirty) return 'blocked';
    this.remove(tab, true); this.changed(); return 'closed';
  }
  private remove(tab: FileTab, remember: boolean): void {
    const index = this.tabs.indexOf(tab); if (index < 0) return;
    if (remember) { this.closed.unshift({ ...tab.route }); this.closed.splice(25); }
    this.tabs.splice(index, 1); tab.buffer?.dispose();
    if (this.activeId === tab.id) this.activeId = this.tabs[Math.min(index, this.tabs.length - 1)]?.id ?? null;
  }
  async restoreClosed(): Promise<void> {
    const route = this.closed.shift(); if (!route) return;
    const root = this.rootFor(route);
    if (root) await this.open(root, route.relativePath, true);
    else { const tab = { id: crypto.randomUUID(), route, pinned: true, loading: false, error: '原目录来源当前不可用', buffer: null }; this.tabs.push(tab); this.activeId = tab.id; this.changed(); }
  }
  selectRoot(root: FileRoot): void { this.treeRoot = root; this.changed(); void this.list(root, ''); }
  setTreeWidth(width: number): void { this.treeWidth = Math.max(0, Math.min(1600, width)); this.changed(); }
  toggleDirectory(path: string): void {
    const root = this.treeRoot; if (!root) return;
    const key = sourceKey(root), expanded = this.currentExpanded;
    this.expanded[key] = expanded.includes(path) ? expanded.filter((item) => item !== path) : [...expanded, path];
    this.changed(); if (this.expanded[key].includes(path)) void this.list(root, path);
  }
  directoryKey(root: FileRoot, path: string): string { return `${root.lease}/${path}`; }
  list(root: FileRoot, path: string, refresh = false): Promise<void> {
    const key = this.directoryKey(root, path), pending = this.pendingDirectories.get(key), own = this.epoch;
    if (pending) return pending;
    if (!refresh && this.directories.get(key)?.state === 'ready') return Promise.resolve();
    this.directories.set(key, { state: 'loading' }); this.changed();
    const work = this.api.list({ lease: root.lease, generation: root.generation, relativePath: path }).then((entries) => {
      if (!this.disposed && own === this.epoch) this.directories.set(key, { state: 'ready', entries });
    }).catch((error) => {
      if (!this.disposed && own === this.epoch) this.directories.set(key, { state: 'error', message: errorMessage(error) });
    }).finally(() => { this.pendingDirectories.delete(key); if (!this.disposed && own === this.epoch) this.changed(); });
    this.pendingDirectories.set(key, work); return work;
  }
  async refresh(): Promise<void> {
    const root = this.treeRoot;
    if (root) this.metadataRevisions.set(root.lease, (this.metadataRevisions.get(root.lease) ?? 0) + 1);
    if (root) await Promise.all(['', ...this.currentExpanded].map((path) => this.list(root, path, true)));
    await this.active?.buffer?.refresh();
  }
  private async refreshRoot(root: FileRoot): Promise<void> {
    this.metadataRevisions.set(root.lease, (this.metadataRevisions.get(root.lease) ?? 0) + 1);
    await Promise.all([
      ...(this.treeRoot === root ? ['', ...(this.expanded[sourceKey(root)] ?? [])].map((path) => this.list(root, path, true)) : []),
      ...this.tabs.flatMap((tab) => tab.buffer?.file.ref.lease === root.lease ? [tab.buffer.refresh()] : []),
    ]);
  }
  dispose(): void {
    if (this.disposed) return;
    this.disposed = true; this.epoch++;
    this.unlistenWorkspace?.(); this.unlistenWorkspace = null;
    this.unlistenWatch?.(); this.unlistenWatch = null;
    for (const watch of this.watches.values()) if (watch.id) void this.api.stopWatch(watch.id).catch(() => undefined);
    this.watches.clear(); this.watchStates.clear();
    for (const tab of this.tabs) tab.buffer?.dispose();
    this.listeners.clear(); void this.api.closeScope(this.scope).catch(() => undefined);
  }
}

const workspaces = new Map<string, FileWorkspaceStore>();
export function fileWorkspaceFor(scope: FileScope): FileWorkspaceStore {
  const key = fileScopeKey(scope);
  let store = workspaces.get(key);
  if (!store) { store = new FileWorkspaceStore(scope); workspaces.set(key, store); }
  return store;
}
export function openFileBuffers(): FileBuffer[] { return [...new Set([...workspaces.values()].flatMap((store) => store.tabs.flatMap((tab) => tab.buffer ? [tab.buffer] : [])))]; }
