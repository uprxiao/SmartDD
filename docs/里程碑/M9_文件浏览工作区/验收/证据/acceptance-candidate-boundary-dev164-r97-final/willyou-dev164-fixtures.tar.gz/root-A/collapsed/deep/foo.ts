OWN SOURCE root-A collapsed/deep/foo.ts
