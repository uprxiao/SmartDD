OWN SOURCE root-A foo/Foo.ts
