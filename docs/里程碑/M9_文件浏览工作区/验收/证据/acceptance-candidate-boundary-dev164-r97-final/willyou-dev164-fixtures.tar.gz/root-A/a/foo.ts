OWN SOURCE root-A a/foo.ts
