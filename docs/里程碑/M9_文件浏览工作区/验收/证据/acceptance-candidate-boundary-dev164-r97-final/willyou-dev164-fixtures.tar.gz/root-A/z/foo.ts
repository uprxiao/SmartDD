OWN SOURCE root-A z/foo.ts
