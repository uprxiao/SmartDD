OWN SOURCE root-B z/foo.ts
