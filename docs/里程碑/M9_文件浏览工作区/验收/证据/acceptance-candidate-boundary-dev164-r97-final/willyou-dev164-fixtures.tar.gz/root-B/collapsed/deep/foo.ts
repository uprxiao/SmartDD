OWN SOURCE root-B collapsed/deep/foo.ts
