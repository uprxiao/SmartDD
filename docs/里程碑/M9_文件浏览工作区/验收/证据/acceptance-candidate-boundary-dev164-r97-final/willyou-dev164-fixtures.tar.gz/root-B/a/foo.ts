OWN SOURCE root-B a/foo.ts
