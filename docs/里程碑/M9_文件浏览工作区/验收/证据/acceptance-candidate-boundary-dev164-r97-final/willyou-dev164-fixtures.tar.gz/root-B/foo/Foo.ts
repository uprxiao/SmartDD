OWN SOURCE root-B foo/Foo.ts
