File name alone is not a body hit
