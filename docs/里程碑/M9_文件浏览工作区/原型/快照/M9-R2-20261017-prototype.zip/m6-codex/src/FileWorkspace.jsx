import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { File, FileCode2, FileText, FileSearch, FolderOpen, Folder, ChevronDown, ChevronRight, X, Plus, Search, PanelRight, Maximize2, Minimize2, Code2, Copy, ExternalLink, Check, AlertCircle, RotateCcw, Save, Download, Sun, Moon, Settings2, MoreHorizontal, Undo2, Redo2, WrapText, TextSelect, Image, FileSpreadsheet, FileSliders, Play, Pause, ZoomIn, ZoomOut, ArrowLeft, ArrowRight, Pin } from 'lucide-react';
import { FILES, FILE_BY_PATH, SAMPLE_MD, fileKey, initialWorkspace, openFile, closeFile, restoreFile, treeRows, directoryChildren, treeKeyboardIntent, searchTreeRows, migratePrototypeSaved, openDocument, readRootView, updateRootView } from './file-workspace-model.mjs';
import iconMap from './m9-icon-map.json';
import { FileArtifactPreview } from './FileArtifactPreview';
import { createOfficeDocument, serializeOffice } from './file-office-model.mjs';
import { FileMarkdown } from './FileMarkdown';
import { localFind } from './file-markdown-model.mjs';
import { workspaceScope, searchFiles, serializeWorkspaceStore, documentKey, fileScenario, setFileScenario, editDraft, commitDraft, acceptDisk, captureSelection, applySelectionEdit, artifactModel, updateArtifactCell, updateArtifactSlide } from './file-workspace-model.mjs';
import './file-workspace.css';
const STORAGE = 'willyou-m9-prototype-v1';
const load = () => {
  try {
    const saved=JSON.parse(localStorage.getItem(STORAGE)) || {};
    return {...saved,saved:migratePrototypeSaved(saved.saved)};
  } catch {
    return {};
  }
};
const isText = f => ['code', 'markdown', 'html', 'svg', 'large'].includes(f?.kind);
function Icon({
  file,
  size = 16
}) {
  const path = typeof file === 'string' ? file : file?.path || '';
  const name = path.split('/').pop().toLowerCase();
  const ext = name.split('.').slice(1);
  let type = iconMap.fileNameTokens[name];
  for (let i = 0; !type && i < ext.length; i++) {
    const suffix = ext.slice(i).join('.');
    type = iconMap.completeExtensionOverrides[suffix] || iconMap.extensionTokens[suffix];
  }
  type = type || iconMap.defaultType;
  const colors = iconMap.palette[iconMap.colorRoles[type]];
  return <svg className="fw-file-icon" width={size} height={size} viewBox="0 0 16 16" aria-hidden="true" style={{
    '--file-light': colors?.light || 'currentColor',
    '--file-dark': colors?.dark || 'currentColor'
  }}><use href={iconMap.spriteUrl + '#' + iconMap.idPrefix + type} /></svg>;
}
const Button = ({
  icon: C,
  label,
  onClick,
  active,
  disabled
}) => <button className={'fw-icon ' + (active ? 'active' : '')} title={label} aria-label={label} onClick={onClick} disabled={disabled}><C size={17} strokeWidth={1.65} /></button>;
function ContentSearch({
  onClose,
  onOpen,
  scope,
  files = FILES
}) {
  const historyKey = 'willyou-m9-search-history-v1';
  const loadHistory = () => {
    try {
      const all = JSON.parse(localStorage.getItem(historyKey)) || [];
      return all.find(x => x.scope === scope) || {
        queries: [],
        masks: []
      };
    } catch {
      return {
        queries: [],
        masks: []
      };
    }
  };
  const [query, setQuery] = useState(''),
    [mask, setMask] = useState(''),
    [selected, setSelected] = useState(0),
    [history, setHistory] = useState(loadHistory);
  const [hits, setHits] = useState([]),
    [busy, setBusy] = useState(false),
    [spinner, setSpinner] = useState(false),
    [error, setError] = useState('');
  const input = useRef(null),
    historyIndex = useRef(-1),
    historyDraft = useRef(''), resultsRef = useRef(null);
  useEffect(()=>{resultsRef.current?.querySelector('[aria-selected=true]')?.scrollIntoView({block:'nearest'});},[selected]);
  const remember = (rememberQuery = false) => {
    const next = {
      queries: rememberQuery && query ? [query, ...history.queries.filter(x => x !== query)].slice(0, 30) : history.queries,
      masks: mask.trim() ? [mask.trim(), ...history.masks.filter(x => x !== mask.trim())].slice(0, 20) : history.masks
    };
    setHistory(next);
    try {
      const all = JSON.parse(localStorage.getItem(historyKey)) || [];
      localStorage.setItem(historyKey, JSON.stringify([{
        scope,
        ...next
      }, ...all.filter(x => x.scope !== scope)].slice(0, 20)));
    } catch {
      setError('原型搜索历史未能保存。');
    }
  };
  useEffect(() => {
    if (!query) {
      setHits([]);
      setBusy(false);
      setSpinner(false);
      return;
    }
    setBusy(true);
    setError('');
    let valid = true;
    const spin = setTimeout(() => {
      if (valid) setSpinner(true);
    }, 500);
    const work = setTimeout(() => {
      try {
        const m = mask.trim(),
          negate = m.startsWith('!'),
          raw = negate ? m.slice(1) : m;
        const escaped = raw.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\?/g, '.').replace(/\u0000/g, '.*');
        const pattern = raw ? new RegExp('(?:^|/)' + escaped + '$', 'i') : null;
        const results = files.filter(f => !pattern || (negate ? !pattern.test(f.path) : pattern.test(f.path))).flatMap(f => f.text.split('\n').map((line, i) => ({
          path: f.path,
          line,
          number: i + 1,
          column: line.toLowerCase().indexOf(query.toLowerCase()) + 1
        })).filter(r => r.column > 0)).slice(0, 100);
        if (valid) {
          setHits(results);
          setSelected(0);
        }
      } catch {
        if (valid) setError('搜索条件无法解析。请修改文件范围后重试。');
      } finally {
        if (valid) {
          setBusy(false);
          setSpinner(false);
          clearTimeout(spin);
        }
      }
    }, 50);
    return () => {
      valid = false;
      clearTimeout(work);
      clearTimeout(spin);
    };
  }, [query, mask, scope]);
  const pick = r => {
    if (!r || busy) return;
    remember(true);
    onOpen(r.path, query, r.number, r.column);
  };
  const keydown = e => {
    if (e.isComposing) return;
    if (e.key === 'Escape') {
      e.stopPropagation();
      onClose();
    }
    if (e.key === 'ArrowUp' && e.target === input.current && (selected === 0 || !hits.length)) {
      e.preventDefault();
      if (historyIndex.current === -1) historyDraft.current = query;
      if (historyIndex.current + 1 < history.queries.length) setQuery(history.queries[++historyIndex.current]);
      return;
    }
    if (e.key === 'ArrowDown' && e.target === input.current && historyIndex.current >= 0) {
      e.preventDefault();
      historyIndex.current--;
      setQuery(historyIndex.current < 0 ? historyDraft.current : history.queries[historyIndex.current]);
      return;
    }
    if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
      e.preventDefault();
      setSelected(i => Math.max(0, Math.min(hits.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1))));
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      pick(hits[selected]);
    }
  };
  return <div className="fw-modal-scrim" onClick={onClose}><section className="fw-dialog fw-search-dialog" role="dialog" aria-modal="true" aria-label="在文件中搜索" onClick={e => e.stopPropagation()} onKeyDown={keydown}>
    <div className="fw-find"><Search size={18} /><input ref={input} aria-label="搜索文件内容" autoFocus maxLength={256} placeholder="搜索所有文件中的文本…" value={query} onChange={e => {
          setQuery(e.target.value);
          setSelected(0);
          historyIndex.current = -1;
        }} /><Button icon={X} label="关闭内容搜索" onClick={onClose} /></div>
    <div className="fw-search-mask"><label>文件范围<input aria-label="文件范围" list="m9-file-masks" maxLength={256} value={mask} onChange={e => setMask(e.target.value)} onKeyDown={e => {
            if(e.isComposing)return;
            if (['ArrowUp', 'ArrowDown', 'Enter'].includes(e.key)) e.stopPropagation();
            if (e.key === 'Enter') {
              remember();
              input.current?.focus();
            }
          }} placeholder="*.ts" /><datalist id="m9-file-masks">{history.masks.map(m => <option key={m} value={m} />)}</datalist></label><span>{spinner ? '搜索中…' : hits.length + ' 条匹配'}{hits.length === 100 ? '（最多前100行）' : ''}</span></div>
    <div className="fw-search-results" ref={resultsRef} role="listbox" aria-label="搜索结果" aria-busy={busy}>{hits.map((r, i) => <button key={r.path + ':' + r.number} role="option" aria-selected={selected === i} onMouseEnter={() => setSelected(i)} onClick={() => pick(r)}><code>{r.line.slice(0, r.column - 1)}<mark>{r.line.slice(r.column - 1, r.column - 1 + query.length)}</mark>{r.line.slice(r.column - 1 + query.length)}</code><span title={r.path}><Icon file={r.path} />{r.path}<small>:{r.number}:{r.column}</small></span></button>)}{error && <p role="alert">{error}</p>}{query && !hits.length && !busy && !error && <p>没有匹配内容</p>}{!query && <p>搜索当前目录中的文件内容；↑ 可访问本目录的查询历史。</p>}</div>
    <small>↑↓ 选择 · Enter 打开 · Esc 关闭。原型仅搜索示例文件，glob与取消服务不是实际rg后端。</small>
  </section></div>;
}
function Media({
  kind,
  name,
  onCopy,
  onDownload
}) {
  const [playing, setPlaying] = useState(false),
    [position, setPosition] = useState(0),
    [speed, setSpeed] = useState(1),
    [muted, setMuted] = useState(false),
    [volume, setVolume] = useState(.75),
    [expanded, setExpanded] = useState(false),
    [pip, setPip] = useState(false),
    [menu, setMenu] = useState(false),
    [volumeOpen, setVolumeOpen] = useState(false);
  const resume = useRef(false);
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => setPosition(p => {
      if (p >= 20) {
        setPlaying(false);
        return 20;
      }
      return Math.min(20, p + .1 * speed);
    }), 100);
    return () => clearInterval(timer);
  }, [playing, speed]);
  const toggle = () => {
    if (position >= 20) setPosition(0);
    setPlaying(p => !p);
  };
  const release = () => {
    if (resume.current) setPlaying(true);
    resume.current = false;
  };
  const time = n => Math.floor(n / 60) + ':' + String(Math.floor(n % 60)).padStart(2, '0');
  return <div className={'fw-media ' + (expanded ? 'fw-media-expanded' : '') + (pip ? ' fw-media-pip' : '')}>
  {kind === 'video' ? <div className="fw-video-frame" tabIndex={0} aria-label="视频画面" onKeyDown={e => {
      if ([' ', 'Enter'].includes(e.key)) {
        e.preventDefault();
        if (!e.repeat) toggle();
      }
    }}><img src="/assets/app-icon.png" alt="WillYou 演示画面" /><h2>文件工作区</h2><p>媒体控件交互示例</p></div> : <strong>{name} · WAV</strong>}
  <div className="fw-media-bar"><Button icon={playing ? Pause : Play} label={playing ? '暂停' : '播放'} onClick={toggle} /><input aria-label="播放进度" type="range" min={0} max={20} step={.1} value={position} onPointerDown={() => {
        resume.current = playing;
        setPlaying(false);
      }} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release} onChange={e => setPosition(+e.target.value)} /><span>{time(position)} / {time(20)}</span>
  {kind === 'video' && <><button aria-label="视频音量" aria-expanded={volumeOpen} onClick={() => setVolumeOpen(!volumeOpen)}>{muted ? '静音中' : '声音'}</button>{volumeOpen && <span className="fw-volume"><button aria-label={muted ? '取消静音' : '静音'} onClick={() => setMuted(!muted)}>{muted ? '取消静音' : '静音'}</button><input aria-label="音量" type="range" min={0} max={1} step={.01} value={muted ? 0 : volume} onChange={e => {
            setVolume(+e.target.value);
            setMuted(false);
          }} /></span>}<button onClick={() => setPip(!pip)}>{pip ? '退出画中画' : '画中画（模拟）'}</button><Button icon={expanded ? Minimize2 : Maximize2} label={expanded ? '退出全屏示例' : '全屏示例'} onClick={() => setExpanded(!expanded)} /></>}
  <Button icon={MoreHorizontal} label="媒体菜单" onClick={() => setMenu(!menu)} /></div>
  {menu && <div className="fw-media-options">{kind === 'audio' && <button onClick={() => {
        onCopy();
        setMenu(false);
      }}>复制路径</button>}<button onClick={() => {
        onDownload();
        setMenu(false);
      }}>{kind === 'video' ? '视频另存为' : '另存副本'}</button>{kind === 'video' && <label>播放速度 <select aria-label="播放速度" value={speed} onChange={e => setSpeed(+e.target.value)}>{[.25, .5, .75, 1, 1.25, 1.5, 1.75, 2].map(v => <option key={v} value={v}>{v}×</option>)}</select></label>}</div>}
  <small>模拟时间轴和控件；不播放真实文件。系统全屏、画中画可用性与 codec 尚未验证。</small></div>;
}
export function FileWorkspace({
  task,
  project,
  dark,
  onTheme,
  onClose
}) {
  const [store, setStore] = useState(load),
    [query, setQueryLocal] = useState(''),
    [menu, setMenuState] = useState(null),
    [confirm, setConfirm] = useState(null),
    [demo, setDemo] = useState(false),
    [full, setFull] = useState(false),
    [searchMode, setSearchMode] = useState(false),
    [status, setStatus] = useState(''),
    [auto, setAuto] = useState(true),
    [find, setFind] = useState(''),
    [findIndex, setFindIndex] = useState(0),
    [focusedPath, setFocusedPathLocal] = useState('AGENTS.md'),
    [searchCollapsed, setSearchCollapsed] = useState([]),
    [tooltip, setTooltip] = useState(null),
    [appsState, setAppsState] = useState('ready'),
    [rootScenario, setRootScenario] = useState('multiple'),
    [finding, setFinding] = useState(false),
    [context, setContext] = useState(''),
    [rich, setRich] = useState(null),
    [dock, setDock] = useState('right'),
    [contentSearch, setContentSearch] = useState(false),
    [wrap, setWrap] = useState(false),
    [selection, setSelection] = useState(null),
    [aiState, setAiState] = useState(null),
    [composing, setComposing] = useState(false),
    [selectedRows, setSelectedRowsLocal] = useState([]),
    [reveal, setReveal] = useState(null),
    [remote, setRemote] = useState(false),
    [imageOverlay, setImageOverlay] = useState(false),
    [changedOnly, setChangedOnly] = useState(false),
    [hideGenerated, setHideGenerated] = useState(false),
    [blame, setBlame] = useState(false),
    [extension, setExtension] = useState(false),
    [symbol, setSymbol] = useState(null);
  const roots = rootScenario==='none'?[]:[{
    id: 'main',
    hostId: task.hostId || 'local',
    label: project.name || 'WillYou',
    path: task.cwd || project.path || '/workspace/SmartDD'
  }, ...(rootScenario==='single'?[]:[{
    id: 'extra',
    hostId: task.hostId || 'local',
    label: '共享文档',
    path: rootScenario==='nested' ? (task.cwd || project.path || '/workspace/SmartDD')+'/docs' : '/workspace/shared-docs'
  }])];
  const scope = workspaceScope(task.id, roots);
  const createState=()=>roots.length?initialWorkspace():{...initialWorkspace(),tabs:[],active:null};
  const state = store[scope] || createState(),
    set = fn => setStore(old => {
      const previous=old[scope]||createState();
      const next=typeof fn==='function'?fn(previous):fn;
      return {...old,[scope]:next.expanded!==previous.expanded?updateRootView(next,{expanded:next.expanded}):next};
    });
  function filesForRoot(id=state.root) {
    return rootScenario==='nested'&&id==='extra'?FILES.filter(f=>f.path.startsWith('docs/')).map(f=>({...f,path:f.path.slice(5)})):FILES;
  }
  function getFile(id,path) {return filesForRoot(id).find(f=>f.path===path);}
  function setQuery(value) {const next=typeof value==='function'?value(query):value;setQueryLocal(next);set(s=>updateRootView(s,{query:next}));}
  function setSelectedRows(value) {const next=typeof value==='function'?value(selectedRows):value;setSelectedRowsLocal(next);set(s=>updateRootView(s,{selected:next}));}
  function setFocusedPath(value) {setFocusedPathLocal(value);set(s=>updateRootView(s,{focused:value}));}
  const current = state.tabs.find(t => fileKey(t.root, t.path) === state.active),
    file = getFile(current?.root,current?.path),
    draft = state.drafts[state.active],
    identity = documentKey(roots, state.active),
    revision = state.revisions?.[state.active] || 0,
    text = draft?.text ?? store.saved?.[identity] ?? file?.text ?? '',
    scenario = fileScenario(state),
    mode = state.mode[state.active] || 'render';
  const editor = useRef(null),
    filter = useRef(null),
    host = useRef(null),
    compose = useRef(false),
    dragged = useRef(null),
    timer = useRef(null),
    historyRef = useRef({}),
    anchor = useRef(null), menuRef = useRef(null), triggerRef = useRef(null), pointerRef = useRef(null), treeRef = useRef(null), tooltipTimer = useRef(null);
  const root = roots.find(r => r.id === state.root) || roots[0] || {id:'none',path:'',label:'无工作目录',hostId:'local'},
    activeRoot = roots.find(r => r.id === current?.root) || root;
  const effective = scenario === 'ready' ? file?.kind : scenario;
  function setMenu(next) {
    if (!next) { setMenuState(null); if(triggerRef.current?.isConnected)triggerRef.current.focus({preventScroll:true}); return; }
    if (!menu) triggerRef.current = document.activeElement;
    const target = document.activeElement?.getBoundingClientRect();
    const location = next.point || (pointerRef.current && performance.now()-pointerRef.current.time<400 ? pointerRef.current : { x:target?.left||0, y:target?.bottom||0 });
    setMenuState({...next, point:location});
  }
  useLayoutEffect(() => {
    if(!menu || !menuRef.current) return;
    const el=menuRef.current, r=el.getBoundingClientRect();
    el.style.left=Math.max(8,Math.min(menu.point.x,innerWidth-r.width-8))+'px';
    el.style.top=Math.max(8,Math.min(menu.point.y,innerHeight-r.height-8))+'px';
    el.querySelector('button:not(:disabled)')?.focus();
  },[menu]);
  const modalActive=!!(confirm||contentSearch||aiState);
  useEffect(() => {
    if(!modalActive)return;
    const previous=document.activeElement, dialog=host.current?.querySelector('[role=dialog]');
    if(!dialog)return;
    dialog.querySelector('input,textarea,button')?.focus();
    const trap=e=>{
      if(e.key!=='Tab')return;
      const items=[...dialog.querySelectorAll('input:not(:disabled),textarea:not(:disabled),button:not(:disabled),select:not(:disabled),[tabindex="0"]')].filter(el=>el.getClientRects().length);
      if(!items.length)return;
      const index=items.indexOf(document.activeElement);
      if((e.shiftKey&&index<=0)||(!e.shiftKey&&index===items.length-1)){e.preventDefault();items[e.shiftKey?items.length-1:0].focus();}
    };
    dialog.addEventListener('keydown',trap);
    return()=>{dialog.removeEventListener('keydown',trap);if(previous?.isConnected)previous.focus();};
  },[modalActive,contentSearch,confirm?.type,aiState?.phase]);
  function changeRoot(id) {
    const next=readRootView(state,id);
    set(s=>({...s,root:id,expanded:next.expanded,rootStates:{...s.rootStates,[s.root]:{expanded:s.expanded,selected:selectedRows,query,focused:focusedPath,scrollTop:treeRef.current?.scrollTop||0}}}));
    setQueryLocal(next.query);setSelectedRowsLocal(next.selected);setFocusedPathLocal(next.focused);anchor.current=null;
    requestAnimationFrame(()=>{if(treeRef.current)treeRef.current.scrollTop=next.scrollTop;});
  }
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE, JSON.stringify(serializeWorkspaceStore(store)));
    } catch {
      setStatus('原型存储已满；当前页内容仍保留。');
    }
  }, [store]);
  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => {
    if (!reveal || !editor.current) return;
    const offset = text.split('\n').slice(0, reveal.number - 1).join('\n').length + (reveal.number > 1 ? 1 : 0) + Math.max(0, (reveal.column || 1) - 1);
    editor.current.focus();
    editor.current.setSelectionRange(offset, offset + reveal.query.length);
    editor.current.scrollTop = Math.max(0, (reveal.number - 3) * 21);
    setReveal(null);
  }, [reveal, text, mode]);
  useLayoutEffect(() => {
    const view=readRootView(state);
    setQueryLocal(view.query);setSelectedRowsLocal(view.selected);setFocusedPathLocal(view.focused);
    setMenuState(null);setRich(null);anchor.current=null;setSearchCollapsed([]);
    const frame=requestAnimationFrame(()=>{if(treeRef.current)treeRef.current.scrollTop=view.scrollTop;});
    return()=>cancelAnimationFrame(frame);
  }, [scope]);
  useEffect(() => {
    setSelection(null);
    setAiState(null);
  }, [identity, revision]);
  function scenarioText(value, label) {
    if(['xlsx','pptx'].includes(file?.kind)) {
      const doc=createOfficeDocument(file.kind,value);
      if(file.kind==='xlsx')doc.sheets[0].cells[0][0]=label;
      else {doc.slides[0].title+=' · '+label;const title=doc.slides[0].elements.find(e=>e.kind==='text');if(title)title.text+=' · '+label;}
      return serializeOffice(doc);
    }
    return value + '\n' + label;
  }
  function setScenario(value, key = state.active) {
    const diskText = value === 'conflict' ? scenarioText(store.saved?.[documentKey(roots, key)] ?? getFile(key?.split('\u0000')[0],key?.split('\u0000')[1])?.text ?? '', '外部更新') : undefined;
    set(s => setFileScenario(s, key, value, diskText));
  }
  function note(message) {
    setStatus(message);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setStatus(''), 3500);
  }
  function open(path, pin = false, rootId = state.root) {
    set(s => { const next=openDocument(s, roots, rootId, path, pin);const ancestors=path.split('/').slice(0,-1).map((_,i)=>path.split('/').slice(0,i+1).join('/'));return {...next,expanded:[...new Set([...next.expanded,...ancestors])]}; });
    setRich(null);
    setMenu(null);
  }
  function save(key = state.active, override = false) {
    if (!state.drafts[key]) return true;
    const outcome = commitDraft({
      ...store,
      [scope]: state
    }, scope, roots, key, {
      override
    });
    if (outcome.result === 'conflict') {
      setStore(old => commitDraft(old, scope, roots, key, {
        override
      }).store);
      setConfirm({
        type: 'conflict',
        key
      });
      return;
    }
    if (outcome.result === 'save-error') {
      note('保存失败：文件不可写。修改仍保留，可重试或另存为。');
      return;
    }
    if (outcome.result !== 'saved') return false;
    setStore(old => commitDraft(old, scope, roots, key, {
      override
    }).store);
    note('已保存到原型示例数据');
    return true;
  }
  useEffect(() => {
    if (!auto || !draft || scenario !== 'ready' || composing) return;
    const id = setTimeout(() => save(), ['xlsx', 'pptx'].includes(file?.kind) ? 500 : 3000);
    return () => clearTimeout(id);
  }, [text, auto, scenario, state.active, scope, composing]);
  function edit(value, record = true) {
    if (value === text) return;
    if (record) {
      const h = historyRef.current[identity] || {
        undo: [],
        redo: []
      };
      h.undo.push(text);
      h.redo = [];
      historyRef.current[identity] = h;
    }
    const key = state.active;
    set(s => editDraft(s, key, value, store.saved?.[identity] ?? file?.text ?? ''));
  }
  function undo(redo = false) {
    const h = historyRef.current[identity];
    if (!h) return;
    const from = redo ? h.redo : h.undo,
      to = redo ? h.undo : h.redo;
    if (!from.length) return;
    to.push(text);
    edit(from.pop(), false);
  }
  function switchMode() {
    if (draft && !save()) return;
    set(s => ({
      ...s,
      mode: {
        ...s.mode,
        [s.active]: mode === 'source' ? 'render' : 'source'
      }
    }));
    setRich(null);
  }
  function close(key) {
    if (state.drafts[key]) {
      if (!save(key)) {
        setConfirm({
          type: 'close',
          key
        });
        return;
      }
    }
    set(s => closeFile(s, key));
  }
  function discard(key) {
    set(s => {
      const drafts = {
        ...s.drafts
      };
      delete drafts[key];
      return closeFile({
        ...s,
        drafts
      }, key);
    });
    setConfirm(null);
  }
  function reorder(key) {
    const source = dragged.current;
    if (!source || source === key) return;
    set(s => {
      const tabs = [...s.tabs],
        a = tabs.findIndex(t => fileKey(t.root, t.path) === source),
        b = tabs.findIndex(t => fileKey(t.root, t.path) === key);
      if (a < 0 || b < 0) return s;
      const [t] = tabs.splice(a, 1);
      tabs.splice(b, 0, {
        ...t,
        preview: false
      });
      return {
        ...s,
        tabs
      };
    });
  }
  function resize(e) {
    e.preventDefault();
    const start = e.clientX,
      w = state.width;
    const move = ev => set(s => ({
      ...s,
      tree: w + start - ev.clientX >= 100,
      width: Math.max(200, Math.min(host.current.clientWidth * .6, w + start - ev.clientX))
    }));
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
  }
  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      note('已复制路径');
    } catch {
      setContext(value);
      note('复制权限不可用，路径已显示在下方供选择。');
    }
    setMenu(null);
  }
  function download(path, rootId = current?.root || state.root) {
    const item = getFile(rootId,path);
    if(!item)return note('示例目录中没有该文件。');
    const key = fileKey(rootId, path);
    const blob = new Blob([state.drafts[key]?.text ?? store.saved?.[documentKey(roots, key)] ?? item.text], {
      type: 'text/plain'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = path.split('/').pop() + (isText(item) ? '' : '.preview.txt');
    a.click();
    URL.revokeObjectURL(a.href);
    setMenu(null);
    note(isText(item) ? '已下载原型示例内容' : '已下载交互示例文本，不是实际文档文件');
  }
  function keys(e) {
    if (compose.current || e.isComposing || e.defaultPrevented) return;
    if (e.target.closest('[role=dialog], [role=menu]')) { if(e.key==='Escape'){e.stopPropagation();setMenu(null);setConfirm(null);setAiState(null);setContentSearch(false);} return; }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      e.stopPropagation();
      save();
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f' && !rich && isText(file) && !e.target.closest('input,select')) {
      e.preventDefault();
      e.stopPropagation();setFinding(true);
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 't') {
      e.preventDefault();
      set(s => restoreFile(s));
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase()==='g' && finding){e.preventDefault();navigateFind(e.shiftKey?-1:1);}
    if(e.key==='F3'&&finding){e.preventDefault();navigateFind(e.shiftKey?-1:1);}
    if (e.key === 'Escape') {
      setMenu(null);
      setFinding(false);
      setConfirm(null);
    }
  }
  const displayed=(!roots.length?[]:query.trim()?searchTreeRows(filesForRoot(),query,searchCollapsed):treeRows(filesForRoot(),state.expanded)).filter(r=>!changedOnly||r.folder||['AGENTS.md','src/main.ts','package.json','CHANGELOG.md'].includes(r.path)).filter(r=>!changedOnly||!hideGenerated||r.path!=='package.json');
  const effectiveExpanded=query.trim()?displayed.filter(r=>r.folder&&!searchCollapsed.includes(r.path)).map(r=>r.path):state.expanded;
  function toggleFolder(path, expand=!effectiveExpanded.includes(path)) {
    if(query.trim())setSearchCollapsed(old=>expand?old.filter(p=>p!==path):[...new Set([...old,path])]);
    else set(s=>({...s,expanded:expand?[...new Set([...s.expanded,path])]:s.expanded.filter(p=>p!==path)}));
  }
  const hideTooltip=()=>{clearTimeout(tooltipTimer.current);setTooltip(null);};
  function showTooltip(e,path) {
    if(e.pointerType==='touch'||e.buttons)return;
    const box=e.currentTarget.getBoundingClientRect();clearTimeout(tooltipTimer.current);
    tooltipTimer.current=setTimeout(()=>setTooltip({path:root.path+'/'+path,x:Math.min(box.left,innerWidth-328),y:Math.min(box.bottom+5,innerHeight-100)}),500);
  }
  useEffect(()=>{hideTooltip();return()=>clearTimeout(tooltipTimer.current);},[scope,query,state.root]);
  function selectRow(e, r) {
    if (r.folder && !e.metaKey && !e.ctrlKey && !e.shiftKey) {
      setFocusedPath(r.path);setSelectedRows([r.path]);anchor.current=r.path;
      toggleFolder(r.path);
      return;
    }
    let next = [r.path];
    if (e.shiftKey && anchor.current) {
      const a = displayed.findIndex(x => x.path === anchor.current),
        b = displayed.findIndex(x => x.path === r.path);
      next = displayed.slice(Math.min(a, b), Math.max(a, b) + 1).map(x => x.path);
    } else if (e.metaKey || e.ctrlKey) next = selectedRows.includes(r.path) ? selectedRows.filter(p => p !== r.path) : [...selectedRows, r.path];else anchor.current = r.path;
    setSelectedRows(next);
    setFocusedPath(r.path);
    if (!r.folder && !e.shiftKey && !e.ctrlKey && !e.metaKey) open(r.path);
  }
  const findResults=localFind(text,find);
  function navigateFind(delta){
    if(!findResults.matches.length)return;
    const next=(findIndex+delta+findResults.matches.length)%findResults.matches.length;setFindIndex(next);
    const hit=findResults.matches[next], line=text.slice(0,hit.from).split('\n').length;
    if(editor.current){editor.current.setSelectionRange(hit.from,hit.to);editor.current.scrollTop=Math.max(0,(line-3)*21);}
    else host.current?.querySelector('[data-md-line="'+line+'"]')?.scrollIntoView({block:'center'});
  }
  return <aside ref={host} className={'file-workspace ' + (full ? 'fw-full' : '') + (dock === 'bottom' ? ' fw-bottom' : '')} aria-label="M9 文件工作区原型" onKeyDown={e=>{hideTooltip();keys(e);}} onPointerDownCapture={e=>{pointerRef.current={x:e.clientX,y:e.clientY,time:performance.now()};}}>
  <div className="fw-tabs" role="tablist" aria-label="文件标签" onKeyDown={e=>{if(e.isComposing||!e.target.matches('[role=tab]'))return;const tabs=[...e.currentTarget.querySelectorAll('[role=tab]')],i=tabs.indexOf(e.target);if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;tabs[next]?.click();tabs[next]?.focus();}}}>{state.tabs.map(t => {
        const key = fileKey(t.root, t.path);
        return <div key={key} className={'fw-tab ' + (key === state.active ? 'selected ' : '') + (t.preview ? 'preview' : '')} draggable onDragStart={() => dragged.current = key} onDragOver={e => e.preventDefault()} onDrop={() => reorder(key)} onContextMenu={e => {
          e.preventDefault();
          setMenu({
            type: 'tab',
            key
          });
        }}><button role="tab" tabIndex={key===state.active?0:-1} aria-selected={key === state.active} onClick={() => {
            set(s => ({
              ...s,
              active: key
            }));
            setRich(null);
          }} onDoubleClick={() => open(t.path, true, t.root)} title={roots.find(r => r.id === t.root)?.path + '/' + t.path}><Icon file={t.path} /><span>{key===state.active&&rich?'格式演示 · '+rich.toUpperCase():t.path.split('/').pop()}</span>{state.drafts[key] && <span className="fw-dirty" aria-label="未保存" />}</button><button className="fw-tab-close" aria-label={'关闭 ' + t.path} onClick={() => close(key)}><X size={14} /></button></div>;
      })}<Button icon={Plus} label="查找并打开文件" onClick={() => {
        set(s => ({
          ...s,
          tree: true
        }));
        requestAnimationFrame(()=>filter.current?.focus());
      }} /><span className="fw-push" /><Button icon={full ? Minimize2 : Maximize2} label={full ? '退出文件聚焦' : '聚焦文件工作区'} onClick={() => setFull(!full)} /><Button icon={PanelRight} label="隐藏文件工作区" onClick={onClose} /></div>
  <div className="fw-toolbar"><div className="fw-breadcrumb">{(rich?['会话产物查看器演示',rich.toUpperCase()]:[activeRoot.label, ...(current?.path.split('/') || [])]).map((part, i, arr) => <span key={i}><button title={activeRoot.path + '/' + arr.slice(1, i + 1).join('/')} className={i === arr.length - 1 ? 'current' : ''} disabled={!!rich} onClick={() => setMenu(menu?.type === 'crumb' ? null : {
            type: 'crumb',
            prefix: i===arr.length-1 && current ? current.path.split('/').slice(0,-1).join('/') : arr.slice(1, i + 1).join('/'),
            root: current?.root || state.root
          })}>{part}</button>{i < arr.length - 1 && <ChevronRight size={13} />}</span>)}</div><div className="fw-tools"><Button icon={FileSearch} label="在文件中搜索" active={searchMode} onClick={() => setContentSearch(true)} />{!rich && file && ['markdown', 'svg', 'html'].includes(file.kind) && <button className="fw-pill" onClick={switchMode}><Code2 size={16} />{mode === 'source' ? '查看文档' : '查看源代码'}</button>}<Button icon={MoreHorizontal} label="文件查看选项" onClick={() => setMenu({
          type: 'viewer'
        })} /><Button icon={FolderOpen} label="切换文件目录" active={state.tree} onClick={() => set(s => ({
          ...s,
          tree: !s.tree
        }))} /><button className="fw-pill" onClick={() => setMenu(menu?.type === 'external' ? null : {
          type: 'external'
        })}><ExternalLink size={16} />打开<ChevronDown size={13} /></button></div></div>
  <div className="fw-body"><section className="fw-content" aria-label="文件内容">
   {finding && !rich && isText(file) && <div className="fw-find"><Search size={15}/><input autoFocus aria-label="查找当前文件" value={find} onChange={e=>{setFind(e.target.value);setFindIndex(0);}} onKeyDown={e=>{if(e.isComposing)return;if(e.key==='Enter'){e.preventDefault();navigateFind(e.shiftKey?-1:1);}if(e.key==='Escape'){e.preventDefault();e.stopPropagation();setFinding(false);editor.current?.focus();}}} placeholder="查找当前文件"/><button aria-label="上一个匹配" disabled={!findResults.matches.length} onClick={()=>navigateFind(-1)}><ArrowLeft size={14}/></button><button aria-label="下一个匹配" disabled={!findResults.matches.length} onClick={()=>navigateFind(1)}><ArrowRight size={14}/></button><span>{findResults.matches.length?Math.min(findIndex+1,findResults.matches.length):0} / {Math.min(999,findResults.matches.length)}{findResults.matches.length>999?'+':''}</span><Button icon={X} label="关闭查找" onClick={()=>{setFinding(false);editor.current?.focus();}}/></div>}

   {draft && <div className="fw-save-strip"><span>{scenario === 'save-error' ? '保存失败，修改已保留' : scenario === 'conflict' ? '文件已被外部修改' : '未保存的修改'}</span><button onClick={() => save()}>保存</button>{scenario === 'conflict' && <button onClick={() => setConfirm({
            type: 'conflict',
            key: state.active
          })}>查看差异</button>}</div>}
   {file && !rich && isText(file) && <div className="fw-editor-tools"><Button icon={Undo2} label="撤销" disabled={!historyRef.current[identity]?.undo.length} onClick={() => undo()} /><Button icon={Redo2} label="重做" disabled={!historyRef.current[identity]?.redo.length} onClick={() => undo(true)} /><Button icon={WrapText} label="自动换行" active={wrap} onClick={() => setWrap(!wrap)} /><Button icon={Copy} label="复制文件内容" onClick={() => copy(text)} /><span className="fw-push" /><button onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
          }} disabled={!selection || file.kind === 'large'}>编辑所选文本</button></div>}
   {blame && file && <div className="fw-save-strip"><span>示例作者 · a1b2c3 · 初始文件（只读归属演示）</span><button onClick={() => setBlame(false)}>关闭行归属</button></div>}
   {symbol && <div className="fw-symbol-panel"><strong>{symbol === 'definition' ? '定义' : '引用'} · workspace</strong><button onClick={() => {
            open('src/main.ts', true);
            setSymbol(null);
          }}>src/main.ts:4:14</button><button onClick={() => {
            open('src/renderer/App.tsx', true);
            setSymbol(null);
          }}>src/renderer/App.tsx:2:10</button><small>LSP 返回示例，不执行语言服务器。</small><Button icon={X} label="关闭符号结果" onClick={() => setSymbol(null)} /></div>}
   {extension ? <div className="fw-empty"><FileSliders size={28} /><h2>扩展文件查看器</h2><p>演示扩展 · {current?.path} · {remote ? '远程' : '本地'}资源</p><p>资源匹配、权限、读取失败及 ifMatch 冲突按技术方案验证。</p><button onClick={() => setScenario('conflict')}>模拟资源版本冲突</button>{scenario === 'conflict' && <p role="alert">资源已更新。请重新读取后重试，旧版本未覆盖。</p>}<button onClick={() => setExtension(false)}>返回默认查看器</button></div> : !file ? <div className="fw-empty"><File size={30} /><p>选择文件以开始浏览</p><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}>重新打开关闭的文件</button></div> : effective === 'loading' ? <div className="fw-empty" aria-busy="true"><span className="fw-loading" />正在读取文件…<button onClick={() => setScenario('ready')}>完成加载（模拟）</button></div> : ['missing', 'unreadable', 'too-large', 'unsupported', 'root-missing'].includes(effective) ? <div className="fw-empty"><AlertCircle size={28} /><h2>{{
              missing: '文件不存在',
              unreadable: '无法读取文件',
              'too-large': '文件过大',
              unsupported: '不支持预览此文件',
              'root-missing': '工作目录不可用'
            }[effective]}</h2><p>{{
              missing: '文件可能已移动或删除。现有草稿会保留。',
              unreadable: '检查文件权限后重试。',
              'too-large': '此示例超过文本预览限制，请使用外部应用。',
              unsupported: '可以通过外部应用打开此文件。',
              'root-missing': '重新连接或更新项目目录后重试。'
            }[effective]}</p><button className="fw-pill" onClick={() => setScenario('ready')}><RotateCcw size={15} />重试</button><button onClick={() => setMenu({
            type: 'external'
          })}>使用外部应用打开</button></div> : rich ? <FileArtifactPreview key={rich + state.active} kind={rich} readOnly onDownload={() => download(current.path)} /> : file.kind === 'svg' && mode !== 'source' ? <div className="fw-image"><img src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(text)} alt="SVG 文件预览" /></div> : file.kind === 'html' && mode !== 'source' ? <iframe className="fw-html" title="HTML 文件文档预览" sandbox="" srcDoc={text} /> : file.kind === 'markdown' && mode !== 'source' ? <FileMarkdown key={identity + ':' + (state.reloads?.[state.active] || 0)} text={text} findQuery={finding?find:''} path={current.path} overlay={imageOverlay} readOnly={scenario === 'conflict'} onEdit={edit} onSelect={(start,end) => setSelection(captureSelection({scope, identity, revision, text, start, end}))} onOpenFile={path => { const resolved = getFile(current.root,path) ? path : path.startsWith('assets/') ? 'resources/app-icon.png' : null; resolved ? open(resolved,true,current.root) : note('示例目录中没有该目标：'+path); }} onImageReference={image => setContext('图片引用（待发送）：' + image.alt + ' · ' + image.path)} onImageAction={note} onComposition={value => { compose.current=value; setComposing(value); }} /> : ['code', 'html', 'svg', 'large', 'markdown'].includes(file.kind) ? <div className="fw-editor"><div className="fw-line-numbers" aria-hidden="true">{text.split('\n').map((_, i) => <div key={i}>{i + 1}</div>)}</div><textarea ref={editor} aria-label="文件编辑器" spellCheck={false} value={text} readOnly={file.kind === 'large'} onChange={e => edit(e.target.value)} style={{
            whiteSpace: wrap ? 'pre-wrap' : 'pre'
          }} onContextMenu={e => {
            e.preventDefault();
            setMenu({
              type: 'code'
            });
          }} onSelect={e => setSelection(captureSelection({
            scope: scope,
            identity,
            revision,
            text: e.currentTarget.value,
            start: e.currentTarget.selectionStart,
            end: e.currentTarget.selectionEnd
          }))} onCompositionStart={() => {
            compose.current = true;
            setComposing(true);
          }} onCompositionEnd={() => {
            compose.current = false;
            setComposing(false);
          }} />{file.kind === 'large' && <div className="fw-readonly">10–20 MiB 文本：只读预览示例</div>}</div> : file.kind === 'image' ? <div className="fw-image"><img src={file.text} alt={file.path} /></div> : ['audio', 'video'].includes(file.kind) ? <Media key={identity} kind={file.kind} name={file.path.split('/').pop()} onCopy={() => copy(activeRoot.path + '/' + current.path)} onDownload={() => download(current.path)} /> : <FileArtifactPreview key={scope + ':' + identity + ':' + (state.reloads?.[state.active] || 0)} kind={file.kind} readOnly={scenario==='conflict'} initialValue={text} onDraft={edit} onDownload={() => download(current.path)} />}
  </section>{state.tree && <><div className="fw-tree-resizer" role="separator" tabIndex={0} aria-label="调整目录宽度" aria-orientation="vertical" aria-valuenow={state.width} aria-valuemin={200} aria-valuemax={Math.max(200,Math.round((host.current?.clientWidth||1000)*.6))} onPointerDown={resize} onKeyDown={e => {
          if (['ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault();
            set(s => ({
              ...s,
              width: Math.max(200, Math.min(Math.max(200,(host.current?.clientWidth||1000)*.6), s.width + (e.key === 'ArrowLeft' ? 10 : -10)))
            }));
          }
        }} /><aside className="fw-tree" style={{
          width: state.width
        }} aria-label="目录树">{!remote && <label className="fw-filter"><Search size={14} /><input ref={filter} placeholder={searchMode ? '搜索文件内容…' : '筛选文件…'} aria-label="筛选文件" value={query} onChange={e => {setQuery(e.target.value);setSelectedRows([]);anchor.current=null;setSearchCollapsed([]);hideTooltip();}} onKeyDown={e => {
              if(e.isComposing)return;
              if (e.key === 'Escape') {
                e.stopPropagation();
                setQuery('');
              }
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                host.current.querySelector('[role=treeitem]')?.focus();
              }
            }} />{query && <button aria-label="清除筛选" onClick={() => setQuery('')}><X size={13} /></button>}</label>}{changedOnly && <label className="fw-generated"><input type="checkbox" checked={hideGenerated} onChange={e => setHideGenerated(e.target.checked)} />筛除生成文件 {hideGenerated ? "1" : ""}</label>}{roots.length>1&&<div className="fw-root"><button aria-label="选择工作目录" aria-haspopup="menu" onClick={()=>setMenu({type:'roots'})}><Folder size={14}/><span title={root.path}>{root.label}</span><ChevronDown size={12}/></button></div>}{!roots.length&&<p className="fw-no-results">当前任务没有可用工作目录。请在项目中配置目录。</p>}<div className="fw-tree-scroll" role="tree" aria-multiselectable="true" ref={treeRef} onScroll={e=>{hideTooltip();const scrollTop=e.currentTarget.scrollTop;set(s=>updateRootView(s,{scrollTop}));}} onKeyDown={e=>{
            if(e.isComposing)return;
            const intent=treeKeyboardIntent(displayed,effectiveExpanded,e.target.dataset.path||focusedPath,e.key,{shift:e.shiftKey,toggle:e.metaKey||e.ctrlKey,anchor:anchor.current,selected:selectedRows});
            if(!Object.keys(intent).length)return;
            e.preventDefault();e.stopPropagation();
            if(intent.expand)toggleFolder(intent.expand,true);
            if(intent.collapse)toggleFolder(intent.collapse,false);
            if(intent.selected)setSelectedRows(intent.selected);
            if(intent.anchor)anchor.current=intent.anchor;
            if(intent.focus){setFocusedPath(intent.focus);const item=[...e.currentTarget.querySelectorAll('[role=treeitem]')].find(el=>el.dataset.path===intent.focus);item?.focus();item?.scrollIntoView({block:'nearest'});}
          }}>{displayed.map(r => <button key={r.path} role="treeitem" aria-expanded={r.folder ? effectiveExpanded.includes(r.path) : undefined} aria-selected={selectedRows.length ? selectedRows.includes(r.path) : identity === documentKey(roots,fileKey(state.root,r.path))} aria-level={r.depth+1} data-path={r.path} tabIndex={focusedPath===r.path||(!displayed.some(x=>x.path===focusedPath)&&displayed[0]?.path===r.path)?0:-1} onFocus={()=>setFocusedPath(r.path)} className={'fw-tree-row ' + (identity === documentKey(roots,fileKey(state.root,r.path)) ? 'selected' : '')} style={{
              paddingLeft: 3 + r.depth * 16
            }} onPointerEnter={e=>showTooltip(e,r.path)} onPointerLeave={hideTooltip} onPointerDown={hideTooltip} onClick={e => selectRow(e, r)} onDoubleClick={() => !r.folder && open(r.path, true)} onKeyDown={e => {
              if(e.isComposing)return;
              if((e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10'))&&!r.folder&&!remote){e.preventDefault();const box=e.currentTarget.getBoundingClientRect();setMenu({type:'file',path:r.path,point:{x:box.left,y:box.bottom}});}
              if (e.key === 'Enter' && !r.folder) {
                e.preventDefault();
                open(r.path, true);
              }
            }} onContextMenu={e => {
              if (r.folder || remote) return;
              e.preventDefault();
              setMenu({
                type: 'file',
                path: r.path,
                folder: r.folder, point:{x:e.clientX,y:e.clientY}
              });
            }}>{r.folder ? effectiveExpanded.includes(r.path) ? <ChevronDown size={13} /> : <ChevronRight size={13} /> : <span className="fw-tree-spacer" />}{!r.folder && <Icon file={r.path} />}<span>{query&&r.indices?.length?r.name.split('').map((c,i)=><span key={i} className={r.indices.includes(i)?'fw-fuzzy-hit':''}>{c}</span>):r.name}</span>{!r.folder&&{'AGENTS.md':'M','src/main.ts':'M','package.json':'A','CHANGELOG.md':'M'}[r.path]&&<small className="fw-git-state" aria-label="Git 状态示例">{{'AGENTS.md':'M','src/main.ts':'M','package.json':'A','CHANGELOG.md':'M'}[r.path]}</small>}</button>)}{roots.length>0&&!displayed.length && <p className="fw-no-results">{query?'未找到匹配的文件':'此目录为空'}</p>}</div></aside></>}</div>
  <footer className="fw-footer"><button onClick={() => setDemo(!demo)}><Settings2 size={13} />M9 交互样例<ChevronDown size={12} /></button><span role="status">{status || '示例数据 · 未连接真实文件'}</span><span className="fw-push" />{current && <span>{current.preview ? '预览' : '已固定'} · UTF-8</span>}<Button icon={dark ? Sun : Moon} label="切换原型主题" onClick={onTheme} /></footer>
  {demo && <div className="fw-demo"><label>目录样例<select aria-label="工作目录场景" value={rootScenario} onChange={e=>setRootScenario(e.target.value)}><option value="multiple">多根</option><option value="single">单根</option><option value="nested">嵌套根</option><option value="none">无根</option></select></label><label>场景<select aria-label="文件状态场景" value={scenario} onChange={e => {
          setScenario(e.target.value);
          if (['conflict', 'save-error'].includes(e.target.value) && file) edit(scenarioText(text, '本地修改'));
        }}>{[['ready', '正常'], ['loading', '读取中'], ['conflict', '外部修改冲突'], ['save-error', '保存失败'], ['missing', '已删除'], ['unreadable', '无读取权限'], ['too-large', '过大'], ['unsupported', '未知二进制'], ['root-missing', '根不可用']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label><label><input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)} />自动保存（3秒）</label><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}><RotateCcw size={14} />恢复关闭标签</button><button onClick={() => setMenu({
        type: 'formats'
      })}>全部格式与入口</button><label>外开能力<select aria-label="外部应用能力场景" value={appsState} onChange={e=>setAppsState(e.target.value)}><option value="ready">可用</option><option value="loading">加载中</option><option value="error">读取失败</option><option value="unavailable">无能力</option></select></label><label><input type="checkbox" checked={remote} onChange={e => {
          setRemote(e.target.checked);
          setQuery('');
          setMenu(null);
        }} />远程环境（模拟）</label><label><input type="checkbox" checked={changedOnly} onChange={e => {
          setChangedOnly(e.target.checked);
          setQuery('');
        }} />变化文件上下文</label><label><input type="checkbox" checked={imageOverlay} onChange={e => setImageOverlay(e.target.checked)} />图片新叠层（模拟开关）</label><button onClick={() => note('原型状态已在本浏览器保存；刷新可检查恢复。')}>检查恢复</button></div>}
  {tooltip&&<div className="fw-path-tooltip" role="tooltip" style={{left:tooltip.x,top:tooltip.y}}>{tooltip.path}</div>}
  {context && <div className="fw-context"><File size={14} /><span>{context}</span><Button icon={X} label="移除文件引用" onClick={() => setContext('')} /></div>}
  {contentSearch && <ContentSearch files={filesForRoot()} scope={JSON.stringify([root.hostId, [root.path]])} onClose={() => setContentSearch(false)} onOpen={(path, line, number, column) => {
      open(path, true);
      set(s => ({
        ...s,
        mode: {
          ...s.mode,
          [fileKey(state.root, path)]: 'source'
        }
      }));
      setFinding(true);
      setFind(line);
      setReveal({
        number,
        column,
        query: line
      });
      setContentSearch(false);
    }} />}
  {menu && <><div className="fw-dismiss" onClick={() => setMenu(null)} /><div ref={menuRef} className={'fw-menu fw-positioned-menu ' + (menu.type === 'formats' ? 'fw-format-menu' : '')} role="menu" aria-label="文件操作菜单" onKeyDown={e=>{e.stopPropagation();const items=[...e.currentTarget.querySelectorAll('button:not(:disabled)')],i=items.indexOf(document.activeElement);if(e.key==='Escape'||e.key==='Tab'){setMenu(null);if(e.key==='Escape')e.preventDefault();}if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();items[e.key==='Home'?0:e.key==='End'?items.length-1:(i+(e.key==='ArrowDown'?1:-1)+items.length)%items.length]?.focus();}}}>
   {menu.type==='roots'&&<><strong>选择工作目录</strong>{roots.map(r=><button key={r.id} role="menuitemradio" aria-checked={state.root===r.id} title={r.path} onClick={()=>{changeRoot(r.id);setMenu(null);}}><Folder size={15}/><span>{r.label}</span><small>{r.path}</small>{state.root===r.id&&<Check size={14}/>}</button>)}</>}
   {menu.type === 'viewer' && <><strong>文件查看选项</strong><button onClick={() => {
            setWrap(!wrap);
            setMenu(null);
          }}>自动换行 {wrap ? '已开' : '已关'}</button><button onClick={() => {
            setBlame(!blame);
            setMenu(null);
          }}>只读行归属（示例）</button><button onClick={() => {
            setExtension(!extension);
            setMenu(null);
          }}>扩展文件查看器（模拟）</button><button onClick={() => copy(activeRoot.path + '/' + current?.path)}>复制路径</button><button onClick={() => copy(text)}>复制文件内容</button></>}
   {menu.type === 'code' && <><button onClick={() => {
            setSymbol('definition');
            setMenu(null);
          }}>转到定义</button><button onClick={() => {
            setSymbol('references');
            setMenu(null);
          }}>查找引用</button><button disabled={!selection} onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
            setMenu(null);
          }}>编辑所选文本（模拟）</button><button onClick={() => copy(selection?.text || text)}>复制</button></>}
   {menu.type === 'file' && <><strong>{menu.path.split('/').pop()}</strong><button disabled={appsState!=='ready'} onClick={()=>{note('使用首选应用 Visual Studio Code 打开（模拟）');setMenu(null);}}>使用 Visual Studio Code 打开</button>{appsState==='loading'&&<small>正在读取可用应用…</small>}{appsState==='error'&&<small>无法获取可用应用。可重试或复制路径。</small>}<button onClick={() => setMenu({
            type: 'external',
            path: menu.path
          })}><ExternalLink size={15} />打开方式</button>{!menu.folder && <button disabled={appsState==='unavailable'} onClick={() => download(menu.path, state.root)}><Download size={15} />另存为…</button>}<button onClick={() => copy(root.path + '/' + menu.path)}><Copy size={15} />复制路径</button><button onClick={() => {
            setContext(root.path + '/' + menu.path);
            setMenu(null);
          }}>添加到会话引用（模拟）</button></>}
   {menu.type === 'tab' && <><button onClick={() => {
            set(s => ({
              ...s,
              tabs: s.tabs.map(t => fileKey(t.root, t.path) === menu.key ? {
                ...t,
                preview: false
              } : t)
            }));
            setMenu(null);
          }}><Pin size={15} />固定标签</button><button onClick={() => {
            close(menu.key);
            setMenu(null);
          }}>关闭标签</button><button onClick={() => {
            set(s => restoreFile(s));
            setMenu(null);
          }}>重新打开关闭的标签</button><button onClick={() => {
            setDock(dock === 'right' ? 'bottom' : 'right');
            setMenu(null);
          }}>{dock === 'right' ? '移到底部面板' : '移到右侧面板'}</button></>}
   {menu.type === 'crumb' && <><strong>{menu.prefix||activeRoot.label}</strong>{menu.prefix&&<button onClick={()=>setMenu({...menu,prefix:menu.prefix.split('/').slice(0,-1).join('/')})}><Folder size={15}/>上级目录</button>}{directoryChildren(filesForRoot(menu.root),menu.prefix).map(f=><button key={f.path} onClick={()=>f.folder?setMenu({...menu,prefix:f.path}):open(f.path,false,menu.root)}>{f.folder?<Folder size={15}/>:<Icon file={f}/>} {f.name}</button>)}{!directoryChildren(filesForRoot(menu.root),menu.prefix).length&&<p>此目录为空</p>}<hr/><button onClick={()=>copy(activeRoot.path+(menu.prefix?'/'+menu.prefix:''))}>复制目录路径</button><button onClick={()=>{note('在文件管理器显示目录（模拟）');setMenu(null);}}>在文件管理器中显示</button></>}
   {menu.type === 'external' && <><strong>打开方式</strong>{appsState!=='ready'&&<p>{appsState==='loading'?'正在读取可用应用…':appsState==='error'?'读取应用失败':'此宿主未提供外部应用能力'}</p>}{['Visual Studio Code', '系统默认应用', '在 Finder 中显示'].map(label => <button disabled={appsState!=='ready'} key={label} onClick={() => {
            note(label + '：原型仅模拟，未启动外部应用');
            setMenu(null);
          }}><ExternalLink size={15} />{label}</button>)}<button onClick={() => copy(activeRoot.path + '/' + (menu.path || current?.path || ''))}><Copy size={15} />复制路径</button></>}
   {menu.type === 'formats' && <><strong>文件类型 / 会话产物入口（模拟）</strong>{filesForRoot().map(f => <button key={f.path} onClick={() => open(f.path, true)}><Icon file={f} />{f.path}</button>)}<hr />{['csv', 'tsv', 'ipynb', 'tex', 'pdf', 'pdf-review', 'docx', 'xlsx', 'pptx'].map(kind => <button key={kind} onClick={() => {
            setRich(kind);
            setMenu(null);
          }}>以会话产物打开 {kind.toUpperCase()}</button>)}</>}
  </div></>}
  {aiState && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label="所选文本编辑模拟"><h2>编辑所选文本</h2><p>仅演示文件中的选择、指令、差异与确认流程；未调用模型。</p><pre className="fw-ai-selection">{aiState.selection?.text}</pre>{aiState.phase === 'request' ? <><textarea aria-label="编辑指令" className="fw-ai-prompt" placeholder="描述你希望怎样修改…" value={aiState.instruction} onChange={e => setAiState(a => ({
            ...a,
            instruction: e.target.value
          }))} /><div className="fw-dialog-actions"><button onClick={() => setAiState(null)}>取消</button><button disabled={!aiState.instruction.trim()} onClick={() => setAiState(a => ({
              ...a,
              phase: 'review',
              result: a.selection.text + ' // 修改示例'
            }))}>生成修改（模拟）</button></div></> : <><h3>修改后</h3><pre className="fw-ai-selection">{aiState.result}</pre><div className="fw-dialog-actions"><button onClick={() => setAiState(null)}>拒绝</button><button onClick={() => {
              const next = applySelectionEdit(aiState.selection, {
                scope: scope,
                identity,
                revision,
                text,
                replacement: aiState.result
              });
              if (next === null) note('文件或选区已变化，请重新选择后编辑；未应用旧建议。');else edit(next);
              setAiState(null);
            }}>接受修改</button></div></>}</section></div>}
  {confirm && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label={confirm.type === 'close' ? '保留未保存修改' : '文件修改冲突'}>{confirm.type === 'close' ? <><h2>仍有未保存的修改</h2><p>可以继续查看并保存，或者放弃此文件的修改。</p><div className="fw-dialog-actions"><button onClick={() => setConfirm(null)}>继续查看</button><button className="fw-danger" onClick={() => discard(confirm.key)}>放弃修改并关闭</button></div></> : <><h2>文件已在外部更改</h2><p>请核对本地草稿与磁盘版本。选择前不会覆盖任何一方。</p><div className="fw-conflict-columns"><div><strong>磁盘版本（模拟）</strong><pre>{state.fileStates?.[confirm.key]?.diskText ?? ''}</pre></div><div><strong>本地草稿</strong><pre>{state.drafts[confirm.key]?.text ?? ''}</pre></div></div><div className="fw-dialog-actions"><button onClick={() => setConfirm(null)}>继续编辑</button><button onClick={() => {
              const diskText = state.fileStates?.[confirm.key]?.diskText;
              if (diskText === undefined) {
                note('磁盘示例尚未读取，保留当前修改。');
                return;
              }
              const targetIdentity = documentKey(roots, confirm.key);
              delete historyRef.current[targetIdentity];
              setStore(old => ({
                ...old,
                [scope]: acceptDisk(old[scope] || state, confirm.key),
                saved: {
                  ...old.saved,
                  [targetIdentity]: diskText
                }
              }));
              setConfirm(null);
            }}>采用磁盘版本</button><button onClick={() => {
              save(confirm.key, true);
              setConfirm(null);
            }}>保留本地并保存</button></div></>}</section></div>}
 </aside>;
}
