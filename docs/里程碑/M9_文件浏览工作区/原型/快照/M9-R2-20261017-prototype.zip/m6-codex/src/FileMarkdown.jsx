import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Download, X, ZoomIn, ZoomOut, Copy, Check } from 'lucide-react';
import { markdownBlocks, replaceMarkdownBlock, resolveMarkdownPath, imageMenuActions, fitImage, stepImageZoom, anchoredImageZoom, scaleWheelDelta } from './file-markdown-model.mjs';
import './file-markdown.css';

// Synthetic Markdown editor. Source offsets are retained; never round-trip arbitrary HTML.
export function FileMarkdown({ text, path, findQuery='', overlay=false, readOnly=false, onEdit, onSelect, onOpenFile, onImageReference, onImageAction, onComposition }) {
  const blocks = markdownBlocks(text);
  const [editing, setEditing] = useState(null), [context, setContext] = useState(null), [active, setActive] = useState(null), [copied, setCopied] = useState(false);
  const [imageScenario, setImageScenario] = useState('local'), [showScenario, setShowScenario] = useState(false);
  const article = useRef(null), editRef = useRef(null), origin = useRef(null);
  const pictures = blocks.filter(b => b.type === 'image').map(b => {
    const m = b.raw.trim().match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    const raw = m?.[2] || '', resolved = resolveMarkdownPath(path, raw);
    const safe = raw === '/assets/app-icon.png' || raw === '/assets/m9-image-fixture.svg' || raw.startsWith('data:image/') ? raw : '/assets/app-icon.png';
    return { id:b.from, alt:m?.[1] || '图片', src:safe, original:raw, path:resolved || 'resources/app-icon.png', localPath:resolved ? '/workspace/' + resolved : undefined };
  });
  useEffect(() => { if (editing !== null) editRef.current?.focus(); }, [editing]);
  const begin = (block, event) => {
    if (readOnly || event?.target.closest('a,button,input,summary') || window.getSelection()?.toString()) return;
    setEditing({from:block.from,to:block.to,line:block.line});
  };
  const inline = value => value.split(/(\*\*[^*]+\*\*|~~[^~]+~~|`[^`]+`|\*[^*]+\*|\[[^\]]+\]\([^)]+\)|\$[^$]+\$)/g).map((part,i) => {
    if (part.startsWith('**')) return <strong key={i}>{part.slice(2,-2)}</strong>;
    if (part.startsWith('~~')) return <del key={i}>{part.slice(2,-2)}</del>;
    if (part.startsWith('`')) return <code key={i}>{part.slice(1,-1)}</code>;
    if (part.startsWith('*')) return <em key={i}>{part.slice(1,-1)}</em>;
    if (part.startsWith('$')) return <span className="fw-md-math" key={i} title={'公式源码：' + part}>{part.slice(1,-1)}</span>;
    const link=part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) return <a key={i} href="#" onClick={e=>{e.preventDefault();const target=resolveMarkdownPath(path,link[2]);target?onOpenFile(target):onImageAction('外部链接入口（原型不导航）：'+link[2]);}}>{link[1]}</a>;
    if(!findQuery)return part;
    const pieces=[];let start=0,index;
    while((index=part.toLowerCase().indexOf(findQuery.toLowerCase(),start))>=0){pieces.push(part.slice(start,index),<mark key={index}>{part.slice(index,index+findQuery.length)}</mark>);start=index+findQuery.length;}
    pieces.push(part.slice(start));return <span key={i}>{pieces}</span>;
  });
  const editBlock = b => <textarea ref={editRef} aria-label={'编辑 Markdown 第 '+b.line+' 行'} value={b.raw} rows={Math.max(1,b.raw.split('\n').length)} spellCheck={false} onChange={e=>{const next=replaceMarkdownBlock(text,b,e.target.value);if(next!==null){setEditing({...editing,to:b.from+e.target.value.length});onEdit(next);}}} onBlur={e=>{if(!e.relatedTarget?.closest('[data-markdown-tools]'))setEditing(null);}} onSelect={e=>onSelect?.(b.from+e.target.selectionStart,b.from+e.target.selectionEnd)} onCompositionStart={()=>onComposition?.(true)} onCompositionEnd={()=>onComposition?.(false)} onKeyDown={e=>{if(e.key==='Escape'&&!e.isComposing){e.stopPropagation();setEditing(null);article.current?.focus();}}} />;
  const openImage = (p,e) => {
    origin.current=e.currentTarget;
    const connected=[...article.current.querySelectorAll('[data-md-image]')].filter(n=>n.isConnected).map(n=>pictures.find(p=>p.id===Number(n.dataset.mdImage))).filter(Boolean);
    setActive({ picture:p, pictures:connected.length?connected:[p] });
  };
  const imageAction = async (action,picture) => {
    setContext(null);
    if(action.id==='open') return onOpenFile(picture.path);
    if(action.id==='reference'&&imageScenario==='no-input')return onImageAction('当前模型不支持图片输入，图片未加入会话草稿。');
    if(action.id==='reference') return onImageReference({path:picture.path,alt:picture.alt,src:picture.src});
    if(action.id==='reveal') return onImageAction('已选择“在文件管理器中显示”（原型不启动外部应用）');
    try {
      if(action.id==='address') await navigator.clipboard.writeText(action.value);
      if(action.id==='copy') {
        const img=new window.Image();img.src=picture.src;await img.decode();
        const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
        canvas.getContext('2d').drawImage(img,0,0);
        const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
        if(!blob)throw new Error('图片转换失败');
        await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);
      }
      if(action.id==='download') {
        const a=document.createElement('a');a.href=picture.src;a.download='willyou-image-fixture.'+(picture.src.endsWith('.svg')?'svg':'png');a.click();
      }
      onImageAction(action.id==='download'?'已下载合成图片副本':action.id==='copy'?'已复制合成图片（PNG）':'已复制示例图片地址');
    } catch {onImageAction('图片操作失败：权限或图片解码不可用，请重试。');}
  };
  return <>
    <article className="fw-markdown fw-markdown-editable" ref={article} tabIndex={-1} aria-label="Markdown 文档编辑区">
      {blocks.map(b=>{
        if(editing && b.from>editing.from && b.from<editing.to)return null;
        if(editing?.from===b.from)return <div key={b.from} className="fw-md-edit-block">{editBlock({...b,to:editing.to,raw:text.slice(b.from,editing.to)})}</div>;
        const raw=b.raw.replace(/\r?\n$/,'');
        const attr={onClick:e=>begin(b,e),onFocus:e=>{if(e.target===e.currentTarget&&!readOnly)setEditing({from:b.from,to:b.to,line:b.line});},tabIndex:readOnly||b.type==='image'?-1:0,'data-md-line':b.line};
        if(b.type==='frontmatter') return <dl key={b.from} className="fw-md-frontmatter" {...attr}>{raw.split('\n').slice(1,-1).filter(Boolean).map((line,i)=><div key={i}><dt>{line.split(':')[0]}</dt><dd>{line.slice(line.indexOf(':')+1).trim()}</dd></div>)}</dl>;
        if(b.type==='heading'){const level=raw.match(/^#+/)[0].length;const Tag='h'+level;return <Tag key={b.from} {...attr}>{inline(raw.slice(level+1))}</Tag>;}
        if(b.type==='blank')return <div key={b.from} className="fw-paragraph-break" {...attr} aria-label={'空行 '+b.line}/>;
        if(b.type==='rule')return <div key={b.from} {...attr}><hr/></div>;
        if(b.type==='image'){
          const p=pictures.find(p=>p.id===b.from);
          return <button className="fw-md-image" data-md-image={p.id} key={b.from} title="打开嵌入图片" onClick={e=>openImage(p,e)} onContextMenu={e=>{e.preventDefault();origin.current=e.currentTarget;setContext({picture:p,x:e.clientX,y:e.clientY});}}><img src={p.src} alt={p.alt}/></button>;
        }
        if(b.type==='table'){
          const rows=raw.split('\n').filter((_,i)=>i!==1).map(r=>r.replace(/^\s*\||\|\s*$/g,'').split('|'));
          return <table key={b.from} {...attr}><tbody>{rows.map((r,i)=><tr key={i}>{r.map((c,j)=>i===0?<th key={j}>{inline(c.trim())}</th>:<td key={j}>{inline(c.trim())}</td>)}</tr>)}</tbody></table>;
        }
        if(b.type==='quote')return <blockquote key={b.from} {...attr}>{inline(raw.replace(/^>\s?/,''))}</blockquote>;
        if(b.type==='task')return <div className="fw-md-task" key={b.from} {...attr}><input type="checkbox" checked={/\[[xX]\]/.test(raw)} disabled={readOnly} aria-label={raw.replace(/^\s*[-*+] \[[ xX]\]\s*/, '')} onChange={e=>{const value=b.raw.replace(/\[[ xX]\]/,e.target.checked?'[x]':'[ ]');onEdit(replaceMarkdownBlock(text,b,value));}}/>{inline(raw.replace(/^\s*[-*+] \[[ xX]\]\s*/,''))}</div>;
        if(b.type==='list')return <p key={b.from} className="fw-bullet" {...attr}>{inline(raw)}</p>;
        if(b.type==='code'||b.type==='mermaid'||b.type==='math'){
          const body=raw.split('\n').slice(1,-1).join('\n');
          return <div key={b.from} className={'fw-md-fence '+(b.type==='math'?'fw-md-math':'')} {...attr}><small>{b.language||b.type}</small>{b.type==='mermaid'?<><div className="fw-md-mermaid" aria-label="Mermaid 图示"><span>需求</span><span>→</span><span>原型</span><span>→</span><span>验收</span></div><details onClick={e=>e.stopPropagation()}><summary>查看图表源码</summary><pre>{body}</pre></details><small>图示为合成示例；通用 Mermaid 渲染见技研接口。</small></>:<pre>{body}</pre>}</div>;
        }
        return <p key={b.from} {...attr}>{inline(raw)}</p>;
      })}
      {!text&&<button className="fw-md-empty" onClick={()=>{onEdit('\n');setEditing({from:0,to:1,line:1});}}>使用 Markdown 写作…</button>}
    </article>
    <div className="fw-md-fixture-tools"><button onClick={()=>setShowScenario(!showScenario)}>图片能力样例</button>{showScenario&&<select aria-label="图片能力场景" value={imageScenario} onChange={e=>setImageScenario(e.target.value)}><option value="local">本机静态图</option><option value="remote">远程静态图</option><option value="http">HTTP 地址</option><option value="gif">动画 GIF</option><option value="no-input">模型不接收图片</option><option value="fallback">新叠层不可用，退旧灯箱</option></select>}<button aria-label="复制 Markdown" onClick={async()=>{try{await navigator.clipboard.writeText(text);setCopied(true);}catch{onImageAction('复制失败');}}}>{copied?<Check size={13}/>:<Copy size={13}/>}</button></div>
    {context&&<ImageMenu context={context} onClose={()=>{setContext(null);origin.current?.focus();}} actions={imageMenuActions({src:imageScenario==='http'?'https://example.invalid/fixture.png':context.picture.original,localPath:context.picture.localPath,host:imageScenario==='remote'?'remote':'local',animated:imageScenario==='gif',canSelect:true,clipboard:typeof ClipboardItem!=='undefined'&&!!navigator.clipboard?.write})} onAction={action=>imageAction(action,context.picture)}/>}
    {active&&<ImageGallery initial={active} overlay={overlay&&imageScenario!=='fallback'} download={!(overlay&&imageScenario==='fallback')} onClose={()=>{setActive(null);origin.current?.focus({preventScroll:true});}} onDownload={p=>imageAction({id:'download'},p)}/>}
  </>;
}
function ImageMenu({context,actions,onAction,onClose}){
  const ref=useRef(null);
  useEffect(()=>{const el=ref.current;const rect=el.getBoundingClientRect();el.style.left=Math.max(8,Math.min(context.x,window.innerWidth-rect.width-8))+'px';el.style.top=Math.max(8,Math.min(context.y,window.innerHeight-rect.height-8))+'px';el.querySelector('button')?.focus({preventScroll:true});},[context]);
  return <><div className="fw-dismiss" onClick={onClose}/><div ref={ref} className="fw-menu fw-image-menu" role="menu" onKeyDown={e=>{e.stopPropagation();const all=[...ref.current.querySelectorAll('button')],i=all.indexOf(document.activeElement);if(e.key==='Escape')onClose();if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();all[e.key==='Home'?0:e.key==='End'?all.length-1:(i+(e.key==='ArrowDown'?1:-1)+all.length)%all.length]?.focus();}}}>{actions.map(a=><button role="menuitem" key={a.id} onClick={()=>onAction(a)}>{a.label}</button>)}</div></>;
}
function ImageGallery({initial,overlay,download,onClose,onDownload}){
  const [index,setIndex]=useState(initial.pictures.findIndex(p=>p.id===initial.picture.id)),[zoom,setZoom]=useState(1),[fit,setFit]=useState(1),[pan,setPan]=useState({x:0,y:0}),[failed,setFailed]=useState(false),[attempt,setAttempt]=useState(0),[dimensions,setDimensions]=useState({width:1024,height:1024});
  const view=useRef(null), image=useRef(null), pointers=useRef(new Map()),gesture=useRef(null),transform=useRef({zoom,pan});
  transform.current={zoom,pan}; const picture=initial.pictures[index];
  const reset=()=>{if(!view.current||!image.current)return;const next=fitImage(image.current.naturalWidth||1024,image.current.naturalHeight||1024,view.current.clientWidth-64,view.current.clientHeight-32);setFit(next);setZoom(next);setPan({x:0,y:0});pointers.current.clear();gesture.current=null;};
  useEffect(()=>{setFailed(false);reset();view.current?.focus();},[index]);
  useEffect(()=>{const el=view.current;const observer=new ResizeObserver(reset);observer.observe(el);const wheel=e=>{if(!e.ctrlKey)return;e.preventDefault();const {zoom:old,pan:p}=transform.current;const next=Math.min(5,Math.max(.1,old*Math.exp(-scaleWheelDelta(e.deltaY,e.deltaMode)*.002)));const r=el.getBoundingClientRect();setPan(anchoredImageZoom(old,next,p,{x:e.clientX-r.left-r.width/2,y:e.clientY-r.top-r.height/2}));setZoom(next);};el.addEventListener('wheel',wheel,{passive:false});return()=>{observer.disconnect();el.removeEventListener('wheel',wheel);};},[index]);
  const initializeGesture=()=>{const points=[...pointers.current.values()];gesture.current={...transform.current,points,distance:points.length===2?Math.hypot(points[0].x-points[1].x,points[0].y-points[1].y):0};};
  const pointerMove=e=>{if(!pointers.current.has(e.pointerId))return;pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});const points=[...pointers.current.values()],g=gesture.current;if(!g)return;if(points.length===1&&g.points.length===1)setPan({x:g.pan.x+points[0].x-g.points[0].x,y:g.pan.y+points[0].y-g.points[0].y});if(points.length===2&&g.distance){const next=Math.min(5,Math.max(.1,g.zoom*Math.hypot(points[0].x-points[1].x,points[0].y-points[1].y)/g.distance));const r=view.current.getBoundingClientRect(),p={x:(g.points[0].x+g.points[1].x)/2-r.left-r.width/2,y:(g.points[0].y+g.points[1].y)/2-r.top-r.height/2};const base=anchoredImageZoom(g.zoom,next,g.pan,p);setZoom(next);setPan({x:base.x+(points[0].x+points[1].x-g.points[0].x-g.points[1].x)/2,y:base.y+(points[0].y+points[1].y-g.points[0].y-g.points[1].y)/2});}};
  const up=e=>{pointers.current.delete(e.pointerId);initializeGesture();};
  const move=delta=>setIndex(i=>Math.max(0,Math.min(initial.pictures.length-1,i+delta)));
  return <div className={'fw-gallery '+(overlay?'fw-gallery-overlay':'fw-gallery-legacy')} role="dialog" aria-modal="true" aria-label={overlay?'图片只读叠层':'图片预览'} onKeyDown={e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();onClose();return;}if(e.isComposing||e.defaultPrevented||e.altKey||e.metaKey||e.ctrlKey||e.shiftKey||e.target.closest('input,textarea,select,[contenteditable=true],[role=menu],[role=slider],[role=grid],[role=tree]'))return;if(e.key==='ArrowLeft'){e.preventDefault();move(-1);}if(e.key==='ArrowRight'){e.preventDefault();move(1);}}}>
    <header><span>{picture.alt}</span><div>{download&&<button onClick={()=>onDownload(picture)}><Download size={16}/>{overlay?'保存':'下载'}</button>}<button aria-label="关闭图片预览" onClick={onClose}><X size={18}/></button></div></header>
    <div className="fw-gallery-viewport" tabIndex={0} ref={view} onPointerDown={e=>{if(e.button!==0)return;e.currentTarget.setPointerCapture(e.pointerId);pointers.current.set(e.pointerId,{x:e.clientX,y:e.clientY});initializeGesture();}} onPointerMove={pointerMove} onPointerUp={up} onPointerCancel={up}>
      {failed?<div className="fw-gallery-error"><p>无法加载图片</p><button onClick={()=>{setFailed(false);setAttempt(n=>n+1);}}>重试加载图片</button></div>:<img ref={image} key={picture.id+':'+attempt} src={picture.src} alt={picture.alt} referrerPolicy="no-referrer" draggable={false} onError={()=>setFailed(true)} onLoad={e=>{setDimensions({width:e.target.naturalWidth,height:e.target.naturalHeight});reset();}} style={{width:dimensions.width,height:dimensions.height,transform:`translate(${pan.x}px, ${pan.y}px) scale(${zoom})`}}/>}
    </div><footer><button aria-label="上一张图片" disabled={index===0} onClick={()=>move(-1)}><ArrowLeft size={17}/></button><button aria-label="缩小图片" disabled={zoom<=.1} onClick={()=>setZoom(stepImageZoom(zoom,-1,fit))}><ZoomOut size={17}/></button><button aria-label="重置图片适应缩放" onClick={reset}>{Math.round(zoom*100)}%</button><button aria-label="放大图片" disabled={zoom>=5} onClick={()=>setZoom(stepImageZoom(zoom,1,fit))}><ZoomIn size={17}/></button><button aria-label="下一张图片" disabled={index===initial.pictures.length-1} onClick={()=>move(1)}><ArrowRight size={17}/></button>{overlay&&<span>{index+1} / {initial.pictures.length}</span>}</footer>
  </div>;
}
