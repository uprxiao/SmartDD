// Independent interaction model for synthetic Markdown documents, not a CommonMark codec.
export function markdownBlocks(text) {
  const lines = text.match(/[^\n]*(?:\n|$)/g)?.filter(Boolean) || [''];
  const out = []; let offset = 0;
  for (let i = 0; i < lines.length;) {
    const start = i, from = offset, first = lines[i].replace(/\r?\n$/, '');
    let type = 'paragraph', language = '';
    if (i === 0 && first === '---') {
      type = 'frontmatter'; i++;
      while (i < lines.length && !/^---\s*$/.test(lines[i])) i++;
      if (i < lines.length) i++;
    } else if (/^\s*(`{3,}|~{3,})/.test(first)) {
      const [, fence, info] = first.match(/^\s*(`{3,}|~{3,})(.*)$/);
      language = info.trim(); type = language === 'mermaid' ? 'mermaid' : language === 'math' ? 'math' : 'code'; i++;
      while (i < lines.length && !lines[i].trim().startsWith(fence)) i++;
      if (i < lines.length) i++;
    } else if (first.trim() === '$$') {
      type = 'math'; i++; while (i < lines.length && lines[i].trim() !== '$$') i++; if (i < lines.length) i++;
    } else if (lines[i + 1] && /^\s*\|?\s*:?-{3,}/.test(lines[i + 1]) && first.includes('|')) {
      type = 'table'; i += 2; while (i < lines.length && lines[i].includes('|') && lines[i].trim()) i++;
    } else {
      type = /^#{1,6} /.test(first) ? 'heading' : /^>/.test(first) ? 'quote' : /^\s*[-*+] \[[ xX]\]/.test(first) ? 'task' : /^\s*(?:[-*+]|\d+\.) /.test(first) ? 'list' : /^\s*(?:---+|\*\*\*+|___+)\s*$/.test(first) ? 'rule' : /^!\[.*\]\(.*\)$/.test(first) ? 'image' : !first.trim() ? 'blank' : 'paragraph';
      i++;
    }
    const raw = lines.slice(start, i).join(''); offset += raw.length;
    out.push({ type, language, raw, from, to: offset, line: start + 1 });
  }
  return out;
}
export function replaceMarkdownBlock(text, block, value) {
  if (!block || text.slice(block.from, block.to) !== block.raw) return null;
  return text.slice(0, block.from) + value + text.slice(block.to);
}
export function resolveMarkdownPath(currentPath, href) {
  if (/^(?:[a-z][\w+.-]*:|\/\/|\\)/i.test(href)) return null;
  const parts = href.startsWith('/') ? [] : currentPath.split('/').slice(0, -1);
  for (const part of href.split(/[?#]/)[0].split('/')) {
    if (part === '..') { if (!parts.length) return null; parts.pop(); }
    else if (part && part !== '.') parts.push(part);
  }
  return parts.join('/');
}
export function imageMenuActions({ src = '', displaySrc = '', localPath, host = 'local', originHost = 'local', animated = false, canSelect = true, canCopy = true, clipboard = true }) {
  const address = [src, displaySrc].find(s => /^https?:\/\//i.test(s));
  return [
    { id: 'open', label: '在新标签打开图片' },
    ...(address ? [{ id: 'address', label: '复制图片地址', value: address }] : []),
    ...(!animated && canSelect ? [{ id: 'reference', label: '添加到当前任务' }] : []),
    ...(!animated && canCopy && clipboard ? [{ id: 'copy', label: '复制图片' }] : []),
    ...(localPath?.startsWith('/') && host === 'local' && originHost === host ? [{ id: 'reveal', label: '在文件管理器中显示' }] : []),
    { id: 'download', label: '下载副本' }
  ];
}
export const IMAGE_ZOOM_STEPS = [25, 33, 50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300, 400, 500];
export const fitImage = (width, height, viewportWidth, viewportHeight) => Math.min(1, Math.max(.01, Math.min(viewportWidth / width, viewportHeight / height)));
export function stepImageZoom(current, direction, fit = 1) {
  const values = [...new Set([...IMAGE_ZOOM_STEPS.map(v => v / 100), fit])].sort((a,b) => a-b);
  return direction > 0 ? values.find(v => v > current + .00001) ?? values.at(-1) : [...values].reverse().find(v => v < current - .00001) ?? values[0];
}
export const scaleWheelDelta = (delta, mode) => delta * (mode === 1 ? 16 : mode === 2 ? 800 : 1);
export function anchoredImageZoom(previous, next, pan, point) {
  return { x: point.x - (point.x - pan.x) * next / previous, y: point.y - (point.y - pan.y) * next / previous };
}
export function localFind(text, query, { caseSensitive = false, wholeWord = false, regex = false } = {}) {
  if (!query) return { matches: [], error: '' };
  try {
    const pattern = regex ? query : query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(wholeWord ? '\\b(?:' + pattern + ')\\b' : pattern, caseSensitive ? 'gu' : 'giu');
    const matches = [];
    for (const m of text.matchAll(re)) {
      matches.push({ from: m.index, to: m.index + m[0].length, value: m[0] });
      if (matches.length >= 10000) break;
    }
    return { matches, error: '' };
  } catch { return { matches: [], error: '正则表达式无效' }; }
}
