#!/usr/bin/env python3
"""Validate or render M9 case documents from the reviewed JSON source.

No application, browser, external resource or test fixture is executed.
Usage: python3 维护用例索引.py --check | --write
"""
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
INDEX = HERE / '用例覆盖索引.json'
CASES = HERE / '测试用例.md'
MAP = HERE / '需求与用例映射.md'


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', '<br>')


def dependency_caption(case):
    parts = []
    for key, label in [('decision_dependencies', '用户决策'),
                       ('engineering_dependencies', '工程依赖'),
                       ('evidence_dependencies', '证据／基线评审')]:
        if case.get(key):
            parts.append(label + '：' + '/'.join(case[key]))
    return '；'.join(parts)


def derive(data):
    coverage, parents = defaultdict(list), defaultdict(list)
    ids = set()
    requirements = (HERE.parent / '需求.md').read_text()
    known = {'M9-' + value for value in re.findall(r'\b(R\d{2}\.\d+)\b', requirements)}
    pages = set(re.findall(r'\| (P\d{2})\b', (HERE.parent / '原型/原型说明与变更.md').read_text()))
    for case in data['cases']:
        cid = case['id']
        assert cid not in ids, f'duplicate case: {cid}'
        ids.add(cid)
        assert re.fullmatch(r'M9-T-[A-Z]\d{2}', cid), cid
        assert case['group'] in data['groups'], cid
        assert re.fullmatch(rf'M9-T-{case["group"]}\d{{2}}', cid), cid
        for key in ('title', 'requirements', 'level', 'environments', 'data', 'steps', 'expected',
                    'source', 'prototype', 'prototype_pages', 'prototype_status', 'prototype_note', 'status'):
            assert case.get(key), f'{cid}: empty {key}'
        assert all(re.fullmatch(r'M9-R\d{2}\.\d+', req) for req in case['requirements']), f'{cid}: parent-only mapping'
        assert set(case['requirements']) <= known, f'{cid}: undefined requirements {set(case["requirements"]) - known}'
        assert set(case['prototype_pages']) <= pages, f'{cid}: undefined pages'
        for field in ('decision_dependencies', 'engineering_dependencies', 'evidence_dependencies'):
            assert set(case[field]) <= set(data['dependencies']), f'{cid}: undefined dependencies'
        assert set(case['decision_dependencies']) <= {'D01', 'D07'}, f'{cid}: engineering item labelled user decision'
        assert isinstance(case['evidence'], list) and isinstance(case['defects'], list), cid
        assert 'actual_result' in case, cid
        for req in case['requirements']:
            coverage[req].append(cid)
        for parent in sorted({req.split('.')[0] for req in case['requirements']}):
            parents[parent].append(cid)
    assert len(ids) == 417, 'Stable 417-case baseline changed; coordinate requirements/index first.'
    assert len(data['groups']) == 23
    if data['execution_status'] == 'not-executed':
        assert all(c['status'] == '未执行' and c['actual_result'] is None and not c['evidence'] and not c['defects']
                   for c in data['cases']), 'Execution metadata disagrees with case results.'
    data['case_count'] = len(ids)
    data['group_count'] = len(data['groups'])
    data['coverage'] = dict(sorted(coverage.items(), key=lambda p: tuple(map(int, p[0][4:].split('.')))))
    data['parent_coverage'] = dict(sorted(parents.items()))
    data['unmapped_requirements'] = sorted(known - set(coverage))
    for key, group in data['groups'].items():
        group['req'] = ','.join(sorted({req.split('.')[0] for c in data['cases'] if c['group'] == key for req in c['requirements']}))
    return data


def render_cases(data):
    preamble = CASES.read_text().split('## 3. ', 1)[0].rstrip()
    preamble = re.sub(r'版本：R3(?:\.1)?-20261017', '版本：' + data['version'], preamble)
    preamble = preamble.replace('M9-R01–R09](../需求.md)', 'M9-R01–R09 子需求](../需求.md)')
    paragraph = ('本版以 JSON 为逐条维护来源，`requirements` 精确关联 `Rxx.x`，`prototype_pages` 关联现有 P01–P18。'
                 '页面关联只表示入口与状态落点；实现边界、待决策项和逐条映射见[需求与用例映射](需求与用例映射.md)。'
                 '修改后运行 `python3 维护用例索引.py --write` 同步本文，再用 `--check` 检查；脚本不执行正式用例。')
    if paragraph not in preamble:
        preamble += '\n\n' + paragraph
    lines = [preamble, '']
    for section, (key, group) in enumerate(data['groups'].items(), 3):
        cases = sorted((c for c in data['cases'] if c['group'] == key), key=lambda c: c['id'])
        lines += [f'## {section}. {group["title"]}', '',
                  f'原型逻辑状态：`{group["prototype"]}`。共 {len(cases)} 条；公共前提见 §2，具体页面及尚缺状态逐条列明。', '',
                  '| 用例／子需求 | 层级·环境·数据 | 步骤 | 可判定预期与来源 | 原型入口／边界 | 状态 | 证据 |',
                  '| --- | --- | --- | --- | --- | --- | --- |']
        for c in cases:
            caption = dependency_caption(c)
            decision = '；' + caption if caption else ''
            values = [f'**{c["id"]} {c["title"]}**<br>' + '、'.join(c['requirements']),
                      c['level'] + '<br>' + '+'.join(c['environments']) + ' / ' + '+'.join(c['data']),
                      c['steps'], c['expected'] + '<br>依据：' + c['source'],
                      '/'.join(c['prototype_pages']) + '；' + c['prototype_status'] + decision,
                      c['status'], '；'.join(map(str, c['evidence'])) if c['evidence'] else '—']
            lines.append('| ' + ' | '.join(cell(v) for v in values) + ' |')
        lines += ['']
    lines += ['## 覆盖统计与准出', '',
              '当前共 **417 条用例／23 组**。保留原有稳定编号；R3.1 修正候选业务流程、保存/Office 保真预期并补逐条子需求和页面映射。正式用例仍全部未执行；参数化行须拆成子结果。统计为设计关联数量，不是通过率，也不证明子需求的所有分支均已覆盖。', '',
              '| 父需求 | 关联用例数 |', '| --- | --- |']
    lines += [f'| {key} | {len(ids)} |' for key, ids in data['parent_coverage'].items()]
    lines += ['', f'已建立 {len(data["coverage"])} 个子需求的用例关联；无关联子项：' + ('、'.join(data['unmapped_requirements']) or '无') + '。未收口的场景与决策见[映射中的缺口账](需求与用例映射.md#仍待收口的覆盖与设计问题)。', '',
              '准出以需求评审后的完整矩阵为准：每个纳入功能有安装 App 结果，核心 IO/保存/冲突/权限/PTY 失败项清零，视觉差异逐项处理或明确接受。原型、单元、集成、安装、跨平台、参考观察分别统计；未执行、受阻、待确认不能计为通过。正式用例未执行是开发前的正常状态，不能据此要求先完成生产验收；当前正式开发仍需需求/原型/方案一致且获批准。', '']
    return '\n'.join(lines)


def render_mapping(data):
    lines = ['# M9 需求、用例与原型映射', '',
             f'依据需求修订：**{data["version"]}**。本次是一致性整理；没有执行或改写任何正式验收结果。', '',
             '逐条检查 417 个稳定用例，将其实际步骤/预期关联到具体子需求和既有 P01–P18 页面。JSON 是唯一逐条维护来源；本文件与测试用例由 `维护用例索引.py --write` 生成。不得通过整组挂全部子需求或重复编号提高覆盖数字。', '',
             f'- {len(data["cases"])} 条用例／{len(data["groups"])} 组；{len(data["coverage"])} 个子需求有至少一条设计关联。',
             '- 全部正式用例仍未执行，实际结果为空，证据数组为空。',
             '- “有设计关联”不等于“所有分支完整覆盖”，也不等于原型已实现或验收通过。',
             '- `prototype` 保留原 PS 逻辑状态，`prototype_pages` 指向真实页面入口；未实现/未核验状态通过状态和备注明确列出。',
             '- R3 局部浏览器/隔离实验保持在原执行记录，未迁成正式用例通过。', '',
             '## 仍待收口的覆盖与设计问题', '',
             '以下是已有用例仍需确定条件/补足设计的部分，不通过删除用例消除缺口，也不要求开发前完成正式安装验收。', '',
             '只有 D01/D07 是用户产品／范围决策。D02–D06/B01 属于工程方案、实验或参数落实；D08 是证据边界与整体基线评审。这里引用需求 §7，不另造一套要求用户选择技术协议的清单。', '',
             '| 编号 | 性质 | 当前约束与待办 |', '| --- | --- | --- |']
    lines += [f'| {key} | {cell(data["dependency_kinds"][key])} | {cell(value)} |' for key, value in data['dependencies'].items()]
    lines += ['', '| 子需求／用例 | 当前覆盖边界与下一步 |', '| --- | --- |']
    for gap in data.get('coverage_gaps', []):
        lines.append('| ' + cell('、'.join(gap['requirements']) + '<br>' + '、'.join(gap['cases'])) + ' | ' + cell(gap['note']) + ' |')
    lines += ['', '## 子需求反向索引', '', '| 子需求 | 关联用例 |', '| --- | --- |']
    lines += [f'| {req} | ' + '、'.join(cid.removeprefix('M9-T-') for cid in ids) + ' |' for req, ids in data['coverage'].items()]
    lines += ['', '无关联子项：' + ('、'.join(data['unmapped_requirements']) or '无') + '。这是关联检查结果，不是完整功能覆盖证明。', '',
              '## 逐条原型与用例映射', '',
              '页面定义见[原型说明 P01–P18](../原型/原型说明与变更.md)。同一用例涉及多个页面时只列与具体步骤有关的入口；服务/平台行为没有可操作页面时标明未实现，不虚构一个已通过的 UI 状态。', '',
              '| 用例 | 子需求 | 原型入口 | 当前边界／依赖 |', '| --- | --- | --- | --- |']
    for c in sorted(data['cases'], key=lambda c: c['id']):
        details = c['prototype_status'] + '：' + c['prototype_note']
        caption = dependency_caption(c)
        if caption:
            details += ' ' + caption + '。'
        values = [c['id'] + ' ' + c['title'], '、'.join(c['requirements']), '/'.join(c['prototype_pages']), details]
        lines.append('| ' + ' | '.join(cell(v) for v in values) + ' |')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    choice = parser.add_mutually_exclusive_group(required=True)
    choice.add_argument('--check', action='store_true')
    choice.add_argument('--write', action='store_true')
    args = parser.parse_args()
    original = json.loads(INDEX.read_text())
    data = derive(json.loads(json.dumps(original)))
    rendered = {CASES: render_cases(data), MAP: render_mapping(data)}
    if args.write:
        INDEX.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
        for path, content in rendered.items():
            path.write_text(content)
        print(f'Wrote {len(data["cases"])} cases, {len(data["coverage"])} subrequirements; preserved case results/evidence.')
    else:
        assert data == original, 'Derived JSON coverage/count/group summaries are stale; run --write.'
        for path, content in rendered.items():
            assert path.exists() and path.read_text() == content, f'{path.name} is stale; run --write.'
        print(f'PASS: {len(data["cases"])} unique cases / {len(data["groups"])} groups; {len(data["coverage"])} valid subrequirements; Markdown/JSON/mapping consistent.')


if __name__ == '__main__':
    main()
