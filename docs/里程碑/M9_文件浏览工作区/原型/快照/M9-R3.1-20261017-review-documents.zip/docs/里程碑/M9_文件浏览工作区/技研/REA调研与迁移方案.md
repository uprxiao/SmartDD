# M9 / F22-A 文件工作区：技术方案 R3.1

更新：2026-10-17；依据需求 **R3.1-20261017**，为 R3 一致性修订，不新增范围、不代表已经批准。R3 的保存/监听/解析、Office/PDF 及业务适配实验保留；本修订统一终端候选路线、AFS 回读边界、Office 保真判据与工程待办，R1/R2 历史证据不重写。状态：**前期研究与设计；正式 App 未开发，本方案中的 API、表和状态机均为拟实现契约。** 用户当前授权包含研究、需求、原型、技研、用例及一致性修正，不包含正式功能开发或发布。文件模块可在现有 Electron/React 架构实现；Office 等复杂文档的等价呈现和写回仍须通过技术闸门。不能以待验证项删格式或将整个模块缩成只读预览。

产品范围以[需求](../需求.md)为准；[原型说明](../原型/原型说明与变更.md)和[测试用例](../验收/测试用例.md)共同约束交付。中央任务终端保持原有会话切换和运行机制。完整浏览器 F22-B、Git 提交/分支/暂存管理、F20 文档业务与 Codex 专有聊天能力不在 M9 内。根据本轮最新用户“纯文件全量”要求，文件状态图标、只读 blame、generated 过滤、文件 MCP viewer 和文件内 selection-edit 等条件能力纳入研究/原型/设计，不沿用早期一概排除 Git 状态的范围。

## 1. 基线与历史结论的修订

| 版本 | 证据与意义 | 本轮处理 |
| --- | --- | --- |
| F22 初查，2026-10-16 | [文件实现证据](../调研/Codex文件工作区实现证据.md)、[类型路由补查](../调研/文件类型路由补充证据.md)、[历史证据索引](../../../design/f22/证据索引.md) | 保留原始哈希、REA evidence 与静态来源；旧“只读先行”只能是实施阶段，不能作为最终缩减范围 |
| M9 R1，2026-10-17 | [类型与编辑状态全集](../调研/M9_文件类型与编辑状态全集.md)、[项目会话与文件生命周期](../调研/M9_项目会话与文件生命周期.md)；树/搜索专项见[调研目录](../调研/README.md) | 替换旧技术草图，明确 DTO、安全边界、生命周期、选型和开工验证项 |
| M9 R2 独立实验，2026-10-17 | [脚本与运行记录](实验/README.md)、[迁移决策](实验/实验结论与迁移决策.md) | 真实文件操作、独立进程竞争/监控、三类 Office 转换与 UNO 命令编辑；仅合成输入，不等于正式 App 或 Codex 动态验收 |
| M9 R3 独立实验，2026-10-17 | [实验结论 §8](实验/实验结论与迁移决策.md#8-r3-补充实验保存安全监听恢复与解析成本m9-gap-08--gap-09)：目录 fd 锚定与交换式提交、监听恢复策略、Markdown 引擎耗时/Worker 取消与崩溃 | 仅合成输入；macOS arm64；Windows/Linux 未验；不等于正式 App |
| M9 R3.1 一致性修订，2026-10-17 | [需求 §7](../需求.md)及现有 R3 实验/原型事实 | 旧 selection-edit 模型直连、react-markdown 候选不再是现行路线；不新增实验结果或开发授权 |
| SmartDD 当前源码 | HEAD `d75bbaa81e924d1f9a9509ae1d068d69d4ea8ec7`、package `0.0.5`，读取当前工作区 | 已有 `createScopedRPCController`，旧“RPC 丢失 sender，必须整体重构”的判断已过时 |
| Yoda 当前源码 | HEAD `960fd3224508edc52fb7e99d9e8f8cf1723ad683`、package `0.20.3`、Apache-2.0 | 参考本地源码，抽取文件能力；只抽取文件与只读 Git 元数据；不搬提交/分支/暂存、聊天/worktree/浏览器业务 |

逆向目标是名称为 ChatGPT 的 Codex 壳：`com.openai.codex`，版本 `26.1007.30912` build `20156`，ASAR SHA-256 `75e397e2280dde93b70a85aa926f4282c728eacc84dfeb15ba7fb6ddd84628af`。原包无 source map。本轮 REA 分析没有执行目标 bundle，没有对 Codex 做动态交互验收。语句存在、静态调用关联、迁移建议和未知行为必须区分；详细 evidence/字节定位在各调研报告的 JSON，原始片段留 ignored `release/f22-research/`、`release/m9-research/`。

最新授权边界见[执行记录 M9-D14](../验收/执行与缺陷记录.md)：用户已要求不再操作或查看 Codex。本方案仅引用已有归档来源，后续利用归档或用户独立提供的材料；旧动态取证计划不再执行，未知保留未知。

## 2. 迁移架构与源码落点

```mermaid
flowchart LR
  Task[现有 TaskView / PTY] --- Workbench[ResourceWorkbench]
  Workbench --> Tabs[FileTabsStore]
  Workbench --> Tree[Tree / Search]
  Tabs --> Models[DocumentModel / ViewerRegistry]
  Tree --> RPC[files scoped RPC]
  Models --> RPC
  RPC --> Roots[RootLeaseRegistry]
  Roots --> FS[FileService / LocalProvider]
  FS --> Watch[WatchRegistry]
  FS --> Parse[Parser workers / PreviewHost]
  Models --> State[Checkpoint / DraftService]
  Watch --> Event[owner-scoped events]
  Event --> Workbench
```

| 现有入口 | 可复用内容 | 拟新增/适配 |
| --- | --- | --- |
| `src/main/db/schema.ts:62,170`，`src/main/core/tasks/task-service.ts:157` | projectDirs、多目录、任务 cwd 快照 | `RootResolver` 通过项目/任务服务确定目录；项目改址不悄悄替换历史任务 cwd |
| `src/shared/ipc/rpc.ts:11,33`，`src/main/core/projects/transfer-controller.ts:11` | sender-aware controller、窗口导航/销毁清理样例 | `src/main/core/files/controller.ts`；入参 Zod 校验、只接受 main 签发 lease；不复用项目导入 token |
| `src/renderer/lib/layout/workspace.tsx:71,81` | TaskView keepMounted | 旁置 `features/workspace-files/ResourceWorkbench`，文件 tabs 独立于 TasksStore |
| `src/renderer/views/task-view.tsx:155,208,221` | ResizeObserver、0×0保护、ptyId实例 | 分栏只 fit/resize，按帧去重；可见性变化不抢文件搜索/编辑器焦点 |
| `src/renderer/core/tasks-store.ts:140` | 任务关闭会 kill session | 文件 close 不调用 task close；停 CLI 不等于释放文件草稿 |
| `src/main/core/settings/settings-service.ts:17` | SQLite/schema/写队列模式 | `FileWorkspaceStateService` 专用 checkpoint/draft 表，避免任意动态 key 绕过 settings schema |
| `src/renderer/index.html:5` | 当前 CSP | worker、本地 asset、隔离预览分别配置；不在主 renderer 中执行文档脚本 |

新模块建议：`shared/workspace-files.ts`（DTO/schema/事件）、`main/core/files/{controller,root-resolver,file-service,watch-registry,search-service,document-session-service,state-service}.ts`、`renderer/features/workspace-files/{stores,tree,tabs,viewers,editor}`。这是一组职责边界，开发时可按实际体量拆分，不要求照抄文件名或生成空壳。

## 3. 身份、授权和基础 DTO

以下类型是设计规范，正式开发需要运行期 schema 和测试，不能把 TypeScript 当授权。

```ts
type RootRequest =
  | { kind: 'project-dir'; projectId: string; dirId: string }
  | { kind: 'task-cwd'; taskId: string };
type WorkspaceScope =
  | { kind: 'task'; taskId: string }
  | { kind: 'project'; projectId: string };
type RootLease = {
  leaseId: string;                 // main随机生成，仅在当前window/main生命周期有效
  generation: number;              // 根身份/授权变化即失效
  rootIdentity: string;            // main规范化身份，供去重；不能直接当授权
  hostIdentity: string;
  source: RootRequest;
  displayName: string;
  displayPath: string;
  capabilities: {
    read: boolean; writeText: boolean; writeBinary: boolean;
    searchNames: boolean; searchContent: boolean;
    watch: 'native' | 'poll' | 'none'; atomicReplace: boolean;
    pathCase: 'sensitive' | 'insensitive' | 'unknown';
  };
};
type RequestContext = { leaseId: string; generation: number; requestId: string };
type FileRef = { relativePath: string }; // POSIX化相对路径；规范化/边界由main复核
// revision是opaque比较令牌；实现可包含stat+hash，不能由renderer构造可信版本。
type Revision = string;
type FileStat = {
  fileId: string; relativePath: string; kind: 'file'|'directory'|'symlink';
  sizeBytes: number; mtimeMs: number; revision: Revision;
  readable: boolean; writable: boolean; linkTargetWithinRoot?: boolean;
};
type FileFailure = {
  code: FileErrorCode; message: string; retryable: boolean;
  requestId?: string; opId?: string; currentRevision?: Revision;
};
type Reply<T> = { ok: true; value: T } | { ok: false; error: FileFailure };
```

`relativePath=''` 表示根目录；不接受 NUL、绝对路径、协议 URL、驱动器/UNC 注入，`..` 不得越界。允许合法中文/空格/点文件；不能仅凭 replace/字符串 startsWith 判断安全。fileId由main生成，使用 host+canonical root+规范化相对路径；同名不合并，同真实根别名可共享模型。大小写/Unicode按实际文件系统语义处理，不全局 lowercase。

lease在main保存 `{senderWebContentsId,frame,source,canonicalRoot,rootIdentity,generation,createdAt}`，renderer不能指定owner。每次调用核对主frame、可信应用文档、窗口未销毁、lease属于该sender、generation仍有效、项目/任务仍存在且目录来源未被重定向。根被删/改址/撤销、窗口导航/销毁即取消请求、撤销资源URL、停止该owner订阅。持久化lease禁止跨重启复用。

读取前 `realpath(root/target)` containment；写入前验证目标/父目录、拒绝根外symlink；操作时再次核对根/目标身份，尽量使用已打开的文件描述符和平台可用的no-follow能力。**realpath+再检查不是消除全部TOCTOU的证明**；跨平台无法等价时，返回明确能力/错误并在安全探针中界定，不能给不受限文件路径兜底。

R2 已在真实临时文件中复现：父目录在检查后被替换为 symlink 时，仅最终组件 `O_NOFOLLOW` 仍可写出根；同路径新建根可由 dev/ino 检查拦下。正式可写 Provider 必须补平台目录描述符/句柄锚定策略及相同攻击重放，不能将本节的 JS 校验顺序当作已经完成防逃逸。[实验 FS01–FS03、FS09](实验/实验结论与迁移决策.md#2-文件系统实测不是仅检查自写函数)

## 4. 文件服务方法与返回契约

所有方法返回 `Reply`；涉及lease的方法默认附带 `RequestContext`。表中只省略重复的 `ctx`，具体实现不得省略其校验。大结果通过有界分页/事件/资源句柄传递，不一次性把全项目或大二进制JSON送IPC。

| 方法 | 输入 | 成功返回/事件 | 约束 |
| --- | --- | --- | --- |
| `openRoot` | `RootRequest` | `RootLease` | 仅已登记目录/任务cwd；无任意绝对路径入参 |
| `closeRoot` | leaseId,generation | `{closed:true}` | 幂等；释放本owner引用，不关闭其它窗口共享底层watch |
| `stat` | FileRef，`refresh:boolean` | FileStat | 缺失/无权限区分；`refresh`跳缓存 |
| `listDirectory` | relativeDir,includeHidden,cursor?,pageSize | `{entries,nextCursor,truncated,reason?,snapshotRevision}` | 单层懒加载；分页cursor绑定root/dir/revision，不能跨目录复用 |
| `readText` | FileRef,`maxBytes`（服务端限额内） | `{content,revision,sizeBytes,encoding,bom,eol,readOnly,truncated:false}` | 全量可编辑文本不允许truncated；编码不明返回状态，不能误写成UTF-8 |
| `readTextPrefix` | FileRef,maxBytes | `{content,revision,totalBytes,truncated:true,readOnly:true}` | 大文件查看专用；不可拿前缀调用保存 |
| `sniff` | FileRef | `{contentKind,mime?,extension,rendererCandidates,reason}` | 后缀+有限magic/text样本；解析失败不是空文件 |
| `acquireAsset` | FileRef,revision?,purpose:'image'|'media'|'pdf'|'document',rangeSupported | `{assetId,url,mime,sizeBytes,revision,expiresAt}` | owner+lease绑定，不接受调用者自定URL/MIME；URL不持久化 |
| `releaseAsset` | assetId | `{released:true}` | 引用归零撤销；先销毁消费者再撤URL |
| `writeText` | FileRef,baseRevision,content,encoding,bom,eol,opId,editVersion | `{outcome:'saved',revision,editVersion}`或`{outcome:'conflict',currentRevision}` | 不接受截断模型；同文件串行；opId重试返回原结果，内容不同复用opId报错 |
| `writeBinary` | FileRef,baseRevision,uploadId,opId | saved/conflict+revision | 上传必须受控且完整；仅当前viewer声明可写；禁止当作任意文件写接口 |
| `beginUpload/appendUpload/finishUpload/abortUpload` | purpose,maxBytes→uploadId；chunk sequence+ArrayBuffer；final SHA-256 | `{uploadId}`、ack、`{sha256,bytes}` | main限额/顺序/owner；上传不是写盘，finish不等于save；dispose删除临时文件 |
| `cancel` | requestId | `{state:'cancel-requested'\|'already-finished'}` | 只取消本owner；写入在commit前可取消，commit后不能谎称未写 |
| `getOperation` | opId | `{state:'running'\|'saved'\|'conflict'\|'failed'\|'unknown',result?}` | 超时后查询，不盲目再次写；重启未知时重读revision核对 |
| `revealInSystem/openExternal` | FileRef,targetId? | `{opened:true}` | target来自main允许列表；只打开已验证资源，不拼shell命令 |
| `copyPath` | FileRef,format:'relative'|'absolute' | `{text}` | 返回授权根内路径；写剪贴板可在现有受信任UI动作完成 |
| `exportCopy` | FileRef或当前已验证draftId | `{cancelled:boolean,displayPath?}` | main原生保存框；明确另存副本，不等于写回原文件 |

树的新增/重命名/删除/移动在当前已观察 Codex host 中没有绑定入口（第三方树库具备能力不等于产品启用）。M9不凭库能力增加破坏性文件管理RPC；但**外部**删改重命名必须被监控并表现为状态变化。

错误码固定：`INVALID_ARGUMENT`、`UNTRUSTED_SENDER`、`LEASE_EXPIRED`、`ROOT_CHANGED`、`ROOT_MISSING`、`PATH_ESCAPE`、`SYMLINK_OUTSIDE_ROOT`、`NOT_FOUND`、`NOT_A_FILE`、`NOT_A_DIRECTORY`、`PERMISSION_DENIED`、`READ_ONLY`、`UNSUPPORTED_TYPE`、`UNSUPPORTED_ENCODING`、`TOO_LARGE`、`PARSE_FAILED`、`CANCELLED`、`TIMEOUT`、`IO_ERROR`、`DISK_FULL`、`CONFLICT`、`OP_ID_REUSED`、`HOST_UNAVAILABLE`、`CAPABILITY_UNAVAILABLE`、`WORKER_CRASHED`。错误对象结构化过IPC，不能依赖Error自定义属性序列化；message不暴露凭据/内部堆栈。

## 5. 搜索与监控契约

### 5.1 搜索

Codex文件名搜索为sessionStart/update/stop，兼容退回单次；全文搜索是另一条流。SmartDD在UI中区分名称过滤和全文搜索，不能只过滤已经展开的树节点就宣称覆盖项目。

```ts
type SearchStart = {
  roots: Array<{leaseId:string; generation:number}>;
  mode: 'names'|'content'; query: string; queryVersion: number;
  includeHidden: boolean; excludePolicy: 'reference-default'|'all';
  fileMask?: string; maxResults: number;
};
type SearchEvent = {
  sessionId: string; queryVersion: number; sequence: number;
  state: 'batch'|'complete'|'cancelled'|'error';
  hits: Array<{leaseId:string; generation:number; fileId:string;
    relativePath:string; name:string; score?:number;
    line?:number; column?:number; preview?:string}>;
  truncated: boolean; reason?: 'result-limit'|'time-budget'|'file-limit';
  error?: FileFailure;
};
```

`search.start(input)→{sessionId}`、`search.update(sessionId,query,queryVersion)`、`search.stop(sessionId)`；名称模式用worker异步遍历/缓存索引+可解释fuzzy排序，目录改变使相应索引失效。仅读取文件名无需解析文件内容；全文只对可读文本进行流式扫描，必须有每文件字节/总时间/结果预算。R1优先复用Yoda遍历与取消结构；名称遍历不依赖Git，文件状态/只读blame/generated由独立只读元数据provider提供。无需新增rg二进制即可实现基线；若实测达不到性能预算，再比较官方ripgrep打包路线并单列许可/跨平台成本，不能假定用户已安装rg。

R1a 树专项已补齐 native 候选检索与客户端排序的边界：客户端 `ZXc` 丢弃 native score/indices，`QXc` 对 label 调用本地 fragment matcher，零分候选仍保留；同分按 JS label 字典序，再保留原 index。路径 query 还有 basename 前缀 fallback。正式实现必须把候选召回与客户端兼容排序分开，按[目录搜索全集 §11](../调研/M9_目录搜索与视觉交互全集.md#11-文件名模糊评分已重建的客户端与原生边界)的行为固定 fixture 验证；不能以普通 substring 或直接 native score 声称已对齐。私有 matcher 不直接搬入生产。

名称搜索初始排除表按Codex参考（.git/.hg/.next/.pnpm-store/.svn/.turbo/.yarn/build/coverage/dist/node_modules），普通树仍可展示这些目录。过滤策略是状态字段，不能伪装成所有文件的完整结果。前端以sessionId+queryVersion+generation拒绝乱序；输入法组合期间不提交中间字符；停止后事件丢弃。所有budget触顶显式truncated，不能悄悄少结果。

### 5.2 Watch

`watch.subscribe(ctx,{consumerId,paths,recursivePurpose:'expanded-directories'|'open-files'})→{watchId,sequence,coverage}`；`watch.update(watchId,paths)`；`watch.unsubscribe(watchId)`。consumerId只在owner内部标记用途，不能冒充另一窗口owner。

事件：`{watchId,leaseId,generation,sequence,events:[{type:'created'|'changed'|'deleted'|'renamed'|'unknown',relativePath,oldRelativePath?,revision?,opId?}],resyncRequired,rootState?:'ready'|'missing'|'changed'}`。底层只报告删/建时不得伪造确定的rename；同名新文件通过file identity/revision更新。丢事件、队列洪峰、后端不支持递归或断线恢复均可要求resync。

共享registry按host+canonicalRoot持有原生watch；消费者的路径并集决定关注范围。复用Yoda `@parcel/watcher` debounce/backpressure和late-subscribe cleanup，改为sender-bound lease。流程先建立watch→取目录/文件快照→核对sequence变化→必要时补扫；不能在扫描之后才开始订阅而漏掉间隙。自己的保存通过opId/revision匹配，不能无条件屏蔽5秒的其它程序修改。引用归零释放；启动promise迟到仍须unsubscribe。

R2 原生目录 `fs.watch` 在获准本机执行时可用，受限进程未收到事件；原子替换后的单文件 inode watch 则漏掉新 inode 的后续编辑。有界快照 polling 已在受限环境发现编辑/替换/新建。正式方案因此使用父目录订阅、revision 重新读取、覆盖/健康声明和预算化 polling，不能依赖一次 file watch 永久有效；`@parcel/watcher` 尚未在当前项目安装或打包验证。[实验 FS10–FS12](实验/实验结论与迁移决策.md#2-文件系统实测不是仅检查自写函数)

**R3 监听恢复策略（已由原型验证，见实验 §8.2）：** `WatchGuard` 订阅父目录，事件只触发 stat 快照重扫并与上一快照比较；对外声明 `coverage: native|poll|none` 与 `resyncRequired`。事件数超过阈值（实验取 50/500）标记 resync；原生创建失败或运行期 error 时降级到有界轮询；快照读取失败（如 EACCES）记录错误并保持降级，下一次成功后自动补扫；`stop()` 同时关闭 watcher、事件去抖定时器和轮询定时器。实验中 3000 个文件只收到 2889 个事件，因此逐事件记账不可取。轮询只扫已展开目录与已打开文件并退避；2000 文件 stat 快照 p95 10.4ms 只是测量，不是已批准预算。`@parcel/watcher` 的锁版本与安装包原生加载仍须验证。

## 6. 文档、保存与冲突状态

文件内容状态与view状态分离：`loading|ready|dirty|saving|conflict|missing|unreadable|too-large|unsupported|parse-error`；另有`readOnlyReason`、`saveError`、`pendingExternalChange`，避免一枚status同时承担多个含义。模型保留 `{baseText,localText,baseRevision,editVersion,lastSavedEditVersion,encoding,eol,bom}`。

- 同一文件写入串行，写请求快照editVersion。成功只更新对应base；若用户在等待期间继续输入，当前内容仍dirty，再次排保存。old request不得把新文本替换成请求时文本。
- 手动保存与3秒自动保存共用saveUntilClean；dirty关闭、Markdown/源码模式切换先等当前保存。失败保留buffer；关闭时继续查看/放弃修改，明确确认后才清草稿。此流程对齐已观察Codex文本分支；自动保存数值仍在原型/实测中核对。
- mtime只是提示；main生成强revision时读取内容hash，按canonical file串行执行preflight→临时同目录写→必要flush→复核目标→替换→返回revision。保存现有文件权限等元数据需保留。原子替换防半写与外部程序并发CAS不是同一保证，仍测试最后检查窗口。
- 外部变更区分 `disk==base`、`disk==local`、`local==base`、三者各异。clean可按viewer规则重载；dirty保留local/disk/base并暂停autosave。使用“保留我的修改/使用磁盘版本/继续编辑”表达结果，不固定把Codex Accept译为接受外部版本。
- `CONFLICT`之后没有无条件forceWrite通道。用户明确保留本地时先取得最新revision并确认将覆盖的磁盘版本，再带该revision保存；版本又变化则再次冲突。
- 被删文件进入missing并保留dirty。不能默认创建同路径覆盖新身份；恢复写入需明确“保存副本/重新建立”的产品规则；本轮不借此扩展任意create功能。
- 编码：UTF-8与已识别BOM/EOL保持；无法可靠解码时只读/错误并可外开。不能无提示改写GBK/UTF-16；是否扩充编码器在fixture结果基础上确认。

文本阈值对标 ≤10MiB编辑、(10,20]MiB只读、>20MiB拒绝编辑器；review、媒体、artifact有各自阈值，不混为一个max。服务端和parser在真实读取/解压后复核，不只相信metadata。

R2 已证相同 mtime/size 可以包含不同内容，因此 revision 对可编辑基线加入 hash；同目录 atomic rename 的独立读进程观察到完整旧/新内容，未见半写。但外部程序在最后校验与 rename 之间写入仍被覆盖，原子替换不等于系统级 CAS。应用内串行/opId、跨程序协调与剩余竞争边界分别验收，不能宣称仅 hash+rename 消除了外部并发风险。[实验 FS04–FS08](实验/实验结论与迁移决策.md#2-文件系统实测不是仅检查自写函数)

**R3 保存提交方案（已由原型验证，见实验 §8.1）：** 可写保存交给 native broker（N-API 或独立子进程），不再在 Node 里用路径字符串提交。流程：从已授权根 fd 逐级 `openat(O_DIRECTORY|O_NOFOLLOW)` 持有目录 fd → 同目录 `O_EXCL` 创建临时文件、写入、`fsync`、复制原 mode → `renameatx_np(RENAME_SWAP)`（Linux 为 `renameat2(RENAME_EXCHANGE)`，**未验证**）与目标交换 → 对被换下的旧 inode 重算 hash，与基线不符则换回并返回 conflict，相符则删除临时文件 → 提交后复核根内路径身份并回读内容。这消除了 FS09（父目录被换成 symlink 后写入落在原目录，不越根）以及 FS08 中“已持有旧 fd 的外部写入被静默覆盖”。加上“提交后回读”后，交换后、回读前按路径新写入的进程被检测为冲突（实验 AFS07，不还原对方内容、保留本地草稿）。**仍不能消除**：回读结束之后的写入（实验 AFS10），那相当于保存后的新外改，只能由监听发现。因此 UI/文档只承诺“检测并保留两版”的范围，不承诺系统级无丢失；不保证 ACL/xattr/owner/目录 fsync。Windows 没有等价调用，需要另行设计（例如 `ReplaceFile`/句柄锚定）并重放同样的攻击样本。

## 7. 标签、checkpoint、草稿与终端共存

### 7.1 标签模型

```ts
type FileTab = {
  tabId:string; contentInstanceId:string; fileId:string;
  rootSource:RootRequest; relativePath:string;
  isPreview:boolean; rendererId:string; mode:'rich'|'source';
  viewState:{scrollTop:number; cursor?:{line:number;column:number};
    page?:number; sheet?:string; zoom?:number; wrap?:boolean};
};
type WorkspaceCheckpoint = {
  schemaVersion:1; scope:WorkspaceScope; revision:number;
  tabs:Array<Omit<FileTab,'contentInstanceId'>>;
  order:string[]; activeTabId:string|null;
  tree:{activeRootSource:RootRequest|null;
    roots:Record<string,{rootSource:RootRequest;expandedPaths:string[];
      selectedPath:string|null;scrollTop:number;searchQuery:string}>};
  layout:{panelOpen:boolean;panelRatio:number;treeOpen:boolean;
    treeRatio:number;fullWidth:boolean};
};
```

树 `roots` 的持久键由 host+规范化根来源组成，不使用临时 lease；切根分别恢复展开/选中/滚动/query，旧 root 不可用时保留状态和错误占位。

单scope最多一个preview；固定tab不降级；dirty preview在替换前固定，保留当前修改。双击固定、同fileId复用、重排保tabId；contentInstanceId在内容替换时更新。异步close/save/load/restore完成必须核对scope/generation/contentInstanceId。关闭后选相邻项/打开来源，最后关闭恢复终端或原焦点；恢复栈存route+index+panel，最多25条是参考基线。

scope按task独立；项目页单独scope。底层同fileId模型可以共享，但一个buffer的所有视图必须看到同dirty/revision，不能各自独立autosave互相覆盖；若当前实现先按scope隔离，则另scope外部变更必须进入同样冲突规则。**R2 默认选择同窗口共享 DocumentRegistry、跨窗口独立 buffer 并通过 main revision 解决竞争。** task/root 的树、tab、定位独立；共享模型按窗口内 documentInstanceId 持有一份 draft，scope 只持引用，不能多个 task 对同一模型各自 autosave。若变更该取舍，先更新 DTO/草稿归属与用例，不混用身份。

checkpoint只存固定tab，preview不恢复；rootSource持久化、lease不持久化。恢复依次openRoot→stat→建tab→还原有效视图；不可用root/file保留“标签不可用”可重试占位，不静默删除。用户在异步恢复期间手动选择时不被旧checkpoint抢回。

### 7.2 持久化方法

`workspaceState.load(scope)→checkpoint|null`；`workspaceState.save(scope,expectedRevision,checkpoint,opId)→{revision}`；`workspaceState.delete(scope,expectedRevision)`（仅工作区布局，不删除项目文件）。main按scope序列化，多窗口expectedRevision失败需merge或重读，不last-writer静默丢标签。

`draft.put({documentInstanceId,scopeRefs,fileId,rootSource,relativePath,baseRevision,baseTextHash,localText,encoding,bom,eol,editVersion,opId})→{draftId,revision}`；`draft.attachScope(draftId,scope)`；`draft.detachScope(draftId,scope)`；`draft.list(scope)`；`draft.read(draftId)`；`draft.delete(draftId,expectedRevision)`。草稿为SmartDD设计增强，Codex本轮只证实tab state内存快照，未证实跨重启落盘。沿用500ms节流候选、可见失败状态与独立容量配额；配额数值须以样本测量冻结，满额或写入失败时保留内存修改并明确提示，不淘汰 dirty 草稿。关闭窗口前尽力flush但不能把unload异步当可靠唯一持久化。草稿包含项目源码，仅存应用本地userData；不得同步/导入导出到项目包或记录日志正文。编码/BOM/EOL随buffer和草稿保留；只有可往返的已识别编码可写，不可识别或不能无损编码时只读并解释，禁止静默转UTF-8。

拟新增SQLite表：`file_workspace_checkpoints(scope_key PK,schema_version,revision,json,updated_at)`；`file_drafts(draft_id PK,document_instance_id,file_id,root_source_json,relative_path,base_revision,content_blob,encoding,eol,bom,edit_version,revision,updated_at)`；`file_draft_scope_refs(draft_id,scope_key,PRIMARY KEY(draft_id,scope_key))`。删除某个 scope 仅解除引用；最后引用释放也不能在未明确放弃时删除 dirty 草稿。migration先在临时DB验证，未批准开发时不生成正式迁移文件。

### 7.3 PTY不变量

保持TaskView和ptyId key；文件开合、换tab、切模式不spawn/kill CLI。布局拖动按frame fit并跳过0×0/相同rows+cols。隐藏终端不销毁会话；文件搜索、编辑器、菜单和关闭确认获得焦点后，TaskTerminal的visible effect不能抢回。任务被删除时先处理该scope dirty提示/草稿归属，再撤lease；不把关闭文件当停止任务。

## 8. 格式实现矩阵与解析边界

[调研类型全集](../调研/M9_文件类型与编辑状态全集.md) F01–F22 是完整证据集合；每类必须在需求/测试矩阵中有状态，不能只选容易的六类。下表同步到 R3.1 当前候选：原型已使用 Markdown/PDF/高亮依赖，LSP 依赖仅用于仓库外实验，均不表示生产已接入；LibreOffice 基础探针与复杂保真/打包待验分别记录。

| 类型 | 实现路线 | 写入/边界 |
| --- | --- | --- |
| 文本/345语言映射 | 本地打包Monaco；文件名/复合后缀/内容探测统一ViewerRegistry；Markdown可使用独立rich视图 | 语言映射不等于语言服务器/编译支持；完整文本保存策略见§6 |
| Markdown/mdx | R3 原型采用 markdown-it＋KaTeX＋Mermaid＋js-yaml；源码与rich共享权威source，见§8.3；R1/R2 react-markdown候选已被替代 | 原始HTML转义、不执行MDX/JS；模式切换先保存/检查实例；图片相对路径走受限asset。整块编辑仍未达到参考选区/装饰语义，正式编辑适配方案须补实验，不把渲染库当编辑器等价证明 |
| 图片/AVIF/BMP/GIF/ICO/JPEG/PNG/WebP | 普通文件入口为 img/受限 asset 协议、object-contain/加载失败，不加专用 zoom；Markdown 嵌图画廊另按条件提供缩放/导航/菜单；SVG以img呈现并可看源码 | SVG不注入主DOM；TIFF按参考明确unsupported，不能伪装图片加载成功 |
| PDF | PDF.js 本地 worker；artifact 连续页 canvas/text/link 层、缩略页导航/条件展开与 dock、Zoom/Fit/Ctrl+wheel；review fallback 独立单页 canvas+prev/next | renderForms=false；不增参考没有的 search/rotate/print/页码输入/独立加减按钮。签名编辑未证；按当前候选保持30%–800% clamp、25%预设实际30%、Fit≤100%。Yoda embed不足以替代全交互 |
| CSV/TSV | worker解析为虚拟表格，源文本仍可查看/编辑；明确separator/quote/newline | 首选Papa Parse候选；保留字符串精度和格式，不自行执行公式；表格编辑回源须独立round-trip验证 |
| Notebook ipynb | schema验证code/markdown/raw cell，输出按参考MIME优先级；Markdown与代码高亮走§8.4；JSON/Vega仅源码 | HTML output iframe sandbox=""禁脚本，不能运行 cell；外层cell默认展开，仅非空source且descriptionMarkdown.trim()非空才有默认折叠的内部Code，是否有output不控制此分支；Copy code可用，无Notebook专用编辑/查找/缩放/换行开关，不能把Run计数变执行入口 |
| 音频/视频 | Chromium media 元素+range asset；audio 自定义 play/seek/time+条件copy/save，无可见volume；video 下方自定义音量/mute/八档speed/PiP/fullscreen/另存 | 后缀与真实 codec、条件能力分别验；128MiB 是某 binary-read 参数，本地 protocol 可跳过该查询，不能当所有媒体的统一限制 |
| HTML源码 | 文本路径 | 不依赖BrowserService |
| HTML文档预览 | 独立DocumentPreviewHost，隔离origin/session，无Node/preload能力；受限本地资源映射 | 与Notebook禁脚本输出不同；需要脚本的文件以可执行文档子模式和独立能力策略处理，禁任意网络/文件/弹窗；不得靠宽松iframe+同源替代。不提供地址栏/浏览历史/导航浏览器 |
| TeX | 源码可编辑；编译worker/受控宿主产出PDF再走PDF viewer | 不调用任意用户shell、不自动下载TeX；外部工具/资源/网络策略及平台安装成本在A0验证。编译不可用有明确状态，完整目标保持待验 |
| DOCX | docx-preview候选富预览；复杂排版与字体另用隔离Office引擎对比 | 预览库不提供等价写回；DOCX可写条件在Codex尚未知，需求评审保持该证据边界 |
| XLSX/XLSM | ExcelJS候选解析+虚拟工作表；与更完整引擎做公式/样式/图表/宏fixtures对比 | ExcelJS并非Walnut/CRDT替代；XLSM不得执行宏，不承诺无损写回；可写XLSX需DocumentSession与保留未知OpenXML部件策略 |
| PPTX | 本机已试验 LibreOffice/UNO 的幻灯片文本命令编辑、同格式输出与 PDF；拟封装独立 OfficeEngineAdapter，前端工具条/选区/对象模型仍需验证 | UNO 最小编辑通过不代表复杂 PPTX 保真或 UI 完成；bytes+etag写回仍经FileService。未知部件/关系变化须阻止静默覆盖，不可用 PDF 预览代替目标编辑 |
| doc/xls/ppt、key/numbers/pages、ODF、RTF、归档、未知binary | 对齐unsupported类型/说明/外开；明确被专用viewer接管与未接管的区别 | 不新增通用hex编辑器/解压执行；不把docx/pptx/xlsx一概归unsupported |
| MCP自定义viewer、附件/历史/library来源 | ViewerRegistry保留来源/能力字段；文件MCP viewer按用户最新全量目标纳入适配，见§8.1 | 不引入Codex账户/文档库业务；已配置MCP不等于已拥有viewer注册、资源URI写回和隔离UI协议，未知点作为开工闸门 |

解析统一在worker/隔离进程中做：`parse.start({assetId,revision,rendererId,options,budget})→{jobId}`；`parse.cancel(jobId)`；`parse.release(jobId)`；事件 `{jobId,sequence,state:'progress'|'ready'|'failed'|'cancelled',modelHandle?,error?}`。parser不得持有任意磁盘路径，assetId只读且绑定revision。限制原始bytes、解压总bytes/条目/嵌套、页/行/cell数量、解析时间和内存；达到限制显示too-large/parse-error并保留原文件。XML禁外部实体/网络；Office外部关系、链接、宏与嵌入对象不自动执行；转换过程使用每job临时目录，结束/崩溃清理。

### 8.1 文件只读 Git 元数据、MCP viewer 与 selection-edit

本段覆盖旧F22“一概不做Git状态”的历史建议，来自最新用户指令，不是从第三方依赖自行扩大范围。

| 能力 | 拟实现契约 | 条件与未知 |
| --- | --- | --- |
| 文件状态/变化文件浏览 | `fileMetadata.status(ctx,{paths?,view:'tree'\|'changes'})→{repositoryId,revision,entries:[{relativePath,status:'added'\|'modified'\|'deleted'\|'renamed'\|'untracked'\|'ignored',previousPath?,generated?}],truncated}` | 仅已验证仓库、结果限定授权根；普通树与变化文件视图分开。Git管理命令不提供 |
| 只读 blame | `fileMetadata.blame(ctx,{file,lineStart,lineEnd,baseRevision})→{lines:[{line,commitId,author,at,summary}],revision}` | 有仓库/文本/有效行时提供；不运行文本转换器，不把blame按钮常驻所有viewer。未提交文本与行号失配明确不可用 |
| generated过滤 | `fileMetadata.attributes(ctx,{paths})→{path,generated:boolean\|null,source}`；变化文件视图按结果过滤 | Codex在识别到linguist-generated时才提供，非普通隐藏文件开关；未知属性不能当false/true猜测 |
| 仓库定位外链 | `fileMetadata.externalLocation(ctx,{file,line?})→{url,label}\|null` | 解析已登记远端并限制http(s)，有可信映射才显示；不复制凭据/远端私有token到URL |
| MCP viewer发现 | `viewers.list(ctx,{file,contentKind})→{viewerId,title,suffixes,capabilities,availability,reason}` | 按最长复合后缀/用户偏好；已配置server≠可用viewer；扩展不可自动得到全磁盘权限 |
| MCP viewer资源 | `viewers.open(ctx,{file,viewerId,mode})→{sessionId,resourceUri,etag,capabilities}`；`viewers.read(sessionId)`；`viewers.write(sessionId,{ifMatch,uploadId,opId})`；`viewers.close(sessionId)` | URI严格匹配会话文件、返回bytes/text限额、ifMatch冲突；扩展UI在隔离宿主，不能拿主preload。失败可选内建viewer但保留失败原因 |
| 文件内selection-edit（R3唯一现行候选，D01待确认） | `selectionEdit.start`建立文件/选区/版本快照并经专用终端插入通道放入指令（不回车）；文件内容变化触发`pending→review`；`keep/revert/cancel`分别保留审阅版、按版本条件还原、停止本功能等待；另有`expired/failed` | 不传providerId、不调用模型、不期待结构化patch回包；以§8.5和需求R07.19为准。还原走FileService带版本保存、受§6并发保护边界约束；取消不停止CLI或自动撤回磁盘变化 |

只读Git provider使用受控参数数组、不拼shell；repo discovery/输出限额/timeout/cancel与root lease绑定。禁止运行仓库配置中的外部helpers、fsmonitor、textconv或hooks，不用全局`safe.directory=*`绕过归属保护；参数必须阻止路径被当选项。Git目录可能在选择目录祖先或worktree外部，需额外验证repo身份及元数据边界，文件内容仍只读授权根内。无Git/未受信仓库显示不可用，不把空状态伪装为干净。Yoda现有只读metadata可抽取，但写管理方法不随之注册。

SmartDD现状：`src/main/core/capabilities/discovery.ts:104`起只发现/校验MCP配置；`capability-service.ts:232–262`为CLI注入项目context MCP并标记loaded=unverified。它们**没有证明**viewer注册、resource URI read/write、ifMatch或沙箱UI已经实现。当前任务CLI由PTY运行，终端插入确认不证明CLI已读取、识别引用或提交，不能解析ANSI输出伪装成可靠的编辑RPC。

**历史方案已替代：** R1/R2 曾提出`FileAssistantAdapter`直连模型/结构化协议、模型返回patch后接受到buffer。R3现行候选改为§8.5的“终端输入＋外部文件变化审阅”，旧方案不再作为A0/A4实施任务，不新增模型调用或并行会话；D01仍须用户评审。MCP viewer的清单、文件资源/权限、隔离UI和自定义写回协议继续独立验证，与CLI修改审阅不混为一种结构化模型回包。

### 8.2 Office编辑会话契约

`documents.open(ctx,ref,{rendererId,intent:'preview'|'edit'})→{sessionId,state,capabilities,baseRevision,stateVersion,materializedStateVersion}`；`documents.apply(sessionId,{updateId,originId,baseStateVersion,patch})→{stateVersion}`；`documents.flush(sessionId,{opId,expectedPublicRevision})→{state:'saved'|'stale'|'conflict'|'too-large',materializedStateVersion,publicRevision}`；`documents.refresh(sessionId)`；`documents.close(sessionId,{mode:'flush'|'discard-confirmed'})`。

state分`starting|live|refreshing|blocked|fallback`，problem分`conflict|persistence|unsupported|too-large|parse`。`stateVersion`与`materializedStateVersion`独立：内存接受编辑不等于磁盘保存。op/update幂等、队列串行、关闭前flush；flush失败阻止默认关闭并保留草稿/编辑日志；hard dispose不能偷偷宣称saved。PPTX整bytes路线用baseRevision/etag和500ms参考debounce；XLSX结构化路线先验证单人编辑日志/重放，再决定是否需要CRDT，**不能只因为Codex用了CRDT就额外引入协同业务**。任何renderer声称支持的编辑功能都必须通过round-trip：内容、样式、关系、嵌入对象和未知部件不被静默丢弃。

R2 已通过私有 UNO pipe 对 DOCX/XLSX/PPTX 原生模型执行基础编辑并独立读取输出；另一次 OOXML 往返发现 DOCX 未知部件丢失。具体 adapter、部件 manifest、损失阻断、另存副本与保留草稿策略见[实验决策 §6](实验/实验结论与迁移决策.md#6-office-adapter-可执行落点)。`materialize` 产生候选 bytes 以后仍必须做保真门禁与正式文件 revision 校验；不能直接把 UNO storeAsURL 指向用户原路径。

**R3 Office 保存策略（实验已验证文本/数值类编辑，见实验 §9；R3.1明确差异判据）：** 写回原文件分两条路。(1) **精确补丁**：定位被编辑的 XML 部件，字节级唯一匹配替换，其余部件逐字节保留；匹配不唯一即拒绝；跨 run 文本改为结构化补丁并保留 run 属性；XLSX 改共享字符串前统计引用数（≠1 就追加新字符串），改输入数值时使旧公式缓存失效并设置 `fullCalcOnLoad`。(2) **引擎重写**：LibreOffice 可用于预览/导出 PDF；需要重排的复杂编辑仍为待验证路线，不允许将同格式输出直接写回原件。每个编辑操作建立预期变更清单（部件、关系、内容与必要关联变化），检查候选输出是否仅含可解释的变化、引用是否完整；删除幻灯片等用户操作允许对应部件/关系被删除，不能把任何删除一律当破坏。**非预期丢件、无关内容破坏或无法解释的差异阻止覆盖**，保留编辑/草稿，提示后由用户明确选择另存副本；另存有损副本不算完整原格式编辑已通过。已观察到的未知部件、缩略图、webSettings 丢失是基础文字编辑不应造成的损失，仍属失败负对照。结构性编辑的清单生成、语义/布局检查及独立读取器验证尚未实现，不能仅凭ZIP部件数相同判定保真。

### 8.3 Markdown 渲染与编辑管线（R3，原型已验证）

权威数据仍是 source 文本。解析：markdown-it（`html:false`）产出 token 与行号映射，顶层每个块记录 `from/to/line`（UTF-16 偏移）；块间空行和引用定义各为独立块，保证所有块 `raw` 拼接后逐字节等于原文（含 CRLF/CR、末行无换行，已用 400 个种子随机文档验证）。渲染：每块用该块 token 渲染为 HTML 后插入；frontmatter 用 YAML 解析，失败显示错误；公式用 KaTeX（`throwOnError:false`）；图表按需加载 Mermaid。编辑：点击/聚焦某块即以该块源文本进入 textarea，输入只经 `replaceMarkdownBlock` 替换该块范围，不从 HTML 反序列化。任务项勾选只改写 token 记录的源码行。链接/图片目标保留作者原文，不使用 markdown-it 的百分号编码值做路径解析。

**已知限制：** 这不是 CodeMirror 的装饰/选区模型，跨块选区、公式内选区、光标进入时的标记显露仍沿用“整块切源码”的简化；围栏代码未做语法高亮；每次文本变化重新解析全文，10MiB 约 0.3s，必须在正式实现中改为 Worker 或增量并带取消/超时（需求 R08.11）。

### 8.4 PDF 与 Notebook 管线（R3，原型已验证）

**PDF**：pdf.js（pdfjs-dist 5.4.296，Apache-2.0）与其 Worker 都是独立懒加载块，首屏不加载（原型构建：pdf 约 440KB/gzip 128KB，Worker 约 1046KB/gzip 288KB）；禁用 eval，不使用系统字体。流程：`getDocument` → `onPassword`（缺失/错误两态）→ 取各页尺寸与大纲 → 页面组件按“接近视口才渲染”渲染画布、文本层（pdf.js TextLayer）和链接层，离开视口后释放画布；缩放按 `pdfRenderPlan` 计算显示尺寸与渲染倍率，面积超过约 1677 万像素或边长超过 16384 时降采样并提示；`classifyPdfError` 把异常分为 password/invalid/missing/network/aborted/unknown；目的地用 `resolveDestinationPage` 统一解析页引用、整数页码与命名目的地。销毁来自来源切换、卸载与用户取消密码，且取消密码需要标记，避免销毁产生的异常覆盖成通用错误（原型已修复该缺陷）。评论/区域坐标统一按每页真实尺寸（点）换算，不再用固定 600×780。

**未解决**：① 为得到页尺寸会遍历所有页，几千页的文档需改为只取首页并按需更新；② 非嵌入 CJK/标准字体需要配置 `cMapUrl`/`standardFontDataUrl` 资源并评估体积；③ 真实 Worker 崩溃/终止、内存与 p95 需在 Chromium 与安装 App 中测量并冻结预算；④ review（canvas 路线）的真实渲染没有单独验证；⑤ PDF 内表单、JavaScript 动作、批注层不渲染也不执行。

**Notebook**：Markdown 单元走与文档相同的 markdown-it 管线（`renderMarkdownReadOnly`：HTML 关闭、链接 href 改为 #、图片白名单、任务框禁用）；代码与 JSON 输出用 highlight.js 11.11.1（BSD-3-Clause）子集高亮，HTML 输出仍进入 `sandbox=""` 的 iframe，不执行单元。高亮色浅/深色各一套。主包因此增至约 1632KB（gzip 492KB），Mermaid 与 pdf.js 保持按需。

### 8.5 业务接入闭环（R3 第三批，原型与隔离实验已验证；**设计待用户评审，未实现生产代码**）

对应需求 R05.10–R05.12、R07.19、R05.13、R06.18、R08.12（见[需求](../需求.md)）；实验与数字见[实验 §11](实验/实验结论与迁移决策.md#11-r3-第三批与-smartdd-业务的接入闭环m9-gap-07)。

**① 文件引用 → 终端输入（D01 的建议映射）。** 参考的“添加到聊天”映射为“终端引用托盘＋插入终端输入”：文件/选区/评论加入托盘（`file | range | comment`，保存相对根路径、行范围、revision、所选文本哈希）；托盘可预览、移除、标记 `fresh|stale|missing`；“插入到终端输入”只把文本放进当前运行任务的输入行，**永不追加回车**，提交永远是用户在终端里按 Enter。SmartDD 不调用模型、不解析终端输出，不引入聊天界面。

| 约束 | 规则（来自实验 TI01–TI08，实现为 `file-reference-model.mjs`） |
| --- | --- |
| 文本清理 | 文件内容不可信：去除 ESC、除 `\t\n` 外的 C0、DEL、C1（含 0x9B）、双向控制字符；孤立代理对→U+FFFD；清理项在界面可见 |
| 括号粘贴 | 开关来自目标程序实际发出的 `ESC[?2004h`（xterm 的 `bracketedPasteMode`），不写死；开启时保留换行并包 `ESC[200~…ESC[201~` |
| 非括号模式 | 换行会被终端当回车自动提交（TI05 已证），必须折叠为空格 |
| 大小 | 所选文字 ≤4,000 字符且 ≤200 行（超出截断并标记），总长 ≤8,000 字符（超出拒绝并给数字） |
| 引用语法 | 默认通用写法 `相对路径:L12-30`；`@路径` 仅为可选样式，Claude Code/Codex 是否识别需分别验证，**未验证** |

**专用“终端插入”RPC（要求，未实现）。** 渲染进程不得直接用原始 PTY 写入：`src/main/index.ts:133` 的 `events.on(ptyInputEvent, …)` 对任意 `ptyId/data` 不做所有权校验。新通道输入 `{taskId, ptyId, text}`，主进程校验可信sender及其任务访问、ptyId属于该任务（否则`pty-not-owned-by-task`）、任务运行中（`task-not-running`）、非空、≤8,000字符；再做清理并按目标实际括号模式拼装，只写一次、不回车。必须验证不能经存量原始写入通道绕过新增校验，所需收口属于M9接入安全工作，不另交用户决定是否校验。1.5秒未收到插入RPC确认时提示结果未知、保留托盘且不自动重发；确认只表示本次写入结果，不从PTY输出猜测CLI是否读取/提交。

**② 请 CLI 修改所选文本（R07.14的唯一现行候选，D01待确认）。** 选区＋指令作为一条带路径/行范围的文本放进终端输入（同上，不回车）；状态机`pending → review → kept | reverted`，另有`cancelled | expired | failed`。用户自行在终端提交；该文件磁盘**内容**相对快照变化才进入review（revision变而内容相同不算），该信号不能证明变化一定来自CLI。**此路线由CLI先改原文件、SmartDD随后审阅，不是审阅批准后才写回**；该写盘时机须在D01明确。如果用户要求后者，要重做候选流程与适配实验，不能自动恢复旧模型直连方案。“保留”接受被审阅版本；“还原”经main重新核对当前revision和内容，匹配时走FileService正常带版本保存，不匹配则保持审阅并提示冲突。它遵守§6/R08.12实际保护边界，不是系统级CAS；provider不满足还原条件时明确不可用。本地编辑该文件、切任务/换根或超时使快照过期，迟到结果不落到新实例；取消仅停止本功能等待/审阅，不停止CLI、不撤回已插入文本、不自动回滚已发生变化。真实PTY无法可靠得知Enter，`submitted`只在演示终端中出现，正式实现以文件变化为准。

**图像引用仍未闭环（既有范围的工程前置）。** 参考Markdown嵌图加入当前输入涉及模型图像能力与失败恢复，现有托盘仅`file | range | comment`。不能将文字路径插入等同图像已送达；须补实际CLI图像输入能力、不可用/失败原型与适配实验，保留需求及V05/V06，不以文本路线偷偷替代或移出范围；用户接受D01终端流程也不代表同意降级图片功能。

**③ LSP语义能力（D05，供应策略已明确，工程验证待做）。** 复用本机已存在或用户显式配置的LSP，不自动安装/捆绑；按语言/项目匹配、记录服务版本，握手后按声明能力开放菜单。实验LS01–LS10加LS08b共11项只证明当前TS服务，既不限定只支持TS，也不外推其他服务。位置按UTF-16列，每请求带文档版本；版本已变丢弃响应，支持取消和超时；服务崩溃未完成请求立即失败、可重启；根外结果标`outside-root`只读。共享服务按消费者释放，最终关闭时`shutdown`+`exit`清理进程树（macOS进程组已测，Linux/Windows需各自验证）。无服务/无匹配/能力缺失明确说明。服务发现/配置入口、语言匹配、项目配置与真实能力矩阵继续工程验证，不能靠“可配置”或长期禁用宣称完成；自动下载/捆绑若后续提出，再作范围变更。

**④ 扩展viewer（MCP）策略（D05，供应约束已明确，工程闭环待验）。** `resources`只是必要条件；还需显式viewer适配清单声明匹配后缀/来源、呈现入口及能力，隔离UI、会话资源映射验证后才可用；配置MCP服务≠完整viewer。适配层使用`initialize`与`resources/*`，不请求`tools/list`（真实`rea mcp`一次约3MB/207工具）；`rea`握手不是文档viewer成功证据。URI严格匹配会话，大小按解码bytes；单行上限按最大资源推导（20MiB×4/3+256KiB≈28.2MB），超限即失败。只对显式支持自定义写回的适配器开放`ifMatch`，仅`saved`更新基线、`conflict`保留编辑；通知限速200/s计数，超时和迟到响应分开处理。**写回为SmartDD适配器自定义契约，不是MCP标准接口**；普通resources服务不能被误称可写。无匹配/失败时解释并可回内建viewer。真实第三方viewer、隔离UI/沙箱、资源订阅仍需最小完整实验，不以全部禁用代替完成；这些是工程选择与验证，不要求用户替代协议实现判断。

**⑤ 远程provider（D07，范围待用户确认）。** 接口沿用§10的`HostFileProvider`：若纳入本期，主机密钥首次确认并固定、变更在认证前拒绝（生产`ssh-tester.ts`目前不校验，须随接入补）；连接后探测`{atomicReplace, compareAndSwap:false, watch:false}`。SFTP无条件写，“校验后、rename前”外部写入可能被覆盖，界面不承诺无丢失；不能原子覆盖默认拒绝写回，仅在用户明确同意后才可走非原子“删除→rename”。所有调用有连接关闭/超时保护（裸ssh2断线后写调用挂起，SF07已证）；无watch则轮询。上传/提交前断线不改原件；提交开始后结果可能未知，非原子删除后中断还可能目标缺失。保留本地编辑和可确认临时文件，重连先核对目标/临时身份、hash与操作状态，再恢复/清理，不能盲重试或先删临时副本。各提交中断点与重连恢复仍需故障注入，现有SF实验未证明所有情况。是否做远程工作区及逐能力范围仍待D07评审。


## 9. 依赖、来源与许可决策

Yoda源码按Apache-2.0适配并更新SmartDD NOTICE；Codex私有bundle只研究行为/结构，不搬实现/字体/品牌资产。版本列是拟试验基线，非“已装/已安全验收”；新增依赖须核对对应实际tarball及传递依赖、worker打包和安装包许可。许可元数据不等于完整分发结论。

| 组件 | 试验版本/来源 | 许可与取舍 |
| --- | --- | --- |
| 虚拟树 | @tanstack/react-virtual 3.13.23（Yoda锁文件） | 上游[主分支MIT声明](https://raw.githubusercontent.com/TanStack/virtual/main/LICENSE)已核对；该锁版本tarball许可仍须保存，不能用主分支版本替换锁版本 |
| 本地watch | @parcel/watcher 2.5.6 | [MIT，原生模块](https://raw.githubusercontent.com/parcel-bundler/watcher/v2.5.6/package.json)；增加mac arm64/x64、Windows、Linux安装包探针 |
| 文本编辑 | monaco-editor 0.55.1 + @monaco-editor/react 4.7.0 | [Monaco MIT](https://raw.githubusercontent.com/microsoft/monaco-editor/v0.55.1/package.json)、[React wrapper MIT](https://raw.githubusercontent.com/suren-atoyan/monaco-react/v4.7.0/package.json)；本地worker，不用CDN；不声称等于Codex Pierre/CodeMirror内部 |
| Markdown（原型 R3 已用） | markdown-it 14.1.0、markdown-it-texmath 1.0.0、katex 0.16.22、mermaid 11.12.0、js-yaml 4.1.0（均 MIT，精确锁定，见实验 §8.3及[原型锁文件](../../../../prototypes/m6-codex/package-lock.json)）；R1 拟试验的 react-markdown 链未采用 | 原型选型：markdown-it 关闭原始 HTML，Mermaid 用 strict 且 `htmlLabels:false`（类图的 foreignObject 标签在本原型页面中渲染为空白，原因未查明；改用 SVG 文本标签后恢复），mermaid 按需加载；全链锁依赖与许可须随生产实际引入入包，清洗不等于允许任意资源URL。旧 react-markdown/rehype 许可材料只属历史候选，不作为当前依赖证明 |
| PDF（原型 R3 已用） | pdfjs-dist 5.4.296（精确锁定，legacy 构建用于 Node 实验） | [Apache-2.0及Node要求](https://raw.githubusercontent.com/mozilla/pdf.js/v5.4.296/package.json)；这是受控试验版本，开发前核对当前修复和实际pdfjs-dist包，未做漏洞/兼容扫描 |
| CSV/TSV | Papa Parse5.5.3 | [MIT](https://raw.githubusercontent.com/mholt/PapaParse/5.5.3/package.json)；worker/流式接口适合大表，格式保真另验 |
| XLSX | ExcelJS4.4.0 | [MIT，XLSX/CSV读写定位](https://raw.githubusercontent.com/exceljs/exceljs/v4.4.0/package.json)；仅候选，不推断宏、图表、公式计算和无损往返能力 |
| DOCX | docx-preview0.4.1（本轮读取master元数据，待固定tag/tarball） | [Apache-2.0声明](https://raw.githubusercontent.com/VolodymyrBaydalka/docxjs/master/package.json)；无等价编辑/写回承诺，复杂排版比较后定 |
| Office转换/高保真备用 | 本机 LibreOffice 26.2.4.2 / UNO 已实测；打包版本、体积、跨平台分发方式待固定 | [官方MPL2.0及多组件许可说明](https://www.libreoffice.org/licenses/)；本轮只调用既有引擎，无安装。三类基础命令编辑通过；DOCX 丢件已记录。字体/宏/复杂保真、进程沙箱、安装包和其它平台仍待验 |
| 代码高亮（原型 R3 已用） | highlight.js 11.11.1（精确锁定，BSD-3-Clause） | 仅注册 10 种语言以控制体积；输出由库转义，只含 `span.hljs-*`；未知语言退回纯文本。许可证需随安装包提供 |
| 语言服务适配实验（仓库外） | typescript-language-server 4.3.4（Apache-2.0）、typescript 5.9.3（Apache-2.0） | 只装在 `/tmp/m9-lsp` 做实验，**未加入 SmartDD 依赖**；现行候选复用本机已有/显式配置服务、不自动安装或捆绑；发现/配置/匹配与版本矩阵继续验证，见§8.5 |
| 远程实验 | ssh2 1.17.0（SmartDD 已有依赖，MIT） | 实验用其客户端和内置 SFTP 服务；**未新增依赖**，OpenSSH 行为未验 |
| 图标/字体 | 优先现有可用资源；Yoda devicon2.17.0仅候选 | 每个资源来源、许可与参考差异另记；不因为包开源就称品牌图标/字体可原样复制 |

R2 另核对 Univer、ONLYOFFICE、Collabora 的一手能力和 OSS/服务/二进制许可边界，见[候选矩阵](实验/实验结论与迁移决策.md#5-合法替代组件的明确分工)。本轮未部署这些候选，不能把文档介绍当兼容验证。

Office试验结论不满足完整目标时，保留问题和第二候选/自研适配工作量，提请范围评审；**不得将“外部打开”写成已完成PPTX/XLSX编辑，也不得隐藏该类测试用例**。

## 10. 远程host与跨平台条件

当前SmartDD服务器配置用于已授权SSH能力，不等于已实现远程文件workspace。本期本地闭环与远程能力分开记录：只有存在可解析RootRequest、host身份、路径语义、读写/取消/revision/监控能力声明的provider才启用远程tab。未满足时显示HOST_UNAVAILABLE/CAPABILITY_UNAVAILABLE及重试，保留tab描述符；不自动上传源码到第三方解析服务。

接口保留HostFileProvider：`resolveRoot/stat/list/readRange/readText/writeWithRevision/search/watch/reveal`，本地使用Node；远程可复用已有SSH/SFTP连接服务的授权和生命周期，但不绕过成renderer任意host/path。网络断线使当前generation暂停/失效，重连重新解析授权与revision；partial upload不可当已保存。远端不支持CAS/atomic rename时显式能力降级并追加验证，不能承诺与本地完全等价。

SmartDD `src/shared/projects.ts:60` 仍以`/`判绝对路径，Windows drive/UNC/WSL在开工探针中单独解决。macOS大小写/Unicode、Windows锁文件/rename/路径长度、Linux权限/symlink与watch限额各自测；主机路径与远端路径分开用对应path实现。Mac通过不意味着其它平台通过。

## 11. 分阶段实施与开工闸门

阶段为工作拆解，不代表授权已扩大，也不代表允许中途把完整目标标完成。

| 阶段 | 必须完成的工程工作 | 退出证据 |
| --- | --- | --- |
| A0 技术闸门（已有R3隔离证据，未整体通过） | 冻结R01–R09行为/类型与D01/D07决策；对根/保存、编辑器与worker、watch原生加载、HTML隔离、Office复杂编辑、只读Git、MCP真实viewer、终端/图像引用及TeX补关键可行性探针；明确各平台方案和能力边界 | 关键未知有实测结果/失败原因/可行替代路线，选型版本/许可/资源预算可判定；未做的生产实现与安装包测试明确列入A1–A5，不将占位或未知填通过 |
| A1 根与生命周期 | shared schema、scoped controller、RootResolver、取消/请求身份、AssetRegistry、结构化错误、checkpoint/draft服务 | owner越权/旧root/迟到响应/释放测试通过；所有写入仍在fixture |
| A2 树/搜索/标签 | 懒树、虚拟化、名称/全文搜索模式、preview/pin/去重/重排/恢复、面包屑菜单；PTY并排 | 大目录、隐藏/忽略策略、键盘焦点、恢复和终端不重建通过；对齐原型 |
| A3 基础viewer与文本编辑 | Markdown/source、图片/SVG、PDF、CSV、Notebook、音视频、HTML/TeX分支、unsupported；完整保存冲突/关闭 | 逐类fixture、边界值、损坏文件、外部改动、草稿恢复及安全测试通过 |
| A4 Office与条件能力 | DOCX/PPTX/XLSX/XLSM适配；可写路由的版本队列/flush/materialize、来源只读规则与预期差异门禁；文件MCP viewer隔离/资源适配；已确认的终端引用（含图像能力）及CLI外改审阅；已确认远程provider | 解析与往返保真矩阵、真实能力闭环、冲突/失败恢复、资源上限、许可与安装包结果；无模型直连结构化patch任务，未通过项保持未交付 |
| A5 完整验收 | 浅/深、hover/selection/long path/menu/IME；跨平台声明逐项验证；文档/原型/App一致 | [测试用例](../验收/测试用例.md)逐条真实结果；差异明确，未验证不写完全一致 |

A0不是“全部研究做完才允许画原型”；本轮原型可先表达完整状态和交互，真实parser/文件写入在后续授权开发时验证。技术闸门失败要回写需求/方案/用例，开发前完成具体取舍，不默默回到旧“只读够用”。

**R3.1 接续分类：** D01是终端映射及“先改原件再审阅”的产品决策，D07是远程范围决策；参考/合法资源差异与候选快照在整体设计评审中确认，不请求再次操作Codex。D02/D03/D04/D05/D06是工程工作：Office预期差异和复杂往返、受控TeX、双HTML隔离、只读Git、LSP发现/实际能力、第三方viewer/图像输入、草稿容量/编码与恢复，按需求§7推进；没有可行性证据的关键部分继续设计/实验，不能仅改成“工程事项”就算完成。生产native broker、IPC/数据库迁移、完整多窗口/恢复、真实App及各平台安装包属于授权后的实现与验收；相同攻击/故障样本必须保留用于复验。

## 12. 验证计划与当前未完成项

研究阶段已做：指定版本静态逆向、原始字节/哈希记录、REA聚焦图/trace、SmartDD/Yoda源码对照、一手依赖许可核对，以及 R2 **真实临时文件/独立进程竞争/watch/poll 与三类 Office 转换、UNO 原生命令编辑实验**。结果包含失败和负对照，详细运行环境及可重现脚本见[实验索引](实验/README.md)。

**未做**：正式文件功能代码、生产依赖接入、数据库迁移、Codex动态交互、用户真实文档写入、生产安装包或Windows/Linux验收。原型和仓库外实验已引入的依赖见§9，不能笼统写“没有安装任何依赖”。原型真实界面QA以验收记录为准；实验脚本不替代页面证据。受限环境watch/LibreOffice失败与批准本机运行的结果分开保留；既有批准隔离实验不构成Codex观察授权。

R3另做：PDF解析6项（实验§10，含Node/fake-worker解析耗时、内存和取消观察）、目录fd锚定与交换式提交10项（9通过＋AFS10残余窗口；AFS07回读前覆盖已报冲突）、监听恢复6项、Markdown引擎成本与Worker取消/超时/崩溃8项；OOXML精确补丁10通过＋3个对照缺口；第三批终端注入7通过＋1负对照、LSP11通过、MCP13通过、SFTP7通过＋2观察缺口。入口见[实验索引](实验/README.md)。**仍未做**：Chromium真实PDF Worker终止/崩溃及渲染成本与预算、LibreOffice成本/取消与复杂编辑保真、Linux/Windows保存方案、`@parcel/watcher`安装包验证、Chromium下Markdown主线程成本与增量适配、真实第三方viewer及CLI图像输入等；Node解析结果不能充当这些验证。

后续验证按对应风险选取：

- 单元/状态机：preview替换与dirty固定、去重、异步close实例守卫；保存时继续输入；冲突真值表；checkpoint schema/version；parser路由/阈值；search queryVersion和取消。
- 文件集成：临时多根、symlink越界/根替换、权限/磁盘满、相同mtime不同内容、外部原子替换、双窗口并发、重复opId；snapshot/watch间隙与洪峰resync。
- worker/预览：错误文件、压缩炸弹、外部XML关系、恶意SVG/HTML/Notebook、PDF worker崩溃；每格式都验加载/错误/上限/释放，不能只截图happy path。
- Office：源bytes保存基线、未知OpenXML部件、宏不执行、字体回退、批注/图表/公式/合并单元格、编辑后在独立读取器比对；不能仅用同一parser自读自写证明兼容。
- 实际App：运行CLI时拖拽文件栏、搜索/编辑/IME与全局快捷键冲突；单击/双击、关闭dirty、快速切任务；刷新/退出/崩溃恢复；PTY数量/ID和焦点观测。
- 包与平台：阶段端到端验收即使用打包应用，正式发布时再按AGENTS发布流程检查；文件worker、原生watch、资源协议、字体和平台外开从安装包验证，每平台单列，不等到发版才做阶段安装包验收。

剩余研究未知以专项报告T项及验收清单维护；本方案已把接口与验证路径具体化，但不把未跑过的技术选型标为通过。
