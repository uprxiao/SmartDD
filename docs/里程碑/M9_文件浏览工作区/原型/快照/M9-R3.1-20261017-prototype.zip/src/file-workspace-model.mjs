// Original interaction model. Synthetic data only; no native filesystem access.
import { rankFileCandidates } from './file-fuzzy-model.mjs';
export const REFERENCE_REV = 'M9-R2-20261017';
export const SAMPLE_MD = `# SmartDD 协作与发布约定

本文件是 Codex 与 Claude Code 共用的项目规则。用户在当前会话明确提出的要求优先。

## 开发与分支

- 在 feature/<版本号> 分支开发，同一版本完成前沿用该分支。
- main 保存经过验证、可发布的代码。
- 开始工作先检查当前分支与工作区，保留用户和其他 Agent 的改动。
- 有适用的现成实现就复用，按项目实际依赖和配置适配。

## Codex UI 细粒度复刻

- 逐项对齐布局、尺寸、字体、颜色、图标、间距与微交互。
- 覆盖浅色、深色、选中、悬停和长文本状态。
- 中央运行工作区继续使用终端。

## 验收与交付

需求、原型、技术方案与测试用例必须逐项对应。未经验证的状态不能宣称完全一致。
`;
export const FILES = [['AGENTS.md', 'markdown', SAMPLE_MD], ['CLAUDE.md', 'markdown', '# CLAUDE.md\n\n请先阅读 AGENTS.md 中的项目约定。'], ['CHANGELOG.md', 'markdown', '# 变更记录\n\n## M9\n\n文件浏览工作区 · 设计预览'], ['.gitignore', 'code', 'node_modules/\nrelease/\n.DS_Store'], ['.DS_Store', 'unsupported', ''], ['package.json', 'code', '{\n  "name": "smartdd",\n  "displayName": "WillYou",\n  "version": "0.0.5"\n}\n'], ['src/main.ts', 'code', 'import { app } from "electron";\n\n// 示例，不执行\nexport const workspace = {\n  name: "WillYou",\n  root: "SmartDD"\n};\n'], ['src/renderer/App.tsx', 'code', 'export function App() {\n  return <main>WillYou</main>;\n}\n'], ['docs/需求.md', 'markdown', '# 文件浏览工作区\n\n## 目标\n\n完整记录每个文件行为，保留独立终端会话。\n\n- 懒加载目录\n- 预览与固定标签\n- 编辑、保存与冲突恢复'], ['docs/图文说明.md', 'markdown', '# 图文说明\n\n普通文件图片与 Markdown 嵌入图片使用不同入口。\n\n![WillYou 图标](/assets/app-icon.png)\n\n## 第二张图片\n\n![WillYou 图标副本](/assets/app-icon.png)'], ['docs/一份需要完整展示而不能挤掉关闭按钮的很长的中文需求文档名称.md', 'markdown', '# 长文件名\n\n悬停查看完整路径，标签保留关闭入口。'], ['docs/验收.pdf', 'pdf', '验收记录'], ['docs/概要设计.docx', 'docx', '项目文档与文件工作区'], ['docs/发布演示.pptx', 'pptx', '文件工作区'], ['docs/数据.xlsx', 'xlsx', ''], ['docs/含宏工作簿.xlsm', 'xlsx', ''], ['docs/数据.csv', 'code', '阶段,名称,状态\nM8,项目导入导出,已完成\nM9,文件浏览工作区,设计中'], ['docs/数据.tsv', 'code', '阶段\t名称\t状态\nM9\t文件浏览工作区\t设计中'], ['docs/实验.ipynb', 'ipynb', '{ "cells": [{"cell_type":"markdown", "source":["# M9 实验"]}], "nbformat":4 }'], ['docs/公式.tex', 'code', '\\documentclass{article}\n\\begin{document}\nE = mc^2\n\\end{document}'], ['resources/app-icon.png', 'image', '/assets/app-icon.png'], ['resources/vector.svg', 'svg', '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="80"><text x="10" y="45">WillYou</text></svg>'], ['resources/录音.wav', 'audio', ''], ['resources/演示.webm', 'video', ''], ['resources/扫描.tiff', 'unsupported', ''], ['index.html', 'html', '<!doctype html>\n<html lang="zh"><body><h1>WillYou</h1><p>文件文档预览</p></body></html>'], ['fixtures/large.log', 'large', '只读大文件示例\n'.repeat(30)], ['fixtures/too-large.log', 'too-large', ''], ['fixtures/不可读.txt', 'unreadable', ''], ['fixtures/已删除.md', 'missing', ''], ['fixtures/未知.bin', 'unsupported', ''], ['fixtures/empty.txt', 'code', ''], ['licenses/NOTICE', 'code', '示例文件。图标上游及许可证见 assets/m9-file-icons。'], ['drizzle/schema.ts', 'code', 'export const schema = {};'], ['native/README.md', 'markdown', '# Native\n\n本机模块'], ['scripts/build.mjs', 'code', '// 构建示例']].map(([path, kind, text]) => ({
  path,
  kind,
  text
}));
FILES.push({path:'docs/Markdown完整交互.md',kind:'markdown',text:`---
title: 文件工作区
status: 设计中
---
# Markdown 完整交互

点击文字可直接编辑；离开后恢复格式。**加粗**、*斜体*、~~删除线~~ 和 \`code\`。

> 保留文件与会话的独立状态。

- [ ] 验证直接编辑
- [x] 已记录需求

| 阶段 | 内容 |
| --- | --- |
| M9 | 文件工作区 |

[打开需求](需求.md)

![图标](/assets/app-icon.png)

![图示](/assets/m9-image-fixture.svg)

\`\`\`typescript
const name = "WillYou";
\`\`\`

$$
E = mc^2
$$

\`\`\`mermaid
flowchart LR
  A[需求] --> B[原型] --> C[验收]
\`\`\`
`});
FILES.push({path:'docs/Markdown语法全集.md',kind:'markdown',text:`---
title: 语法全集
tags: [markdown, 样例]
meta: {owner: WillYou, rev: 3}
---
# 一级标题 😀 中文 emoji

Setext 二级标题
---------------

段落含 **加粗**、*斜体*、~~删除线~~、\`行内代码\`、<b>不会执行的 HTML</b> 与自动转义 &amp; 实体，行末两空格换行  
下一行。行内公式 $a^2+b^2=c^2$，价格 $5 和 $6 不是公式。

1. 有序一
   - 嵌套无序 **加粗**
     1. 三层有序
   - [ ] 嵌套任务
2. 有序二
   - [x] 已完成任务

> 引用第一层
> > 引用第二层
> - 引用中的列表

| 左对齐 | 居中 | 右对齐 |
|:-------|:----:|-------:|
| \`a\\|b\` | **粗** | 12.50 |
| 中文 | 😀 | 3 |

使用 [引用式链接][doc]、[相对文件](../AGENTS.md) 和 [外部地址](https://example.invalid)。

[doc]: 需求.md "引用定义保留为源码"

\`\`\`typescript
const html = "<script>alert(1)</script>";
\`\`\`

    缩进代码块

$$
\\begin{aligned} \\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix} &= M \\\\ \\int_0^1 x^2\\,dx &= \\frac{1}{3} \\end{aligned}
$$

\`\`\`mermaid
sequenceDiagram
  用户->>终端: 提交修改请求
  终端-->>用户: 返回结果
\`\`\`

\`\`\`mermaid
classDiagram
  class FileWorkspace
  FileWorkspace --> Tab
\`\`\`

***

![图示](/assets/m9-image-fixture.svg)
`});
FILES.push({path:'docs/Markdown异常样例.md',kind:'markdown',text:`---
title: [未闭合
---
# 异常样例

无效公式：$\\frac{1$ 之后仍可编辑。

\`\`\`mermaid
flowchart LR
  A --> 
\`\`\`

未闭合围栏会延伸到文件末尾：

\`\`\`js
still code
`});
// 引用安全演示：第 2 行含 ESC[201~（提前结束括号粘贴）与 ^C（中断前台进程）。放入终端前必须被清理。
FILES.push({path:'fixtures/控制字符.txt',kind:'code',text:'safe line\nx\u001b[201~\u0003touch INJECTED\ntail\n'});
export const FILE_BY_PATH = Object.fromEntries(FILES.map(f => [f.path, f]));
export const EMPTY_DIRS = ['node_modules', 'out', 'prototypes', 'release', 'fixtures/空目录'];
export const SEARCH_EXCLUDES = new Set(['.git', '.hg', '.next', '.pnpm-store', '.svn', '.turbo', '.yarn', 'build', 'coverage', 'dist', 'node_modules']);
export function fuzzyScore(path, query) {
  let score = 0,
    pos = -1;
  for (const c of query.toLowerCase()) {
    const next = path.toLowerCase().indexOf(c, pos + 1);
    if (next < 0) return -1;
    score += next === pos + 1 ? 10 : 1;
    pos = next;
  }
  return score + (path.split('/').pop().toLowerCase().startsWith(query.toLowerCase()) ? 100 : 0);
}
export function searchFiles(files, query) {
  // Mock candidate provider: a path subsequence, not the native search service.
  // Ranking is separate and retains basename zero-score path matches.
  const candidates = files.filter(f => !f.path.split('/').some(p => SEARCH_EXCLUDES.has(p)))
    .filter(f => fuzzyScore(f.path, query.trim().replaceAll('*', '')) >= 0);
  return rankFileCandidates(query, candidates);
}
export function directoryChildren(files, prefix = '') {
  const base = prefix ? prefix.replace(/\/+$/, '') + '/' : '';
  const entries = new Map();
  for (const f of files) {
    if (!f.path.startsWith(base)) continue;
    const tail = f.path.slice(base.length);
    if (!tail) continue;
    const name = tail.split('/')[0], path = base + name;
    entries.set(path, { path, name, folder: tail.includes('/') });
  }
  return [...entries.values()].sort((a,b) => Number(b.folder)-Number(a.folder) || a.name.localeCompare(b.name));
}
export function searchTreeRows(files, query, collapsed = []) {
  const ranked = searchFiles(files, query), rows = new Map();
  for (const file of ranked) {
    const parts=file.path.split('/');
    for(let i=0;i<parts.length;i++) {
      const path=parts.slice(0,i+1).join('/');
      if(rows.has(path))continue;
      rows.set(path,{path,name:parts[i],folder:i<parts.length-1,depth:i,score:file.score,indices:i===parts.length-1?file.indices:[]});
    }
  }
  // Compact a chain with only one directory child; leaves retain a visible parent.
  const compact=[];
  for(const row of rows.values()) {
    if([...rows.values()].some(parent=>parent.folder&&parent.path!==row.path&&row.path.startsWith(parent.path+'/')&&collapsed.includes(parent.path)))continue;
    const children=[...rows.values()].filter(r=>r.path.split('/').slice(0,-1).join('/')===row.path);
    if(row.folder&&children.length===1&&children[0].folder&&!collapsed.includes(row.path))continue;
    const visibleParents=compact.filter(r=>r.folder&&row.path.startsWith(r.path+'/'));
    const parent=visibleParents.at(-1);
    compact.push({...row,depth:visibleParents.length,name:row.folder?row.path.slice(parent?parent.path.length+1:0):row.name});
  }
  return compact;
}
export function treeKeyboardIntent(rows, expanded, focusedPath, key, { shift=false, toggle=false, anchor=focusedPath, selected=[] } = {}) {
  if (!rows.length) return {};
  const index = Math.max(0, rows.findIndex(r => r.path === focusedPath)), row = rows[index];
  if (key === 'ArrowRight' && row.folder && !expanded.includes(row.path)) return { expand:row.path };
  if (key === 'ArrowRight' && (!row.folder || !rows[index+1]?.path.startsWith(row.path+'/'))) return {};
  if (key === 'ArrowLeft' && row.folder && expanded.includes(row.path)) return { collapse:row.path };
  if (toggle && key === ' ') return { selected:selected.includes(row.path) ? selected.filter(p=>p!==row.path) : [...selected,row.path], anchor:row.path };
  if (toggle && key.toLowerCase() === 'a') return { selected:rows.map(r=>r.path), anchor:row.path };
  let next = index;
  if (key === 'ArrowLeft') { const parents=rows.filter(r=>r.folder&&row.path.startsWith(r.path+'/')).sort((a,b)=>b.path.length-a.path.length); next=parents.length?rows.indexOf(parents[0]):index; }
  else if (key === 'Home') next=0;
  else if (key === 'End') next=rows.length-1;
  else if (key === 'ArrowDown' || key === 'ArrowRight') next=Math.min(rows.length-1,index+1);
  else if (key === 'ArrowUp') next=Math.max(0,index-1);
  else return {};
  const result={focus:rows[next].path};
  if (shift) {let start=rows.findIndex(r=>r.path===anchor);if(start<0)start=index; // 没有有效锚点时从当前焦点行开始，而不是第一行
    result.selected=rows.slice(Math.min(start,next),Math.max(start,next)+1).map(r=>r.path);result.anchor=rows[start].path;}
  return result;
}
export function serializeWorkspaceStore(store) {
  return {
    ...store,
    ...Object.fromEntries(Object.entries(store).filter(([k]) => k !== 'saved').map(([key, s]) => {
      const tabs = s.tabs.filter(t => !t.preview);
      return [key, {
        ...s,
        tabs,
        active: tabs.some(t => fileKey(t.root, t.path) === s.active) ? s.active : tabs[0] ? fileKey(tabs[0].root, tabs[0].path) : null
      }];
    }))
  };
}
export function fileKey(root, path) {
  return root + '\u0000' + path;
}
export function workspaceScope(taskId, roots) {
  return JSON.stringify([taskId, roots.map(r => [r.id, r.hostId || 'local', r.path.replace(/\\/g, '/').replace(/\/+$/, '') || '/'])]);
}
// Tab route keys are task-local aliases. Saved identity is host + absolute path;
// overlapping roots are navigation contexts, not distinct copies of a document.
// This normalizes synthetic paths only; production canonicalization belongs to main.
export function documentKey(roots, routeKey) {
  if (!routeKey) return null;
  const separator = routeKey.indexOf('\u0000');
  const root = roots.find(r => r.id === routeKey.slice(0, separator));
  if (!root || separator < 0) return null;
  const rootPath = root.path.replace(/\\/g, '/').replace(/\/+$/, '') || '/';
  const segments=[];
  for(const part of (rootPath+'/'+routeKey.slice(separator+1)).split('/')){
    if(part==='..')segments.pop();else if(part&&part!=='.')segments.push(part);
  }
  return JSON.stringify([root.hostId || 'local', (rootPath.startsWith('/')?'/':'')+segments.join('/')]);
}
export function migratePrototypeSaved(saved = {}) {
  const next={...saved}, candidates=new Map();
  for(const [key,value] of Object.entries(saved)) {
    let identity;try{identity=JSON.parse(key);}catch{continue;}
    if(!Array.isArray(identity)||identity.length!==3||!identity.every(v=>typeof v==='string'))continue;
    const destination=documentKey([{id:'old',hostId:identity[0],path:identity[1]}],fileKey('old',identity[2]));
    if(!candidates.has(destination))candidates.set(destination,[]);
    candidates.get(destination).push(value);
  }
  for(const [key,values] of candidates)if(!(key in next)&&values.every(v=>v===values[0]))next[key]=values[0];
  return next;
}
export function fileScenario(state, key = state.active) {
  return state.fileStates?.[key]?.scenario || 'ready';
}
export function setFileScenario(state, key, scenario, diskText) {
  if (!key) return state;
  return { ...state, fileStates: { ...state.fileStates, [key]: {
    ...state.fileStates?.[key], scenario,
    ...(diskText !== undefined ? { diskText } : {})
  } } };
}
export function editDraft(state, key, text, base) {
  if (!state.tabs.some(t => fileKey(t.root, t.path) === key)) return state;
  const previous = state.drafts[key];
  if (previous?.text === text || (!previous && text === base)) return state;
  if (text === (previous?.base ?? base) && fileScenario(state,key) !== 'conflict') {
    const drafts = {...state.drafts}; delete drafts[key];
    return {...state,drafts,revisions:{...state.revisions,[key]:(state.revisions?.[key]||0)+1}};
  }
  return { ...state,
    drafts: { ...state.drafts, [key]: { text, base: state.drafts[key]?.base ?? base } },
    revisions: { ...state.revisions, [key]: (state.revisions?.[key] || 0) + 1 },
    tabs: state.tabs.map(t => fileKey(t.root, t.path) === key ? { ...t, preview: false } : t)
  };
}
export function openDocument(state, roots, root, path, pin=false) {
  const identity=documentKey(roots,fileKey(root,path));
  const alias=identity && state.tabs.find(t=>documentKey(roots,fileKey(t.root,t.path))===identity);
  return openFile(state,alias?.root||root,alias?.path||path,pin);
}
export function readRootView(state, root=state.root) {
  return {expanded:['docs'],selected:[],query:'',focused:'AGENTS.md',scrollTop:0,...state.rootStates?.[root]};
}
export function updateRootView(state, patch, root=state.root) {
  return {...state,rootStates:{...state.rootStates,[root]:{...readRootView(state,root),...patch}}};
}
export function commitDraft(store, taskId, roots, key, { override = false } = {}) {
  const state = store[taskId];
  if (!state?.drafts[key]) return { store, result: 'clean' };
  const scenario = fileScenario(state, key);
  if (scenario === 'conflict' && !override) return { store, result: 'conflict' };
  if (scenario === 'save-error') return { store, result: 'save-error' };
  const identity = documentKey(roots, key);
  if (!identity) return { store, result: 'missing-root' };
  const disk = store.saved?.[identity];
  if (!override && disk !== undefined && disk !== state.drafts[key].base && disk !== state.drafts[key].text) {
    return { result: 'conflict', store: { ...store, [taskId]: setFileScenario(state, key, 'conflict', disk) } };
  }
  const drafts = { ...state.drafts };
  const value = drafts[key].text;
  delete drafts[key];
  const next = setFileScenario({ ...state, drafts }, key, 'ready');
  return { result: 'saved', store: { ...store, [taskId]: next, saved: { ...store.saved, [identity]: value } } };
}
export function acceptDisk(state, key) {
  const drafts = { ...state.drafts };
  delete drafts[key];
  return setFileScenario({ ...state, drafts,
    revisions: { ...state.revisions, [key]: (state.revisions?.[key] || 0) + 1 },
    reloads: { ...state.reloads, [key]: (state.reloads?.[key] || 0) + 1 }
  }, key, 'ready');
}
export function captureSelection({ scope, identity, revision, text, start, end }) {
  if (!identity || start < 0 || end <= start || end > text.length) return null;
  return { scope, identity, revision, start, end, source: text, text: text.slice(start, end) };
}
export function applySelectionEdit(selection, { scope, identity, revision, text, replacement }) {
  if (!selection || selection.scope !== scope || selection.identity !== identity || selection.revision !== revision || selection.source !== text) return null;
  return text.slice(0, selection.start) + replacement + text.slice(selection.end);
}

export function artifactModel(value = '') {
  let initial;
  try { initial = JSON.parse(value); } catch { initial = {}; }
  if (!initial || typeof initial !== 'object') initial = {};
  const defaultCells = [['阶段', '名称', '状态'], ['M8', '项目导入导出', '已完成'], ['M9', '文件浏览工作区', '设计中'], ['M10', '定时任务', '待规划']];
  const validCells = cells => Array.isArray(cells) && cells.length && cells.every(row => Array.isArray(row) && row.length);
  const cells = cells => (validCells(cells) ? cells : defaultCells).map(row => row.map(v => String(v ?? '')));
  return {
    slides: [0, 1, 2].map(i => ({ title: String(initial.slides?.[i]?.title ?? (i === 0 ? initial.title || '文件浏览工作区' : i === 1 ? '每一项需求都有依据' : '评审与交付')) })),
    comments: Array.isArray(initial.comments) ? initial.comments.map(String) : [],
    sheets: [0, 1].map(i => ({ name: i === 0 ? '需求' : '验收', cells: cells(initial.sheets?.[i]?.cells ?? (i === 0 ? initial.cells : undefined)) }))
  };
}
export function updateArtifactCell(model, sheet, row, column, value) {
  return { ...model, sheets: model.sheets.map((s, i) => i === sheet ? { ...s, cells: s.cells.map((r, j) => j === row ? r.map((v, k) => k === column ? value : v) : r) } : s) };
}
export function updateArtifactSlide(model, slide, title) {
  return { ...model, slides: model.slides.map((s, i) => i === slide ? { ...s, title } : s) };
}
export function initialWorkspace() {
  return {
    root: 'main',
    tabs: [{
      root: 'main',
      path: 'AGENTS.md',
      preview: false
    }],
    active: fileKey('main', 'AGENTS.md'),
    closed: [],
    drafts: {},
    fileStates: {},
    revisions: {},
    reloads: {},
    expanded: ['docs'],
    mode: {},
    width: 250,
    tree: true
  };
}
export function openFile(state, root, path, pin = false) {
  const key = fileKey(root, path),
    existing = state.tabs.find(t => fileKey(t.root, t.path) === key);
  if (existing) return {
    ...state,
    active: key,
    tabs: state.tabs.map(t => t === existing ? {
      ...t,
      preview: t.preview && !pin
    } : t)
  };
  const tab = {
      root,
      path,
      preview: !pin
    },
    preview = state.tabs.findIndex(t => t.preview && !state.drafts[fileKey(t.root, t.path)]);
  const tabs = [...state.tabs];
  if (preview >= 0) tabs[preview] = tab;else tabs.push(tab);
  return {
    ...state,
    tabs,
    active: key
  };
}
export function closeFile(state, key) {
  const index = state.tabs.findIndex(t => fileKey(t.root, t.path) === key);
  if (index < 0) return state;
  const tab = state.tabs[index],
    tabs = state.tabs.filter(t => fileKey(t.root, t.path) !== key);
  return {
    ...state,
    tabs,
    active: state.active === key ? tabs[Math.min(index, tabs.length - 1)] ? fileKey(tabs[Math.min(index, tabs.length - 1)].root, tabs[Math.min(index, tabs.length - 1)].path) : null : state.active,
    closed: [{
      ...tab,
      index
    }, ...state.closed].slice(0, 25)
  };
}
export function restoreFile(state) {
  const [tab, ...closed] = state.closed;
  if (!tab) return state;
  const next = openFile(state, tab.root, tab.path, true);
  const tabs = next.tabs.filter(t => fileKey(t.root, t.path) !== fileKey(tab.root, tab.path));
  tabs.splice(Math.min(tab.index, tabs.length), 0, {
    root: tab.root,
    path: tab.path,
    preview: false
  });
  return {
    ...next,
    tabs,
    closed
  };
}
export function treeRows(files, expanded, query = '') {
  const paths = [...files.map(f => f.path), ...EMPTY_DIRS];
  const rows = new Map();
  for (const path of paths) {
    const parts = path.split('/');
    parts.forEach((name, i) => {
      const p = parts.slice(0, i + 1).join('/');
      if (!rows.has(p)) rows.set(p, {
        path: p,
        name,
        depth: i,
        folder: i < parts.length - 1 || EMPTY_DIRS.includes(p)
      });
    });
  }
  return [...rows.values()].filter(r => query ? !r.folder && r.path.toLowerCase().includes(query.toLowerCase()) : r.path.split('/').slice(0, -1).every((_, i) => expanded.includes(r.path.split('/').slice(0, i + 1).join('/')))).sort((a, b) => {
    const ap = a.path.split('/'),
      bp = b.path.split('/');
    for (let i = 0; i < Math.max(ap.length, bp.length); i++) {
      if (ap[i] === bp[i]) continue;
      if (!ap[i]) return -1;
      if (!bp[i]) return 1;
      const ad = ap.slice(0, i + 1).join('/'),
        bd = bp.slice(0, i + 1).join('/');
      return Number(rows.get(bd)?.folder) - Number(rows.get(ad)?.folder) || ap[i].localeCompare(bp[i], 'zh');
    }
    return 0;
  });
}
// 树的 ARIA 位置：同一父目录下的兄弟序号与总数（仅统计当前可见行）。
export function treeSetInfo(rows) {
  const parentOf = path => path.includes('/') ? path.slice(0, path.lastIndexOf('/')) : '';
  const groups = new Map();
  for (const row of rows) { const key = parentOf(row.path); if (!groups.has(key)) groups.set(key, []); groups.get(key).push(row.path); }
  const info = {};
  for (const list of groups.values()) list.forEach((path, i) => { info[path] = { pos: i + 1, size: list.length }; });
  return info;
}
