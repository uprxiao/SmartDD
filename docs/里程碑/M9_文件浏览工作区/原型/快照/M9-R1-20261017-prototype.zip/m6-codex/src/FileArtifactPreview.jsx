import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, ArrowRight, ChevronDown, Download, List, MessageSquare, ZoomIn, ZoomOut, Play, Code2, Check, Copy } from 'lucide-react';
import { artifactModel, updateArtifactCell, updateArtifactSlide } from './file-workspace-model.mjs';

// Interaction fixtures, not a document codec. No Office/TeX code executes here.
export function FileArtifactPreview(props) {
  if (['pdf', 'pdf-review', 'tex'].includes(props.kind)) return <PdfFixture {...props} />;
  if (props.kind === 'ipynb') return <NotebookFixture {...props} />;
  return <OfficeFixture {...props} />;
}
function OfficeFixture({
  kind,
  readOnly = false,
  initialValue = '',
  onDraft = () => {},
  onDownload = () => {}
}) {
  const [model, setModel] = useState(() => artifactModel(initialValue));
  const [page, setPage] = useState(1),
    [zoom, setZoom] = useState(100),
    [thumbs, setThumbs] = useState(true);
  const [sheet, setSheet] = useState(0),
    [comment, setComment] = useState(''),
    [notes, setNotes] = useState(false),
    [editing, setEditing] = useState(false),
    [activeCell, setActiveCell] = useState([0, 0]);
  const spreadsheet = ['xlsx', 'csv', 'tsv'].includes(kind),
    slides = kind === 'pptx';
  const cells = model.sheets[sheet].cells,
    formula = cells[activeCell[0]]?.[activeCell[1]] || '',
    title = model.slides[page - 1].title;
  const change = next => {
    setModel(next);
    onDraft(JSON.stringify(next));
  };
  const changeCell = (r, c, value) => change(updateArtifactCell(model, sheet, r, c, value));
  const icon = (C, label, action, disabled = false) => <button className="fw-icon" title={label} aria-label={label} disabled={disabled} onClick={action}><C size={16} /></button>;
  return <div className="fw-artifact">
    <div className="fw-artifact-tools">{slides && icon(List, '切换幻灯片缩略图', () => setThumbs(!thumbs))}<select aria-label="文档缩放" value={zoom} onChange={e => setZoom(Number(e.target.value))}>{[50,75,100,125,150,200].map(n => <option key={n} value={n}>{n}%</option>)}</select>{icon(Download, '下载文档示例', onDownload)}{slides && icon(MessageSquare, '演示稿批注', () => setNotes(!notes))}{['pptx', 'xlsx'].includes(kind) && <button className="fw-pill" disabled={readOnly} onClick={() => setEditing(!editing)}>{readOnly ? '附件只读' : editing ? '完成编辑' : '编辑'}</button>}</div>
    {spreadsheet && <div className="fw-formula"><span>{String.fromCharCode(65 + activeCell[1])}{activeCell[0] + 1}</span><label>fx<input aria-label="单元格内容" value={formula} readOnly={!editing || readOnly} onChange={e => changeCell(activeCell[0], activeCell[1], e.target.value)} /></label></div>}
    <div className="fw-artifact-main">{slides && thumbs && <nav className="fw-thumbnails" aria-label="幻灯片缩略图">{model.slides.map((slide, i) => <button key={i} aria-current={i + 1 === page ? 'page' : undefined} onClick={() => setPage(i + 1)}><span>{slide.title}</span><small>{i + 1}</small></button>)}</nav>}
      <div className="fw-artifact-scroll"><div className={'fw-paper ' + (slides ? 'slide' : '')} style={{
          zoom: zoom / 100
        }}>
        {spreadsheet ? <><h2>{model.sheets[sheet].name}</h2><table><thead><tr>{['', 'A', 'B', 'C'].map(h => <th key={h}>{h}</th>)}</tr></thead><tbody>{cells.map((row, r) => <tr key={r}><th>{r + 1}</th>{row.map((v, c) => <td key={c} className={activeCell[0] === r && activeCell[1] === c ? 'cell-selected' : ''}><input aria-label={'单元格 ' + String.fromCharCode(65 + c) + (r + 1)} value={v} readOnly={!editing || readOnly} onFocus={() => setActiveCell([r, c])} onChange={e => changeCell(r, c, e.target.value)} /></td>)}</tr>)}</tbody></table></> : <><small>{kind.toUpperCase()} · 示例内容</small><h1 key={page} contentEditable={slides && editing && !readOnly} suppressContentEditableWarning onInput={e => {
              const next = e.currentTarget.textContent;
              if (next !== title) change(updateArtifactSlide(model, page - 1, next));
            }}>{slides ? title : '项目文档与文件工作区'}</h1><p>项目、会话与文件分别维护状态。</p><p>浏览、编辑、保存和恢复形成完整流程。</p><hr /><h2>M9 设计评审</h2><p>文件支持范围与来源路由逐项对应，不同保存机制分别验证。</p></>}
        <p className="fw-codec-note">此处为交互示例，工具栏仍待逐控件对齐。未解析真实文档、计算公式或执行宏；布局、编辑格式与保存协议按技术方案验证。</p>
      </div></div>
      {notes && slides && <aside className="fw-comments"><h3>批注</h3>{model.comments.map((c, i) => <p key={i}>{c}</p>)}<textarea aria-label="新批注" value={comment} onChange={e => setComment(e.target.value)} placeholder="添加批注…" /><button className="fw-pill" disabled={!comment.trim() || readOnly} onClick={() => {
          change({
            ...model,
            comments: [...model.comments, comment.trim()]
          });
          setComment('');
        }}>添加</button></aside>}
    </div>
    {spreadsheet && <nav className="fw-sheet-tabs" aria-label="工作表">{model.sheets.map((s, i) => <button key={i} className={sheet === i ? 'active' : ''} onClick={() => {
        setSheet(i);
        setActiveCell([0, 0]);
      }}>{s.name}</button>)}<span>{editing ? '编辑中 · 原型模拟保存' : '只读预览'}</span></nav>}
  </div>;
}
function MarkdownCell() {
  return <div><h2>文件工作区</h2><p>Markdown 单元支持静态呈现，源代码不会执行。</p></div>;
}
function PdfFixture({
  kind,
  onDownload = () => {}
}) {
  const review = kind === 'pdf-review';
  const [page, setPage] = useState(1),
    [zoom, setZoom] = useState(100),
    [zoomMenu, setZoomMenu] = useState(false);
  const [docked, setDocked] = useState(false),
    [annotation, setAnnotation] = useState(false),
    [selection, setSelection] = useState('');
  const [comment, setComment] = useState(''),
    [requests, setRequests] = useState([]);
  const scroll = useRef(null),
    pageNodes = useRef([]),
    zoomValue = useRef(100);
  const zoomTo = value => {
    const next = Math.max(30, Math.min(800, value));
    zoomValue.current = next;
    setZoom(next);
  };
  useEffect(() => {
    if (review || !scroll.current) return;
    const el = scroll.current;
    const wheel = e => {
      if (!e.ctrlKey) return;
      e.preventDefault();
      const previous = zoomValue.current;
      let next = Math.max(30, Math.min(800, previous * Math.exp(-Math.max(-20, Math.min(20, e.deltaY)) * .005)));
      const snap = [50, 75, 100, 125, 150, 200, 300, 400].find(n => Math.abs(n - next) / n < .02);
      if (snap) next = snap;
      const rect = el.getBoundingClientRect(),
        x = e.clientX - rect.left,
        y = e.clientY - rect.top;
      const targetX = (el.scrollLeft + x) * next / previous - x,
        targetY = (el.scrollTop + y) * next / previous - y;
      zoomTo(next);
      requestAnimationFrame(() => {
        el.scrollLeft = targetX;
        el.scrollTop = targetY;
      });
    };
    el.addEventListener('wheel', wheel, {
      passive: false
    });
    return () => el.removeEventListener('wheel', wheel);
  }, [review]);
  useEffect(() => {
    if (review || !scroll.current) return;
    const visible = new Map();
    const observer = new IntersectionObserver(entries => {
      entries.forEach(e => visible.set(Number(e.target.dataset.page), e.intersectionRatio));
      const highest = [...visible].sort((a, b) => b[1] - a[1])[0];
      if (highest?.[1] > 0) setPage(highest[0]);
    }, {
      root: scroll.current,
      threshold: [0, .1, .25, .5, .75, 1]
    });
    pageNodes.current.filter(Boolean).forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, [review]);
  const goto = n => {
    setPage(n);
    pageNodes.current[n - 1]?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  };
  return <div className={'fw-artifact fw-pdf ' + (review ? 'fw-pdf-review' : '')} onKeyDown={e => {
    if (e.key === 'Escape' && !comment) {
      setAnnotation(false);
      setZoomMenu(false);
    }
  }}>
    {review ? <div className="fw-pdf-pager"><button aria-label="上一页" disabled={page === 1} onClick={() => setPage(p => p - 1)}><ArrowLeft size={16} /></button><span>{page} / 3</span><button aria-label="下一页" disabled={page === 3} onClick={() => setPage(p => p + 1)}><ArrowRight size={16} /></button></div> : <div className="fw-artifact-tools">
      <span className="fw-push" /><div className="fw-zoom-control"><button aria-label="PDF 缩放" aria-expanded={zoomMenu} onClick={() => setZoomMenu(!zoomMenu)}>{Math.round(zoom)}% <ChevronDown size={12} /></button>{zoomMenu && <div className="fw-zoom-menu" role="menu">{[25, 50, 100, 150, 200].map(n => <button key={n} role="menuitemradio" aria-checked={zoom === n} onClick={() => {
            zoomTo(n);
            setZoomMenu(false);
          }}>{zoom === n ? <Check size={12} /> : <span />}{n}%</button>)}<button role="menuitem" onClick={() => {
            zoomTo(Math.min(100, ((scroll.current?.clientWidth || 644) - 44) / 600 * 100));
            setZoomMenu(false);
          }}>适合宽度</button></div>}</div>
      <button className="fw-icon" title="下载文档示例" aria-label="下载文档示例" onClick={onDownload}><Download size={16} /></button><button className={'fw-icon ' + (annotation ? 'active' : '')} title="PDF 评论" aria-label="PDF 评论" onClick={() => setAnnotation(!annotation)}><MessageSquare size={16} /></button>
    </div>}
    <div className="fw-artifact-main">{!review && <nav className={'fw-thumbnails ' + (docked ? 'docked' : 'undocked')} aria-label="PDF 页面缩略图"><button className="fw-dock-thumbnails" onClick={() => setDocked(!docked)}><List size={12}/><span className="fw-thumbnail-dock-label">{docked ? '取消停靠' : '停靠缩略图'}</span></button>{[1, 2, 3].map(n => <button key={n} aria-label={'第 ' + n + ' 页'} aria-current={n === page ? 'page' : undefined} onClick={() => goto(n)}><span>文件浏览工作区</span><small>{n}</small></button>)}</nav>}
      <div className="fw-artifact-scroll" ref={scroll} onMouseUp={() => {
        if (annotation) setSelection(window.getSelection()?.toString() || '');
      }}>
        {(review ? [page] : [1, 2, 3]).map(n => <article key={n} ref={el => {
          pageNodes.current[n - 1] = el;
        }} data-page={n} className="fw-paper fw-pdf-page" style={{
          zoom: review ? 1 : zoom / 100,
          userSelect: review ? 'none' : 'text'
        }}>
          <small>{kind === 'tex' ? 'TeX → PDF' : 'PDF'} · 第 {n} 页</small><h1>{['文件浏览工作区', '交互与状态', '验收与交付'][n - 1]}</h1><p>项目维护根目录；会话保存面板与标签状态；文件身份由宿主与路径共同确定。</p><p>文件保存时检查外部变化。冲突需要保留草稿，不能直接覆盖。</p>{!review && <button className="text-button" onClick={() => goto(n === 3 ? 1 : n + 1)}>文档内部链接：第 {n === 3 ? 1 : n + 1} 页</button>}
          <p className="fw-codec-note">页面与文字为合成示例。未解析真实 PDF、验证字体或加密文件。</p>
        </article>)}
      </div>
      {!review && annotation && <aside className="fw-comments"><h3>评论</h3><p>{selection ? '已选择：' + selection : '选择文档文字，或添加当前页评论。'}</p><textarea aria-label="PDF 评论内容" value={comment} onChange={e => setComment(e.target.value)} /><button className="fw-pill" disabled={!comment.trim()} onClick={() => {
          setRequests(r => [...r, {
            page,
            text: comment,
            selection
          }]);
          setComment('');
          setSelection('');
        }}>添加到请求（模拟）</button>{requests.map((r, i) => <p key={i}>第 {r.page} 页：{r.text}</p>)}<p className="fw-codec-note">演示任务评论；不写入 PDF，也不发送给模型。区域选取、批处理开关和任务桥接仍待对齐。</p></aside>}
    </div>
  </div>;
}
function NotebookFixture({
  onDownload = () => {}
}) {
  const [copied, setCopied] = useState(''),
    [source, setSource] = useState(false);
  const copy = async (key, value) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
    } catch {
      setCopied('failed');
    }
  };
  const code = 'print("WillYou")';
  const block = (key, value) => <div className="fw-notebook-code"><button className="fw-icon" aria-label={'复制 ' + key} onClick={() => copy(key, value)}>{copied === key ? <Check size={14} /> : <Copy size={14} />}</button><pre>{value}</pre></div>;
  return <div className="fw-artifact"><div className="fw-artifact-tools"><strong>M9 实验笔记</strong><small>3 个单元</small><span className="fw-push" /><button className="fw-icon" aria-label="下载 Notebook 示例" onClick={onDownload}><Download size={16} /></button></div><div className="fw-artifact-scroll"><div className="fw-paper">
    <details className="fw-notebook-cell" open><summary>Markdown</summary><MarkdownCell /></details>
    <details className="fw-notebook-cell" open><summary>Code <span className="fw-notebook-run" title="只读预览不支持运行"><Play size={12} /> Run 1</span></summary><details><summary>Code</summary>{block('code source', code)}</details><pre>WillYou</pre><button className="text-button" onClick={() => setSource(!source)}><Code2 size={14} />{source ? '收起 HTML 源码' : '查看 HTML 输出源码'}</button>{source ? block('HTML output', '<p>这是 Notebook 的 HTML 输出</p>') : <iframe title="Notebook HTML 输出" sandbox="" srcDoc="<meta http-equiv='Content-Security-Policy' content=&quot;default-src 'none'; style-src 'unsafe-inline'&quot;><p>这是 Notebook 的 HTML 输出</p>" />}<details><summary>错误输出示例</summary><pre>ValueError: 示例输入不完整</pre></details></details>
    <details className="fw-notebook-cell" open><summary>Raw</summary>{block('raw source', 'Raw cell content')}</details>{copied === 'failed' && <p role="status">复制失败，请选择内容手动复制。</p>}<p className="fw-codec-note">只读输出示例；不运行代码。完整 MIME 优先级及大输出状态按 PRD 验收。</p>
  </div></div></div>;
}
