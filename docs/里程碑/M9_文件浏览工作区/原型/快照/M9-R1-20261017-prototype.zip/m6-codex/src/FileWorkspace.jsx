import { useEffect, useRef, useState } from 'react';
import { File, FileCode2, FileText, FileSearch, FolderOpen, Folder, ChevronDown, ChevronRight, X, Plus, Search, PanelRight, Maximize2, Minimize2, Code2, Copy, ExternalLink, Check, AlertCircle, RotateCcw, Save, Download, Sun, Moon, Settings2, MoreHorizontal, Undo2, Redo2, WrapText, TextSelect, Image, FileSpreadsheet, FileSliders, Play, Pause, ZoomIn, ZoomOut, ArrowLeft, ArrowRight, Pin } from 'lucide-react';
import { FILES, FILE_BY_PATH, SAMPLE_MD, fileKey, initialWorkspace, openFile, closeFile, restoreFile, treeRows } from './file-workspace-model.mjs';
import iconMap from './m9-icon-map.json';
import { FileArtifactPreview } from './FileArtifactPreview';
import { workspaceScope, searchFiles, serializeWorkspaceStore, documentKey, fileScenario, setFileScenario, editDraft, commitDraft, acceptDisk, captureSelection, applySelectionEdit, artifactModel, updateArtifactCell, updateArtifactSlide } from './file-workspace-model.mjs';
import './file-workspace.css';
const STORAGE = 'willyou-m9-prototype-v1';
const load = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE)) || {};
  } catch {
    return {};
  }
};
const isText = f => ['code', 'markdown', 'html', 'svg', 'large'].includes(f?.kind);
function Icon({
  file,
  size = 16
}) {
  const path = typeof file === 'string' ? file : file?.path || '';
  const name = path.split('/').pop().toLowerCase();
  const ext = name.split('.').slice(1);
  let type = iconMap.fileNameTokens[name];
  for (let i = 0; !type && i < ext.length; i++) {
    const suffix = ext.slice(i).join('.');
    type = iconMap.completeExtensionOverrides[suffix] || iconMap.extensionTokens[suffix];
  }
  type = type || iconMap.defaultType;
  const colors = iconMap.palette[iconMap.colorRoles[type]];
  return <svg className="fw-file-icon" width={size} height={size} viewBox="0 0 16 16" aria-hidden="true" style={{
    '--file-light': colors?.light || 'currentColor',
    '--file-dark': colors?.dark || 'currentColor'
  }}><use href={iconMap.spriteUrl + '#' + iconMap.idPrefix + type} /></svg>;
}
const Button = ({
  icon: C,
  label,
  onClick,
  active,
  disabled
}) => <button className={'fw-icon ' + (active ? 'active' : '')} title={label} aria-label={label} onClick={onClick} disabled={disabled}><C size={17} strokeWidth={1.65} /></button>;
function ContentSearch({
  onClose,
  onOpen,
  scope
}) {
  const historyKey = 'willyou-m9-search-history-v1';
  const loadHistory = () => {
    try {
      const all = JSON.parse(localStorage.getItem(historyKey)) || [];
      return all.find(x => x.scope === scope) || {
        queries: [],
        masks: []
      };
    } catch {
      return {
        queries: [],
        masks: []
      };
    }
  };
  const [query, setQuery] = useState(''),
    [mask, setMask] = useState(''),
    [selected, setSelected] = useState(0),
    [history, setHistory] = useState(loadHistory);
  const [hits, setHits] = useState([]),
    [busy, setBusy] = useState(false),
    [spinner, setSpinner] = useState(false),
    [error, setError] = useState('');
  const input = useRef(null),
    historyIndex = useRef(-1),
    historyDraft = useRef('');
  const remember = (rememberQuery = false) => {
    const next = {
      queries: rememberQuery && query ? [query, ...history.queries.filter(x => x !== query)].slice(0, 30) : history.queries,
      masks: mask.trim() ? [mask.trim(), ...history.masks.filter(x => x !== mask.trim())].slice(0, 20) : history.masks
    };
    setHistory(next);
    try {
      const all = JSON.parse(localStorage.getItem(historyKey)) || [];
      localStorage.setItem(historyKey, JSON.stringify([{
        scope,
        ...next
      }, ...all.filter(x => x.scope !== scope)].slice(0, 20)));
    } catch {
      setError('原型搜索历史未能保存。');
    }
  };
  useEffect(() => {
    if (!query) {
      setHits([]);
      setBusy(false);
      setSpinner(false);
      return;
    }
    setBusy(true);
    setError('');
    let valid = true;
    const spin = setTimeout(() => {
      if (valid) setSpinner(true);
    }, 500);
    const work = setTimeout(() => {
      try {
        const m = mask.trim(),
          negate = m.startsWith('!'),
          raw = negate ? m.slice(1) : m;
        const escaped = raw.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\?/g, '.').replace(/\u0000/g, '.*');
        const pattern = raw ? new RegExp('(?:^|/)' + escaped + '$', 'i') : null;
        const results = FILES.filter(f => !pattern || (negate ? !pattern.test(f.path) : pattern.test(f.path))).flatMap(f => f.text.split('\n').map((line, i) => ({
          path: f.path,
          line,
          number: i + 1,
          column: line.toLowerCase().indexOf(query.toLowerCase()) + 1
        })).filter(r => r.column > 0)).slice(0, 100);
        if (valid) {
          setHits(results);
          setSelected(0);
        }
      } catch {
        if (valid) setError('搜索条件无法解析。请修改文件范围后重试。');
      } finally {
        if (valid) {
          setBusy(false);
          setSpinner(false);
          clearTimeout(spin);
        }
      }
    }, 50);
    return () => {
      valid = false;
      clearTimeout(work);
      clearTimeout(spin);
    };
  }, [query, mask, scope]);
  const pick = r => {
    if (!r || busy) return;
    remember(true);
    onOpen(r.path, query, r.number, r.column);
  };
  const keydown = e => {
    if (e.isComposing) return;
    if (e.key === 'Escape') {
      e.stopPropagation();
      onClose();
    }
    if (e.key === 'ArrowUp' && e.target === input.current && (selected === 0 || !hits.length)) {
      e.preventDefault();
      if (historyIndex.current === -1) historyDraft.current = query;
      if (historyIndex.current + 1 < history.queries.length) setQuery(history.queries[++historyIndex.current]);
      return;
    }
    if (e.key === 'ArrowDown' && e.target === input.current && historyIndex.current >= 0) {
      e.preventDefault();
      historyIndex.current--;
      setQuery(historyIndex.current < 0 ? historyDraft.current : history.queries[historyIndex.current]);
      return;
    }
    if (['ArrowDown', 'ArrowUp'].includes(e.key)) {
      e.preventDefault();
      setSelected(i => Math.max(0, Math.min(hits.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1))));
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      pick(hits[selected]);
    }
  };
  return <div className="fw-modal-scrim" onClick={onClose}><section className="fw-dialog fw-search-dialog" role="dialog" aria-modal="true" aria-label="在文件中搜索" onClick={e => e.stopPropagation()} onKeyDown={keydown}>
    <div className="fw-find"><Search size={18} /><input ref={input} aria-label="搜索文件内容" autoFocus maxLength={256} placeholder="搜索所有文件中的文本…" value={query} onChange={e => {
          setQuery(e.target.value);
          setSelected(0);
          historyIndex.current = -1;
        }} /><Button icon={X} label="关闭内容搜索" onClick={onClose} /></div>
    <div className="fw-search-mask"><label>文件范围<input aria-label="文件范围" list="m9-file-masks" maxLength={256} value={mask} onChange={e => setMask(e.target.value)} onKeyDown={e => {
            if (['ArrowUp', 'ArrowDown', 'Enter'].includes(e.key)) e.stopPropagation();
            if (e.key === 'Enter') {
              remember();
              input.current?.focus();
            }
          }} placeholder="*.ts" /><datalist id="m9-file-masks">{history.masks.map(m => <option key={m} value={m} />)}</datalist></label><span>{spinner ? '搜索中…' : hits.length + ' 条匹配'}{hits.length === 100 ? '（最多前100行）' : ''}</span></div>
    <div className="fw-search-results" role="listbox" aria-label="搜索结果" aria-busy={busy}>{hits.map((r, i) => <button key={r.path + ':' + r.number} role="option" aria-selected={selected === i} onMouseEnter={() => setSelected(i)} onClick={() => pick(r)}><code>{r.line.slice(0, r.column - 1)}<mark>{r.line.slice(r.column - 1, r.column - 1 + query.length)}</mark>{r.line.slice(r.column - 1 + query.length)}</code><span title={r.path}><Icon file={r.path} />{r.path}<small>:{r.number}:{r.column}</small></span></button>)}{error && <p role="alert">{error}</p>}{query && !hits.length && !busy && !error && <p>没有匹配内容</p>}{!query && <p>搜索当前目录中的文件内容；↑ 可访问本目录的查询历史。</p>}</div>
    <small>↑↓ 选择 · Enter 打开 · Esc 关闭。原型仅搜索示例文件，glob与取消服务不是实际rg后端。</small>
  </section></div>;
}
function Markdown({
  text,
  overlay = false,
  onOpenImage,
  onImageAction
}) {
  const pictures = text.split('\n').map((line, index) => {
    const m = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    return m ? {
      index,
      alt: m[1],
      src: m[2]
    } : null;
  }).filter(Boolean);
  const [active, setActive] = useState(null),
    [zoom, setZoom] = useState(1),
    [contextImage, setContextImage] = useState(null),
    [failed, setFailed] = useState(false);
  const picture = pictures.find(p => p.index === active),
    position = pictures.findIndex(p => p.index === active);
  const view = useRef(null),
    drag = useRef(null);
  const open = index => {
    setActive(index);
    setZoom(1);
    setFailed(false);
  };
  const move = delta => {
    const next = pictures[position + delta];
    if (next) open(next.index);
  };
  useEffect(() => {
    if (!picture || !view.current) return;
    view.current.focus();
    const el = view.current,
      wheel = e => {
        if (!e.ctrlKey) return;
        e.preventDefault();
        setZoom(z => Math.max(.1, Math.min(8, z * Math.exp(-e.deltaY * .005))));
      };
    el.addEventListener('wheel', wheel, {
      passive: false
    });
    return () => el.removeEventListener('wheel', wheel);
  }, [active]);
  return <><article className="fw-markdown">{text.split('\n').map((line, i) => {
        const image = pictures.find(p => p.index === i);
        if (image) return <button className="fw-md-image" key={i} title="打开嵌入图片" onClick={() => open(i)} onContextMenu={e => {
          e.preventDefault();
          setContextImage(image);
        }}><img src={image.src} alt={image.alt} /></button>;
        return line.startsWith('# ') ? <h1 key={i}>{line.slice(2)}</h1> : line.startsWith('## ') ? <h2 key={i}>{line.slice(3)}</h2> : line.startsWith('- ') ? <p className="fw-bullet" key={i}>- {line.slice(2)}</p> : line ? <p key={i}>{line}</p> : <div className="fw-paragraph-break" key={i} />;
      })}</article>
  {contextImage && <><div className="fw-dismiss" onClick={() => setContextImage(null)} /><div className="fw-menu" role="menu"><button onClick={() => {
          onOpenImage();
          setContextImage(null);
        }}>在新标签打开图片</button><button onClick={() => {
          onImageAction('图片已加入当前任务引用示例');
          setContextImage(null);
        }}>添加到当前任务</button><button onClick={() => {
          onImageAction('复制图片：原型展示入口，尚未调用系统图片剪贴板');
          setContextImage(null);
        }}>复制图片</button><button onClick={() => {
          onImageAction('在文件管理器显示：原型不启动外部应用');
          setContextImage(null);
        }}>在文件管理器中显示</button><button onClick={() => {
          onImageAction('下载图片副本：此入口仅演示');
          setContextImage(null);
        }}>下载副本</button></div></>}
  {picture && <div className={'fw-gallery ' + (overlay ? 'fw-gallery-overlay' : 'fw-gallery-legacy')} role="dialog" aria-modal="true" aria-label={overlay ? '图片只读叠层' : '图片预览'} onKeyDown={e => {
      if (e.target.matches('input,textarea,select,[role=slider],[role=menuitem]')) return;
      if (e.key === 'Escape') setActive(null);
      if (e.key === 'ArrowLeft') move(-1);
      if (e.key === 'ArrowRight') move(1);
    }}>
    <header><span>{overlay ? picture.alt : '图片预览'}</span><div><button onClick={() => onImageAction('图片保存入口已触发（模拟）')}><Download size={16} />{overlay ? '保存' : '下载'}</button><button aria-label="关闭图片预览" onClick={() => setActive(null)}><X size={18} /></button></div></header>
    <div className="fw-gallery-viewport" tabIndex={0} ref={view} onPointerDown={e => {
        drag.current = {
          x: e.clientX,
          y: e.clientY,
          left: e.currentTarget.scrollLeft,
          top: e.currentTarget.scrollTop
        };
        e.currentTarget.setPointerCapture(e.pointerId);
      }} onPointerMove={e => {
        if (drag.current) {
          e.currentTarget.scrollLeft = drag.current.left + drag.current.x - e.clientX;
          e.currentTarget.scrollTop = drag.current.top + drag.current.y - e.clientY;
        }
      }} onPointerUp={() => {
        drag.current = null;
      }} onPointerCancel={() => {
        drag.current = null;
      }}>
      {failed ? <button onClick={() => {
          setFailed(false);
        }}>重试加载图片</button> : <img key={active} src={picture.src} alt={picture.alt} referrerPolicy="no-referrer" draggable={false} style={{
          width: 360 * zoom,
          maxWidth: 'none'
        }} onError={() => setFailed(true)} />}
    </div><footer><button aria-label="上一张图片" disabled={position === 0} onClick={() => move(-1)}><ArrowLeft size={17} /></button><button aria-label="缩小图片" onClick={() => setZoom(z => Math.max(.1, z - .1))}><ZoomOut size={17} /></button><span>{Math.round(zoom * 100)}%</span><button aria-label="放大图片" onClick={() => setZoom(z => Math.min(8, z + .1))}><ZoomIn size={17} /></button><button aria-label="下一张图片" disabled={position === pictures.length - 1} onClick={() => move(1)}><ArrowRight size={17} /></button>{overlay && <span>{position + 1} / {pictures.length}</span>}</footer>
  </div>}</>;
}
function Media({
  kind,
  name,
  onCopy,
  onDownload
}) {
  const [playing, setPlaying] = useState(false),
    [position, setPosition] = useState(0),
    [speed, setSpeed] = useState(1),
    [muted, setMuted] = useState(false),
    [volume, setVolume] = useState(.75),
    [expanded, setExpanded] = useState(false),
    [pip, setPip] = useState(false),
    [menu, setMenu] = useState(false),
    [volumeOpen, setVolumeOpen] = useState(false);
  const resume = useRef(false);
  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => setPosition(p => {
      if (p >= 20) {
        setPlaying(false);
        return 20;
      }
      return Math.min(20, p + .1 * speed);
    }), 100);
    return () => clearInterval(timer);
  }, [playing, speed]);
  const toggle = () => {
    if (position >= 20) setPosition(0);
    setPlaying(p => !p);
  };
  const release = () => {
    if (resume.current) setPlaying(true);
    resume.current = false;
  };
  const time = n => Math.floor(n / 60) + ':' + String(Math.floor(n % 60)).padStart(2, '0');
  return <div className={'fw-media ' + (expanded ? 'fw-media-expanded' : '') + (pip ? ' fw-media-pip' : '')}>
  {kind === 'video' ? <div className="fw-video-frame" tabIndex={0} aria-label="视频画面" onKeyDown={e => {
      if ([' ', 'Enter'].includes(e.key)) {
        e.preventDefault();
        if (!e.repeat) toggle();
      }
    }}><img src="/assets/app-icon.png" alt="WillYou 演示画面" /><h2>文件工作区</h2><p>媒体控件交互示例</p></div> : <strong>{name} · WAV</strong>}
  <div className="fw-media-bar"><Button icon={playing ? Pause : Play} label={playing ? '暂停' : '播放'} onClick={toggle} /><input aria-label="播放进度" type="range" min={0} max={20} step={.1} value={position} onPointerDown={() => {
        resume.current = playing;
        setPlaying(false);
      }} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release} onChange={e => setPosition(+e.target.value)} /><span>{time(position)} / {time(20)}</span>
  {kind === 'video' && <><button aria-label="视频音量" aria-expanded={volumeOpen} onClick={() => setVolumeOpen(!volumeOpen)}>{muted ? '静音中' : '声音'}</button>{volumeOpen && <span className="fw-volume"><button aria-label={muted ? '取消静音' : '静音'} onClick={() => setMuted(!muted)}>{muted ? '取消静音' : '静音'}</button><input aria-label="音量" type="range" min={0} max={1} step={.01} value={muted ? 0 : volume} onChange={e => {
            setVolume(+e.target.value);
            setMuted(false);
          }} /></span>}<button onClick={() => setPip(!pip)}>{pip ? '退出画中画' : '画中画（模拟）'}</button><Button icon={expanded ? Minimize2 : Maximize2} label={expanded ? '退出全屏示例' : '全屏示例'} onClick={() => setExpanded(!expanded)} /></>}
  <Button icon={MoreHorizontal} label="媒体菜单" onClick={() => setMenu(!menu)} /></div>
  {menu && <div className="fw-media-options">{kind === 'audio' && <button onClick={() => {
        onCopy();
        setMenu(false);
      }}>复制路径</button>}<button onClick={() => {
        onDownload();
        setMenu(false);
      }}>{kind === 'video' ? '视频另存为' : '另存副本'}</button>{kind === 'video' && <label>播放速度 <select aria-label="播放速度" value={speed} onChange={e => setSpeed(+e.target.value)}>{[.25, .5, .75, 1, 1.25, 1.5, 1.75, 2].map(v => <option key={v} value={v}>{v}×</option>)}</select></label>}</div>}
  <small>模拟时间轴和控件；不播放真实文件。系统全屏、画中画可用性与 codec 尚未验证。</small></div>;
}
export function FileWorkspace({
  task,
  project,
  dark,
  onTheme,
  onClose
}) {
  const [store, setStore] = useState(load),
    [query, setQuery] = useState(''),
    [menu, setMenu] = useState(null),
    [confirm, setConfirm] = useState(null),
    [demo, setDemo] = useState(false),
    [full, setFull] = useState(false),
    [searchMode, setSearchMode] = useState(false),
    [status, setStatus] = useState(''),
    [auto, setAuto] = useState(true),
    [find, setFind] = useState(''),
    [finding, setFinding] = useState(false),
    [context, setContext] = useState(''),
    [rich, setRich] = useState(null),
    [dock, setDock] = useState('right'),
    [contentSearch, setContentSearch] = useState(false),
    [wrap, setWrap] = useState(false),
    [selection, setSelection] = useState(null),
    [aiState, setAiState] = useState(null),
    [composing, setComposing] = useState(false),
    [selectedRows, setSelectedRows] = useState([]),
    [reveal, setReveal] = useState(null),
    [remote, setRemote] = useState(false),
    [imageOverlay, setImageOverlay] = useState(false),
    [changedOnly, setChangedOnly] = useState(false),
    [hideGenerated, setHideGenerated] = useState(false),
    [blame, setBlame] = useState(false),
    [extension, setExtension] = useState(false),
    [symbol, setSymbol] = useState(null);
  const roots = [{
    id: 'main',
    hostId: task.hostId || 'local',
    label: project.name || 'WillYou',
    path: task.cwd || project.path || '/workspace/SmartDD'
  }, {
    id: 'extra',
    hostId: task.hostId || 'local',
    label: '共享文档',
    path: '/workspace/shared-docs'
  }];
  const scope = workspaceScope(task.id, roots);
  const state = store[scope] || initialWorkspace(),
    set = fn => setStore(old => ({
      ...old,
      [scope]: typeof fn === 'function' ? fn(old[scope] || initialWorkspace()) : fn
    }));
  const current = state.tabs.find(t => fileKey(t.root, t.path) === state.active),
    file = FILE_BY_PATH[current?.path],
    draft = state.drafts[state.active],
    identity = documentKey(roots, state.active),
    revision = state.revisions?.[state.active] || 0,
    text = draft?.text ?? store.saved?.[identity] ?? file?.text ?? '',
    scenario = fileScenario(state),
    mode = state.mode[state.active] || 'render';
  const editor = useRef(null),
    filter = useRef(null),
    host = useRef(null),
    compose = useRef(false),
    dragged = useRef(null),
    timer = useRef(null),
    historyRef = useRef({}),
    anchor = useRef(null);
  const root = roots.find(r => r.id === state.root) || roots[0],
    activeRoot = roots.find(r => r.id === current?.root) || root;
  const effective = scenario === 'ready' ? file?.kind : scenario;
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE, JSON.stringify(serializeWorkspaceStore(store)));
    } catch {
      setStatus('原型存储已满；当前页内容仍保留。');
    }
  }, [store]);
  useEffect(() => () => clearTimeout(timer.current), []);
  useEffect(() => {
    if (!reveal || !editor.current) return;
    const offset = text.split('\n').slice(0, reveal.number - 1).join('\n').length + (reveal.number > 1 ? 1 : 0) + Math.max(0, (reveal.column || 1) - 1);
    editor.current.focus();
    editor.current.setSelectionRange(offset, offset + reveal.query.length);
    editor.current.scrollTop = Math.max(0, (reveal.number - 3) * 21);
    setReveal(null);
  }, [reveal, text, mode]);
  useEffect(() => {
    setQuery('');
    setMenu(null);
    setRich(null);
  }, [scope]);
  useEffect(() => {
    setSelection(null);
    setAiState(null);
  }, [identity, revision]);
  function scenarioText(value, label) {
    if (file?.kind === 'xlsx') return JSON.stringify(updateArtifactCell(artifactModel(value), 0, 1, 1, label));
    if (file?.kind === 'pptx') {
      const model = artifactModel(value);
      return JSON.stringify(updateArtifactSlide(model, 0, model.slides[0].title + ' · ' + label));
    }
    return value + '\n' + label;
  }
  function setScenario(value, key = state.active) {
    const diskText = value === 'conflict' ? scenarioText(store.saved?.[documentKey(roots, key)] ?? FILE_BY_PATH[key?.split('\u0000')[1]]?.text ?? '', '外部更新') : undefined;
    set(s => setFileScenario(s, key, value, diskText));
  }
  function note(message) {
    setStatus(message);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setStatus(''), 3500);
  }
  function open(path, pin = false, rootId = state.root) {
    set(s => openFile(s, rootId, path, pin));
    setRich(null);
    setMenu(null);
  }
  function save(key = state.active, override = false) {
    if (!state.drafts[key]) return true;
    const outcome = commitDraft({
      ...store,
      [scope]: state
    }, scope, roots, key, {
      override
    });
    if (outcome.result === 'conflict') {
      setStore(old => commitDraft(old, scope, roots, key, {
        override
      }).store);
      setConfirm({
        type: 'conflict',
        key
      });
      return;
    }
    if (outcome.result === 'save-error') {
      note('保存失败：文件不可写。修改仍保留，可重试或另存为。');
      return;
    }
    if (outcome.result !== 'saved') return false;
    setStore(old => commitDraft(old, scope, roots, key, {
      override
    }).store);
    note('已保存到原型示例数据');
    return true;
  }
  useEffect(() => {
    if (!auto || !draft || scenario !== 'ready' || composing) return;
    const id = setTimeout(() => save(), ['xlsx', 'pptx'].includes(file?.kind) ? 500 : 3000);
    return () => clearTimeout(id);
  }, [text, auto, scenario, state.active, scope, composing]);
  function edit(value, record = true) {
    if (record) {
      const h = historyRef.current[identity] || {
        undo: [],
        redo: []
      };
      h.undo.push(text);
      h.redo = [];
      historyRef.current[identity] = h;
    }
    const key = state.active;
    set(s => editDraft(s, key, value, store.saved?.[identity] ?? file?.text ?? ''));
  }
  function undo(redo = false) {
    const h = historyRef.current[identity];
    if (!h) return;
    const from = redo ? h.redo : h.undo,
      to = redo ? h.undo : h.redo;
    if (!from.length) return;
    to.push(text);
    edit(from.pop(), false);
  }
  function switchMode() {
    if (draft && !save()) return;
    set(s => ({
      ...s,
      mode: {
        ...s.mode,
        [s.active]: mode === 'source' ? 'render' : 'source'
      }
    }));
    setRich(null);
  }
  function close(key) {
    if (state.drafts[key]) {
      if (!save(key)) {
        setConfirm({
          type: 'close',
          key
        });
        return;
      }
    }
    set(s => closeFile(s, key));
  }
  function discard(key) {
    set(s => {
      const drafts = {
        ...s.drafts
      };
      delete drafts[key];
      return closeFile({
        ...s,
        drafts
      }, key);
    });
    setConfirm(null);
  }
  function reorder(key) {
    const source = dragged.current;
    if (!source || source === key) return;
    set(s => {
      const tabs = [...s.tabs],
        a = tabs.findIndex(t => fileKey(t.root, t.path) === source),
        b = tabs.findIndex(t => fileKey(t.root, t.path) === key);
      if (a < 0 || b < 0) return s;
      const [t] = tabs.splice(a, 1);
      tabs.splice(b, 0, {
        ...t,
        preview: false
      });
      return {
        ...s,
        tabs
      };
    });
  }
  function resize(e) {
    e.preventDefault();
    const start = e.clientX,
      w = state.width;
    const move = ev => set(s => ({
      ...s,
      tree: w + start - ev.clientX >= 100,
      width: Math.max(200, Math.min(host.current.clientWidth * .6, w + start - ev.clientX))
    }));
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
  }
  async function copy(value) {
    try {
      await navigator.clipboard.writeText(value);
      note('已复制路径');
    } catch {
      setContext(value);
      note('复制权限不可用，路径已显示在下方供选择。');
    }
    setMenu(null);
  }
  function download(path, rootId = current?.root || state.root) {
    const item = FILE_BY_PATH[path];
    const key = fileKey(rootId, path);
    const blob = new Blob([state.drafts[key]?.text ?? store.saved?.[documentKey(roots, key)] ?? item.text], {
      type: 'text/plain'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = path.split('/').pop() + (isText(item) ? '' : '.preview.txt');
    a.click();
    URL.revokeObjectURL(a.href);
    setMenu(null);
    note(isText(item) ? '已下载原型示例内容' : '已下载交互示例文本，不是实际文档文件');
  }
  function keys(e) {
    if (compose.current || e.isComposing) return;
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      e.stopPropagation();
      save();
    }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      setFinding(true);
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === 't') {
      e.preventDefault();
      set(s => restoreFile(s));
    }
    if (e.key === 'Escape') {
      setMenu(null);
      setFinding(false);
      setConfirm(null);
    }
  }
  const rows = (query ? searchFiles(FILES, query).map(f => ({
    path: f.path,
    name: f.path.split('/').pop(),
    folder: false,
    depth: 0
  })) : treeRows(FILES, state.expanded)).filter(r => !searchMode || !query || FILE_BY_PATH[r.path]?.text?.toLowerCase().includes(query.toLowerCase()) || r.path.toLowerCase().includes(query.toLowerCase()));
  const contentMatches = searchMode && query ? FILES.filter(f => f.text.toLowerCase().includes(query.toLowerCase())) : [];
  const matchedRows = searchMode && query ? [...new Map([...rows, ...contentMatches.map(f => ({
    path: f.path,
    name: f.path.split('/').pop(),
    folder: false,
    depth: 0
  }))].map(r => [r.path, r])).values()] : rows;
  const displayed = matchedRows.filter(r => !changedOnly || ['AGENTS.md', 'src/main.ts', 'package.json', 'CHANGELOG.md'].includes(r.path)).filter(r => !hideGenerated || r.path !== 'package.json');
  function selectRow(e, r) {
    if (r.folder) {
      set(s => ({
        ...s,
        expanded: s.expanded.includes(r.path) ? s.expanded.filter(p => p !== r.path) : [...s.expanded, r.path]
      }));
      return;
    }
    let next = [r.path];
    if (e.shiftKey && anchor.current) {
      const a = displayed.findIndex(x => x.path === anchor.current),
        b = displayed.findIndex(x => x.path === r.path);
      next = displayed.slice(Math.min(a, b), Math.max(a, b) + 1).filter(x => !x.folder).map(x => x.path);
    } else if (e.metaKey || e.ctrlKey) next = selectedRows.includes(r.path) ? selectedRows.filter(p => p !== r.path) : [...selectedRows, r.path];else anchor.current = r.path;
    setSelectedRows(next);
    if (next[0]) open(next[0]);
  }
  return <aside ref={host} className={'file-workspace ' + (full ? 'fw-full' : '') + (dock === 'bottom' ? ' fw-bottom' : '')} aria-label="M9 文件工作区原型" onKeyDown={keys}>
  <div className="fw-tabs" role="tablist" aria-label="文件标签">{state.tabs.map(t => {
        const key = fileKey(t.root, t.path);
        return <div key={key} className={'fw-tab ' + (key === state.active ? 'selected ' : '') + (t.preview ? 'preview' : '')} draggable onDragStart={() => dragged.current = key} onDragOver={e => e.preventDefault()} onDrop={() => reorder(key)} onContextMenu={e => {
          e.preventDefault();
          setMenu({
            type: 'tab',
            key
          });
        }}><button role="tab" aria-selected={key === state.active} onClick={() => {
            set(s => ({
              ...s,
              active: key
            }));
            setRich(null);
          }} onDoubleClick={() => open(t.path, true, t.root)} title={roots.find(r => r.id === t.root)?.path + '/' + t.path}><Icon file={t.path} /><span>{t.path.split('/').pop()}</span>{state.drafts[key] && <span className="fw-dirty" aria-label="未保存" />}</button><button className="fw-tab-close" aria-label={'关闭 ' + t.path} onClick={() => close(key)}><X size={14} /></button></div>;
      })}<Button icon={Plus} label="查找并打开文件" onClick={() => {
        set(s => ({
          ...s,
          tree: true
        }));
        filter.current?.focus();
      }} /><span className="fw-push" /><Button icon={full ? Minimize2 : Maximize2} label={full ? '退出文件聚焦' : '聚焦文件工作区'} onClick={() => setFull(!full)} /><Button icon={PanelRight} label="隐藏文件工作区" onClick={onClose} /></div>
  <div className="fw-toolbar"><div className="fw-breadcrumb">{[activeRoot.label, ...(current?.path.split('/') || [])].map((part, i, arr) => <span key={i}><button title={activeRoot.path + '/' + arr.slice(1, i + 1).join('/')} className={i === arr.length - 1 ? 'current' : ''} onClick={() => setMenu(menu?.type === 'crumb' ? null : {
            type: 'crumb',
            prefix: arr.slice(1, i + 1).join('/'),
            root: current?.root || state.root
          })}>{part}</button>{i < arr.length - 1 && <ChevronRight size={13} />}</span>)}</div><div className="fw-tools"><Button icon={FileSearch} label="在文件中搜索" active={searchMode} onClick={() => setContentSearch(true)} />{file && ['markdown', 'svg', 'html'].includes(file.kind) && <button className="fw-pill" onClick={switchMode}><Code2 size={16} />{mode === 'source' ? '查看文档' : '查看源代码'}</button>}<Button icon={MoreHorizontal} label="文件查看选项" onClick={() => setMenu({
          type: 'viewer'
        })} /><Button icon={FolderOpen} label="切换文件目录" active={state.tree} onClick={() => set(s => ({
          ...s,
          tree: !s.tree
        }))} /><button className="fw-pill" onClick={() => setMenu(menu?.type === 'external' ? null : {
          type: 'external'
        })}><ExternalLink size={16} />打开<ChevronDown size={13} /></button></div></div>
  <div className="fw-body"><section className="fw-content" aria-label="文件内容">
   {finding && <div className="fw-find"><Search size={15} /><input autoFocus aria-label="查找当前文件" value={find} onChange={e => setFind(e.target.value)} placeholder="查找当前文件" /><span>{find ? text.split(find).length - 1 : 0} 个匹配</span><Button icon={X} label="关闭查找" onClick={() => setFinding(false)} /></div>}
   {draft && <div className="fw-save-strip"><span>{scenario === 'save-error' ? '保存失败，修改已保留' : scenario === 'conflict' ? '文件已被外部修改' : '未保存的修改'}</span><button onClick={() => save()}>保存</button>{scenario === 'conflict' && <button onClick={() => setConfirm({
            type: 'conflict',
            key: state.active
          })}>查看差异</button>}</div>}
   {file && isText(file) && <div className="fw-editor-tools"><Button icon={Undo2} label="撤销" disabled={!historyRef.current[identity]?.undo.length} onClick={() => undo()} /><Button icon={Redo2} label="重做" disabled={!historyRef.current[identity]?.redo.length} onClick={() => undo(true)} /><Button icon={WrapText} label="自动换行" active={wrap} onClick={() => setWrap(!wrap)} /><Button icon={Copy} label="复制文件内容" onClick={() => copy(text)} /><span className="fw-push" /><button onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
          }} disabled={!selection || file.kind === 'large'}>编辑所选文本</button></div>}
   {blame && file && <div className="fw-save-strip"><span>示例作者 · a1b2c3 · 初始文件（只读归属演示）</span><button onClick={() => setBlame(false)}>关闭行归属</button></div>}
   {symbol && <div className="fw-symbol-panel"><strong>{symbol === 'definition' ? '定义' : '引用'} · workspace</strong><button onClick={() => {
            open('src/main.ts', true);
            setSymbol(null);
          }}>src/main.ts:4:14</button><button onClick={() => {
            open('src/renderer/App.tsx', true);
            setSymbol(null);
          }}>src/renderer/App.tsx:2:10</button><small>LSP 返回示例，不执行语言服务器。</small><Button icon={X} label="关闭符号结果" onClick={() => setSymbol(null)} /></div>}
   {extension ? <div className="fw-empty"><FileSliders size={28} /><h2>扩展文件查看器</h2><p>演示扩展 · {current?.path} · {remote ? '远程' : '本地'}资源</p><p>资源匹配、权限、读取失败及 ifMatch 冲突按技术方案验证。</p><button onClick={() => setScenario('conflict')}>模拟资源版本冲突</button>{scenario === 'conflict' && <p role="alert">资源已更新。请重新读取后重试，旧版本未覆盖。</p>}<button onClick={() => setExtension(false)}>返回默认查看器</button></div> : !file ? <div className="fw-empty"><File size={30} /><p>选择文件以开始浏览</p><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}>重新打开关闭的文件</button></div> : effective === 'loading' ? <div className="fw-empty" aria-busy="true"><span className="fw-loading" />正在读取文件…<button onClick={() => setScenario('ready')}>完成加载（模拟）</button></div> : ['missing', 'unreadable', 'too-large', 'unsupported', 'root-missing'].includes(effective) ? <div className="fw-empty"><AlertCircle size={28} /><h2>{{
              missing: '文件不存在',
              unreadable: '无法读取文件',
              'too-large': '文件过大',
              unsupported: '不支持预览此文件',
              'root-missing': '工作目录不可用'
            }[effective]}</h2><p>{{
              missing: '文件可能已移动或删除。现有草稿会保留。',
              unreadable: '检查文件权限后重试。',
              'too-large': '此示例超过文本预览限制，请使用外部应用。',
              unsupported: '可以通过外部应用打开此文件。',
              'root-missing': '重新连接或更新项目目录后重试。'
            }[effective]}</p><button className="fw-pill" onClick={() => setScenario('ready')}><RotateCcw size={15} />重试</button><button onClick={() => setMenu({
            type: 'external'
          })}>使用外部应用打开</button></div> : rich ? <FileArtifactPreview key={rich + state.active} kind={rich} readOnly onDownload={() => download(current.path)} /> : file.kind === 'svg' && mode !== 'source' ? <div className="fw-image"><img src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(text)} alt="SVG 文件预览" /></div> : file.kind === 'html' && mode !== 'source' ? <iframe className="fw-html" title="HTML 文件文档预览" sandbox="" srcDoc={text} /> : file.kind === 'markdown' && mode !== 'source' ? <Markdown key={identity} text={text} overlay={imageOverlay} onOpenImage={() => open('resources/app-icon.png', true)} onImageAction={note} /> : ['code', 'html', 'svg', 'large', 'markdown'].includes(file.kind) ? <div className="fw-editor"><div className="fw-line-numbers" aria-hidden="true">{text.split('\n').map((_, i) => <div key={i}>{i + 1}</div>)}</div><textarea ref={editor} aria-label="文件编辑器" spellCheck={false} value={text} readOnly={file.kind === 'large'} onChange={e => edit(e.target.value)} style={{
            whiteSpace: wrap ? 'pre-wrap' : 'pre'
          }} onContextMenu={e => {
            e.preventDefault();
            setMenu({
              type: 'code'
            });
          }} onSelect={e => setSelection(captureSelection({
            scope: scope,
            identity,
            revision,
            text: e.currentTarget.value,
            start: e.currentTarget.selectionStart,
            end: e.currentTarget.selectionEnd
          }))} onCompositionStart={() => {
            compose.current = true;
            setComposing(true);
          }} onCompositionEnd={() => {
            compose.current = false;
            setComposing(false);
          }} />{file.kind === 'large' && <div className="fw-readonly">10–20 MiB 文本：只读预览示例</div>}</div> : file.kind === 'image' ? <div className="fw-image"><img src={file.text} alt={file.path} /></div> : ['audio', 'video'].includes(file.kind) ? <Media key={identity} kind={file.kind} name={file.path.split('/').pop()} onCopy={() => copy(activeRoot.path + '/' + current.path)} onDownload={() => download(current.path)} /> : <FileArtifactPreview key={scope + ':' + identity + ':' + (state.reloads?.[state.active] || 0)} kind={file.kind} initialValue={text} onDraft={edit} onDownload={() => download(current.path)} />}
  </section>{state.tree && <><div className="fw-tree-resizer" role="separator" tabIndex={0} aria-label="调整目录宽度" aria-orientation="vertical" aria-valuenow={state.width} aria-valuemin={200} aria-valuemax={600} onPointerDown={resize} onKeyDown={e => {
          if (['ArrowLeft', 'ArrowRight'].includes(e.key)) {
            e.preventDefault();
            set(s => ({
              ...s,
              width: Math.max(200, Math.min(600, s.width + (e.key === 'ArrowLeft' ? 10 : -10)))
            }));
          }
        }} /><aside className="fw-tree" style={{
          width: state.width
        }} aria-label="目录树">{!remote && <label className="fw-filter"><Search size={14} /><input ref={filter} placeholder={searchMode ? '搜索文件内容…' : '筛选文件…'} aria-label="筛选文件" value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => {
              if (e.key === 'Escape') {
                e.stopPropagation();
                setQuery('');
              }
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                host.current.querySelector('[role=treeitem]')?.focus();
              }
            }} />{query && <button aria-label="清除筛选" onClick={() => setQuery('')}><X size={13} /></button>}</label>}{changedOnly && <label className="fw-generated"><input type="checkbox" checked={hideGenerated} onChange={e => setHideGenerated(e.target.checked)} />筛除生成文件 {hideGenerated ? "1" : ""}</label>}<div className="fw-root"><select aria-label="选择工作目录" value={state.root} onChange={e => {
              set(s => ({
                ...s,
                root: e.target.value
              }));
              setQuery('');
            }}>{roots.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}</select></div><div className="fw-tree-scroll" role="tree" onKeyDown={e => {
            if (e.isComposing) return;
            const items = [...e.currentTarget.querySelectorAll('[role=treeitem]')],
              i = items.indexOf(document.activeElement);
            if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') {
              e.preventDefault();
              setSelectedRows(displayed.filter(r => !r.folder).map(r => r.path));
              return;
            }
            if (['ArrowUp', 'ArrowDown', 'Home', 'End'].includes(e.key)) {
              e.preventDefault();
              items[e.key === 'Home' ? 0 : e.key === 'End' ? items.length - 1 : Math.max(0, Math.min(items.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))]?.focus();
            }
          }}>{displayed.map(r => <button key={r.path} role="treeitem" aria-expanded={r.folder ? state.expanded.includes(r.path) : undefined} aria-selected={selectedRows.length ? selectedRows.includes(r.path) : state.active === fileKey(state.root, r.path)} data-path={r.path} tabIndex={0} className={'fw-tree-row ' + (state.active === fileKey(state.root, r.path) ? 'selected' : '')} style={{
              paddingLeft: 3 + (query ? 0 : r.depth * 16)
            }} title={root.path + '/' + r.path} onClick={e => selectRow(e, r)} onDoubleClick={() => !r.folder && open(r.path, true)} onKeyDown={e => {
              if (r.folder && ['ArrowLeft', 'ArrowRight'].includes(e.key)) {
                e.preventDefault();
                set(s => ({
                  ...s,
                  expanded: e.key === 'ArrowRight' ? [...new Set([...s.expanded, r.path])] : s.expanded.filter(p => p !== r.path)
                }));
              }
              if (e.key === 'Enter' && !r.folder) {
                e.preventDefault();
                open(r.path, true);
              }
            }} onContextMenu={e => {
              if (r.folder || remote) return;
              e.preventDefault();
              setMenu({
                type: 'file',
                path: r.path,
                folder: r.folder
              });
            }}>{r.folder ? state.expanded.includes(r.path) ? <ChevronDown size={13} /> : <ChevronRight size={13} /> : <span className="fw-tree-spacer" />}{!r.folder && <Icon file={r.path} />}<span>{query ? r.path : r.name}</span></button>)}{!displayed.length && <p className="fw-no-results">未找到匹配的文件</p>}</div></aside></>}</div>
  <footer className="fw-footer"><button onClick={() => setDemo(!demo)}><Settings2 size={13} />M9 交互样例<ChevronDown size={12} /></button><span role="status">{status || '示例数据 · 未连接真实文件'}</span><span className="fw-push" />{current && <span>{current.preview ? '预览' : '已固定'} · UTF-8</span>}<Button icon={dark ? Sun : Moon} label="切换原型主题" onClick={onTheme} /></footer>
  {demo && <div className="fw-demo"><label>场景<select aria-label="文件状态场景" value={scenario} onChange={e => {
          setScenario(e.target.value);
          if (['conflict', 'save-error'].includes(e.target.value) && file) edit(scenarioText(text, '本地修改'));
        }}>{[['ready', '正常'], ['loading', '读取中'], ['conflict', '外部修改冲突'], ['save-error', '保存失败'], ['missing', '已删除'], ['unreadable', '无读取权限'], ['too-large', '过大'], ['unsupported', '未知二进制'], ['root-missing', '根不可用']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label><label><input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)} />自动保存（3秒）</label><button onClick={() => set(s => restoreFile(s))} disabled={!state.closed.length}><RotateCcw size={14} />恢复关闭标签</button><button onClick={() => setMenu({
        type: 'formats'
      })}>全部格式与入口</button><label><input type="checkbox" checked={remote} onChange={e => {
          setRemote(e.target.checked);
          setQuery('');
          setMenu(null);
        }} />远程环境（模拟）</label><label><input type="checkbox" checked={changedOnly} onChange={e => {
          setChangedOnly(e.target.checked);
          setQuery('');
        }} />变化文件上下文</label><label><input type="checkbox" checked={imageOverlay} onChange={e => setImageOverlay(e.target.checked)} />图片新叠层（模拟开关）</label><button onClick={() => note('原型状态已在本浏览器保存；刷新可检查恢复。')}>检查恢复</button></div>}
  {context && <div className="fw-context"><File size={14} /><span>{context}</span><Button icon={X} label="移除文件引用" onClick={() => setContext('')} /></div>}
  {contentSearch && <ContentSearch scope={JSON.stringify([root.hostId, [root.path]])} onClose={() => setContentSearch(false)} onOpen={(path, line, number, column) => {
      open(path, true);
      set(s => ({
        ...s,
        mode: {
          ...s.mode,
          [fileKey(state.root, path)]: 'source'
        }
      }));
      setFinding(true);
      setFind(line);
      setReveal({
        number,
        column,
        query: line
      });
      setContentSearch(false);
    }} />}
  {menu && <><div className="fw-dismiss" onClick={() => setMenu(null)} /><div className={'fw-menu ' + (menu.type === 'formats' ? 'fw-format-menu' : '')} role="menu">
   {menu.type === 'viewer' && <><strong>文件查看选项</strong><button onClick={() => {
            setWrap(!wrap);
            setMenu(null);
          }}>自动换行 {wrap ? '已开' : '已关'}</button><button onClick={() => {
            setBlame(!blame);
            setMenu(null);
          }}>只读行归属（示例）</button><button onClick={() => {
            setExtension(!extension);
            setMenu(null);
          }}>扩展文件查看器（模拟）</button><button onClick={() => copy(activeRoot.path + '/' + current?.path)}>复制路径</button><button onClick={() => copy(text)}>复制文件内容</button></>}
   {menu.type === 'code' && <><button onClick={() => {
            setSymbol('definition');
            setMenu(null);
          }}>转到定义</button><button onClick={() => {
            setSymbol('references');
            setMenu(null);
          }}>查找引用</button><button disabled={!selection} onClick={() => {
            setAiState({
              phase: 'request',
              selection,
              instruction: ''
            });
            setMenu(null);
          }}>编辑所选文本（模拟）</button><button onClick={() => copy(selection?.text || text)}>复制</button></>}
   {menu.type === 'file' && <><strong>{menu.path.split('/').pop()}</strong><button onClick={() => setMenu({
            type: 'external',
            path: menu.path
          })}><ExternalLink size={15} />打开方式</button>{!menu.folder && <button onClick={() => download(menu.path, state.root)}><Download size={15} />另存为…</button>}<button onClick={() => copy(root.path + '/' + menu.path)}><Copy size={15} />复制路径</button><button onClick={() => {
            setContext(root.path + '/' + menu.path);
            setMenu(null);
          }}>添加到会话引用（模拟）</button></>}
   {menu.type === 'tab' && <><button onClick={() => {
            set(s => ({
              ...s,
              tabs: s.tabs.map(t => fileKey(t.root, t.path) === menu.key ? {
                ...t,
                preview: false
              } : t)
            }));
            setMenu(null);
          }}><Pin size={15} />固定标签</button><button onClick={() => {
            close(menu.key);
            setMenu(null);
          }}>关闭标签</button><button onClick={() => {
            set(s => restoreFile(s));
            setMenu(null);
          }}>重新打开关闭的标签</button><button onClick={() => {
            setDock(dock === 'right' ? 'bottom' : 'right');
            setMenu(null);
          }}>{dock === 'right' ? '移到底部面板' : '移到右侧面板'}</button></>}
   {menu.type === 'crumb' && <><strong>跳转目录</strong>{FILES.filter(f => f.path.startsWith(menu.prefix.includes('.') ? menu.prefix.split('/').slice(0, -1).join('/') : menu.prefix)).map(f => <button key={f.path} onClick={() => open(f.path, false, menu.root)}><Icon file={f} />{f.path}</button>)}</>}
   {menu.type === 'external' && <><strong>打开方式</strong>{['Visual Studio Code', '系统默认应用', '在 Finder 中显示'].map(label => <button key={label} onClick={() => {
            note(label + '：原型仅模拟，未启动外部应用');
            setMenu(null);
          }}><ExternalLink size={15} />{label}</button>)}<button onClick={() => copy(activeRoot.path + '/' + (menu.path || current?.path || ''))}><Copy size={15} />复制路径</button></>}
   {menu.type === 'formats' && <><strong>文件类型 / 会话产物入口（模拟）</strong>{FILES.map(f => <button key={f.path} onClick={() => open(f.path, true)}><Icon file={f} />{f.path}</button>)}<hr />{['csv', 'tsv', 'ipynb', 'tex', 'pdf', 'pdf-review', 'docx', 'xlsx', 'pptx'].map(kind => <button key={kind} onClick={() => {
            setRich(kind);
            setMenu(null);
          }}>以会话产物打开 {kind.toUpperCase()}</button>)}</>}
  </div></>}
  {aiState && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label="所选文本编辑模拟"><h2>编辑所选文本</h2><p>仅演示文件中的选择、指令、差异与确认流程；未调用模型。</p><pre className="fw-ai-selection">{aiState.selection?.text}</pre>{aiState.phase === 'request' ? <><textarea aria-label="编辑指令" className="fw-ai-prompt" placeholder="描述你希望怎样修改…" value={aiState.instruction} onChange={e => setAiState(a => ({
            ...a,
            instruction: e.target.value
          }))} /><div className="fw-dialog-actions"><button onClick={() => setAiState(null)}>取消</button><button disabled={!aiState.instruction.trim()} onClick={() => setAiState(a => ({
              ...a,
              phase: 'review',
              result: a.selection.text + ' // 修改示例'
            }))}>生成修改（模拟）</button></div></> : <><h3>修改后</h3><pre className="fw-ai-selection">{aiState.result}</pre><div className="fw-dialog-actions"><button onClick={() => setAiState(null)}>拒绝</button><button onClick={() => {
              const next = applySelectionEdit(aiState.selection, {
                scope: scope,
                identity,
                revision,
                text,
                replacement: aiState.result
              });
              if (next === null) note('文件或选区已变化，请重新选择后编辑；未应用旧建议。');else edit(next);
              setAiState(null);
            }}>接受修改</button></div></>}</section></div>}
  {confirm && <div className="fw-modal-scrim"><section className="fw-dialog" role="dialog" aria-modal="true" aria-label={confirm.type === 'close' ? '保留未保存修改' : '文件修改冲突'}>{confirm.type === 'close' ? <><h2>仍有未保存的修改</h2><p>可以继续查看并保存，或者放弃此文件的修改。</p><div className="fw-dialog-actions"><button onClick={() => setConfirm(null)}>继续查看</button><button className="fw-danger" onClick={() => discard(confirm.key)}>放弃修改并关闭</button></div></> : <><h2>文件已在外部更改</h2><p>请核对本地草稿与磁盘版本。选择前不会覆盖任何一方。</p><div className="fw-conflict-columns"><div><strong>磁盘版本（模拟）</strong><pre>{state.fileStates?.[confirm.key]?.diskText ?? ''}</pre></div><div><strong>本地草稿</strong><pre>{state.drafts[confirm.key]?.text ?? ''}</pre></div></div><div className="fw-dialog-actions"><button onClick={() => setConfirm(null)}>继续编辑</button><button onClick={() => {
              const diskText = state.fileStates?.[confirm.key]?.diskText;
              if (diskText === undefined) {
                note('磁盘示例尚未读取，保留当前修改。');
                return;
              }
              const targetIdentity = documentKey(roots, confirm.key);
              delete historyRef.current[targetIdentity];
              setStore(old => ({
                ...old,
                [scope]: acceptDisk(old[scope] || state, confirm.key),
                saved: {
                  ...old.saved,
                  [targetIdentity]: diskText
                }
              }));
              setConfirm(null);
            }}>采用磁盘版本</button><button onClick={() => {
              save(confirm.key, true);
              setConfirm(null);
            }}>保留本地并保存</button></div></>}</section></div>}
 </aside>;
}
