// pdf.js 加载（浏览器）。pdf.js 与 worker 均为独立懒加载块，首屏不加载。不使用 eval，不加载远程字体/资源。
let enginePromise = null;
export function loadPdfEngine() {
  return enginePromise ||= Promise.all([import('pdfjs-dist/build/pdf.mjs'), import('pdfjs-dist/build/pdf.worker.min.mjs?url')]).then(([pdfjs, worker]) => {
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
    return pdfjs;
  });
}
