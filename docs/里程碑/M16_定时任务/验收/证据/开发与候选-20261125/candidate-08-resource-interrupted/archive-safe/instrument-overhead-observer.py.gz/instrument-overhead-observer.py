import json, pathlib, time, datetime, psutil
root=pathlib.Path('/private/tmp/willyou-m16-f36-run-C7ZhLG')
cohort=json.loads(pathlib.Path('/private/tmp/willyou-m16-f36-cohort-r6OvBP/expected-cohort.json').read_text())
qa=pathlib.Path('/private/tmp/willyou-m16-f36-qa')
rows={r['pid']: r['before'] for r in cohort['rows']}
first_os=json.loads((root/'resource-samples.jsonl').read_text().splitlines()[0])
first_native=json.loads((root/'native-cpu-samples.jsonl').read_text().splitlines()[0])
roles={69052:('wrapper',None),69079:('driver',None),first_os['samplerPid']:('osSampler',str(qa/'resource-sampler/resource-sampler.py')),first_native['collectorPid']:('nativeCollector',str(qa/'resource-sampler/cpu_collector.py'))}
bound={}
for pid,(role,script) in roles.items():
 p=psutil.Process(pid); birth=p.create_time(); exe=p.exe()
 if script:
  assert p.ppid()==69079 and script in p.cmdline(),role
 else:
  expected=rows[pid]; rb=expected['bsd']; assert exe==expected['path'] and abs(birth-(rb['birthSec']+rb['birthUsec']/1e6))<.001,role
 bound[pid]=(role,birth,exe,script)
with (root/'independent-instrumentation-partial.jsonl').open('x') as out:
 for tick in range(200):
  row={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicNs':time.monotonic_ns(),'scope':'Only unique private test harness identities, not product PIDs; partial observation starting mid-run','rows':[]}
  for pid,(role,birth,exe,script) in bound.items():
   r={'pid':pid,'role':role,'birth':birth,'exe':exe}
   try:
    p=psutil.Process(pid)
    if p.create_time()!=birth or p.exe()!=exe:r['state']='gone-or-reused'
    else:
     c=p.cpu_times();r.update(state='alive',user=c.user,system=c.system)
   except (psutil.NoSuchProcess,psutil.ZombieProcess):r['state']='gone'
   except psutil.AccessDenied:r['state']='read-denied'
   row['rows'].append(r)
  out.write(json.dumps(row)+'\n');out.flush()
  if tick==0:print(json.dumps(row),flush=True)
  if all(r['state']!='alive' for r in row['rows']):break
  time.sleep(10)
