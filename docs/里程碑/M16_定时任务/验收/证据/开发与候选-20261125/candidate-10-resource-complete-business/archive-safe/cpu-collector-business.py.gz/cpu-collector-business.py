#!/Library/Frameworks/Python.framework/Versions/3.11/bin/python3
"""Known fixed identities + actual group aggregate; no transient child traversal."""
import sys,json,time,os
from cpu_collector import Native
from coalition_accounting import CoalitionTracker,identity_valid,cid_valid
N=Native();anchors={};runtime={};runtimeDepartures={};tracker=None;base=None;previous=None;metrics=None;helperPages=None;capture=0
for line in sys.stdin:
 try:
  req=json.loads(line)
  if req.get('type')=='stop':print(json.dumps({'kind':'cpu-stopped','collectorPid':os.getpid(),'scopeApproved':False,'captures':capture}),flush=True);break
  start=time.monotonic_ns()
  if req['type']=='init':
   assert tracker is None;initial=[];metrics=set(req['electronMetricPids']);helperPages={x['pageId']:x['pids'][0]for x in req['helpers']if len(x['pids'])==1};assert len(helperPages)==5
   for a in req['anchors']:
    pid=a['pid'];r=N.read(pid);b,u=r['bsd'],r['rusage'];expect={'identity':str(pid)+':'+str(u['startAbstime']),'birth':{'pid':pid,'startAbstime':u['startAbstime'],'birthSec':b['birthSec'],'birthUsec':b['birthUsec'],'path':r['path']},'role':a['role'],'path':r['path']}
    valid=r['path']==a['expectedPath'] and abs(b['birthSec']+b['birthUsec']/1e6-a['createdAtEpochSeconds'])<.001 and identity_valid(r,expect,N.uid,N.abi)
    if not valid and a['role']=='actual-fixed-runtime':runtimeDepartures[pid]={'pid':pid,'atNs':time.monotonic_ns(),'reason':'initial owned optional runtime left before native identity could be bound; unattributed, no further query'};continue
    assert valid;initial.append(r);(runtime if a['role']=='actual-fixed-runtime' else anchors)[pid]=expect
   assert len(anchors)+len(runtime)+len(runtimeDepartures)==len(req['anchors']);tracker=CoalitionTracker(N,anchors);cohort=tracker.capture('initial-business');assert len(cohort['resourceIds'])==1;previous=base=cohort['counters'][0];row={'kind':'cpu-initialized','initialReads':initial,'coalition':cohort}
  else:
   assert tracker;assert metrics==set(req['electronMetricPids']);assert helperPages=={x['pageId']:x['pids'][0]for x in req['helpers']if len(x['pids'])==1};cohort=tracker.capture('final-business' if req.get('final')else 'capture-business');current=cohort['counters'][0];delta={'actualGroupStartedSinceLast':current['tasks_started']-previous['tasks_started'],'actualGroupExitedSinceLast':current['tasks_exited']-previous['tasks_exited'],'actualGroupNetAlive':current['tasks_started']-current['tasks_exited'],'scope':'transient group task identities not individually attributed; includes instrument/transient/runtime, no per-PID command or scope certification'};previous=current;capture+=1;row={'kind':'cpu-upper-sample','coalition':cohort,'unattributableGroupTransientDelta':delta,'capture':capture,'final':bool(req.get('final'))}
  runtimeMemberChecks=[]
  for pid,expected in runtime.items():
   if pid in runtimeDepartures:continue
   before=N.read(pid)
   if not identity_valid(before,expected,N.uid,N.abi):runtimeDepartures[pid]={'pid':pid,'atNs':time.monotonic_ns(),'reason':'previously-bound known runtime unavailable or changed; no further query; unknown descendant scope not attributed'};continue
   cid=N.coalition_id(pid);after=N.read(pid)
   if not cid_valid(cid,pid)or cid['resourceId']!=cohort['resourceIds'][0]or not identity_valid(after,expected,N.uid,N.abi):runtimeDepartures[pid]={'pid':pid,'atNs':time.monotonic_ns(),'reason':'previously-bound diagnostic runtime changed identity or group; no further query; scope incomplete'};continue
   runtimeMemberChecks.append({'expected':expected,'before':before,'cid':cid,'after':after})
  row.update(requestId=req['requestId'],collectorPid=os.getpid(),collectorIdentity=N.read(os.getpid()),abi=N.abi,anchors=anchors,knownRuntime=runtime,knownRuntimeChecks=runtimeMemberChecks,knownRuntimeDepartures=list(runtimeDepartures.values()),helperPages=helperPages,births={a['identity']:a['birth']for a in list(anchors.values())+list(runtime.values())},startNs=start,endNs=time.monotonic_ns(),scopeApproved=False,gaps=[],diagnosticScope='Only actual fixed retained identities; no transient inventory attempted. Whole-group CPU counter diagnostic superset; original formal proof missing',upperLifetimeSeconds=None);print(json.dumps(row,separators=(',',':')),flush=True)
 except Exception as e:print(json.dumps({'kind':'cpu-collector-error','requestId':req.get('requestId'),'error':type(e).__name__+': '+str(e),'scopeApproved':False}),flush=True)
