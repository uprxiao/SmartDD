#!/Library/Frameworks/Python.framework/Versions/3.11/bin/python3
"""Fixed own identities only. RSS/CPU are diagnostic, not total-workload proof."""
import sys,json,time,os,psutil,pathlib
known={};seeds0=None;initial_unattributable=[];departedRuntime={}

def sample(req):
 global seeds0,initial_unattributable
 start=time.monotonic_ns();wall=time.time_ns();seeds={req['appPid']}|set(req['electronMetricPids'])|set(req['helperPids']);bundle=pathlib.Path(req['appBundle']).resolve();assert str(bundle).startswith('/private/tmp/willyou-m16-f36-resource-pkg-');allowedRuntime=set(req['knownRuntimeExecutables']);assert all(p.startswith('/Users/liubu/.local/share/claude/versions/')or p.startswith('/Applications/Xcode.app/')or p.startswith('/private/tmp/willyou-m16-verified-codex-')for p in allowedRuntime)
 if seeds0 is None:
  seeds0=seeds;app=psutil.Process(req['appPid']);assert app.exe()==str(bundle/'Contents/MacOS/WillYou')
  # Initial private own tree inventory, not a machine-wide scan. Do not retain
  # unidentified transient metadata; no later query/operation to these PIDs.
  candidates={p.pid:p for p in app.children(recursive=True)};candidates.update((p,psutil.Process(p))for p in seeds)
  for pid,p in candidates.items():
   try:
    birth=p.create_time();exe=p.exe();stable=pid in seeds or exe==str(bundle/'Contents/MacOS/WillYou')or exe in allowedRuntime
    if stable:
     assert exe.startswith(str(bundle)+'/')or exe in allowedRuntime
     known[pid]={'birth':birth,'exe':exe,'required':pid in seeds,'reason':'actual-root-metric/helper' if pid in seeds else 'initial-own-verified-runtime'}
    else:initial_unattributable.append({'category':'other-own-short-or-unclassified-child','notSampledFurther':True})
   except (psutil.NoSuchProcess,psutil.ZombieProcess,psutil.AccessDenied)as e:
    if pid in seeds:raise
    initial_unattributable.append({'category':type(e).__name__,'notSampledFurther':True})
  assert seeds<=known.keys()
 assert seeds==seeds0,'retained actual metric/helper identity set changed'
 records=[];errors=[]
 for pid,knownId in sorted(known.items()):
  if pid in departedRuntime:continue
  try:
   p=psutil.Process(pid);born=p.create_time();exe=p.exe();assert born==knownId['birth'] and exe==knownId['exe'];c=p.cpu_times();rss=p.memory_info().rss
   assert p.is_running() and p.create_time()==born and p.exe()==exe
   records.append({'pid':pid,'ppid':p.ppid(),'createdAtEpochSeconds':born,'identity':str(pid)+':'+format(born,'.6f'),'name':p.name(),'executable':exe,'rssBytes':rss,'userCpuSeconds':c.user,'systemCpuSeconds':c.system,'cpuSeconds':c.user+c.system,'threads':p.num_threads(),'ownership':[knownId['reason']]})
  except Exception as e:
   record={'pid':pid,'class':type(e).__name__,'ownership':[knownId['reason']],'atNs':time.monotonic_ns()}
   if knownId['required']:errors.append(record)
   else:departedRuntime[pid]={**record,'classification':'previously-bound diagnostic runtime ended or changed identity; no further query to this identity; workload may continue, scope incomplete'}
 return {'kind':'actual-os-sample','requestId':req['requestId'],'atUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'samplingStartedWallNs':wall,'wallTimeNs':time.time_ns(),'monotonicNs':time.monotonic_ns(),'samplingDurationNs':time.monotonic_ns()-start,'processes':records,'rssTotalBytes':sum(x['rssBytes']for x in records),'readErrors':errors,'samplerPid':os.getpid(),'samplerIdentity':{'pid':os.getpid(),'birth':psutil.Process().create_time(),'exe':psutil.Process().exe()},'logicalCpuCount':psutil.cpu_count(),'systemCpuTimes':psutil.cpu_times()._asdict(),'availableSystemMemoryBytes':psutil.virtual_memory().available,'method':'fixed owned identity RSS/CPU diagnostic only; transient population not attributed; never total-product CPU proof','initialUnattributedChildren':initial_unattributable,'fixedDiagnosticRuntimeDepartures':list(departedRuntime.values()),'transientIdentityScope':'unknown between every interval; no PID operations outside fixed known set'}
for line in sys.stdin:
 try:
  req=json.loads(line)
  if req.get('type')=='stop':print(json.dumps({'kind':'sampler-stopped','pid':os.getpid(),'knownCount':len(known)}),flush=True);break
  print(json.dumps(sample(req)),flush=True)
 except Exception as exc:print(json.dumps({'kind':'sampler-error','class':type(exc).__name__,'message':str(exc)}),flush=True)
