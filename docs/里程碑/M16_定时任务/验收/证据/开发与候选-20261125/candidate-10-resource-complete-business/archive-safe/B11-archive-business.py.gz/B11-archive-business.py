"""Archive only completed, exact isolated business evidence; no HOME, DB, credentials or live probing."""
import pathlib,json,hashlib,gzip,shutil,sys
q=pathlib.Path('/private/tmp/willyou-m16-f36-qa');root=pathlib.Path(sys.argv[1]);cohort=pathlib.Path(sys.argv[2]);dest=root/'archive-safe'
J=lambda p:json.loads(p.read_text());L=lambda p:[json.loads(s)for s in p.read_text().splitlines()];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=J(root/'result.json');O=L(root/'resource-samples.jsonl');N=L(root/'native-cpu-samples.jsonl');bundle=r['bundle'];assert r.get('status') in {'pass','passed','ok','failed','error','diagnostic-complete'} or (root/'independent-cleanup.json').exists(),'live run not archiveable';expected=J(cohort/'expected-cohort.json');assert r['resource']['cohort']['resourceId']==expected['resourceId'];assert r['resource']['cohort']['driverPid']==expected['driverPid']
allowedRuntime={'/private/tmp/willyou-m16-verified-codex-fph7Kw/package/vendor/aarch64-apple-darwin/bin/codex','/Applications/Xcode.app/Contents/Developer/Library/Frameworks/Python3.framework/Versions/3.9/Resources/Python.app/Contents/MacOS/Python','/usr/bin/git'}
allowedInstrument={'/Library/Frameworks/Python.framework/Versions/3.11/Resources/Python.app/Contents/MacOS/Python','/Users/liubu/.hermes/node/bin/node'}
scope=set();instrumentPaths=set();nativeRows=0;unknownCount=0;departures=set()
def check_runtime(path):
 if path is None:return
 assert path.startswith(bundle+'/') or path in allowedRuntime,'unexpected runtime path: raw must stay private pending reduction';scope.add(path)
def check_instrument(path):
 assert path in allowedInstrument or path.startswith(str(cohort)+'/'),'unexpected instrument path';instrumentPaths.add(path)
for row in O:
 check_instrument(row['samplerIdentity']['exe'])
 for p in row['processes']:check_runtime(p['executable'])
 for a in row.get('fixedDiagnosticRuntimeDepartures',[]):
  # A disappeared known process is not proof of a new member. Only archive prior exact identity.
  p=a.get('executable') or a.get('exe') or a.get('path');check_runtime(p)
  if isinstance(a.get('identity'),dict):check_runtime(a['identity'].get('exe') or a['identity'].get('path'))
 for a in row.get('initialUnattributedChildren',[]):
  # This field records counts/categories only. Unexpected detailed records require reduction.
  if isinstance(a,dict):assert 'path' not in a and 'executable' not in a and 'cmdline' not in a
  unknownCount+=1
for row in N:
 assert row['scopeApproved'] is False
 check_instrument(row['collectorIdentity']['path'])
 for k in ('anchors','knownRuntime'):
  for a in row.get(k,{}).values():check_runtime(a['path']);check_runtime(a['birth']['path']);nativeRows+=1
 for b in row.get('births',{}).values():check_runtime(b['path'])
 for a in row.get('initialReads',[]):check_runtime(a['path'])
 for a in row.get('coalition',{}).get('anchorReads',[]):
  for k in ('before','after'):check_runtime(a[k]['path'])
 for a in row.get('knownRuntimeChecks',[]):
  p=a['expected']['path'];check_runtime(p)
  for k in ('before','after'):
   v=a.get(k)
   if v:assert v.get('path') is None or v['path']==p,'reused identity requires private reduction before archive'
 for a in row.get('knownRuntimeDepartures',[]):
  p=a.get('expected',{}).get('path') or a.get('path');check_runtime(p)
  if p:departures.add(p)
  for k in ('before','after','raw'):
   v=a.get(k)
   if isinstance(v,dict):assert not v.get('path') or v['path']==p,'unexpected raw departure metadata; do not archive'
files=[root/x for x in ['resource-samples.jsonl','native-cpu-samples.jsonl','native-parked-observations.jsonl','independent-cleanup.json','B11-adjudication.json','result.json']]+[cohort/x for x in ['expected-cohort.json','payload/run.mjs','controller-result.json','driver-exit.json']]+[q/x for x in ['B11-business-adjudication.py','B11-cleanup-observer-business.py','B11-archive-business.py','cohort-source/controller-business-codex-fixed.mjs','cohort-source/wrapper-business-codex.m']]+[q/'business-sampler'/k for k in r['samplerFiles']]
files.extend(sorted(root.glob('resource-minute-*.json')))
# Controller/exit timing files are private metadata only, no inherited environment or key material.
# Do not include wrapper-config.private.json, HOME, sqlite, application stderr or request logs standalone.
manifest={'scope':'Frozen C10 actual isolated native CLI business endurance; fixed known exact identities and test instrument. Unknown transient individual membership is deliberately not observed or attributed. No private HOME/DB/credentials. Original raw unmodified; gzip byte exact. This is not formal whole-resource passing evidence.','pin':r['pin'],'driverSha':r['driverSha256'],'privacyAudit':{'actualOsSamples':len(O),'actualNativeSamples':len(N),'nativeIdentityRows':nativeRows,'knownRuntimeOutsideBundle':sorted(scope&allowedRuntime),'knownInstrumentPaths':sorted(instrumentPaths),'knownDeparturePaths':sorted(departures),'initialUnattributedCategoryEntriesAcrossRows':unknownCount},'artifacts':[]}
for f in files:
 assert f.is_file(),str(f);h=sha(f);assert f.name!='run.mjs'or h==r['driverSha256'];assert f.name not in r['samplerFiles']or h==r['samplerFiles'][f.name]
dest.mkdir(exist_ok=False)
for f in files:
 h=sha(f);out=dest/(f.name+'.gz')
 with f.open('rb')as src,out.open('wb')as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as z:shutil.copyfileobj(src,z)
 assert hashlib.sha256(gzip.decompress(out.read_bytes())).hexdigest()==h and sha(f)==h;manifest['artifacts'].append({'original':str(f),'originalBytes':f.stat().st_size,'originalSHA256':h,'archive':str(out),'archiveBytes':out.stat().st_size,'archiveSHA256':sha(out),'roundTripByteExact':True})
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(str(dest),len(files),sum(x['archiveBytes']for x in manifest['artifacts']))
