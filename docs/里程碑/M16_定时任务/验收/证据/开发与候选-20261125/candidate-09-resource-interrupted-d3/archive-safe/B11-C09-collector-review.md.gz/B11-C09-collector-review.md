# B11 C08 原中止、C09 独立计量修订（私有验收准备，非产品改动）

## 原事实（保留，不重写）

- C08 `9f276…` 真实固定 5 页，5 暖机＋25 正式 MCP 命令；0/5/10/15/20min 实际回执。原 native CLI `willyou-app` 在本机当前 CLI 能力计划未注入（另有实际退出127），不能把 MCP 途径称为原 CLI I/A 完整通过。
- 独占 Darwin resource coalition 171636 与外部 controller 1567 不同。正常计量到 1345.062106583s。capture271 父 App PID69081 初始 child inventory 包含36736；随后读取 BSD/rusage/path 时全部 ESRCH，末 inventory 替换为36737，父 child 累计增长31670 Mach tick（该机125/3纳秒）。唯一严格 native gap `unresolved-reap-or-orphan`，原 driver 作为失败触发退出。不能声称该短命 PID 的真实文件名或一定已 wait。
- 同一区间内完整 coalition native counter 仍有效；启动到截止 `tasks_started` 965→16215, `tasks_exited` 930→16180，净活35保持；两类增量都15250（约11.34个/s），最后一次 counter 各增长48。这支持频繁短寿命进程自然出现和结束；不能仅据净活相等证明该特定PID的回收或所有未观测进程从未逃逸。
- 直接观测产品/runtime 29稳定 PID 的 idle CPU 下界3.882%；按 idle 区间整个独立组上界6.372%；原始保守组起点→截止上界8.272%。中途独立 observer 仪器测量约1.775%（只能描述部分时间，不从全时长减）。整个资源组是上界；大于5%不证明实际产品超阈。正式30min、25/30min、RSS终点、<5%均未验收完成。app 正常0/null退出，独立核42精确PID、5组helper全部20私有条目、两个本轮端口均清场；原始证据和17项SHA压缩清单仍在 C08 run-C7ZhLG。

## 不把 collector 瞬时观测竞态等价为产品失败或跳过证明

- 原具备严格 missing gate 的 native tree 与 coalition 是相互独立的证据。原 M12 P079 probe007 实际受控双fork/PPID变1退出子进程仍计入同一resource coalition，约50.545ms被85.404ms整体增量覆盖；P103完整封闭源链及19xx项核查才给历史CPU范围通过。该历史验证在当时原CLI、固定源、固定 native 工具下有效，不自动证明现行MCP/实际模型 runtime 源闭包。
- 修订外部 driver：完整 1800s、0/5/10/15/20/25/30点、35+5、5s固定采样、原阈值与正常退出不变。若只出现已核父身份的 `unresolved-reap-or-orphan`、所有失败为原 child ESRCH、父自身仍为原身份、前/后family真实记录齐全、coalition所有 anchor/计数仍合法，继续保存完整长度的**原始**数据。该 gap 永久入单独缺项，不删除，不置scopeApproved，不算0、不伪装通过；只有为了得到原时长实际RSS及其他行为才续采。其余身份变化、合成流失败、持有 owner/真实固定 helper 失效、coalition ID/计数变动与权限失败等按原硬门槛停止依赖，保留完整证据。不重复重启，不直接用第二次样本掩盖第一次 gap。
- 对新采样范围增加已观测的真实持续 runtime PID 的 birth/exe/CID 绑定，检查真实际安装的执行器、MCP helper、固定 browser daemon。已观测成员均归同一个本轮唯一 cohort；外部采集仪器本身单独核归属。保留原 native tree/raw 与原psutil记录；粗粒度 system aggregate 不作产品CPU。
- 实际 OS cohort 对已回收、短寿命、可核同组的普通子进程有真实累计意义。需核历史内核/实际 probe支持的 fork/exec/setsid继承、现行选定普通受管调用路径、已观测所有 provider/MCP/runtime归属，不能用未知闭源runtime推测替代完整性证明。必要时以新的纯本机短命子进程和同一当前系统真实 native计数验证；不使用真实站点/登录/用户数据，不做任意进程操作。任何未知孤儿仍独立未决，不因持续采样而被豁免。

## C09 仪器 CPU 从起点直接测，不依赖终点猜测

- C09 独立 clone 已 pin `721378…`，18个关键hash一致，后续不能同时用这一唯一 clone 路径启动另一应用（避免实际 psutil 归属污染）。原 release 另由协调者分配。
- 新独立 outside-cohort observer 在内部 driver 的 1800s clock0 前确认 wrapper、driver、两个 sampler 都是精确 PID/birth/exe，实际 native resourceId为本轮 CID，并记录首笔真实累计CPU；driver 等已就绪后才开始时钟。observer ≈5s cadence、monotonic时间、每次身份/CID前后读，终点在正常退出前；记录 observer 本身归外部CID。只读精确本轮身份，不扫描/发信号给日常实例。可先用独立短进程验证首尾时序。
- CPU收口同时给出 (1) 原group conservative完整上界，(2) 分 idle 区间的 group上界，(3) 直接产品/实际 runtime survivors CPU 下界并分角色，(4) 同窗口已测仪器CPU。只有可审计的 exact identity/CID 和共同 monotonic 区间下，将已测仪器CPU的**下界**从对应组上界中扣除；禁止用 lifetime、部分区间平均或退出缺口推补第一半段。忙命令窗与 idle窗分离，严格只扣测量区间完全落入对应原始闲段。如仍有无法证明的遗漏，上界与下界跨过5%时保持未定，不能宣称整条绿。
- 真实 final 仍用原 Q&A/正常退出验证；所有原始 read gaps 原因和实际判断应另列。两项预检：回放截断 capture271/真实正常无gap和改造的负控（非ESRCH/anchor变/计数倒退/未绑定父）证明新 driver 只继续测量、不转换判据；独立短程真实 native native CPU/CID 仪器起止与数据采样完整。预检不算正式整例。

## 复验进入条件

协调者明确分配真实C09共享UI和长测资源；先完成短预检（合成静态同样5页/真实执行器、无用户凭据），确认 CPU scope proof 的可审计前置；重跑完整 1800s 不降低原RSS、原CPU判据并保留原C08中止。MCP途径仍保留与原CLI合同差异、本机arm64与其他硬件S层缺项。正式用例按整条统计，不以此次改造及观察通过数替代。
