// Diagnostic continuation only: an unresolved transient stays unresolved forever.
export function classifyNativeSample(row, previous, expectedResourceId, expectedOwnHelperPath) {
 const gaps=row.gaps??[];const reported=[];const errors=[];
 const cid=row.coalition;const counter=cid?.counters?.[0];
 if(!cid||cid.resourceIds?.length!==1||cid.resourceIds[0]!==expectedResourceId||counter?.resourceId!==expectedResourceId||counter.rc!==0||counter.errno!==0||!(counter.tasks_started>=counter.tasks_exited)||!Object.values(cid.bindings??{}).every(v=>v===expectedResourceId))errors.push('actual-cohort-mismatch');
 for(const gap of gaps){
  const key=`${gap.capture}:${gap.code}:${gap.pid??'none'}:${gap.parent??'none'}`;
  if(previous.has(key)){reported.push(previous.get(key));continue;}
  const matched=(row.races??[]).find(r=>r.kind==='child-missing-before-read'&&r.reapOrOrphanUnresolved&&r.pid===gap.pid&&r.parent===gap.parent);
  const family=(row.races??[]).find(r=>r.pid===gap.parent&&r.kind==='family-changed-during-scan');
  const parent=(row.nodes??[]).find(n=>n.pid===gap.parent&&n.anchor);const expected=row.anchors?.[String(gap.parent)];
  const nativeIdentityValid=(sample)=>sample?.bsd?.pid===gap.parent&&sample?.bsd?.bytes===row.abi?.bsdSize&&sample?.bsd?.errno===0&&sample?.rusage?.rc===0&&sample?.rusage?.errno===0&&!sample.rusage.exitAbstime&&sample?.rusage?.startAbstime===expected?.birth?.startAbstime&&sample?.path===expected?.path;
  const raw=matched?.raw;
  const exactMissing=raw?.pid===gap.pid&&raw?.bsd?.bytes===0&&raw?.bsd?.errno===3&&raw?.rusage?.rc===-1&&raw?.rusage?.errno===3&&raw?.path===null&&raw?.pathRc===0&&raw?.pathErrno===3;
  const helper=(row.nodes??[]).find(n=>n.pid===gap.pid&&n.parentFromInventory===gap.parent&&!n.anchor);const hf=helper?.first,hl=helper?.last,helperRace=(row.races??[]).find(r=>r.pid===gap.pid&&r.parent===gap.parent&&r.kind==='unreaped-parent-binding-needs-post-inventory');
  const exactKnownHelper=gap.code==='new-unreaped-parent-binding-raced'&&typeof expectedOwnHelperPath==='string'&&hf?.path===expectedOwnHelperPath&&hf?.pathRc>0&&hf.pathErrno===0&&hf.bsd?.bytes===row.abi?.bsdSize&&hf.bsd.errno===0&&hf.bsd.pid===gap.pid&&hf.bsd.ppid===gap.parent&&hf.bsd.uid===parent?.first?.bsd?.uid&&hf.rusage?.rc===0&&hf.rusage.errno===0&&!hf.rusage.exitAbstime&&hl?.rusage?.rc===0&&hl.rusage.errno===0&&hl.rusage.startAbstime===hf.rusage.startAbstime&&hl.rusage.exitAbstime>=hf.rusage.startAbstime&&hl.bsd?.bytes===0&&hl.bsd.errno===3&&hl.path===null&&hl.pathRc===0&&hl.pathErrno===3&&helper.parentListBindingConfirmedAfterRead===false&&helperRace?.rusageStartAbstime===hf.rusage.startAbstime;
  const originalExactMissing=gap.code==='unresolved-reap-or-orphan'&&exactMissing;
  if(gap.capture!==row.capture||!(originalExactMissing||exactKnownHelper)||!family?.before?.includes(gap.pid)||family?.after?.includes(gap.pid)||family.parentAfterChildRaw<family.parentBeforeChildRaw||!nativeIdentityValid(parent?.first)||!nativeIdentityValid(parent?.last)||cid?.bindings?.[String(gap.parent)]!==expectedResourceId){errors.push('unclassified-native-gap:'+key);continue;}
  // Measured parent/coalition remains valid. Still no identity proof for missing child.
  const unresolved={key,gap,raw,ownHelperIdentity:exactKnownHelper?{first:hf,last:hl,parentBindingRaced:true}:null,parentInventory:family,parentAnchor:expected,classification:'diagnostic-collection-may-continue; scope not resolved',scopeApproved:false};previous.set(key,unresolved);reported.push(unresolved);
 }
 return {continueMeasurement:errors.length===0,scopeApproved:false,unresolved:reported,errors,classification:gaps.length?'transient-gap-preserved-unproven':'no-diagnostic-gaps-in-this-collector'};
}
