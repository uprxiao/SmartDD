"""Independent passive check of actual own test-owned identities after natural exit."""
import json,pathlib,sys,psutil,datetime,hashlib,socket,urllib.parse
root=pathlib.Path(sys.argv[1]);result=json.loads((root/'result.json').read_text());assert root.resolve().parent==pathlib.Path('/private/tmp') and root.name.startswith('willyou-m16-f36-run-');assert pathlib.Path(result['userData']).resolve().parent==root.resolve()
raw=[json.loads(line) for line in (root/'resource-samples.jsonl').read_text().splitlines()];native=[json.loads(line) for line in (root/'native-cpu-samples.jsonl').read_text().splitlines()];bundle=pathlib.Path(result['bundle']).resolve();assert str(bundle).startswith('/private/tmp/willyou-m16-f36-resource-pkg-');expected={}
for s in raw:
 for p in s['processes']:expected[(p['pid'],p['createdAtEpochSeconds'],p['executable'])]='actual-os-sample'
unknownNativeBirths=set()
for row in native:
 for p in row.get('births',{}).values():
  if p['birthSec'] is not None and p['birthUsec'] is not None and p['path']:expected[(p['pid'],p['birthSec']+p['birthUsec']/1e6,p['path'])]='native-birth'
  else:unknownNativeBirths.add(p['pid'])
 for node in row.get('nodes',[]):
  for a in (node['first'],node['last']):
   if a['bsd']['bytes']==row['abi']['bsdSize'] and a['bsd']['pid']==node['pid'] and a['path']:expected[(a['pid'],a['bsd']['birthSec']+a['bsd']['birthUsec']/1e6,a['path'])]='observed-native-node-birth'
for r in result['resource']['cohort']['rows']:
 if r['pid'] not in [result['resource']['cohort']['driverPid'],result['resource']['cohort']['wrapperPid']]:continue
 old=r['before'];expected[(r['pid'],old['bsd']['birthSec']+old['bsd']['birthUsec']/1e6,old['path'])]='dedicated-wrapper-or-driver'
partial=root/'independent-instrumentation-partial.jsonl'
if partial.exists():
 for x in json.loads(partial.read_text().splitlines()[0])['rows']:expected[(x['pid'],x['birth'],x['exe'])]='independent-harness-identity'
complete=root/'instrument-cpu-complete.jsonl'
if complete.exists():
 for x in json.loads(complete.read_text().splitlines()[0])['records']:
  b=x['expected']['birth'];expected[(x['pid'],b['birthSec']+b['birthUsec']/1e6,x['expected']['path'])]='independent-harness-identity'
observations=[]
for (pid,birth,exe),source in sorted(expected.items()):
 r={'pid':pid,'birth':birth,'exe':exe,'source':source}
 try:
  p=psutil.Process(pid);same=abs(p.create_time()-birth)<.001 and p.exe()==exe;r['status']='alive-exact-identity' if same else 'gone-or-reused'
 except psutil.NoSuchProcess:r['status']='gone'
 except psutil.AccessDenied:r['status']='unknown-read-denied'
 observations.append(r)
paths=set()
for s in raw:
 for h in s['helpers']:
  for g in h['generations']:
   p=pathlib.Path(g['dir']);assert p.parent==pathlib.Path('/private/tmp') and p.name.startswith('wy-ab-')
   for name in g['socketNames']:
    assert pathlib.PurePath(name).name==name
    paths.add(p/name)
files=[{'path':str(p),'exists':p.exists(),'isSocket':p.is_socket()} for p in sorted(paths)]
port_file=pathlib.Path(result['userData'])/'DevToolsActivePort'
ports=[('synthetic-server',urllib.parse.urlparse(result['fixture']['origin']).port)]
if port_file.exists():ports.append(('actual-own-devtools',int(port_file.read_text().splitlines()[0])))
endpoints=[]
for role,port in ports:
 assert 1024<port<65536
 with socket.socket() as s:s.settimeout(.5);code=s.connect_ex(('127.0.0.1',port))
 endpoints.append({'role':role,'port':port,'connectEx':code,'listeningAtProbe':code==0})
none=[r for r in observations if r['status'] not in ['gone','gone-or-reused']]
print(json.dumps({'purpose':'Only exact recorded private test identities, known sockets and known fixture endpoints, passive independently after App quit. No signal or cleanup action.','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'appExit':result.get('exit'),'appExitError':result.get('exitError'),'status':result.get('status'),'candidateHashStill':hashlib.sha256((bundle/'Contents/Resources/app.asar').read_bytes()).hexdigest(),'identities':observations,'unverifiedTransientBirths':sorted(unknownNativeBirths),'notConfirmedGone':none,'helperSocketAndMetadata':files,'endpoints':endpoints,'allExactKnownPidsAbsent':not none,'allOwnHelperSocketsAbsent':not any(p['isSocket'] for p in files),'allKnownEndpointsNotListening':not any(e['listeningAtProbe'] for e in endpoints)},indent=2,ensure_ascii=False))
