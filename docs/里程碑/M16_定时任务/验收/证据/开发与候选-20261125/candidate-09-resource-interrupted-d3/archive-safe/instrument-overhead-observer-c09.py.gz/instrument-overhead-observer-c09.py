"""Outside-cohort instrument-only native cumulative CPU observer, no product I/O or signals."""
import sys,json,pathlib,time,datetime,os,psutil
qa=pathlib.Path('/private/tmp/willyou-m16-f36-qa');sys.path.insert(0,str(qa/'resource-sampler'))
from cpu_collector import Native
from coalition_accounting import identity_valid,cid_valid
cohortRoot=pathlib.Path(sys.argv[1]).resolve();assert cohortRoot.parent==pathlib.Path('/private/tmp') and cohortRoot.name.startswith('willyou-m16-f36-cohort-');C=json.loads((cohortRoot/'expected-cohort.json').read_text());N=Native();ownCid=N.coalition_id(os.getpid());assert cid_valid(ownCid,os.getpid()) and ownCid['resourceId'] in C['externalResourceIds'] and ownCid['resourceId']!=C['resourceId'];assert os.getuid()==C['uid']
for attempt in range(1200):
 try:q=json.loads((cohortRoot/'instrument-request.private.json').read_text());break
 except (FileNotFoundError,json.JSONDecodeError):
  if (cohortRoot/'driver-exit.json').exists():raise SystemExit(0)
  time.sleep(.2)
else:raise RuntimeError('driver instrumentation request timed out')
root=pathlib.Path(q['runRoot']).resolve();assert root.parent==pathlib.Path('/private/tmp') and root.name.startswith('willyou-m16-f36-run-');assert q['nonce']==C['nonce'] and q['driverPid']==C['driverPid'] and q['resourceId']==C['resourceId'];report=json.loads((root/'result.json').read_text());assert report['pin']==C['pin'] and report['driverSha256']==C['driverSha'] and report['root']==str(root)
base={r['pid']:r['before']for r in C['rows']};roles={'wrapper':C['wrapperPid'],'driver':C['driverPid'],'osSampler':q['samplerPid'],'nativeCollector':q['collectorPid']};assert len(set(roles.values()))==4
known={}
for role,pid in roles.items():
 x=N.read(pid);b,u=x['bsd'],x['rusage'];assert b['bytes']==N.abi['bsdSize'] and b['pid']==pid and b['uid']==os.getuid() and u['rc']==u['errno']==0 and u['startAbstime'] and not u['exitAbstime']
 if role in ['wrapper','driver']:
  y=base[pid];assert (x['path'],b['birthSec'],b['birthUsec'],u['startAbstime'])==(y['path'],y['bsd']['birthSec'],y['bsd']['birthUsec'],y['rusage']['startAbstime'])
 else:
  script=qa/'resource-sampler'/('resource-sampler.py' if role=='osSampler' else 'cpu_collector.py');P=psutil.Process(pid);assert P.ppid()==C['driverPid'] and str(script) in P.cmdline();assert b['ppid']==C['driverPid']
 expected={'path':x['path'],'birth':{'pid':pid,'birthSec':b['birthSec'],'birthUsec':b['birthUsec'],'startAbstime':u['startAbstime']}};known[role]=expected

# Initial 29 observed own stable identities from the already-proven actual App inventory.
# Diagnostic runtime membership is independent of the four instrumentation-role counters.
bound_runtime={};bundle=report['bundle'];allowed_runtime={'/Users/liubu/.local/share/claude/versions/2.1.331','/Applications/Xcode.app/Contents/Developer/Library/Frameworks/Python3.framework/Versions/3.9/Resources/Python.app/Contents/MacOS/Python','/usr/bin/git'}
for initial in q['observedRuntime']:
 pid=initial['pid'];path=initial['executable'];assert path.startswith(bundle+'/') or path in allowed_runtime;assert initial['ownership'] and set(initial['ownership'])<= {'previous-owned-same-birth','current-owned-descendant','current-host-seed','exact-test-app-bundle-executable'}
 x=N.read(pid);b,u=x['bsd'],x['rusage'];assert b['bytes']==N.abi['bsdSize'] and b['errno']==0 and b['pid']==pid and b['uid']==N.uid and not u['exitAbstime'] and u['rc']==u['errno']==0 and x['path']==path and abs((b['birthSec']+b['birthUsec']/1e6)-initial['createdAtEpochSeconds'])<.001
 bound_runtime[pid]={'path':path,'birth':{'pid':pid,'birthSec':b['birthSec'],'birthUsec':b['birthUsec'],'startAbstime':u['startAbstime']}}
assert len(bound_runtime)==len(q['observedRuntime']) and len(bound_runtime)>0

def take():
 start=time.monotonic_ns();records=[];errors=[]
 for role,pid in roles.items():
  before=N.read(pid);cid=N.coalition_id(pid);after=N.read(pid);valid=identity_valid(before,known[role],N.uid,N.abi) and cid_valid(cid,pid) and cid['resourceId']==C['resourceId'] and identity_valid(after,known[role],N.uid,N.abi)
  records.append({'role':role,'pid':pid,'expected':known[role],'before':before,'cid':cid,'after':after,'valid':valid})
  if not valid:errors.append(role)
 runtime_members=[];runtime_errors=[]
 for pid,expected in bound_runtime.items():
  before=N.read(pid);cid=N.coalition_id(pid);after=N.read(pid);valid=identity_valid(before,expected,N.uid,N.abi) and cid_valid(cid,pid) and cid['resourceId']==C['resourceId'] and identity_valid(after,expected,N.uid,N.abi)
  runtime_members.append({'pid':pid,'expected':expected,'before':before,'cid':cid,'after':after,'valid':valid})
  if not valid:runtime_errors.append(pid)
 observer=N.coalition_id(os.getpid());validOutside=cid_valid(observer,os.getpid()) and observer['resourceId']==ownCid['resourceId'];return {'startNs':start,'endNs':time.monotonic_ns(),'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'resourceId':C['resourceId'],'observer':observer,'observerOutsideValid':validOutside,'abi':N.abi,'records':records,'errors':errors,'runtimeMembers':runtime_members,'runtimeIdentityOrCidGaps':runtime_errors}

with (root/'instrument-cpu-complete.jsonl').open('x') as f:
 for i in range(500):
  row=take();f.write(json.dumps(row,separators=(',',':'))+'\n');f.flush()
  if i==0:
   assert not row['errors'] and not row['runtimeIdentityOrCidGaps'] and row['observerOutsideValid'];(cohortRoot/'instrument-ready.private.json').write_text(json.dumps({'nonce':q['nonce'],'firstEndNs':row['endNs'],'observerPid':os.getpid(),'resourceId':C['resourceId'],'observerResourceId':ownCid['resourceId'],'roles':roles,'firstRecordFile':str(root/'instrument-cpu-complete.jsonl')}))
  if row['errors'] or not row['observerOutsideValid'] or (cohortRoot/'driver-exit.json').exists():break
  time.sleep(5)
