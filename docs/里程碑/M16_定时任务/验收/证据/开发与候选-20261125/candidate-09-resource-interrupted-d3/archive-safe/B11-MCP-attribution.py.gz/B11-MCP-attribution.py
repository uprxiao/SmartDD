"""Read-only ownership attribution, not a replacement of original scope or threshold."""
import collections,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);result=json.loads((root/'result.json').read_text());bundle=result['bundle'];raw=[json.loads(s) for s in (root/'resource-samples.jsonl').read_text().splitlines()];warm=raw[0];pages={p for h in warm['helpers'] for p in h['pids']};metrics={p['pid']:p['type'] for p in warm['electronMetrics']}
def role(p):
 if p['pid'] in metrics:return 'appElectron.'+metrics[p['pid']]
 if p['pid'] in pages and p['name']=='agent-browser':return 'ownedAgentBrowserDaemon'
 if 'claude/versions/' in p['executable']:return 'ownedNativeClaudeRuntime'
 if p['executable']==bundle+'/Contents/MacOS/WillYou':return 'ownedWillYouMcpProcess'
 if p['name']=='Python':return 'ownedAuxiliaryPythonProcess'
 return 'otherOwnedObserved'
S=[s for s in raw if s.get('elapsedSeconds') is not None];cpu=collections.defaultdict(float);seconds=0.;counts=collections.defaultdict(int)
for a,b in zip(S,S[1:]):
 if a['label'] not in {'milestone-post-command','idle-observation'} or b['label'] not in {'idle-observation','milestone-pre-command'}:continue
 A={json.dumps(v['identity'],sort_keys=True):v for v in a['processes']};B={json.dumps(v['identity'],sort_keys=True):v for v in b['processes']};seconds+=(b['monotonicNs']-a['monotonicNs'])/1e9
 for k in A.keys()&B.keys():
  p=A[k];q=B[k];assert role(p)==role(q);delta=q['cpuSeconds']-p['cpuSeconds'];assert delta>=0;cpu[role(q)]+=delta;counts[role(q)]+=1
checkpoints={}
for s in S:
 if s['label']!='milestone-pre-command':continue
 rss=collections.defaultdict(int);pids=collections.defaultdict(list)
 for p in s['processes']:r=role(p);rss[r]+=p['rssBytes'];pids[r].append(p['pid'])
 checkpoints[str(s['minute'])]={'rssTotalBytes':s['rssTotalBytes'],'categoryRssBytes':rss,'categoryExactPids':pids}
print(json.dumps({'scope':'All observed own process identities included in original direct RSS/CPU observation; category split diagnostic only, no provider process excluded from threshold','idlePairedSeconds':seconds,'directObservedCPUSecondsByRole':cpu,'directObservedIdlePercentageByRole':{r:100*v/seconds for r,v in cpu.items()},'pairedIdentityObservationsByRole':counts,'formalPreCommandRssCheckpoints':checkpoints},ensure_ascii=False,indent=2))
