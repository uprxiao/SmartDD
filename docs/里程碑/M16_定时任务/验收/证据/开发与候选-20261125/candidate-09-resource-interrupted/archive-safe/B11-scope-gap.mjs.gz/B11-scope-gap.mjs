// Diagnostic continuation only: an unresolved transient stays unresolved forever.
export function classifyNativeSample(row, previous, expectedResourceId) {
 const gaps=row.gaps??[];const reported=[];const errors=[];
 const cid=row.coalition;const counter=cid?.counters?.[0];
 if(!cid||cid.resourceIds?.length!==1||cid.resourceIds[0]!==expectedResourceId||counter?.resourceId!==expectedResourceId||counter.rc!==0||counter.errno!==0||!(counter.tasks_started>=counter.tasks_exited)||!Object.values(cid.bindings??{}).every(v=>v===expectedResourceId))errors.push('actual-cohort-mismatch');
 for(const gap of gaps){
  const key=`${gap.capture}:${gap.code}:${gap.pid??'none'}:${gap.parent??'none'}`;
  if(previous.has(key)){reported.push(previous.get(key));continue;}
  const matched=(row.races??[]).find(r=>r.kind==='child-missing-before-read'&&r.reapOrOrphanUnresolved&&r.pid===gap.pid&&r.parent===gap.parent);
  const family=(row.races??[]).find(r=>r.pid===gap.parent&&r.kind==='family-changed-during-scan');
  const parent=(row.nodes??[]).find(n=>n.pid===gap.parent&&n.anchor);const expected=row.anchors?.[String(gap.parent)];
  const nativeIdentityValid=(sample)=>sample?.bsd?.pid===gap.parent&&sample?.bsd?.bytes===row.abi?.bsdSize&&sample?.bsd?.errno===0&&sample?.rusage?.rc===0&&sample?.rusage?.errno===0&&!sample.rusage.exitAbstime&&sample?.rusage?.startAbstime===expected?.birth?.startAbstime&&sample?.path===expected?.path;
  const raw=matched?.raw;
  const exactMissing=raw?.pid===gap.pid&&raw?.bsd?.bytes===0&&raw?.bsd?.errno===3&&raw?.rusage?.rc===-1&&raw?.rusage?.errno===3&&raw?.path===null&&raw?.pathRc===0&&raw?.pathErrno===3;
  if(gap.capture!==row.capture||gap.code!=='unresolved-reap-or-orphan'||!exactMissing||!family?.before?.includes(gap.pid)||family?.after?.includes(gap.pid)||family.parentAfterChildRaw<family.parentBeforeChildRaw||!nativeIdentityValid(parent?.first)||!nativeIdentityValid(parent?.last)||cid?.bindings?.[String(gap.parent)]!==expectedResourceId){errors.push('unclassified-native-gap:'+key);continue;}
  // Measured parent/coalition remains valid. Still no identity proof for missing child.
  const unresolved={key,gap,raw,parentInventory:family,parentAnchor:expected,classification:'diagnostic-collection-may-continue; scope not resolved',scopeApproved:false};previous.set(key,unresolved);reported.push(unresolved);
 }
 return {continueMeasurement:errors.length===0,scopeApproved:false,unresolved:reported,errors,classification:gaps.length?'transient-gap-preserved-unproven':'no-diagnostic-gaps-in-this-collector'};
}
