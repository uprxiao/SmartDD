"""Read only raw isolated acceptance evidence; no sampling/driver behavior change."""
import sys,json,pathlib,statistics,collections
root=pathlib.Path(sys.argv[1]);J=lambda n: json.loads((root/n).read_text())
L=lambda n:[json.loads(s) for s in (root/n).read_text().splitlines() if s.strip()]
result=J('result.json'); R=result['resource']; raw=L('resource-samples.jsonl'); native=L('native-cpu-samples.jsonl'); parks=L('native-parked-observations.jsonl'); instrument=L('independent-instrumentation-partial.jsonl') if (root/'independent-instrumentation-partial.jsonl').exists() else []
S=[s for s in raw if s.get('elapsedSeconds') is not None]; N={n['requestId']:n for n in native if n.get('kind')=='cpu-upper-sample'};expectedCID=R['cohort']['resourceId']
def native_counter(row):
 n=N.get(row['requestId']); c=n.get('coalition') if n else None
 if not c or c.get('resourceIds')!=[expectedCID] or len(c.get('counters',[]))!=1:return None
 x=c['counters'][0]
 if x.get('rc')!=0:return None
 return x

def idle_pair(a,b):
 return a['label'] in {'milestone-post-command','idle-observation'} and b['label'] in {'idle-observation','milestone-pre-command'}
def key(p):return json.dumps(p['identity'],sort_keys=True)
def direct_lower(a,b):
 A={key(p):p for p in a['processes']}; B={key(p):p for p in b['processes']}; D={k:B[k]['cpuSeconds']-A[k]['cpuSeconds'] for k in A.keys()&B.keys()}
 assert all(v>=-1e-6 for v in D.values()),'counter reversed'
 return sum(max(v,0) for v in D.values()),len(A.keys()-B.keys()),len(B.keys()-A.keys()),len(D)
full_upper=None
if S and (first:=native_counter(S[0])) and (last:=native_counter(S[-1])):
 a=S[0]; b=S[-1]; span=(last['startNs']-first['endNs'])/1e9
 if span>0:full_upper={'secondsLowerBound':span,'cpuSecondsUpper':(last['cpu_time']-first['cpu_time'])*N[b['requestId']]['abi']['numer']/N[b['requestId']]['abi']['denom']/1e9,'startedDelta':last['tasks_started']-first['tasks_started'],'exitedDelta':last['tasks_exited']-first['tasks_exited'],'firstRequest':a['requestId'],'lastRequest':b['requestId'],'includesActiveCommandsAndHarness':True}
 if full_upper:full_upper['averageUpperPercent']=100*full_upper['cpuSecondsUpper']/span
init=next((n for n in native if n.get('kind')=='cpu-initialized'),None)
fullOriginalBaseline=None
if init and S and (tail:=native_counter(S[-1])):
 cs=init.get('coalition',{}).get('counters',[])
 if len(cs)==1 and cs[0].get('resourceId')==tail['resourceId'] and tail['cpu_time']>=cs[0]['cpu_time']:
  total=(tail['cpu_time']-cs[0]['cpu_time'])*init['abi']['numer']/init['abi']['denom']/1e9
  idle_denom=(R.get('final',{}).get('elapsedSeconds') or S[-1]['elapsedSeconds'])-sum(r['activeElapsedSeconds'] for r in R['rounds'])
  fullOriginalBaseline={'baselineRequest':init['requestId'],'finalRequest':S[-1]['requestId'],'cpuSecondsUpper':total,'idleDenominatorSeconds':idle_denom,'conservativePercentWithActiveAndHarness':100*total/idle_denom,'sameStartAndIdleDenominatorAsHistoricalM12':True}
idle={'pairCount':0,'directSecondsLower':0.,'directIntervalSeconds':0.,'nativeCpuSecondsUpper':0.,'nativeIntervalSecondsLowerBound':0.,'nativePairs':0,'directLostIdentities':0,'directNewIdentities':0,'nativeCounterGaps':0,'directReadErrors':0}
for a,b in zip(S,S[1:]):
 if not idle_pair(a,b):continue
 idle['pairCount']+=1; low,lost,added,common=direct_lower(a,b); dt=(b['monotonicNs']-a['monotonicNs'])/1e9
 idle['directSecondsLower']+=low;idle['directIntervalSeconds']+=dt;idle['directLostIdentities']+=lost;idle['directNewIdentities']+=added;idle['directReadErrors']+=len(a['readErrors'])+len(b['readErrors'])
 A=native_counter(a); B=native_counter(b)
 if not A or not B or B['cpu_time']<A['cpu_time'] or B['startNs']<=A['endNs']:
  idle['nativeCounterGaps']+=1;continue
 abi=N[b['requestId']]['abi'];idle['nativePairs']+=1;idle['nativeCpuSecondsUpper']+=(B['cpu_time']-A['cpu_time'])*abi['numer']/abi['denom']/1e9;idle['nativeIntervalSecondsLowerBound']+=(B['startNs']-A['endNs'])/1e9
if idle['directIntervalSeconds']>0:idle['directObservedPercentLower']=idle['directSecondsLower']*100/idle['directIntervalSeconds']
if idle['nativeIntervalSecondsLowerBound']>0:idle['cohortIdleAverageUpperPercent']=idle['nativeCpuSecondsUpper']*100/idle['nativeIntervalSecondsLowerBound']
partial={}
for role in ['wrapper','driver','osSampler','nativeCollector']:
 samples=[(a['monotonicNs'],row) for a in instrument for row in a['rows'] if row['role']==role and row['state']=='alive']
 if len(samples)>1:
  t,a=samples[0];u,b=samples[-1];partial[role]={'pid':a['pid'],'birth':a['birth'],'exe':a['exe'],'startNs':t,'endNs':u,'seconds':(u-t)/1e9,'measuredCpuSeconds':b['user']+b['system']-a['user']-a['system']};partial[role]['averagePercent']=partial[role]['measuredCpuSeconds']*100/partial[role]['seconds']
checkpoints={r['minute']:r for r in R['rounds']};warm=R['warmup'];commands=warm+[c for r in R['rounds'] for c in r['commands']];checks={'samplingRows':len(raw),'allReadErrors':sum(len(s['readErrors']) for s in raw),'elapsedSeconds':S[-1]['elapsedSeconds'] if S else None,'formalDurationConfigured':R['formalLongSeconds'],'points':list(checkpoints),'warmCommandCount':len(warm),'formalCommandCount':len(commands)-len(warm),'allReceiptsOk':all(c['receipt']['status']=='ok' and c['receipt']['data']['browserPageId']==c['pageId'] and c['accepted']['status']=='accepted' for c in commands),'pageCount':len(set(c['pageId'] for c in warm)),'helperPidSets':len(set(tuple(sorted(p for h in s['helpers'] for p in h['pids'])) for s in raw)),'osSamplerWallSeconds':sum(s['samplingDurationNs'] for s in raw)/1e9,'nativeCollectorWallSeconds':sum(n['endNs']-n['startNs'] for n in N.values())/1e9,'nativeGapsTotal':sum(len(n['gaps']) for n in N.values())}
checkpointsRss={}
for t,r in checkpoints.items():checkpointsRss[t]={'beforeBytes':r['before']['rssTotalBytes'],'afterBytes':r['after']['rssTotalBytes'] if r.get('after') else None}
if len(checkpoints)>=7:
 v=[checkpointsRss[t]['beforeBytes'] for t in sorted(checkpointsRss)];checks['RSS30vs10']={'10':v[2],'30':v[6],'ratio':v[6]/v[2],'within110Percent':v[6]*10<=v[2]*11};checks['last4CheckpointRss']={'bytes':v[-4:],'notStrictlyIncreasing':not all(a<b for a,b in zip(v[-4:],v[-3:]))}
parked=collections.defaultdict(list)
for park in parks:parked[park['pageId']].append(park)
checks['parkedNativeIdentity']={id:{'count':len(rows),'markerCount':len(set(r['state']['page']['marker'] for r in rows)),'nativeIdCount':len(set(r['state']['id'] for r in rows)),'nativePidCount':len(set(r['state']['process'] for r in rows)),'formCount':len(set(r['state']['page']['form'] for r in rows)),'boundsCount':len(set(json.dumps(r['bounds'],sort_keys=True) for r in rows)),'prefsAllContract':all(r['prefs'][k]==v for r in rows for k,v in {'sandbox':True,'debuggerAttached':True,'contextIsolation':True,'nodeIntegration':False,'webSecurity':True,'backgroundThrottling':False}.items())} for id,rows in parked.items()}
print(json.dumps({'scope':'Frozen C09 isolated real App, synthetic own task+MCP route; original CLI path unavailable, no S x64 or user claim','status':result.get('status') or R['status'],'resourceInternalStatusAtExit':R['status'],'complete30MinuteRun':bool(R.get('final',{}).get('elapsedSeconds',0)>=1800 and len(checkpoints)==7 and len(commands)==40),'checks':checks,'checkpointRss':checkpointsRss,'fullCohortCPUUpper':full_upper,'fullConservativeOriginalBaselineAndIdleDenominator':fullOriginalBaseline,'idleDirectObservedLowerAndCohortUpper':idle,'partialIndependentHarnessReadings':partial,'adjudicationLimit':'Instrument CPU starts mid-run and is not safe to subtract from a whole-run upper. Cohort covers product+driver+fixture including short-lived transients, so not a proven product-only average. Direct observed counters omit short-lived-between-sample activity. Formal CPU criterion must remain unproven when lower<5%<upper.'},ensure_ascii=False,indent=2))
