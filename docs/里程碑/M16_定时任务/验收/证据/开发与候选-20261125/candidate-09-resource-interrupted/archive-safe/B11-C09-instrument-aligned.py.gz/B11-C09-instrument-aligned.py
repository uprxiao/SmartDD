"""Conservative subtraction from selected actual same-CID counter intervals only.
Never makes an original scope gap pass: product completeness assessed independently.
"""
import pathlib,json,sys,collections
root=pathlib.Path(sys.argv[1]);L=lambda name:[json.loads(s)for s in (root/name).read_text().splitlines()];result=json.loads((root/'result.json').read_text());native=L('native-cpu-samples.jsonl');osraw=L('resource-samples.jsonl');I=L('instrument-cpu-complete.jsonl');cid=result['resource']['cohort']['resourceId'];N={n['requestId']:n for n in native if n.get('kind')=='cpu-upper-sample'};abi=native[0]['abi'];roles=['wrapper','driver','osSampler','nativeCollector'];expected=I[0]['records'];wanted={x['role']:x['expected'] for x in expected}
assert len(wanted)==4 and set(wanted)==set(roles)
def good(row):
 return row['resourceId']==cid and row['observerOutsideValid'] and row['observer']['resourceId']!=cid and not row['errors'] and row['abi']==abi and set(x['role'] for x in row['records'])==set(roles) and all(x['valid'] and x['expected']==wanted[x['role']] and x['cid']['resourceId']==cid for x in row['records'])
def counter(row):
 x=row['coalition'];assert x['resourceIds']==[cid] and len(x['counters'])==1 and x['counters'][0]['resourceId']==cid;return x['counters'][0]
def segment(A,B,label):
 a,b=counter(A),counter(B);s=a['endNs'];e=b['startNs'];assert e>=s;ds=b['cpu_time']-a['cpu_time'];assert ds>=0
 members=[r for r in I if r['startNs']>=s and r['endNs']<=e];lower={role:0 for role in roles}
 if len(members)>=2 and all(good(r) for r in members):
  first,last=members[0],members[-1];F={x['role']:x['after']['rusage'] for x in first['records']};L={x['role']:x['before']['rusage'] for x in last['records']};lower={role:max(0,(L[role]['user']+L[role]['system'])-(F[role]['user']+F[role]['system'])) for role in roles};assert sum(lower.values())<=ds
 else:first=last=None
 scale=abi['numer']/abi['denom']/1e9
 return{'label':label,'counterInterval':[s,e],'secondsLowerBound':(e-s)/1e9,'rawWholeGroupUpperSeconds':ds*scale,'instrumentRawLower':lower,'instrumentSecondsLower':sum(lower.values())*scale,'residualCoarseUpperSeconds':(ds-sum(lower.values()))*scale,'firstContainedInstrument':first['startNs'] if first else None,'lastContainedInstrument':last['endNs'] if last else None,'containedInstrumentRows':len(members),'scopeStillDependsOnCompleteProductGroup':True}
S=[s for s in osraw if s.get('elapsedSeconds') is not None];groups=[];start=None;last=None
for a,b in zip(S,S[1:]):
 idle=a['label'] in {'milestone-post-command','idle-observation'} and b['label'] in {'idle-observation','milestone-pre-command'}
 if idle:
  if start is None:start=a
  last=b
 elif start is not None:
  groups.append(segment(N[start['requestId']],N[last['requestId']],f"idle-{start['requestId']}-{last['requestId']}"));start=last=None
if start is not None:groups.append(segment(N[start['requestId']],N[last['requestId']],f"idle-{start['requestId']}-{last['requestId']}"))
full=segment(native[0],N[S[-1]['requestId']],'full-baseline-until-last-actual-counter')
D=sum(x['secondsLowerBound'] for x in groups);raw=sum(x['rawWholeGroupUpperSeconds'] for x in groups);inst=sum(x['instrumentSecondsLower'] for x in groups);residual=sum(x['residualCoarseUpperSeconds'] for x in groups);nativeGaps={json.dumps(g,sort_keys=True) for n in native for g in n.get('gaps',[])}
summary={'scope':'only measured instrument cumulative CPU lower inside actual same-CID monotonic intervals, no interpolation/lifetime subtraction; unknown runtime descendants or extra group members remain in residual. Scope completeness not presumed.','actualRows':len(I),'allInstrumentIdentityCidsValidExceptTeardownTail':all(good(r)for r in I[:-1]),'runtimeIdentityOrCidGapPids':sorted(set(p for r in I[:-1] for p in r.get('runtimeIdentityOrCidGaps',[]))),'nativeUnresolvedGaps':sorted(nativeGaps),'fullGroup':full,'idleSegments':groups,'idleSecondsLowerBound':D,'idleRawGroupUpperPercent':100*raw/D if D else None,'idleInstrumentObservedContainedLowerPercent':100*inst/D if D else None,'residualIdleGroupUpperPercent':100*residual/D if D else None,'measurementComplete':bool(result['resource'].get('final',{}).get('elapsedSeconds',0)>=1800 and len(result['resource']['rounds'])==7),'scopeApproved':False}
print(json.dumps(summary,indent=2,ensure_ascii=False))
