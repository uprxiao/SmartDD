import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {LedgerCandidate} from './ledger-candidate.mjs';
const dir=dirname(fileURLToPath(import.meta.url));
const l=new LedgerCandidate(join(dir,'ledger-contrast.sqlite'));
try{
  const now=Date.parse('2026-11-27T03:00:00Z'),old=now+60000,newDue=now+86400000;
  const one=instant=>({type:'once',onceAt:instant,zone:'UTC'});
  let p=l.create({id:'p',schedule:one(old)},now);
  const r=l.claim('p',{now:old,expected:p.revision}).run;
  l.begin(r.id,old);l.accepted(r.id,{inputId:r.input_id,taskId:r.task_id});
  p=l.plan('p');p=l.edit('p',p.revision,{schedule:one(newDue)},old+1);p=l.setEnabled('p',p.revision,false,old+2);
  l.finish(r.id,'completed',old+3);const beforeResume=l.plan('p');
  assert.equal(beforeResume.ended,0);assert.equal(beforeResume.enabled,0);
  const resumed=l.setEnabled('p',beforeResume.revision,true,old+4);assert.equal(resumed.next_due,newDue);
  writeFileSync(join(dir,'ledger-contrast.json'),JSON.stringify({layer:'E02/E08 isolated technical candidate with real SQLite, no actual Agent task',oldDue:r.due,newDue,beforeResume:{status:beforeResume.ended?'ended':'paused',enabled:beforeResume.enabled},resumedDue:resumed.next_due,runStatus:l.run(r.id).status},null,2)+'\n');
  console.log('E02/E08 candidate preserves the new paused one-shot date and resumes it.');
}finally{l.close()}
