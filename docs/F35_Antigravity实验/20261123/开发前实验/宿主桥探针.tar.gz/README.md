# F35 宿主 MCP、审批与委派技术实验

2026-11-23，macOS arm64。WillYou 冻结提交 `e7fc5f57ffc4191c175f0a41902e62e4d4bf3133`，本机 `agy 1.5.14`。十条技术断言见证据目录的 `result.json`。运行清理与进程出生身份、数据库清理与业务写入、ACP 原始事件分别留证。证据只使用合成账户和隔离项目。

## 实际执行边界

- 真实 `agy` 通过 ACP 启动了冻结源码构建的 WillYou stdio MCP。宿主通过内核取得 Unix 连接对端的进程及祖先身份，生产私有 broker 验证一次性票据以及运行绑定。生产 `DelegationService` 返回目标和委派收据，生产 `sample-kv` 应用及本地进程写入隔离磁盘。
- 真实 `agy` 发出权限请求。冻结的 `AgentRunService`、`AgentTaskService` 和请求持久化检查任务、运行、绑定、代次和修订。实验由主机脚本提交对应用户决定，随后核对 native ACP 响应、操作表和磁盘内容。
- 个人扩展正控从合成的原生个人配置启动了对应进程并发送发现消息。托管初次及恢复会话显示零个人扩展进程和零个人工具声明。个人标记用于证明配置加载路径。
- Codex、Claude Code 使用确定性对端进程。四个方向均经过生产宿主调度、原始父子关系和结果投递，Antigravity 一侧为真实 `agy`。Codex 配置的「帮我批准」通过候选权限登记降为「请求批准」。
- 实验代码提供 ACP 事件映射、新执行器的候选权限登记、托管配置隔离、绑定快照投影、确定性 Gemini 和合成档案。构建脚本中的源码指纹可核实复用部分。应用主进程 UI 与打包 App 验收仍在后续用例范围内，真实 Codex、Claude Code 与 Carbon、Argon 结果也需另行验收。
- 合成 Gemini 仅监听本机。真实 `agy` 与语言服务器只开放回环 TCP 和本轮将使用的 Unix socket。使用文档保留的非回环地址得到内核拒绝，进程环境使用合成 Key。可执行文件、进程和套接字均在清理记录中核对。

## 复验

在可写的全新临时目录展开，进入 `replay/`。设 `F35_REPO_DIR` 为带该提交及当前锁定依赖的仓库路径，并可设 `F35_AGY_BIN` 指定待验的本机 CLI。按顺序执行。

```sh
/bin/sh ./prepare-bridge.sh
/bin/sh ./run-bridge.sh
```

准备脚本只从冻结提交提取源码。当前使用 Node 22 构建，直接运行现有 Electron 的 Node 模式加载 ABI 146 的 SQLite 模块，无界面。运行需要当前主机允许本地端口和 Unix socket。成功或失败均生成独立的 `attempt-*/result.json`。资源索引仅因隔离源码中无 Git 目录而省略构建元数据，审核的资源集指纹保持一致。
