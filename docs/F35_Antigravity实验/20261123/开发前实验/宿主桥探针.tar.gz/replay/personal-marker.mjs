import {appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';

const marker = process.argv[2];
const tool = {
  name:'f35_personal_probe', description: 'Synthetic personal extension marker for an isolated scope test',
  inputSchema: {type: 'object', properties: {}, additionalProperties: false},
  annotations: {readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false},
};
appendFileSync(marker, JSON.stringify({event: 'started', pid: process.pid}) + '\n', {mode: 0o600});
for await (const line of createInterface({input: process.stdin})) {
  const request = JSON.parse(line);
  appendFileSync(marker, JSON.stringify({event: request.method, pid: process.pid}) + '\n', {mode: 0o600});
  let result;
  if (request.method === 'initialize') result = {protocolVersion: request.params.protocolVersion, capabilities: {tools:{}}, serverInfo: {name: 'personal marker', version:'1.0.0'}};
  if (request.method === 'tools/list') result = {tools: [tool]};
  if (request.method === 'tools/call') result = {content: [{type: 'text', text: 'F35-PERSONAL-CANARY'}]};
  if (request.id != null) {
    const payload = result ? {result} : {error:{code:-32601, message:'Method not found'}};
    process.stdout.write(JSON.stringify({jsonrpc:'2.0', id: request.id, ...payload}) + '\n');
  }
}
