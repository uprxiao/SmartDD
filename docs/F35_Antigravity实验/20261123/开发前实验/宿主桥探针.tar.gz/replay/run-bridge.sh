#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
run_root="$(/bin/pwd -P)"
repo_dir="${F35_REPO_DIR:-/Users/liubu/hx/4.uprxiao/SmartDD}"
agy_bin="${F35_AGY_BIN:-/Users/liubu/.local/bin/agy}"
electron="$repo_dir/node_modules/electron/dist/Electron.app/Contents/MacOS/Electron"
base="$(/usr/bin/mktemp -d "$run_root/host-env-XXXXXX")"
mkdir -m 700 "$base/tmp"
exec /usr/bin/env -i PATH=/usr/bin:/bin HOME="$base" TMPDIR="$base/tmp" LANG=en_US.UTF-8 \
  ELECTRON_RUN_AS_NODE=1 F35_AGY_BIN="$agy_bin" F35_LAYER="${F35_LAYER:-all}" \
  "$electron" "$run_root/run-bridge.mjs"
