import {createServer} from 'node:http';
import {once} from 'node:events';
import {setTimeout as wait} from 'node:timers/promises';

export const carbon = 'gemini-4-carbon';
export const argon = 'gemini-4-argon';
export const profileIds = ['agy-parent', 'agy-child', 'codex-fixture', 'claude-fixture'];

export function toolAction(text) {
  const marker = text.match(/F35:(TARGETS|PERSONAL|READ|WRITE|DELEGATE)(?::([a-z0-9-]+))?(?::([a-z0-9-]+))?/);
  if (!marker) return;
  const [, mode, subject, extra] = marker;
  if (mode === 'PERSONAL') return {operation: 'f35_personal_probe', args: {}};
  if (mode === 'TARGETS') return {operation: 'wy_targets', args: {}};
  if (mode === 'READ') return {operation: 'smartdd_sample_kv_read_v2', args: {key: `demo:${subject}`}};
  if (mode === 'WRITE') return {operation: 'smartdd_sample_kv_write_v2', args: {key: `demo:${subject}`, value: `F35-MARKER-${subject}`, expectedRevision: 0}};
  if (mode === 'DELEGATE') return {operation: 'wy_delegate', args: {
    requestKey: `f35-${subject}-${extra}`, profileId: subject, profileRevision: `isolation-r1-${subject}`,
    title: `F35 ${subject} ${extra}`,
    instructions: subject === 'agy-child' ? (extra.endsWith('text') ? 'F35:CHILD-TEXT' : `F35:WRITE:${extra}`) : `F35-FIXTURE-CHILD-${subject}`,
    ...(subject === 'agy-child' && {model: argon}),
  }};
}

export async function startGemini() {
  const evidence = [];
  const requests = new Set();
  const server = createServer(async (req, res) => {
    try {
      const route = new URL(req.url, 'http://127.0.0.1');
      const match = route.pathname.match(/^\/v1beta\/models\/(gemini-4-(?:carbon|argon)):(streamGenerateContent|generateContent)$/);
      if (!match || req.method !== 'POST') { res.writeHead(403).end(); return; }
      let body = '';
      for await (const bytes of req) {
        body += bytes;
        if (Buffer.byteLength(body) > 512000) { res.writeHead(413).end(); return; }
      }
      const model = match[1];
      const request = JSON.parse(body);
      const declarations = (request.tools ?? []).flatMap(group => group.functionDeclarations ?? []).map(tool => tool.name);
      const parts = request.contents?.at(-1)?.parts ?? [];
      const returned = parts.flatMap(part => part.functionResponse ? [part.functionResponse] : []);
      const prompt = parts.map(part => part.text ?? '').join(' ');
      const action = toolAction(prompt);
      evidence.push({model, method: match[2], toolNames: declarations, ...(action && {action}), ...(returned.length && {returned}),
        ...(prompt.includes('F35:CHILD-TEXT') && {scriptedChildText: true})});
      let part;
      if (returned.length) {
        part = {text: 'F35-WIRE-TOOL-RESULT ' + JSON.stringify(returned).slice(0, 1800)};
      } else if (action) {
        const name = declarations.find(name => name.endsWith(action.operation));
        part = name ? {functionCall: {name, args: {...action.args, toolSummary: 'Run the isolated WillYou test operation'}},
          thoughtSignature: 'RjM1LVNDUklQVEVELVRPT0w='} : {text: 'F35-MISSING-TOOL ' + action.operation};
      } else {
        part = {text: prompt.includes('F35:CHILD-TEXT') ? 'F35-REAL-AGY-CHILD-RETURN-' + model : 'F35-SCRIPTED-LOCAL-TEXT'};
      }
      const frame = {candidates: [{index: 0, content: {role: 'model', parts: [part]}, finishReason: 'STOP'}],
        modelVersion: model, usageMetadata: {promptTokenCount: 12, candidatesTokenCount: 5, totalTokenCount: 17}};
      const serialized = JSON.stringify(frame);
      if (match[2] === 'generateContent') res.writeHead(200, {'Content-Type': 'application/json'}).end(serialized);
      else res.writeHead(200, {'Content-Type': 'text/event-stream'}).end(`data: ${serialized}\n\n`);
    } catch (error) {
      evidence.push({error: error.message});
      if (!res.headersSent) res.writeHead(500);
      res.end();
    }
  });
  server.on('connection', socket => { requests.add(socket); socket.once('close', () => requests.delete(socket)); });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  return {port, origin: `http://127.0.0.1:${port}`, evidence, async close() {
    const closed = once(server, 'close');
    server.close();
    for (const socket of requests) socket.destroy();
    await Promise.race([closed, wait(2500).then(() => { throw new Error('Fixture listener did not close'); })]);
  }};
}
