import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {appendFileSync} from 'node:fs';
import {createInterface} from 'node:readline';
import {setTimeout as wait} from 'node:timers/promises';
import host from './build/host.cjs';

export class AcpDriver {
  constructor({id, launch, traces}) {
    this.driverId = id;
    this.launch = launch;
    this.traces = traces;
    this.events = new host.Emitter();
    this.on = this.events.on.bind(this.events);
    this.serial = 0;
    this.calls = new Map();
    this.requests = new Map();
  }

  async open(options) {
    const launch = this.launch(options);
    const {command, args, tracePath} = launch;
    this.tracePath = tracePath;
    const child = this.child = spawn(command, args,
      {cwd: options.cwd, env: options.env, detached: true, stdio: ['pipe', 'pipe', 'pipe']});
    this.exit = new Promise(resolve => child.once('close', (code, signal) => {
      this.exitOutcome = {code, signal};
      for (const response of this.calls.values()) response.reject(new Error(`ACP stream closed (${code ?? signal})`));
      this.calls.clear();
      this.events.emit({type: 'exit', code, signal});
      this.record({event: 'exit', code, signal});
      resolve(this.exitOutcome);
    }));
    child.stderr.on('data', bytes => appendFileSync(tracePath + '.stderr', bytes, {mode: 0o600}));
    child.stdin.on('error', error => this.record({event: 'stdin-error', message: error.message}));
    createInterface({input: child.stdout}).on('line', line => this.onLine(line));
    await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
    this.record({event: 'spawn', pid: child.pid, cwd: options.cwd, driver: this.driverId});
    this.events.emit({type: 'process', pid: child.pid});
    await options.beforeInitialize?.();
    const init = await this.send('initialize', {protocolVersion: 1, clientCapabilities: {}, clientInfo: {name: 'WillYou F35 host probe', version: '1.0.0'}});
    assert.equal(init.protocolVersion, 1);
    if (this.driverId === 'antigravity-acp') {
      assert(init.authMethods.some(method => method.id === 'gemini-api-key'));
      await this.send('authenticate', {methodId: 'gemini-api-key'});
    }
    const mcpServers = Object.entries(options.mcpServers ?? {}).map(([name, config]) => ({
      name, command: config.command, args: config.args, env: Object.entries(config.env).map(([name, value]) => ({name, value}))
    }));
    let session;
    if (options.resumeNativeId) {
      session = (await this.send('session/resume', {cwd: options.cwd, sessionId: options.resumeNativeId, mcpServers})).sessionId ?? options.resumeNativeId;
    } else {
      session = (await this.send('session/new', {cwd: options.cwd, mcpServers})).sessionId;
    }
    assert.equal(typeof session, 'string');
    this.sessionId = session;
    this.events.emit({type: 'session', nativeId: session});
    this.model = await this.choose('model', options.model ?? launch.defaultModel);
    return {nativeId: session, confirmed: true, defaultModel: this.model};
  }

  async choose(configId, value) {
    const response = await this.send('session/set_config_option', {sessionId: this.sessionId, configId, value});
    const selected = response.configOptions?.find(option => option.id === configId)?.currentValue;
    assert.equal(selected, value, `ACP rejected ${configId}`);
    return selected;
  }

  record(row) {
    appendFileSync(this.tracePath, JSON.stringify({at: new Date().toISOString(), ...row}) + '\n', {mode: 0o600});
  }

  write(message) {
    this.record({direction: 'to-agent', message});
    this.child.stdin.write(JSON.stringify({jsonrpc: '2.0', ...message}) + '\n');
  }

  send(method, params, timeout = 12_000) {
    const id = ++this.serial;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.calls.delete(id); reject(new Error(`ACP timeout: ${method}`)); }, timeout);
      this.calls.set(id, {
        resolve: value => { clearTimeout(timer); resolve(value); },
        reject: error => { clearTimeout(timer); reject(error); },
      });
      this.write({id, method, params});
    });
  }

  onLine(line) {
    let message;
    try { message = JSON.parse(line); } catch { this.record({event: 'unparsed-stdout', bytes: Buffer.byteLength(line)}); return; }
    this.record({direction: 'from-agent', message});
    if (message.method === 'session/request_permission' && message.id != null) {
      const {sessionId, toolCall, options} = message.params;
      if (sessionId !== this.sessionId || !this.turn) {
        this.write({id: message.id, result: {outcome: {outcome: 'cancelled'}}});
        return;
      }
      const key = String(message.id);
      this.requests.set(key, {id: message.id, options, turn: this.turn.id});
      const title = toolCall.title ?? '';
      const input = toolCall.rawInput ?? toolCall.input ?? {};
      this.events.emit({type: 'request', requestKey: key, kind: 'tool_approval',
        payload: {name: title, input, toolCall, options}});
    } else if (message.method === 'session/update') {
      const update = message.params?.update;
      if (message.params?.sessionId === this.sessionId && update?.sessionUpdate === 'agent_message_chunk' && this.turn) {
        this.turn.text += update.content?.text ?? '';
      }
    } else if (message.method && message.id != null) {
      this.write({id: message.id, error: {code: -32601, message: 'The isolated host declines this unneeded ACP method'}});
    } else if (!message.method) {
      const response = this.calls.get(message.id);
      if (!response) return;
      this.calls.delete(message.id);
      if (message.error) response.reject(new Error(JSON.stringify(message.error)));
      else response.resolve(message.result);
    }
  }

  async startTurn(input) {
    assert.equal(this.turn, undefined);
    if (input.model && input.model !== this.model) this.model = await this.choose('model', input.model);
    if (input.effort && this.driverId === 'antigravity-acp') await this.choose('thought_level', input.effort);
    const turn = this.turn = {id: randomUUID(), text: ''};
    this.events.emit({type: 'turn.started', nativeTurnId: turn.id, clientInputId: input.clientInputId});
    void this.send('session/prompt', {sessionId: this.sessionId, prompt: [{type: 'text', text: input.text}]},
      20_000).then(reply => this.finish(turn, reply), error => this.finish(turn, {}, error));
    return {nativeTurnId: turn.id};
  }

  finish(turn, reply, error) {
    if (this.turn !== turn) return;
    if (turn.text) {
      const payload = this.driverId === 'claude-sdk' ? {content: [{type: 'text', text: turn.text}], model: this.model}
        : {id: turn.id, type: 'agentMessage', text: turn.text, model: this.model};
      this.events.emit({type: 'item.completed', nativeItemId: turn.id,
        itemType: this.driverId === 'claude-sdk' ? 'assistant' : 'agentMessage', payload});
    }
    for (const [key, request] of this.requests) {
      if (request.turn !== turn.id) continue;
      this.requests.delete(key);
      this.events.emit({type: 'request.resolved', requestKey: key});
    }
    this.turn = undefined;
    const status = error ? 'failed' : reply.stopReason === 'cancelled' ? 'interrupted'
      : reply.stopReason === 'end_turn' ? 'completed' : 'failed';
    this.events.emit({type: 'turn.completed', nativeTurnId: turn.id, status,
      ...((error || status === 'failed') && {error: error?.message ?? String(reply.stopReason)})});
  }

  async respond(requestKey, result) {
    const request = this.requests.get(requestKey);
    assert(request && request.turn === this.turn?.id, 'stale native approval');
    assert(['allow', 'deny'].includes(result.behavior), 'unsupported decision in experiment');
    const kind = result.behavior === 'allow' ? 'allow_once' : 'reject_once';
    const option = request.options.find(option => option.kind === kind);
    if (!option && kind === 'allow_once') throw new Error('ACP has no one-time approve decision');
    this.requests.delete(requestKey);
    this.write({id: request.id, result: {outcome: option ? {outcome: 'selected', optionId: option.optionId} : {outcome: 'cancelled'}}});
  }

  async interrupt() {
    if (this.turn) this.write({method: 'session/cancel', params: {sessionId: this.sessionId}});
  }

  async close() {
    if (!this.child || this.exitOutcome) return;
    this.child.stdin.end();
    const closed = await Promise.race([this.exit.then(() => true), wait(1800, false, {ref: false})]);
    if (!closed && !this.exitOutcome) this.child.kill('SIGTERM');
    const terminated = await Promise.race([this.exit.then(() => true), wait(2000, false, {ref: false})]);
    if (!terminated && !this.exitOutcome) this.child.kill('SIGKILL');
    await this.exit;
  }

  async injectHistory(text) {
    this.record({event: 'host-history-context', characters: text.length});
  }
}
