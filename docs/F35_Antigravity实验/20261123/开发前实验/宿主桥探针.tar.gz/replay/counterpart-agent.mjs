import {randomUUID} from 'node:crypto';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {toolAction} from './local-fixtures.mjs';

const send = (id, result) => process.stdout.write(JSON.stringify({jsonrpc: '2.0', id, result}) + '\n');
const notify = (method, params) => process.stdout.write(JSON.stringify({jsonrpc: '2.0', method, params}) + '\n');
let sessionId, bridge, callId = 0, definitions = [];
const pending = new Map();
const mcp = (method, params) => new Promise((resolve, reject) => {
  const id = ++callId;
  pending.set(id, {resolve, reject});
  bridge.stdin.write(JSON.stringify({jsonrpc: '2.0', id, method, params}) + '\n');
});
async function openBridge(entry, cwd) {
  bridge = spawn(entry.command, entry.args, {cwd,
    env: {...process.env, ...Object.fromEntries(entry.env.map(pair => [pair.name, pair.value]))}, stdio: ['pipe', 'pipe', 'inherit']});
  bridge.once('exit', (code, signal) => {
    for (const reply of pending.values()) reply.reject(new Error(`fixture MCP exit ${code ?? signal}`));
    pending.clear();
  });
  bridge.stdin.on('error', () => {});
  createInterface({input: bridge.stdout}).on('line', line => {
    const message = JSON.parse(line);
    const reply = pending.get(message.id);
    if (!reply) return;
    pending.delete(message.id);
    if (message.error) reply.reject(new Error(JSON.stringify(message.error)));
    else reply.resolve(message.result);
  });
  await mcp('initialize', {protocolVersion: '2025-06-18', capabilities: {}, clientInfo: {name: 'F35 deterministic counterpart', version: '1.0.0'}});
  bridge.stdin.write(JSON.stringify({jsonrpc: '2.0', method: 'notifications/initialized'}) + '\n');
  definitions = (await mcp('tools/list', {})).tools;
}

const lines = createInterface({input: process.stdin});
lines.on('line', async line => {
  const {id, method, params} = JSON.parse(line);
  try {
    if (method === 'initialize') send(id, {protocolVersion: 1, agentInfo: {name: 'F35 deterministic counterpart', version: '1.0.0'}, authMethods: []});
    if (method === 'session/new' || method === 'session/resume') {
      sessionId = params.sessionId ?? randomUUID();
      if (params.mcpServers.length) await openBridge(params.mcpServers[0], params.cwd);
      send(id, {sessionId});
    }
    if (method === 'session/set_config_option') send(id, {configOptions: [{id: params.configId, currentValue: params.value}]});
    if (method === 'session/prompt') {
      const text = params.prompt.map(item => item.text).join(' ');
      const action = toolAction(text);
      let answer;
      if (action) {
        const tool = definitions.find(item => item.name === action.operation);
        if (!tool) throw new Error('Fixture declared tools missing ' + action.operation);
        const result = await mcp('tools/call', {name: tool.name, arguments: action.args});
        answer = 'F35-FIXTURE-WIRE-RESULT ' + JSON.stringify(result.structuredContent ?? result.content);
      } else {
        const marker = text.match(/F35-FIXTURE-CHILD-[a-z-]+/)?.[0];
        answer = marker ? marker + '-RETURN' : 'F35-FIXTURE-PROFILE-TEXT';
      }
      notify('session/update', {sessionId, update: {sessionUpdate: 'agent_message_chunk', content: {type: 'text', text: answer}}});
      send(id, {stopReason: 'end_turn'});
    }
  } catch (error) {
    process.stdout.write(JSON.stringify({jsonrpc: '2.0', id, error: {code: -32603, message: error.message}}) + '\n');
  }
});
lines.once('close', () => bridge?.stdin.end());
