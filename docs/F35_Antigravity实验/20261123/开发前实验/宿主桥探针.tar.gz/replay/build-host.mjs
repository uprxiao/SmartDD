import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {globSync, readFileSync, writeFileSync} from 'node:fs';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const {build} = createRequire(createRequire(import.meta.url).resolve('vite'))('esbuild');

const root = import.meta.dirname;
const frozen = resolve(process.env.F35_FROZEN_DIR ?? join(root, '../baseline'));
const sha = content => createHash('sha256').update(content).digest('hex');
const sources = {
  'src/main/db/migrations': ['runBundledMigrations'],
  'src/main/db/schema': ['projects', 'projectDirs', 'appSecrets'],
  'src/main/secrets': ['SecretsStore'],
  'src/main/core/projects/project-service': ['ProjectService'],
  'src/main/core/capabilities/capability-service': ['CapabilityService'],
  'src/main/core/agent/agent-store': ['AgentStore'],
  'src/main/core/agent/agent-run-service': ['AgentRunService'],
  'src/main/core/agent/agent-task-service': ['AgentTaskService'],
  'src/main/core/agent/delegation-service': ['DelegationService'],
  'src/main/core/agent/git-workspaces': ['GitWorkspaces'],
  'src/main/core/agent/driver': ['Emitter'],
  'src/main/core/applications/resource-store': ['ResourceStore'],
  'src/main/core/applications/agent-support-service': ['AgentSupportService'],
  'src/main/core/applications/application-service': ['ApplicationService'],
  'src/main/core/applications/task-capability-launcher': ['ManagedTaskCapabilities'],
  'src/main/core/applications/process-identity': ['MacProcessIdentityReader'],
  'src/main/core/applications/unix-peer-identity': ['MacUnixPeerIdentityReader'],
  'src/main/core/applications/modules/index': ['builtinApplicationModules'],
  'src/main/core/applications/run-plan': ['createApplicationRunPlan'],
  'src/main/core/applications/run-registry': ['assertOwnedCapabilityRun'],
  'src/main/core/applications/runtime-registry': ['RuntimeRegistry'],
  'src/main/core/applications/manifest': ['canonicalJson', 'digest'],
  'src/shared/application-session-v3': ['capabilitySessionSnapshotV3Schema'],
  'src/shared/application-session': ['applicationMcpServerName']
};
const entry = Object.entries(sources).map(([file, names]) => `export {${names.join(',')}} from './${file}.ts';`).join('\n');
const bundle = join(root, 'build/host.cjs');
const transforms = [];
const trace = await build({
  stdin: {contents: entry, resolveDir: root, loader: 'ts'}, bundle: true, platform: 'node', format: 'cjs',
  target: 'node22', outfile: bundle, metafile: true, tsconfig: join(root, 'tsconfig.node.json'),
  external: ['electron', 'better-sqlite3', 'node-pty'],
  define: {'import.meta.url': JSON.stringify(pathToFileURL(bundle).href)},
  plugins: [{name: 'candidate-asset-loading-and-ask-registration', setup(api) {
    api.onLoad({filter: /\/(migrations|assets|mcp-projection|agent-assets|permissions)\.ts$/}, ({path}) => {
      if (!path.startsWith(join(root, 'src') + '/')) return;
      const original = readFileSync(path, 'utf8');
      let content = original.replace(/import\.meta\.glob\('([^']+)',\s*\{[\s\S]*?\}\)/g, (_match, pattern) => {
        const resolved = pattern.replace('@root/', root + '/');
        const matches = globSync(resolved).sort().flatMap(file => {
          try {
            const data = readFileSync(file, 'utf8');
            transforms.push({asset: file.slice(root.length + 1), sha256: sha(data)});
            return [[file, data]];
          } catch { return []; }
        });
        assert(matches.length, pattern);
        return '(' + JSON.stringify(Object.fromEntries(matches)) + ')';
      });
      if (path === join(root, 'src/main/core/agent/permissions.ts')) {
        assert(content.includes("driverId === 'claude-sdk' ? CLAUDE_TIERS : null"));
        content = content.replace("driverId === 'claude-sdk' ? CLAUDE_TIERS : null",
          "driverId === 'claude-sdk' ? CLAUDE_TIERS : driverId === 'antigravity-acp' ? { ask: { permissionMode: 'default' } } : null");
      }
      if (content === original) return;
      transforms.push({source: path.slice(root.length + 1), before: sha(original), after: sha(content)});
      return {contents: content, loader: 'ts'};
    });
  }}]
});
const fingerprints = Object.keys(trace.metafile.inputs).filter(file => file.startsWith('src/')).sort().map(file => {
  const hash = sha(readFileSync(join(root, file)));
  assert.equal(hash, sha(readFileSync(join(frozen, file))), file);
  return {file, sha256: hash};
});
writeFileSync(join(root, 'build/host-build.json'), JSON.stringify({frozenSourceCommit: 'e7fc5f57ffc4191c175f0a41902e62e4d4bf3133',
  fixtures: ['esbuild inlines Vite file globs', 'Candidate antigravity-acp registered for ask only in the in-memory permissions module'],
  outputs: {host: sha(readFileSync(bundle)), bridge: sha(readFileSync(join(root, 'build/runtime/mcp-bridge.cjs'))),
    nativeIdentity: sha(readFileSync(join(root, 'build/willyou-process-identity')))},
  inputs: fingerprints, transforms}, null, 2) + '\n');
console.log(`${fingerprints.length} frozen TypeScript inputs verified`);
