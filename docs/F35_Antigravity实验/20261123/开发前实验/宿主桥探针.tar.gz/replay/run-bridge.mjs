import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {execFileSync, spawnSync} from 'node:child_process';
import {EventEmitter} from 'node:events';
import {existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, realpathSync, writeFileSync} from 'node:fs';
import {createServer as createTcpServer, connect} from 'node:net';
import {dirname, join, resolve} from 'node:path';
import {once} from 'node:events';
import {setTimeout as delay} from 'node:timers/promises';
import Database from 'better-sqlite3';
import {drizzle} from 'drizzle-orm/better-sqlite3';
import host from './build/host.cjs';
import {AcpDriver} from './acp-driver.mjs';
import {argon, carbon, profileIds, startGemini} from './local-fixtures.mjs';

const root = realpathSync(import.meta.dirname);
assert.equal(process.cwd(), root);
assert.equal(process.platform, 'darwin');
assert.equal(process.arch, 'arm64');
assert.equal(process.env.ELECTRON_RUN_AS_NODE, '1');
export const evidenceDir = mkdtempSync(join(root, 'attempt-'));
const save = (file, data) => writeFileSync(join(evidenceDir, file), JSON.stringify(data, null, 2) + '\n', {mode: 0o600});
const stopAt = process.env.F35_LAYER ?? 'all';
const result = {frozenSourceCommit: 'e7fc5f57ffc4191c175f0a41902e62e4d4bf3133',
  startedAt: new Date().toISOString(), evidenceDir, cases: [], cleanup: []};
let stage = 'initialize', db, store, app, manager, delegates, tasks, runs, model, processes, endpoint, capability;
const identities = [], bridgeProofs = [], retireProofs = [], adapters = [], childBirths = [];
const scopes = new Map(), drivers = new Map();
const diagnostics = [];
const managedMarkers = new Set();
const mkdir = path => { mkdirSync(path, {recursive: true, mode: 0o700}); return path; };
const identityHelper = join(root, 'build/willyou-process-identity');
const agy = realpathSync(process.env.F35_AGY_BIN);
const targetProfile = id => {
  assert(profileIds.includes(id), id);
  const ag = id.startsWith('agy-');
  return {profileId: id, driverId: ag ? 'antigravity-acp' : id === 'codex-fixture' ? 'codex-app-server' : 'claude-sdk',
    name: id, revision: `isolation-r1-${id}`, available: true, trustedRead: false,
    models: ag ? [carbon, argon] : [id + '-model']};
};
const allTargets = () => profileIds.map(targetProfile);
const driverStages = ['basic','resume','mcp','skills','nativeSubagents','steer','approvalsReviewer','goal','plan'];
const capabilitySet = id => Object.fromEntries(driverStages.map(name => [name, {
  state: ['basic', 'resume', 'mcp'].includes(name) || id === 'codex-app-server' && name === 'approvalsReviewer' ? 'enabled' : 'disabled',
}]));
const profileEnvironment = (home, port) => ({
  PATH: '/usr/bin:/bin:/usr/sbin:/sbin', HOME: home, TMPDIR: mkdir(join(home, 'tmp')),
  XDG_CONFIG_HOME: mkdir(join(home, 'config')), XDG_CACHE_HOME: mkdir(join(home, 'cache')),
  XDG_DATA_HOME: mkdir(join(home, 'data')), LANG: 'en_US.UTF-8', BROWSER: '/usr/bin/false',
  GEMINI_API_KEY: 'F35-SYNTHETIC-OFFLINE-CANDIDATE-KEY', GOOGLE_GEMINI_BASE_URL: `http://127.0.0.1:${port}`,
  GOOGLE_CLOUD_DISABLE_GRPC: '1', HTTP_PROXY: 'http://127.0.0.1:1', HTTPS_PROXY: 'http://127.0.0.1:1',
  ALL_PROXY: 'http://127.0.0.1:1', NO_PROXY: '127.0.0.1',
  http_proxy: 'http://127.0.0.1:1', https_proxy: 'http://127.0.0.1:1', all_proxy: 'http://127.0.0.1:1', no_proxy: '127.0.0.1',
});
const sbpl = socket => '(version 1)(allow default)(deny network*)' +
  '(allow network-bind (local ip "localhost:*"))(allow network-inbound (local ip "localhost:*"))' +
  '(allow network-outbound (remote ip "localhost:*"))' +
  (socket ? `(allow network-outbound (remote unix-socket (literal ${JSON.stringify(socket)})) (remote unix-socket (literal ${JSON.stringify('/private' + socket)})))` : '');
const proofMcp = '\n';
function seedPersonal(home, tracePath) {
  const library = mkdir(join(home, '.gemini', 'config'));
  const config = {mcpServers: {f35_personal: {command: process.execPath,
    args: [join(root, 'personal-marker.mjs'), tracePath], env: {ELECTRON_RUN_AS_NODE:'1'}}}};
  writeFileSync(join(library, 'mcp_config.json'), JSON.stringify(config), {mode: 0o600});
  return join(home, '.gemini');
}
function agyArgs(geminiDir, defaults) {
  return ['acp', '--gemini-dir', geminiDir, '--app-data-dir', 'antigravity-acp',
    '--disable-telemetry=true', `--include-default-customizations=${defaults}`, '--sandbox=true'];
}
async function positivePersonalScope(work) {
  const marker = join(evidenceDir, 'personal-positive-marker.jsonl');
  const home = mkdir(join(evidenceDir, 'personal-positive-home'));
  const geminiDir = seedPersonal(home, marker);
  const tracePath = join(evidenceDir, 'agy-personal-positive.jsonl');
  const driver = new AcpDriver({id:'antigravity-acp', launch: () => ({command:'/usr/bin/sandbox-exec',
    args:['-p', sbpl(endpoint), agy, ...agyArgs(geminiDir, true)], defaultModel:carbon, tracePath})});
  identities.push(driver);
  const traceStart = model.evidence.length;
  const promptDone = new Promise(ok => driver.on(event => {
    if (event.type === 'request') void driver.respond(event.requestKey, {behavior:'allow'});
    if (event.type === 'turn.completed') ok(event);
  }));
  try {
    await driver.open({cwd:work, env:profileEnvironment(home, model.port), model:carbon});
    await driver.startTurn({clientInputId:randomUUID(), text:'F35:PERSONAL', tier:'ask'});
    const turn = await Promise.race([promptDone, delay(4000, null, {ref:false})]);
    assert.equal(turn?.status, 'completed');
    const rows = model.evidence.slice(traceStart);
    const events = await until('personal default configuration spawn and discovery', () => {
      if (!existsSync(marker)) return;
      const events = readFileSync(marker, 'utf8').trim().split('\n').map(line => JSON.parse(line));
      if (events.some(row => ['server/discover','tools/list'].includes(row.event))) return events;
    }, 4000);
    const identity = processes.read(driver.child.pid);
    assert(identity);
    const extension = processes.read(events.find(row => row.event === 'started').pid);
    assert(extension);
    return {events, declared:rows.some(row => row.toolNames?.some(tool => tool.endsWith('f35_personal_probe'))),
      canaryReturned:rows.some(row => JSON.stringify(row.returned)?.includes('F35-PERSONAL-CANARY')),
      driverIdentity:identity, extensionIdentity:extension};
  } finally { await driver.close(); }
}
async function egressWitness() {
  const script = `const net=require('node:net'); const probe=(host,port)=>new Promise(done=>{const s=net.connect(Number(port),host); s.setTimeout(500); s.on('connect',()=>{s.end();done('connected');});s.on('error',e=>done(e.code));s.on('timeout',()=>{s.destroy();done('timeout');});});Promise.all([probe('127.0.0.1',process.argv[1]),probe('192.0.2.1',9)]).then(r=>console.log(JSON.stringify(r)));`;
  const observed = spawnSync('/usr/bin/sandbox-exec', ['-p', sbpl(endpoint), process.execPath, '-e', script, String(model.port)], {
    timeout: 4000, env: {PATH: '/usr/bin:/bin', HOME: join(evidenceDir, 'host-home'), ELECTRON_RUN_AS_NODE:'1'}, encoding: 'utf8',
  });
  assert.equal(observed.status, 0, observed.stderr);
  const outcomes = JSON.parse(observed.stdout);
  assert.equal(outcomes[0], 'connected');
  assert(['EPERM', 'EACCES'].includes(outcomes[1]), JSON.stringify(outcomes));
  return {fixturePort: model.port, fixtureReachable: true, reservedNonLoopbackAddressRejected: outcomes[1],
    loopbackEphemeralPortsRequiredByNativeLanguageServer: true};
}

function logCase(name, data) {
  result.cases.push({name, status: 'passed', ...data});
  save('progress.json', result);
  console.log(`PASS ${name}`);
}
async function until(label, fn, ms = 14_000) {
  const deadline = performance.now() + ms;
  do {
    const value = await fn();
    if (value) return value;
    await delay(25);
  } while (performance.now() < deadline);
  throw new Error(`Deadline waiting for ${label}`);
}
function snapshotRun(taskId) {
  return db.prepare('SELECT run_id,task_id,project_id,binding_id,generation,pid,process_started_at,state,driver_id,capability_session_id FROM capability_runs WHERE task_id=? ORDER BY rowid DESC LIMIT 1').get(taskId);
}
function readItems(taskId) {
  return db.prepare("SELECT item_id,task_id,turn_id,type,payload_ref FROM agent_items WHERE task_id=? AND type IN ('assistant_message','thread_created','subagent','notification','error','system_notice') ORDER BY ordinal").all(taskId);
}
async function rawBroker(message) {
  const socket = connect(endpoint);
  const frame = JSON.stringify({schema: 1, id: randomUUID(), ...message}) + proofMcp;
  try {
    await once(socket, 'connect', {signal: AbortSignal.timeout(3000)});
    socket.write(frame);
    const [data] = await once(socket, 'data', {signal: AbortSignal.timeout(3000)});
    return JSON.parse(String(data).trim());
  } finally { socket.destroy(); }
}
function assertPeer(row) {
  const proof = bridgeProofs.find(item => item.proof?.ancestors.some(parent => parent.pid === row.pid && parent.startedAt === row.process_started_at));
  assert(proof, `No inherited kernel peer for ${JSON.stringify(row)}`);
  const persisted = db.prepare("SELECT run_id, kind, pid, process_started_at FROM capability_run_processes WHERE run_id=? AND pid=? AND kind='bridge'").get(row.run_id, proof.proof.peer.pid);
  assert.deepEqual(persisted, {run_id: row.run_id, kind: 'bridge', pid: proof.proof.peer.pid, process_started_at: proof.proof.peer.startedAt});
  const scope = scopes.get(row.run_id);
  assert(scope && scope.owned.runId === row.run_id && scope.driverId === row.driver_id);
  return {run: row, bridge: persisted, currentIdentity: proof.proof.ancestors.find(parent => parent.pid === row.pid), peerExecutable: proof.proof.peer.executable,
    ticketConsumed: !existsSync(scope.ticket.bootstrapPath)};
}

async function prepareCandidate({taskId, cwd, driverId, home, stateRoot, runId, bindingId, nativeId, startupCancelled}) {
  function assertCurrent() { assert(!startupCancelled(), 'candidate start canceled'); }
  const row = store.task(taskId);
  const version = driverId === 'antigravity-acp' ? result.agy.version : '1.0.0';
  const projectId = row.project_id;
  const selected = manager.authorization.selectedApps(projectId);
  assert.deepEqual(selected.map(it => it.appId), ['sample-kv']);
  const bindings = manager.authorization.bindings(projectId, selected.map(it => it.appId));
  const packages = selected.map(it => manager.authorization.packageSelection(projectId, it.packageHash, bindings, []));
  const runtimeHash = packages[0].runtimeHash, adapter = adapters.find(item => item.driverId === driverId);
  const server = host.applicationMcpServerName(host.digest(taskId));
  const snapshot = host.capabilitySessionSnapshotV3Schema.parse({
    schema: 3, taskId, projectId, createdAt: new Date().toISOString(),
    runner: driverId, adapterBinding: {id: driverId, version: '1.0.0', hash: adapter.contentHash, projectionFormatVersion: 1, nativeToolNames: {}},
    native: {sessionId: nativeId ?? null, stateRoot, cwd},
    agentAtCreation: {version, adapterRevision: 1}, catalogGeneration: 'isolated-f35-candidate',
    packages, standardSkills: [], mcp: [{kind: 'applications', serverName: server, protocolMajor: 1, runtimeHash}], provenance: 'created',
  });
  const hash = host.digest(host.canonicalJson(snapshot));
  const sources = selected.map(it => {
    const pack = app.builtin.retainedMetadata(it.packageHash);
    return {packageHash: it.packageHash, manifest: pack.manifest, capabilities: host.builtinApplicationModules.capabilityViews(pack.manifest)};
  });
  const plan = host.createApplicationRunPlan({runId, snapshotHash: hash, snapshot, applications: sources, skills: [],
    available: {mcp: true, cli: false}, cliVersion: version});
  const business = JSON.stringify({kind: 'business', snapshot, runId});
  const update = db.prepare("UPDATE agent_capability_sessions SET content_hash=?,snapshot_json=? WHERE binding_id=? AND capability_session_id=(SELECT capability_session_id FROM capability_runs WHERE run_id=? AND pid IS NULL AND state='preparing') AND json_extract(snapshot_json,'$.kind')='run_preparing'");
  assert.equal(update.run(host.digest(business), business, bindingId, runId).changes, 1);
  const owned = await manager.runs.adoptAgentRun(runId, bindingId, {
    session: {snapshot, pointer: {schema: 3, taskId, snapshotHash: hash}, selectionHash: hash, discoveryHome: home, retention: 'active', legacyStatus: 'created'},
    resourceIds: [adapter.resourceId, 'runtime:' + runtimeHash, ...packages.map(pack => 'app:' + pack.packageHash)], bindings: [],
    plan, assertCurrent, verify: async () => {
      new host.RuntimeRegistry(app.store).verify(runtimeHash);
      assert.equal(host.digest(readFileSync(join(app.store.directory(adapter), 'driver.mjs'))), adapter.contentHash);
    },
  });
  await owned.prepare();
  host.assertOwnedCapabilityRun(manager.runs, owned);
  assert.throws(() => host.assertOwnedCapabilityRun(manager.runs, {...owned}), err => err.code === 'SCOPE_DENIED');
  const ticket = await manager.broker.reserve(owned, server, assertCurrent);
  const scope = {taskId, driverId, owned, ticket};
  scopes.set(runId, scope);
  return {
    extraArgs: [], env: {}, mcpServers: {[server]: {command: process.execPath,
      args: [join(app.store.root, 'runtime', runtimeHash, 'mcp-bridge.cjs'), '--bootstrap', ticket.bootstrapPath],
      env: {ELECTRON_RUN_AS_NODE: '1'}}},
    assertCurrent,
    beforeFork: async () => {
      assertCurrent(); await ticket.bridge.arm(); await owned.cli.arm(); ticket.issue();
      scope.oldTicket = JSON.parse(readFileSync(ticket.bootstrapPath, 'utf8'));
    },
    attached: async pid => {
      const identity = processes.read(pid);
      assert(identity && identity.pid === pid);
      childBirths.push({runId, driverId, identity});
      await owned.cli.attach(pid, identity.startedAt);
    },
    exited: async () => {
      manager.broker.revokeRun(runId);
      await manager.bridges.poll();
      await owned.cli.exited();
      await until(`run ${runId} release`, () => ['stopped', 'failed'].includes(manager.runs.get(runId).state));
    },
    cancelBeforeFork: async () => {
      await ticket.cancel();
      await owned.cli.cancelUnforked();
      await owned.stop('unforked-candidate');
    },
  };
}

function makeTask(profileId, cwd, title, tier = 'ask') {
  const task = tasks.create({projectId: result.projectId, dirId: null, cwd, title, profileId, tier,
    model: targetProfile(profileId).models[0]});
  return task.taskId;
}
async function submit(taskId, text) {
  const revision = store.task(taskId).selection_revision;
  return tasks.submit(taskId, {text, clientInputId: randomUUID(), expectedSelectionRevision: revision});
}
function approval(taskId) {
  return store.pendingRequests(taskId).find(request => request.class === 'native' && request.kind === 'tool_approval');
}
async function resolveTurn(taskId, turnId) {
  return until('prompt completes or permission arrives', async () => {
    const request = approval(taskId);
    if (request) {
      await tasks.respond(taskId, request.requestId, request.revision, {behavior: 'allow', updatedInput: {notTrusted: 'synthetic client amendment'}});
    }
    const row = store.turn(turnId);
    if (!['accepted', 'dispatching', 'started'].includes(row.status)) return row;
  });
}
async function delegateFrom(parentTaskId, target, key) {
  delegates.setMode(parentTaskId, true);
  const submission = await submit(parentTaskId, `F35:DELEGATE:${target}:${key}`);
  const ready = await resolveTurn(parentTaskId, submission.turnId);
  assert.equal(ready.status, 'completed', JSON.stringify(ready));
  const relation = await until('real delegation row', () => db.prepare("SELECT * FROM agent_delegations WHERE parent_task_id=? AND request_key=?").get(parentTaskId, `f35-${target}-${key}`));
  assert.equal(relation.parent_run_id, ready.run_id);
  return relation;
}
async function reloadTicket(row) {
  const old = scopes.get(row.run_id).oldTicket;
  const {secret, bridgeId} = old;
  const response = await rawBroker({method: 'exchange', runId: row.run_id, bridgeId, secret});
  assert.equal(response.status, 'error');
  assert.equal(response.error.code, 'AUTH_REQUIRED');
  return {code: response.error.code, auditId: response.auditId, brokerRejected: true};
}

try {
  result.agy = {path: agy, version: execFileSync('/usr/bin/sandbox-exec', ['-p', '(version 1)(allow default)(deny network*)', agy, '--version'], {env: {HOME: mkdir(join(evidenceDir, 'host-home')), PATH: '/usr/bin:/bin'}, timeout: 4000, encoding: 'utf8'}).trim(), sha256: host.digest(readFileSync(agy))};
  result.host = {node: process.versions.node, abi: process.versions.modules, platform: process.platform, arch: process.arch,
    build: JSON.parse(readFileSync(join(root, 'build/host-build.json'))).outputs};
  stage = 'local-loopback';
  model = await startGemini();
  stage = 'prepare-host-database-and-runtime';
  const userData = mkdir(join(evidenceDir, 'data'));
  const work = mkdir(join(evidenceDir, 'project'));
  const stateHome = mkdir(join(evidenceDir, 'profiles'));
  db = new Database(join(userData, 'state.sqlite'));
  db.pragma('foreign_keys=ON');
  result.migrations = host.runBundledMigrations(db);
  const drizzleDb = drizzle(db, {schema: {projects: host.projects, projectDirs: host.projectDirs, appSecrets: host.appSecrets}});
  const secretStore = new host.SecretsStore(drizzleDb, {isAvailable: () => true, encrypt: value => Buffer.from(value), decrypt: bytes => bytes.toString()});
  const projects = new host.ProjectService(drizzleDb, secretStore);
  result.projectId = projects.createProject({name: 'F35 isolated host bridge', aliases: [], description: '', rulesPath: null}, [{label: 'fixture', path: work}]).id;
  const resource = new host.ResourceStore(db, userData);
  capability = new host.CapabilityService({db: drizzleDb, projects, secrets: secretStore, userData});
  const support = new host.AgentSupportService(resource, capability, join(root, 'build/capability-bundles'));
  await support.initialize();
  assert.equal(support.status().state, 'ready', JSON.stringify(support.status()));
  result.applicationRuntime = support.status().runtimeHash;
  processes = new host.MacProcessIdentityReader(identityHelper);
  app = new host.ApplicationService(resource, {secrets: secretStore, projects,
    tasks: {stopProject: async () => true, runningInProject: () => 0}, requireSender: sender => assert.equal(sender.sender.id, 803),
    mailWorker: join(userData, 'unused-mail-worker'), foxmailNative: join(userData, 'unused-foxmail'), processes});
  await app.recover();
  db.prepare("UPDATE application_project_settings SET enabled=0 WHERE project_id=? AND app_id IN ('mail','browser')").run(result.projectId);
  const sender = {sender: Object.assign(new EventEmitter(), {id: 803, isDestroyed: () => false}), senderFrame: {}};
  await app.setAdded(sender, 'sample-kv', true, 0);
  const tested = await app.testConnection(sender, {expectedRevision: 0, name: 'F35 isolated reference',
    config: {kind: 'sample-kv', service: 'f35-isolated', prefix: 'demo:', transport: 'mcp', authMode: 'token'}, secret: 'SYNTHETIC_F35_REFERENCE'});
  const connection = await app.saveConnection(sender, 'sample-kv', tested.operationId, tested.candidateHash);
  result.connectionId = connection.id;
  await app.select(sender, {projectId: result.projectId, appId: 'sample-kv', enabled: true, expectedRevision: 0, connections: {'sample-kv': connection.id}});
  stage = 'real-private-broker';
  const kernel = new host.MacUnixPeerIdentityReader(identityHelper);
  manager = await host.ManagedTaskCapabilities.open(support, capability, app, {helper: identityHelper, processes, peers: {
    read: async socket => {
      const proof = await kernel.read(socket);
      bridgeProofs.push({proof});
      return proof;
    },
  }, pollMs: 35, stopPty: () => {}});
  endpoint = manager.broker.endpoint;
  result.egress = await egressWitness();
  stage = 'compose-probe-adapter-with-frozen-host';
  for (const driverId of ['antigravity-acp', 'codex-app-server', 'claude-sdk']) {
    const bytes = Buffer.concat([readFileSync(join(root, 'acp-driver.mjs')), Buffer.from('\n// ' + driverId + '\n')]);
    const hash = host.digest(bytes);
    const adapter = await resource.publish({
      resourceId: `agent-adapter:${driverId}:${hash}`, kind: 'agent-adapter', contentHash: hash, relativePath: `f35-candidate/${hash}`,
      dependencies: [], materialize: dir => { mkdir(dir); writeFileSync(join(dir, 'driver.mjs'), bytes); },
      verify: dir => assert.equal(host.digest(readFileSync(join(dir, 'driver.mjs'))), hash),
    });
    adapters.push({...adapter, driverId});
    drivers.set(driverId, {id: driverId, command: driverId === 'antigravity-acp' ? agy : process.execPath,
      create: () => {
        const driver = new AcpDriver({id: driverId, launch: options => {
          const tracePath = join(evidenceDir, `${driverId}-${randomUUID()}.jsonl`);
          if (driverId !== 'antigravity-acp') return {command: process.execPath, args: [join(root, 'counterpart-agent.mjs')],
            defaultModel: options.model, tracePath};
          const args = agyArgs(join(options.env.HOME, 'managed-gemini'), false);
          return {command: '/usr/bin/sandbox-exec', args: ['-p', sbpl(endpoint), agy, ...args], defaultModel: options.model, tracePath};
        }});
        identities.push(driver);
        return driver;
      }});
  }
  store = new host.AgentStore(db);
  const hostIdentity = processes.read(process.pid);
  assert(hostIdentity);
  runs = new host.AgentRunService({store, drivers, processes, host: {instanceId: randomUUID(), pid: process.pid, startedAt: hostIdentity.startedAt}});
  runs.onLive(event => { if (event.event.type === 'diagnostic') diagnostics.push(event); });
  tasks = new host.AgentTaskService({store, runs, userData, profileDriver: id => targetProfile(id).driverId,
    resolveLaunch: async ({taskId, profileId, cwd}) => {
      const profile = targetProfile(profileId), driverId = profile.driverId, ag = driverId === 'antigravity-acp';
      const home = mkdir(join(stateHome, taskId));
      const stateRoot = mkdir(join(home, 'managed-gemini'));
      if (ag) {
        const marker = join(home, 'personal-extension-marker.jsonl');
        seedPersonal(home, marker);
        managedMarkers.add(marker);
      }
      const env = ag ? profileEnvironment(home, model.port) : {HOME: home, TMPDIR: mkdir(join(home, 'tmp')),
        PATH: '/usr/bin:/bin', ELECTRON_RUN_AS_NODE: '1'};
      return {driverId, executable: {path: ag ? agy : process.execPath, version: ag ? result.agy.version : '1.0.0'},
        stateRoot, env, compatibility: {candidate: true, testProfile: profileId}, extraArgs: [], model: profile.models[0],
        capabilities: capabilitySet(driverId), integrate: meta => prepareCandidate({...meta, taskId, home, stateRoot, cwd, driverId})};
    }});
  delegates = new host.DelegationService({store, runs, tasks, git: new host.GitWorkspaces({store, home: join(evidenceDir, 'host-home')}),
    profile: targetProfile, profiles: allTargets, roots: taskId => [store.task(taskId).cwd], project: () => ({id: result.projectId, name: 'F35 isolated project'})});
  manager.attachAgentTools(delegates);

  if (stopAt === 'personal') {
    stage = 'A15-personal-positive-control';
    const configured = await positivePersonalScope(work);
    logCase('A15 personal positive control process and discovery', configured);
    throw {done:true};
  }

  stage = 'A15-real-agy-target-and-business-read';
  const mainId = makeTask('agy-parent', work, 'A15 main');
  const targetTurn = await submit(mainId, 'F35:TARGETS');
  const targetTurnDone = await resolveTurn(mainId, targetTurn.turnId);
  assert.equal(targetTurnDone.status, 'completed', JSON.stringify(targetTurnDone));
  assert(readItems(mainId).some(item => item.payload_ref.includes('isolation-r1-agy-child')), JSON.stringify(readItems(mainId)));
  const mainRow = snapshotRun(mainId);
  const firstPeer = assertPeer(mainRow);
  const readTurn = await submit(mainId, 'F35:READ:baseline');
  assert.equal((await resolveTurn(mainId, readTurn.turnId)).status, 'completed');
  const readResult = model.evidence.flatMap(item => item.returned ?? []).find(item => JSON.stringify(item).includes('demo:baseline'));
  assert(readResult, JSON.stringify(model.evidence.slice(-4)));
  logCase('A15 target list and sample read through real agy, actual broker and OS peer', {targetIds: profileIds, peer: firstPeer, readResult});
  stage = 'A15-cold-restart-and-stale-ticket';
  await runs.close(mainRow.run_id);
  await until('A15 original run stops', () => snapshotRun(mainId).state === 'stopped');
  const staleTicket = await reloadTicket(mainRow);
  const restored = await submit(mainId, 'F35:TARGETS');
  assert.equal((await resolveTurn(mainId, restored.turnId)).status, 'completed');
  const follow = snapshotRun(mainId);
  assert.equal(follow.binding_id, mainRow.binding_id);
  assert.equal(follow.generation, mainRow.generation + 1);
  assert.notEqual(follow.run_id, mainRow.run_id);
  logCase('A15 stale Unix ticket denied and restored session uses a new run', {old: firstPeer, staleTicket, restored: assertPeer(follow)});
  await runs.close(follow.run_id);
  const managedRequests = [...model.evidence];
  stage = 'A15-personal-extension-positive-and-managed-negative';
  assert(managedMarkers.size > 0);
  assert([...managedMarkers].every(path => !existsSync(path)));
  assert(managedRequests.every(row => !row.toolNames?.some(tool => tool.endsWith('f35_personal_probe'))));
  const configured = await positivePersonalScope(work);
  await until('personal control process cleanup', () => processes.state(configured.driverIdentity) === 'stopped' && processes.state(configured.extensionIdentity) === 'stopped', 2500);
  logCase('A15 managed personal-extension isolation', {positiveControl: configured,
    managedProfilesWithSeededPersonalConfig: [...managedMarkers].length, personalToolNotDeclared: true, personalProcessNotStarted: true, positiveControlProcessesStopped: true});
  if (stopAt === 'a15') throw {done: true};

  for (const decision of ['allow', 'deny', 'late']) {
    stage = 'A16-' + decision;
    const cwd = mkdir(join(work, decision));
    const parent = makeTask('agy-parent', cwd, `A16 parent ${decision}`);
    const relation = await delegateFrom(parent, 'agy-child', decision);
    const child = relation.child_task_id;
    const request = await until(`A16 ${decision} real child approval`, () => approval(child), 19_000);
    const row = snapshotRun(child);
    assert.equal(request.origin.runId, row.run_id);
    assert.equal(request.origin.taskId, child);
    assert.equal(request.origin.generation, row.generation);
    assert.equal(request.origin.bindingId, row.binding_id);
    assert.equal(row.driver_id, 'antigravity-acp');
    const childPeer = assertPeer(row);
    const bodyView = tasks.requestBody(child, request.requestId, 0, request.revision);
    assert(JSON.stringify(bodyView).includes('smartdd_sample_kv_write_v2'), JSON.stringify(bodyView));
    assert(JSON.stringify(bodyView).includes('demo:' + decision), JSON.stringify(bodyView));
    const mismatched = await tasks.respond(parent, request.requestId, request.revision, {behavior: 'allow'}).then(() => 'accepted', error => error.message);
    assert.match(mismatched, /请求不存在/);
    const readKey = async () => (await app.invokeCapability(sender, result.projectId, 'sample-kv', 'sample-kv.entry.read', {key: 'demo:' + decision})).data;
    assert.deepEqual(await readKey(), {key:'demo:' + decision, value:null, revision:0, operationId:null});
    let repeat;
    if (decision === 'late') {
      await delegates.cancel(parent, child);
      await until('A16 retired pending approval', () => store.request(request.requestId).status === 'retired');
      repeat = await tasks.respond(child, request.requestId, request.revision, {behavior: 'allow'}).then(() => 'accepted', error => error.message);
    } else {
      await tasks.respond(child, request.requestId, request.revision, {behavior: decision, updatedInput: {key: 'demo:forged'}});
      await until('A16 settled approval', () => store.request(request.requestId).status === 'resolved');
      if (decision === 'allow') repeat = await tasks.respond(child, request.requestId, request.revision, {behavior:'allow'}).then(() => 'accepted', error => error.message);
    }
    if (repeat) assert.match(repeat, /请求已结束|已结束的运行/);
    await until('delegated child drained', () => ['stopped', 'failed'].includes(snapshotRun(child)?.state), 20_000);
    const status = store.request(request.requestId).status;
    assert.equal(status, decision === 'late' ? 'retired' : 'resolved');
    const business = await readKey();
    assert.deepEqual(business, {key:'demo:' + decision, value: decision === 'allow' ? 'F35-MARKER-allow' : null, revision: decision === 'allow' ? 1 : 0,
      operationId: decision === 'allow' ? business.operationId : null});
    const qa = db.prepare('SELECT tool_name AS operation,task_id,run_id,state,attempt_count FROM application_invocations WHERE task_id=?').all(child);
    const writeOperations = qa.filter(row => row.operation === 'smartdd_sample_kv_write_v2');
    assert.equal(writeOperations.length, decision === 'allow' ? 1 : 0, JSON.stringify(qa));
    if (writeOperations.length) assert.equal(writeOperations[0].run_id, row.run_id);
    const directory = join(app.store.root, 'reference-services', host.digest('f35-isolated'));
    const destination = join(directory, host.digest('demo:' + decision) + '.json');
    const persisted = existsSync(destination) ? JSON.parse(readFileSync(destination, 'utf8')) : null;
    assert.deepEqual(persisted, decision === 'allow' ? business : null);
    assert(!existsSync(join(directory, host.digest('demo:forged') + '.json')));
    logCase('A16 ' + decision, {relation, request: {id: request.requestId, revision: request.revision, origin: request.origin, body: bodyView, status},
      mismatched, repeat, childPeer, business, writeOperations, persisted});
  }
  if (stopAt === 'a16') throw {done: true};

  stage = 'A17-A20-generic-scheduler-with-deterministic-counterparts';
  for (const [parentProfile, childProfile, abbreviation] of [
    ['agy-parent', 'codex-fixture', 'a17'], ['agy-parent', 'claude-fixture', 'a18'],
    ['codex-fixture', 'agy-child', 'a19'], ['claude-fixture', 'agy-child', 'a20'],
  ]) {
    const cwd = mkdir(join(work, abbreviation));
    const parent = makeTask(parentProfile, cwd, `F35 ${abbreviation}`, parentProfile === 'codex-fixture' ? 'auto' : 'ask');
    const relation = await delegateFrom(parent, childProfile, abbreviation + '-text');
    const child = relation.child_task_id;
    const settled = await until('delivered host receipt for ' + abbreviation,
      () => db.prepare("SELECT * FROM agent_delegations WHERE child_task_id=? AND delivery_state='delivered'").get(child), 20_000);
    const childRow = snapshotRun(child);
    assert.equal(childRow.driver_id, targetProfile(childProfile).driverId);
    const expected = childProfile === 'agy-child' ? 'F35-REAL-AGY-CHILD-RETURN-' + argon : 'F35-FIXTURE-CHILD-' + childProfile + '-RETURN';
    const childItems = readItems(child);
    assert(childItems.some(item => item.payload_ref.includes(expected)), JSON.stringify(childItems));
    const output = db.prepare("SELECT item_id,type,payload_ref FROM agent_items WHERE task_id=? AND json_extract(payload_ref,'$.childTaskId')=? ORDER BY ordinal").all(parent, child);
    const returns = output.filter(item => item.payload_ref.includes(expected));
    assert.equal(returns.length, 1, JSON.stringify(output));
    const acceptedTarget = JSON.parse(settled.target_json);
    if (parentProfile === 'codex-fixture') {
      assert.equal(acceptedTarget.parentTier, 'auto'); assert.equal(acceptedTarget.tier, 'ask'); assert(acceptedTarget.tierNotice);
    }
    logCase(abbreviation.toUpperCase() + ' paired with deterministic counterpart', {relation: settled, target: acceptedTarget, child: childRow, result: returns[0]});
  }
} catch (error) {
  if (!error?.done) {
    result.error = {stage, message: error.message ?? String(error), stack: error.stack};
    process.exitCode = 1;
    console.error(result.error);
  }
} finally {
  const cleanup = async (name, cleanup) => {
    try { result.cleanup.push({name, ...await cleanup()}); } catch (error) {
      result.cleanup.push({name, error: error.message});
      process.exitCode = 1;
    }
  };
  await cleanup('delegation-service', async () => { await delegates?.close(); });
  await cleanup('native-runs', async () => {
    await runs?.closeAll();
    await Promise.all(identities.map(driver => driver.close()));
    const processStates = childBirths.map(row => ({...row, state: processes.state(row.identity)}));
    assert(processStates.every(row => row.state === 'stopped'), JSON.stringify(processStates));
    return {processes: processStates,
      drivers: identities.map(d => ({id: d.driverId, pid: d.child?.pid, exit: d.exitOutcome, tracePath: d.tracePath}))};
  });
  await cleanup('private-broker', async () => {
    await manager?.dispose();
    const gone = !endpoint || !existsSync(endpoint) && !existsSync(dirname(endpoint));
    assert(gone);
    const peers = bridgeProofs.filter(it => it.proof).map(({proof}) => ({pid: proof.peer.pid, startedAt: proof.peer.startedAt, state: processes.state(proof.peer)}));
    assert(peers.every(item => item.state === 'stopped'), JSON.stringify(peers));
    return {endpoint, socketAndPrivateBrokerDirRemoved: gone, peers};
  });
  await cleanup('application-service', async () => { await app?.dispose(); capability?.dispose(); });
  await cleanup('sqlite', async () => {
    if (!db) return {};
    try {
      const foreignKeys = db.pragma('foreign_key_check'), integrity = db.pragma('integrity_check');
      const leases = db.prepare("SELECT owner_id,state FROM capability_resource_leases WHERE state<>'released'").all();
      const pendingProcesses = db.prepare("SELECT run_id,kind,state FROM capability_run_processes WHERE state NOT IN ('exited','canceled')").all();
      const aggregate = {foreignKeys, integrity, leftoverLeases: leases, pendingProcesses,
        invocationRows: db.prepare('SELECT tool_name AS operation,task_id,run_id,state,attempt_count FROM application_invocations ORDER BY rowid').all(),
        operations: db.prepare('SELECT task_id,run_id,operation_id,action,caller_kind FROM application_data_operations ORDER BY rowid').all(),
        approvalRows: db.prepare('SELECT request_id,task_id,kind,status,revision,origin_json,decision_ref FROM agent_requests ORDER BY rowid').all(),
        brokerDenials: db.prepare('SELECT audit_id,run_id,bridge_id,method,error_code FROM capability_broker_denials ORDER BY rowid').all()};
      save('database-evidence.json', aggregate);
      assert.deepEqual(foreignKeys, []); assert.deepEqual(integrity, [{integrity_check:'ok'}]);
      assert.deepEqual(leases, []); assert.deepEqual(pendingProcesses, []);
      return {foreignKeys, integrity, leasesReleased: true, pendingProcesses};
    } finally { db.close(); }
  });
  await cleanup('deterministic-loopback', async () => { await model?.close(); return {port: model?.port, closed: !!model}; });
  if (model) save('local-model-evidence.json', model.evidence);
  save('kernel-peer-evidence.json', bridgeProofs);
  save('diagnostics.json', diagnostics);
  result.finishedAt = new Date().toISOString();
  result.success = !process.exitCode;
  save('result.json', result);
  writeFileSync(join(root, 'latest.json'), JSON.stringify({resultPath: join(evidenceDir,'result.json'), success: result.success}, null, 2) + '\n');
  console.log(JSON.stringify({resultPath: join(evidenceDir, 'result.json'), success: result.success}));
}
