#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
run_root="$(/bin/pwd -P)"
repo_dir="${F35_REPO_DIR:-/Users/liubu/hx/4.uprxiao/SmartDD}"
commit=e7fc5f57ffc4191c175f0a41902e62e4d4bf3133
test -d "$repo_dir/node_modules"
test ! -e "$run_root/src"
test ! -e "$run_root/node_modules"
mkdir -p "$run_root/frozen-prep" "$run_root/build/clang-cache" "$run_root/build/cache"
git -C "$repo_dir" archive "$commit" src drizzle package.json tsconfig.json tsconfig.node.json tsconfig.web.json \
  resources native/applications/process-identity.cc licenses/M10/bridge plugins/zentao/src \
  scripts/applications/build-runtime.mjs scripts/applications/build-bundles.mjs scripts/applications/verify-bundles.cjs \
  | tar -xf - -C "$run_root/frozen-prep"
for path in src drizzle resources native licenses plugins scripts package.json tsconfig.json tsconfig.node.json tsconfig.web.json; do
  cp -R "$run_root/frozen-prep/$path" "$run_root/$path"
done
ln -s "$repo_dir/node_modules" "$run_root/node_modules"
export CLANG_MODULE_CACHE_PATH="$run_root/build/clang-cache"
export XDG_CACHE_HOME="$run_root/build/cache"
/usr/bin/clang++ -std=c++17 -O2 -Wall -Wextra -arch arm64 native/applications/process-identity.cc -o build/willyou-process-identity
node scripts/applications/build-runtime.mjs build/runtime
node scripts/applications/build-bundles.mjs build/capability-bundles build/runtime/mcp-bridge.cjs
F35_FROZEN_DIR="$run_root/frozen-prep" node build-host.mjs
