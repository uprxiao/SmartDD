from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import sys
from tempfile import mkdtemp
from threading import Thread

sys.path.insert(0, str(Path(__file__).parent / "prior"))
from agy_key_path_probe import RpcProcess
from agy_observe_routes import handshake, summarize_config

class Fixture(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_CONNECT(self):
        self.send_error(403, "Fixture never forwards.")

    def do_POST(self):
        if not self.path.startswith("/v1beta/models/gemini-4-carbon:streamGenerateContent"):
            self.send_error(403, "Fixture only responds on its local model route.")
            return
        request = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        last = request["contents"][-1]["parts"]
        if not self.server.tools:
            self.server.tools.update({entry["name"]: entry for group in request["tools"]
                for entry in group.get("functionDeclarations", [])})
        name = next((x for x in ("write_file", "write_to_file") if x in self.server.tools), None)
        part = {"text": "DISCOVERY"}
        if name and all("functionResponse" not in item for item in last):
            tool_args = {"file_path": "native.txt", "content": "NATIVE-WRITTEN\n", "toolSummary": "Write the synthetic native marker"}
            schema = self.server.tools[name].get("parameters", {})
            params = schema.get("properties", {})
            if "TargetFile" in params:
                tool_args = {"TargetFile": "native.txt", "CodeContent": "NATIVE-WRITTEN\n", "Description": "Write the synthetic native marker"}
            part = {"functionCall": {"name": name, "args": tool_args},
                    "thoughtSignature": "RjM1LVNDUklQVEVELVRPT0w="}
        if any("functionResponse" in item for item in last):
            self.server.results.append(last)
        data = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [part]},
                 "finishReason": "STOP"}], "modelVersion": "gemini-4-carbon",
                "usageMetadata": {"promptTokenCount": 12, "candidatesTokenCount": 5, "totalTokenCount": 17}}
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        self.wfile.write(b"data: " + json.dumps(data).encode() + b"\n\n")

base = Path(mkdtemp(prefix="discovery-state-", dir=Path(__file__).parent))
cwd = base / "project"
home = base / "home"
for path in (cwd, home, home / "tmp"):
    path.mkdir()
server = ThreadingHTTPServer(("127.0.0.1", 0), Fixture)
server.tools, server.results = {}, []
thread = Thread(target=server.serve_forever, daemon=True)
thread.start()
endpoint = f"http://127.0.0.1:{server.server_port}"
env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(home / "tmp"),
       "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
       "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
       "GEMINI_API_KEY": "F35-FIXTURE-PLACEHOLDER", "GOOGLE_GEMINI_BASE_URL": endpoint}
for key in ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY", "https_proxy", "http_proxy", "all_proxy"):
    env[key] = endpoint
env["NO_PROXY"] = env["no_proxy"] = "127.0.0.1"
args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
        "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
wire = None
record = {}
try:
    wire = RpcProcess(args, cwd, env)
    def permit(req):
        record.setdefault("permissions", []).append(req)
        options = req.get("params", {}).get("options", [])
        option = next((o for o in options if o.get("kind") == "allow_once"), None)
        if req.get("method") == "session/request_permission" and option:
            return {"result": {"outcome": {"outcome": "selected", "optionId": option["optionId"]}}}
        return {"result": {"outcome": {"outcome": "cancelled"}}}
    wire.answer_request = permit
    record["handshake"] = handshake(wire)
    opened = wire.call("session/new", {"cwd": str(cwd), "mcpServers": []})
    session = opened["result"]["sessionId"]
    record["model"] = summarize_config(wire.call("session/set_config_option",
        {"sessionId": session, "configId": "model", "value": "gemini-4-carbon"}), "model")
    record["turn"] = wire.call("session/prompt",
        {"sessionId": session, "prompt": [{"type": "text", "text": "Write a synthetic marker in native.txt."}]})
    record["updates"] = wire.notifications
    record["readback"] = (cwd / "native.txt").read_text() if (cwd / "native.txt").exists() else None
finally:
    if wire:
        wire.close()
        record["nativeExit"] = wire.proc.returncode
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
    record["functions"] = sorted(server.tools)
    record["interestingFunctions"] = {name: row for name, row in server.tools.items()
        if any(word in name for word in ("file", "shell", "command"))}
    record["reports"] = server.results
    (Path(__file__).parent / "native-discovery.json").write_text(json.dumps(record, indent=2) + "\n")
    shutil.rmtree(base)
