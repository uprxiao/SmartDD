# F35 目录与恢复技研复验

2026-11-23 在 macOS arm64 上使用真实 Antigravity CLI 1.5.14、仅回环的确定性 Gemini 服务，以及 `e7fc5f57ffc4191c175f0a41902e62e4d4bf3133` 的 WillYou 主进程源码。临时 Git、SVN、普通目录和 SQLite 均由探针建立，使用占位凭据。App 层及真实模型层留待正式验收。

| 用例 | 技研实测 | 待完成 |
| --- | --- | --- |
| F35-A23 | 三类目录都用真实 `agy` 的 `write_file`、`read_file` 和写入审批。实际 `DirectoryQueue` 将符号链接和物理工作目录识别为同一写入根。父进程仍活跃时无法交出资格，子退出后父重获资格并以原会话读到追加内容。Git 的 HEAD 保持原提交，SVN 和 Git 均可见未提交文件。 | 将新执行器接入委派服务后完整验收真实 App 中的派发和展示。 |
| F35-A24 | 实际 `GitWorkspaces` 按基准 HEAD 创建并映射 `sub`。父任务等待原生写入审批期间，子进程独立写文件。双方文件各自留在原目录，父未提交文件未带入。宿主提交并持久化了单一子任务提交及溯源。 | 委派尝试外键由探针准备。正式验收托管 Antigravity 委派、关系卡和真实 App 界面。 |
| F35-A25 | 原生文件写入审批等待时取消 ACP 回合，原回执补发批准也未写盘。SQLite、宿主辅助进程与 agy 原生进程重新打开后，已取消的排队项无法再取得资格，同一原生会话保留历史、配置及工作目录。后续写入可独立审批并正常完成。 | 正式验收整棵任务树停止、打包 App 异常重启和结果收据只投递一次。 |

冻结宿主的驱动枚举目前只包括 Codex、Claude Code。探针为数据表设置了既有枚举值并单独运行真实 `agy`。宿主队列、会话绑定存储、Git 工作副本、Git 命令和迁移来自冻结源码。进程调度与原生 ACP 适配在探针中完成。审批的合成允许只作用于本轮生成的文件。

## 证据

- `attempt-002/result.json` 保存所有模型请求的脚本步骤、原生工具响应、确认的模型与档位、权限回执、进程工作目录和磁盘核对。
- `attempt-002/cleanup.json` 记录 13 个 agy 及两个无界面的 Electron Node 进程正常退出、模型端口关闭和运行目录删除。`cleanup-verification.json` 再查了原进程号。
- `attempt-001/result.json` 记录临时委派尝试夹具缺 `created_at` 导致的失败。下一轮补该字段后复跑。目录、写入、审批和提交的断言沿用原判据。
- `native-discovery*.json` 记录本机工具声明、错误参数和相对路径的原生拒绝，以及使用绝对路径并批准后的真实写入。两个发现阶段错误均先保留再改对应试验输入。
- `sandbox-check.txt` 保存默认执行环境拒绝回环监听的实际报错。需要能监听 `127.0.0.1` 的执行环境以复跑。运行中的模型夹具拒绝其他请求且不转发。

## 复跑

需要 macOS、Python 3.11、Node.js、可运行的 `agy`、Git 和 SVN、SmartDD 已安装依赖，以及冻结提交的源码树。使用只读的已安装依赖运行一个无界面的 Electron Node 辅助进程。运行目录由探针创建，结束时自动回收。

```sh
f35_repo="/path/to/SmartDD"
f35_baseline="/path/to/extracted-baseline"
node build-host.cjs "$f35_repo" "$f35_baseline" host-fixture.mjs
node --check host-fixture.mjs
F35_REPO="$f35_repo" F35_AGY_BIN="/path/to/agy" PYTHONDONTWRITEBYTECODE=1 python3 directory-probe.py attempt-replay
```

`f35_baseline` 应有冻结提交的 `src/` 和 `drizzle/`。目标目录需允许监听回环及创建自己的临时项目和用户状态。选择新的执行结果目录以保留既有证据。
