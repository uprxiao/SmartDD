"""Local-only F35 directory and native session integration probe."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import subprocess
import sys
from tempfile import mkdtemp
from threading import Event, Thread
from time import monotonic
import traceback
from urllib.parse import urlsplit

SOURCES = Path(__file__).resolve().parent
sys.path.insert(0, str(SOURCES / "prior"))
from acp_probe import AGY
from agy_key_path_probe import RpcProcess
from agy_observe_routes import summarize_config

REPO = Path(os.environ.get("F35_REPO", "/Users/liubu/hx/4.uprxiao/SmartDD"))
ELECTRON = REPO / "node_modules/electron/dist/Electron.app/Contents/MacOS/Electron"
BASELINE = "e7fc5f57ffc4191c175f0a41902e62e4d4bf3133"
MODELS = ("gemini-4-carbon", "gemini-4-argon")
MARKER = re.compile(r"F35_CASE_[A-Z_]+")
DRAINED = dict(nativeExited=True, descendantsDrained=True, businessDrained=True, admissionFrozen=True)
HASHED = {"write_file", "read_file"}
PROBE_PATH = "/v1beta/models/"
LIVE = "end_turn"


def utc():
    return datetime.now(timezone.utc).isoformat()


def require(value, label, context=None):
    if not value:
        raise AssertionError(f"{label}: {context!r}")


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def clean_env(home):
    home.mkdir(parents=True, exist_ok=True)
    private_tmp = home / "tmp"
    private_tmp.mkdir(exist_ok=True)
    return {"PATH": "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
            "HOME": str(home), "TMPDIR": str(private_tmp),
            "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
            "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8",
            "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_TERMINAL_PROMPT": "0",
            "GIT_AUTHOR_NAME": "F35 Fixture", "GIT_AUTHOR_EMAIL": "f35@example.invalid",
            "GIT_COMMITTER_NAME": "F35 Fixture", "GIT_COMMITTER_EMAIL": "f35@example.invalid",
            "BROWSER": "/usr/bin/false"}


def tool(name, path, **arguments):
    require(path.is_absolute(), "model tool path is absolute")
    return {"functionCall": {"name": name, "args": {"Path": str(path), **arguments}},
            "thoughtSignature": "RjM1LVNDUklQVEVELVRPT0w="}


class ScriptedModel(BaseHTTPRequestHandler):
    """No relay and no outbound requests."""
    def log_message(self, *_):
        pass

    def do_CONNECT(self):
        self.server.blocked.append({"method": self.command, "destination": self.path})
        self.send_error(403, "The fixture never forwards requests.")

    def do_GET(self):
        self.server.blocked.append({"method": self.command, "destination": urlsplit(self.path).hostname})
        self.send_error(403, "The fixture only receives its deterministic model requests.")

    def do_POST(self):
        route = urlsplit(self.path)
        model = route.path[len(PROBE_PATH):].split(":")[0]
        if (route.scheme or not route.path.startswith(PROBE_PATH) or model not in MODELS
                or route.path != f"{PROBE_PATH}{model}:streamGenerateContent"):
            self.server.blocked.append({"method": self.command, "destination": route.hostname or route.path})
            self.send_error(403, "The fixture only receives its deterministic model requests.")
            return
        try:
            size = int(self.headers["Content-Length"])
            require(0 < size <= 1_000_000, "bounded body")
            request = json.loads(self.rfile.read(size))
            row, response = self.script(model, request)
            self.server.evidence.append(row)
            data = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [response]},
                                    "finishReason": "STOP"}], "modelVersion": model,
                    "usageMetadata": {"promptTokenCount": 12, "candidatesTokenCount": 5, "totalTokenCount": 17}}
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            self.wfile.write(b"data: " + json.dumps(data).encode() + b"\n\n")
        except (AssertionError, ValueError, KeyError, IndexError) as error:
            self.server.failures.append(str(error))
            self.send_error(400, str(error))
        except (BrokenPipeError, ConnectionResetError):
            pass

    def script(self, model, request):
        contents = request["contents"]
        parts = [part for item in contents for part in item.get("parts", [])]
        all_text = [part["text"] for part in parts if "text" in part]
        case = next((hit.group() for part in reversed(all_text) for hit in [MARKER.search(part)] if hit), None)
        require(case in self.server.plans, "unknown fixture turn", case)
        plan = self.server.plans[case]
        require(model == plan["model"], "unexpected actual model", (model, plan["model"]))
        declarations = {entry["name"]: sorted((entry.get("parameters") or {}).get("properties") or {})
                        for group in request.get("tools", []) for entry in group.get("functionDeclarations", [])
                        if entry["name"] in HASHED}
        require(set(declarations) == HASHED, "native tool inventory", declarations)
        last = contents[-1].get("parts", [])
        result = next((part["functionResponse"] for part in last if "functionResponse" in part), None)
        steps = plan["steps"]
        step = len(plan["requests"])
        require(step < len(steps), "unexpected extra model request", (case, step))
        expected_report, response = steps[step]
        serialized = json.dumps(result or {}, ensure_ascii=False)
        if expected_report:
            native_name, marker = expected_report
            require(result and result.get("name") == native_name and marker in serialized,
                    "unexpected native tool result", (expected_report, result))
        else:
            require(not result, "unexpected current tool result", result)
        marker = plan.get("history")
        if marker:
            require(any(marker in part for part in all_text[:-1]), "history marker absent from cold resume", marker)
        row = {"case": case, "step": step, "model": model, "nativeToolSchemas": declarations,
               "actualThinkingConfig": (request.get("generationConfig") or {}).get("thinkingConfig"),
               "nativeResult": result, "historyMarkerInRequest": marker if marker else None,
               "respondedWith": response}
        plan["requests"].append(row)
        return row, response


class Host:
    def __init__(self, root, cleanup):
        self.cleanup = cleanup
        self.log = (root / "host-stderr.txt").open("ab")
        home = root / "host-home"
        self.process = subprocess.Popen(
            [str(ELECTRON), str(SOURCES / "host-fixture.mjs"), str(root / "agent.sqlite"), str(home)],
            cwd=root, env={**clean_env(home), "ELECTRON_RUN_AS_NODE": "1", "F35_REPO": str(REPO)},
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log, text=True,
        )

    def call(self, method, allow_error=False, **params):
        self.process.stdin.write(json.dumps({"method": method, "params": params}) + "\n")
        self.process.stdin.flush()
        ready = __import__("select").select([self.process.stdout], [], [], 12)[0]
        require(ready, "host command timed out", method)
        line = self.process.stdout.readline()
        require(line, "host exited early", method)
        response = json.loads(line)
        if allow_error:
            return response
        require("error" not in response, f"production {method}", response)
        return response.get("result")

    def close(self):
        if self.process.stdin.closed:
            return
        self.process.stdin.close()
        try:
            self.process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        self.process.stdout.close()
        self.log.close()
        self.cleanup.append({"kind": "hostNodeNoGui", "pid": self.process.pid, "exitCode": self.process.returncode})


@contextmanager
def native(home, cwd, endpoint, model, effort, result, closed, session=None):
    env = {**clean_env(home), "GEMINI_API_KEY": "F35-DIRECTORY-PLACEHOLDER",
           "GOOGLE_GEMINI_BASE_URL": endpoint, "NO_PROXY": "127.0.0.1", "no_proxy": "127.0.0.1"}
    for key in ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY", "https_proxy", "http_proxy", "all_proxy"):
        env[key] = endpoint
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    wire = RpcProcess(args, cwd, env)
    pid = wire.proc.pid
    result.update(nativePid=pid, requestedCwd=str(cwd), nativeProfileRoot=str(home),
                  openedBy="session/resume" if session else "session/new")
    try:
        info = rpc(wire, "initialize", protocolVersion=1, clientCapabilities={})
        result["agentInfo"] = info.get("agentInfo")
        require(info["protocolVersion"] == 1, "ACP version", info)
        rpc(wire, "authenticate", methodId="gemini-api-key")
        opened = rpc(wire, result["openedBy"], cwd=str(cwd), mcpServers=[],
                     **({"sessionId": session} if session else {}))
        session_id = opened.get("sessionId") or session
        result["nativeSessionId"] = session_id
        result["resumeResponseKeys"] = sorted(opened) if session else None
        require(session_id, "no native session identifier")
        for key, value in (("model", model), ("thought_level", effort)):
            options = wire.call("session/set_config_option", {"sessionId": session_id, "configId": key, "value": value})
            actual = summarize_config(options, key)["currentValue"]
            require(actual == value, f"CLI acknowledged {key}", options)
            result[key] = actual
        pwd = subprocess.run(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"],
                             capture_output=True, text=True, env=clean_env(home), timeout=5)
        observed = next((line[1:] for line in pwd.stdout.splitlines() if line.startswith("n")), "")
        result["processCwd"] = observed
        require(observed and Path(observed).resolve() == cwd.resolve(), "OS process cwd", pwd.stdout)
        yield wire, session_id
    finally:
        wire.close()
        result["nativeExitCode"] = wire.proc.returncode
        closed.append({"kind": "agy", "pid": pid, "exitCode": wire.proc.returncode})


def rpc(wire, method, **params):
    reply = wire.call(method, params, timeout=8)
    require("result" in reply, f"ACP {method}", reply)
    return reply["result"]


def prompt(wire, session_id, message, allow=None, cancel=None):
    before = len(wire.notifications)
    permissions = []
    def answer(request):
        params = request.get("params") or {}
        call = params.get("toolCall") or {}
        target = (call.get("rawInput") or {}).get("Path")
        record = {"request": request, "receivedAt": utc()}
        permissions.append(record)
        if request["method"] != "session/request_permission" or params.get("sessionId") != session_id:
            return {"error": {"code": -32601, "message": "Unexpected callback"}}
        if call.get("name") != "write_file" or target not in {str(allow), str(cancel)}:
            return {"result": {"outcome": {"outcome": "cancelled"}}}
        option = next((item for item in params["options"] if item.get("kind") == "allow_once"), None)
        require(option, "there is a genuine allow_once option", params)
        record["allowOption"] = option["optionId"]
        if cancel is not None:
            wire.write({"method": "session/cancel", "params": {"sessionId": session_id}})
            record["decision"] = "cancel_notification_without_answer"
            return None
        record["decision"] = "allow_once"
        return {"result": {"outcome": {"outcome": "selected", "optionId": option["optionId"]}}}
    wire.answer_request = answer
    reply = wire.call("session/prompt", {"sessionId": session_id, "prompt": [{"type": "text", "text": message}]}, timeout=12)
    updates = [event["params"]["update"] for event in wire.notifications[before:] if event.get("method") == "session/update"]
    assistant = "".join(update.get("content", {}).get("text", "") for update in updates
                        if update.get("sessionUpdate") == "agent_message_chunk")
    tool_updates = [update for update in updates if update.get("sessionUpdate") in ("tool_call", "tool_call_update")]
    return {"terminalAt": utc(), "reply": reply, "text": assistant, "permissionRequests": permissions,
            "toolUpdates": tool_updates}


def good_turn(turn, marker):
    require(turn["reply"].get("result", {}).get("stopReason") == LIVE, "native completed", turn)
    require(turn["text"] == marker, "native assistant marker", turn)


def plan(server, name, *steps, model=MODELS[0], history=None):
    key = f"F35_CASE_{name.upper()}"
    server.plans[key] = {"steps": steps, "model": model, "history": history, "requests": []}
    return key


def command(env, cwd, name, *args):
    return subprocess.check_output([name, *args], cwd=cwd, env=env, text=True, stderr=subprocess.STDOUT, timeout=15).rstrip("\n")


def initialize(kind, root, env):
    checkout = root / f"{kind}-checkout"
    source = root / f"{kind}-source"
    cwd = checkout / "sub"
    if kind == "svn":
        command(env, root, "svnadmin", "create", str(source))
        command(env, root, "svn", "checkout", source.as_uri(), str(checkout), "--non-interactive", "--no-auth-cache")
    cwd.mkdir(parents=True, exist_ok=True)
    (cwd / "committed.txt").write_text("FIXTURE-BASE\n")
    if kind == "git" or kind == "worktree":
        command(env, checkout, "git", "init", "-q", "-b", "main")
        command(env, checkout, "git", "add", "sub/committed.txt")
        command(env, checkout, "git", "commit", "-qm", "Synthetic base")
    if kind == "svn":
        command(env, checkout, "svn", "add", "sub")
        command(env, checkout, "svn", "commit", "-qm", "Synthetic base")
        command(env, checkout, "svn", "update", "-q")
    return checkout, cwd


def queue_enter(host, task, identity):
    return host.call("enter", taskId=task, identity=identity)["queue_id"]


def shared(kind, root, env, server, endpoint, host, closed, outcome):
    start = monotonic()
    checkout, cwd = initialize(kind, root, env)
    alias = root / f"{kind}-alias"
    alias.symlink_to(cwd, target_is_directory=True)
    base = command(env, checkout, "git", "rev-parse", "HEAD") if kind == "git" else None
    path = cwd / "shared.txt"
    parent_text, child_text = f"{kind.upper()}-PARENT\n", f"{kind.upper()}-CHILD\n"
    homes = [root / f"{kind}-parent-profile", root / f"{kind}-child-profile"]
    writer_a = plan(server, kind + "_parent", (None, tool("write_file", path, Content=parent_text)),
                    (("write_file", "Created file."), {"text": "PARENT-WROTE"}))
    writer_b = plan(server, kind + "_child", (None, tool("read_file", path)),
                    (("read_file", parent_text.strip()), tool("write_file", path, Content=child_text, Append=True)),
                    (("write_file", "output"), {"text": "CHILD-WROTE"}), model=MODELS[1])
    reread = plan(server, kind + "_reread", (None, tool("read_file", path)),
                  (("read_file", child_text.strip()), {"text": "PARENT-READ-CHILD"}), history="PARENT-WROTE")
    parent = host.call("add", cwd=str(cwd), title=kind + " parent")
    child = host.call("add", cwd=str(alias), title=kind + " child", parentTaskId=parent)
    a = host.call("identity", cwd=str(cwd), roots=[str(checkout), str(cwd)])
    b = host.call("identity", cwd=str(alias), roots=[str(checkout), str(alias)])
    require(a == b, "aliases share production physical identity", (a, b))
    p_q = queue_enter(host, parent, a["identity"])
    require(host.call("acquire", id=p_q), "parent acquires directory")
    c_q = queue_enter(host, child, b["identity"])
    require(host.call("acquire", id=c_q) is False, "child waits before parent releases")
    require(host.call("get", id=c_q)["state"] == "queued", "child persisted as queued")
    outcome.update(kind=kind, cwd=str(cwd), alias=str(alias), canonicalIdentity=a, aliasIdentity=b, parentTask=parent,
                   childTask=child, childQueueBeforeParentDrain=host.call("get", id=c_q),
                   nativeParent={}, nativeChild={}, nativeParentResumed={}, baseHead=base)
    with native(homes[0], cwd, endpoint, MODELS[0], "medium", outcome["nativeParent"], closed) as (wire, session):
        parent_turn = prompt(wire, session, writer_a, allow=path)
        outcome["nativeParentTurn"] = parent_turn
        good_turn(parent_turn, "PARENT-WROTE")
        require(path.read_text() == parent_text, "parent wrote real uncommitted marker")
        blocked = host.call("release", allow_error=True, id=p_q, proof={**DRAINED, "nativeExited": False})
        require("保留目录占用" in blocked.get("error", ""), "production queue refused incomplete drain", blocked)
        require(host.call("acquire", id=c_q) is False, "child cannot start before real parent exit")
        require(wire.proc.poll() is None, "parent still live at incomplete drain assertion")
        outcome["incompleteDrain"] = {"reason": blocked["error"], "childAcquire": False, "parentWasAlive": True}
    require(outcome["nativeParent"]["nativeExitCode"] == 0, "parent exit observed")
    require(host.call("release", id=p_q, proof=DRAINED), "parent releases after native exit")
    require(host.call("acquire", id=c_q), "child acquires after parent exit")
    p_return = queue_enter(host, parent, a["identity"])
    require(host.call("acquire", id=p_return) is False, "parent waits while child owns directory")
    with native(homes[1], alias, endpoint, MODELS[1], "high", outcome["nativeChild"], closed) as (wire, child_id):
        child_turn = prompt(wire, child_id, writer_b, allow=path)
        outcome["nativeChildTurn"] = child_turn
        good_turn(child_turn, "CHILD-WROTE")
        require(path.read_text() == parent_text + child_text, "child appended parent's real bytes exactly once", path.read_text())
        require(host.call("acquire", id=p_return) is False, "no premature reacquire while child alive")
    require(outcome["nativeChild"]["nativeExitCode"] == 0, "child exit observed")
    require(host.call("release", id=c_q, proof=DRAINED), "child releases after native exit")
    require(host.call("acquire", id=p_return), "parent reacquires after child's actual exit")
    with native(homes[0], cwd, endpoint, MODELS[0], "medium", outcome["nativeParentResumed"], closed, session) as (wire, resumed):
        resumed_turn = prompt(wire, resumed, reread)
        outcome["nativeParentResumedTurn"] = resumed_turn
        good_turn(resumed_turn, "PARENT-READ-CHILD")
    require(session == resumed, "original native identity restored")
    require(host.call("release", id=p_return, proof=DRAINED), "reopened parent releases")
    outcome.update(readback=path.read_text(), originalNativeSessionResumed=session == resumed,
                   queueAfter=[host.call("get", id=x) for x in (p_q, c_q, p_return)])
    if base:
        outcome["gitHeadAfter"] = command(env, checkout, "git", "rev-parse", "HEAD")
        outcome["gitStatusAfter"] = command(env, checkout, "git", "status", "--porcelain=v1", "-uall")
        require(outcome["gitHeadAfter"] == base and "?? sub/shared.txt" in outcome["gitStatusAfter"],
                "Git checkout remains dirty at original HEAD")
    elif kind == "svn":
        outcome["svnStatusAfter"] = command(env, checkout, "svn", "status", "--non-interactive")
        require("?       " in outcome["svnStatusAfter"] and outcome["svnStatusAfter"].endswith("sub/shared.txt"), "SVN remains uncommitted")
    outcome["status"] = "passed"
    outcome["elapsedMs"] = round((monotonic() - start) * 1000)


def worktree(root, env, server, endpoint, host, closed, outcome):
    checkout, cwd = initialize("worktree", root, env)
    path_dirty, path_parent = cwd / "private-parent.txt", cwd / "parent-concurrent.txt"
    path_dirty.write_text("DIRTY-PARENT-ONLY\n")
    parent = host.call("add", cwd=str(cwd), title="worktree parent")
    child = host.call("add", cwd=str(cwd), title="worktree child", parentTaskId=parent)
    title = "F35 native writer"
    created = host.call("makeWorktree", cwd=str(cwd), parentTaskId=parent, childTaskId=child, title=title)
    work = created["created"]["workspace"]
    child_cwd = Path(created["created"]["cwd"])
    separate = child_cwd / "child.txt"
    branch = work["branch"]
    base = created["source"]["baseCommit"]
    require(child_cwd == Path(work["path"]) / "sub", "actual GitWorkspaces mapped source subdirectory")
    require(not (child_cwd / path_dirty.name).exists(), "uncommitted parent marker absent in worktree")
    require(command(env, child_cwd, "git", "rev-parse", "HEAD") == base, "worktree starts at accepted commit")
    require(created["source"]["uncommittedFiles"] == 1, "source uncommitted count", created)
    parent_live, parent_release = Event(), Event()
    parent_case = plan(server, "WORKTREE_PARENT", (None, tool("write_file", path_parent, Content="PARENT-CONCURRENT\n")),
                       (("write_file", "Created file."), {"text": "PARENT-CONCURRENT-DONE"}))
    child_case = plan(server, "WORKTREE_CHILD", (None, tool("read_file", child_cwd / "committed.txt")),
                      (("read_file", "FIXTURE-BASE"), tool("write_file", separate, Content="WORKTREE-CHILD\n")),
                      (("write_file", "Created file."), {"text": "WORKTREE-CHILD-DONE"}), model=MODELS[1])
    outcome.update(nativeParent={}, nativeChild={}, hostCreation=created, baseHead=base, worktreePath=str(child_cwd))
    # Hold parent approval while the independent child subdirectory reaches its real write.
    def run_parent():
        with native(root / "worktree-parent-profile", cwd, endpoint, MODELS[0], "medium", outcome["nativeParent"], closed) as (wire, session):
            original = wire.write
            def gate_write(message):
                if message.get("result", {}).get("outcome", {}).get("outcome") == "selected":
                    parent_live.set()
                    require(parent_release.wait(10), "bounded concurrent parent approval hold")
                original(message)
            wire.write = gate_write
            turn = prompt(wire, session, parent_case, allow=path_parent)
            outcome["nativeParentTurn"] = turn
            good_turn(turn, "PARENT-CONCURRENT-DONE")
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(run_parent)
        try:
            require(parent_live.wait(8), "parent waiting on real file approval in separate process")
            require(not path_parent.exists(), "parent's held file has not appeared")
            with native(root / "worktree-child-profile", child_cwd, endpoint, MODELS[1], "high", outcome["nativeChild"], closed) as (wire, session):
                turn = prompt(wire, session, child_case, allow=separate)
                outcome["nativeChildTurn"] = turn
                good_turn(turn, "WORKTREE-CHILD-DONE")
                require(separate.read_text() == "WORKTREE-CHILD\n", "native child wrote only inside worktree")
                require(not path_parent.exists() and not future.done(), "two independent active agy processes overlapped")
                outcome["childWroteWhileParentApprovalWasPending"] = True
                parent_release.set()
            future.result(timeout=10)
        finally:
            parent_release.set()
    require(path_parent.read_text() == "PARENT-CONCURRENT\n", "parent actual write after release")
    require(not (child_cwd / path_parent.name).exists() and not (cwd / separate.name).exists(), "writes isolated in both directions")
    finalized = host.call("finalizeWorktree", parentTaskId=parent, childTaskId=child, title=title, baseCommit=base)
    outcome.update(hostFinalization=finalized, parentWorktreeWriteAbsent=(not (cwd / separate.name).exists()),
                   parentDirtyMarkerAbsentInWorktree=(not (child_cwd / path_dirty.name).exists()),
                   parentHeadAfter=command(env, checkout, "git", "rev-parse", "HEAD"),
                   parentStatusAfter=command(env, checkout, "git", "status", "--porcelain=v1", "-uall"),
                   childCommitReadback=command(env, child_cwd, "git", "show", "HEAD:sub/child.txt"),
                   childCommitParent=command(env, child_cwd, "git", "rev-parse", "HEAD^"),
                   childBranchAfter=command(env, child_cwd, "git", "rev-parse", "--abbrev-ref", "HEAD"))
    require(outcome["parentHeadAfter"] == base, "parent HEAD unchanged")
    require(set(outcome["parentStatusAfter"].splitlines()) == {"?? sub/parent-concurrent.txt", "?? sub/private-parent.txt"},
            "only original parent work remains local", outcome["parentStatusAfter"])
    require(outcome["childCommitParent"] == base and outcome["childBranchAfter"] == branch,
            "host-created commit has correct base and branch", outcome)
    require(outcome["childCommitReadback"] == "WORKTREE-CHILD", "Git object equals native output")
    require(finalized["range"] == finalized["durableRange"] and finalized["range"]["files"] == ["sub/child.txt"]
            and len(finalized["range"]["commits"]) == 1 and finalized["provenance"]["kind"] == "child_result",
            "real host finalize wrote one child commit and persisted provenance", finalized)
    host.call("removeWorktree", workspaceId=work["workspace_id"])
    outcome["registeredWorktreeRemoved"] = not Path(work["path"]).exists()
    require(outcome["registeredWorktreeRemoved"], "registered Git worktree removed normally")
    outcome["status"] = "passed"


def recovery(root, server, endpoint, host, closed, outcome):
    cwd = root / "recovery-checkout"
    cwd.mkdir()
    stale = cwd / "must-never-appear.txt"
    next_file = cwd / "resumed-fresh.txt"
    home = root / "recovery-profile"
    identity = host.call("identity", cwd=str(cwd), roots=[str(cwd)])["identity"]
    task = host.call("add", cwd=str(cwd), title="recoverable native child")
    queued = host.call("add", cwd=str(cwd), title="canceled without starting")
    slot = queue_enter(host, task, identity)
    deferred = queue_enter(host, queued, identity)
    require(host.call("acquire", id=slot), "running recovery fixture holds directory")
    require(host.call("acquire", id=deferred) is False, "second task stays queued")
    host.call("cancel", taskId=queued)
    require(host.call("get", id=deferred)["state"] == "canceled", "queued item persisted canceled")
    remember = plan(server, "RECOVERY_REMEMBER", (None, {"text": "F35-RECOVERY-ORIGINAL"}), model=MODELS[1])
    waiting = plan(server, "RECOVERY_PENDING", (None, tool("write_file", stale, Content="STALE-WRITE\n")), model=MODELS[1])
    after_cancel = plan(server, "RECOVERY_AFTER_CANCEL", (None, {"text": "AFTER-CANCEL-CLEAN"}), model=MODELS[1])
    next_turn = plan(server, "RECOVERY_REOPEN", (None, tool("write_file", next_file, Content="FRESH-WRITE\n")),
                     (("write_file", "Created file."), {"text": "RECOVERY-FRESH-DONE"}), model=MODELS[1],
                     history="F35-RECOVERY-ORIGINAL")
    outcome.update(cwd=str(cwd), nativeBefore={}, nativeAfter={}, canceledQueueId=deferred, canceledTaskId=queued,
                   recoverableTaskId=task)
    with native(home, cwd, endpoint, MODELS[1], "high", outcome["nativeBefore"], closed) as (wire, session):
        remembered = prompt(wire, session, remember)
        outcome["rememberedTurn"] = remembered
        good_turn(remembered, "F35-RECOVERY-ORIGINAL")
        binding = host.call("saveBinding", taskId=task, cwd=str(cwd), home=str(home), nativeSession=session)
        outcome["savedBinding"] = binding
        canceled = prompt(wire, session, waiting, cancel=stale)
        outcome["canceledWhileAwaitingNativeApproval"] = canceled
        require(canceled["reply"].get("result", {}).get("stopReason") == "cancelled", "real ACP cancel terminal", canceled)
        require(len(canceled["permissionRequests"]) == 1 and not stale.exists(), "real native pending approval wrote nothing")
        old = canceled["permissionRequests"][0]
        wire.write({"id": old["request"]["id"], "result": {"outcome": {"outcome": "selected", "optionId": old["allowOption"]}}})
        outcome["lateNativeAllowSentAt"] = utc()
        turn = prompt(wire, session, after_cancel)
        outcome["sameProcessTurnAfterOldAllow"] = turn
        good_turn(turn, "AFTER-CANCEL-CLEAN")
        require(not stale.exists(), "late native approval produced no write")
    require(outcome["nativeBefore"]["nativeExitCode"] == 0, "observed recovery prior native exit")
    require(host.call("release", id=slot, proof=DRAINED), "recovery prior slot released")
    outcome["hostBeforeRestart"] = host.call("hello")
    host.close()
    with reopened_host(root, closed) as opened:
        outcome["hostAfterRestart"] = opened.call("hello")
        require(outcome["hostAfterRestart"]["migrated"] == [], "same durable database reopened")
        outcome["canceledQueueAfterRestart"] = opened.call("get", id=deferred)
        require(outcome["canceledQueueAfterRestart"]["state"] == "canceled"
                and opened.call("acquire", id=deferred) is False, "canceled queue cannot be replayed after restart")
        saved = opened.call("readBinding", taskId=task, continuationHash=binding["continuationHash"])
        outcome["readBindingAfterRestart"] = saved
        require(saved["binding_id"] == binding["bindingId"] and saved["native_id"] == session
                and saved["cwd_identity"] == str(cwd) and saved["state_root"] == str(home),
                "actual host store preserves native identity and directory", saved)
        fresh_slot = queue_enter(opened, task, identity)
        require(opened.call("acquire", id=fresh_slot), "legal original task reacquires")
        with native(home, cwd, endpoint, MODELS[1], "high", outcome["nativeAfter"], closed, saved["native_id"]) as (wire, resumed):
            turn = prompt(wire, resumed, next_turn, allow=next_file)
            outcome["freshApprovedTurnAfterResume"] = turn
            good_turn(turn, "RECOVERY-FRESH-DONE")
            require(resumed == session and next_file.read_text() == "FRESH-WRITE\n" and not stale.exists(),
                    "same session and restored directory writes fresh bytes only")
        require(opened.call("release", id=fresh_slot, proof=DRAINED), "resumed task exits before release")
        outcome["finalDirectoryStates"] = opened.call("queueStates")
    outcome["staleWriteRemainedAbsent"] = not stale.exists()
    outcome["freshNativeWrite"] = next_file.read_text()
    outcome["status"] = "passed"


@contextmanager
def reopened_host(root, closed):
    host = Host(root, closed)
    try:
        yield host
    finally:
        host.close()


def main(output):
    output.mkdir(mode=0o700, exist_ok=False)
    root = Path(mkdtemp(prefix="runtime-", dir=output)).resolve()
    model_server, model_thread = None, None
    closed = []
    result = {"timeUtc": utc(), "platform": platform.platform(), "sourceCommit": BASELINE,
              "testMode": "real agy native filesystem tools with local deterministic Gemini and frozen WillYou host components",
              "credential": "synthetic placeholder", "network": "loopback fixture, proxy no forwarding",
              "cases": {},
              "remaining": [
                  "WillYou production baseline has no Antigravity Driver registration. DirectoryQueue, AgentStore and GitWorkspaces were exercised directly with a private harness and the legacy-schema identity as a fixture.",
                  "A23 native disk and queue integration covers Git, SVN and ordinary directories; full app delegation events, directory hold and UI still require production integration.",
                  "A24 host creates and finalizes the worktree and native files were verified. A fixture seeded the delegation-attempt foreign keys. Full app delegation acceptance and relationship card remain open.",
                  "A25 this is a controlled ACP cancel and local host database close/reopen, not a packaged app crash or task-tree result delivery. Result receipt exactly-once, actual app restart and UI remain open.",
              ]}
    status = 1
    try:
        env = clean_env(root / "git-home")
        result["cliVersion"] = command(env, root, str(AGY), "--version")
        result["cliSha256"] = digest(AGY)
        model_server = ThreadingHTTPServer(("127.0.0.1", 0), ScriptedModel)
        model_server.plans, model_server.evidence, model_server.blocked, model_server.failures = {}, [], [], []
        model_thread = Thread(target=model_server.serve_forever, daemon=True)
        model_thread.start()
        endpoint = f"http://127.0.0.1:{model_server.server_port}"
        with reopened_host(root, closed) as host:
            result["hostReady"] = host.call("hello")
            for kind in ("git", "svn", "ordinary"):
                outcomes = result["cases"].setdefault("F35-A23", {})
                scenario = outcomes.setdefault(kind, {})
                shared(kind, root, env, model_server, endpoint, host, closed, scenario)
            worktree(root, env, model_server, endpoint, host, closed, result["cases"].setdefault("F35-A24", {}))
            recovery(root, model_server, endpoint, host, closed, result["cases"].setdefault("F35-A25", {}))
        require(not model_server.failures, "loopback fixture handled the expected requests", model_server.failures)
        require(all(len(p["requests"]) == len(p["steps"]) for p in model_server.plans.values()), "every scripted native phase requested")
        result["status"] = "passed technical experiment"
        status = 0
    except Exception:
        result["status"] = "failed technical experiment"
        result["failure"] = traceback.format_exc()
        print(result["failure"], file=sys.stderr)
    finally:
        listener = None
        if model_server:
            port = model_server.server_port
            result["modelRequests"] = model_server.evidence
            result["blockedProxyAttempts"] = model_server.blocked
            result["localFixtureFailures"] = model_server.failures
            model_server.shutdown()
            model_server.server_close()
            if model_thread:
                model_thread.join(timeout=3)
            with socket.socket() as client:
                listener = {"address": f"127.0.0.1:{port}",
                            "closed": client.connect_ex(("127.0.0.1", port)) != 0,
                            "workerStopped": not model_thread.is_alive() if model_thread else True}
        cleanup = {"timeUtc": utc(), "privateRuntime": str(root), "modelListener": listener,
                   "observedChildExits": closed, "rootRemoved": False}
        host_log = root / "host-stderr.txt"
        if host_log.exists() and host_log.stat().st_size:
            shutil.copyfile(host_log, output / "host-stderr.txt")
        shutil.rmtree(root)
        cleanup["rootRemoved"] = not root.exists()
        result["finishedAtUtc"] = utc()
        (output / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        (output / "cleanup.json").write_text(json.dumps(cleanup, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"status": result["status"], "result": str(output / "result.json"),
                          "cleaned": cleanup["rootRemoved"], "childExits": len(closed)}, ensure_ascii=False), flush=True)
    return status


if __name__ == "__main__":
    raise SystemExit(main(Path(sys.argv[1]).resolve()))
