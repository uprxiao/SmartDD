import { randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createInterface } from 'node:readline';
import { createRequire } from 'node:module';
import { AgentStore, sha256 } from '@f35-baseline/src/main/core/agent/agent-store';
import { DirectoryQueue, directoryIdentity } from '@f35-baseline/src/main/core/agent/directory-queue';
import { GitWorkspaces } from '@f35-baseline/src/main/core/agent/git-workspaces';
import { runBundledMigrations } from '@f35-baseline/src/main/db/migrations';

const requireDependency = createRequire(join(process.env.F35_REPO!, 'package.json'));
const Database = requireDependency('better-sqlite3');
const [databaseFile, home] = process.argv.slice(2);
const database = new Database(databaseFile);
database.pragma('foreign_keys=ON');
const migrated = runBundledMigrations(database);
const store = new AgentStore(database);
const queue = new DirectoryQueue(store);
const git = new GitWorkspaces({ store, home });

// Older production storage knows only two driver IDs. The probe never launches Codex.
const legacyDriverId = 'codex-app-server';
const addTask = (cwd: string, title: string, parentTaskId?: string) =>
  store.createTask({ projectId: null, dirId: null, cwd, title, parentTaskId,
    selection: { driverId: legacyDriverId, profileId: 'f35-native-storage-fixture', tier: 'ask' } });

const methods = {
  hello: () => ({ pid: process.pid, migrated, sqliteVersion: database.prepare('select sqlite_version() as ver').get().ver }),
  add: ({cwd, title, parentTaskId}: any) => addTask(cwd, title, parentTaskId),
  identity: ({cwd, roots}: any) => directoryIdentity(cwd, roots),
  detect: ({cwd}: any) => git.detect(cwd),
  enter: ({taskId, identity}: any) => queue.enter(taskId, identity),
  get: ({id}: any) => queue.get(id),
  acquire: ({id}: any) => queue.acquire(id),
  cancel: ({taskId}: any) => queue.cancel(taskId),
  release: ({id, proof}: any) => queue.release(id, proof),
  queueStates: () => database.prepare('SELECT queue_id, task_id, kind, state, directory_identity, accepted_order FROM agent_directory_queue ORDER BY accepted_order').all(),
  makeWorktree: async ({cwd, parentTaskId, childTaskId, title}: any) => {
    const detected = await git.detect(cwd);
    if (!detected) throw Error('Expected a Git checkout');
    const source = await git.sourceSnapshot(detected);
    const created = await git.create({ cwd, parentTaskId, childTaskId, title,
      projectName: 'F35 Directory', projectId: 'disposable-f35', expectedBranch: detected.branch,
      expectedRoot: detected.root, baseCommit: source.baseCommit });
    return { detected, source, created };
  },
  finalizeWorktree: async ({parentTaskId, childTaskId, title, baseCommit}: any) => {
    const delegation = randomUUID();
    const attempt = randomUUID();
    const now = new Date().toISOString();
    // Seed only the foreign-key rows required by production GitWorkspaces.finalize.
    store.tx(() => {
      database.prepare("INSERT INTO agent_delegations(delegation_id,parent_task_id,child_task_id,target_json,access,request_key,delivery_state,created_at,updated_at) VALUES(?,?,?,'{}','write',?,'running',?,?)")
        .run(delegation, parentTaskId, childTaskId, delegation, now, now);
      database.prepare("INSERT INTO agent_delegation_attempts(attempt_id,delegation_id,ordinal,kind,input_ref) VALUES(?,?,1,'initial','{}')")
        .run(attempt, delegation);
    });
    const range = await git.finalize(childTaskId, attempt, title, baseCommit);
    return { range, attempt,
      provenance: database.prepare('SELECT commit_sha,workspace_id,attempt_id,intent_id,kind FROM agent_commit_provenance WHERE attempt_id=?').get(attempt),
      intent: database.prepare("SELECT action,state,head_before,expected_parent FROM agent_intents WHERE target_ref=(SELECT path FROM agent_workspaces WHERE child_task_id=?) AND action='child_result_commit'").get(childTaskId),
      durableRange: JSON.parse(database.prepare('SELECT commit_range FROM agent_delegation_attempts WHERE attempt_id=?').get(attempt).commit_range),
    };
  },
  removeWorktree: ({workspaceId}: any) => git.removeRegistered(workspaceId),
  saveBinding: ({taskId, cwd, home: stateRoot, nativeSession}: any) => {
    const continuationHash = sha256(JSON.stringify({ driver: legacyDriverId, profile: 'f35-native-storage-fixture', stateRoot, cwd, compatibility: { probe: 'agy' } }));
    const bindingId = store.createBinding({task_id: taskId, driver_id: legacyDriverId,
      profile_id: 'f35-native-storage-fixture', continuation_hash: continuationHash,
      state_root: stateRoot, cwd_identity: cwd});
    store.freezeBinding(bindingId, { compatibility: { probe: 'agy' }, stateRoot, cwd });
    store.confirmNative(bindingId, nativeSession);
    return { bindingId, continuationHash };
  },
  readBinding: ({taskId, continuationHash}: any) => store.findBinding(taskId, legacyDriverId, continuationHash),
};
try {
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  for await (const line of input) {
    const { method, params } = JSON.parse(line);
    try {
      if (!Object.hasOwn(methods, method)) throw Error('Fixture method not allowed');
      const result = await methods[method as keyof typeof methods](params);
      console.log(JSON.stringify({ result: result ?? null }));
    } catch (error) {
      console.log(JSON.stringify({ error: (error as Error).message }));
    }
  }
} finally {
  database.close();
}
