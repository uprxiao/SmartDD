import json
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import sys
import time

from acp_probe import AGY, ROOT


class RpcProcess:
    def __init__(self, args, cwd, env):
        self.proc = subprocess.Popen(
            [str(AGY), *args], cwd=cwd, env=env, stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, start_new_session=True,
        )
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.proc.stdout, selectors.EVENT_READ)
        self.buffer = b""
        self.notifications = []
        self.slots = []
        self.answer_request = lambda _message: {'result': {'outcome': {'outcome': 'cancelled'}}}

    def write(self, message):
        self.proc.stdin.write(json.dumps({"jsonrpc": "2.0", **message}).encode() + b"\n")
        self.proc.stdin.flush()

    def call(self, method, params, timeout=6):
        request_id = len(self.slots) + 1
        self.slots.append(method)
        self.write({"id": request_id, "method": method, "params": params})
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            while b"\n" in self.buffer:
                line, self.buffer = self.buffer.split(b"\n", 1)
                try:
                    message = json.loads(line)
                except (ValueError, UnicodeDecodeError):
                    continue
                if not isinstance(message, dict):
                    continue
                if "method" not in message and message.get("id") == request_id:
                    return message
                if "method" in message and "id" in message:
                    answer = self.answer_request(message)
                    if answer is not None:
                        self.write({"id": message["id"], **answer})
                if "method" in message and "id" not in message:
                    self.notifications.append(message)
            ready = self.selector.select(max(0, deadline - time.monotonic()))
            if ready:
                chunk = os.read(ready[0][0].fd, 65536)
                if not chunk:
                    return {"outcome": "stdout_closed"}
                self.buffer += chunk
        return {"outcome": "timeout"}

    def close(self):
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(self.proc.pid, signal.SIGTERM)
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(self.proc.pid, signal.SIGKILL)
                self.proc.wait(timeout=3)
        self.selector.close()
        self.proc.stdout.close()


HOSTS = ("generativelanguage.googleapis.com", "daily-cloudcode-pa.googleapis.com",
         "cloudcode-pa.googleapis.com", "127.0.0.1:1/f35-ccpa", "127.0.0.1:1/f35-gemini")
MODELS = ("gemini-4-carbon", "gemini-4-argon")


def shape(response):
    error = response.get("error") or {}
    outcome = response.get("outcome") or ("error" if error else "ok")
    serialized = json.dumps(response).lower()
    return {
        "outcome": outcome,
        "code": error.get("code"),
        "description": re.sub(r"(?:F35-DUMMY-CREDENTIAL-[A-Z-]+|sk-[A-Za-z0-9_-]+|AIza[A-Za-z0-9_-]+)", "<redacted>", str(error.get("message", "")))[:220],
        "destinationHints": [host for host in HOSTS if host in serialized],
        "errorHints": [flag for flag, patterns in {
            "auth_required": ("auth required", "authentication required", "please sign in", "not authenticated"),
            "missing_api_key": ("api key is required", "gemini_api_key", "invalid api key"),
            "network_failure": ("connection refused", "connect: permission denied", "network is unreachable",
                                "proxyconnect", "network error", "could not resolve"),
            "unadvertised_model_or_value": ("invalid model", "unknown model", "not supported", "invalid value",
                                           "not a valid", "invalid config"),
        }.items() if any(value in serialized for value in patterns)],
    }


def probe(variant):
    state = ROOT / ("state-" + variant)
    cwd = ROOT / ("workspace-" + variant)
    for path in (state, state / "tmp", cwd):
        path.mkdir(exist_ok=True, mode=0o700)
    env = {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
        "HOME": str(state), "TMPDIR": str(state / "tmp"),
        "XDG_CONFIG_HOME": str(state / "config"), "XDG_CACHE_HOME": str(state / "cache"),
        "XDG_DATA_HOME": str(state / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
        "GEMINI_API_KEY": "F35-DUMMY-CREDENTIAL-FOR-OFFLINE-PROBE",
        "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1",
        "NO_PROXY": "127.0.0.1,localhost",
    }
    args = ["acp", "--gemini-dir", str(state / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false"]
    if variant == "ccpa_flag":
        args += ["--cloud_code_endpoint", "http://127.0.0.1:1/f35-ccpa"]
    if variant == "gemini_base_env":
        env["GOOGLE_GEMINI_BASE_URL"] = "http://127.0.0.1:1/f35-gemini"

    wire = RpcProcess(args, cwd, env)
    row = {"case": variant, "fakeCredentialOnly": True}
    try:
        handshake = wire.call("initialize", {"protocolVersion": 1, "clientCapabilities": {}})
        row["initialize"] = shape(handshake)
        options = (handshake.get("result") or {}).get("authMethods") or []
        if not any(method.get("id") == "gemini-api-key" for method in options):
            return row
        auth = wire.call("authenticate", {"methodId": "gemini-api-key"})
        row["authenticate"] = shape(auth)
        if row["authenticate"]["outcome"] != "ok":
            return row
        session = wire.call("session/new", {"cwd": str(cwd), "mcpServers": []})
        row["sessionNew"] = shape(session)
        info = session.get("result") or {}
        session_id = info.get("sessionId")
        models = (info.get("models") or {}).get("availableModels") or []
        model_ids = [entry.get("modelId") for entry in models if isinstance(entry, dict)]
        config = info.get("configOptions") or []
        model_option = next((item for item in config if item.get("id") == "model" or item.get("category") == "model"), {})
        for item in model_option.get("options", []):
            if "value" in item:
                model_ids.append(item["value"])
            else:
                model_ids.extend(option.get("value") for option in item.get("options", []))
        row["catalogModelCount"] = len(set(model_ids))
        row["requestedModelsInCatalog"] = [model for model in MODELS if model in model_ids]
        row["configOptionIds"] = [item.get("id") for item in config if isinstance(item, dict)]
        row["createdSession"] = isinstance(session_id, str) and bool(session_id)
        if not row["createdSession"]:
            return row
        if variant == "default":
            row["setRequestedModel"] = {
                model: shape(wire.call("session/set_config_option", {
                    "sessionId": session_id, "configId": "model", "value": model,
                })) for model in MODELS
            }
        response = wire.call("session/prompt", {
            "sessionId": session_id,
            "prompt": [{"type": "text", "text": "Reply with F35-OFFLINE-PROBE. Do not use tools."}],
        })
        row["prompt"] = shape(response)
        row["prompt"]["stopReason"] = (response.get("result") or {}).get("stopReason")
        logs = json.dumps(wire.notifications).lower()
        row["notificationDestinationHints"] = [host for host in HOSTS if host in logs]
        row["assistantChunks"] = sum(
            item.get("method") == "session/update" and
            (item.get("params") or {}).get("update", {}).get("sessionUpdate") == "agent_message_chunk"
            for item in wire.notifications
        )
        return row
    finally:
        wire.close()


if __name__ == "__main__":
    variants = sys.argv[1:] or ["default", "ccpa_flag", "gemini_base_env"]
    if any(item not in {"default", "ccpa_flag", "gemini_base_env"} for item in variants):
        raise SystemExit("Unknown offline probe case.")
    evidence = [probe(variant) for variant in variants]
    (ROOT / "agy-key-path-evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(json.dumps(evidence, indent=2), flush=True)

