import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parent
AGY = Path(os.environ.get("F35_AGY_BIN") or shutil.which("agy") or Path.home() / ".local/bin/agy").expanduser().absolute()


def read_response(process, request_id, timeout=8):
    deadline = time.monotonic() + timeout
    buffered = b""
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout, selectors.EVENT_READ)
        while time.monotonic() < deadline:
            for key, _ in selector.select(max(0, deadline - time.monotonic())):
                chunk = os.read(key.fd, 65536)
                if not chunk:
                    return {"outcome": "stdout_closed"}
                buffered += chunk
                while b"\n" in buffered:
                    line, buffered = buffered.split(b"\n", 1)
                    try:
                        message = json.loads(line)
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if isinstance(message, dict) and message.get("id") == request_id and "method" not in message:
                        return message
    return {"outcome": "timeout"}


def initialize(version):
    home = ROOT / f"home-acp{version}"
    workspace = ROOT / f"work-acp{version}"
    tmp = home / "tmp"
    for path in (home, workspace, tmp):
        path.mkdir(mode=0o700, exist_ok=True)
    env = {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
        "HOME": str(home),
        "TMPDIR": str(tmp),
        "XDG_CONFIG_HOME": str(home / "config"),
        "XDG_CACHE_HOME": str(home / "cache"),
        "XDG_DATA_HOME": str(home / "data"),
        "LANG": "en_US.UTF-8",
        "BROWSER": "/usr/bin/false",
    }
    started = time.monotonic()
    child = subprocess.Popen(
        [str(AGY), "acp", "--gemini-dir", str(home / ".gemini"),
         "--app-data-dir", "antigravity-acp", "--disable-telemetry=true",
         "--include-default-customizations=false"],
        cwd=workspace, env=env, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL, start_new_session=True,
    )
    try:
        payload = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": version, "clientCapabilities": {
                "fs": {"readTextFile": False, "writeTextFile": False}, "terminal": False,
            }, "clientInfo": {"name": "willyou-f35-isolated-probe", "version": "1.0.0"},
        }}
        child.stdin.write(json.dumps(payload).encode() + b"\n")
        child.stdin.flush()
        reply = read_response(child, 1)
        result = reply.get("result", {})
        caps = result.get("agentCapabilities") or {}
        row = {
            "requestedProtocolVersion": version,
            "elapsedMs": round((time.monotonic() - started) * 1000),
            "outcome": "initialized" if result else reply.get("outcome", "rpc_error"),
            "protocolVersion": result.get("protocolVersion"),
            "agentInfo": {key: result.get("agentInfo", {}).get(key) for key in ("name", "version")},
            "authMethods": [entry.get("id") for entry in result.get("authMethods", [])],
            "loadSession": caps.get("loadSession", False),
            "sessionCapabilities": sorted((caps.get("sessionCapabilities") or {}).keys()),
            "mcpCapabilities": caps.get("mcpCapabilities", {}),
            "promptCapabilities": caps.get("promptCapabilities", {}),
        }
        if isinstance(reply.get("error"), dict):
            row["rpcCode"] = reply["error"].get("code")
        return row
    finally:
        child.stdin.close()
        try:
            child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            child.wait(timeout=3)
        child.stdout.close()


if __name__ == "__main__":
    report = {
        "cliVersion": subprocess.check_output([str(AGY), "--version"], text=True).strip(),
        "launcherSha256": hashlib.sha256(AGY.read_bytes()).hexdigest(),
        "isolatedHome": True,
        "handshakes": [initialize(2), initialize(1)],
    }
    (ROOT / "acp-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)

