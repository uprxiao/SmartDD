from functools import partial
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import sys
from threading import Thread, Timer
import time
from urllib.parse import urlsplit

from acp_probe import ROOT
from agy_key_path_probe import MODELS, RpcProcess, shape


class Capture(BaseHTTPRequestHandler):
    def __init__(self, records, *args, **kwargs):
        self.records = records
        super().__init__(*args, **kwargs)

    def log_message(self, *_args):
        pass

    def record(self):
        if self.command == "CONNECT":
            label = self.path
        else:
            parsed = urlsplit(self.path)
            label = (parsed.hostname or "") + parsed.path
        if re.fullmatch(r"[a-zA-Z0-9_/:.-]{1,200}", label):
            self.records.append({"method": self.command, "destination": label})
        if self.command == "CONNECT":
            self.send_error(503, "Fixture blocks upstream")
        else:
            error = b'{"error":{"code":404,"message":"F35 offline fixture","status":"NOT_FOUND"}}'
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(error)))
            self.end_headers()
            try:
                self.wfile.write(error)
            except OSError:
                pass

    do_CONNECT = record
    do_GET = record
    do_POST = record
    do_HEAD = record


def summarize_config(response, name):
    options = (response.get("result") or {}).get("configOptions") or []
    descriptor = next((entry for entry in options if entry.get("id") == name), {})
    return {"currentValue": descriptor.get("currentValue"),
            "values": [value.get("value") for value in descriptor.get("options") or [] if "value" in value]}


def handshake(wire):
    init = wire.call("initialize", {"protocolVersion": 1, "clientCapabilities": {}})
    auth = wire.call("authenticate", {"methodId": "gemini-api-key"})
    return {"initialize": shape(init), "authenticate": shape(auth)}


def run_case(case):
    case_root = ROOT / f"route-{case}"
    cwd = case_root / "cwd"
    home = case_root / "home"
    tmp = home / "tmp"
    for path in (cwd, tmp):
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    trace = case_root / "mcp-protocol.txt"
    trace.write_text("")
    records = []
    capture = ThreadingHTTPServer(("127.0.0.1", 0), partial(Capture, records))
    capture_thread = Thread(target=capture.serve_forever, daemon=True)
    capture_thread.start()
    address = f"http://127.0.0.1:{capture.server_port}"
    baseline = {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(tmp),
        "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
        "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
        "GEMINI_API_KEY": "F35-DUMMY-CREDENTIAL-FOR-OFFLINE-PROBE",
        "HTTPS_PROXY": address, "HTTP_PROXY": address, "ALL_PROXY": address, "NO_PROXY": "127.0.0.1",
        "https_proxy": address, "http_proxy": address, "all_proxy": address, "no_proxy": "127.0.0.1",
    }
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false"]
    if case == "ccpa_flag":
        args.extend(["--cloud_code_endpoint", address + "/f35-ccpa"])
    if case == "gemini_base_env":
        baseline["GOOGLE_GEMINI_BASE_URL"] = address + "/f35-gemini"

    summary = {"case": case, "proxyDoesNotForward": True, "fakeCredentialOnly": True}
    wire = None
    try:
        mcp = [{
            "name": "f35_probe_tools", "command": sys.executable,
            "args": [str(ROOT / "mcp_fixture.py"), str(trace)], "env": [],
        }] if case == "default" else []
        wire = RpcProcess(args, cwd, baseline)
        summary.update(handshake(wire))
        if summary["authenticate"]["outcome"] != "ok":
            return summary
        session = wire.call("session/new", {"cwd": str(cwd), "mcpServers": mcp})
        summary["sessionNew"] = shape(session)
        info = session.get("result") or {}
        session_id = info.get("sessionId")
        if not session_id:
            return summary
        summary["sessionIdSha256"] = hashlib.sha256(session_id.encode()).hexdigest()
        summary["modelSelections"] = {}
        for model in MODELS:
            result = wire.call("session/set_config_option", {
                "sessionId": session_id, "configId": "model", "value": model,
            })
            summary["modelSelections"][model] = {"status": shape(result)["outcome"],
                                                   "actual": summarize_config(result, "model")["currentValue"],
                                                   "thinking": summarize_config(result, "thought_level")}
        if case == "default":
            last = summary["modelSelections"][MODELS[-1]]["thinking"]
            if "medium" in last["values"]:
                effort = wire.call("session/set_config_option",
                                   {"sessionId": session_id, "configId": "thought_level", "value": "medium"})
                summary["explicitThinking"] = summarize_config(effort, "thought_level")

        cancel = Timer(3, lambda: wire.write({"method": "session/cancel", "params": {"sessionId": session_id}}))
        cancel.daemon = True
        cancel.start()
        try:
            turn = wire.call("session/prompt", {"sessionId": session_id,
                            "prompt": [{"type": "text", "text": "Reply F35-OFFLINE-ONLY."}]}, timeout=7)
            summary["turn"] = shape(turn)
            summary["turn"]["stopReason"] = (turn.get("result") or {}).get("stopReason")
        finally:
            cancel.cancel()

        if case == "default":
            summary["mcpMethods"] = trace.read_text().splitlines()
            wire.close()
            wire = None
            wire = RpcProcess(args, cwd, baseline)
            summary["freshProcess"] = handshake(wire)
            resume = wire.call("session/resume", {"sessionId": session_id, "cwd": str(cwd), "mcpServers": mcp})
            summary["resumeEstablished"] = isinstance(resume.get("result"), dict)
            summary["resume"] = shape(resume)
            summary["resumeModel"] = summarize_config(resume, "model")["currentValue"]
        return summary
    finally:
        if wire is not None:
            wire.close()
        capture.shutdown()
        capture.server_close()
        capture_thread.join(timeout=1)
        summary["capturedRequests"] = list({(r["method"], r["destination"]): r for r in records}.values())


if __name__ == "__main__":
    evidence = [run_case(case) for case in ("default", "ccpa_flag", "gemini_base_env")]
    (ROOT / "agy-observed-route-evidence.json").write_text(json.dumps(evidence, indent=2) + "\n")
    print(json.dumps(evidence, indent=2), flush=True)

