const { readFileSync, readdirSync } = require('node:fs');
const { join, resolve } = require('node:path');
const { createRequire } = require('node:module');
const [repo, baseline, destination] = process.argv.slice(2).map(arg => resolve(arg));
const requireDependency = createRequire(join(repo, 'package.json'));
const esbuild = createRequire(requireDependency.resolve('vite'))('esbuild');
const dialect = 'import.meta.glob(\'@root/drizzle/*.sql\', {';
const migrationSource = join(baseline, 'src/main/db/migrations.ts');
esbuild.build({
  entryPoints: [join(__dirname, 'host-fixture.ts')],
  outfile: destination,
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  alias: { '@f35-baseline': baseline, '@root': baseline },
  plugins: [{
    name: 'fixture-vite-sql-loader',
    setup(build) {
      build.onLoad({ filter: /[/\\]db[/\\]migrations\.ts$/ }, args => {
        if (args.path !== migrationSource) throw Error('Unexpected source identity');
        const source = readFileSync(args.path, 'utf8');
        const delimiter = /import\.meta\.glob\('@root\/drizzle\/\*\.sql', \{[\s\S]*?\}\)/;
        if (!source.includes(dialect) || !delimiter.test(source)) throw Error('Bundled migration contract changed');
        const sql = Object.fromEntries(readdirSync(join(baseline, 'drizzle')).filter(name => name.endsWith('.sql'))
          .map(name => [`/drizzle/${name}`, readFileSync(join(baseline, 'drizzle', name), 'utf8')]));
        return { contents: source.replace(delimiter, () => JSON.stringify(sql)), loader: 'ts', resolveDir: join(baseline, 'src/main/db') };
      });
    },
  }],
}).catch(error => { console.error(error); process.exitCode = 1; });
