// host-fixture.ts
import { randomUUID as randomUUID4 } from "node:crypto";
import { join as join3 } from "node:path";
import { createInterface } from "node:readline";
import { createRequire } from "node:module";

// ../baseline/src/main/core/agent/driver.ts
var DriverError = class extends Error {
  constructor(code, message, nativeCode) {
    super(message);
    this.code = code;
    this.nativeCode = nativeCode;
  }
};

// ../baseline/src/main/core/agent/agent-store.ts
import { createHash, randomUUID } from "node:crypto";
import { mkdirSync, readFileSync, realpathSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import { join, relative, sep } from "node:path";
var EVENT_PAYLOAD_LIMIT = 32 * 1024;
var BODY_LIMIT = 1024 * 1024;
var INPUT_TEXT_LIMIT = 256 * 1024;
var DRAFT_STORE_LIMIT = 2 * 1024 * 1024;
var now = () => (/* @__PURE__ */ new Date()).toISOString();
var sha256 = (text) => createHash("sha256").update(text).digest("hex");
function removeArtifactFile(path) {
  try {
    rmSync(path, { force: true });
  } catch (error) {
    const code = error.code;
    if (code !== "ENOTDIR") console.warn("[agent/artifacts] independent body cleanup failed:", code ?? "UNKNOWN");
  }
}
function boundedJson(value, limit = EVENT_PAYLOAD_LIMIT) {
  const text = JSON.stringify(value ?? null);
  if (Buffer.byteLength(text) <= limit) return text;
  return JSON.stringify({ truncated: true, bytes: Buffer.byteLength(text), sha256: sha256(text), head: Buffer.from(text).subarray(0, Math.floor(limit / 4)).toString("utf8") });
}
var bodyJson = (value) => boundedJson(value, BODY_LIMIT);
function cutStrings(v, cap) {
  return typeof v === "string" ? v.length > cap ? v.slice(0, cap) : v : Array.isArray(v) ? v.map((x) => cutStrings(x, cap)) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, cutStrings(x, cap)])) : v;
}
function shortenedJson(value, extra, limit = BODY_LIMIT) {
  for (const cap of [128 * 1024, 32 * 1024, 8 * 1024, 1024]) {
    const out = JSON.stringify({ ...cutStrings(value, cap), ...extra });
    if (Buffer.byteLength(out) <= limit) return out;
  }
  return null;
}
function minimalRef(value, artifact) {
  const top = value && typeof value === "object" && !Array.isArray(value) ? Object.entries(value).slice(0, 40) : [];
  const fields = Object.fromEntries(top.filter(([, v]) => v === null || typeof v !== "object").map(([k, v]) => [k.slice(0, 64), typeof v === "string" ? v.slice(0, 500) : v]));
  return JSON.stringify({ ...fields, previewOmitted: true, artifact });
}
var ARTIFACT_LIMIT = 64 * 1024 * 1024;
function itemJson(value) {
  const text = JSON.stringify(value ?? null);
  const bytes = Buffer.byteLength(text);
  if (bytes <= BODY_LIMIT) return text;
  return shortenedJson(value, { storedTruncated: true, bytes, sha256: sha256(text) }) ?? boundedJson(value, BODY_LIMIT);
}
var TURN_TOOL_TYPES = ["command_execution", "file_change", "file_search", "web_search", "tool_call", "proposed_plan"];
function timelineItem(row) {
  return {
    itemId: row.item_id,
    turnId: row.turn_id,
    runId: row.run_id,
    type: row.type,
    ordinal: row.ordinal,
    revision: row.revision,
    payload: JSON.parse(row.payload_ref),
    terminal: row.terminal_state,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
var AgentStore = class _AgentStore {
  constructor(sqlite, opts = {}) {
    this.sqlite = sqlite;
    this.artifactDir = opts.artifactDir;
  }
  transactionEvents = [];
  listeners = /* @__PURE__ */ new Set();
  /** 超限正文的 artifact 目录（技术方案 §3.1“超限正文转 artifact”，复核 U01）；不设时降级为结构化截短。 */
  artifactDir;
  /** 最近读过的一个原文（分段读取连续命中）；按文件身份与修改时间失效，改动或替换都会重新核对摘要。 */
  artifactCache = null;
  /**
   * 条目正文：1 MiB 内直接入库；超限时把完整原文写成 artifact 文件（先写临时文件再改名），
   * 库里只存结构化预览与受任务／条目／修订约束的引用。写入失败或超过 artifact 上限时降级并标不完整，不冒充完整保存。
   */
  itemBody(taskId, itemId, revision, value, written) {
    const text = JSON.stringify(value ?? null);
    const bytes = Buffer.byteLength(text);
    if (bytes <= BODY_LIMIT) return text;
    if (this.artifactDir && bytes <= ARTIFACT_LIMIT) {
      const rel = `${taskId}/${itemId}.r${revision}.json`;
      const file = join(this.artifactDir, rel);
      const tmp = `${file}.${randomUUID()}.tmp`;
      let renamed = false;
      try {
        mkdirSync(join(this.artifactDir, taskId), { recursive: true, mode: 448 });
        writeFileSync(tmp, text, { mode: 384, flag: "wx" });
        renameSync(tmp, file);
        renamed = true;
        const artifact = { file: rel, bytes, sha256: sha256(text) };
        const ref = shortenedJson(value, { artifact }, 256 * 1024) ?? minimalRef(value, artifact);
        written.push(file);
        return ref;
      } catch {
        removeArtifactFile(tmp);
        if (renamed) removeArtifactFile(file);
      }
    }
    return itemJson(value);
  }
  /** 带 artifact 的写事务：事务失败删除本次写出的文件；成功后删除被替换修订的旧文件。 */
  itemTx(fn) {
    const written = [], replaced = [];
    let result;
    try {
      result = this.tx((emit) => fn(written, replaced, emit));
    } catch (e) {
      for (const f of written) removeArtifactFile(f);
      throw e;
    }
    for (const ref of replaced) {
      const f = this.artifactPath(ref);
      if (f) removeArtifactFile(f);
    }
    return result;
  }
  artifactPath(rel) {
    if (!this.artifactDir || typeof rel !== "string") return null;
    const f = join(this.artifactDir, rel), r = relative(this.artifactDir, f);
    return !r || r.startsWith("..") || r.includes(`..${sep}`) ? null : f;
  }
  static artifactOf(payloadJson) {
    try {
      const a = JSON.parse(payloadJson)?.artifact;
      return a && typeof a.file === "string" ? a : null;
    } catch {
      return null;
    }
  }
  /** 条目完整正文：有 artifact 的读文件并核对大小与摘要；文件丢失或被改动明确报错，不返回残缺内容。 */
  readItemBody(taskId, itemId) {
    const r = this.itemById(taskId, itemId);
    if (!r) return void 0;
    const a = _AgentStore.artifactOf(r.payloadJson);
    if (!a) return { revision: r.revision, text: r.payloadJson };
    const file = this.artifactPath(a.file);
    if (!file || a.file !== `${taskId}/${itemId}.r${r.revision}.json`) throw new DriverError("REJECTED", "\u539F\u6587\u5F15\u7528\u65E0\u6548");
    let text, key;
    try {
      const real = realpathSync(file);
      if (relative(realpathSync(this.artifactDir), real).startsWith("..")) throw new Error("outside");
      const st = statSync(real);
      key = `${real}:${st.ino}:${st.size}:${st.mtimeMs}:${a.sha256}`;
      if (this.artifactCache?.key === key) return { revision: r.revision, text: this.artifactCache.text };
      text = readFileSync(real, "utf8");
    } catch {
      throw new DriverError("REJECTED", "\u539F\u6587\u6587\u4EF6\u4E22\u5931\uFF0C\u65E0\u6CD5\u8BFB\u53D6\u5168\u6587");
    }
    if (Buffer.byteLength(text) !== a.bytes || sha256(text) !== a.sha256) throw new DriverError("REJECTED", "\u539F\u6587\u6587\u4EF6\u5DF2\u635F\u574F\uFF0C\u65E0\u6CD5\u8BFB\u53D6\u5168\u6587");
    this.artifactCache = { key, text };
    return { revision: r.revision, text };
  }
  subscribe(listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
  notify(events) {
    for (const e of events) for (const l of [...this.listeners]) {
      try {
        l(e);
      } catch {
      }
    }
  }
  /** 在事务内追加事件；返回已提交事件，由调用方在事务外 notify。 */
  appendIn(taskId, type, payload, itemId = null, revision = null) {
    const { seq } = this.sqlite.prepare("SELECT COALESCE(MAX(seq),0)+1 AS seq FROM agent_events WHERE task_id=?").get(taskId);
    const stored = boundedJson(payload);
    this.sqlite.prepare("INSERT INTO agent_events(task_id,seq,event_type,item_id,revision,payload,created_at) VALUES(?,?,?,?,?,?,?)").run(taskId, seq, type, itemId, revision, stored, now());
    return { taskId, seq, type, itemId, payload: stored === JSON.stringify(payload ?? null) ? payload : JSON.parse(stored) };
  }
  /** 写库与事件在同一事务；提交成功后才通知。 */
  tx(fn) {
    const pending = [];
    this.transactionEvents.push(pending);
    try {
      const result = this.sqlite.transaction(() => fn((taskId, type, payload, itemId = null, revision = null) => {
        pending.push(this.appendIn(taskId, type, payload, itemId, revision));
      }))();
      this.transactionEvents.pop();
      const parent = this.transactionEvents.at(-1);
      if (parent) parent.push(...pending);
      else this.notify(pending);
      return result;
    } catch (e) {
      this.transactionEvents.pop();
      throw e;
    }
  }
  createTask(input) {
    const taskId = input.taskId ?? randomUUID(), at2 = now(), ms = Date.now();
    this.tx((emit) => {
      this.sqlite.prepare("INSERT INTO tasks(id,project_id,dir_id,cwd,runner,title,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)").run(taskId, input.projectId, input.dirId, input.cwd, input.selection.driverId === "codex-app-server" ? "codex" : "claude", input.title, ms, ms);
      this.sqlite.prepare("INSERT INTO agent_tasks(task_id,parent_task_id,selection_json,created_at,updated_at) VALUES(?,?,?,?,?)").run(taskId, input.parentTaskId ?? null, JSON.stringify(input.selection), at2, at2);
      emit(taskId, "task.created", { selection: input.selection });
    });
    return taskId;
  }
  task(taskId) {
    return this.sqlite.prepare("SELECT t.id,t.project_id,t.dir_id,t.cwd,t.title,a.selection_json,a.selection_revision,a.archived_at,a.parent_task_id FROM tasks t JOIN agent_tasks a ON a.task_id=t.id WHERE t.id=?").get(taskId);
  }
  /** 同一任务、执行器与兼容身份下最新的绑定；兼容身份变化（配置根、开关等）必须新建绑定。 */
  findBinding(taskId, driverId, continuationHash) {
    return this.sqlite.prepare("SELECT * FROM agent_bindings WHERE task_id=? AND driver_id=? AND continuation_hash=? ORDER BY created_at DESC, rowid DESC LIMIT 1").get(taskId, driverId, continuationHash);
  }
  binding(bindingId) {
    return this.sqlite.prepare("SELECT * FROM agent_bindings WHERE binding_id=?").get(bindingId);
  }
  /** 不含凭据的创建配置快照；恢复绑定沿用创建时扩展选择。 */
  bindingLaunch(taskId, profileId) {
    const row = this.sqlite.prepare("SELECT b.*,s.snapshot_json FROM agent_bindings b JOIN agent_capability_sessions s ON s.binding_id=b.binding_id WHERE b.task_id=? AND b.profile_id=? AND json_extract(s.snapshot_json,'$.kind')='launch' ORDER BY b.created_at DESC,b.rowid DESC,s.revision DESC LIMIT 1").get(taskId, profileId);
    return row ? { binding: row, frozen: JSON.parse(row.snapshot_json) } : void 0;
  }
  freezeBinding(bindingId, value) {
    if (this.sqlite.prepare("SELECT 1 FROM agent_capability_sessions WHERE binding_id=? AND json_extract(snapshot_json,'$.kind')='launch' LIMIT 1").get(bindingId)) return;
    const text = JSON.stringify({ kind: "launch", ...value });
    const row = this.sqlite.prepare("SELECT COALESCE(MAX(revision),0)+1 AS revision FROM agent_capability_sessions WHERE binding_id=?").get(bindingId);
    this.sqlite.prepare("INSERT INTO agent_capability_sessions(capability_session_id,binding_id,revision,content_hash,snapshot_json,created_at) VALUES(?,?,?,?,?,?)").run(randomUUID(), bindingId, row.revision, sha256(text), text, now());
  }
  recordTransfer(t) {
    return this.itemTx((written, _replaced, emit) => {
      this.sqlite.prepare("INSERT INTO agent_transfers(transfer_id,task_id,target_binding_id,kind,through_seq,covered_ids_json,omissions_json,payload_hash,delivery_state,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)").run(t.id, t.taskId, t.bindingId, t.kind, this.watermark(t.taskId), JSON.stringify(t.covered), JSON.stringify(t.omissions), sha256(t.text), "pending", now());
      const itemId = randomUUID();
      const { ordinal } = this.sqlite.prepare("SELECT COALESCE(MAX(ordinal),0)+1 AS ordinal FROM agent_items WHERE task_id=?").get(t.taskId);
      const payload = { transferId: t.id, inputTurnId: t.turnId, text: t.text, covered: t.covered, omissions: t.omissions, kind: t.kind, sourceKind: "history" };
      this.sqlite.prepare("INSERT INTO agent_items(item_id,task_id,turn_id,type,ordinal,revision,native_key,payload_ref,terminal_state,created_at,updated_at) VALUES(?,?,?,'handoff',?,1,?,?,'completed',?,?)").run(itemId, t.taskId, t.turnId, ordinal, `transfer:${t.id}`, this.itemBody(t.taskId, itemId, 1, payload, written), now(), now());
      emit(t.taskId, "item.created", { type: "handoff", ordinal, payload }, itemId, 1);
      return itemId;
    });
  }
  createBinding(b) {
    const id = randomUUID();
    this.sqlite.prepare("INSERT INTO agent_bindings(binding_id,task_id,driver_id,profile_id,continuation_hash,state_root,cwd_identity,created_at) VALUES(?,?,?,?,?,?,?,?)").run(id, b.task_id, b.driver_id, b.profile_id, b.continuation_hash, b.state_root, b.cwd_identity, now());
    return id;
  }
  /** 原生确认身份。已确认的绑定不能改指其他原生会话；新原生身份须新建绑定。 */
  confirmNative(bindingId, nativeId) {
    this.tx((emit) => {
      const row = this.binding(bindingId);
      if (!row) throw new Error("\u7ED1\u5B9A\u4E0D\u5B58\u5728");
      if (row.native_confirmed_at && row.native_id !== nativeId) throw new Error("\u7ED1\u5B9A\u5DF2\u786E\u8BA4\u4E3A\u5176\u4ED6\u539F\u751F\u4F1A\u8BDD");
      if (row.native_confirmed_at) return;
      this.sqlite.prepare("UPDATE agent_bindings SET native_id=?,native_confirmed_at=? WHERE binding_id=?").run(nativeId, now(), bindingId);
      emit(row.task_id, "binding.confirmed", { bindingId, nativeId });
      const creation = this.sqlite.prepare(`UPDATE agent_items
        SET payload_ref=json_set(payload_ref,'$.bindingId',?),revision=revision+1,updated_at=?
        WHERE task_id=(SELECT parent_task_id FROM agent_delegations WHERE child_task_id=?)
          AND type='thread_created' AND json_extract(payload_ref,'$.childTaskId')=?
          AND json_type(payload_ref,'$.bindingId')='null'
        RETURNING task_id,item_id,revision`).get(bindingId, now(), row.task_id, row.task_id);
      if (creation) emit(creation.task_id, "item.updated", { type: "thread_created", bindingId }, creation.item_id, creation.revision);
    });
  }
  nextGeneration(bindingId) {
    return this.sqlite.prepare("SELECT COALESCE(MAX(generation),0)+1 AS g FROM capability_runs WHERE binding_id=?").get(bindingId).g;
  }
  insertRun(r) {
    this.tx((emit) => {
      const sessionId = randomUUID(), text = JSON.stringify({ kind: "run_preparing", runId: r.runId, launchPlanHash: r.launchPlanHash });
      const revision = this.sqlite.prepare("SELECT COALESCE(MAX(revision),0)+1 AS n FROM agent_capability_sessions WHERE binding_id=?").get(r.bindingId).n;
      this.sqlite.prepare("INSERT INTO agent_capability_sessions(capability_session_id,binding_id,revision,content_hash,snapshot_json,created_at) VALUES(?,?,?,?,?,?)").run(sessionId, r.bindingId, revision, sha256(text), text, now());
      this.sqlite.prepare("INSERT INTO capability_runs(run_id,task_id,project_id,runner,state,started_at,owner_instance_id,owner_pid,owner_started_at,binding_id,capability_session_id,driver_id,generation,launch_plan_hash,binding_mode) VALUES(?,?,?,?,'preparing',?,?,?,?,?,?,?,?,?,'run')").run(r.runId, r.taskId, r.projectId ?? "", r.driverId, now(), r.owner.instanceId, r.owner.pid, r.owner.startedAt, r.bindingId, sessionId, r.driverId, r.generation, r.launchPlanHash);
      emit(r.taskId, "run.preparing", { runId: r.runId, bindingId: r.bindingId, generation: r.generation, driverId: r.driverId });
    });
  }
  freezeNativeRun(runId, value) {
    const r = this.run(runId);
    if (!r || r.pid || r.state !== "preparing") throw new DriverError("STATE", "\u539F\u751F\u542F\u52A8\u4EA4\u4ED8\u5DF2\u7ECF\u56FA\u5B9A");
    const row = this.sqlite.prepare("SELECT snapshot_json FROM agent_capability_sessions WHERE capability_session_id=?").get(r.capability_session_id);
    if (JSON.parse(row.snapshot_json).kind !== "run_preparing") throw new DriverError("STATE", "\u4E0D\u80FD\u66FF\u6362\u5DF2\u56FA\u5B9A\u7684\u8FD0\u884C\u80FD\u529B");
    const text = JSON.stringify({ kind: "native", runId, value });
    this.sqlite.prepare("UPDATE agent_capability_sessions SET snapshot_json=?,content_hash=? WHERE capability_session_id=?").run(text, sha256(text), r.capability_session_id);
  }
  /** 只接受本宿主自己启动的原生进程 PID（来自 ChildProcess），不接受客户端或模型自报。 */
  attachRunProcess(runId, taskId, pid, processStartedAt) {
    this.tx((emit) => {
      const changed = this.sqlite.prepare("UPDATE capability_runs SET pid=?,process_started_at=?,state='active' WHERE run_id=? AND state IN ('preparing','prepared') AND pid IS NULL").run(pid, processStartedAt, runId).changes;
      if (changed) emit(taskId, "run.active", { runId, pid, processStartedAt });
    });
  }
  finishRun(runId, taskId, state, errorCode) {
    this.tx((emit) => {
      if (this.sqlite.prepare("SELECT 1 FROM agent_events WHERE task_id=? AND event_type='run.ended' AND json_extract(payload,'$.runId')=?").get(taskId, runId)) return;
      const row = this.run(runId);
      if (!row || !["preparing", "prepared", "active", "stopping", "stopped", "failed"].includes(row.state)) return;
      this.sqlite.prepare("UPDATE capability_runs SET state=?,error_code=?,ended_at=COALESCE(ended_at,?) WHERE run_id=?").run(state, errorCode, now(), runId);
      const retired = this.sqlite.prepare("UPDATE agent_requests SET status='retired',updated_at=? WHERE class='native' AND status='pending' AND json_extract(origin_json,'$.runId')=?").run(now(), runId).changes;
      const open = this.sqlite.prepare("SELECT turn_id FROM agent_turns WHERE run_id=? AND status IN ('dispatching','started')").all(runId);
      for (const t of open) {
        this.sqlite.prepare("UPDATE agent_turns SET status='unknown',ended_at=?,error_code='RUN_ENDED' WHERE turn_id=?").run(now(), t.turn_id);
        this.settleTurnTools(emit, { taskId, turnId: t.turn_id });
        emit(taskId, "turn.ended", { turnId: t.turn_id, status: "unknown" });
      }
      emit(taskId, "run.ended", { runId, state, errorCode, retiredRequests: retired });
    });
  }
  run(runId) {
    return this.sqlite.prepare("SELECT * FROM capability_runs WHERE run_id=?").get(runId);
  }
  /** 本地接受：同一 clientInputId 只接受一次，重复提交返回原收据（幂等只保证宿主接受）。 */
  acceptTurn(t) {
    return this.itemTx((written, _replaced, emit) => {
      const existing = this.sqlite.prepare("SELECT * FROM agent_turns WHERE task_id=? AND client_input_id=?").get(t.taskId, t.clientInputId);
      if (existing) return { turn: existing, duplicate: true };
      const turnId = randomUUID();
      if (Buffer.byteLength(t.text) > INPUT_TEXT_LIMIT) throw new Error(`\u8F93\u5165\u8D85\u8FC7 ${INPUT_TEXT_LIMIT / 1024} KB\uFF0C\u8BF7\u62C6\u5206\u6216\u6539\u7528\u9644\u4EF6`);
      this.sqlite.prepare("INSERT INTO agent_turns(turn_id,task_id,client_input_id,input_ref,source_kind,status,accepted_at) VALUES(?,?,?,?,?,'accepted',?)").run(turnId, t.taskId, t.clientInputId, JSON.stringify({ text: t.text, ...t.attachments?.length ? { attachments: t.attachments } : {} }), t.sourceKind, now());
      emit(t.taskId, "turn.accepted", { turnId, clientInputId: t.clientInputId, sourceKind: t.sourceKind });
      const { ordinal } = this.sqlite.prepare("SELECT COALESCE(MAX(ordinal),0)+1 AS ordinal FROM agent_items WHERE task_id=?").get(t.taskId);
      const itemId = randomUUID();
      this.sqlite.prepare("INSERT INTO agent_items(item_id,task_id,turn_id,type,ordinal,revision,native_key,payload_ref,terminal_state,created_at,updated_at) VALUES(?,?,?,'user_message',?,1,?,?,'completed',?,?)").run(itemId, t.taskId, turnId, ordinal, `input:${turnId}`, this.itemBody(t.taskId, itemId, 1, { text: t.text, sourceKind: t.sourceKind, ...t.attachments?.length ? { attachments: t.attachments.map((a) => ({ name: a.name, kind: a.kind, image: a.image, relativePath: a.relativePath })) } : {} }, written), now(), now());
      emit(t.taskId, "item.created", { type: "user_message", ordinal, payload: { text: t.text, sourceKind: t.sourceKind } }, itemId, 1);
      return { turn: this.sqlite.prepare("SELECT * FROM agent_turns WHERE turn_id=?").get(turnId), duplicate: false };
    });
  }
  itemById(taskId, itemId) {
    const r = this.sqlite.prepare("SELECT item_id,type,revision,payload_ref FROM agent_items WHERE task_id=? AND item_id=?").get(taskId, itemId);
    return r ? { itemId: r.item_id, type: r.type, revision: r.revision, payloadJson: r.payload_ref } : void 0;
  }
  turnByClientInput(taskId, clientInputId) {
    return this.sqlite.prepare("SELECT * FROM agent_turns WHERE task_id=? AND client_input_id=?").get(taskId, clientInputId);
  }
  inputForTurn(turnId) {
    return this.sqlite.prepare("SELECT * FROM agent_turns WHERE turn_id=?").get(turnId);
  }
  editQueuedInput(taskId, turnId, version, text) {
    return this.itemTx((written, replaced, emit) => {
      const turn = this.inputForTurn(turnId);
      if (turn?.task_id !== taskId || turn.source_kind !== "user" || turn.status !== "accepted" || sha256(turn.input_ref) !== version) {
        throw new DriverError("STATE", "\u6392\u961F\u8F93\u5165\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6");
      }
      const message = this.sqlite.prepare("SELECT item_id, revision, payload_ref FROM agent_items WHERE task_id=? AND native_key=? AND type='user_message'").get(taskId, "input:" + turnId);
      if (!message) throw new DriverError("STATE", "\u6392\u961F\u8F93\u5165\u7684\u5386\u53F2\u8BB0\u5F55\u4E0D\u53EF\u7528");
      const input = JSON.parse(turn.input_ref);
      const attachments = (input.attachments ?? []).map((a) => ({ name: a.name, kind: a.kind, image: a.image, relativePath: a.relativePath }));
      const payload = { text, sourceKind: "user", ...attachments.length ? { attachments } : {} };
      const revision = message.revision + 1;
      const old = _AgentStore.artifactOf(message.payload_ref);
      if (old) replaced.push(old.file);
      this.sqlite.prepare("UPDATE agent_turns SET input_ref=? WHERE turn_id=?").run(JSON.stringify({ ...input, text }), turnId);
      this.sqlite.prepare("UPDATE agent_items SET payload_ref=?, revision=?, updated_at=? WHERE item_id=?").run(this.itemBody(taskId, message.item_id, revision, payload, written), revision, now(), message.item_id);
      emit(taskId, "item.updated", { type: "user_message" }, message.item_id, revision);
    });
  }
  turn(turnId) {
    return this.sqlite.prepare("SELECT * FROM agent_turns WHERE turn_id=?").get(turnId);
  }
  turnByNative(runId, nativeTurnId) {
    return this.sqlite.prepare("SELECT * FROM agent_turns WHERE run_id=? AND native_turn_id=? ORDER BY started_at,rowid LIMIT 1").get(runId, nativeTurnId);
  }
  dispatchTurn(turnId, runId) {
    const turn = this.turn(turnId);
    this.tx((emit) => {
      if (!this.sqlite.prepare("UPDATE agent_turns SET status='dispatching',run_id=? WHERE turn_id=? AND status='accepted'").run(runId, turnId).changes) throw new Error("\u8BE5\u8F93\u5165\u5DF2\u5728\u5904\u7406\u6216\u5DF2\u7ED3\u675F");
      emit(turn.task_id, "turn.dispatching", { turnId, runId });
    });
  }
  startTurn(turnId, nativeTurnId) {
    const turn = this.turn(turnId);
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_turns SET status='started',native_turn_id=?,started_at=? WHERE turn_id=? AND status='dispatching'").run(nativeTurnId, now(), turnId).changes)
        emit(turn.task_id, "turn.started", { turnId, nativeTurnId });
    });
  }
  endTurn(turnId, status, errorCode = null) {
    const turn = this.turn(turnId);
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_turns SET status=?,ended_at=?,error_code=? WHERE turn_id=? AND status IN ('accepted','dispatching','started')").run(status, now(), errorCode, turnId).changes) {
        this.sqlite.prepare("UPDATE agent_requests SET status='retired',updated_at=? WHERE class='native' AND status='pending' AND json_extract(origin_json,'$.turnId')=?").run(now(), turnId);
        this.settleTurnTools(emit, { taskId: turn.task_id, turnId });
        emit(turn.task_id, "turn.ended", { turnId, status, errorCode });
      }
    });
  }
  /** Preserve the last native payload and its body revision, including any artifact. */
  settleTurnTools(emit, turn) {
    const scope = turn ? "task_id=? AND turn_id=?" : "turn_id IN (SELECT turn_id FROM agent_turns WHERE status IN ('completed','failed','interrupted','unknown','canceled'))";
    const rows = this.sqlite.prepare(`UPDATE agent_items SET terminal_state='unconfirmed',updated_at=?
      WHERE terminal_state IS NULL AND node_id IS NULL AND ${scope}
        AND type IN (${TURN_TOOL_TYPES.map(() => "?").join(",")})
      RETURNING task_id,item_id,type,revision`).all(now(), ...turn ? [turn.taskId, turn.turnId] : [], ...TURN_TOOL_TYPES);
    for (const row of rows) emit(row.task_id, "item.updated", { type: row.type, terminal: "unconfirmed" }, row.item_id, row.revision);
  }
  /** 规范条目：ordinal 稳定；原生键包含 binding/run/generation，同一原生条目重复到达只升修订。 */
  upsertItem(i) {
    return this.itemTx((written, replaced, emit) => {
      const existing = this.sqlite.prepare("SELECT item_id,revision,payload_ref,terminal_state FROM agent_items WHERE task_id=? AND native_key=?").get(i.taskId, i.nativeKey);
      if (existing) {
        if (existing.terminal_state && !i.terminalState && TURN_TOOL_TYPES.includes(i.type)) return existing.item_id;
        const revision = existing.revision + 1;
        const old = _AgentStore.artifactOf(existing.payload_ref);
        if (old) replaced.push(old.file);
        this.sqlite.prepare("UPDATE agent_items SET payload_ref=?,revision=?,terminal_state=?,updated_at=? WHERE item_id=?").run(this.itemBody(i.taskId, existing.item_id, revision, i.payload, written), revision, i.terminalState ?? null, now(), existing.item_id);
        emit(i.taskId, "item.updated", { type: i.type, payload: i.payload }, existing.item_id, revision);
        return existing.item_id;
      }
      const itemId = randomUUID();
      const { ordinal } = this.sqlite.prepare("SELECT COALESCE(MAX(ordinal),0)+1 AS ordinal FROM agent_items WHERE task_id=?").get(i.taskId);
      this.sqlite.prepare("INSERT INTO agent_items(item_id,task_id,turn_id,run_id,node_id,type,ordinal,revision,native_key,payload_ref,terminal_state,created_at,updated_at) VALUES(?,?,?,?,?,?,?,1,?,?,?,?,?)").run(itemId, i.taskId, i.turnId, i.runId, i.nodeId ?? null, i.type, ordinal, i.nativeKey, this.itemBody(i.taskId, itemId, 1, i.payload, written), i.terminalState ?? null, now(), now());
      emit(i.taskId, "item.created", { type: i.type, ordinal, payload: i.payload }, itemId, 1);
      return itemId;
    });
  }
  insertNativeRequest(r) {
    return this.tx((emit) => {
      const requestId = randomUUID();
      this.sqlite.prepare("INSERT INTO agent_requests(request_id,task_id,class,origin_json,kind,payload_ref,status,created_at,updated_at) VALUES(?,?,'native',?,?,?,'pending',?,?)").run(requestId, r.taskId, JSON.stringify(r.origin), r.kind, bodyJson(r.payload), now(), now());
      emit(r.taskId, "request.opened", { requestId, kind: r.kind, payload: r.payload, origin: r.origin });
      return requestId;
    });
  }
  request(requestId) {
    return this.sqlite.prepare("SELECT * FROM agent_requests WHERE request_id=?").get(requestId);
  }
  requestByNative(runId, nativeRequest) {
    return this.sqlite.prepare("SELECT * FROM agent_requests WHERE class='native' AND json_extract(origin_json,'$.runId')=? AND json_extract(origin_json,'$.nativeRequest')=?").get(runId, nativeRequest);
  }
  resolveRequest(requestId, decision) {
    const row = this.request(requestId);
    let persisted = decision;
    if (row.class === "native" && row.kind === "user_input") {
      const payload = JSON.parse(row.payload_ref);
      if (payload.truncated) persisted = null;
      else if (Array.isArray(payload.params?.questions)) {
        const secrets = new Set(payload.params.questions.filter((q) => q?.isSecret === true).map((q) => q.id));
        if (secrets.size) {
          const answers = decision?.answers;
          persisted = { answers: Object.fromEntries(Object.entries(answers ?? {}).filter(([id]) => !secrets.has(id))) };
        }
      }
    }
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_requests SET status='resolved',decision_ref=?,updated_at=? WHERE request_id=? AND status='pending'").run(boundedJson(persisted), now(), requestId).changes)
        emit(row.task_id, "request.resolved", { requestId });
    });
  }
  retireRequest(requestId, reason) {
    const row = this.request(requestId);
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_requests SET status='retired',updated_at=? WHERE request_id=? AND status='pending'").run(now(), requestId).changes)
        emit(row.task_id, "request.retired", { requestId, reason });
    });
  }
  /** 草稿 CAS：修订不符返回冲突，保留调用方本地编辑（R01 草稿按任务持久保存）。 */
  saveDraft(taskId, draft, expectedRevision) {
    return this.sqlite.transaction(() => {
      const row = this.sqlite.prepare("SELECT draft_json,draft_revision FROM agent_tasks WHERE task_id=?").get(taskId);
      if (!row) throw new Error("\u4EFB\u52A1\u4E0D\u5B58\u5728");
      if (row.draft_revision !== expectedRevision) return { ok: false, revision: row.draft_revision, draft: JSON.parse(row.draft_json) };
      const revision = row.draft_revision + 1;
      const text = JSON.stringify(draft ?? null);
      if (Buffer.byteLength(text) > DRAFT_STORE_LIMIT) throw new DriverError("REJECTED", "\u8349\u7A3F\u8FC7\u5927\uFF0C\u672A\u4FDD\u5B58");
      this.sqlite.prepare("UPDATE agent_tasks SET draft_json=?,draft_revision=?,updated_at=? WHERE task_id=?").run(text, revision, now(), taskId);
      return { ok: true, revision };
    })();
  }
  updateSelection(taskId, patch, expectedRevision, labels) {
    return this.itemTx((written, _replaced, emit) => {
      const row = this.sqlite.prepare("SELECT selection_json,selection_revision FROM agent_tasks WHERE task_id=?").get(taskId);
      if (!row) throw new Error("\u4EFB\u52A1\u4E0D\u5B58\u5728");
      const current = JSON.parse(row.selection_json);
      if (row.selection_revision !== expectedRevision) return { ok: false, revision: row.selection_revision, selection: current };
      const selection = { ...current, ...patch }, revision = row.selection_revision + 1;
      this.sqlite.prepare("UPDATE agent_tasks SET selection_json=?,selection_revision=?,updated_at=? WHERE task_id=?").run(JSON.stringify(selection), revision, now(), taskId);
      if (current.profileId !== selection.profileId) {
        const itemId = randomUUID(), payload = { from: current.profileId, to: selection.profileId, fromName: labels?.from ?? current.profileId, toName: labels?.to ?? selection.profileId, driverId: selection.driverId };
        const { ordinal } = this.sqlite.prepare("SELECT COALESCE(MAX(ordinal),0)+1 AS ordinal FROM agent_items WHERE task_id=?").get(taskId);
        this.sqlite.prepare("INSERT INTO agent_items(item_id,task_id,type,ordinal,revision,native_key,payload_ref,terminal_state,created_at,updated_at) VALUES(?,?,'provider_switch',?,1,?,?,'completed',?,?)").run(itemId, taskId, ordinal, `switch:${revision}`, this.itemBody(taskId, itemId, 1, payload, written), now(), now());
        emit(taskId, "item.created", { type: "provider_switch", ordinal, payload }, itemId, 1);
      }
      emit(taskId, "selection.changed", { selection, revision });
      return { ok: true, revision, selection };
    });
  }
  taskFamily(taskId) {
    return this.sqlite.prepare(`WITH RECURSIVE family(id) AS (
      SELECT task_id FROM agent_tasks WHERE task_id=?
      UNION SELECT a.task_id FROM agent_tasks a JOIN family f ON a.parent_task_id=f.id
    ) SELECT id FROM family`).all(taskId).map((row) => row.id);
  }
  setTasksArchived(taskIds, archived) {
    const stamp = now();
    this.tx((emit) => {
      const update = this.sqlite.prepare(`UPDATE agent_tasks SET archived_at=?,updated_at=? WHERE task_id=? AND archived_at IS ${archived ? "" : "NOT "}NULL`);
      for (const id of taskIds) {
        if (update.run(archived ? stamp : null, stamp, id).changes) emit(id, archived ? "task.archived" : "task.unarchived", {});
      }
    });
  }
  renameTask(taskId, title) {
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE tasks SET title=? WHERE id=? AND title<>?").run(title, taskId, title).changes) {
        emit(taskId, "task.renamed", { title });
      }
    });
  }
  setTaskPinned(taskId, pinned) {
    this.tx((emit) => {
      const result = this.sqlite.prepare(`UPDATE agent_tasks SET pinned_at=? WHERE task_id=? AND pinned_at IS ${pinned ? "" : "NOT "}NULL`).run(pinned ? now() : null, taskId);
      if (result.changes) emit(taskId, "task.pinChanged", { pinned });
    });
  }
  deleteTask(taskId, purge) {
    const event = this.sqlite.transaction(() => {
      const { seq } = this.sqlite.prepare("SELECT COALESCE(MAX(seq),0)+1 AS seq FROM agent_events WHERE task_id=?").get(taskId);
      purge();
      this.sqlite.prepare("DELETE FROM tasks WHERE id=?").run(taskId);
      return { taskId, seq, type: "task.removed", itemId: null, payload: {} };
    })();
    this.notify([event]);
  }
  listTasks(includeArchived = false) {
    return this.sqlite.prepare(`SELECT t.id,t.project_id,t.dir_id,t.cwd,t.title,a.selection_json,a.archived_at,a.created_at,a.updated_at,a.parent_task_id,a.pinned_at FROM tasks t JOIN agent_tasks a ON a.task_id=t.id ${includeArchived ? "" : "WHERE a.archived_at IS NULL"} ORDER BY a.created_at DESC, a.rowid DESC`).all();
  }
  /** 排队中的输入：已接受、尚未派发，按接受顺序。 */
  queuedTurns(taskId) {
    return this.sqlite.prepare("SELECT turn_id,client_input_id,input_ref,accepted_at,source_kind FROM agent_turns WHERE task_id=? AND status='accepted' ORDER BY accepted_at,rowid").all(taskId);
  }
  turns(taskId) {
    return this.sqlite.prepare("SELECT turn_id,client_input_id,status,native_turn_id,accepted_at,started_at,ended_at,error_code,run_id,source_kind FROM agent_turns WHERE task_id=? ORDER BY accepted_at,rowid").all(taskId);
  }
  /** Foreground time excludes the union of blocking waits on the same run and turn. */
  turnsWithNativeWait(taskId) {
    const turns = this.turns(taskId);
    if (!turns.length) return turns;
    const byTurn = new Map(turns.map((turn) => [turn.turn_id, turn]));
    const intervals = /* @__PURE__ */ new Map();
    const requests = this.sqlite.prepare(`SELECT json_extract(origin_json,'$.turnId') AS turn_id,
      json_extract(origin_json,'$.runId') AS run_id, created_at, updated_at, status
      FROM agent_requests WHERE task_id=? AND class='native' AND json_valid(origin_json)
        AND json_extract(origin_json,'$.nodeId') IS NULL`).all(taskId);
    for (const request of requests) {
      if (!request.turn_id) continue;
      const turn = byTurn.get(request.turn_id);
      if (!turn?.started_at || turn.run_id !== request.run_id) continue;
      const start = Math.max(Date.parse(turn.started_at), Date.parse(request.created_at));
      const end = Math.min(
        turn.ended_at ? Date.parse(turn.ended_at) : Infinity,
        request.status === "pending" ? Infinity : Date.parse(request.updated_at)
      );
      if (!(end > start)) continue;
      const windows = intervals.get(request.turn_id) ?? [];
      windows.push([start, end]);
      intervals.set(request.turn_id, windows);
    }
    return turns.map((turn) => {
      const windows = intervals.get(turn.turn_id);
      if (!windows?.length) return turn;
      windows.sort((a, b) => a[0] - b[0]);
      let [start, end] = windows[0];
      let waited = 0;
      for (const [nextStart, nextEnd] of windows.slice(1)) {
        if (nextStart > end) {
          waited += end - start;
          start = nextStart;
          end = nextEnd;
        } else {
          end = Math.max(end, nextEnd);
        }
      }
      return end === Infinity ? { ...turn, native_wait_ms: waited, native_wait_since: start } : { ...turn, native_wait_ms: waited + end - start };
    });
  }
  /** 最近的条目（renderer 每任务上限 2000 条，技术方案 §3.1）；beforeOrdinal 分页读更早的。 */
  items(taskId, opts = {}) {
    const limit = Math.min(opts.limit ?? 2e3, 2e3);
    return this.sqlite.prepare(`SELECT * FROM (SELECT item_id,turn_id,run_id,type,ordinal,revision,payload_ref,terminal_state,created_at,updated_at FROM agent_items WHERE task_id=? AND type NOT IN ('subagent_message','subagent_status') AND ordinal<? ORDER BY ordinal DESC LIMIT ?) ORDER BY ordinal`).all(taskId, opts.beforeOrdinal ?? Number.MAX_SAFE_INTEGER, limit).map(timelineItem);
  }
  historyItems(taskId, itemIds) {
    if (!itemIds.length) return [];
    const params = itemIds.map(() => "?").join(",");
    const rows = this.sqlite.prepare(`SELECT item_id,turn_id,run_id,type,ordinal,revision,payload_ref,terminal_state,created_at,updated_at
      FROM agent_items WHERE task_id=? AND type NOT IN ('subagent_message','subagent_status') AND item_id IN (${params}) ORDER BY ordinal`).all(taskId, ...itemIds);
    return rows.map(timelineItem);
  }
  pendingRequests(taskId, present = false) {
    return this.sqlite.prepare("SELECT request_id,class,kind,revision,payload_ref,origin_json,status,created_at FROM agent_requests WHERE task_id=? AND status IN ('pending','approved_pending_bind') ORDER BY created_at,rowid").all(taskId).map((r) => {
      const payload = JSON.parse(r.payload_ref);
      const targetId = present && r.class === "host_business" && payload?.businessKind === "browser_access" ? payload.review?.targetTaskId : void 0;
      const target = typeof targetId === "string" ? this.sqlite.prepare("SELECT b.title FROM tasks a JOIN tasks b ON a.project_id=b.project_id WHERE a.id=? AND b.id=?").get(taskId, targetId) : void 0;
      return { requestId: r.request_id, class: r.class, kind: r.kind, revision: r.revision, payload, origin: JSON.parse(r.origin_json), status: r.status, createdAt: r.created_at, targetTaskTitle: target?.title.slice(0, 120) };
    });
  }
  draft(taskId) {
    const r = this.sqlite.prepare("SELECT draft_json,draft_revision FROM agent_tasks WHERE task_id=?").get(taskId);
    if (!r) return null;
    const draft = JSON.parse(r.draft_json);
    if (draft && typeof draft === "object" && draft.truncated === true && typeof draft.sha256 === "string" && "head" in draft) return { draft: null, revision: r.draft_revision, damaged: true, bytes: Number(draft.bytes) || 0 };
    return { draft, revision: r.draft_revision };
  }
  watermark(taskId) {
    return this.sqlite.prepare("SELECT COALESCE(MAX(seq),0) AS seq FROM agent_events WHERE task_id=?").get(taskId).seq;
  }
  /**
   * 宿主重启恢复（技术方案 §9）：上一宿主实例留下的新运行一律收口为 orphaned；原生阻塞请求退役；
   * 已派发但无原生终态的回合标“结果未知”，不自动重发。返回需要按出生身份核对的原生进程。
   */
  recoverOrphanRuns(currentInstanceId) {
    return this.tx((emit) => {
      const rows = this.sqlite.prepare("SELECT run_id,task_id,pid,process_started_at FROM capability_runs WHERE binding_id IS NOT NULL AND state IN ('preparing','active','stopping') AND COALESCE(owner_instance_id,'')<>?").all(currentInstanceId);
      for (const r of rows) {
        this.sqlite.prepare("UPDATE capability_runs SET state='orphaned',error_code='HOST_RESTARTED',ended_at=? WHERE run_id=?").run(now(), r.run_id);
        this.sqlite.prepare("UPDATE agent_requests SET status='retired',updated_at=? WHERE class='native' AND status='pending' AND json_extract(origin_json,'$.runId')=?").run(now(), r.run_id);
        for (const t of this.sqlite.prepare("SELECT turn_id FROM agent_turns WHERE run_id=? AND status IN ('dispatching','started')").all(r.run_id)) {
          this.sqlite.prepare("UPDATE agent_turns SET status='unknown',ended_at=?,error_code='HOST_RESTARTED' WHERE turn_id=?").run(now(), t.turn_id);
          emit(r.task_id, "turn.ended", { turnId: t.turn_id, status: "unknown", errorCode: "HOST_RESTARTED" });
        }
        emit(r.task_id, "run.ended", { runId: r.run_id, state: "orphaned", errorCode: "HOST_RESTARTED" });
      }
      this.settleTurnTools(emit);
      return rows.map((r) => ({ runId: r.run_id, taskId: r.task_id, pid: r.pid, processStartedAt: r.process_started_at }));
    });
  }
  runsAwaitingRestartRecovery(currentInstanceId, taskId) {
    return this.sqlite.prepare(`SELECT r.run_id AS runId,r.task_id AS taskId,r.pid,r.process_started_at AS startedAt
      FROM capability_runs r WHERE r.binding_id IS NOT NULL AND r.owner_instance_id<>?
      AND r.pid IS NOT NULL AND r.process_started_at IS NOT NULL
      AND (r.state='orphaned' AND EXISTS(SELECT 1 FROM capability_run_processes p WHERE p.run_id=r.run_id AND p.kind='cli')
        OR (r.state='orphaned' OR (r.state='stopped' AND r.error_code='HOST_INTERRUPTED'))
          AND EXISTS(SELECT 1 FROM agent_items i WHERE i.run_id=r.run_id AND i.type='subagent_status' AND i.terminal_state IS NULL))
      ${taskId === void 0 ? "" : "AND r.task_id=?"}`).all(...taskId === void 0 ? [currentInstanceId] : [currentInstanceId, taskId]);
  }
  interruptRecoveredNativeNodes(runId) {
    this.tx((emit) => {
      const rows = this.sqlite.prepare(`UPDATE agent_items
        SET payload_ref=json_set(payload_ref,'$.state','interrupted','$.reason','owner-restarted'),
          terminal_state='failed',revision=revision+1,updated_at=?
        WHERE run_id=? AND type='subagent_status' AND terminal_state IS NULL
        RETURNING item_id,task_id,revision,payload_ref`).all(now(), runId);
      for (const row of rows) emit(row.task_id, "item.updated", { type: "subagent_status", payload: JSON.parse(row.payload_ref) }, row.item_id, row.revision);
    });
  }
  tasksWithQueue() {
    return this.sqlite.prepare("SELECT DISTINCT task_id FROM agent_turns WHERE status='accepted'").all().map((r) => r.task_id);
  }
  /** 原生自行开始的回合（目标自动续跑等）：宿主记录为系统来源的回合，不生成用户消息。 */
  acceptAutoTurn(taskId, runId, nativeTurnId) {
    return this.tx((emit) => {
      const existing = this.turnByNative(runId, nativeTurnId);
      if (existing) return existing.turn_id;
      const turnId = randomUUID();
      this.sqlite.prepare("INSERT INTO agent_turns(turn_id,task_id,run_id,client_input_id,input_ref,source_kind,status,native_turn_id,accepted_at,started_at) VALUES(?,?,?,?,'{}','system','started',?,?,?)").run(turnId, taskId, runId, `auto:${nativeTurnId}`, nativeTurnId, now(), now());
      emit(taskId, "turn.started", { turnId, nativeTurnId, sourceKind: "system" });
      return turnId;
    });
  }
  /** 插话被原生接受后并入当前原生回合；该回合结束时一起收口。 */
  attachSteer(turnId, runId, nativeTurnId) {
    const turn = this.turn(turnId);
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_turns SET status='started',run_id=?,native_turn_id=?,started_at=? WHERE turn_id=? AND status='accepted'").run(runId, nativeTurnId, now(), turnId).changes)
        emit(turn.task_id, "turn.steered", { turnId, nativeTurnId });
    });
  }
  /** 驱动在发送前就拒绝（证明未发出）：放回排队，不记未知（技术方案 §5 投递状态 not_sent）。 */
  requeueTurn(turnId) {
    const turn = this.turn(turnId);
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE agent_turns SET status='accepted',run_id=NULL WHERE turn_id=? AND status='dispatching'").run(turnId).changes) emit(turn.task_id, "turn.requeued", { turnId });
    });
  }
  turnsByNative(runId, nativeTurnId) {
    return this.sqlite.prepare("SELECT * FROM agent_turns WHERE run_id=? AND native_turn_id=? AND status IN ('dispatching','started')").all(runId, nativeTurnId);
  }
  upsertGoal(g) {
    this.tx((emit) => {
      const cur = this.sqlite.prepare("SELECT objective,revision,turns,status FROM agent_goals WHERE task_id=?").get(g.taskId);
      if (g.status === "cleared") {
        if (cur) this.sqlite.prepare("UPDATE agent_goals SET status='cleared',paused_reason=NULL,updated_at=? WHERE task_id=?").run(now(), g.taskId);
        emit(g.taskId, "goal.changed", { status: "cleared" });
        return;
      }
      const objective = g.objective ?? cur?.objective ?? "";
      const status = g.status === "limited" ? "paused" : g.status;
      const reason = status === "paused" ? g.status === "limited" ? "limit" : g.pausedReason ?? "user" : null;
      const previous = this.goalNativeMeta(g.taskId);
      const nativeCreatedAt = Number.isFinite(g.nativeCreatedAt) ? g.nativeCreatedAt : previous.nativeCreatedAt;
      const nativeUpdatedAt = Number.isFinite(g.nativeUpdatedAt) ? g.nativeUpdatedAt : previous.nativeUpdatedAt;
      const revision = !cur ? 1 : cur.status === "cleared" || cur.objective !== objective || previous.nativeCreatedAt !== void 0 && nativeCreatedAt !== previous.nativeCreatedAt ? cur.revision + 1 : cur.revision;
      this.sqlite.prepare(`INSERT INTO agent_goals(task_id,binding_id,objective,revision,status,paused_reason,turns,time_used_s,updated_at) VALUES(?,?,?,?,?,?,0,?,?)
        ON CONFLICT(task_id) DO UPDATE SET binding_id=excluded.binding_id,objective=excluded.objective,revision=excluded.revision,status=excluded.status,paused_reason=excluded.paused_reason,time_used_s=MAX(agent_goals.time_used_s,excluded.time_used_s),turns=CASE WHEN agent_goals.revision<>excluded.revision THEN 0 ELSE agent_goals.turns END,updated_at=excluded.updated_at`).run(g.taskId, g.bindingId, objective, revision, status, reason, Math.round(g.timeUsedSeconds ?? 0), now());
      emit(g.taskId, "goal.changed", { objective, status, pausedReason: reason, revision, bindingId: g.bindingId, nativeCreatedAt, nativeUpdatedAt });
    });
  }
  /** 执行器不回报目标用时（Claude）时，由宿主按目标进行期间的回合用时累计。 */
  addGoalTime(taskId, seconds) {
    if (seconds > 0) this.sqlite.prepare("UPDATE agent_goals SET time_used_s=time_used_s+?,updated_at=? WHERE task_id=? AND status='active'").run(Math.round(seconds), now(), taskId);
  }
  countGoalTurn(taskId) {
    this.sqlite.prepare("UPDATE agent_goals SET turns=turns+1,updated_at=? WHERE task_id=? AND status='active'").run(now(), taskId);
  }
  goalNativeMeta(taskId) {
    const r = this.sqlite.prepare("SELECT payload FROM agent_events WHERE task_id=? AND event_type='goal.changed' ORDER BY seq DESC LIMIT 1").get(taskId);
    if (!r) return {};
    const p = JSON.parse(r.payload);
    return { ...Number.isFinite(p.nativeCreatedAt) ? { nativeCreatedAt: p.nativeCreatedAt } : {}, ...Number.isFinite(p.nativeUpdatedAt) ? { nativeUpdatedAt: p.nativeUpdatedAt } : {} };
  }
  goal(taskId) {
    const r = this.sqlite.prepare("SELECT binding_id,objective,revision,status,paused_reason,turns,time_used_s,updated_at FROM agent_goals WHERE task_id=?").get(taskId);
    return r && r.status !== "cleared" ? { ...this.goalNativeMeta(taskId), bindingId: r.binding_id, objective: r.objective, revision: r.revision, status: r.status, pausedReason: r.paused_reason, turns: r.turns, timeUsedSeconds: r.time_used_s, updatedAt: r.updated_at } : null;
  }
  /** 宿主条目（启动失败等用户可见原因，复核 CR17）：不属于任何原生运行。 */
  addHostItem(taskId, turnId, type, payload) {
    return this.itemTx((written, _replaced, emit) => {
      const itemId = randomUUID();
      const { ordinal } = this.sqlite.prepare("SELECT COALESCE(MAX(ordinal),0)+1 AS ordinal FROM agent_items WHERE task_id=?").get(taskId);
      this.sqlite.prepare("INSERT INTO agent_items(item_id,task_id,turn_id,type,ordinal,revision,native_key,payload_ref,terminal_state,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,'completed',?,?)").run(itemId, taskId, turnId, type, ordinal, `host:${itemId}`, this.itemBody(taskId, itemId, 1, payload, written), now(), now());
      emit(taskId, "item.created", { type, ordinal, payload }, itemId, 1);
      return itemId;
    });
  }
  /** 已请求关闭但尚未观察到进程退出：保留占用（复核 CR04）。 */
  markRunStopping(runId, taskId) {
    this.tx((emit) => {
      if (this.sqlite.prepare("UPDATE capability_runs SET state='stopping' WHERE run_id=? AND state IN ('preparing','active')").run(runId).changes) emit(taskId, "run.stopping", { runId });
    });
  }
  recordProbe(p) {
    const id = randomUUID();
    this.sqlite.prepare("INSERT INTO agent_driver_probes(probe_id,driver_id,binary_path,realpath,version,capabilities_json,state,reason,probed_at) VALUES(?,?,?,?,?,?,?,?,?)").run(id, p.driverId, p.binaryPath, p.realpath, p.version, JSON.stringify(p.capabilities), p.state, p.reason, now());
    return id;
  }
  events(taskId, afterSeq = 0, limit = 128, throughSeq = Number.MAX_SAFE_INTEGER) {
    return this.sqlite.prepare("SELECT task_id,seq,event_type,item_id,payload FROM agent_events WHERE task_id=? AND seq>? AND seq<=? ORDER BY seq LIMIT ?").all(taskId, afterSeq, throughSeq, limit).map((r) => ({ taskId: r.task_id, seq: r.seq, type: r.event_type, itemId: r.item_id, payload: JSON.parse(r.payload) }));
  }
};

// ../baseline/src/main/core/agent/directory-queue.ts
import { randomUUID as randomUUID2 } from "node:crypto";
import { realpathSync as realpathSync2, statSync as statSync2 } from "node:fs";
import { relative as relative2, isAbsolute } from "node:path";
var within = (parent, child) => {
  const r = relative2(parent, child);
  return !r || !isAbsolute(r) && r !== ".." && !r.startsWith("../");
};
function directoryIdentity(cwd, registered) {
  const actual = realpathSync2(cwd);
  const roots = registered.map((p) => {
    try {
      return realpathSync2(p);
    } catch {
      return null;
    }
  }).filter((p) => !!p && within(p, actual));
  if (!roots.length) throw new DriverError("REJECTED", "\u5DE5\u4F5C\u76EE\u5F55\u4E0D\u5C5E\u4E8E\u5DF2\u767B\u8BB0\u7684\u5DE5\u4F5C\u6839\uFF0C\u4E0D\u80FD\u53D6\u5F97\u5199\u5165\u8D44\u683C");
  const root = roots.sort((a, b) => a.length - b.length)[0], stat = statSync2(root);
  if (!stat.isDirectory()) throw new DriverError("REJECTED", "\u767B\u8BB0\u5DE5\u4F5C\u6839\u4E0D\u662F\u76EE\u5F55");
  return { root, identity: `${root}:${stat.dev}:${stat.ino}` };
}
function overlappingIdentity(a, b) {
  if (a === b) return true;
  const x = /^(.*):(\d+):(\d+)$/.exec(a), y = /^(.*):(\d+):(\d+)$/.exec(b);
  return !!x && !!y && (x[2] === y[2] && x[3] === y[3] || within(x[1], y[1]) || within(y[1], x[1]));
}
var DirectoryQueue = class {
  constructor(store2) {
    this.store = store2;
  }
  enter(taskId, identity, trustedRead = false) {
    return this.store.tx((emit) => {
      const existing = this.forTask(taskId);
      if (existing) {
        if (existing.directory_identity !== identity) throw new DriverError("STATE", "\u4EFB\u52A1\u7684\u5DE5\u4F5C\u6839\u5360\u7528\u4ECD\u672A\u91CA\u653E");
        return existing;
      }
      const id = randomUUID2(), order = this.store.sqlite.prepare("SELECT COALESCE(MAX(accepted_order),0)+1 AS n FROM agent_directory_queue").get().n;
      this.store.sqlite.prepare("INSERT INTO agent_directory_queue(queue_id,directory_identity,task_id,kind,state,accepted_order,created_at) VALUES(?,?,?,?,'queued',?,?)").run(id, identity, taskId, trustedRead ? "read" : "write", order, (/* @__PURE__ */ new Date()).toISOString());
      emit(taskId, "directory.queued", { queueId: id, order });
      return this.get(id);
    });
  }
  get(id) {
    return this.store.sqlite.prepare("SELECT * FROM agent_directory_queue WHERE queue_id=?").get(id);
  }
  forTask(taskId) {
    return this.store.sqlite.prepare("SELECT * FROM agent_directory_queue WHERE task_id=? AND state IN ('queued','active') ORDER BY accepted_order LIMIT 1").get(taskId);
  }
  writeView(identities) {
    if (!identities.size) return [];
    return this.store.sqlite.prepare("SELECT * FROM agent_directory_queue WHERE kind='write' AND state IN ('queued','active') ORDER BY rowid").all().filter((row) => [...identities].some((identity) => overlappingIdentity(identity, row.directory_identity)));
  }
  acquire(id) {
    return this.store.tx((emit) => {
      const row = this.get(id);
      if (!row || !["queued", "active"].includes(row.state)) return false;
      if (row.state === "active") return true;
      const serial = this.store.sqlite.prepare("SELECT rowid AS n FROM agent_directory_queue WHERE queue_id=?").get(id).n;
      if (row.kind === "write" && this.store.sqlite.prepare("SELECT rowid AS serial,* FROM agent_directory_queue WHERE kind='write' AND state IN ('active','queued') AND queue_id<>?").all(id).some((other) => overlappingIdentity(row.directory_identity, other.directory_identity) && (other.state === "active" || other.serial < serial))) return false;
      this.store.sqlite.prepare("UPDATE agent_directory_queue SET state='active' WHERE queue_id=? AND state='queued'").run(id);
      emit(row.task_id, "directory.acquired", { queueId: id });
      return true;
    });
  }
  hasQueuedCompetitor(taskId) {
    const q = this.forTask(taskId);
    if (!q) return false;
    return this.store.sqlite.prepare("SELECT directory_identity FROM agent_directory_queue WHERE task_id<>? AND kind='write' AND state='queued'").all(taskId).some((other) => overlappingIdentity(q.directory_identity, other.directory_identity));
  }
  bind(id, runId) {
    const row = this.get(id), run = this.store.run(runId);
    if (!row || row.state !== "active" || run?.task_id !== row.task_id || row.run_id && row.run_id !== runId) throw new DriverError("STATE", "\u8FD0\u884C\u4E0E\u76EE\u5F55\u8D44\u683C\u4E0D\u7B26");
    this.store.sqlite.prepare("UPDATE agent_directory_queue SET run_id=? WHERE queue_id=?").run(runId, id);
  }
  release(id, proof) {
    if (!Object.values(proof).every((v) => v === true)) throw new DriverError("STATE", "\u9000\u51FA\u3001\u540E\u4EE3\u6216\u4E1A\u52A1\u4ECD\u672A\u6392\u7A7A\uFF0C\u4FDD\u7559\u76EE\u5F55\u5360\u7528");
    return this.store.tx((emit) => {
      const r = this.get(id);
      if (!r || r.state !== "active") return false;
      this.store.sqlite.prepare("UPDATE agent_directory_queue SET state='released',ended_at=? WHERE queue_id=?").run((/* @__PURE__ */ new Date()).toISOString(), id);
      emit(r.task_id, "directory.released", { queueId: id, proof });
      return true;
    });
  }
  cancel(taskId) {
    this.store.tx((emit) => {
      const changed = this.store.sqlite.prepare("UPDATE agent_directory_queue SET state='canceled',ended_at=? WHERE task_id=? AND state='queued'").run((/* @__PURE__ */ new Date()).toISOString(), taskId);
      if (changed.changes) emit(taskId, "directory.canceled", {});
    });
  }
};

// ../baseline/src/main/core/agent/git-workspaces.ts
import { execFile } from "node:child_process";
import { randomUUID as randomUUID3 } from "node:crypto";
import { existsSync, lstatSync, mkdirSync as mkdirSync2, realpathSync as realpathSync3 } from "node:fs";
import { dirname, isAbsolute as isAbsolute2, join as join2, relative as relative3, resolve } from "node:path";
var runWorkspaceCommand = (cwd, command, args, timeoutMs = 12e4, options = {}) => new Promise((resolveCommand) => {
  execFile(command, [...args], { cwd, signal: options.signal, timeout: timeoutMs, maxBuffer: 8 * 1024 * 1024, encoding: "utf8", env: { ...process.env, GIT_TERMINAL_PROMPT: "0" } }, (e, stdout, stderr) => resolveCommand({ stdout, stderr, code: e ? typeof e.code === "number" ? e.code : -1 : 0 }));
});
var at = () => (/* @__PURE__ */ new Date()).toISOString();
var inside = (root, path) => {
  const r = relative3(root, path);
  return !r || !isAbsolute2(r) && r !== ".." && !r.startsWith("../");
};
var slug = (s) => s.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48) || "task";
var GitWorkspaces = class {
  constructor(d) {
    this.d = d;
  }
  preparingByRoot = /* @__PURE__ */ new Map();
  call(cwd, args) {
    return (this.d.command ?? runWorkspaceCommand)(cwd, "git", args);
  }
  async effect(taskId, cwd, args, signal) {
    const r = await (this.d.command ?? runWorkspaceCommand)(cwd, "git", args, 12e4, { taskId, signal });
    if (r.code !== 0) throw new DriverError("STATE", `Git ${args[0]} \u5931\u8D25\uFF1A${r.stderr.slice(-1800)}`);
    return r.stdout.trim();
  }
  async git(cwd, ...args) {
    const r = await this.call(cwd, args);
    if (r.code !== 0) throw new DriverError("STATE", `Git ${args[0]} \u5931\u8D25\uFF1A${r.stderr.slice(-1800) || r.stdout.slice(-1800)}`);
    return r.stdout.trim();
  }
  async detect(cwd) {
    const actual = realpathSync3(cwd);
    for (let p = actual; ; p = dirname(p)) {
      if (existsSync(join2(p, ".svn"))) return null;
      if (dirname(p) === p) break;
    }
    const r = await this.call(actual, ["rev-parse", "--show-toplevel"]);
    if (r.code !== 0 || !r.stdout.trim()) return null;
    const root = realpathSync3(r.stdout.trim());
    if (!inside(root, actual)) return null;
    return { root, cwd: actual, branch: await this.git(root, "rev-parse", "--abbrev-ref", "HEAD") };
  }
  async sourceSnapshot(repo) {
    const baseCommit = await this.git(repo.root, "rev-parse", "HEAD");
    const status = await this.call(repo.root, ["--no-optional-locks", "status", "--porcelain=v1", "-z", "-uall", "--no-renames"]);
    if (status.code !== 0) throw new DriverError("STATE", "\u65E0\u6CD5\u6838\u5BF9\u4E3B\u76EE\u5F55\u5C1A\u672A\u63D0\u4EA4\u7684\u6587\u4EF6");
    return { baseCommit, uncommittedFiles: status.stdout.split("\0").filter(Boolean).length };
  }
  workspace(childTaskId) {
    return this.d.store.sqlite.prepare("SELECT * FROM agent_workspaces WHERE child_task_id=? AND kind='git_worktree' AND state<>'archived' ORDER BY rowid DESC LIMIT 1").get(childTaskId);
  }
  snapshotExclusions(taskId, cwd, userData) {
    const stateRoot = resolve(this.d.home, ".willyou");
    const root = join2(stateRoot, "worktrees"), workspace = this.workspace(taskId);
    if (workspace?.state !== "ready" || workspace.path === root || !inside(root, workspace.path) || !inside(workspace.path, cwd)) {
      return [userData, stateRoot];
    }
    if (realpathSync3(workspace.path) !== workspace.path || realpathSync3(cwd) !== cwd) {
      throw new DriverError("STATE", "\u5DEE\u5F02\u6355\u83B7\u65F6\u5DF2\u767B\u8BB0\u5DE5\u4F5C\u526F\u672C\u7684\u8DEF\u5F84\u53D1\u751F\u53D8\u5316");
    }
    return [userData];
  }
  intent(taskId, action, target, head, metadata = {}) {
    const id = randomUUID3();
    this.d.store.sqlite.prepare("INSERT INTO agent_intents(intent_id,task_id,action,target_ref,head_before,expected_parent,state,result_json,created_at,updated_at) VALUES(?,?,?,?,?,?,'intended',?,?,?)").run(id, taskId, action, target, head, head, JSON.stringify(metadata), at(), at());
    return id;
  }
  finish(id, state, value) {
    const old = this.d.store.sqlite.prepare("SELECT result_json FROM agent_intents WHERE intent_id=?").get(id);
    this.d.store.sqlite.prepare("UPDATE agent_intents SET state=?,result_json=?,updated_at=? WHERE intent_id=?").run(state, JSON.stringify({ ...JSON.parse(old.result_json ?? "{}"), ...value }), at(), id);
  }
  async cleanBoundary(cwd) {
    for (const name of ["CHERRY_PICK_HEAD", "MERGE_HEAD", "REBASE_HEAD", "rebase-merge", "rebase-apply"]) {
      const state = await this.git(cwd, "rev-parse", "--git-path", name);
      if (!state || existsSync(isAbsolute2(state) ? state : join2(cwd, state))) throw new DriverError("STATE", `\u4ED3\u5E93\u6709\u672A\u7ED3\u675F\u7684 ${name}\uFF0C\u8BF7\u5148\u5904\u7406`);
    }
    if ((await this.git(cwd, "ls-files", "-u")).length) throw new DriverError("STATE", "\u4ED3\u5E93\u4ECD\u6709\u672A\u89E3\u51B3\u51B2\u7A81");
  }
  async commit(taskId, workspace, attemptId, message) {
    await this.cleanBoundary(workspace.path);
    const before = await this.git(workspace.path, "rev-parse", "HEAD");
    if (!await this.git(workspace.path, "status", "--porcelain=v1", "-uall")) return before;
    const kind = "child_result";
    const id = this.intent(taskId, "child_result_commit", workspace.path, before, { attemptId, workspaceId: workspace.workspace_id, message, kind });
    try {
      await this.effect(taskId, workspace.path, ["add", "-A"]);
      await this.effect(taskId, workspace.path, ["commit", "-m", message, "-m", `WillYou-Intent: ${id}`]);
      const head = await this.git(workspace.path, "rev-parse", "HEAD");
      if (await this.git(workspace.path, "rev-parse", `${head}^`) !== before) throw new DriverError("STATE", "\u63D0\u4EA4\u7684\u7236\u63D0\u4EA4\u4E0D\u7B26\uFF0C\u4FDD\u7559\u4E3A\u5F85\u6838\u5B9E");
      this.d.store.tx(() => {
        this.d.store.sqlite.prepare("INSERT OR IGNORE INTO agent_commit_provenance(commit_sha,workspace_id,attempt_id,intent_id,kind,message,created_at) VALUES(?,?,?,?,?,?,?)").run(head, workspace.workspace_id, attemptId, id, kind, message, at());
        this.finish(id, "done", { head });
      });
      return head;
    } catch (e) {
      this.finish(id, "needs_review", { error: e.message });
      throw e;
    }
  }
  async create(input) {
    const repo = await this.detect(input.cwd);
    if (!repo) return null;
    if (input.expectedBranch !== void 0 && repo.branch !== input.expectedBranch) throw new DriverError("STATE", "\u63A5\u53D7\u59D4\u6D3E\u540E\u4E3B\u5206\u652F\u5DF2\u7ECF\u53D8\u5316\uFF0C\u672A\u521B\u5EFA\u5DE5\u4F5C\u526F\u672C");
    if (input.expectedRoot && repo.root !== input.expectedRoot) throw new DriverError("STATE", "\u63A5\u53D7\u59D4\u6D3E\u540E\u4ED3\u5E93\u8EAB\u4EFD\u5DF2\u53D8\u5316");
    const previous = this.preparingByRoot.get(repo.root);
    let unlock;
    const slot = new Promise((resolve2) => {
      unlock = resolve2;
    });
    this.preparingByRoot.set(repo.root, slot);
    const release = () => {
      if (this.preparingByRoot.get(repo.root) === slot) this.preparingByRoot.delete(repo.root);
      unlock();
    };
    await previous;
    try {
      const existing = this.workspace(input.childTaskId);
      if (existing) {
        if (existing.state !== "ready") throw new DriverError("STATE", "\u5DE5\u4F5C\u526F\u672C\u51C6\u5907\u5F85\u6838\u5B9E\uFF0C\u672A\u91CD\u590D\u6267\u884C");
        return { workspace: existing, cwd: this.worktreeCwd(existing, input.cwd) };
      }
      input.signal?.throwIfAborted();
      return await this.prepareWorktree(input, repo, release);
    } finally {
      release();
    }
  }
  async prepareWorktree(input, repo, release) {
    const { signal } = input;
    signal?.throwIfAborted();
    const base = input.baseCommit ?? await this.git(repo.root, "rev-parse", "HEAD");
    if (!/^[a-f0-9]{40,64}$/.test(base)) throw new DriverError("STATE", "\u5DE5\u4F5C\u526F\u672C\u57FA\u51C6\u63D0\u4EA4\u65E0\u6548");
    const branchBase = `${repo.branch === "HEAD" ? base.slice(0, 8) : repo.branch.toLowerCase()}_willyou_${slug(input.title)}`;
    let branch = branchBase, n = 1;
    while ((await this.call(repo.root, ["show-ref", "--verify", "--quiet", "refs/heads/" + branch])).code === 0) branch = `${branchBase}-${++n}`;
    await this.git(repo.root, "check-ref-format", "--branch", branch);
    const ownedRoot = resolve(this.d.home, ".willyou/worktrees"), project = slug(input.projectName).replace(/^task$/, "project") + "-" + input.projectId.replace(/[^a-zA-Z0-9]/g, "").slice(0, 6);
    const path = join2(ownedRoot, project, branch);
    if (inside(repo.root, path)) throw new DriverError("REJECTED", "\u5DE5\u4F5C\u526F\u672C\u4E0D\u80FD\u653E\u8FDB\u4E3B\u4ED3\u5E93\u5185\u90E8\uFF0C\u8BF7\u4F7F\u7528\u4E0D\u5305\u542B\u7528\u6237\u5DE5\u4F5C\u526F\u672C\u767B\u8BB0\u6839\u7684\u9879\u76EE\u76EE\u5F55");
    if (!inside(ownedRoot, path) || /\s/.test(path)) throw new DriverError("REJECTED", "\u5DE5\u4F5C\u526F\u672C\u8DEF\u5F84\u8D8A\u754C\u6216\u542B\u7A7A\u683C\uFF0C\u4E0D\u80FD\u6309\u5DF2\u786E\u8BA4\u89C4\u5219\u521B\u5EFA");
    if (existsSync(path)) throw new DriverError("STATE", "\u5DE5\u4F5C\u526F\u672C\u8DEF\u5F84\u5DF2\u5B58\u5728\uFF0C\u672A\u8986\u76D6");
    mkdirSync2(dirname(path), { recursive: true });
    if (!inside(realpathSync3(ownedRoot), realpathSync3(dirname(path)))) throw new DriverError("REJECTED", "\u5DE5\u4F5C\u526F\u672C\u7236\u76EE\u5F55\u5DF2\u88AB\u94FE\u63A5\u5230\u767B\u8BB0\u6839\u4EE5\u5916");
    const id = randomUUID3(), intent = this.intent(input.parentTaskId, "worktree_add", path, base, { childTaskId: input.childTaskId, branch });
    this.d.store.sqlite.prepare("INSERT INTO agent_workspaces(workspace_id,task_id,child_task_id,kind,repo_root,path,branch,base_commit,state,created_at,updated_at) VALUES(?,?,?,'git_worktree',?,?,?,?,'preparing',?,?)").run(id, input.parentTaskId, input.childTaskId, repo.root, path, branch, base, at(), at());
    try {
      signal?.throwIfAborted();
      await this.effect(input.childTaskId, repo.root, ["worktree", "add", "-b", branch, path, base], signal);
      release();
      const childCwd = this.worktreeCwd({ path, repo_root: repo.root }, repo.cwd, true);
      const dependencies = await this.installDependencies(childCwd, path, { signal: input.signal, taskId: input.childTaskId });
      this.d.store.tx((emit) => {
        this.d.store.sqlite.prepare("UPDATE agent_workspaces SET state='ready',deps_result=?,updated_at=? WHERE workspace_id=?").run(JSON.stringify(dependencies), at(), id);
        this.finish(intent, "done", { path, branch, base });
        emit(input.childTaskId, "workspace.ready", { path, branch });
      });
      return { workspace: this.workspace(input.childTaskId), cwd: childCwd };
    } catch (e) {
      this.d.store.sqlite.prepare("UPDATE agent_workspaces SET state='failed',updated_at=? WHERE workspace_id=?").run(at(), id);
      this.finish(intent, "needs_review", { error: e.message });
      throw e;
    }
  }
  worktreeCwd(workspace, sourceCwd, create = false) {
    const root = realpathSync3(workspace.path);
    if (root !== workspace.path) throw new DriverError("STATE", "\u5DF2\u767B\u8BB0\u5DE5\u4F5C\u526F\u672C\u8DEF\u5F84\u5DF2\u53D8\u5316");
    const source = realpathSync3(sourceCwd);
    if (!inside(workspace.repo_root, source)) throw new DriverError("STATE", "\u539F\u5DE5\u4F5C\u76EE\u5F55\u5DF2\u8D8A\u51FA\u4ED3\u5E93");
    let cwd = root;
    for (const part of relative3(workspace.repo_root, source).split("/").filter(Boolean)) {
      cwd = join2(cwd, part);
      if (create && !existsSync(cwd)) mkdirSync2(cwd);
      if (realpathSync3(cwd) !== cwd) throw new DriverError("STATE", "\u5DE5\u4F5C\u526F\u672C\u7684\u6620\u5C04\u76EE\u5F55\u5305\u542B\u7B26\u53F7\u94FE\u63A5");
    }
    return cwd;
  }
  async installDependencies(cwd, root, options = {}) {
    if (options.signal?.aborted) return { state: "canceled", reason: "\u5B50\u4EFB\u52A1\u51C6\u5907\u5DF2\u53D6\u6D88" };
    for (const dir of [.../* @__PURE__ */ new Set([cwd, root])]) for (const [file, command, args] of [["pnpm-lock.yaml", "pnpm", ["install", "--frozen-lockfile"]], ["package-lock.json", "npm", ["ci"]], ["yarn.lock", "yarn", ["install", "--frozen-lockfile"]]]) {
      if (!existsSync(join2(dir, file))) continue;
      const r = await (this.d.command ?? runWorkspaceCommand)(dir, command, args, this.d.dependencyTimeoutMs ?? 12e4, options);
      return { state: options.signal?.aborted ? "canceled" : r.code === 0 ? "installed" : "failed", command, args, cwd: dir, code: r.code, detail: (r.stderr || r.stdout).slice(-4e3) };
    }
    return { state: "skipped", reason: "\u6CA1\u6709\u53D7\u652F\u6301\u7684 JS \u9501\u6587\u4EF6\uFF08Maven\uFF0FGradle \u4E0D\u5B89\u88C5\uFF09" };
  }
  async finalize(childTaskId, attemptId, title, startHead) {
    const w = this.workspace(childTaskId);
    if (!w || w.state !== "ready") return null;
    const head = await this.commit(childTaskId, w, attemptId, `willyou: ${title.slice(0, 120)}\uFF08\u5B50\u4EFB\u52A1\u63D0\u4EA4\uFF09`);
    const base = startHead ?? w.base_commit;
    const commits = (await this.git(w.path, "rev-list", "--reverse", `${base}..${head}`)).split("\n").filter(Boolean);
    const range = { branch: w.branch, base, head, commits, files: (await this.git(w.path, "diff", "--name-only", base, head)).split("\n").filter(Boolean), summary: await this.git(w.path, "diff", "--stat", base, head) };
    this.d.store.sqlite.prepare("UPDATE agent_delegation_attempts SET commit_range=? WHERE attempt_id=?").run(JSON.stringify(range), attemptId);
    return range;
  }
  async checkMerge(cwd, range, expectedBranch) {
    const result = { pass: false, missingCommits: [...range.commits], inProgress: [], conflictMarkers: "", branchOk: false };
    try {
      const cherry = await this.git(cwd, "cherry", "HEAD", range.branch), equivalent = new Set(cherry.split("\n").filter((s) => s.startsWith("- ")).map((s) => s.slice(2)));
      const picked = new Set([...(await this.git(cwd, "log", "--format=%B", `${range.base}..HEAD`)).matchAll(/\(cherry picked from commit ([a-f0-9]{40,64})\)/g)].map((m) => m[1]));
      result.missingCommits = [];
      for (const h of range.commits) if ((await this.call(cwd, ["merge-base", "--is-ancestor", h, "HEAD"])).code !== 0 && !equivalent.has(h) && !picked.has(h)) result.missingCommits.push(h);
      for (const name of ["CHERRY_PICK_HEAD", "MERGE_HEAD", "REBASE_HEAD", "rebase-merge", "rebase-apply"]) {
        const p = await this.git(cwd, "rev-parse", "--git-path", name);
        if (!p) throw new Error(`\u72B6\u6001 ${name} \u65E0\u6CD5\u89E3\u6790`);
        if (existsSync(isAbsolute2(p) ? p : join2(cwd, p))) result.inProgress.push(name);
      }
      if (range.files.length) {
        const markers = await this.call(cwd, ["grep", "-nE", "^(<<<<<<<|>>>>>>>)( |$)", "--", ...range.files]);
        if (markers.code !== 0 && markers.code !== 1) throw new Error("\u51B2\u7A81\u6807\u8BB0\u6838\u5BF9\u5931\u8D25");
        result.conflictMarkers = markers.stdout;
      }
      result.branchOk = await this.git(cwd, "rev-parse", "--abbrev-ref", "HEAD") === expectedBranch;
      result.pass = !result.missingCommits.length && !result.inProgress.length && !result.conflictMarkers && result.branchOk;
    } catch (e) {
      result.error = e.message;
    }
    return result;
  }
  /** No guessed replay: recognize an exact unique commit trailer or a registered worktree; ambiguous windows stay needs_review. */
  async recoverIntents() {
    this.d.store.sqlite.prepare("UPDATE agent_intents SET state='needs_review',updated_at=? WHERE state='intended' AND action='auto_commit'").run(at());
    const rows = this.d.store.sqlite.prepare("SELECT * FROM agent_intents WHERE state='intended' AND action IN ('child_result_commit','worktree_add')").all();
    for (const r of rows) {
      try {
        const meta = JSON.parse(r.result_json ?? "{}");
        if (r.action === "worktree_add") {
          const w = this.workspace(meta.childTaskId ?? "");
          if (!w || w.path !== r.target_ref) throw new Error("\u5DE5\u4F5C\u526F\u672C\u767B\u8BB0\u7F3A\u5931");
          const list = await this.git(w.repo_root, "worktree", "list", "--porcelain");
          const records = list.split("\n\n").map((t) => Object.fromEntries(t.split("\n").map((l) => {
            const i = l.indexOf(" ");
            return [l.slice(0, i), l.slice(i + 1)];
          })));
          if (!records.some((x) => resolve(x.worktree ?? "") === resolve(w.path) && x.branch === "refs/heads/" + w.branch && x.HEAD === w.base_commit)) throw new Error("\u767B\u8BB0\u8DEF\u5F84\u3001\u5206\u652F\u6216\u57FA\u51C6\u4E0D\u540C\uFF0C\u672A\u91CD\u590D\u521B\u5EFA");
          if (!await this.d.recoverySafe?.(r.task_id)) throw new Error("\u539F\u8FD0\u884C\u6216\u4E1A\u52A1\u5C1A\u672A\u6838\u5B9E\u6392\u7A7A\uFF0C\u4FDD\u7559\u51C6\u5907\u72B6\u6001");
          this.d.store.tx(() => {
            this.d.store.sqlite.prepare("UPDATE agent_workspaces SET state='ready',deps_result=COALESCE(deps_result,?),updated_at=? WHERE workspace_id=?").run(JSON.stringify({ state: "unknown", reason: "\u5BBF\u4E3B\u9000\u51FA\u4E2D\u65AD\u4F9D\u8D56\u51C6\u5907\uFF0C\u672A\u81EA\u52A8\u91CD\u88C5\uFF1B\u542F\u52A8\u65F6\u987B\u62A5\u544A\u6B64\u9650\u5236" }), at(), w.workspace_id);
            this.finish(r.intent_id, "done", { recovered: true, path: w.path });
          });
        } else {
          if (!r.expected_parent || r.expected_parent !== r.head_before) throw new Error("\u610F\u56FE\u7684\u9884\u671F\u7236\u63D0\u4EA4\u7F3A\u5931\u6216\u4E0D\u540C");
          let head = await this.git(r.target_ref, "rev-parse", "HEAD");
          if ((await this.call(r.target_ref, ["merge-base", "--is-ancestor", r.expected_parent, head])).code !== 0) throw new Error("HEAD \u5DF2\u79FB\u79BB\u9884\u671F\u7236\u63D0\u4EA4\uFF0C\u672A\u81EA\u52A8\u91CD\u505A");
          const lines = await this.git(r.target_ref, "log", "--format=%H%x00%B%x00", "--fixed-strings", "--grep", `WillYou-Intent: ${r.intent_id}`, `${r.expected_parent}..HEAD`);
          let matches = lines.split("\0").reduce((out, _x, i, a) => {
            if (i % 2 === 0 && a[i + 1]?.split("\n").includes(`WillYou-Intent: ${r.intent_id}`) && /^[a-f0-9]{40,64}$/.test(a[i].trim())) out.push(a[i].trim());
            return out;
          }, []);
          const w = this.d.store.sqlite.prepare("SELECT * FROM agent_workspaces WHERE workspace_id=? AND path=?").get(meta.workspaceId ?? "", r.target_ref);
          if (!w || !meta.message || w.kind !== "git_worktree" || meta.kind !== "child_result") throw new Error("\u63D0\u4EA4\u7684\u56FA\u5B9A\u5DE5\u4F5C\u526F\u672C\u6216\u6765\u6E90\u4FE1\u606F\u7F3A\u5931");
          if (!matches.length && head === r.expected_parent && await this.git(w.path, "status", "--porcelain=v1", "-uall") && await this.d.recoverySafe?.(r.task_id)) {
            await this.cleanBoundary(w.path);
            await this.effect(r.task_id, w.path, ["add", "-A"]);
            await this.effect(r.task_id, w.path, ["commit", "-m", meta.message, "-m", `WillYou-Intent: ${r.intent_id}`]);
            head = await this.git(w.path, "rev-parse", "HEAD");
            matches = [head];
          }
          if (matches.length !== 1 || await this.git(w.path, "rev-parse", `${matches[0]}^`) !== r.expected_parent) throw new Error("\u63D0\u4EA4\u610F\u56FE\u65E0\u6CD5\u552F\u4E00\u5BF9\u5E94\u5230\u9884\u671F\u7236\u63D0\u4EA4\u7684\u771F\u5B9E\u63D0\u4EA4");
          this.d.store.tx(() => {
            this.d.store.sqlite.prepare("INSERT OR IGNORE INTO agent_commit_provenance(commit_sha,workspace_id,attempt_id,intent_id,kind,message,created_at) VALUES(?,?,?,?,?,?,?)").run(matches[0], w.workspace_id, meta.attemptId ?? null, r.intent_id, meta.kind, meta.message, at());
            this.finish(r.intent_id, "done", { head: matches[0], recovered: true });
          });
        }
      } catch (e) {
        this.finish(r.intent_id, "needs_review", { error: e.message });
      }
    }
  }
  async removeRegistered(workspaceId) {
    const w = this.d.store.sqlite.prepare("SELECT * FROM agent_workspaces WHERE workspace_id=?").get(workspaceId);
    const root = resolve(this.d.home, ".willyou/worktrees");
    if (!w || w.kind !== "git_worktree" || !inside(root, w.path) || !existsSync(w.path) || lstatSync(w.path).isSymbolicLink() || !inside(realpathSync3(root), realpathSync3(w.path))) throw new DriverError("REJECTED", "\u4EC5\u6E05\u7406\u767B\u8BB0\u6839\u5185\u7684\u5DF2\u767B\u8BB0\u5DE5\u4F5C\u526F\u672C");
    const list = await this.git(w.repo_root, "worktree", "list", "--porcelain");
    if (!list.split("\n\n").some((s) => s.includes(`worktree ${w.path}
`) && s.includes(`branch refs/heads/${w.branch}`))) throw new DriverError("STATE", "Git \u767B\u8BB0\u4E0E\u5DE5\u4F5C\u526F\u672C\u4E0D\u7B26\uFF0C\u672A\u6E05\u7406");
    if (await this.git(w.path, "merge-base", w.base_commit, "HEAD") !== w.base_commit) throw new DriverError("STATE", "\u5DE5\u4F5C\u526F\u672C\u57FA\u51C6\u5DF2\u53D8\u5316\uFF0C\u672A\u6E05\u7406");
    await this.effect(w.child_task_id ?? w.task_id, w.repo_root, ["worktree", "remove", w.path]);
    this.d.store.sqlite.prepare("UPDATE agent_workspaces SET state='archived',updated_at=? WHERE workspace_id=?").run(at(), workspaceId);
  }
};

// ../baseline/src/main/db/migrations.ts
import { createHash as createHash2 } from "node:crypto";

// ../baseline/drizzle/meta/_journal.json
var journal_default = {
  version: "7",
  dialect: "sqlite",
  entries: [
    {
      idx: 0,
      version: "6",
      when: 1791978722839,
      tag: "0000_init",
      breakpoints: true
    },
    {
      idx: 1,
      version: "6",
      when: 1791988005282,
      tag: "0001_projects",
      breakpoints: true
    },
    {
      idx: 2,
      version: "6",
      when: 1791992183018,
      tag: "0002_tasks",
      breakpoints: true
    },
    {
      idx: 3,
      version: "6",
      when: 1792026072572,
      tag: "0003_ai_profile_check",
      breakpoints: true
    },
    {
      idx: 4,
      version: "6",
      when: 1792035171435,
      tag: "0004_capabilities",
      breakpoints: true
    },
    {
      idx: 5,
      version: "6",
      when: 179214e7,
      tag: "0005_project_transfer",
      breakpoints: true
    },
    {
      idx: 6,
      version: "6",
      when: 1792461246e3,
      tag: "0006_application_packages",
      breakpoints: true
    },
    {
      idx: 7,
      version: "6",
      when: 17924624e5,
      tag: "0007_application_connections",
      breakpoints: true
    },
    {
      idx: 8,
      version: "6",
      when: 1792464e6,
      tag: "0008_mail_drafts",
      breakpoints: true
    },
    {
      idx: 9,
      version: "6",
      when: 17924646e5,
      tag: "0009_mail_execution",
      breakpoints: true
    },
    {
      idx: 10,
      version: "6",
      when: 17924658e5,
      tag: "0010_capability_session_identity",
      breakpoints: true
    },
    {
      idx: 11,
      version: "6",
      when: 17924664e5,
      tag: "0011_capability_run_lifecycle",
      breakpoints: true
    },
    {
      idx: 12,
      version: "6",
      when: 1792467e6,
      tag: "0012_application_invocations",
      breakpoints: true
    },
    {
      idx: 13,
      version: "6",
      when: 17924676e5,
      tag: "0013_agent_adapters",
      breakpoints: true
    },
    {
      idx: 14,
      version: "6",
      when: 17924682e5,
      tag: "0014_discovery_catalog",
      breakpoints: true
    },
    {
      idx: 15,
      version: "6",
      when: 17924688e5,
      tag: "0015_builtin_package_sources",
      breakpoints: true
    },
    {
      idx: 16,
      version: "6",
      when: 17924694e5,
      tag: "0016_application_data_operations",
      breakpoints: true
    },
    {
      idx: 17,
      version: "6",
      when: 179247e7,
      tag: "0017_zentao_business_reads",
      breakpoints: true
    },
    {
      idx: 18,
      version: "6",
      when: 17924706e5,
      tag: "0018_mail_index_provenance",
      breakpoints: true
    },
    {
      idx: 19,
      version: "6",
      when: 17924712e5,
      tag: "0019_mail_user_action_sources",
      breakpoints: true
    },
    {
      idx: 20,
      version: "6",
      when: 17924988e5,
      tag: "0020_application_activity_subjects",
      breakpoints: true
    },
    {
      idx: 21,
      version: "6",
      when: 1792506e6,
      tag: "0021_capability_run_evidence",
      breakpoints: true
    },
    {
      idx: 22,
      version: "6",
      when: 1792521e6,
      tag: "0022_legacy_task_migration_preparations",
      breakpoints: true
    },
    {
      idx: 23,
      version: "6",
      when: 17925462e5,
      tag: "0023_capability_run_restrictions",
      breakpoints: true
    },
    {
      idx: 24,
      version: "6",
      when: 1792563e6,
      tag: "0024_native_history_observation",
      breakpoints: true
    },
    {
      idx: 25,
      version: "6",
      when: 179257104e4,
      tag: "0025_legacy_h_bindings",
      breakpoints: true
    },
    {
      idx: 26,
      version: "6",
      when: 17927442e5,
      tag: "0026_registered_application_hosts",
      breakpoints: true
    },
    {
      idx: 27,
      version: "6",
      when: 1792782e6,
      tag: "0027_capability_skill_observations",
      breakpoints: true
    },
    {
      idx: 28,
      version: "6",
      when: 17927856e5,
      tag: "0028_capability_broker_denials",
      breakpoints: true
    },
    {
      idx: 29,
      version: "6",
      when: 1793507771201,
      tag: "0029_mail_sender_identity",
      breakpoints: true
    },
    {
      idx: 30,
      version: "6",
      when: 17936976e5,
      tag: "0030_browser_operations",
      breakpoints: true
    },
    {
      idx: 31,
      version: "6",
      when: 17944056e5,
      tag: "0031_external_plugins",
      breakpoints: true
    },
    {
      idx: 32,
      version: "6",
      when: 17944866e5,
      tag: "0032_ai_agent_entities",
      breakpoints: true
    },
    {
      idx: 33,
      version: "6",
      when: 1794504470040,
      tag: "0033_ai_provider_key_hint",
      breakpoints: true
    },
    {
      idx: 34,
      version: "6",
      when: 1794514149956,
      tag: "0034_capability_registry",
      breakpoints: true
    },
    {
      idx: 35,
      version: "6",
      when: 1794530333205,
      tag: "0035_builtin_plugin_preferences",
      breakpoints: true
    },
    {
      idx: 36,
      version: "6",
      when: 1794588171092,
      tag: "0036_connection_history_retention",
      breakpoints: true
    },
    {
      idx: 37,
      version: "6",
      when: 17946e8,
      tag: "0037_agent_workspace",
      breakpoints: true
    },
    {
      idx: 38,
      version: "6",
      when: 179496e7,
      tag: "0038_agent_resource_cleanup",
      breakpoints: true
    },
    {
      idx: 39,
      version: "6",
      when: 17953056e5,
      tag: "0039_agent_task_pin",
      breakpoints: true
    }
  ]
};

// ../baseline/src/main/db/migrations.ts
var sqlFiles = { "/drizzle/0000_init.sql": "-- Hand-edited: IF NOT EXISTS lets this migration adopt databases created by M0 (no migration table).\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `app_secrets` (\n	`key` text PRIMARY KEY NOT NULL,\n	`secret` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `app_settings` (\n	`key` text PRIMARY KEY NOT NULL,\n	`value` text NOT NULL,\n	`updated_at` integer DEFAULT (unixepoch() * 1000) NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `sessions` (\n	`id` text PRIMARY KEY NOT NULL,\n	`runner` text NOT NULL,\n	`cwd` text NOT NULL,\n	`native_session_id` text,\n	`title` text NOT NULL,\n	`created_at` integer NOT NULL\n);\n", "/drizzle/0001_projects.sql": "-- Hand-edited: IF NOT EXISTS keeps the migration safe to re-run (project rule: migrations must be idempotent).\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `project_databases` (\n	`id` text PRIMARY KEY NOT NULL,\n	`project_id` text NOT NULL,\n	`env` text NOT NULL,\n	`label` text DEFAULT '' NOT NULL,\n	`aliases` text DEFAULT '[]' NOT NULL,\n	`vendor` text NOT NULL,\n	`host` text NOT NULL,\n	`port` integer NOT NULL,\n	`database` text DEFAULT '' NOT NULL,\n	`schema` text,\n	`username` text DEFAULT '' NOT NULL,\n	`access_level` text DEFAULT 'readonly' NOT NULL,\n	`is_default` integer DEFAULT false NOT NULL,\n	`note` text DEFAULT '' NOT NULL,\n	`last_test_at` integer,\n	`last_test_ok` integer,\n	`last_test_category` text,\n	`last_test_message` text,\n	`last_test_ms` integer,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL,\n	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `project_dirs` (\n	`id` text PRIMARY KEY NOT NULL,\n	`project_id` text NOT NULL,\n	`label` text DEFAULT '' NOT NULL,\n	`path` text NOT NULL,\n	`is_default` integer DEFAULT false NOT NULL,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL,\n	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `project_servers` (\n	`id` text PRIMARY KEY NOT NULL,\n	`project_id` text NOT NULL,\n	`env` text NOT NULL,\n	`label` text DEFAULT '' NOT NULL,\n	`aliases` text DEFAULT '[]' NOT NULL,\n	`host` text NOT NULL,\n	`port` integer DEFAULT 22 NOT NULL,\n	`username` text NOT NULL,\n	`auth_type` text NOT NULL,\n	`private_key_path` text,\n	`default_root` integer DEFAULT false NOT NULL,\n	`sudo_policy` text DEFAULT 'none' NOT NULL,\n	`app_root` text,\n	`logs_path` text,\n	`note` text DEFAULT '' NOT NULL,\n	`last_test_at` integer,\n	`last_test_ok` integer,\n	`last_test_category` text,\n	`last_test_message` text,\n	`last_test_ms` integer,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL,\n	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `projects` (\n	`id` text PRIMARY KEY NOT NULL,\n	`name` text NOT NULL,\n	`aliases` text DEFAULT '[]' NOT NULL,\n	`description` text DEFAULT '' NOT NULL,\n	`rules_path` text,\n	`config_version` integer DEFAULT 1 NOT NULL,\n	`archived_at` integer,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `project_databases_project_idx` ON `project_databases` (`project_id`);--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `project_dirs_project_idx` ON `project_dirs` (`project_id`);--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `project_servers_project_idx` ON `project_servers` (`project_id`);", "/drizzle/0002_tasks.sql": "-- Hand-edited: IF NOT EXISTS / INSERT OR IGNORE keep the migration safe to re-run (project rule: migrations must be idempotent).\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `ai_profiles` (\n	`id` text PRIMARY KEY NOT NULL,\n	`name` text NOT NULL,\n	`runner` text NOT NULL,\n	`executable` text,\n	`env` text DEFAULT '[]' NOT NULL,\n	`args` text DEFAULT '[]' NOT NULL,\n	`color` text,\n	`is_default` integer DEFAULT false NOT NULL,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `tasks` (\n	`id` text PRIMARY KEY NOT NULL,\n	`project_id` text,\n	`dir_id` text,\n	`cwd` text NOT NULL,\n	`ai_profile_id` text,\n	`ai_profile_name` text,\n	`runner` text NOT NULL,\n	`native_session_id` text,\n	`title` text NOT NULL,\n	`first_message` text DEFAULT '' NOT NULL,\n	`injected_env_names` text DEFAULT '[]' NOT NULL,\n	`config_version` integer,\n	`state_root` text,\n	`archived_at` integer,\n	`last_launched_at` integer,\n	`created_at` integer NOT NULL,\n	`updated_at` integer NOT NULL,\n	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade,\n	FOREIGN KEY (`dir_id`) REFERENCES `project_dirs`(`id`) ON UPDATE no action ON DELETE set null,\n	FOREIGN KEY (`ai_profile_id`) REFERENCES `ai_profiles`(`id`) ON UPDATE no action ON DELETE set null\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `tasks_project_idx` ON `tasks` (`project_id`);\n--> statement-breakpoint\n-- M0/M1 sessions become tasks without a project; the old table is kept untouched.\nINSERT OR IGNORE INTO `tasks` (`id`, `cwd`, `runner`, `native_session_id`, `title`, `created_at`, `updated_at`, `last_launched_at`)\nSELECT `id`, `cwd`, `runner`, `native_session_id`, `title`, `created_at`, `created_at`, `created_at` FROM `sessions`;\n", "/drizzle/0003_ai_profile_check.sql": "ALTER TABLE `ai_profiles` ADD `check_status` text;--> statement-breakpoint\nALTER TABLE `ai_profiles` ADD `check_category` text;--> statement-breakpoint\nALTER TABLE `ai_profiles` ADD `check_source` text;--> statement-breakpoint\nALTER TABLE `ai_profiles` ADD `check_message` text;--> statement-breakpoint\nALTER TABLE `ai_profiles` ADD `check_ms` integer;--> statement-breakpoint\nALTER TABLE `ai_profiles` ADD `check_at` integer;", "/drizzle/0004_capabilities.sql": "CREATE TABLE IF NOT EXISTS `project_capabilities` (\n	`id` text PRIMARY KEY NOT NULL,\n	`project_id` text NOT NULL,\n	`capability_id` text NOT NULL,\n	`enabled` integer DEFAULT true NOT NULL,\n	FOREIGN KEY (`project_id`) REFERENCES `projects`(`id`) ON UPDATE no action ON DELETE cascade\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `skill_versions` (\n	`id` text PRIMARY KEY NOT NULL,\n	`skill_id` text NOT NULL,\n	`name` text NOT NULL,\n	`version` text NOT NULL,\n	`hash` text NOT NULL,\n	`installed_at` integer NOT NULL,\n	`active` integer DEFAULT false NOT NULL\n);\n--> statement-breakpoint\nALTER TABLE `tasks` ADD `runtime_snapshot` text;\n", "/drizzle/0005_project_transfer.sql": "ALTER TABLE `ai_profiles` ADD `command_pending` integer DEFAULT false NOT NULL;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `project_import_receipts` (\n  `request_id` text PRIMARY KEY NOT NULL,\n  `fingerprint` text NOT NULL,\n  `result` text NOT NULL,\n  `created_at` integer NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `imported_keys` (\n  `server_id` text PRIMARY KEY NOT NULL,\n  `path` text NOT NULL,\n  `created_at` integer NOT NULL\n);\n", "/drizzle/0006_application_packages.sql": "CREATE TABLE IF NOT EXISTS `capability_resources` (\n  `resource_id` text PRIMARY KEY NOT NULL,\n  `kind` text NOT NULL,\n  `content_hash` text NOT NULL,\n  `owner_store_id` text NOT NULL,\n  `path_scope` text NOT NULL CHECK (`path_scope` IN ('C','H')),\n  `relative_path` text NOT NULL,\n  `state` text NOT NULL CHECK (`state` IN ('staged','verified','ready','deleting','removed','recovery-required')),\n  `generation` integer NOT NULL DEFAULT 1,\n  `integrity` text NOT NULL CHECK (`integrity` IN ('unknown','valid','invalid')),\n  `operation_id` text,\n  UNIQUE (`owner_store_id`,`path_scope`,`relative_path`)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_resource_dependencies` (\n  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),\n  `dependency_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),\n  PRIMARY KEY (`resource_id`,`dependency_id`),\n  CHECK (`resource_id` <> `dependency_id`)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_resource_leases` (\n  `lease_id` text PRIMARY KEY NOT NULL,\n  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),\n  `owner_kind` text NOT NULL,\n  `owner_id` text NOT NULL,\n  `host_instance_id` text NOT NULL,\n  `pid` integer,\n  `process_started_at` text,\n  `state` text NOT NULL CHECK (`state` IN ('preparing','active','releasing','released','recovery-required')),\n  `created_at` text NOT NULL,\n  `ended_at` text\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `capability_resource_leases_resource_idx` ON `capability_resource_leases` (`resource_id`,`state`);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_resource_operations` (\n  `operation_id` text PRIMARY KEY NOT NULL,\n  `kind` text NOT NULL,\n  `owner_store_id` text NOT NULL,\n  `state` text NOT NULL,\n  `plan_json` text NOT NULL,\n  `error_code` text,\n  `created_at` text NOT NULL,\n  `updated_at` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_packages` (\n  `package_hash` text PRIMARY KEY NOT NULL,\n  `app_id` text NOT NULL,\n  `version` text NOT NULL,\n  `hash_algorithm` text NOT NULL CHECK (`hash_algorithm` = 'app-manifest-v1'),\n  `relative_path` text NOT NULL,\n  `manifest_json` text NOT NULL,\n  `resource_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),\n  `installed_at` text NOT NULL,\n  UNIQUE (`app_id`,`version`)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_active_packages` (\n  `app_id` text PRIMARY KEY NOT NULL,\n  `package_hash` text NOT NULL REFERENCES `capability_packages` (`package_hash`),\n  `activation_generation` integer NOT NULL,\n  `activated_at` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_install_journal` (\n  `install_id` text PRIMARY KEY NOT NULL REFERENCES `capability_resource_operations` (`operation_id`),\n  `host_build` text NOT NULL,\n  `from_generation` integer,\n  `to_generation` integer,\n  `state` text NOT NULL,\n  `plan_json` text NOT NULL,\n  `backup_path` text,\n  `error_code` text,\n  `updated_at` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_session_snapshots` (\n  `task_id` text PRIMARY KEY NOT NULL,\n  `schema_version` integer NOT NULL,\n  `snapshot_json` text NOT NULL,\n  `snapshot_hash` text NOT NULL,\n  `created_at` text NOT NULL,\n  `legacy_status` text NOT NULL,\n  `retention_state` text NOT NULL CHECK (`retention_state` IN ('active','tombstone','hold'))\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_session_refs` (\n  `task_id` text NOT NULL REFERENCES `capability_session_snapshots` (`task_id`),\n  `ref_kind` text NOT NULL,\n  `ref_id` text NOT NULL REFERENCES `capability_resources` (`resource_id`),\n  `ref_hash` text NOT NULL,\n  `relative_path` text NOT NULL,\n  PRIMARY KEY (`task_id`,`ref_kind`,`ref_id`)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `capability_session_refs_resource_idx` ON `capability_session_refs` (`ref_id`);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_runs` (\n  `run_id` text PRIMARY KEY NOT NULL,\n  `task_id` text NOT NULL REFERENCES `capability_session_snapshots` (`task_id`),\n  `project_id` text NOT NULL REFERENCES `projects` (`id`),\n  `runner` text NOT NULL,\n  `pid` integer,\n  `process_started_at` text,\n  `state` text NOT NULL,\n  `started_at` text NOT NULL,\n  `ended_at` text,\n  `error_code` text\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `capability_schema_migrations` (\n  `app_id` text NOT NULL,\n  `migration_id` text NOT NULL,\n  `checksum` text NOT NULL,\n  `from_version` integer NOT NULL,\n  `to_version` integer NOT NULL,\n  `applied_at` text NOT NULL,\n  `host_build` text NOT NULL,\n  PRIMARY KEY (`app_id`,`migration_id`)\n);\n", "/drizzle/0007_application_connections.sql": "CREATE TABLE IF NOT EXISTS `application_connections` (\n  `id` text PRIMARY KEY NOT NULL,\n  `app_id` text NOT NULL CHECK (`app_id` IN ('zentao','mail')),\n  `provider_id` text NOT NULL CHECK (`provider_id` IN ('zentao','foxmail','smtp')),\n  `name` text NOT NULL,\n  `config_schema_version` integer NOT NULL DEFAULT 1,\n  `config_json` text NOT NULL,\n  `revision` integer NOT NULL,\n  `config_revision` integer NOT NULL,\n  `identity_revision` integer NOT NULL,\n  `verified_identity_json` text NOT NULL,\n  `identity_hash` text NOT NULL,\n  `secret_ref` text,\n  `secret_revision` integer NOT NULL,\n  `policy_revision` integer NOT NULL,\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `auth_state` text NOT NULL CHECK (`auth_state` IN ('connected','disconnected')),\n  `health` text NOT NULL CHECK (`health` IN ('unverified','healthy','unavailable')),\n  `health_code` text,\n  `health_message` text,\n  `tested_at` text,\n  `cleanup_pending` integer NOT NULL DEFAULT 0 CHECK (`cleanup_pending` IN (0,1)),\n  `created_at` text NOT NULL,\n  `updated_at` text NOT NULL,\n  CHECK ((`provider_id`='zentao' AND `app_id`='zentao') OR (`provider_id` IN ('foxmail','smtp') AND `app_id`='mail'))\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS `application_connections_provider_idx` ON `application_connections` (`provider_id`,`app_id`);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS `application_connections_identity_key` ON `application_connections` (`id`,`provider_id`,`app_id`);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_secret_changes` (\n  `operation_id` text PRIMARY KEY NOT NULL,\n  `connection_id` text NOT NULL,\n  `expected_revision` integer NOT NULL,\n  `old_secret_ref` text,\n  `new_secret_ref` text,\n  `candidate_hash` text NOT NULL,\n  `candidate_json` text NOT NULL,\n  `verified_identity_json` text,\n  `compatibility_plan_json` text,\n  `expires_at` text NOT NULL,\n  `state` text NOT NULL CHECK (`state` IN ('preparing','validated','committed','cleanup-pending','failed','cleaned')),\n  `error_code` text,\n  `created_at` text NOT NULL,\n  `updated_at` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_catalog_state` (\n  `app_id` text PRIMARY KEY NOT NULL CHECK (`app_id` IN ('zentao','mail')),\n  `added` integer NOT NULL CHECK (`added` IN (0,1)),\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `revision` integer NOT NULL,\n  `updated_at` text NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_project_settings` (\n  `project_id` text NOT NULL REFERENCES `projects` (`id`) ON DELETE CASCADE,\n  `app_id` text NOT NULL CHECK (`app_id` IN ('zentao','mail')),\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `binding_revision` integer NOT NULL,\n  `pending_operation_id` text,\n  `updated_at` text NOT NULL,\n  PRIMARY KEY (`project_id`,`app_id`)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_project_bindings` (\n  `project_id` text NOT NULL,\n  `app_id` text NOT NULL,\n  `slot` text NOT NULL CHECK (`slot` IN ('zentao','foxmail','smtp')),\n  `connection_id` text NOT NULL,\n  `identity_revision` integer NOT NULL,\n  PRIMARY KEY (`project_id`,`app_id`,`slot`),\n  FOREIGN KEY (`connection_id`,`slot`,`app_id`) REFERENCES `application_connections` (`id`,`provider_id`,`app_id`),\n  FOREIGN KEY (`project_id`,`app_id`) REFERENCES `application_project_settings` (`project_id`,`app_id`) ON DELETE CASCADE,\n  CHECK ((`app_id`='zentao' AND `slot`='zentao') OR (`app_id`='mail' AND `slot` IN ('foxmail','smtp')))\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_binding_changes` (\n  `operation_id` text PRIMARY KEY NOT NULL,\n  `project_id` text NOT NULL,\n  `app_id` text NOT NULL,\n  `from_revision` integer NOT NULL,\n  `to_revision` integer,\n  `previous_json` text NOT NULL,\n  `next_json` text NOT NULL,\n  `state` text NOT NULL,\n  `error_code` text,\n  `created_at` text NOT NULL,\n  `updated_at` text NOT NULL\n);\n", "/drizzle/0008_mail_drafts.sql": "CREATE TABLE IF NOT EXISTS mail_blob_objects (\n  content_hash TEXT PRIMARY KEY NOT NULL,\n  byte_size INTEGER NOT NULL CHECK(byte_size >= 0),\n  created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_attachment_objects (\n  id TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  content_hash TEXT NOT NULL REFERENCES mail_blob_objects(content_hash) ON DELETE RESTRICT,\n  filename TEXT NOT NULL,\n  content_type TEXT NOT NULL,\n  byte_size INTEGER NOT NULL CHECK(byte_size >= 0),\n  created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_blob_writes (\n  operation_id TEXT PRIMARY KEY NOT NULL,\n  attachment_id TEXT NOT NULL,\n  project_id TEXT NOT NULL,\n  request_hash TEXT NOT NULL,\n  metadata_json TEXT NOT NULL,\n  state TEXT NOT NULL CHECK(state IN ('preparing','staged','published','committed','failed')),\n  error_code TEXT,\n  cleanup_pending INTEGER NOT NULL DEFAULT 0 CHECK(cleanup_pending IN (0,1)),\n  created_at TEXT NOT NULL,\n  updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_drafts (\n  id TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  source_task_id TEXT,\n  copied_from_draft_id TEXT REFERENCES mail_drafts(id) ON DELETE RESTRICT,\n  subject TEXT NOT NULL,\n  attachment_count INTEGER NOT NULL CHECK(attachment_count >= 0),\n  current_revision INTEGER NOT NULL CHECK(current_revision >= 1),\n  state TEXT NOT NULL CHECK(state IN ('draft','sending','sent','failed','unknown')),\n  active_intent_id TEXT,\n  last_execution_id TEXT,\n  created_at TEXT NOT NULL,\n  updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS mail_drafts_project_updated ON mail_drafts(project_id,updated_at,id);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_draft_revisions (\n  draft_id TEXT NOT NULL REFERENCES mail_drafts(id) ON DELETE RESTRICT,\n  revision INTEGER NOT NULL CHECK(revision >= 1),\n  content_json TEXT NOT NULL,\n  content_hash TEXT NOT NULL,\n  actor_task_id TEXT,\n  created_at TEXT NOT NULL,\n  PRIMARY KEY(draft_id,revision)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_draft_mutations (\n  project_id TEXT NOT NULL,\n  operation_id TEXT NOT NULL,\n  request_hash TEXT NOT NULL,\n  draft_id TEXT NOT NULL REFERENCES mail_drafts(id) ON DELETE RESTRICT,\n  result_json TEXT NOT NULL,\n  created_at TEXT NOT NULL,\n  PRIMARY KEY(project_id,operation_id)\n);\n", "/drizzle/0009_mail_execution.sql": "ALTER TABLE mail_attachment_objects ADD COLUMN kind TEXT NOT NULL DEFAULT 'attachment' CHECK(kind IN ('attachment','message'));\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_send_intents (\n  id TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  source_task_id TEXT,\n  source_run_id TEXT,\n  operation_id TEXT NOT NULL,\n  request_hash TEXT NOT NULL,\n  draft_id TEXT NOT NULL,\n  draft_revision INTEGER NOT NULL,\n  draft_content_hash TEXT NOT NULL,\n  connection_id TEXT NOT NULL REFERENCES application_connections(id) ON DELETE RESTRICT,\n  identity_revision INTEGER NOT NULL,\n  config_revision INTEGER NOT NULL,\n  policy_revision INTEGER NOT NULL,\n  binding_revision INTEGER NOT NULL,\n  identity_json TEXT NOT NULL,\n  smtp_config_json TEXT NOT NULL,\n  raw_write_id TEXT NOT NULL,\n  raw_object_id TEXT REFERENCES mail_attachment_objects(id) ON DELETE RESTRICT,\n  raw_hash TEXT,\n  frozen_hash TEXT,\n  envelope_json TEXT,\n  message_id TEXT NOT NULL,\n  review_json TEXT,\n  review_hash TEXT,\n  state TEXT NOT NULL CHECK(state IN ('preparing','awaiting-authorization','authorized','executing','server-accepted','failed','unknown','canceled','stale')),\n  grant_id TEXT,\n  execution_id TEXT,\n  cancel_requested_at TEXT,\n  owner_instance_id TEXT NOT NULL,\n  owner_pid INTEGER NOT NULL,\n  owner_started_at TEXT NOT NULL,\n  error_code TEXT,\n  created_at TEXT NOT NULL,\n  updated_at TEXT NOT NULL,\n  UNIQUE(project_id,operation_id),\n  FOREIGN KEY(draft_id,draft_revision) REFERENCES mail_draft_revisions(draft_id,revision) ON DELETE RESTRICT\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS mail_send_intents_project_updated ON mail_send_intents(project_id,updated_at,id);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_send_grants (\n  id TEXT PRIMARY KEY NOT NULL,\n  intent_id TEXT NOT NULL REFERENCES mail_send_intents(id) ON DELETE RESTRICT,\n  source TEXT NOT NULL CHECK(source IN ('renderer-confirmation','native-user-message')),\n  evidence_id TEXT NOT NULL,\n  evidence_hash TEXT NOT NULL,\n  review_hash TEXT NOT NULL,\n  evidence_json TEXT NOT NULL,\n  state TEXT NOT NULL CHECK(state IN ('active','used','revoked')),\n  expires_at TEXT NOT NULL,\n  created_at TEXT NOT NULL,\n  UNIQUE(source,evidence_id)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_send_executions (\n  id TEXT PRIMARY KEY NOT NULL,\n  intent_id TEXT NOT NULL UNIQUE REFERENCES mail_send_intents(id) ON DELETE RESTRICT,\n  project_id TEXT NOT NULL,\n  draft_id TEXT NOT NULL,\n  draft_revision INTEGER NOT NULL,\n  review_hash TEXT NOT NULL,\n  state TEXT NOT NULL CHECK(state IN ('executing','server-accepted','failed','unknown')),\n  result_json TEXT,\n  secret_revision INTEGER NOT NULL,\n  owner_instance_id TEXT NOT NULL,\n  started_at TEXT NOT NULL,\n  ended_at TEXT,\n  UNIQUE(draft_id,draft_revision)\n);\n\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_binding_slot_revisions (\n  project_id TEXT NOT NULL,\n  app_id TEXT NOT NULL,\n  slot TEXT NOT NULL,\n  revision INTEGER NOT NULL CHECK(revision >= 0),\n  PRIMARY KEY(project_id,app_id,slot),\n  FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE,\n  CHECK((app_id='zentao' AND slot='zentao') OR (app_id='mail' AND slot IN ('foxmail','smtp')))\n);\n--> statement-breakpoint\nINSERT OR IGNORE INTO application_binding_slot_revisions(project_id,app_id,slot,revision)\nSELECT project_id,app_id,'zentao',binding_revision FROM application_project_settings WHERE app_id='zentao'\nUNION ALL SELECT project_id,app_id,'foxmail',binding_revision FROM application_project_settings WHERE app_id='mail'\nUNION ALL SELECT project_id,app_id,'smtp',binding_revision FROM application_project_settings WHERE app_id='mail';\n", "/drizzle/0010_capability_session_identity.sql": "CREATE TABLE IF NOT EXISTS capability_session_identities (\n  task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,\n  runner TEXT NOT NULL,\n  identity_root TEXT NOT NULL,\n  session_id TEXT,\n  cwd TEXT NOT NULL,\n  discovery_home TEXT NOT NULL,\n  selection_hash TEXT NOT NULL,\n  created_at TEXT NOT NULL,\n  updated_at TEXT NOT NULL,\n  UNIQUE(runner,identity_root,session_id)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_session_mcp_names (\n  server_name TEXT PRIMARY KEY NOT NULL,\n  task_id TEXT NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,\n  kind TEXT NOT NULL,\n  UNIQUE(task_id,kind)\n);\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN snapshot_hash TEXT;\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN owner_instance_id TEXT;\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN owner_pid INTEGER;\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN owner_started_at TEXT;\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN bindings_json TEXT NOT NULL DEFAULT '[]';\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN pty_id TEXT;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_snapshot_versions (\n  snapshot_hash TEXT PRIMARY KEY NOT NULL,\n  task_id TEXT NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,\n  snapshot_json TEXT NOT NULL,\n  selection_hash TEXT NOT NULL,\n  created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_session_holds (\n  task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,\n  previous_retention TEXT NOT NULL CHECK(previous_retention IN ('active','tombstone','hold')),\n  reason TEXT NOT NULL,\n  created_at TEXT NOT NULL\n);\n--> statement-breakpoint\n-- @smartdd-rebuild-if-foreign-key capability_runs project_id\nCREATE TABLE capability_runs_retained (\n  run_id TEXT PRIMARY KEY NOT NULL,\n  task_id TEXT NOT NULL REFERENCES capability_session_snapshots(task_id) ON DELETE RESTRICT,\n  project_id TEXT NOT NULL,\n  runner TEXT NOT NULL,\n  pid INTEGER,\n  process_started_at TEXT,\n  state TEXT NOT NULL,\n  started_at TEXT NOT NULL,\n  ended_at TEXT,\n  error_code TEXT,\n  snapshot_hash TEXT,\n  owner_instance_id TEXT,\n  owner_pid INTEGER,\n  owner_started_at TEXT,\n  bindings_json TEXT NOT NULL DEFAULT '[]',\n  pty_id TEXT\n);\nINSERT INTO capability_runs_retained(run_id,task_id,project_id,runner,pid,process_started_at,state,started_at,ended_at,error_code,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id)\nSELECT run_id,task_id,project_id,runner,pid,process_started_at,state,started_at,ended_at,error_code,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id FROM capability_runs;\nDROP TABLE capability_runs;\nALTER TABLE capability_runs_retained RENAME TO capability_runs;\n", "/drizzle/0011_capability_run_lifecycle.sql": "ALTER TABLE capability_runs ADD COLUMN revocation_state TEXT NOT NULL DEFAULT 'open';\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_lease_resources (\n  lease_id TEXT NOT NULL REFERENCES capability_resource_leases(lease_id) ON DELETE RESTRICT,\n  resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id) ON DELETE RESTRICT,\n  content_hash TEXT NOT NULL,\n  generation INTEGER NOT NULL,\n  PRIMARY KEY(lease_id,resource_id)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_run_processes (\n  process_id TEXT PRIMARY KEY NOT NULL,\n  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n  kind TEXT NOT NULL CHECK(kind IN ('cli','bridge')),\n  launch_key TEXT NOT NULL UNIQUE,\n  state TEXT NOT NULL CHECK(state IN ('reserved','armed','active','exited','canceled','unknown')),\n  pid INTEGER,\n  process_started_at TEXT,\n  armed_at TEXT,\n  attached_at TEXT,\n  ended_at TEXT\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS capability_run_processes_run_idx ON capability_run_processes(run_id);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS capability_run_one_cli_idx ON capability_run_processes(run_id) WHERE kind='cli';\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_run_activities (\n  activity_id TEXT PRIMARY KEY NOT NULL,\n  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n  state TEXT NOT NULL CHECK(state IN ('active','finished','owner-stopped')),\n  started_at TEXT NOT NULL,\n  ended_at TEXT\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_store_state (\n  singleton INTEGER PRIMARY KEY NOT NULL CHECK(singleton=1),\n  store_id TEXT NOT NULL,\n  resource_generation INTEGER NOT NULL DEFAULT 1,\n  maintenance_state TEXT NOT NULL CHECK(maintenance_state IN ('ready','pending','recovery-required')),\n  maintenance_operation_id TEXT\n);\n", "/drizzle/0012_application_invocations.sql": "CREATE TABLE IF NOT EXISTS capability_package_contracts (\n  package_hash TEXT NOT NULL REFERENCES capability_packages(package_hash) ON DELETE RESTRICT,\n  tool_name TEXT NOT NULL,\n  input_source TEXT NOT NULL,\n  output_source TEXT NOT NULL,\n  PRIMARY KEY(package_hash,tool_name)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_invocations (\n  operation_id TEXT PRIMARY KEY NOT NULL,\n  run_id TEXT NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n  request_id TEXT NOT NULL,\n  request_hash TEXT NOT NULL,\n  project_id TEXT NOT NULL,\n  task_id TEXT NOT NULL,\n  app_id TEXT NOT NULL,\n  package_hash TEXT NOT NULL,\n  tool_name TEXT NOT NULL,\n  contract_major INTEGER NOT NULL,\n  connection_id TEXT,\n  semantics TEXT NOT NULL CHECK(semantics IN ('read','write')),\n  state TEXT NOT NULL CHECK(state IN ('running','succeeded','failed','unknown')),\n  attempt_count INTEGER NOT NULL DEFAULT 0,\n  error_code TEXT,\n  effect_state TEXT NOT NULL CHECK(effect_state IN ('not-started','read-only','completed','unknown')),\n  started_at TEXT NOT NULL,\n  ended_at TEXT,\n  UNIQUE(run_id,request_id)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS application_invocations_project_idx ON application_invocations(project_id,started_at);\n", "/drizzle/0013_agent_adapters.sql": "CREATE TABLE IF NOT EXISTS capability_agent_adapters (\n  agent_id TEXT NOT NULL,\n  version TEXT NOT NULL,\n  adapter_hash TEXT NOT NULL UNIQUE,\n  resource_id TEXT NOT NULL REFERENCES capability_resources(resource_id) ON DELETE RESTRICT,\n  manifest_json TEXT NOT NULL,\n  PRIMARY KEY(agent_id,version)\n);\n", "/drizzle/0014_discovery_catalog.sql": "-- Preserve the original resource PK/FKs and legacy unique key during this additive migration.\n-- H rows use an unambiguous storage key in relative_path; scope_relative_path is the actual\n-- path relative to the canonical discovery HOME. Existing C rows keep their original path.\n--> statement-breakpoint\nALTER TABLE capability_resources ADD scope_identity TEXT NOT NULL DEFAULT '';\n--> statement-breakpoint\nALTER TABLE capability_resources ADD scope_relative_path TEXT;\n--> statement-breakpoint\nUPDATE capability_resources SET scope_identity=owner_store_id WHERE path_scope='C' AND scope_identity='';\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS capability_resources_discovery_path\n  ON capability_resources(scope_identity,scope_relative_path) WHERE path_scope='H' AND state<>'removed';\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_discovery_roots (\n  home_id TEXT PRIMARY KEY NOT NULL,\n  canonical_home TEXT NOT NULL UNIQUE\n);\n", "/drizzle/0015_builtin_package_sources.sql": "CREATE TABLE IF NOT EXISTS capability_builtin_package_sources (\n  package_hash TEXT NOT NULL REFERENCES capability_packages(package_hash) ON DELETE RESTRICT,\n  source_index_hash TEXT NOT NULL,\n  source_index_json TEXT NOT NULL,\n  approved_at TEXT NOT NULL,\n  PRIMARY KEY(package_hash,source_index_hash)\n);\n", "/drizzle/0016_application_data_operations.sql": "ALTER TABLE application_project_settings ADD COLUMN policy_revision INTEGER NOT NULL DEFAULT 0;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_data_operations (\n  operation_id TEXT PRIMARY KEY NOT NULL,\n  caller_kind TEXT NOT NULL CHECK(caller_kind IN ('ui','agent-run','index-job')),\n  scope_kind TEXT NOT NULL CHECK(scope_kind IN ('project','connection-management','internal-index')),\n  project_id TEXT,\n  task_id TEXT,\n  run_id TEXT,\n  job_id TEXT,\n  parent_operation_id TEXT,\n  app_id TEXT NOT NULL,\n  package_hash TEXT NOT NULL,\n  data_api INTEGER NOT NULL,\n  action TEXT NOT NULL,\n  semantics TEXT NOT NULL CHECK(semantics IN ('read','write')),\n  scope_hash TEXT NOT NULL,\n  targets_json TEXT NOT NULL DEFAULT '[]',\n  attempt_count INTEGER NOT NULL DEFAULT 1,\n  state TEXT NOT NULL CHECK(state IN ('running','succeeded','failed','unknown','cancelled')),\n  error_code TEXT,\n  started_at TEXT NOT NULL,\n  ended_at TEXT,\n  CHECK((caller_kind='agent-run' AND scope_kind='project' AND project_id IS NOT NULL AND task_id IS NOT NULL AND run_id IS NOT NULL AND job_id IS NULL AND parent_operation_id IS NULL)\n    OR (caller_kind='ui' AND ((scope_kind='project' AND project_id IS NOT NULL) OR scope_kind='connection-management') AND task_id IS NULL AND run_id IS NULL AND job_id IS NULL AND parent_operation_id IS NULL)\n    OR (caller_kind='index-job' AND scope_kind='internal-index' AND semantics='read' AND project_id IS NOT NULL AND task_id IS NULL AND run_id IS NULL AND job_id IS NOT NULL AND parent_operation_id IS NOT NULL))\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS application_data_operations_project ON application_data_operations(project_id,started_at);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_data_resources (\n  resource_id TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  app_id TEXT NOT NULL,\n  backing_kind TEXT NOT NULL,\n  object_id TEXT NOT NULL,\n  object_revision TEXT NOT NULL,\n  part TEXT NOT NULL,\n  data_contract_major INTEGER NOT NULL,\n  permission TEXT NOT NULL,\n  content_hash TEXT NOT NULL,\n  byte_size INTEGER NOT NULL CHECK(byte_size>=0),\n  media_type TEXT NOT NULL,\n  minted_package_hash TEXT NOT NULL,\n  minted_operation_id TEXT NOT NULL,\n  created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS application_data_resources_identity ON application_data_resources(project_id,app_id,backing_kind,object_id,object_revision,part,data_contract_major);\n", "/drizzle/0017_zentao_business_reads.sql": "CREATE TABLE IF NOT EXISTS application_zentao_revisions (\n  object_key TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  connection_id TEXT NOT NULL,\n  identity_revision INTEGER NOT NULL,\n  object_kind TEXT NOT NULL CHECK(object_kind IN ('bug','story')),\n  native_id TEXT NOT NULL,\n  content_revision TEXT NOT NULL,\n  representation TEXT NOT NULL CHECK(representation IN ('summary','detail')),\n  payload_json TEXT NOT NULL,\n  fetched_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS application_zentao_revisions_identity ON application_zentao_revisions(project_id,connection_id,identity_revision,object_kind,native_id,content_revision,representation);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_zentao_files (\n  object_key TEXT NOT NULL REFERENCES application_zentao_revisions(object_key),\n  file_id TEXT NOT NULL,\n  content_hash TEXT NOT NULL,\n  bytes BLOB NOT NULL,\n  media_type TEXT NOT NULL,\n  byte_size INTEGER NOT NULL CHECK(byte_size>=0),\n  fetched_at TEXT NOT NULL,\n  PRIMARY KEY(object_key,file_id,content_hash)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_zentao_cursors (\n  cursor_id TEXT PRIMARY KEY NOT NULL,\n  project_id TEXT NOT NULL,\n  target_json TEXT NOT NULL,\n  object_kind TEXT NOT NULL,\n  page_size INTEGER NOT NULL,\n  page_no INTEGER NOT NULL,\n  expected_total INTEGER NOT NULL,\n  seen_json TEXT NOT NULL,\n  expires_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_zentao_operation_objects (\n  operation_id TEXT NOT NULL,\n  object_key TEXT NOT NULL REFERENCES application_zentao_revisions(object_key),\n  PRIMARY KEY(operation_id,object_key)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_read_receipt_checks (\n  check_operation_id TEXT PRIMARY KEY NOT NULL,\n  original_operation_id TEXT NOT NULL,\n  checked_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_zentao_operation_resources (\n  operation_id TEXT PRIMARY KEY NOT NULL,\n  backing_json TEXT NOT NULL\n);\n", "/drizzle/0018_mail_index_provenance.sql": "CREATE TABLE IF NOT EXISTS application_index_waiters (\n  index_operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id),\n  parent_operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id),\n  source_key TEXT NOT NULL,\n  joined_at TEXT NOT NULL,\n  ended_at TEXT,\n  state TEXT NOT NULL CHECK(state IN ('waiting','completed','cancelled','failed')),\n  PRIMARY KEY(index_operation_id,parent_operation_id)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_mail_operation_sources (\n  operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_data_operations(operation_id),\n  source_key TEXT NOT NULL,\n  source_revision TEXT NOT NULL,\n  operation_kind TEXT NOT NULL CHECK(operation_kind IN ('query','read','resource')),\n  provenance_json TEXT NOT NULL,\n  created_at TEXT NOT NULL\n);\n", "/drizzle/0019_mail_user_action_sources.sql": "CREATE TABLE IF NOT EXISTS mail_user_action_sources (\n  evidence_id TEXT PRIMARY KEY NOT NULL,\n  intent_id TEXT NOT NULL REFERENCES mail_send_intents(id),\n  source_kind TEXT NOT NULL CHECK(source_kind IN ('renderer-confirmation','native-user-message')),\n  source_hash TEXT NOT NULL,\n  provenance_json TEXT NOT NULL,\n  created_at TEXT NOT NULL\n);\n", "/drizzle/0020_application_activity_subjects.sql": "-- Host-observed business identities for the activity view. These are metadata,\n-- never credentials, permissions, executable arguments or user authorizations.\nCREATE TABLE IF NOT EXISTS application_activity_subjects (\n operation_id TEXT NOT NULL REFERENCES application_data_operations(operation_id) ON DELETE CASCADE,\n kind TEXT NOT NULL CHECK(kind IN ('connection','mail-send','mail-draft')),\n subject_id TEXT NOT NULL,\n PRIMARY KEY(operation_id,kind,subject_id)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS application_activity_subjects_lookup ON application_activity_subjects(kind,subject_id,operation_id);\n--> statement-breakpoint\n-- Only the original preparation operation has a provable old link. Do not infer\n-- later executes or reads from their arguments, timestamps, or current bindings.\nINSERT OR IGNORE INTO application_activity_subjects(operation_id,kind,subject_id)\n SELECT s.operation_id,'mail-send',s.id FROM mail_send_intents s\n JOIN application_data_operations o ON o.operation_id=s.operation_id AND o.project_id=s.project_id AND o.app_id='mail';\n\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS application_data_operations_activity_time ON application_data_operations(started_at,operation_id);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS application_invocations_activity_time ON application_invocations(started_at,operation_id);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS mail_send_intents_activity_time ON mail_send_intents(created_at,id);\n", "/drizzle/0021_capability_run_evidence.sql": "-- Host observations only. Never credentials, arbitrary argv/configs, model claims,\n-- user messages, or a replacement for application/send execution records.\nCREATE TABLE IF NOT EXISTS capability_run_preparations (\n run_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_runs(run_id),\n evidence_json TEXT NOT NULL,\n evidence_hash TEXT NOT NULL,\n prepared_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_bridge_observations (\n run_id TEXT NOT NULL REFERENCES capability_runs(run_id),\n bridge_id TEXT NOT NULL REFERENCES capability_run_processes(process_id),\n evidence_json TEXT NOT NULL,\n evidence_hash TEXT NOT NULL,\n observed_at TEXT NOT NULL,\n PRIMARY KEY(run_id,bridge_id)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS capability_run_evidence_time ON capability_run_preparations(prepared_at,run_id);\n", "/drizzle/0022_legacy_task_migration_preparations.sql": "-- Preserve original M4 metadata before any schema2 migration or task pointer change.\n-- These records and capability_session_refs survive deletion of the UI task/project.\n-- prepared means verified source retention only, never native discovery or execution.\nCREATE TABLE IF NOT EXISTS capability_legacy_migration_preparations (\n task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_session_snapshots(task_id),\n source_snapshot_json TEXT NOT NULL,\n source_record_json TEXT NOT NULL,\n source_snapshot_hash TEXT NOT NULL,\n source_identity_json TEXT NOT NULL,\n bound_native_session_id TEXT,\n evidence_json TEXT,\n evidence_hash TEXT,\n manifest_json TEXT,\n manifest_hash TEXT,\n state TEXT NOT NULL CHECK(state IN ('held','prepared','migrated')),\n issue_code TEXT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL,\n CHECK((evidence_json IS NULL AND evidence_hash IS NULL AND manifest_json IS NULL AND manifest_hash IS NULL)\n    OR (evidence_json IS NOT NULL AND evidence_hash IS NOT NULL AND manifest_json IS NOT NULL AND manifest_hash IS NOT NULL))\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS capability_legacy_preparation_state ON capability_legacy_migration_preparations(state,task_id);\n", "/drizzle/0023_capability_run_restrictions.sql": "-- A host-only pre-fork narrowing receipt. Preserve the original preparation.\n-- Never store argv, environment values, credentials or model claims here.\nCREATE TABLE IF NOT EXISTS capability_run_restrictions (\n run_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_runs(run_id),\n evidence_json TEXT NOT NULL,\n evidence_hash TEXT NOT NULL,\n restricted_at TEXT NOT NULL\n);\n", "/drizzle/0024_native_history_observation.sql": "ALTER TABLE `tasks` ADD `native_history_observed` integer;\n", "/drizzle/0025_legacy_h_bindings.sql": "ALTER TABLE `capability_legacy_migration_preparations` ADD `h_binding_hash` text;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_legacy_h_bindings (\n task_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_legacy_migration_preparations(task_id),\n binding_json TEXT NOT NULL,\n binding_hash TEXT NOT NULL,\n created_at TEXT NOT NULL\n);\n\n-- Original H aliases are derived without changing immutable S; retain the\n-- anchor and receipt after task deletion. ALTER must stay at its statement start\n-- for the runner's existing column replay guard.\n", "/drizzle/0026_registered_application_hosts.sql": "-- @smartdd-foreign-key-rebuild\n-- Host compiled definitions own these identities; rows alone never enable code.\nCREATE TABLE IF NOT EXISTS application_host_applications (\n app_id TEXT PRIMARY KEY NOT NULL CHECK(length(app_id) BETWEEN 1 AND 64 AND app_id GLOB '[a-z]*' AND app_id NOT GLOB '*[^a-z0-9-]*')\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_host_providers (\n provider_id TEXT PRIMARY KEY NOT NULL CHECK(length(provider_id) BETWEEN 1 AND 64 AND provider_id GLOB '[a-z]*' AND provider_id NOT GLOB '*[^a-z0-9-]*'),\n app_id TEXT NOT NULL REFERENCES application_host_applications(app_id) ON DELETE RESTRICT,\n config_api_major INTEGER NOT NULL CHECK(config_api_major=1),\n UNIQUE(provider_id,app_id)\n);\n--> statement-breakpoint\nINSERT OR IGNORE INTO application_host_applications VALUES('zentao'),('mail');\n--> statement-breakpoint\nINSERT OR IGNORE INTO application_host_providers VALUES('zentao','zentao',1),('foxmail','mail',1),('smtp','mail',1);\n\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_connections_host_next` (\n  `id` text PRIMARY KEY NOT NULL,\n  `app_id` text NOT NULL REFERENCES application_host_applications(app_id),\n  `provider_id` text NOT NULL,\n  `name` text NOT NULL,\n  `config_schema_version` integer NOT NULL DEFAULT 1,\n  `config_json` text NOT NULL,\n  `revision` integer NOT NULL,\n  `config_revision` integer NOT NULL,\n  `identity_revision` integer NOT NULL,\n  `verified_identity_json` text NOT NULL,\n  `identity_hash` text NOT NULL,\n  `secret_ref` text,\n  `secret_revision` integer NOT NULL,\n  `policy_revision` integer NOT NULL,\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `auth_state` text NOT NULL CHECK (`auth_state` IN ('connected','disconnected')),\n  `health` text NOT NULL CHECK (`health` IN ('unverified','healthy','unavailable')),\n  `health_code` text,\n  `health_message` text,\n  `tested_at` text,\n  `cleanup_pending` integer NOT NULL DEFAULT 0 CHECK (`cleanup_pending` IN (0,1)),\n  `created_at` text NOT NULL,\n  `updated_at` text NOT NULL,\n  FOREIGN KEY (`provider_id`,`app_id`) REFERENCES application_host_providers(provider_id,app_id)\n);\n--> statement-breakpoint\nINSERT INTO application_connections_host_next(id,app_id,provider_id,name,config_schema_version,config_json,revision,config_revision,identity_revision,verified_identity_json,identity_hash,secret_ref,secret_revision,policy_revision,enabled,auth_state,health,health_code,health_message,tested_at,cleanup_pending,created_at,updated_at) SELECT id,app_id,provider_id,name,config_schema_version,config_json,revision,config_revision,identity_revision,verified_identity_json,identity_hash,secret_ref,secret_revision,policy_revision,enabled,auth_state,health,health_code,health_message,tested_at,cleanup_pending,created_at,updated_at FROM application_connections;\n--> statement-breakpoint\nDROP TABLE application_connections;\n--> statement-breakpoint\nALTER TABLE application_connections_host_next RENAME TO application_connections;\n--> statement-breakpoint\nCREATE INDEX application_connections_provider_idx ON application_connections(provider_id,app_id);\n--> statement-breakpoint\nCREATE UNIQUE INDEX application_connections_identity_key ON application_connections(id,provider_id,app_id);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_catalog_state_host_next` (\n  `app_id` text PRIMARY KEY NOT NULL REFERENCES application_host_applications(app_id),\n  `added` integer NOT NULL CHECK (`added` IN (0,1)),\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `revision` integer NOT NULL,\n  `updated_at` text NOT NULL\n);\n--> statement-breakpoint\nINSERT INTO application_catalog_state_host_next(app_id,added,enabled,revision,updated_at) SELECT app_id,added,enabled,revision,updated_at FROM application_catalog_state;\n--> statement-breakpoint\nDROP TABLE application_catalog_state;\n--> statement-breakpoint\nALTER TABLE application_catalog_state_host_next RENAME TO application_catalog_state;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_project_settings_host_next` (\n  `project_id` text NOT NULL REFERENCES `projects` (`id`) ON DELETE CASCADE,\n  `app_id` text NOT NULL REFERENCES application_host_applications(app_id),\n  `enabled` integer NOT NULL CHECK (`enabled` IN (0,1)),\n  `binding_revision` integer NOT NULL,\n  `pending_operation_id` text,\n  `updated_at` text NOT NULL,\n  `policy_revision` INTEGER NOT NULL DEFAULT 0,\n  PRIMARY KEY (`project_id`,`app_id`)\n);\n--> statement-breakpoint\nINSERT INTO application_project_settings_host_next(project_id,app_id,enabled,binding_revision,pending_operation_id,updated_at,policy_revision) SELECT project_id,app_id,enabled,binding_revision,pending_operation_id,updated_at,policy_revision FROM application_project_settings;\n--> statement-breakpoint\nDROP TABLE application_project_settings;\n--> statement-breakpoint\nALTER TABLE application_project_settings_host_next RENAME TO application_project_settings;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS `application_project_bindings_host_next` (\n  `project_id` text NOT NULL,\n  `app_id` text NOT NULL,\n  `slot` text NOT NULL,\n  `connection_id` text NOT NULL,\n  `identity_revision` integer NOT NULL,\n  PRIMARY KEY (`project_id`,`app_id`,`slot`),\n  FOREIGN KEY (`connection_id`,`slot`,`app_id`) REFERENCES `application_connections` (`id`,`provider_id`,`app_id`),\n  FOREIGN KEY (`project_id`,`app_id`) REFERENCES `application_project_settings` (`project_id`,`app_id`) ON DELETE CASCADE,\n  FOREIGN KEY (`slot`,`app_id`) REFERENCES application_host_providers(provider_id,app_id)\n);\n--> statement-breakpoint\nINSERT INTO application_project_bindings_host_next(project_id,app_id,slot,connection_id,identity_revision) SELECT project_id,app_id,slot,connection_id,identity_revision FROM application_project_bindings;\n--> statement-breakpoint\nDROP TABLE application_project_bindings;\n--> statement-breakpoint\nALTER TABLE application_project_bindings_host_next RENAME TO application_project_bindings;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS application_binding_slot_revisions_host_next (\n  project_id TEXT NOT NULL,\n  app_id TEXT NOT NULL,\n  slot TEXT NOT NULL,\n  revision INTEGER NOT NULL CHECK(revision >= 0),\n  PRIMARY KEY(project_id,app_id,slot),\n  FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE,\n  FOREIGN KEY(slot,app_id) REFERENCES application_host_providers(provider_id,app_id)\n);\n--> statement-breakpoint\nINSERT INTO application_binding_slot_revisions_host_next SELECT * FROM application_binding_slot_revisions;\n--> statement-breakpoint\nDROP TABLE application_binding_slot_revisions;\n--> statement-breakpoint\nALTER TABLE application_binding_slot_revisions_host_next RENAME TO application_binding_slot_revisions;\n", "/drizzle/0027_capability_skill_observations.sql": "-- Diagnostic metadata only; no Skill bodies, native messages or credentials.\nCREATE TABLE IF NOT EXISTS capability_skill_observations (\n run_id TEXT NOT NULL REFERENCES capability_runs(run_id),\n app_id TEXT NOT NULL,\n skill_id TEXT NOT NULL,\n kind TEXT NOT NULL CHECK(kind IN ('discovery','read')),\n evidence_json TEXT NOT NULL,\n evidence_hash TEXT NOT NULL,\n observed_at TEXT NOT NULL,\n PRIMARY KEY(run_id,app_id,skill_id,kind)\n);\n", "/drizzle/0028_capability_broker_denials.sql": "-- Host-only security metadata. No request bodies, client scope, credentials or paths.\nCREATE TABLE IF NOT EXISTS capability_broker_denials (\n audit_id TEXT PRIMARY KEY NOT NULL,\n host_generation TEXT NOT NULL,\n run_id TEXT,\n bridge_id TEXT,\n method TEXT NOT NULL CHECK(method IN ('unknown','exchange','renew','tools/list','tools/call','cancel')),\n error_code TEXT NOT NULL,\n observed_at TEXT NOT NULL,\n CHECK ((run_id IS NULL AND bridge_id IS NULL) OR (run_id IS NOT NULL AND bridge_id IS NOT NULL))\n);\nCREATE INDEX IF NOT EXISTS capability_broker_denials_run ON capability_broker_denials(run_id,observed_at);\n", "/drizzle/0029_mail_sender_identity.sql": "CREATE TABLE IF NOT EXISTS `mail_sender_confirmations` (\n  `project_id` text PRIMARY KEY NOT NULL,\n  `binding_hash` text NOT NULL,\n  `binding_json` text NOT NULL,\n  `method` text NOT NULL CHECK (`method` IN ('automatic','user')),\n  `receipt_id` text NOT NULL UNIQUE,\n  `sender_id` text,\n  `confirmed_at` text NOT NULL,\n  `record_hash` text NOT NULL\n);\n--> statement-breakpoint\nALTER TABLE `mail_send_intents` ADD `sender_identity_hash` text;\n", "/drizzle/0030_browser_operations.sql": "CREATE TABLE IF NOT EXISTS browser_operations (\n run_id TEXT NOT NULL, request_id TEXT NOT NULL, task_id TEXT NOT NULL, page_id TEXT,\n command TEXT NOT NULL, state TEXT NOT NULL CHECK(state IN ('accepted','running','succeeded','failed','unknown')),\n effect_state TEXT NOT NULL, progress TEXT, summary TEXT, error_code TEXT,\n created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,\n PRIMARY KEY(run_id, request_id)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS browser_operations_created ON browser_operations(created_at);\n", "/drizzle/0031_external_plugins.sql": "CREATE TABLE IF NOT EXISTS plugin_packages (\n package_hash TEXT PRIMARY KEY NOT NULL,\n bundle_hash TEXT NOT NULL,\n app_id TEXT NOT NULL,\n version TEXT NOT NULL,\n relative_path TEXT NOT NULL UNIQUE,\n manifest_json TEXT NOT NULL,\n created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_installations (\n app_id TEXT PRIMARY KEY NOT NULL,\n package_hash TEXT REFERENCES plugin_packages(package_hash) ON DELETE RESTRICT,\n installed INTEGER NOT NULL CHECK(installed IN (0,1)),\n enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),\n revision INTEGER NOT NULL CHECK(revision > 0),\n updated_at TEXT NOT NULL,\n CHECK(installed=1 OR (enabled=0 AND package_hash IS NULL))\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_lifecycle_changes (\n change_id TEXT PRIMARY KEY NOT NULL,\n app_id TEXT NOT NULL,\n kind TEXT NOT NULL CHECK(kind IN ('install','update','uninstall')),\n from_hash TEXT, to_hash TEXT,\n from_revision INTEGER NOT NULL,\n previous_enabled INTEGER NOT NULL CHECK(previous_enabled IN (0,1)),\n state TEXT NOT NULL CHECK(state IN ('preparing','prepared','swapping','committed','rolled-back','recovery-required')),\n payload_json TEXT NOT NULL,\n error_code TEXT,\n host_instance_id TEXT NOT NULL,\n created_at TEXT NOT NULL, updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS plugin_lifecycle_pending ON plugin_lifecycle_changes(app_id)\n WHERE state IN ('preparing','prepared','swapping','recovery-required');\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_runtime_leases (\n lease_id TEXT PRIMARY KEY NOT NULL,\n app_id TEXT NOT NULL,\n package_hash TEXT NOT NULL REFERENCES plugin_packages(package_hash) ON DELETE RESTRICT,\n kind TEXT NOT NULL CHECK(kind IN ('invocation','activation')),\n host_instance_id TEXT NOT NULL,\n host_pid INTEGER NOT NULL,\n host_started_at TEXT NOT NULL,\n pid INTEGER,\n process_started_at TEXT,\n state TEXT NOT NULL CHECK(state IN ('reserved','launching','running','closed')),\n created_at TEXT NOT NULL, ended_at TEXT\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_runtime_health (\n app_id TEXT PRIMARY KEY NOT NULL,\n failures_json TEXT NOT NULL,\n paused INTEGER NOT NULL CHECK(paused IN (0,1)),\n error_code TEXT,\n updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_ui_reads (\n operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_data_operations(operation_id) ON DELETE CASCADE,\n host_instance_id TEXT NOT NULL,\n host_pid INTEGER NOT NULL,\n host_started_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_write_approvals (\n operation_id TEXT PRIMARY KEY NOT NULL REFERENCES application_invocations(operation_id),\n approval_id TEXT NOT NULL UNIQUE,\n run_id TEXT NOT NULL,\n app_id TEXT NOT NULL,\n package_hash TEXT NOT NULL,\n capability TEXT NOT NULL,\n input_hash TEXT NOT NULL,\n review_hash TEXT NOT NULL,\n policy_hash TEXT NOT NULL,\n state TEXT NOT NULL CHECK(state IN ('pending','allowed','denied','cancelled','expired','invalidated')),\n host_instance_id TEXT NOT NULL,\n host_pid INTEGER NOT NULL,\n host_started_at TEXT NOT NULL,\n provenance_json TEXT,\n created_at INTEGER NOT NULL,\n expires_at INTEGER NOT NULL,\n decided_at INTEGER\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_connection_defaults (\n app_id TEXT PRIMARY KEY NOT NULL REFERENCES application_host_applications(app_id),\n connection_id TEXT REFERENCES application_connections(id) ON DELETE RESTRICT,\n revision INTEGER NOT NULL CHECK(revision>=0)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_project_preferences (\n project_id TEXT NOT NULL,\n app_id TEXT NOT NULL,\n mode TEXT NOT NULL CHECK(mode IN ('follow','individual')),\n PRIMARY KEY(project_id,app_id),\n FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS plugin_builtin_migrations (\n app_id TEXT PRIMARY KEY NOT NULL,\n migration_version INTEGER NOT NULL CHECK(migration_version>0),\n package_hash TEXT NOT NULL,\n source_hash TEXT NOT NULL,\n tables_json TEXT NOT NULL,\n completed_at TEXT NOT NULL\n);\n", "/drizzle/0032_ai_agent_entities.sql": "CREATE TABLE IF NOT EXISTS ai_tools (\n  id TEXT PRIMARY KEY NOT NULL,\n  kind TEXT NOT NULL,\n  executable TEXT NOT NULL,\n  custom_path TEXT,\n  version TEXT,\n  installed INTEGER NOT NULL DEFAULT 0,\n  login TEXT NOT NULL DEFAULT 'none' CHECK (login IN ('none', 'subscription', 'api', 'local')),\n  created_at INTEGER NOT NULL,\n  updated_at INTEGER NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS ai_providers (\n  id TEXT PRIMARY KEY NOT NULL,\n  name TEXT NOT NULL,\n  preset TEXT,\n  endpoints TEXT NOT NULL,\n  auth_type TEXT NOT NULL DEFAULT 'bearer' CHECK (auth_type IN ('bearer', 'api-key')),\n  secret_ref TEXT,\n  identity_revision INTEGER NOT NULL DEFAULT 1,\n  models TEXT NOT NULL DEFAULT '[]',\n  recommended TEXT NOT NULL DEFAULT '{}',\n  refreshed_at INTEGER,\n  created_at INTEGER NOT NULL,\n  updated_at INTEGER NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS ai_run_configs (\n  profile_id TEXT PRIMARY KEY NOT NULL REFERENCES ai_profiles(id) ON DELETE CASCADE,\n  tool_id TEXT NOT NULL REFERENCES ai_tools(id),\n  source TEXT NOT NULL CHECK (source IN ('login', 'provider', 'legacy')),\n  provider_id TEXT REFERENCES ai_providers(id),\n  models TEXT NOT NULL DEFAULT '[]',\n  default_model TEXT,\n  home_visible INTEGER NOT NULL DEFAULT 1,\n  logged_out INTEGER NOT NULL DEFAULT 0,\n  name_customized INTEGER NOT NULL DEFAULT 1,\n  sort_order INTEGER NOT NULL,\n  legacy_reason TEXT,\n  migration_version INTEGER NOT NULL DEFAULT 1\n);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS ai_run_config_provider_unique ON ai_run_configs(tool_id, provider_id) WHERE source = 'provider';\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS ai_run_config_login_unique ON ai_run_configs(tool_id) WHERE source = 'login';\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS ai_task_snapshots (\n  task_id TEXT PRIMARY KEY NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,\n  snapshot TEXT NOT NULL\n);\n", "/drizzle/0033_ai_provider_key_hint.sql": "ALTER TABLE ai_providers ADD COLUMN key_hint TEXT;\n", "/drizzle/0034_capability_registry.sql": "CREATE TABLE IF NOT EXISTS capability_registry (\n  id TEXT PRIMARY KEY NOT NULL,\n  kind TEXT NOT NULL,\n  name TEXT NOT NULL,\n  runner TEXT NOT NULL,\n  source_path TEXT NOT NULL,\n  source_scope TEXT NOT NULL,\n  project_root TEXT,\n  source_label TEXT NOT NULL,\n  version TEXT,\n  validity TEXT NOT NULL,\n  issues TEXT NOT NULL,\n  managed INTEGER NOT NULL DEFAULT 0,\n  enabled INTEGER NOT NULL DEFAULT 1,\n  auto_approve INTEGER NOT NULL DEFAULT 0,\n  present INTEGER NOT NULL DEFAULT 1,\n  discovered_at INTEGER NOT NULL,\n  scanned_at INTEGER NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_registry_preferences (\n  id INTEGER PRIMARY KEY NOT NULL CHECK (id = 1),\n  auto_manage INTEGER NOT NULL DEFAULT 0,\n  builtin_disabled TEXT NOT NULL DEFAULT '[]'\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS capability_skill_placements (\n  id TEXT PRIMARY KEY NOT NULL,\n  capability_id TEXT NOT NULL REFERENCES capability_registry(id),\n  target_root TEXT NOT NULL,\n  name TEXT NOT NULL,\n  project_root TEXT\n);\n", "/drizzle/0035_builtin_plugin_preferences.sql": "CREATE TABLE IF NOT EXISTS builtin_plugin_defaults (\n  app_id TEXT NOT NULL CHECK(app_id IN ('mail','browser')),\n  slot TEXT NOT NULL,\n  connection_id TEXT REFERENCES application_connections(id),\n  revision INTEGER NOT NULL DEFAULT 0,\n  PRIMARY KEY(app_id,slot)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS builtin_plugin_project_preferences (\n  project_id TEXT NOT NULL,\n  app_id TEXT NOT NULL CHECK(app_id IN ('mail','browser')),\n  slot TEXT NOT NULL,\n  mode TEXT NOT NULL CHECK(mode IN ('follow','individual')),\n  PRIMARY KEY(project_id,app_id,slot),\n  FOREIGN KEY(project_id,app_id) REFERENCES application_project_settings(project_id,app_id) ON DELETE CASCADE\n);\n--> statement-breakpoint\nALTER TABLE capability_runs ADD COLUMN binding_mode TEXT NOT NULL DEFAULT 'current' CHECK(binding_mode IN ('current','run'));\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS mail_sender_confirmation_versions (\n  project_id TEXT NOT NULL,\n  binding_hash TEXT NOT NULL,\n  binding_json TEXT NOT NULL,\n  method TEXT NOT NULL,\n  receipt_id TEXT NOT NULL UNIQUE,\n  sender_id TEXT,\n  confirmed_at TEXT NOT NULL,\n  record_hash TEXT NOT NULL,\n  PRIMARY KEY(project_id,binding_hash,receipt_id)\n);\n--> statement-breakpoint\nINSERT OR IGNORE INTO mail_sender_confirmation_versions SELECT project_id,binding_hash,binding_json,method,receipt_id,sender_id,confirmed_at,record_hash FROM mail_sender_confirmations;\n", "/drizzle/0036_connection_history_retention.sql": "ALTER TABLE application_connections ADD COLUMN deleted_at TEXT;\n", "/drizzle/0037_agent_workspace.sql": "-- @smartdd-foreign-key-rebuild\n-- M14 \u7EDF\u4E00 Agent \u5DE5\u4F5C\u533A\uFF08\u6280\u672F\u65B9\u6848 T1.5 \xA72\uFF09\u3002\u65B0\u4EFB\u52A1\u5728\u540C\u4E00\u4E8B\u52A1\u5199 tasks \u4E0E agent_tasks\uFF1B\u65E7 tasks \u884C\u4E0D\u56DE\u586B\u3002\nCREATE TABLE IF NOT EXISTS agent_tasks (\n task_id TEXT PRIMARY KEY NOT NULL REFERENCES tasks(id) ON DELETE RESTRICT,\n parent_task_id TEXT REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n selection_json TEXT NOT NULL,\n selection_revision INTEGER NOT NULL DEFAULT 1 CHECK(selection_revision>=1),\n mode TEXT NOT NULL DEFAULT 'single' CHECK(mode IN ('single','multi')),\n draft_json TEXT NOT NULL DEFAULT '{}',\n draft_revision INTEGER NOT NULL DEFAULT 0 CHECK(draft_revision>=0),\n archived_at TEXT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_tasks_parent_idx ON agent_tasks(parent_task_id);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_bindings (\n binding_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n driver_id TEXT NOT NULL CHECK(length(driver_id) BETWEEN 1 AND 64),\n profile_id TEXT NOT NULL,\n continuation_hash TEXT NOT NULL CHECK(length(continuation_hash)=64),\n state_root TEXT NOT NULL,\n cwd_identity TEXT NOT NULL,\n native_id TEXT,\n native_confirmed_at TEXT,\n created_at TEXT NOT NULL,\n CHECK(native_confirmed_at IS NULL OR native_id IS NOT NULL)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_bindings_task_idx ON agent_bindings(task_id);\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS agent_bindings_native_key ON agent_bindings(driver_id,continuation_hash,state_root,native_id) WHERE native_id IS NOT NULL;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_capability_sessions (\n capability_session_id TEXT PRIMARY KEY NOT NULL,\n binding_id TEXT NOT NULL REFERENCES agent_bindings(binding_id) ON DELETE RESTRICT,\n revision INTEGER NOT NULL CHECK(revision>=1),\n content_hash TEXT NOT NULL CHECK(length(content_hash)=64),\n snapshot_json TEXT NOT NULL,\n created_at TEXT NOT NULL,\n UNIQUE(binding_id,revision)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_driver_probes (\n probe_id TEXT PRIMARY KEY NOT NULL,\n driver_id TEXT NOT NULL,\n binary_path TEXT NOT NULL,\n realpath TEXT,\n version TEXT,\n capabilities_json TEXT NOT NULL,\n state TEXT NOT NULL CHECK(state IN ('ready','limited','unsupported','missing','failed')),\n reason TEXT,\n probed_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_driver_probes_driver_idx ON agent_driver_probes(driver_id,probed_at);\n--> statement-breakpoint\n-- capability_runs\uFF1Atask_id \u4E0D\u518D\u53EA\u6307\u5411\u65E7\u5355\u4EFB\u52A1\u5FEB\u7167\u3002\u65E7\u884C\u539F\u503C\u4FDD\u7559\uFF1B\u65B0\u884C\u5FC5\u987B\u5E26\u5B8C\u6574\u7684\u7ED1\u5B9A\u5173\u7CFB\uFF08\u89E6\u53D1\u5668\u6838\u9A8C\uFF09\u3002\n-- @smartdd-rebuild-if-foreign-key capability_runs task_id\nCREATE TABLE capability_runs_agent_next (\n  run_id TEXT PRIMARY KEY NOT NULL,\n  task_id TEXT NOT NULL,\n  project_id TEXT NOT NULL,\n  runner TEXT NOT NULL,\n  pid INTEGER,\n  process_started_at TEXT,\n  state TEXT NOT NULL,\n  started_at TEXT NOT NULL,\n  ended_at TEXT,\n  error_code TEXT,\n  snapshot_hash TEXT,\n  owner_instance_id TEXT,\n  owner_pid INTEGER,\n  owner_started_at TEXT,\n  bindings_json TEXT NOT NULL DEFAULT '[]',\n  pty_id TEXT,\n  revocation_state TEXT NOT NULL DEFAULT 'open',\n  binding_mode TEXT NOT NULL DEFAULT 'current' CHECK(binding_mode IN ('current','run')),\n  binding_id TEXT REFERENCES agent_bindings(binding_id) ON DELETE RESTRICT,\n  capability_session_id TEXT REFERENCES agent_capability_sessions(capability_session_id) ON DELETE RESTRICT,\n  generation INTEGER CHECK(generation IS NULL OR generation>=1),\n  driver_id TEXT,\n  launch_plan_hash TEXT,\n  CHECK((binding_id IS NULL AND generation IS NULL AND driver_id IS NULL) OR (binding_id IS NOT NULL AND generation IS NOT NULL AND driver_id IS NOT NULL))\n);\nINSERT INTO capability_runs_agent_next(run_id,task_id,project_id,runner,pid,process_started_at,state,started_at,ended_at,error_code,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id,revocation_state,binding_mode)\nSELECT run_id,task_id,project_id,runner,pid,process_started_at,state,started_at,ended_at,error_code,snapshot_hash,owner_instance_id,owner_pid,owner_started_at,bindings_json,pty_id,revocation_state,binding_mode FROM capability_runs;\nDROP TABLE capability_runs;\nALTER TABLE capability_runs_agent_next RENAME TO capability_runs;\n--> statement-breakpoint\nCREATE UNIQUE INDEX IF NOT EXISTS capability_runs_binding_generation ON capability_runs(binding_id,generation) WHERE binding_id IS NOT NULL;\n--> statement-breakpoint\nCREATE TRIGGER IF NOT EXISTS capability_runs_owner_insert BEFORE INSERT ON capability_runs\nBEGIN\n SELECT RAISE(ABORT,'capability_runs: \u65E7\u8FD0\u884C\u987B\u6709\u5355\u4EFB\u52A1\u5FEB\u7167')\n  WHERE NEW.binding_id IS NULL AND NOT EXISTS(SELECT 1 FROM capability_session_snapshots s WHERE s.task_id=NEW.task_id);\n SELECT RAISE(ABORT,'capability_runs: \u65B0\u8FD0\u884C\u7684\u4EFB\u52A1\u4E0E\u7ED1\u5B9A\u4E0D\u4E00\u81F4')\n  WHERE NEW.binding_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM agent_bindings b WHERE b.binding_id=NEW.binding_id AND b.task_id=NEW.task_id AND b.driver_id=NEW.driver_id);\n SELECT RAISE(ABORT,'capability_runs: \u80FD\u529B\u4F1A\u8BDD\u4E0D\u5C5E\u4E8E\u8BE5\u7ED1\u5B9A')\n  WHERE NEW.capability_session_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM agent_capability_sessions c WHERE c.capability_session_id=NEW.capability_session_id AND c.binding_id=NEW.binding_id);\nEND;\n--> statement-breakpoint\nCREATE TRIGGER IF NOT EXISTS capability_runs_owner_update BEFORE UPDATE OF task_id,binding_id,capability_session_id,driver_id,generation ON capability_runs\nBEGIN\n SELECT RAISE(ABORT,'capability_runs: \u8FD0\u884C\u5F52\u5C5E\u4E0D\u53EF\u4FEE\u6539');\nEND;\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_turns (\n turn_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n client_input_id TEXT NOT NULL,\n input_ref TEXT NOT NULL,\n source_kind TEXT NOT NULL CHECK(source_kind IN ('user','delegation','notification','system')),\n status TEXT NOT NULL CHECK(status IN ('accepted','dispatching','started','completed','failed','interrupted','unknown','canceled')),\n native_turn_id TEXT,\n accepted_at TEXT NOT NULL,\n started_at TEXT,\n ended_at TEXT,\n error_code TEXT,\n UNIQUE(task_id,client_input_id)\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_turns_run_idx ON agent_turns(run_id);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_items (\n item_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n turn_id TEXT REFERENCES agent_turns(turn_id) ON DELETE RESTRICT,\n run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n node_id TEXT,\n type TEXT NOT NULL,\n ordinal INTEGER NOT NULL CHECK(ordinal>=1),\n revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>=1),\n native_key TEXT,\n payload_ref TEXT NOT NULL,\n terminal_state TEXT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL,\n UNIQUE(task_id,ordinal),\n UNIQUE(task_id,native_key)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_events (\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n seq INTEGER NOT NULL CHECK(seq>=1),\n event_type TEXT NOT NULL,\n item_id TEXT REFERENCES agent_items(item_id) ON DELETE RESTRICT,\n revision INTEGER,\n payload TEXT NOT NULL,\n created_at TEXT NOT NULL,\n PRIMARY KEY(task_id,seq)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_requests (\n request_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n class TEXT NOT NULL CHECK(class IN ('native','host_business')),\n origin_json TEXT NOT NULL,\n revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>=1),\n kind TEXT NOT NULL,\n payload_ref TEXT NOT NULL,\n status TEXT NOT NULL CHECK(status IN ('pending','approved_pending_bind','resolved','retired')),\n decision_ref TEXT,\n operation_id TEXT,\n review_hash TEXT,\n account_identity TEXT,\n bound_run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL,\n CHECK(class='host_business' OR (operation_id IS NULL AND review_hash IS NULL AND bound_run_id IS NULL AND status<>'approved_pending_bind'))\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_requests_task_status_idx ON agent_requests(task_id,status);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_transfers (\n transfer_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n target_binding_id TEXT NOT NULL REFERENCES agent_bindings(binding_id) ON DELETE RESTRICT,\n kind TEXT NOT NULL CHECK(kind IN ('full','incremental')),\n through_seq INTEGER NOT NULL CHECK(through_seq>=0),\n covered_ids_json TEXT NOT NULL,\n omissions_json TEXT NOT NULL DEFAULT '[]',\n payload_hash TEXT NOT NULL,\n delivery_state TEXT NOT NULL CHECK(delivery_state IN ('pending','accepted','unsent','unknown')),\n created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_delegations (\n delegation_id TEXT PRIMARY KEY NOT NULL,\n parent_task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n child_task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n parent_run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n target_json TEXT NOT NULL,\n access TEXT NOT NULL CHECK(access IN ('read','write')),\n request_key TEXT NOT NULL,\n result_revision INTEGER NOT NULL DEFAULT 0 CHECK(result_revision>=0),\n delivery_state TEXT NOT NULL CHECK(delivery_state IN ('queued','running','delivered','queued_for_parent','canceled','failed')),\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL,\n UNIQUE(parent_task_id,request_key),\n CHECK(parent_task_id<>child_task_id)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_delegation_attempts (\n attempt_id TEXT PRIMARY KEY NOT NULL,\n delegation_id TEXT NOT NULL REFERENCES agent_delegations(delegation_id) ON DELETE RESTRICT,\n ordinal INTEGER NOT NULL CHECK(ordinal>=1),\n kind TEXT NOT NULL CHECK(kind IN ('initial','rework')),\n input_ref TEXT NOT NULL,\n child_turn_id TEXT REFERENCES agent_turns(turn_id) ON DELETE RESTRICT,\n commit_range TEXT,\n notified_at TEXT,\n merge_check_json TEXT,\n created_at TEXT NOT NULL,\n UNIQUE(delegation_id,ordinal)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_directory_queue (\n queue_id TEXT PRIMARY KEY NOT NULL,\n directory_identity TEXT NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n kind TEXT NOT NULL CHECK(kind IN ('read','write')),\n state TEXT NOT NULL CHECK(state IN ('queued','active','released','canceled')),\n accepted_order INTEGER NOT NULL,\n created_at TEXT NOT NULL,\n ended_at TEXT,\n UNIQUE(directory_identity,accepted_order)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_workspaces (\n workspace_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n child_task_id TEXT REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n kind TEXT NOT NULL CHECK(kind IN ('main','git_worktree')),\n repo_root TEXT NOT NULL,\n path TEXT NOT NULL,\n branch TEXT,\n base_commit TEXT,\n auto_commit TEXT,\n state TEXT NOT NULL CHECK(state IN ('preparing','ready','failed','archived')),\n deps_result TEXT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL,\n UNIQUE(path)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_intents (\n intent_id TEXT PRIMARY KEY NOT NULL,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n action TEXT NOT NULL CHECK(action IN ('auto_commit','worktree_add','child_result_commit','completion_notice','goal_pause','goal_resume')),\n target_ref TEXT,\n expected_parent TEXT,\n head_before TEXT,\n state TEXT NOT NULL CHECK(state IN ('intended','done','needs_review','abandoned')),\n result_json TEXT,\n created_at TEXT NOT NULL,\n updated_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_commit_provenance (\n commit_sha TEXT PRIMARY KEY NOT NULL CHECK(length(commit_sha) BETWEEN 40 AND 64),\n workspace_id TEXT NOT NULL REFERENCES agent_workspaces(workspace_id) ON DELETE RESTRICT,\n attempt_id TEXT REFERENCES agent_delegation_attempts(attempt_id) ON DELETE RESTRICT,\n intent_id TEXT NOT NULL REFERENCES agent_intents(intent_id) ON DELETE RESTRICT,\n kind TEXT NOT NULL CHECK(kind IN ('auto_before_delegate','child_result')),\n message TEXT NOT NULL,\n created_at TEXT NOT NULL\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_goals (\n task_id TEXT PRIMARY KEY NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n binding_id TEXT NOT NULL REFERENCES agent_bindings(binding_id) ON DELETE RESTRICT,\n objective TEXT NOT NULL,\n revision INTEGER NOT NULL DEFAULT 1 CHECK(revision>=1),\n status TEXT NOT NULL CHECK(status IN ('active','paused','complete','cleared')),\n paused_reason TEXT CHECK(paused_reason IS NULL OR paused_reason IN ('user','waiting_children','limit')),\n turns INTEGER NOT NULL DEFAULT 0,\n time_used_s INTEGER NOT NULL DEFAULT 0,\n native_updated_at TEXT,\n updated_at TEXT NOT NULL,\n CHECK(status='paused' OR paused_reason IS NULL)\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_turn_changes (\n turn_id TEXT PRIMARY KEY NOT NULL REFERENCES agent_turns(turn_id) ON DELETE RESTRICT,\n task_id TEXT NOT NULL REFERENCES agent_tasks(task_id) ON DELETE RESTRICT,\n run_id TEXT REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n before_ref TEXT,\n after_ref TEXT,\n changed_files_json TEXT NOT NULL DEFAULT '[]',\n status TEXT NOT NULL CHECK(status IN ('capturing','complete','incomplete','none')),\n incomplete_reason TEXT,\n retained_until TEXT\n);\n--> statement-breakpoint\nCREATE TABLE IF NOT EXISTS agent_resource_refs (\n owner_kind TEXT NOT NULL,\n owner_id TEXT NOT NULL,\n resource_kind TEXT NOT NULL,\n resource_id TEXT NOT NULL,\n hold_reason TEXT NOT NULL,\n created_at TEXT NOT NULL,\n PRIMARY KEY(owner_kind,owner_id,resource_kind,resource_id)\n);\n", "/drizzle/0038_agent_resource_cleanup.sql": "CREATE TABLE IF NOT EXISTS agent_pending_cleanup (\n cleanup_id TEXT PRIMARY KEY NOT NULL,\n project_id TEXT,\n task_id TEXT,\n kind TEXT NOT NULL CHECK(kind IN ('snapshot','attachment','artifact')),\n resource_json TEXT NOT NULL,\n last_error TEXT,\n attempts INTEGER NOT NULL DEFAULT 0,\n next_attempt_at INTEGER NOT NULL DEFAULT 0\n);\n--> statement-breakpoint\nCREATE INDEX IF NOT EXISTS agent_pending_cleanup_due ON agent_pending_cleanup(next_attempt_at,cleanup_id);\n--> statement-breakpoint\n-- Retain the run and invocation history when the agent workspace that owned the run is deleted.\nCREATE TABLE IF NOT EXISTS agent_retained_run_identity (\n run_id TEXT PRIMARY KEY NOT NULL REFERENCES capability_runs(run_id) ON DELETE RESTRICT,\n binding_id TEXT NOT NULL,\n capability_session_id TEXT,\n driver_id TEXT NOT NULL,\n generation INTEGER NOT NULL\n);\n--> statement-breakpoint\nDROP TRIGGER IF EXISTS capability_runs_owner_update;\n--> statement-breakpoint\nCREATE TRIGGER capability_runs_owner_update BEFORE UPDATE OF task_id,binding_id,capability_session_id,driver_id,generation ON capability_runs\nWHEN NOT (\n NEW.task_id=OLD.task_id AND OLD.binding_id IS NOT NULL AND OLD.state IN ('stopped','failed','orphaned')\n AND NEW.binding_id IS NULL AND NEW.capability_session_id IS NULL AND NEW.driver_id IS NULL AND NEW.generation IS NULL\n AND EXISTS (SELECT 1 FROM agent_retained_run_identity a WHERE a.run_id=OLD.run_id AND a.binding_id=OLD.binding_id\n   AND a.capability_session_id IS OLD.capability_session_id AND a.driver_id=OLD.driver_id AND a.generation=OLD.generation)\n)\nBEGIN\n SELECT RAISE(ABORT,'capability_runs: \u8FD0\u884C\u5F52\u5C5E\u4E0D\u53EF\u4FEE\u6539');\nEND;\n", "/drizzle/0039_agent_task_pin.sql": "ALTER TABLE agent_tasks ADD COLUMN pinned_at TEXT;\n" };
function bundledMigrations() {
  return journal_default.entries.map((entry) => {
    const key = Object.keys(sqlFiles).find((k) => k.endsWith(`/${entry.tag}.sql`));
    if (!key) throw new Error(`\u7F3A\u5C11\u6253\u5305\u7684\u8FC1\u79FB\u6587\u4EF6\uFF1A${entry.tag}.sql`);
    const sql = sqlFiles[key];
    return { ...entry, sql, hash: createHash2("sha256").update(sql).digest("hex") };
  });
}
function appliedRecords(connection) {
  if (!connection.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='__drizzle_migrations'").get()) return [];
  return connection.prepare("SELECT hash, created_at FROM __drizzle_migrations ORDER BY id").all();
}
var ADD_COLUMN_RE = /^ALTER\s+TABLE\s+[`"]?(\w+)[`"]?\s+ADD\s+(?:COLUMN\s+)?[`"]?(\w+)[`"]?/i;
function columnAlreadyExists(connection, stmt) {
  const m = ADD_COLUMN_RE.exec(stmt);
  if (!m) return false;
  const cols = connection.prepare("SELECT name FROM pragma_table_info(?)").all(m[1]);
  return cols.some((c) => c.name.toLowerCase() === m[2].toLowerCase());
}
function guardedRebuildAlreadyApplied(connection, statement) {
  const guard = /^-- @smartdd-rebuild-if-foreign-key (\w+) (\w+)\s*$/m.exec(statement);
  if (!guard) return false;
  const keys = connection.prepare('SELECT "from" AS source FROM pragma_foreign_key_list(?)').all(guard[1]);
  return !keys.some((key) => key.source === guard[2]);
}
function planMigrations(connection, migrations) {
  const recorded = appliedRecords(connection), done = recorded.length;
  if (done > migrations.length) {
    throw new Error(`\u6570\u636E\u5E93\u5DF2\u6267\u884C ${done} \u4E2A\u8FC1\u79FB\uFF0C\u5F53\u524D\u7248\u672C\u53EA\u5305\u542B ${migrations.length} \u4E2A\uFF0C\u8BF7\u4F7F\u7528\u66F4\u65B0\u7248\u672C\u7684 WillYou`);
  }
  for (const [index, row] of recorded.entries()) {
    const expected = migrations[index];
    if (row.hash !== expected.hash || row.created_at !== expected.when) {
      throw new Error(`\u8FC1\u79FB\u8BB0\u5F55\u4E0E\u5F53\u524D\u7A0B\u5E8F\u4E0D\u4E00\u81F4\uFF08${expected.tag}\uFF09\uFF0C\u5DF2\u4FDD\u7559\u539F\u6570\u636E\u5E93\uFF0C\u8BF7\u6838\u67E5\u539F\u7248\u672C`);
    }
  }
  return { recorded, before: migrations.slice(0, done), pending: migrations.slice(done) };
}
function runMigrations(connection, migrations, options = {}) {
  const { recorded, pending } = planMigrations(connection, migrations);
  const rebuilding = pending.some((m) => /^-- @smartdd-foreign-key-rebuild$/m.test(m.sql));
  if (rebuilding && connection.inTransaction) throw new Error("\u5BBF\u4E3B\u8FDE\u63A5\u8868\u91CD\u5EFA\u9700\u8981\u5728\u72EC\u7ACB\u8FC1\u79FB\u4E8B\u52A1\u4E2D\u6267\u884C");
  const foreignKeys = connection.pragma("foreign_keys", { simple: true });
  if (rebuilding) connection.pragma("foreign_keys=OFF");
  try {
    connection.transaction(() => {
      const current = appliedRecords(connection);
      if (JSON.stringify(current) !== JSON.stringify(recorded)) throw new Error("\u8FC1\u79FB\u8BB0\u5F55\u5728\u9884\u68C0\u540E\u53D8\u5316\uFF0C\u5DF2\u4FDD\u7559\u539F\u6570\u636E\u5E93\uFF0C\u8BF7\u91CD\u65B0\u9884\u68C0");
      connection.exec(`CREATE TABLE IF NOT EXISTS __drizzle_migrations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      hash TEXT NOT NULL,
      created_at NUMERIC
    )`);
      const record = connection.prepare("INSERT INTO __drizzle_migrations (hash, created_at) VALUES (?, ?)");
      for (const m of pending) {
        for (const stmt of m.sql.split("--> statement-breakpoint")) {
          const trimmed = stmt.trim();
          if (trimmed && !columnAlreadyExists(connection, trimmed) && !guardedRebuildAlreadyApplied(connection, trimmed)) connection.exec(trimmed);
        }
        record.run(m.hash, m.when);
      }
      if (rebuilding) {
        const violations = connection.pragma("foreign_key_check");
        if (!Array.isArray(violations) || violations.length) throw new Error("\u5BBF\u4E3B\u8FDE\u63A5\u8FC1\u79FB\u5916\u952E\u6838\u9A8C\u5931\u8D25\uFF0C\u5DF2\u4FDD\u7559\u539F\u6570\u636E");
      }
      options.recordCommit?.(pending.map((m) => m.tag));
    })();
  } finally {
    if (rebuilding) connection.pragma("foreign_keys=" + (foreignKeys ? "ON" : "OFF"));
  }
  return pending.map((m) => m.tag);
}
function runBundledMigrations(connection) {
  return runMigrations(connection, bundledMigrations());
}

// host-fixture.ts
var requireDependency = createRequire(join3(process.env.F35_REPO, "package.json"));
var Database = requireDependency("better-sqlite3");
var [databaseFile, home] = process.argv.slice(2);
var database = new Database(databaseFile);
database.pragma("foreign_keys=ON");
var migrated = runBundledMigrations(database);
var store = new AgentStore(database);
var queue = new DirectoryQueue(store);
var git = new GitWorkspaces({ store, home });
var legacyDriverId = "codex-app-server";
var addTask = (cwd, title, parentTaskId) => store.createTask({
  projectId: null,
  dirId: null,
  cwd,
  title,
  parentTaskId,
  selection: { driverId: legacyDriverId, profileId: "f35-native-storage-fixture", tier: "ask" }
});
var methods = {
  hello: () => ({ pid: process.pid, migrated, sqliteVersion: database.prepare("select sqlite_version() as ver").get().ver }),
  add: ({ cwd, title, parentTaskId }) => addTask(cwd, title, parentTaskId),
  identity: ({ cwd, roots }) => directoryIdentity(cwd, roots),
  detect: ({ cwd }) => git.detect(cwd),
  enter: ({ taskId, identity }) => queue.enter(taskId, identity),
  get: ({ id }) => queue.get(id),
  acquire: ({ id }) => queue.acquire(id),
  cancel: ({ taskId }) => queue.cancel(taskId),
  release: ({ id, proof }) => queue.release(id, proof),
  queueStates: () => database.prepare("SELECT queue_id, task_id, kind, state, directory_identity, accepted_order FROM agent_directory_queue ORDER BY accepted_order").all(),
  makeWorktree: async ({ cwd, parentTaskId, childTaskId, title }) => {
    const detected = await git.detect(cwd);
    if (!detected) throw Error("Expected a Git checkout");
    const source = await git.sourceSnapshot(detected);
    const created = await git.create({
      cwd,
      parentTaskId,
      childTaskId,
      title,
      projectName: "F35 Directory",
      projectId: "disposable-f35",
      expectedBranch: detected.branch,
      expectedRoot: detected.root,
      baseCommit: source.baseCommit
    });
    return { detected, source, created };
  },
  finalizeWorktree: async ({ parentTaskId, childTaskId, title, baseCommit }) => {
    const delegation = randomUUID4();
    const attempt = randomUUID4();
    const now2 = (/* @__PURE__ */ new Date()).toISOString();
    store.tx(() => {
      database.prepare("INSERT INTO agent_delegations(delegation_id,parent_task_id,child_task_id,target_json,access,request_key,delivery_state,created_at,updated_at) VALUES(?,?,?,'{}','write',?,'running',?,?)").run(delegation, parentTaskId, childTaskId, delegation, now2, now2);
      database.prepare("INSERT INTO agent_delegation_attempts(attempt_id,delegation_id,ordinal,kind,input_ref,created_at) VALUES(?,?,1,'initial','{}',?)").run(attempt, delegation, now2);
    });
    const range = await git.finalize(childTaskId, attempt, title, baseCommit);
    return {
      range,
      attempt,
      provenance: database.prepare("SELECT commit_sha,workspace_id,attempt_id,intent_id,kind FROM agent_commit_provenance WHERE attempt_id=?").get(attempt),
      intent: database.prepare("SELECT action,state,head_before,expected_parent FROM agent_intents WHERE target_ref=(SELECT path FROM agent_workspaces WHERE child_task_id=?) AND action='child_result_commit'").get(childTaskId),
      durableRange: JSON.parse(database.prepare("SELECT commit_range FROM agent_delegation_attempts WHERE attempt_id=?").get(attempt).commit_range)
    };
  },
  removeWorktree: ({ workspaceId }) => git.removeRegistered(workspaceId),
  saveBinding: ({ taskId, cwd, home: stateRoot, nativeSession }) => {
    const continuationHash = sha256(JSON.stringify({ driver: legacyDriverId, profile: "f35-native-storage-fixture", stateRoot, cwd, compatibility: { probe: "agy" } }));
    const bindingId = store.createBinding({
      task_id: taskId,
      driver_id: legacyDriverId,
      profile_id: "f35-native-storage-fixture",
      continuation_hash: continuationHash,
      state_root: stateRoot,
      cwd_identity: cwd
    });
    store.freezeBinding(bindingId, { compatibility: { probe: "agy" }, stateRoot, cwd });
    store.confirmNative(bindingId, nativeSession);
    return { bindingId, continuationHash };
  },
  readBinding: ({ taskId, continuationHash }) => store.findBinding(taskId, legacyDriverId, continuationHash)
};
try {
  const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
  for await (const line of input) {
    const { method, params } = JSON.parse(line);
    try {
      if (!Object.hasOwn(methods, method)) throw Error("Fixture method not allowed");
      const result = await methods[method](params);
      console.log(JSON.stringify({ result: result ?? null }));
    } catch (error) {
      console.log(JSON.stringify({ error: error.message }));
    }
  }
} finally {
  database.close();
}
