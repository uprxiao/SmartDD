"""Connect real agy to a real gateway with a fixed synthetic experiment.

The local server checks the event class and one local fixture marker. It never
forwards a byte of the input request. Outbound payloads are built exclusively
from a generated fixture and the same gateway's own call ID and signature.
"""
from getpass import getpass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import sys
from tempfile import mkdtemp
from threading import Thread
from urllib.parse import urlsplit

from agy_wire_helpers import open_wire, turn
from agy_observe_routes import handshake, summarize_config
from gateway_probe import MODELS, ROOT, as_object
from synthetic_gateway_profiles import MARKER, TOOL_NAME, THINKING, SYNTHETIC_SYSTEM, request, tool_definitions


LOCAL_RESULT = "F35-MCP-FIXTURE"
SYNTHETIC_RESULT = "F35-REAL-GATEWAY-ECHO"
LOCAL_TOOL = "mcp_f35_probe_tools_report_probe"


class SyntheticRelay(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def event(self, part):
        response = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [part]},
                                    "finishReason": "STOP"}], "modelVersion": self.server.model}
        packet = b"data: " + json.dumps(response).encode() + b"\n\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(packet)))
        self.end_headers()
        self.wfile.write(packet)

    def do_POST(self):
        route = urlsplit(self.path)
        model = route.path.rsplit("/", 1)[-1].split(":", 1)[0]
        size = int(self.headers.get("Content-Length", "0"))
        if model != self.server.model or not 0 < size <= 512000:
            self.send_error(403)
            return
        incoming = json.loads(self.rfile.read(size))
        last = (incoming.get("contents") or [{}])[-1]
        parts = last.get("parts") or []
        response_seen = any("functionResponse" in part and LOCAL_RESULT in json.dumps(part) for part in parts)
        ask_seen = any("F35-SAFE-TOOL-TURN" in part.get("text", "") for part in parts)
        if self.server.stage == "starting" and ask_seen:
            self.server.stage = "started"
            row, outbound_parts = request(self.server.credential, model, {
                **self.server.synthetic_options, "contents": [self.server.synthetic_user],
                "toolConfig": {"functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": [TOOL_NAME]}},
            }, timeout=40)
            call = next((part for part in outbound_parts if as_object(part.get("functionCall")).get("name") == TOOL_NAME
                         and as_object(part["functionCall"].get("args")).get("value") == MARKER), None)
            row.update(step="functionCall", matched=bool(call))
            self.server.evidence.append(row)
            if not call or row["http"] != 200 or row["curlExit"] != 0:
                self.send_error(502, "Synthetic upstream tool call failed")
                return
            trusted = {"functionCall": {"name": TOOL_NAME, "args": {"value": MARKER}}}
            call_id = call["functionCall"].get("id")
            if isinstance(call_id, str) and re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", call_id):
                trusted["functionCall"]["id"] = call_id
            signature = call.get("thoughtSignature")
            if isinstance(signature, str) and len(signature) <= 200000 and re.fullmatch(r"[A-Za-z0-9+/=_-]+", signature):
                trusted["thoughtSignature"] = signature
            self.server.gateway_call = trusted
            self.server.stage = "waiting-tool-result"
            self.event({"functionCall": {"name": LOCAL_TOOL, "args": {
                "value": "F35-PROBE-OK", "toolSummary": "Report the isolated fixture marker"}},
                        **({"thoughtSignature": trusted["thoughtSignature"]} if "thoughtSignature" in trusted else {})})
        elif self.server.stage == "waiting-tool-result" and response_seen:
            self.server.stage = "result"
            result = {"name": TOOL_NAME, "response": {"value": SYNTHETIC_RESULT}}
            prior = self.server.gateway_call
            if "id" in prior["functionCall"]:
                result["id"] = prior["functionCall"]["id"]
            # The last role mirrors the actual agy functionResponse shape.
            fixture_contents = [self.server.synthetic_user, {"role": "model", "parts": [prior]},
                                {"role": "model", "parts": [{"functionResponse": result}]}]
            row, outbound_parts = request(self.server.credential, model, {
                **self.server.synthetic_options, "contents": fixture_contents,
            }, timeout=40)
            visible = "".join(part["text"] for part in outbound_parts if isinstance(part.get("text"), str)
                              and not part.get("thought"))
            matched = SYNTHETIC_RESULT in visible and row["http"] == 200 and row["curlExit"] == 0
            row.update(step="functionResponse", matched=matched)
            self.server.evidence.append(row)
            if matched:
                self.event({"text": visible})
            else:
                self.send_error(502, "Synthetic upstream function result failed")
        else:
            self.send_error(409, "Unexpected request in the bounded fixture")


def run_trial(token, model, profile, workspace):
    home, cwd = workspace / "home", workspace / "project"
    for path in (home / "tmp", cwd):
        path.mkdir(mode=0o700, parents=True)
    trace = workspace / "mcp.txt"
    trace.write_text("")
    approvals = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), SyntheticRelay)
    server.credential, server.model, server.stage, server.evidence = token, model, "starting", []
    server.synthetic_user = {"role": "user", "parts": [{"text": f"Call {TOOL_NAME} with {MARKER}. "
                              "When it returns, repeat only the returned value."}]}
    one_tool = [{"functionDeclarations": tool_definitions()[0]["functionDeclarations"][:1]}]
    server.synthetic_options = {"tools": one_tool, "generationConfig": {"maxOutputTokens": 512}}
    if profile == "8192-large":
        server.synthetic_options = {"tools": tool_definitions(), "systemInstruction": {"parts": [
            {"text": SYNTHETIC_SYSTEM}]}, "generationConfig": {"maxOutputTokens": 8192, "thinkingConfig": THINKING}}
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(home / "tmp"),
           "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
           "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
           "GEMINI_API_KEY": "F35-DUMMY-LOCAL-SYNTHETIC-ONLY",
           "GOOGLE_GEMINI_BASE_URL": f"http://127.0.0.1:{server.server_port}",
           "NO_PROXY": "127.0.0.1", "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1"}
    wire = None
    try:
        wire = open_wire(args, cwd, env, approvals)
        opened = handshake(wire)
        assert opened["authenticate"]["outcome"] == "ok", opened
        servers = [{"name": "f35_probe_tools", "command": sys.executable,
                    "args": [str(ROOT / "mcp_fixture.py"), str(trace)], "env": []}]
        setup = wire.call("session/new", {"cwd": str(cwd), "mcpServers": servers})
        session = setup["result"]["sessionId"]
        selected = wire.call("session/set_config_option", {"sessionId": session, "configId": "model", "value": model})
        assert summarize_config(selected, "model")["currentValue"] == model
        check = turn(wire, session, "F35-SAFE-TOOL-TURN. Call report_probe with a synthetic marker.",
                     SYNTHETIC_RESULT, timeout=89)
        invocations = trace.read_text().splitlines().count("tools/call")
        actual_marker = trace.with_suffix(".result").is_file() and trace.with_suffix(".result").read_text().strip() == LOCAL_RESULT
        return {"model": model, "profile": profile, "realAgy": check, "approved": list(approvals),
                "localToolInvocations": invocations, "isolatedFileVerified": actual_marker,
                "gateway": server.evidence, "passed": bool(check["hasExpectedMarker"] and actual_marker and
                                                           invocations == 1 and len(server.evidence) == 2
                                                           and all(row["matched"] for row in server.evidence))}
    finally:
        if wire is not None:
            wire.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required.")
    token = getpass("Model Hub credential (hidden): ")
    if not token or any(c.isspace() for c in token) or not token.isascii():
        raise SystemExit("Missing or invalid credential input.")
    root = Path(mkdtemp(prefix="live-synthetic-acp-", dir=ROOT))
    profiles = [(MODELS[1], "compact"), (MODELS[1], "8192-large"), (MODELS[0], "compact")]
    records = []
    for model, profile in profiles:
        row = run_trial(token, model, profile, root / f"{model}-{profile}")
        records.append(row)
        (ROOT / "live-synthetic-acp.json").write_text(json.dumps({"outboundFixturesOnly": True,
                                                    "records": records}, indent=2, ensure_ascii=False) + "\n")
        print(json.dumps(row, ensure_ascii=False), flush=True)
