"""Real Model Hub probes with a fully synthesized request body.

Only synthetic strings, configuration values, and test tool definitions go to
the gateway. The program does not read the locally captured ACP request.
"""
from concurrent.futures import ThreadPoolExecutor
from getpass import getpass
import json
import subprocess
import sys
from time import monotonic

from gateway_probe import BASE, MODELS, ROOT, as_object
from gateway_retry import scrub


MARKER = "F35-SYNTHETIC-OK"
TOOL_NAME = "f35_echo"
TOOL_RESULT = "F35-SYNTHETIC-TOOL-RESULT"
THINKING = {"includeThoughts": True, "thinkingLevel": "LOW"}
SYNTHETIC_SYSTEM = (
    "This is a synthetic API health check. Follow the last user instruction and emit its fixed marker.\n"
    + "".join(f"Fictional fixture record {index:03}: empty example workflow for a generated API test.\n"
              for index in range(245))
)


def tool_definitions():
    params = {"type": "OBJECT", "properties": {"value": {"type": "STRING"}}, "required": ["value"]}
    tools = [{"name": TOOL_NAME, "description": "Return a synthetic test marker.", "parameters": params}]
    for index in range(1, 17):
        description = f"Placeholder number {index} for a synthetic diagnostic. Do not select this placeholder."
        tools.append({"name": f"f35_placeholder_{index:02}", "description": description + (" Fixture metadata." * 65),
                      "parameters": params})
    return [{"functionDeclarations": tools}]


def request(credential, model, payload, timeout=44):
    assert model in MODELS
    url = f"{BASE}/v1beta/models/{model}:streamGenerateContent?alt=sse"
    headers = ("Content-Type: application/json\nAccept: text/event-stream\n"
               f"x-goog-api-key: {credential}\nAuthorization: Bearer {credential}\n")
    body = json.dumps(payload)
    started = monotonic()
    call = subprocess.run(
        ["/usr/bin/curl", "-q", "-sS", "--proto", "=https", "--max-time", str(timeout),
         "--connect-timeout", "8", "--max-filesize", "512000", "--header", "@-",
         "--data-binary", body, "--write-out", "\n%{http_code}\n%{time_starttransfer}", url],
        input=headers.encode(), capture_output=True, timeout=timeout + 3,
    )
    tail, _, first = call.stdout.rpartition(b"\n")
    content, _, http = tail.rpartition(b"\n")
    status = int(http) if http.isdigit() else 0
    frames = []
    for line in content.splitlines():
        if line.startswith(b"data:") and line[5:].strip() != b"[DONE]":
            try:
                frames.append(json.loads(line[5:]))
            except ValueError:
                continue
    candidates = [as_object(c) for f in frames for c in as_object(f).get("candidates") or []]
    parts = [as_object(p) for c in candidates for p in as_object(c.get("content")).get("parts") or []]
    info = {"model": model, "http": status, "curlExit": call.returncode,
            "elapsedMs": round((monotonic() - started) * 1000),
            "firstByteMs": round(float(first) * 1000) if first else None,
            "syntheticBodyBytes": len(body.encode()), "sseFrames": len(frames),
            "finishReasons": sorted({c["finishReason"] for c in candidates if isinstance(c.get("finishReason"), str)})}
    if status >= 400:
        try:
            envelope = as_object(json.loads(content))
        except ValueError:
            envelope = {}
        reason = as_object(envelope.get("error")).get("message") or envelope.get("message")
        if reason:
            info["gatewayReason"] = scrub(reason, credential)
    return info, parts


def plain_body(limit=384):
    return {"contents": [{"role": "user", "parts": [{"text": f"Reply exactly {MARKER}."}]}],
            "generationConfig": {"maxOutputTokens": limit}}


def tool_payload(compound=False):
    base = {"contents": [{"role": "user", "parts": [{"text": f"Call {TOOL_NAME} with value {MARKER}."}]}],
            "generationConfig": {"maxOutputTokens": 384}, "tools": tool_definitions(), "toolConfig": {
                "functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": [TOOL_NAME]},
            }}
    if compound:
        base["systemInstruction"] = {"parts": [{"text": SYNTHETIC_SYSTEM}]}
        base["generationConfig"] = {"maxOutputTokens": 65536, "thinkingConfig": THINKING}
    return base


def cases(credential, model):
    rows = []
    checkpoint = ROOT / (model + "-profiles.json")

    def sample(case, payload, marker=MARKER, expect_tool=False):
        row, parts = request(credential, model, payload)
        texts = "".join(p["text"] for p in parts if isinstance(p.get("text"), str) and not p.get("thought"))
        tool = next((p for p in parts if as_object(p.get("functionCall")).get("name") == TOOL_NAME
                     and as_object(p["functionCall"].get("args")).get("value") == MARKER), None)
        matched = bool(tool) if expect_tool else marker in texts
        row.update(case=case, expectedOutput=matched, passed=bool(row["http"] == 200 and row["curlExit"] == 0 and
                                                                  row["sseFrames"] and matched))
        rows.append(row)
        checkpoint.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n")
        print(json.dumps(row, ensure_ascii=False), flush=True)
        return row, tool

    base, _ = sample("small_text", plain_body())
    if not base["passed"]:
        return rows
    cap, _ = sample("large_output_cap_only", plain_body(65536))
    thought = plain_body()
    thought["generationConfig"]["thinkingConfig"] = THINKING
    think, _ = sample("thinking_only", thought)
    with_system = plain_body()
    with_system["systemInstruction"] = {"parts": [{"text": SYNTHETIC_SYSTEM}]}
    system, _ = sample("synthesized_system_only", with_system)
    request_tool = tool_payload()
    tool_round, call = sample("synthesized_17_tools", request_tool, expect_tool=True)
    if tool_round["passed"]:
        # Preserve only the provider's optional opaque signature for the
        # synthetic echo call. Every text field is a fixture constant.
        model_part = {"functionCall": {"name": TOOL_NAME, "args": {"value": MARKER}}}
        signature = call.get("thoughtSignature")
        if isinstance(signature, str) and len(signature) <= 200000:
            model_part["thoughtSignature"] = signature
        second = {"contents": [*request_tool["contents"],
                  {"role": "model", "parts": [model_part]},
                  {"role": "user", "parts": [{"functionResponse": {"name": TOOL_NAME,
                    "response": {"value": TOOL_RESULT}}}, {"text": f"Return exactly {TOOL_RESULT}."}]}],
                  "tools": request_tool["tools"], "generationConfig": {"maxOutputTokens": 512}}
        sample("tool_result_followup", second, marker=TOOL_RESULT)
    if all(row["passed"] for row in (cap, think, system, tool_round)):
        sample("combined_synthetic_shape", tool_payload(compound=True), expect_tool=True)
    return rows


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required.")
    token = getpass("Model Hub credential (hidden): ")
    if not token or any(c.isspace() for c in token) or not token.isascii():
        raise SystemExit("Missing or invalid credential input.")
    with ThreadPoolExecutor(max_workers=2) as pool:
        groups = list(pool.map(lambda model: cases(token, model), MODELS))
    (ROOT / "synthetic-gateway-profiles.json").write_text(json.dumps({
        "models": list(MODELS), "fullySynthesizedBody": True,
        "results": [row for group in groups for row in group],
    }, indent=2, ensure_ascii=False) + "\n")
