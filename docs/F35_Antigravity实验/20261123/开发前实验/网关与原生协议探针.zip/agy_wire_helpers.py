from pathlib import Path
import json,sys,time
from threading import Thread
from acp_probe import ROOT
from agy_key_path_probe import RpcProcess, shape
from agy_observe_routes import handshake, summarize_config

def turn(wire, session, prompt, expected, timeout=79):
    before = len(wire.notifications)
    started = time.monotonic()
    response = wire.call("session/prompt", {"sessionId": session,
        "prompt": [{"type": "text", "text": prompt}]}, timeout=timeout)
    updates = [event.get("params", {}).get("update", {}) for event in wire.notifications[before:]
               if event.get("method") == "session/update"]
    chunks = [event.get("content", {}).get("text", "") for event in updates
              if event.get("sessionUpdate") == "agent_message_chunk"]
    row = {"elapsedMs": round((time.monotonic() - started) * 1000),
           "outcome": shape(response)["outcome"],
           "stopReason": (response.get("result") or {}).get("stopReason"),
           "assistantChunkCount": len(chunks),
           "hasExpectedMarker": expected in "".join(chunks),
           "sessionUpdateTypes": sorted({entry.get("sessionUpdate") for entry in updates if entry.get("sessionUpdate")})}
    return row

def open_wire(args, cwd, env, approval_log, allow_fixture_tool=True):
    wire = RpcProcess(args, cwd, env)

    def answer(request):
        if request["method"] != "session/request_permission":
            return {"error": {"code": -32601, "message": "Fixture only accepts a permission request."}}
        params = request.get("params") or {}
        is_fixture_tool = "report_probe" in json.dumps(params.get("toolCall") or {})
        option = next((item for item in params.get("options") or [] if item.get("kind") == "allow_once"), None)
        if is_fixture_tool and not allow_fixture_tool:
            deny = next((item for item in params.get("options") or [] if item.get("kind") == "reject_once"), None)
            approval_log.append("deny_once_for_report_probe")
            if deny:
                return {"result": {"outcome": {"outcome": "selected", "optionId": deny["optionId"]}}}
            return {"result": {"outcome": {"outcome": "cancelled"}}}
        if is_fixture_tool and option:
            approval_log.append("allow_once_for_report_probe")
            return {"result": {"outcome": {"outcome": "selected", "optionId": option["optionId"]}}}
        approval_log.append("cancel_other_request")
        return {"result": {"outcome": {"outcome": "cancelled"}}}

    wire.answer_request = answer
    return wire

def check_model(workspace, candidate, endpoint, expect_extra, publish, allow_fixture_tool=True, cancel_ready=None, first_only=False):
    home = workspace / "home"
    cwd = workspace / "project"
    for path in (home, home / "tmp", cwd):
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(home / "tmp"),
           "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
           "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
           "GEMINI_API_KEY": "F35-DUMMY-CREDENTIAL-RELAY-OWNS-REAL-KEY", "GOOGLE_GEMINI_BASE_URL": endpoint,
           "NO_PROXY": "127.0.0.1", "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1"}
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    trace = workspace / "mcp.txt"
    trace.write_text("")
    servers = [{"name": "f35_probe_tools", "command": sys.executable,
                "args": [str(ROOT / "mcp_fixture.py"), str(trace)], "env": []}] if expect_extra else []
    approvals = []
    wire = open_wire(args, cwd, env, approvals, allow_fixture_tool)
    marker = "F35-CARBON-R2" if expect_extra else "F35-ARGON-R2"
    remember = f"Remember identifier {marker}. Reply with only that identifier. Do not call tools."
    row = {"model": candidate, "fixtureApprovals": approvals}
    try:
        row.update(handshake(wire))
        if row["authenticate"]["outcome"] != "ok":
            return row
        opened = wire.call("session/new", {"cwd": str(cwd), "mcpServers": servers})
        row["sessionNew"] = shape(opened)
        session = (opened.get("result") or {}).get("sessionId")
        if not session:
            return row
        chosen = wire.call("session/set_config_option", {"sessionId": session, "configId": "model", "value": candidate})
        row["confirmedModel"] = summarize_config(chosen, "model")["currentValue"]
        if row["confirmedModel"] != candidate:
            return row
        effort = wire.call("session/set_config_option", {"sessionId": session, "configId": "thought_level", "value": "low"})
        row["effort"] = summarize_config(effort, "thought_level")
        row["firstTurn"] = turn(wire, session, remember, marker)
        publish(row)
        if expect_extra and row["firstTurn"]["hasExpectedMarker"] and not first_only:
            wire.close()
            wire = None
            wire = open_wire(args, cwd, env, approvals, allow_fixture_tool)
            row["freshProcess"] = handshake(wire)
            resumed = wire.call("session/resume", {"sessionId": session, "cwd": str(cwd), "mcpServers": servers})
            row["resume"] = shape(resumed)
            if row["resume"]["outcome"] == "ok":
                chosen = wire.call("session/set_config_option",
                                   {"sessionId": session, "configId": "model", "value": candidate})
                row["modelAfterReapply"] = summarize_config(chosen, "model")["currentValue"]
                row["followup"] = turn(wire, session, "Reply with the identifier I asked you to remember.", marker)
                publish(row)
                row["mcpTurn"] = turn(wire, session, "Call the report_probe MCP tool with value F35-PROBE-OK. "
                                     "Reply with only the exact tool result. Use only this tool.", "F35-MCP-FIXTURE")
        if cancel_ready is not None:
            def cancel():
                if cancel_ready.wait(timeout=7):
                    wire.write({"method": "session/cancel", "params": {"sessionId": session}})
            watcher = Thread(target=cancel, daemon=True)
            watcher.start()
            row["cancelTurn"] = turn(wire, session, "Wait for F35-TEST-CANCEL.", "F35-CANCEL-LATE", timeout=8)
            watcher.join(timeout=1)
        row["mcpMethods"] = trace.read_text().splitlines()
        row["toolWroteSyntheticResult"] = trace.with_suffix(".result").exists()
        return row
    finally:
        if wire is not None:
            wire.close()
