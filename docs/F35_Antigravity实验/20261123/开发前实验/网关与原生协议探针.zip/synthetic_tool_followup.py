"""Use only generated fixtures to vary tool-result role and output budget."""
from concurrent.futures import ThreadPoolExecutor
from getpass import getpass
import json
import re
import sys

from gateway_probe import MODELS, ROOT, as_object
from synthetic_gateway_profiles import MARKER, TOOL_NAME, TOOL_RESULT, plain_body, request, tool_definitions


def cases(credential, model):
    rows = []
    checkpoint = ROOT / (model + "-tool-followup.json")

    def run(case, payload, expected_text=None):
        row, parts = request(credential, model, payload, timeout=40)
        row["case"] = case
        if expected_text:
            text = "".join(p["text"] for p in parts if isinstance(p.get("text"), str) and not p.get("thought"))
            row["expectedText"] = expected_text in text
            row["passed"] = bool(row["http"] == 200 and row["curlExit"] == 0 and row["expectedText"])
        else:
            row["passed"] = bool(row["http"] == 200 and row["curlExit"] == 0)
        rows.append(row)
        return row, parts

    def publish(row):
        checkpoint.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n")
        print(json.dumps(row, ensure_ascii=False), flush=True)

    new_prompt = {"role": "user", "parts": [{"text": f"Call {TOOL_NAME} with {MARKER}. "
                    "When the function returns, repeat only the value it returned."}]}
    tiny_tools = [{"functionDeclarations": tool_definitions()[0]["functionDeclarations"][:1]}]
    common = {"tools": tiny_tools, "generationConfig": {"maxOutputTokens": 512}}
    forced = {**common, "contents": [new_prompt], "toolConfig": {"functionCallingConfig": {
        "mode": "ANY", "allowedFunctionNames": [TOOL_NAME],
    }}}
    first, parts = run("single_echo_request", forced)
    p = next((p for p in parts if as_object(p.get("functionCall")).get("name") == TOOL_NAME
              and as_object(p["functionCall"].get("args")).get("value") == MARKER), None)
    first["passed"] = first["passed"] and p is not None
    if not first["passed"]:
        publish(first)
    else:
        call = {"name": TOOL_NAME, "args": {"value": MARKER}}
        part = {"functionCall": call}
        returned_id = p["functionCall"].get("id")
        if isinstance(returned_id, str) and re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", returned_id):
            call["id"] = returned_id
        signature = p.get("thoughtSignature")
        if isinstance(signature, str) and len(signature) <= 200000 and re.fullmatch(r"[A-Za-z0-9+/=_-]+", signature):
            part["thoughtSignature"] = signature
        first["gatewayReturnedCallId"] = "id" in call
        first["gatewayReturnedThoughtSignature"] = "thoughtSignature" in part
        publish(first)
        result = {"name": TOOL_NAME, "response": {"value": TOOL_RESULT}}
        if "id" in call:
            result["id"] = call["id"]
        opening = [new_prompt, {"role": "model", "parts": [part]}]

        def followup(case, role, separate=False):
            response = {"parts": [{"functionResponse": result}]}
            if role:
                response["role"] = role
            contents = [*opening, response]
            if separate:
                contents.append({"role": "user", "parts": [{"text": "Repeat only the value from the function."}]})
            row, _ = run(case, {**common, "contents": contents}, expected_text=TOOL_RESULT)
            publish(row)
            return row

        native = followup("result_role_model_agy_shape", "model")
        if not native["passed"]:
            conventional = followup("result_role_user_only", "user")
            if not conventional["passed"]:
                followup("result_role_user_then_separate_text", "user", separate=True)
    cap, _ = run("medium_output_cap_8192", plain_body(8192), expected_text=MARKER)
    publish(cap)
    return rows


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required.")
    token = getpass("Model Hub credential (hidden): ")
    if not token or any(c.isspace() for c in token) or not token.isascii():
        raise SystemExit("Missing or invalid credential input.")
    with ThreadPoolExecutor(max_workers=2) as pool:
        groups = list(pool.map(lambda model: cases(token, model), MODELS))
    (ROOT / "synthetic-tool-followup.json").write_text(json.dumps({
        "models": list(MODELS), "fullySynthesizedBody": True,
        "results": [row for group in groups for row in group],
    }, indent=2, ensure_ascii=False) + "\n")
