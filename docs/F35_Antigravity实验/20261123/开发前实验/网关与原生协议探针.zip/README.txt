F35 predevelopment probes. Python 3 and the locally installed agy are required.
Run in an empty, private extraction directory. Local loopback permission is required for capture and the isolated ACP tests.
capture_native.py, capture_tool_shapes.py and probe_turn_failure.py only use local fixtures.
capture_native.py writes a private captured body for local inspection only. Keep it local.
synthetic_gateway_profiles.py and synthetic_tool_followup.py send only generated fixture content to the configured Model Hub using hidden input for the key.
live_synthetic_acp_round.py starts real agy locally and sends only generated fixtures upstream.
The evidence JSON records results separately for each model and trial. A failed upstream prerequisite ends that trial.
