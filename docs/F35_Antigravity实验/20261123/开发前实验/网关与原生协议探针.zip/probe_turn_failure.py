"""Locally verify agy's ACP result and native per-session error-step distinction."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import sqlite3
from tempfile import mkdtemp
from threading import Thread
from urllib.parse import urlsplit

from agy_wire_helpers import open_wire, turn
from agy_observe_routes import handshake, summarize_config
from gateway_probe import MODELS, ROOT


MODEL = MODELS[0]


class FaultFixture(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        route = urlsplit(self.path)
        if route.path != f"/v1beta/models/{MODEL}:streamGenerateContent":
            self.send_error(403)
            return
        size = int(self.headers.get("Content-Length", "0"))
        if not 0 < size <= 512000:
            self.send_error(400)
            return
        body = json.loads(self.rfile.read(size))
        contents = body["contents"]
        latest = " ".join(p.get("text", "") for p in contents[-1].get("parts") or [])
        if "F35-FAULT-PROBE" in latest:
            code = 400
            data = json.dumps({"error": {"code": code, "message": "F35-FIXTURE-UPSTREAM-REJECTED",
                                         "status": "INVALID_ARGUMENT"}}).encode()
            content_type = "application/json"
        else:
            code = 200
            message = "Error 400, Message: F35-ORDINARY-TEXT, Status: INVALID_ARGUMENT"
            result = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [{"text": message}]},
                                      "finishReason": "STOP"}], "modelVersion": MODEL}
            data = b"data: " + json.dumps(result).encode() + b"\n\n"
            content_type = "text/event-stream"
        self.server.responses.append(code)
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def inspect(db, after=-1):
    if not db.exists():
        return []
    assert db.resolve() == db and not db.is_symlink()
    with sqlite3.connect(db.as_uri() + "?mode=ro", uri=True) as connection:
        return connection.execute(
            "SELECT idx,step_type,substr(step_payload,1,16384) FROM steps WHERE idx>? ORDER BY idx",
            (after,),
        ).fetchall()


if __name__ == "__main__":
    root = Path(mkdtemp(prefix="native-turn-outcome-", dir=ROOT))
    home, cwd = root / "home", root / "project"
    for path in (home / "tmp", cwd):
        path.mkdir(mode=0o700, parents=True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), FaultFixture)
    server.responses = []
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(home / "tmp"),
           "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
           "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
           "GEMINI_API_KEY": "F35-DUMMY-LOCAL-FAULT-PROBE",
           "GOOGLE_GEMINI_BASE_URL": f"http://127.0.0.1:{server.server_port}",
           "NO_PROXY": "127.0.0.1", "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1"}
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    wire = open_wire(args, cwd, env, [])
    try:
        assert handshake(wire)["authenticate"]["outcome"] == "ok"
        session = wire.call("session/new", {"cwd": str(cwd), "mcpServers": []})["result"]["sessionId"]
        assert re.fullmatch(r"[A-Za-z0-9_-]+", session)
        settings = wire.call("session/set_config_option", {"sessionId": session, "configId": "model", "value": MODEL})
        assert summarize_config(settings, "model")["currentValue"] == MODEL
        db = home / ".gemini" / "antigravity-acp" / "conversations" / f"{session}.db"
        baseline = max((i for i, _, _ in inspect(db)), default=-1)
        failed = turn(wire, session, "F35-FAULT-PROBE.", "F35-FIXTURE-UPSTREAM-REJECTED", timeout=18)
        failed_steps = inspect(db, baseline)
        assert failed_steps and failed_steps[-1][1] == 17, [(i, k) for i, k, _ in failed_steps]
        assert b"F35-FIXTURE-UPSTREAM-REJECTED" in failed_steps[-1][2]
        assert 400 in server.responses
        success = turn(wire, session, "F35-ORDINARY-PROBE.", "F35-ORDINARY-TEXT", timeout=12)
        success_steps = inspect(db, failed_steps[-1][0])
        assert success["hasExpectedMarker"] and success_steps and success_steps[-1][1] != 17
        result = {"upstreamStatus": server.responses, "failedAcp": failed, "ordinaryAcp": success,
                  "failureNativeStepTypes": [step[1] for step in failed_steps],
                  "failureIsNewType17WithGatewayMarker": True,
                  "ordinaryNativeStepTypes": [step[1] for step in success_steps],
                  "successfulTurnHasNoNewErrorStep": all(step[1] != 17 for step in success_steps),
                  "isolatedSessionDatabaseReadOnly": True}
        (ROOT / "turn-failure-shapes.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2), flush=True)
    finally:
        wire.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)
