from http.server import ThreadingHTTPServer
import io
import json
from pathlib import Path
from tempfile import mkdtemp
from threading import Event, Thread
from urllib.parse import urlsplit

from agy_wire_helpers import check_model
from agy_scripted_model import ScriptedGemini
from gateway_probe import MODELS, ROOT


class CaptureShapes(ScriptedGemini):
    def do_POST(self):
        route = urlsplit(self.path)
        model = route.path.rsplit("/", 1)[-1].split(":", 1)[0]
        size = int(self.headers.get("Content-Length", "0"))
        if model not in MODELS or not 0 < size <= 512000:
            self.send_error(403)
            return
        body = self.rfile.read(size)
        request = json.loads(body)
        history = request.get("contents") or []
        formatting = [{"role": c.get("role"), "parts": [sorted(p)
                       for p in c.get("parts") or []]} for c in history]
        if any("functionResponse" in part for c in formatting for part in c["parts"]):
            self.server.shapes.append({"route": self.path, "requestFields": sorted(request),
                "generationFields": sorted(request.get("generationConfig") or {}),
                "tailOfHistory": formatting[-3:]})
        rfile = self.rfile
        try:
            self.rfile = io.BytesIO(body)
            super().do_POST()
        finally:
            self.rfile = rfile


if __name__ == "__main__":
    root = Path(mkdtemp(prefix="capture-tool-shapes-", dir=ROOT))
    server = ThreadingHTTPServer(("127.0.0.1", 0), CaptureShapes)
    server.shapes = []
    server.evidence = []
    server.cancel_ready = Event()
    server.release_cancel = Event()
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        endpoint = f"http://127.0.0.1:{server.server_port}"
        row = check_model(root / "carbon", MODELS[0], endpoint, True, lambda _row: None)
        assert row["toolWroteSyntheticResult"] and row["mcpTurn"]["hasExpectedMarker"], row
        assert server.shapes, row
        evidence = {"toolTurn": row["mcpTurn"], "shapes": server.shapes}
        (ROOT / "capture-tool-shapes.json").write_text(json.dumps(evidence, indent=2) + "\n")
        print(json.dumps(evidence, indent=2), flush=True)
    finally:
        server.release_cancel.set()
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)
