from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from hashlib import sha256
import json
from pathlib import Path
from tempfile import mkdtemp
from threading import Thread
from urllib.parse import urlsplit

from agy_wire_helpers import check_model
from gateway_probe import MODELS, ROOT


class CaptureRequest(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        route = urlsplit(self.path)
        model = route.path.rsplit("/", 1)[-1].split(":", 1)[0]
        if model not in MODELS:
            self.send_error(403)
            return
        size = int(self.headers.get("Content-Length", "0"))
        if not 0 < size <= 512000:
            self.send_error(400)
            return
        body = self.rfile.read(size)
        payload = json.loads(body)
        if model not in self.server.captures:
            self.server.captures[model] = {
                "route": self.path, "accept": self.headers.get("Accept"),
                "payload": payload,
            }
        marker = "F35-CARBON-R2" if model == MODELS[0] else "F35-ARGON-R2"
        response = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [{"text": marker}]},
                                    "finishReason": "STOP"}], "modelVersion": model,
                    "usageMetadata": {"promptTokenCount": 12, "candidatesTokenCount": 5, "totalTokenCount": 17}}
        data = b"data: " + json.dumps(response).encode() + b"\n\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def summarize(record):
    payload = record["payload"]
    system = payload.get("systemInstruction") or {}
    tools = payload.get("tools") or []
    return {
        "route": record["route"], "accept": record["accept"],
        "bodySha256": sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest(),
        "bodySize": len(json.dumps(payload).encode()),
        "systemSize": len(json.dumps(system).encode()),
        "generation": payload.get("generationConfig"),
        "toolNames": [declaration.get("name") for group in tools
                      for declaration in group.get("functionDeclarations", [])],
    }


if __name__ == "__main__":
    root = Path(mkdtemp(prefix="capture-native-", dir=ROOT))
    server = ThreadingHTTPServer(("127.0.0.1", 0), CaptureRequest)
    server.captures = {}
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        endpoint = f"http://127.0.0.1:{server.server_port}"
        for model in MODELS:
            row = check_model(root / model, model, endpoint, True, lambda _row: None, first_only=True)
            assert row["confirmedModel"] == model, row
            assert model in server.captures, row
        (ROOT / "captured-bodies.private.json").write_text(json.dumps(server.captures, indent=2) + "\n")
        report = {model: summarize(record) for model, record in server.captures.items()}
        (ROOT / "capture-summary.json").write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps(report, indent=2), flush=True)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)
