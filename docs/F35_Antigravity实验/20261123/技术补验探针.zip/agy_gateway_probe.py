from contextlib import contextmanager
from getpass import getpass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from tempfile import TemporaryFile, mkdtemp
from threading import Thread
import time
from urllib.parse import urlsplit

from acp_probe import ROOT
from agy_key_path_probe import RpcProcess, shape
from agy_observe_routes import handshake, summarize_config
from gateway_probe import BASE, MODELS
from gateway_retry import scrub


class Relay(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def respond(self, status, hint):
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps({"error": {"code": status, "message": hint}}).encode())

    def do_POST(self):
        route = urlsplit(self.path)
        match = re.fullmatch(r"/v1beta/models/([\w.-]+):(streamGenerateContent|generateContent)", route.path)
        model = match.group(1) if match else None
        row = {"model": model, "operation": match.group(2) if match else None}
        self.server.evidence.append(row)
        if model not in MODELS or route.query not in ("", "alt=sse"):
            row["blockedByFixture"] = True
            self.respond(403, "F35 fixture allows only the two approved models.")
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            size = 0
        if size < 1 or size > 512000:
            self.respond(400, "F35 fixture rejected request size.")
            return
        body = self.rfile.read(size)
        payload = json.loads(body)
        row["requestFields"] = sorted(payload)
        row["generationFields"] = sorted(payload.get("generationConfig") or {})
        row["toolGroups"] = len(payload.get("tools") or [])
        use_single_frame = self.server.translate and match.group(2) == "streamGenerateContent"
        upstream_path = route.path.replace(":streamGenerateContent", ":generateContent") if use_single_frame else self.path
        if use_single_frame:
            row["upstreamProtocol"] = "generateContent"
        key = self.server.credential
        headers = (f"Content-Type: application/json\nx-goog-api-key: {key}\n"
                   f"Authorization: Bearer {key}\n").encode()
        started = time.monotonic()
        with TemporaryFile(dir=ROOT) as request:
            request.write(body)
            request.seek(0)
            fd = request.fileno()
            curl = subprocess.Popen(
                ["/usr/bin/curl", "-q", "-sS", "-i", "--suppress-connect-headers", "--no-buffer",
                 "--proto", "=https", "--connect-timeout", "12", "--max-time", "75", "--max-filesize", "1000000",
                 "--header", "@-", "--data-binary", f"@/dev/fd/{fd}", BASE + upstream_path],
                pass_fds=(fd,), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            )
            try:
                curl.stdin.write(headers)
                curl.stdin.close()
                first = curl.stdout.readline()
                status = re.match(rb"HTTP/[\d.]+\s+(\d+)", first)
                if not status:
                    row["curlExit"] = curl.wait(timeout=3)
                    self.respond(502, "No HTTPS response from the test gateway.")
                    return
                row["http"] = int(status.group(1))
                row["upstreamFirstByteMs"] = round((time.monotonic() - started) * 1000)
                content_type = "application/json"
                while line := curl.stdout.readline():
                    if not line.strip():
                        break
                    if line.lower().startswith(b"content-type:"):
                        value = line.split(b":", 1)[1].strip()
                        if value.startswith(b"text/event-stream"):
                            content_type = "text/event-stream"
                if use_single_frame or row["http"] >= 400:
                    raw = curl.stdout.read(1000001)
                    try:
                        response = json.loads(raw)
                    except (ValueError, UnicodeDecodeError):
                        response = {}
                    if row["http"] >= 400:
                        error = response.get("error") if isinstance(response, dict) else None
                        reason = error.get("message") if isinstance(error, dict) else None
                        if not reason and isinstance(response, dict):
                            reason = response.get("message") or response.get("detail")
                        if isinstance(reason, str):
                            row["providerReason"] = scrub(reason, self.server.credential)
                    elif isinstance(response, dict) and response.get("candidates"):
                        raw = b"data: " + json.dumps(response).encode() + b"\n\n"
                        content_type = "text/event-stream"
                    self.send_response(row["http"])
                    self.send_header("Content-Type", content_type)
                    self.end_headers()
                    self.wfile.write(raw)
                    self.wfile.flush()
                    row["forwardedBodyBytes"] = len(raw)
                    row["curlExit"] = curl.wait(timeout=3)
                    return
                self.send_response(row["http"])
                self.send_header("Content-Type", content_type)
                self.end_headers()
                row["forwardedBodyBytes"] = 0
                while part := curl.stdout.read1(65536):
                    self.wfile.write(part)
                    self.wfile.flush()
                    row["forwardedBodyBytes"] += len(part)
                row["curlExit"] = curl.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                row["clientDisconnected"] = True
            finally:
                if curl.poll() is None:
                    curl.kill()
                    curl.wait(timeout=3)
                row["elapsedMs"] = round((time.monotonic() - started) * 1000)
                curl.stdout.close()


@contextmanager
def relay(credential, evidence, translate=False):
    server = ThreadingHTTPServer(("127.0.0.1", 0), Relay)
    server.credential = credential
    server.evidence = evidence
    server.translate = translate
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)


def turn(wire, session, prompt, expected, timeout=79):
    before = len(wire.notifications)
    started = time.monotonic()
    response = wire.call("session/prompt", {"sessionId": session,
        "prompt": [{"type": "text", "text": prompt}]}, timeout=timeout)
    updates = [event.get("params", {}).get("update", {}) for event in wire.notifications[before:]
               if event.get("method") == "session/update"]
    chunks = [event.get("content", {}).get("text", "") for event in updates
              if event.get("sessionUpdate") == "agent_message_chunk"]
    row = {"elapsedMs": round((time.monotonic() - started) * 1000),
           "outcome": shape(response)["outcome"],
           "stopReason": (response.get("result") or {}).get("stopReason"),
           "assistantChunkCount": len(chunks),
           "hasExpectedMarker": expected in "".join(chunks),
           "sessionUpdateTypes": sorted({entry.get("sessionUpdate") for entry in updates if entry.get("sessionUpdate")})}
    return row


def open_wire(args, cwd, env, approval_log, allow_fixture_tool=True):
    wire = RpcProcess(args, cwd, env)

    def answer(request):
        if request["method"] != "session/request_permission":
            return {"error": {"code": -32601, "message": "Fixture only accepts a permission request."}}
        params = request.get("params") or {}
        is_fixture_tool = "report_probe" in json.dumps(params.get("toolCall") or {})
        option = next((item for item in params.get("options") or [] if item.get("kind") == "allow_once"), None)
        if is_fixture_tool and not allow_fixture_tool:
            deny = next((item for item in params.get("options") or [] if item.get("kind") == "reject_once"), None)
            approval_log.append("deny_once_for_report_probe")
            if deny:
                return {"result": {"outcome": {"outcome": "selected", "optionId": deny["optionId"]}}}
            return {"result": {"outcome": {"outcome": "cancelled"}}}
        if is_fixture_tool and option:
            approval_log.append("allow_once_for_report_probe")
            return {"result": {"outcome": {"outcome": "selected", "optionId": option["optionId"]}}}
        approval_log.append("cancel_other_request")
        return {"result": {"outcome": {"outcome": "cancelled"}}}

    wire.answer_request = answer
    return wire


def check_model(workspace, candidate, endpoint, expect_extra, publish, allow_fixture_tool=True, cancel_ready=None):
    home = workspace / "home"
    cwd = workspace / "project"
    for path in (home, home / "tmp", cwd):
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home), "TMPDIR": str(home / "tmp"),
           "XDG_CONFIG_HOME": str(home / "config"), "XDG_CACHE_HOME": str(home / "cache"),
           "XDG_DATA_HOME": str(home / "data"), "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
           "GEMINI_API_KEY": "F35-DUMMY-CREDENTIAL-RELAY-OWNS-REAL-KEY", "GOOGLE_GEMINI_BASE_URL": endpoint,
           "NO_PROXY": "127.0.0.1", "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1"}
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    trace = workspace / "mcp.txt"
    trace.write_text("")
    servers = [{"name": "f35_probe_tools", "command": sys.executable,
                "args": [str(ROOT / "mcp_fixture.py"), str(trace)], "env": []}] if expect_extra else []
    approvals = []
    wire = open_wire(args, cwd, env, approvals, allow_fixture_tool)
    marker = "F35-CARBON-R2" if expect_extra else "F35-ARGON-R2"
    remember = f"Remember identifier {marker}. Reply with only that identifier. Do not call tools."
    row = {"model": candidate, "fixtureApprovals": approvals}
    try:
        row.update(handshake(wire))
        if row["authenticate"]["outcome"] != "ok":
            return row
        opened = wire.call("session/new", {"cwd": str(cwd), "mcpServers": servers})
        row["sessionNew"] = shape(opened)
        session = (opened.get("result") or {}).get("sessionId")
        if not session:
            return row
        chosen = wire.call("session/set_config_option", {"sessionId": session, "configId": "model", "value": candidate})
        row["confirmedModel"] = summarize_config(chosen, "model")["currentValue"]
        if row["confirmedModel"] != candidate:
            return row
        effort = wire.call("session/set_config_option", {"sessionId": session, "configId": "thought_level", "value": "low"})
        row["effort"] = summarize_config(effort, "thought_level")
        row["firstTurn"] = turn(wire, session, remember, marker)
        publish(row)
        if expect_extra and row["firstTurn"]["hasExpectedMarker"]:
            wire.close()
            wire = None
            wire = open_wire(args, cwd, env, approvals, allow_fixture_tool)
            row["freshProcess"] = handshake(wire)
            resumed = wire.call("session/resume", {"sessionId": session, "cwd": str(cwd), "mcpServers": servers})
            row["resume"] = shape(resumed)
            if row["resume"]["outcome"] == "ok":
                chosen = wire.call("session/set_config_option",
                                   {"sessionId": session, "configId": "model", "value": candidate})
                row["modelAfterReapply"] = summarize_config(chosen, "model")["currentValue"]
                row["followup"] = turn(wire, session, "Reply with the identifier I asked you to remember.", marker)
                publish(row)
                row["mcpTurn"] = turn(wire, session, "Call the report_probe MCP tool with value F35-PROBE-OK. "
                                     "Reply with only the exact tool result. Use only this tool.", "F35-MCP-FIXTURE")
        if cancel_ready is not None:
            def cancel():
                if cancel_ready.wait(timeout=7):
                    wire.write({"method": "session/cancel", "params": {"sessionId": session}})
            watcher = Thread(target=cancel, daemon=True)
            watcher.start()
            row["cancelTurn"] = turn(wire, session, "Wait for F35-TEST-CANCEL.", "F35-CANCEL-LATE", timeout=8)
            watcher.join(timeout=1)
        row["mcpMethods"] = trace.read_text().splitlines()
        row["toolWroteSyntheticResult"] = trace.with_suffix(".result").exists()
        return row
    finally:
        if wire is not None:
            wire.close()


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required to protect the credential.")
    key = getpass("Gateway credential (hidden): ")
    if not key or any(c.isspace() for c in key) or not key.isascii():
        raise SystemExit("Missing or invalid credential input.")
    tmp = Path(mkdtemp(dir=ROOT, prefix="agy-live-"))
    translate = "--carbon-nonstream" in sys.argv[1:]
    carbon_only = "--carbon-only" in sys.argv[1:]
    candidates = MODELS[:1] if translate or carbon_only else MODELS
    evidence_file = ("agy-carbon-nonstream-evidence.json" if translate else
                     "agy-carbon-live-closeout.json" if carbon_only else "agy-gateway-evidence.json")
    upstream = []
    results = []

    def publish(row=None):
        present = results + ([row] if row is not None else [])
        report = {"testMode": "real-agy-and-authorized-gateway-via-scoped-relay", "credentialPassedToAgy": False, "singleSseFrameTranslation": translate,
                  "allowedModels": list(MODELS), "results": present, "upstreamRequests": upstream}
        (ROOT / evidence_file).write_text(json.dumps(report, indent=2) + "\n")
        if row and "firstTurn" in row:
            print(json.dumps({"model": row["model"], "firstTurn": row["firstTurn"],
                              "followup": row.get("followup")}), flush=True)

    with relay(key, upstream, translate) as endpoint:
        for candidate in candidates:
            results.append(check_model(tmp / candidate, candidate, endpoint, candidate == MODELS[0], publish))
            publish()
    publish()
    print((ROOT / evidence_file).read_text(), flush=True)

