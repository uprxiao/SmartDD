from http.server import ThreadingHTTPServer
import json
from pathlib import Path
from tempfile import mkdtemp
from threading import Event, Thread
from time import monotonic
import sys

from acp_probe import ROOT
from agy_gateway_probe import open_wire, turn
from agy_key_path_probe import shape
from agy_observe_routes import handshake, summarize_config
from agy_scripted_model import ScriptedGemini
from gateway_probe import MODELS


def run_model(workspace, model, endpoint, check_late_approval):
    home = workspace / "home"
    cwd = workspace / "project"
    for path in (home, home / "tmp", cwd):
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
    env = {
        "PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "HOME": str(home),
        "TMPDIR": str(home / "tmp"), "XDG_CONFIG_HOME": str(home / "config"),
        "XDG_CACHE_HOME": str(home / "cache"), "XDG_DATA_HOME": str(home / "data"),
        "LANG": "en_US.UTF-8", "BROWSER": "/usr/bin/false",
        "GEMINI_API_KEY": "F35-DUMMY-CREDENTIAL-LOCAL-FIXTURE",
        "GOOGLE_GEMINI_BASE_URL": endpoint,
        "NO_PROXY": "127.0.0.1", "HTTPS_PROXY": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1",
    }
    args = ["acp", "--gemini-dir", str(home / ".gemini"), "--app-data-dir", "antigravity-acp",
            "--disable-telemetry=true", "--include-default-customizations=false", "--sandbox=true"]
    trace = workspace / "mcp.txt"
    trace.write_text("")
    servers = [{"name": "f35_probe_tools", "command": sys.executable,
                "args": [str(ROOT / "mcp_fixture.py"), str(trace)], "env": []}]
    approvals = []
    wire = None
    marker = "F35-CARBON-R2" if model == MODELS[0] else "F35-ARGON-R2"
    selected_effort = "medium" if model == MODELS[0] else "high"

    def connect():
        client = open_wire(args, cwd, env, approvals)
        hello = handshake(client)
        if hello["authenticate"]["outcome"] != "ok":
            client.close()
            raise RuntimeError(f"Authentication failed in local fixture: {hello['authenticate']}")
        return client

    def set_value(config_id, value):
        answer = wire.call("session/set_config_option",
                           {"sessionId": session, "configId": config_id, "value": value})
        return summarize_config(answer, config_id)["currentValue"]

    try:
        wire = connect()
        setup = {"cwd": str(cwd), "mcpServers": servers}
        started = monotonic()
        opened = wire.call("session/new", setup)
        open_ms = round((monotonic() - started) * 1000)
        session = (opened.get("result") or {}).get("sessionId")
        assert session, shape(opened)
        assert set_value("model", model) == model
        efforts = {value: set_value("thought_level", value) for value in ("low", "medium", "high")}
        assert efforts == {value: value for value in ("low", "medium", "high")}, efforts
        assert set_value("thought_level", selected_effort) == selected_effort
        first = turn(wire, session, f"Remember identifier {marker}. Reply with only that identifier.", marker)
        warm = turn(wire, session, "Reply with the identifier I asked you to remember.", marker)
        assert all(item["hasExpectedMarker"] and item["stopReason"] == "end_turn" for item in (first, warm))
        wire.close()
        wire = connect()
        started = monotonic()
        resumed = wire.call("session/resume", {**setup, "sessionId": session})
        resume_ms = round((monotonic() - started) * 1000)
        assert isinstance(resumed.get("result"), dict), shape(resumed)
        model_after = set_value("model", model)
        effort_after = set_value("thought_level", selected_effort)
        assert (model_after, effort_after) == (model, selected_effort)
        cold = turn(wire, session, "Reply with the identifier I asked you to remember.", marker)
        assert cold["hasExpectedMarker"] and cold["stopReason"] == "end_turn", cold
        result = {
            "model": model, "effortAcknowledgements": efforts, "sessionNewMs": open_ms,
            "first": first, "warm": warm, "cold": cold, "coldResumeMs": resume_ms,
            "modelAfterReapply": model_after, "effortAfterReapply": effort_after,
        }
        if check_late_approval:
            deferred = {}
            answer_default = wire.answer_request

            def defer(request):
                params = request.get("params") or {}
                if request["method"] != "session/request_permission" or "report_probe" not in json.dumps(params):
                    return answer_default(request)
                assert params.get("sessionId") == session
                option = next(item for item in params["options"] if item["kind"] == "allow_once")
                deferred.update(id=request["id"], option=option["optionId"])
                wire.write({"method": "session/cancel", "params": {"sessionId": session}})
                return None

            wire.answer_request = defer
            canceled = turn(wire, session, "Call the report_probe MCP tool with value F35-PROBE-OK.",
                            "F35-MCP-FIXTURE", timeout=12)
            assert deferred and canceled["stopReason"] == "cancelled", canceled
            wire.write({"id": deferred["id"], "result": {"outcome": {"outcome": "selected", "optionId": deferred["option"]}}})
            wire.answer_request = answer_default
            subsequent = turn(wire, session, "Reply with the identifier I asked you to remember.", marker)
            assert subsequent["hasExpectedMarker"] and subsequent["stopReason"] == "end_turn", subsequent
            methods = trace.read_text().splitlines()
            assert "tools/list" in methods and "tools/call" not in methods
            assert not trace.with_suffix(".result").exists()
            result["pendingApprovalCancellation"] = {
                "canceled": canceled,
                "lateApprovalSentAfterCancel": True, "fixtureToolCallCount": methods.count("tools/call"),
                "resultFileExists": False, "subsequent": subsequent,
            }
        return result
    finally:
        if wire is not None:
            wire.close()


if __name__ == "__main__":
    root = Path(mkdtemp(prefix="protocol-closeout-", dir=ROOT))
    server = ThreadingHTTPServer(("127.0.0.1", 0), ScriptedGemini)
    server.evidence = []
    server.cancel_ready = Event()
    server.release_cancel = Event()
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        endpoint = f"http://127.0.0.1:{server.server_port}"
        rows = [run_model(root / model, model, endpoint, model == MODELS[1]) for model in MODELS]
        for model in MODELS:
            follows = [row for row in server.evidence if row["model"] == model and row["step"] == "resume_history"]
            assert len(follows) >= 2 and all(row["previousMarkerInRequest"] for row in follows), follows
        report = {"testMode": "real-agy-with-scripted-local-model", "results": rows, "requestSummary": server.evidence}
        (ROOT / "protocol-closeout.json").write_text(json.dumps(report, indent=2) + "\n")
        for row in rows:
            print(json.dumps({"model": row["model"], "warm": row["warm"]["stopReason"],
                              "cold": row["cold"]["stopReason"], "effort": row["effortAfterReapply"],
                              "pendingApprovalCancellation": "pendingApprovalCancellation" in row}), flush=True)
    finally:
        server.release_cancel.set()
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)
