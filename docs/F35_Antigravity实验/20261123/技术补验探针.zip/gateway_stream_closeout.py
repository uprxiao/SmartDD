from concurrent.futures import ThreadPoolExecutor
from getpass import getpass
import json
import subprocess
import sys
from time import monotonic

from gateway_probe import BASE, MARKER, MODELS, ROOT, TEXT, as_object
from gateway_retry import scrub


def run(credential, model, tool=False):
    parts = [{"text": "Call f35_echo with value F35-PROBE-OK." if tool else TEXT}]
    body = {"contents": [{"role": "user", "parts": parts}],
            "generationConfig": {"maxOutputTokens": 384}}
    if tool:
        body["tools"] = [{"functionDeclarations": [{"name": "f35_echo", "description": "Echo a test marker.",
                         "parameters": {"type": "OBJECT", "properties": {"value": {"type": "STRING"}},
                                        "required": ["value"]}}]}]
        body["toolConfig"] = {"functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": ["f35_echo"]}}
    url = BASE + f"/v1beta/models/{model}:streamGenerateContent?alt=sse"
    headers = ("Content-Type: application/json\nAccept: text/event-stream\n"
               f"x-goog-api-key: {credential}\nAuthorization: Bearer {credential}\n")
    started = monotonic()
    sent = subprocess.run(
        ["/usr/bin/curl", "-q", "-sS", "--proto", "=https", "--max-time", "44",
         "--connect-timeout", "8", "--max-filesize", "512000", "--header", "@-",
         "--data-binary", json.dumps(body), "--write-out", "\n%{http_code}\n%{time_starttransfer}", url],
        input=headers.encode(), capture_output=True, timeout=46,
    )
    payload_and_status, _, first_byte = sent.stdout.rpartition(b"\n")
    payload, _, http = payload_and_status.rpartition(b"\n")
    status = int(http) if http.isdigit() else 0
    row = {"model": model, "probe": "tool_call" if tool else "text", "http": status, "curlExit": sent.returncode,
           "durationMs": round((monotonic() - started) * 1000)}
    if status == 200:
        frames = []
        for line in payload.splitlines():
            if line.startswith(b"data:") and line[5:].strip() != b"[DONE]":
                try:
                    frames.append(json.loads(line[5:].strip()))
                except ValueError:
                    continue
        candidates = [as_object(candidate) for frame in frames for candidate in as_object(frame).get("candidates") or []]
        texts = [as_object(part) for candidate in candidates
                 for part in as_object(candidate.get("content")).get("parts") or []]
        calls = [as_object(part.get("functionCall")) for part in texts]
        matched = (any(call.get("name") == "f35_echo" and as_object(call.get("args")).get("value") == MARKER
                       for call in calls) if tool else
                   MARKER in "".join(part["text"] for part in texts if isinstance(part.get("text"), str)))
        row.update(sseFrames=len(frames), expectedReplyOrCall=matched,
                   firstByteMs=round(float(first_byte) * 1000) if first_byte else 0)
        row["passed"] = bool(matched and frames and sent.returncode == 0)
    else:
        row["passed"] = False
        try:
            envelope = as_object(json.loads(payload))
        except ValueError:
            envelope = {}
        error = as_object(envelope.get("error"))
        reason = error.get("message") or envelope.get("message")
        if reason:
            row["reason"] = scrub(reason, credential)
    return row


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required to protect the credential.")
    credential = getpass("Model Hub credential (hidden): ")
    if not credential or any(c.isspace() for c in credential) or not credential.isascii():
        raise SystemExit("Missing or invalid credential input.")
    with ThreadPoolExecutor(max_workers=2) as pool:
        plain = list(pool.map(lambda model: run(credential, model), MODELS))
        allowed = [row["model"] for row in plain if row["passed"]]
        tools = list(pool.map(lambda model: run(credential, model, tool=True), allowed))
    report = {"scope": list(MODELS), "results": plain + tools,
              "toolProbesWaitingForText": [model for model in MODELS if model not in allowed]}
    (ROOT / "gateway-stream-closeout.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)
