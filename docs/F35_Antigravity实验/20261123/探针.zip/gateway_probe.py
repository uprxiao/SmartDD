from concurrent.futures import ThreadPoolExecutor
from getpass import getpass
import json
from pathlib import Path
import re
import subprocess
import sys
import time


BASE = "https://rjmodel.rjupc.com"
MODELS = ("gemini-4-carbon", "gemini-4-argon")
MARKER = "F35-PROBE-OK"
TEXT = f"Reply with exactly {MARKER}. Do not call tools."
ROOT = Path(__file__).resolve().parent


def safe_label(value):
    if (isinstance(value, str) and not value.lower().startswith(("sk-", "ya29.", "aiza"))
            and re.fullmatch(r"[A-Za-z0-9_.:/-]{1,96}", value)):
        return value
    return None


def as_object(value):
    return value if isinstance(value, dict) else {}


def request(key, api, route, model=None, body=None, native=False):
    started = time.monotonic()
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if native:
        headers["x-goog-api-key"] = key
    else:
        headers["Authorization"] = "Bearer " + key
    payload = None if body is None else json.dumps(body)
    args = ["/usr/bin/curl", "-q", "--silent", "--show-error", "--proto", "=https",
            "--connect-timeout", "8", "--max-time", "24", "--max-filesize", "512000",
            "--header", "@-", "--write-out", "\\n%{http_code}", BASE + route]
    if payload is not None:
        args.extend(["--data-binary", payload])
    row = {"api": api, "route": route, "requestedModel": model}
    sent_headers = "".join(f"{name}: {value}\n" for name, value in headers.items())
    response = subprocess.run(args, input=sent_headers.encode(), capture_output=True, timeout=26)
    content, _, code = response.stdout.rpartition(b"\n")
    if response.returncode != 0:
        row["transportError"] = f"curl_exit_{response.returncode}"
        row["elapsedMs"] = round((time.monotonic() - started) * 1000)
        return row
    row["http"] = int(code)
    row["elapsedMs"] = round((time.monotonic() - started) * 1000)
    try:
        data = as_object(json.loads(content))
    except (ValueError, UnicodeDecodeError):
        row["format"] = "non-json"
        return row
    row["format"] = "json"
    error = as_object(data.get("error"))
    if error:
        row["errorCode"] = safe_label(error.get("code")) or safe_label(error.get("status"))
        row["errorType"] = safe_label(error.get("type"))
        message = str(error.get("message", "")).lower()
        row["errorHints"] = [hint for hint, needles in {
            "unsupported_model_or_channel": ("model", "模型", "channel", "渠道"),
            "authentication": ("unauthorized", "invalid api key", "api key not valid", "无效的令牌", "令牌"),
            "insufficient_quota": ("quota", "insufficient", "余额"),
            "method_or_route": ("unsupported", "not found", "invalid url", "不存在"),
            "validation": ("invalid parameter", "required", "unsupported parameter", "参数"),
        }.items() if any(needle in message for needle in needles)]
        return row
    if api.endswith("models"):
        entries = data.get("data") if api == "openai_models" else data.get("models")
        row["catalogShape"] = isinstance(entries, list)
        ids = {str(e.get("id") or e.get("name", "")).removeprefix("models/") for e in (entries or []) if isinstance(e, dict)}
        row["requestedModelsInCatalog"] = [candidate for candidate in MODELS if candidate in ids]
        return row
    row["returnedModel"] = safe_label(data.get("model")) or safe_label(data.get("modelVersion"))
    if api == "openai_chat" or api == "openai_tool":
        choices = data.get("choices") or []
        choice = as_object(choices[0]) if isinstance(choices, list) and choices else {}
        msg = as_object(choice.get("message"))
        row["finish"] = safe_label(choice.get("finish_reason"))
        row["expectedReply"] = MARKER in (msg.get("content") or "") if isinstance(msg.get("content"), str) else False
        calls = msg.get("tool_calls") or []
        row["expectedToolCall"] = False
        for entry in calls if isinstance(calls, list) else []:
            call = as_object(as_object(entry).get("function"))
            if call.get("name") == "report_probe":
                try:
                    row["expectedToolCall"] = as_object(json.loads(call.get("arguments", "{}"))).get("value") == MARKER
                except (ValueError, TypeError):
                    pass
    elif api == "openai_responses":
        row["finish"] = safe_label(data.get("status"))
        parts = [str(part.get("text", "")) for item in data.get("output", [])
                 if isinstance(item, dict) and item.get("type") == "message"
                 for part in item.get("content", []) if isinstance(part, dict)]
        row["expectedReply"] = MARKER in "".join(parts)
    elif api == "gemini_generate":
        candidates = data.get("candidates") or []
        first = as_object(candidates[0]) if isinstance(candidates, list) and candidates else {}
        row["finish"] = safe_label(first.get("finishReason"))
        parts = as_object(first.get("content")).get("parts") or []
        row["expectedReply"] = MARKER in "".join(str(part.get("text", "")) for part in parts if isinstance(part, dict))
    return row


def build_calls():
    calls = [("openai_models", "/v1/models"), ("gemini_models", "/v1beta/models", None, None, True)]
    tool = {
        "type": "function",
        "function": {
            "name": "report_probe",
            "description": "Return the supplied synthetic probe marker.",
            "parameters": {"type": "object", "properties": {"value": {"type": "string"}},
                           "required": ["value"], "additionalProperties": False},
        },
    }
    for model in MODELS:
        calls.extend([
            ("openai_chat", "/v1/chat/completions", model,
             {"model": model, "messages": [{"role": "user", "content": TEXT}], "max_tokens": 256}),
            ("gemini_generate", f"/v1beta/models/{model}:generateContent", model,
             {"contents": [{"role": "user", "parts": [{"text": TEXT}]}],
              "generationConfig": {"maxOutputTokens": 256}}, True),
            ("openai_responses", "/v1/responses", model, {"model": model, "input": TEXT, "max_output_tokens": 256}),
            ("openai_tool", "/v1/chat/completions", model,
             {"model": model, "messages": [{"role": "user", "content": f"Call report_probe with value {MARKER}."}],
              "tools": [tool], "tool_choice": {"type": "function", "function": {"name": "report_probe"}}, "max_tokens": 256}),
        ])
    return calls


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required to protect the credential.")
    credential = getpass("Gateway credential (hidden): ")
    if not credential or not credential.isascii() or any(c.isspace() for c in credential):
        raise SystemExit("Missing or invalid credential input.")
    with ThreadPoolExecutor(max_workers=4) as pool:
        evidence = list(pool.map(lambda args: request(credential, *args), build_calls()))
    report = {"endpoint": BASE, "models": list(MODELS), "results": evidence}
    (ROOT / "gateway-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2), flush=True)

