import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { readFile, mkdtemp, stat, writeFile } from 'node:fs/promises';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';

const here = dirname(fileURLToPath(import.meta.url));
const staticRoot = resolve(here, process.env.F35_PROTOTYPE_DIR ?? 'prototype-dist');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2' };
const server = createServer(async (request, response) => {
  const path = new URL(request.url, 'http://localhost').pathname;
  const filename = resolve(staticRoot, '.' + (path === '/' ? '/index.html' : path));
  if (!filename.startsWith(staticRoot + '/')) return response.writeHead(404).end();
  try {
    if (!(await stat(filename)).isFile()) throw Error('not a file');
  } catch {
    return response.writeHead(404).end();
  }
  response.writeHead(200, { 'Content-Type': types[extname(filename)] ?? 'application/octet-stream' });
  createReadStream(filename).pipe(response);
});
server.listen(0, '127.0.0.1');
await once(server, 'listening');
const base = 'http://127.0.0.1:' + server.address().port;

const chromeHome = await mkdtemp(join(here, 'f35-chrome-'));
const chrome = spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', [
  '--headless=new', '--no-first-run', '--disable-background-networking',
  '--disable-gpu', '--remote-debugging-port=0', '--window-size=1400,1040',
  '--user-data-dir=' + chromeHome, 'about:blank',
], { stdio: 'ignore' });

async function until(action, name, timeout = 11000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const value = await action();
    if (value) return value;
    await sleep(65);
  }
  throw Error('Timed out: ' + name);
}

let socket;
let send;
try {
  const port = await until(async () => {
    try {
      return (await readFile(join(chromeHome, 'DevToolsActivePort'), 'utf8')).split('\n')[0];
    } catch { return null; }
  }, 'Chrome CDP ready');
  const pages = await fetch('http://127.0.0.1:' + port + '/json/list').then(r => r.json());
  socket = new WebSocket(pages.find(page => page.type === 'page').webSocketDebuggerUrl);
  await Promise.race([once(socket, 'open'), sleep(5000).then(() => { throw Error('CDP connection timeout'); })]);
  const pending = new Map();
  const errors = [];
  let nextId = 0;

  socket.addEventListener('message', message => {
    const result = JSON.parse(message.data);
    if (result.method === 'Runtime.exceptionThrown') errors.push(result.params.exceptionDetails.text);
    const call = pending.get(result.id);
    if (!call) return;
    pending.delete(result.id);
    clearTimeout(call.timer);
    if (result.error) call.reject(Error(result.error.message));
    else call.resolve(result.result);
  });
  send = (method, params = {}) => new Promise((resolve, reject) => {
    const id = ++nextId;
    const timer = setTimeout(() => {
      pending.delete(id);
      reject(Error('CDP timeout: ' + method));
    }, 6000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params }));
  });
  const observe = async expression => {
    const result = await send('Runtime.evaluate', { expression, returnByValue: true });
    if (result.exceptionDetails) throw Error('Read-only browser expression failed.');
    return result.result.value;
  };
  const pageText = () => observe('document.body?.innerText ?? ""');
  const see = text => until(async () => (await pageText()).includes(text), text);
  const screenshot = async name => {
    const { data } = await send('Page.captureScreenshot', { format: 'png' });
    await writeFile(join(here, name), Buffer.from(data, 'base64'));
  };
  async function click(selector, contains, name) {
    const p = await until(() => observe(
      '(() => { const el = [...document.querySelectorAll(' + JSON.stringify(selector) + ')].find(e => !e.disabled && (' +
      JSON.stringify(contains) + ' === null || e.innerText.includes(' + JSON.stringify(contains) + ')) && e.getClientRects().length);' +
      'if (!el) return null; const b = el.getBoundingClientRect(); const x=b.x+b.width/2,y=b.y+b.height/2;' +
      'const top=document.elementFromPoint(x,y);return top && el.contains(top) ? {x,y} : null; })()'
    ), name);
    await send('Input.dispatchMouseEvent', { type: 'mousePressed', ...p, button: 'left', clickCount: 1 });
    await send('Input.dispatchMouseEvent', { type: 'mouseReleased', ...p, button: 'left', clickCount: 1 });
  }

  await send('Runtime.enable');
  await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride', { width: 1400, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send('Page.navigate', { url: base + '/?preview=m14&f35=1&theme=light#settings/ai/configs' });
  await see('F35 接入原型');
  await click('button', '新建智能体', 'Open the existing Agent dialog');
  await click('[role="radio"]', 'Antigravity', 'Select Antigravity');
  await see('ACP v1 握手通过');
  await screenshot('f35-agent-entry.png');

  await click('button', '添加供应商', 'Open the Provider catalog from the Agent dialog');
  await click('button.m13-cat-item', 'Model Hub', 'Select the existing Model Hub entry');
  await see('Gemini 原生');
  await screenshot('f35-provider-native.png');
  await click('input[aria-label="Model Hub Key"]', null, 'Focus the demo key field');
  await send('Input.insertText', { text: 'demo-f35-key' });
  await click('button', '获取模型', 'Fetch the synthetic Gemini catalog');
  await see('gemini-4-carbon');
  await see('gemini-4-argon');

  await send('Page.navigate', { url: base + '/?preview=m14&f35=1&theme=light#task/build' });
  await until(() => observe('Boolean(document.querySelector(".m14-pill-btn"))'), 'Existing unified task composer');
  const before = await observe('document.querySelector(".m14-pill-btn").innerText');
  assert.ok(!before.includes('Antigravity'));
  await click('button.m14-pill-btn', null, 'Open the existing task model menu');
  await click('button[title*="Antigravity"]', null, 'Pick the Antigravity profile');
  await see('gemini-4-carbon');
  await screenshot('f35-existing-task-switch.png');
  await click('button.m14-model-row', 'gemini-4-carbon', 'Switch the existing task to Gemini');
  await until(() => observe('document.querySelector(".m14-pill-btn")?.innerText.includes("Antigravity")'), 'Task model pill switched');
  const after = await observe('document.querySelector(".m14-pill-btn").innerText');
  assert.ok(after.includes('gemini-4-carbon'));
  assert.deepEqual(errors, []);
  const result = { chrome: 'isolated headless', preview: '?preview=m14&f35=1', before, after,
    providerEntryAndModelDiscovery: true, runtimeErrors: errors.length, classification: 'synthetic prototype' };
  await writeFile(join(here, 'f35-prototype-evidence.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
} finally {
  if (send && socket.readyState === WebSocket.OPEN) {
    await Promise.race([send('Browser.close').catch(() => {}), sleep(1000)]);
    socket.close();
  }
  if (chrome.exitCode === null) {
    chrome.kill('SIGTERM');
    await Promise.race([once(chrome, 'exit'), sleep(2000)]);
  }
  server.close();
}

