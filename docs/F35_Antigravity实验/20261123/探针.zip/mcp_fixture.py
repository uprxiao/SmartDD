import json
from pathlib import Path
import sys


trace = Path(sys.argv[1])
tool = {"name": "report_probe", "description": "Echo a synthetic F35 marker.", "inputSchema": {
    "type": "object", "properties": {"value": {"type": "string"}}, "required": ["value"],
}}


for line in sys.stdin:
    message = json.loads(line)
    method = message.get("method")
    if method not in {"initialize", "notifications/initialized", "tools/list", "tools/call", "ping"}:
        if "id" in message:
            print(json.dumps({"jsonrpc": "2.0", "id": message["id"],
                              "error": {"code": -32601, "message": "Unsupported fixture method"}}), flush=True)
        continue
    with trace.open("a") as out:
        out.write(method + "\n")
    if "id" not in message:
        continue
    result = {}
    if method == "initialize":
        result = {"protocolVersion": message["params"]["protocolVersion"],
                  "capabilities": {"tools": {}}, "serverInfo": {"name": "f35-local-probe", "version": "1"}}
    elif method == "tools/list":
        result = {"tools": [tool]}
    elif method == "tools/call":
        trace.with_suffix(".result").write_text("F35-MCP-FIXTURE\n")
        result = {"content": [{"type": "text", "text": "F35-MCP-FIXTURE"}]}
    print(json.dumps({"jsonrpc": "2.0", "id": message["id"], "result": result}), flush=True)

