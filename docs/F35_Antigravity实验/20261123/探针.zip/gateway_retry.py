from concurrent.futures import ThreadPoolExecutor
from getpass import getpass
import json
import re
import subprocess
import sys
import time

from gateway_probe import BASE, MODELS, MARKER, ROOT, TEXT, as_object, safe_label


def scrub(text, credential):
    text = str(text).replace(credential, "<credential>")
    text = re.sub(
        r"(?i)\b(?:sk-[\w-]+|aiza[\w-]+|bearer\s+[\w./+-]+|ya29\.[\w.-]+)\b",
        "<credential>", text,
    )
    text = re.sub(r"https?://[^\s\"\'<>]+", "<url>", text)
    text = re.sub(r"(?:[\w.+-]+)@(?:[\w.-]+\.[A-Za-z]{2,})", "<account>", text)
    return " ".join(text.split())[:260]


def try_request(credential, model, protocol):
    if protocol == "openai_sse":
        path = "/v1/chat/completions"
        auth = f"Authorization: Bearer {credential}\n"
        body = {"model": model, "messages": [{"role": "user", "content": TEXT}],
                "stream": True, "max_tokens": 256}
    else:
        path = f"/v1beta/models/{model}:generateContent"
        auth = f"Authorization: Bearer {credential}\nx-goog-api-key: {credential}\n"
        body = {"contents": [{"parts": [{"text": TEXT}], "role": "user"}],
                "generationConfig": {"maxOutputTokens": 256}}
    started = time.monotonic()
    child = subprocess.run(
        ["/usr/bin/curl", "-q", "-sS", "--proto", "=https", "--max-time", "53",
         "--connect-timeout", "9", "--max-filesize", "512000", "--header", "@-",
         "--data-binary", json.dumps(body), "--write-out", "\\n%{http_code}\\n%{time_starttransfer}",
         BASE + path],
        input=("Content-Type: application/json\n" + auth).encode(), capture_output=True, timeout=55,
    )
    row = {"protocol": protocol, "requestedModel": model, "path": path,
           "elapsedMs": round((time.monotonic() - started) * 1000)}
    data_and_status, _, first_byte = child.stdout.rpartition(b"\n")
    payload, _, code = data_and_status.rpartition(b"\n")
    if code.isdigit() and int(code):
        row["http"] = int(code)
        try:
            row["firstByteMs"] = round(float(first_byte) * 1000)
        except ValueError:
            pass
    if child.returncode:
        row["transportError"] = f"curl_exit_{child.returncode}"

    done = False
    deltas = []
    models_seen = set()
    frame_count = 0
    for frame in payload.splitlines():
        if not frame.startswith(b"data:"):
            continue
        data = frame[5:].strip()
        if data == b"[DONE]":
            done = True
            continue
        try:
            event = as_object(json.loads(data))
        except (ValueError, UnicodeDecodeError):
            continue
        frame_count += 1
        if event.get("model"):
            models_seen.add(str(event["model"]))
        for choice in event.get("choices") or []:
            delta = as_object(as_object(choice).get("delta")).get("content")
            if isinstance(delta, str):
                deltas.append(delta)
    if frame_count or done:
        row.update(streamFrames=frame_count, completedSse=done, expectedReply=MARKER in "".join(deltas),
                   returnedModels=[label for value in sorted(models_seen) if (label := safe_label(value))])
    else:
        try:
            data = as_object(json.loads(payload))
        except (ValueError, UnicodeDecodeError):
            data = {}
        row["jsonEnvelope"] = sorted(set(data) & {"error", "message", "detail", "code", "status", "success",
                                                 "data", "type", "choices", "candidates"})
        err = as_object(data.get("error"))
        hint = err.get("message") or data.get("message") or data.get("error") or data.get("detail")
        if hint and not (200 <= row.get("http", 0) < 300):
            row["serviceReason"] = scrub(hint, credential)
        if isinstance(data.get("candidates"), list):
            row["expectedReply"] = any(
                MARKER in str(part.get("text", ""))
                for candidate in data["candidates"]
                for part in as_object(as_object(candidate).get("content")).get("parts") or []
                if isinstance(part, dict)
            )
    return row


if __name__ == "__main__":
    if not sys.stdin.isatty():
        raise SystemExit("A TTY is required to protect the credential.")
    key = getpass("Gateway credential (hidden): ")
    if not key or any(c.isspace() for c in key) or not key.isascii():
        raise SystemExit("Missing or invalid credential input.")
    tasks = [(model, mode) for mode in ("openai_sse", "gemini_generate") for model in MODELS]
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda args: try_request(key, *args), tasks))
    (ROOT / "gateway-retry-evidence.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2), flush=True)

