from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from tempfile import mkdtemp
from threading import Event, Thread
from urllib.parse import urlsplit

from acp_probe import ROOT
from agy_gateway_probe import check_model
from gateway_probe import MODELS


class ScriptedGemini(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        route = urlsplit(self.path).path
        model = route.split("/")[-1].split(":")[0]
        if model not in MODELS:
            self.send_response(403)
            self.end_headers()
            return
        size = int(self.headers.get("Content-Length", "0"))
        if not 0 < size <= 512000:
            self.send_error(400)
            return
        request = json.loads(self.rfile.read(size))
        history = request.get("contents") or []
        parts = [part for item in history for part in item.get("parts") or []]
        last = history[-1].get("parts") or []
        text = " ".join(part.get("text", "") for part in last)
        marker = "F35-CARBON-R2" if model == MODELS[0] else "F35-ARGON-R2"
        tool_result = next((part["functionResponse"].get("response") for part in last if "functionResponse" in part), None)
        tools = [entry["name"] for group in request.get("tools") or []
                 for entry in group.get("functionDeclarations") or []]
        fixture_tool = next((name for name in tools if name.endswith("report_probe")), None)

        if any("functionResponse" in part for part in last):
            step = "tool_result"
            result = {"text": "F35-MCP-FIXTURE" if "F35-MCP-FIXTURE" in json.dumps(last)
                      else "F35-FIXTURE-RESULT-MISSING"}
        elif "F35-TEST-CANCEL" in text:
            step = "wait_for_cancellation"
            self.server.cancel_ready.set()
            self.server.release_cancel.wait(timeout=4)
            result = {"text": "F35-CANCEL-LATE"}
        elif "Call the report_probe MCP tool" in text:
            step = "tool_request"
            result = ({"functionCall": {"name": fixture_tool, "args": {"value": "F35-PROBE-OK", "toolSummary": "Echo a synthetic probe marker"}},
                       "thoughtSignature": "RjM1LVNDUklQVEVELVRPT0w="}
                      if fixture_tool else {"text": "F35-TOOL-DECLARATION-MISSING"})
        elif any("asked you to remember" in part.get("text", "").lower() for part in parts):
            step = "resume_history"
            result = {"text": marker if any(marker in part.get("text", "") for part in parts) else "F35-HISTORY-MISSING"}
        else:
            step = "first_prompt"
            result = {"text": marker}
        self.server.evidence.append({"model": model, "step": step, "fixtureToolDeclared": bool(fixture_tool),
                                     "previousMarkerInRequest": any(marker in part.get("text", "") for part in parts[:-1]),
                                     **({"fixtureToolResponse": str(tool_result)[:300]} if tool_result else {})})
        response = {"candidates": [{"index": 0, "content": {"role": "model", "parts": [result]},
                                    "finishReason": "STOP"}], "modelVersion": model,
                    "usageMetadata": {"promptTokenCount": 12, "candidatesTokenCount": 5, "totalTokenCount": 17}}
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        self.wfile.write(b"data: " + json.dumps(response).encode() + b"\n\n")
        self.wfile.flush()


if __name__ == "__main__":
    target = Path(mkdtemp(prefix="agy-scripted-", dir=ROOT))
    server = ThreadingHTTPServer(("127.0.0.1", 0), ScriptedGemini)
    server.evidence = []
    server.cancel_ready = Event()
    server.release_cancel = Event()
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        endpoint = f"http://127.0.0.1:{server.server_port}"
        noop = lambda _row: None
        results = [
            {**check_model(target / "carbon-allow", MODELS[0], endpoint, True, noop,
                           cancel_ready=server.cancel_ready), "case": "carbon-allow-and-cancel"},
            {**check_model(target / "carbon-deny", MODELS[0], endpoint, True, noop,
                           allow_fixture_tool=False), "case": "carbon-deny"},
            {**check_model(target / "argon", MODELS[1], endpoint, False, noop), "case": "argon"},
        ]
    finally:
        server.release_cancel.set()
        server.shutdown()
        server.server_close()
        thread.join(timeout=1)
    result = {"testMode": "real-agy-with-scripted-local-model", "noLiveModelResult": True,
              "requests": server.evidence, "results": results}
    (ROOT / "agy-scripted-evidence.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

